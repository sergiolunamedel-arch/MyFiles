"""dast_api.py — DAST crawler + API security scanner engines.

Exposes:
    DastConfig, ApiConfig  (dataclasses)
    run_dast(cfg, out_dir, log, cancel) → (summary_dict, path)
    run_api(cfg, out_dir, log, cancel)  → (summary_dict, path)

Internal helpers (_make_opener, _fetch, _Throttle, …) are kept here and NOT
re-exported; only the two run_* functions and the config dataclasses are part
of the public API.
"""

from __future__ import annotations

import base64, json, re as _re, ssl, threading, time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Callable, Optional
from urllib.parse import (urlparse, urljoin, urlencode,
                          parse_qsl, urlunparse)
from urllib.request import Request, build_opener, HTTPCookieProcessor
from urllib.error import URLError, HTTPError
from http.cookiejar import CookieJar


# ── Shared network constants ──────────────────────────────────────────────────
_DAST_UA  = "VulnScanner-DAST/1.0 (+local security testing)"
_DAST_SVR = {"critical": 4, "high": 3, "medium": 2, "low": 1}

_XSS_PROBE  = "xss<svg/onload=1>vsxx"
_SQL_ERRORS = [
    "you have an error in your sql syntax", "warning: mysql",
    "unclosed quotation mark", "quoted string not properly terminated",
    "pg_query()", "psql:", "sqlite3.OperationalError",
    "ORA-00933", "SQLSTATE[", "Microsoft OLE DB Provider for SQL Server",
]

_DISC_PATHS = [
    ("/.env", ".env file exposed", "critical"),
    ("/.env.local", ".env.local file exposed", "critical"),
    ("/.env.production", ".env.production exposed", "critical"),
    ("/.git/HEAD", ".git repository exposed", "high"),
    ("/.git/config", ".git config exposed", "high"),
    ("/.svn/entries", ".svn metadata exposed", "high"),
    ("/.hg/requires", "Mercurial metadata exposed", "high"),
    ("/.DS_Store", ".DS_Store directory leak", "low"),
    ("/server-status", "Apache server-status exposed", "high"),
    ("/phpinfo.php", "phpinfo() page exposed", "high"),
    ("/info.php", "phpinfo() page exposed", "high"),
    ("/wp-config.php.bak", "WordPress config backup", "critical"),
    ("/.htpasswd", ".htpasswd exposed", "critical"),
    ("/.htaccess", ".htaccess exposed", "medium"),
    ("/web.config", "web.config exposed", "medium"),
    ("/.aws/credentials", "AWS credentials file exposed", "critical"),
    ("/.npmrc", ".npmrc (may leak tokens)", "high"),
    ("/.dockercfg", "Docker auth config exposed", "high"),
    ("/Dockerfile", "Dockerfile exposed", "low"),
    ("/docker-compose.yml", "docker-compose.yml exposed", "medium"),
    ("/.gitlab-ci.yml", "CI pipeline config exposed", "low"),
    ("/backup.zip", "backup.zip exposed", "high"),
    ("/backup.sql", "SQL dump exposed", "critical"),
    ("/db.sqlite", "SQLite database exposed", "critical"),
    ("/actuator/env", "Spring actuator /env exposed", "critical"),
    ("/actuator/health", "Spring actuator /health", "low"),
    ("/actuator/heapdump", "Spring actuator heapdump", "critical"),
    ("/api/docs", "Swagger/OpenAPI docs public", "low"),
    ("/swagger-ui.html", "Swagger UI public", "low"),
    ("/v2/api-docs", "Swagger v2 spec public", "low"),
    ("/openapi.json", "OpenAPI spec public", "low"),
    ("/.well-known/security.txt", "security.txt present (info)", "low"),
]

_SEC_HEADERS = [
    ("strict-transport-security", "Missing HSTS", "medium"),
    ("content-security-policy", "Missing Content-Security-Policy", "medium"),
    ("x-content-type-options", "Missing X-Content-Type-Options", "low"),
    ("x-frame-options", "Missing X-Frame-Options", "low"),
    ("referrer-policy", "Missing Referrer-Policy", "low"),
    ("permissions-policy", "Missing Permissions-Policy", "low"),
    ("cross-origin-opener-policy", "Missing Cross-Origin-Opener-Policy", "low"),
    ("cross-origin-resource-policy", "Missing Cross-Origin-Resource-Policy", "low"),
]

_DIRLIST_MARKERS = (
    "<title>index of /", "directory listing for",
    "<h1>index of /", "[to parent directory]")

_API_REDIRECT = ("next", "redirect", "url", "return",
                 "returnto", "dest", "callback")

# ── Selenium macro JS (injected into recorder browser) ────────────────────────
# Robust recorder. Key design points that fix the "captured 0 interactions" bug:
#   • Events are persisted to sessionStorage, NOT a bare window variable, so they
#     survive the navigation that login inevitably triggers (same-origin nav keeps
#     sessionStorage intact; the Python side ALSO drains it every poll so even a
#     cross-origin jump loses at most one polling window of events).
#   • We listen to `input` (fires on every keystroke → captures the final value
#     even if the field never blurs), `change`, `click`, AND — crucially — the
#     form `submit` event and an Enter `keydown`. A login submitted with the Enter
#     key fires `submit` but never a `click`; the old recorder missed it entirely.
#   • Selectors prefer #id, then data-testid, name, aria-label, then a short
#     structural path — industry-standard locator priority.
#   • Password VALUES are captured so the login can be replayed for the logout
#     recorder, but they stay in the running session only and are stripped from
#     every saved profile / condition file.
_MACRO_JS = r"""
(function(){
  if (window.__macro_installed) return;
  window.__macro_installed = true;
  var KEY = '__vulnscan_macro__';

  // Use BOTH localStorage and sessionStorage. localStorage survives full-page
  // navigations within the same origin more reliably than sessionStorage in
  // some browsers, which matters for logout flows that redirect immediately
  // after the click. We merge both on load and de-dup by the running index `i`.
  function _readStore(store){
    try { return JSON.parse(store.getItem(KEY) || '[]'); } catch(e){ return []; }
  }
  function load(){
    var a = _readStore(sessionStorage);
    var b = _readStore(localStorage);
    if (!b.length) return a;
    if (!a.length) return b;
    // Merge, de-dup by i
    var seen = {}, out = [];
    a.concat(b).forEach(function(e){
      var k = e && e.i;
      if (k == null || !seen[k]) { if (k != null) seen[k] = 1; out.push(e); }
    });
    out.sort(function(x, y){ return (x.i || 0) - (y.i || 0); });
    return out;
  }
  function save(a){
    var s = JSON.stringify(a);
    try { sessionStorage.setItem(KEY, s); } catch(e){}
    try { localStorage.setItem(KEY, s); } catch(e){}
  }
  function push(entry){
    var a = load();
    entry.i   = (a.length ? a[a.length-1].i : 0) + 1;
    entry.url = location.href;
    a.push(entry); save(a);
  }

  function esc(s){
    return (window.CSS && CSS.escape) ? CSS.escape(s)
      : String(s).replace(/[^a-zA-Z0-9_-]/g, function(c){ return '\\' + c; });
  }
  function attr(el, name){ try { return el.getAttribute(name); } catch(e){ return null; } }

  // True for ephemeral framework IDs that change every page load:
  // _xfUid-1-1781304878 (XenForo), :r0: (React 18), ember123 (Ember),
  // mat-input-0 (Angular Material), yui_… (YUI) — or any id with 6+ digits.
  function _isDynId(id){
    if (!id) return false;
    if (/\d{6,}/.test(id)) return true;
    if (/^:r[0-9a-z]+:$/i.test(id)) return true;
    if (/^ember\d+$/i.test(id)) return true;
    if (/^__BVID__\d+/.test(id)) return true;
    if (/^yui_/.test(id)) return true;
    if (/^mat-(input|select|checkbox|radio|slide-toggle)-\d+$/.test(id)) return true;
    return false;
  }

  // Stable selector: skips dynamic IDs, prefers name/autocomplete/aria-label.
  function sel(el){
    if (!el || el.nodeType !== 1) return null;
    var tag = el.tagName.toLowerCase();
    if (el.id && !_isDynId(el.id)) return '#' + esc(el.id);
    var dt = attr(el,'data-testid')||attr(el,'data-test')||attr(el,'data-cy')||attr(el,'data-qa');
    if (dt) return tag + '[data-testid="' + String(dt).replace(/"/g,'\\"') + '"]';
    if (el.name) return tag + '[name="' + esc(el.name) + '"]';
    var ac = attr(el,'autocomplete');
    if (ac && ac !== 'on' && ac !== 'off'){
      var t2 = attr(el,'type');
      return tag + (t2 ? '[autocomplete="'+ac+'"][type="'+t2+'"]'
                       : '[autocomplete="'+ac+'"]');
    }
    var al = attr(el,'aria-label');
    if (al) return tag + '[aria-label="' + String(al).replace(/"/g,'\\"').slice(0,60) + '"]';
    var parts = [], p = el, depth = 0;
    while (p && p.nodeType === 1 && depth < 6){
      if (p.id && !_isDynId(p.id)){ parts.unshift('#' + esc(p.id)); break; }
      var n = p.tagName.toLowerCase();
      if (p.classList && p.classList.length)
        n += '.' + Array.from(p.classList).slice(0,2).map(esc).join('.');
      var par = p.parentNode;
      if (par){ var idx = Array.from(par.children).indexOf(p)+1; if(idx) n+=':nth-child('+idx+')'; }
      parts.unshift(n); p = p.parentElement; depth++;
    }
    return parts.join(' > ');
  }

  // Ordered fallback selectors stored alongside the stable primary.
  // Tried in sequence when the primary doesn't match at replay time.
  function fallbackSels(el){
    if (!el || el.nodeType !== 1) return [];
    var tag = el.tagName.toLowerCase(), fb = [];
    if (el.id) fb.push('#' + esc(el.id));          // dynamic id (same session)
    var t = attr(el,'type'); if (t) fb.push(tag+'[type="'+t+'"]');
    var ph = attr(el,'placeholder');
    if (ph) fb.push(tag+'[placeholder="'+String(ph).replace(/"/g,'\\"').slice(0,60)+'"]');
    // Full structural path including dynamic-id ancestors
    var parts2=[], p2=el, d2=0;
    while(p2 && p2.nodeType===1 && d2<6){
      if(p2.id){ parts2.unshift('#'+esc(p2.id)); break; }
      var n2=p2.tagName.toLowerCase();
      if(p2.classList && p2.classList.length) n2+='.'+Array.from(p2.classList).slice(0,2).map(esc).join('.');
      var par2=p2.parentNode;
      if(par2){ var idx2=Array.from(par2.children).indexOf(p2)+1; if(idx2) n2+=':nth-child('+idx2+')'; }
      parts2.unshift(n2); p2=p2.parentElement; d2++;
    }
    var fp=parts2.join(' > '); if(fp && fp!==fb[0]) fb.push(fp);
    return fb;
  }

  function role(el){
    var type = (el.type || '').toLowerCase();
    var ac   = (attr(el,'autocomplete') || '').toLowerCase();
    if (type === 'password' || ac === 'current-password' || ac === 'new-password') return 'password';
    if (ac === 'username' || ac === 'email' || type === 'email') return 'username';
    var hay = ((el.name||'')+' '+(el.id||'')+' '+(el.placeholder||'')+' '+(attr(el,'aria-label')||'')).toLowerCase();
    if (/(user|email|e-?mail|login|logon|correo|usuario|account|cuenta|phone|tel|m[oó]vil|dni|nif|rfc|curp)/.test(hay)) return 'username';
    return 'other';
  }

  function recordField(el){
    if (!el || !('value' in el) || el.type === 'hidden') return;
    var r = role(el);
    push({ kind:'field', selector: sel(el), fallback_selectors: fallbackSels(el),
           value: el.value, ftype: (el.type || 'text').toLowerCase(), role: r });
  }

  document.addEventListener('input',  function(e){ recordField(e.target); }, true);
  document.addEventListener('change', function(e){ recordField(e.target); }, true);
  document.addEventListener('click',  function(e){
    if (!e.isTrusted) return;
    var t = e.target;
    var b = (t && t.closest) ? t.closest('button,a,input[type=submit],input[type=button],[role=button]') : null;
    var tgt = b || t;
    // Capture href from <a> tags; also check parent anchors for SPAs where the
    // click target is a child <span> or <svg> inside the <a>.
    var href = '';
    if (tgt.tagName === 'A') {
      href = tgt.getAttribute('href') || '';
    } else {
      var anc = tgt.closest ? tgt.closest('a') : null;
      if (anc) href = anc.getAttribute('href') || '';
    }
    // Collect all text signals: innerText + aria-label + id + classes + data-*.
    // Walk up to 3 ancestors so buttons like <li id="logout-item"><button><span>Salir</span>
    // are still detected even when the leaf element itself has no keyword.
    var rawText = (tgt.innerText || tgt.value || tgt.getAttribute('aria-label') || '').trim();
    var rawId   = (tgt.id || '');
    var rawCls  = (tgt.className && typeof tgt.className === 'string') ? tgt.className : '';
    var anc2 = tgt.parentElement;
    for (var d = 0; d < 3 && anc2 && anc2.nodeType === 1; d++, anc2 = anc2.parentElement) {
      if (!rawId  && anc2.id)       rawId  = anc2.id;
      if (!rawCls && anc2.className && typeof anc2.className === 'string') rawCls = anc2.className;
      if (!rawText && anc2.innerText) rawText = anc2.innerText.trim().slice(0, 80);
    }
    var dataAction = attr(tgt,'data-action')||attr(tgt,'data-event')||
                     attr(tgt,'data-cy')||attr(tgt,'data-testid')||'';
    push({ kind:'click', selector: sel(tgt),
           fallback_selectors: fallbackSels(tgt),
           href: href,
           text: rawText.slice(0, 80),
           el_id: rawId.slice(0, 80),
           el_cls: rawCls.slice(0, 120),
           data_action: dataAction.slice(0, 80) });
  }, true);
  document.addEventListener('submit', function(e){
    var f = e.target;
    var b = (f && f.querySelector)
      ? f.querySelector('button[type=submit],input[type=submit],button:not([type])') : null;
    push({ kind:'submit', form: sel(f), button: b ? sel(b) : null });
  }, true);
  document.addEventListener('keydown', function(e){
    if (!e.isTrusted || e.key !== 'Enter') return;
    var t = e.target;
    if (t && 'value' in t) recordField(t);          // flush the current value first
    var f = (t && t.form) ? t.form : (t && t.closest ? t.closest('form') : null);
    push({ kind:'enter', selector: sel(t), form: f ? sel(f) : null });
  }, true);
})();
"""

# Reads (and clears) the buffered events. Python calls this every poll so that
# events captured just before a navigation are pulled out before the page that
# holds them can be torn down.
_MACRO_DRAIN_JS = r"""
return (function(){
  try {
    var KEY = '__vulnscan_macro__';
    function rd(store){ try { return JSON.parse(store.getItem(KEY) || '[]'); } catch(e){ return []; } }
    // Merge both stores (de-dup by running index i) so a click captured just
    // before a navigation isn't lost if only one backend kept it.
    var a = rd(sessionStorage), b = rd(localStorage);
    var seen = {}, out = [];
    a.concat(b).forEach(function(e){
      var k = e && e.i;
      if (k == null || !seen[k]) { if (k != null) seen[k] = 1; out.push(e); }
    });
    out.sort(function(x, y){ return (x.i || 0) - (y.i || 0); });
    // Clear both
    try { sessionStorage.setItem(KEY, '[]'); } catch(e){}
    try { localStorage.setItem(KEY, '[]'); } catch(e){}
    return JSON.stringify(out);
  } catch(e){ return '[]'; }
})();
"""

# NOTE: Selenium's execute_script only hands a value back to Python when the
# script *itself* runs a top-level `return`. A bare IIFE — `(function(){…})();`
# — evaluates but returns nothing, so the previous version always gave Python
# `None` and the capture popup came up blank. The leading `return` below is the
# fix; everything after it is wrapped in an IIFE purely for local scoping.
_LOGOUT_CAPTURE_JS = r"""
return (function(){
    var url   = window.location.href;
    var title = document.title || '';
    var hints = [];
    var seen  = {};
    // NOTE: no `form` or other big containers here — a form's innerText is the
    // whole multi-line form text, which used to flood the review popup with a
    // giant blob. Containers are summarised by the has_* flags below instead.
    var nodes = document.querySelectorAll(
        'h1,h2,input[type=email],input[type=text],input[type=password],' +
        'input[name*=user],input[name*=login],a[href*=login],a[href*=signin],' +
        'button,input[type=submit]');
    nodes.forEach(function(el){
        // Skip invisible elements — they aren't evidence of anything on screen.
        if (el.offsetParent === null && el.tagName !== 'INPUT') return;
        var t = (el.innerText||el.value||el.placeholder||'')+'';
        t = t.replace(/\s+/g,' ').trim().slice(0,80);   // collapse newlines/runs
        if(!t || seen[t.toLowerCase()]) return;
        seen[t.toLowerCase()] = 1;
        hints.push(t);
    });
    // Strong signals that this is a logged-OUT page: a password field and/or a
    // recognisable login form re-appeared. The GUI uses these to help the user
    // confirm they really reached the logout state.
    var hasPassword  = !!document.querySelector('input[type=password]');
    var hasLoginForm = !!document.querySelector(
        'form[action*=login],form[action*=signin],form[id*=login],' +
        'form[class*=login],form[id*=signin],form[class*=signin]');
    return JSON.stringify({
        url: url,
        title: title,
        hints: hints.slice(0, 12),
        has_password_field: hasPassword,
        has_login_form: hasLoginForm
    });
})();
"""


# ── Dataclasses ───────────────────────────────────────────────────────────────
@dataclass
class DastConfig:
    url: str = ""
    auth_type: str = "none"
    username: str = "";     password: str = ""
    token: str = "";        cookie: str = ""
    header_name: str = "";  header_value: str = ""
    login_url: str = "";    login_data: str = ""
    profile: str = "passive"; max_pages: int = 30
    timeout: int = 12;      verify_tls: bool = True
    include_subdomains: bool = False
    selenium_browser: str = "chrome"; selenium_binary: str = ""
    selenium_headless: bool = True
    selenium_wait_seconds: int = 15
    selenium_login_url: str = "";      selenium_user_selector: str = ""
    selenium_user_value: str = "";     selenium_pass_selector: str = ""
    selenium_pass_value: str = "";     selenium_submit_selector: str = ""
    selenium_extra_steps: str = ""
    selenium_macro: str = ""   # full ordered LOGIN recording, replayed step-by-step
    selenium_logout_macro: str = ""   # full ordered LOGOUT recording, replayed step-by-step
    login_success_selector: str = "";  login_success_text: str = ""
    logout_url_re: str = "";           auto_relogin: bool = True
    # Multilingual (EN + ES) logout-path exclusion so the crawler never follows
    # a "cerrar sesión / salir / desconectar" link and kills the session.
    exclude_re: str = (r"(?i)/(logout|log-?out|log-?off|signout|sign-?out|"
                       r"cerrar[-_]?sesion|cerrarsesion|cerrar[-_]?session|salir|"
                       r"desconectar|desconexion|deslog\w*|api/logout)\b")
    rate_limit_rps: float = 8.0;       proxy: str = ""
    concurrency: int = 4


@dataclass
class ApiConfig:
    spec_source: str = "";  base_url: str = ""
    auth_type: str = "none"
    username: str = "";     password: str = ""
    token: str = "";        cookie: str = ""
    header_name: str = "";  header_value: str = ""
    profile: str = "passive"; max_endpoints: int = 80
    timeout: int = 12;      verify_tls: bool = True
    rate_limit_rps: float = 8.0; proxy: str = ""
    exclude_re: str = (r"(?i)/(logout|log-?out|log-?off|signout|sign-?out|"
                       r"cerrar[-_]?sesion|cerrarsesion|cerrar[-_]?session|salir|"
                       r"desconectar|desconexion|deslog\w*)\b")
    concurrency: int = 6
    url: str = ""   # duck-typing for _make_opener


# ── Network primitives ────────────────────────────────────────────────────────
class _Throttle:
    """Token-bucket-ish spacer. Thread-safe across a ThreadPoolExecutor."""
    def __init__(self, rps: float):
        self._min = (1.0 / rps) if rps and rps > 0 else 0.0
        self._next = 0.0
        self._lock = threading.Lock()

    def wait(self):
        if self._min <= 0: return
        with self._lock:
            now = time.monotonic()
            sleep_for = self._next - now
            self._next = max(now, self._next) + self._min
        if sleep_for > 0:
            time.sleep(sleep_for)


def _make_opener(cfg) -> tuple[Any, CookieJar, dict]:
    jar = CookieJar()
    ctx = ssl.create_default_context()
    if not cfg.verify_tls:
        ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
    from urllib.request import HTTPSHandler, ProxyHandler
    handlers: list = [HTTPCookieProcessor(jar), HTTPSHandler(context=ctx)]
    if cfg.proxy:
        handlers.append(ProxyHandler({"http": cfg.proxy, "https": cfg.proxy}))
    opener = build_opener(*handlers)
    hdrs = {"User-Agent": _DAST_UA, "Accept": "*/*"}
    if   cfg.auth_type == "basic"  and cfg.username:
        tok = base64.b64encode(
            f"{cfg.username}:{cfg.password}".encode()).decode()
        hdrs["Authorization"] = f"Basic {tok}"
    elif cfg.auth_type == "bearer" and cfg.token:
        hdrs["Authorization"] = f"Bearer {cfg.token}"
    elif cfg.auth_type == "cookie" and cfg.cookie:
        hdrs["Cookie"] = cfg.cookie
    elif cfg.auth_type == "header" and cfg.header_name:
        hdrs[cfg.header_name] = cfg.header_value
    return opener, jar, hdrs


def _clone_opener(cfg, jar: CookieJar):
    """Build an independent opener carrying a snapshot of jar's cookies."""
    from urllib.request import HTTPSHandler, ProxyHandler
    ctx = ssl.create_default_context()
    if not getattr(cfg, "verify_tls", True):
        ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
    new_jar = CookieJar()
    for c in jar:
        try: new_jar.set_cookie(c)
        except Exception: pass
    handlers: list = [HTTPCookieProcessor(new_jar), HTTPSHandler(context=ctx)]
    if getattr(cfg, "proxy", ""):
        handlers.append(
            ProxyHandler({"http": cfg.proxy, "https": cfg.proxy}))
    return build_opener(*handlers)


def _fetch(opener, hdrs, url, *, method="GET", data=None,
           timeout=12, extra=None) -> tuple[int, dict, bytes, str]:
    req = Request(url, data=data, method=method,
                  headers={**hdrs, **(extra or {})})
    try:
        with opener.open(req, timeout=timeout) as r:
            return r.status, dict(r.headers), r.read(1_500_000), r.geturl()
    except HTTPError as e:
        try: body = e.read(500_000)
        except Exception: body = b""
        return e.code, dict(e.headers or {}), body, url
    except (URLError, TimeoutError, ssl.SSLError, ConnectionError) as e:
        return 0, {}, b"", f"error: {e!r}"


def _inject_cookies(jar: CookieJar, cookies: list[dict]) -> None:
    from http.cookiejar import Cookie
    for c in cookies:
        domain = c.get("domain", "") or ""
        jar.set_cookie(Cookie(
            version=0, name=c["name"], value=c.get("value") or "",
            port=None, port_specified=False, domain=domain,
            domain_specified=bool(domain),
            domain_initial_dot=domain.startswith("."),
            path=c.get("path") or "/", path_specified=True,
            secure=bool(c.get("secure")),
            expires=c.get("expiry") or c.get("expires"),
            discard=False, comment=None, comment_url=None,
            rest={"HttpOnly": ""} if c.get("httpOnly") else {},
            rfc2109=False))


def _same_origin(base: str, candidate: str, subdomains: bool) -> bool:
    try:
        b, c = urlparse(base), urlparse(candidate)
        if c.scheme not in ("http", "https"): return False
        if subdomains:
            return bool(c.hostname) and (
                c.hostname == b.hostname
                or c.hostname.endswith("." + (b.hostname or "")))
        return c.hostname == b.hostname and (c.port or 0) == (b.port or 0)
    except Exception:
        return False


# ── HTML helpers ──────────────────────────────────────────────────────────────
class _LinkExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links: list[str] = []
        # Rich link records: {href, text, id, cls, rel, aria} — used to filter
        # out logout anchors by their visible text / attributes even when the
        # href itself has no logout keyword.
        self.link_meta: list[dict] = []
        self.forms: list[dict] = []
        self._cur_form: Optional[dict] = None
        self._cur_a: Optional[dict] = None   # anchor currently open (for text)

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "a" and a.get("href"):
            self.links.append(a["href"])
            self._cur_a = {
                "href": a["href"],
                "text": "",
                "id":   a.get("id") or "",
                "cls":  a.get("class") or "",
                "rel":  a.get("rel") or "",
                "aria": a.get("aria-label") or "",
                "data_action": a.get("data-action") or a.get("data-method") or "",
            }
        elif tag == "form":
            self._cur_form = {"action": a.get("action") or "",
                              "method": (a.get("method") or "get").lower(),
                              "inputs": []}
        elif tag in ("input", "textarea", "select") and self._cur_form is not None:
            self._cur_form["inputs"].append(
                {"name": a.get("name") or "", "value": a.get("value") or "test"})

    def handle_data(self, data):
        if self._cur_a is not None and data:
            # Accumulate the anchor's visible text (capped).
            self._cur_a["text"] = (self._cur_a["text"] + " " + data.strip())[:120].strip()

    def handle_endtag(self, tag):
        if tag == "a" and self._cur_a is not None:
            self.link_meta.append(self._cur_a)
            self._cur_a = None
        elif tag == "form" and self._cur_form is not None:
            self.forms.append(self._cur_form)
            self._cur_form = None


# ── Passive header helpers (shared between DAST & API) ────────────────────────
def _passive_header_findings(lower: dict, fu: str, add) -> None:
    if "server" in lower:
        add("low", f"Server banner leak: {lower['server']}", fu,
            f"Server: {lower['server']}", "CWE-200", "headers")
    if "x-powered-by" in lower:
        add("low", f"X-Powered-By leak: {lower['x-powered-by']}", fu,
            f"X-Powered-By: {lower['x-powered-by']}", "CWE-200", "headers")
    acao  = lower.get("access-control-allow-origin")
    acred = (lower.get("access-control-allow-credentials") or "").lower() == "true"
    if acao == "*" and acred:
        add("high", "CORS: ACAO=* with credentials", fu,
            "ACAO=*  ACAC=true", "CWE-942", "cors")
    elif acao == "*":
        add("low", "CORS: Access-Control-Allow-Origin: *", fu,
            "ACAO=*", "CWE-942", "cors")


# ── Browser detection ─────────────────────────────────────────────────────────
# Maps each supported browser key to the WebDriver engine it needs.
#   chromium → ChromeDriver (Chrome/Brave/Opera/Opera GX/Vivaldi/Chromium)
#   edge     → EdgeDriver
#   firefox  → GeckoDriver
_BROWSER_ENGINE = {
    "chrome": "chromium", "chromium": "chromium", "brave": "chromium",
    "opera": "chromium", "opera_gx": "chromium", "vivaldi": "chromium",
    "edge": "edge", "firefox": "firefox",
}


def detect_browsers() -> "dict[str, dict]":
    """Probe the host for installed browsers.

    Returns an *ordered* dict ``{key: {"name","binary","engine"}}`` containing
    ONLY browsers that are actually installed, so the UI never offers something
    that can't launch.  Pure stdlib — safe to call before Selenium is imported.
    """
    import os, shutil, platform
    system = platform.system()

    def _first(paths):
        for p in paths:
            if not p:
                continue
            q = os.path.expandvars(os.path.expanduser(p))
            looks_like_path = (os.sep in q) or ("/" in q) or (":" in q[1:3])
            if looks_like_path:
                if os.path.exists(q):
                    return q
            else:
                w = shutil.which(q)
                if w:
                    return w
        return None

    if system == "Windows":
        catalog = [
            ("chrome", "Google Chrome", "chromium", [
                r"%ProgramFiles%\Google\Chrome\Application\chrome.exe",
                r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe",
                r"%LocalAppData%\Google\Chrome\Application\chrome.exe"]),
            ("edge", "Microsoft Edge", "edge", [
                r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe",
                r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"]),
            ("firefox", "Mozilla Firefox", "firefox", [
                r"%ProgramFiles%\Mozilla Firefox\firefox.exe",
                r"%ProgramFiles(x86)%\Mozilla Firefox\firefox.exe"]),
            ("brave", "Brave", "chromium", [
                r"%ProgramFiles%\BraveSoftware\Brave-Browser\Application\brave.exe",
                r"%ProgramFiles(x86)%\BraveSoftware\Brave-Browser\Application\brave.exe",
                r"%LocalAppData%\BraveSoftware\Brave-Browser\Application\brave.exe"]),
            ("opera", "Opera", "chromium", [
                r"%LocalAppData%\Programs\Opera\opera.exe",
                r"%ProgramFiles%\Opera\opera.exe",
                r"%ProgramFiles(x86)%\Opera\opera.exe"]),
            ("opera_gx", "Opera GX", "chromium", [
                r"%LocalAppData%\Programs\Opera GX\opera.exe",
                r"%ProgramFiles%\Opera GX\opera.exe"]),
            ("vivaldi", "Vivaldi", "chromium", [
                r"%LocalAppData%\Vivaldi\Application\vivaldi.exe",
                r"%ProgramFiles%\Vivaldi\Application\vivaldi.exe"]),
            ("chromium", "Chromium", "chromium", [
                r"%LocalAppData%\Chromium\Application\chrome.exe",
                r"%ProgramFiles%\Chromium\Application\chrome.exe"]),
        ]
    elif system == "Darwin":
        catalog = [
            ("chrome", "Google Chrome", "chromium",
             ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"]),
            ("edge", "Microsoft Edge", "edge",
             ["/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"]),
            ("firefox", "Mozilla Firefox", "firefox",
             ["/Applications/Firefox.app/Contents/MacOS/firefox"]),
            ("brave", "Brave", "chromium",
             ["/Applications/Brave Browser.app/Contents/MacOS/Brave Browser"]),
            ("opera", "Opera", "chromium",
             ["/Applications/Opera.app/Contents/MacOS/Opera"]),
            ("opera_gx", "Opera GX", "chromium",
             ["/Applications/Opera GX.app/Contents/MacOS/Opera"]),
            ("vivaldi", "Vivaldi", "chromium",
             ["/Applications/Vivaldi.app/Contents/MacOS/Vivaldi"]),
            ("chromium", "Chromium", "chromium",
             ["/Applications/Chromium.app/Contents/MacOS/Chromium"]),
        ]
    else:  # Linux / *BSD
        catalog = [
            ("chrome", "Google Chrome", "chromium",
             ["google-chrome", "google-chrome-stable",
              "/usr/bin/google-chrome", "/opt/google/chrome/chrome"]),
            ("edge", "Microsoft Edge", "edge",
             ["microsoft-edge", "microsoft-edge-stable", "/usr/bin/microsoft-edge"]),
            ("firefox", "Mozilla Firefox", "firefox",
             ["firefox", "firefox-esr", "/usr/bin/firefox", "/snap/bin/firefox"]),
            ("brave", "Brave", "chromium",
             ["brave-browser", "brave", "/usr/bin/brave-browser"]),
            ("opera", "Opera", "chromium", ["opera", "/usr/bin/opera"]),
            ("vivaldi", "Vivaldi", "chromium",
             ["vivaldi", "vivaldi-stable", "/usr/bin/vivaldi"]),
            ("chromium", "Chromium", "chromium",
             ["chromium", "chromium-browser", "/usr/bin/chromium", "/snap/bin/chromium"]),
        ]

    found: "dict[str, dict]" = {}
    for key, name, engine, paths in catalog:
        binp = _first(paths)
        if binp:
            found[key] = {"name": name, "binary": binp, "engine": engine}
    return found


# ── Selenium driver factory ───────────────────────────────────────────────────
def _make_driver(cfg: DastConfig, *, headless: bool,
                 log: Callable[[str], None] = lambda _: None):
    from selenium import webdriver

    browser = (cfg.selenium_browser or "chrome").lower()
    engine  = _BROWSER_ENGINE.get(browser, "chromium")
    binary  = (getattr(cfg, "selenium_binary", "") or "").strip()

    # Resolve the binary from on-disk detection when the GUI didn't pass one and
    # the browser isn't one that Selenium Manager finds on its own.
    if not binary and browser not in ("chrome", "edge", "firefox"):
        try:
            d = detect_browsers().get(browser)
            if d:
                binary = d["binary"]
        except Exception:
            pass

    log(f"[dast] launching {browser} (engine={engine}, headless={headless}, "
        f"binary={binary or 'auto'})")

    # ── Firefox ──────────────────────────────────────────────────────────────
    if engine == "firefox":
        opts = webdriver.FirefoxOptions()
        if headless: opts.add_argument("-headless")
        if binary:   opts.binary_location = binary
        try: opts.page_load_strategy = "eager"
        except Exception: pass
        if not cfg.verify_tls: opts.accept_insecure_certs = True
        if cfg.proxy:
            host, _, port = cfg.proxy.replace("http://", "").replace("https://", "").partition(":")
            opts.set_preference("network.proxy.type", 1)
            for scheme in ("http", "ssl"):
                opts.set_preference(f"network.proxy.{scheme}", host)
                opts.set_preference(f"network.proxy.{scheme}_port", int(port or 8080))
        try:
            return webdriver.Firefox(options=opts)               # Selenium Manager
        except Exception as e:
            log(f"[dast] Selenium Manager (firefox) failed ({e!r}); webdriver-manager")
            from webdriver_manager.firefox import GeckoDriverManager
            from selenium.webdriver.firefox.service import Service
            return webdriver.Firefox(
                service=Service(GeckoDriverManager().install()), options=opts)

    # Chromium/Edge startup is often dominated by first-run checks, component
    # updates, background networking and — the big one on Linux/macOS — the OS
    # keyring handshake, which can block for several seconds. These flags skip
    # all of that so the window opens promptly.
    def _chromium_speed(opts):
        for a in (
            "--no-first-run", "--no-default-browser-check", "--no-service-autorun",
            "--disable-extensions", "--disable-background-networking",
            "--disable-component-update", "--disable-default-apps",
            "--disable-sync", "--disable-translate",
            "--disable-background-timer-throttling",
            "--disable-backgrounding-occluded-windows",
            "--disable-renderer-backgrounding", "--metrics-recording-only",
            "--mute-audio", "--password-store=basic", "--use-mock-keychain",
            "--disable-features=Translate,OptimizationHints,MediaRouter,"
            "CalculateNativeWinOcclusion",
        ):
            opts.add_argument(a)
        try: opts.page_load_strategy = "eager"   # return on DOMContentLoaded
        except Exception: pass
        return opts

    # ── Edge ─────────────────────────────────────────────────────────────────
    if engine == "edge":
        from selenium.webdriver.edge.options import Options as EdgeOptions
        opts = EdgeOptions()
        if headless: opts.add_argument("--headless=new")
        opts.add_argument("--no-sandbox"); opts.add_argument("--disable-dev-shm-usage")
        opts.add_argument("--disable-gpu")
        _chromium_speed(opts)
        if binary: opts.binary_location = binary
        if not cfg.verify_tls:
            opts.add_argument("--ignore-certificate-errors")
            opts.set_capability("acceptInsecureCerts", True)
        if cfg.proxy: opts.add_argument(f"--proxy-server={cfg.proxy}")
        try:
            return webdriver.Edge(options=opts)                  # Selenium Manager
        except Exception as e:
            log(f"[dast] Selenium Manager (edge) failed ({e!r}); webdriver-manager")
            from webdriver_manager.microsoft import EdgeChromiumDriverManager
            from selenium.webdriver.edge.service import Service
            return webdriver.Edge(
                service=Service(EdgeChromiumDriverManager().install()), options=opts)

    # ── Chromium family (chrome, brave, opera, opera_gx, vivaldi, chromium) ──
    opts = webdriver.ChromeOptions()
    if headless: opts.add_argument("--headless=new")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-dev-shm-usage")
    opts.add_argument("--disable-gpu")
    _chromium_speed(opts)
    if binary: opts.binary_location = binary
    if not cfg.verify_tls:
        opts.add_argument("--ignore-certificate-errors")
        opts.set_capability("acceptInsecureCerts", True)
    if cfg.proxy: opts.add_argument(f"--proxy-server={cfg.proxy}")

    try:
        return webdriver.Chrome(options=opts)                    # Selenium Manager
    except Exception as e:
        log(f"[dast] Selenium Manager (chromium) failed ({e!r}); webdriver-manager")
        from webdriver_manager.chrome import ChromeDriverManager
        from selenium.webdriver.chrome.service import Service
        try:
            from webdriver_manager.core.os_manager import ChromeType
            ctype = (ChromeType.BRAVE if browser == "brave"
                     else ChromeType.CHROMIUM if browser == "chromium"
                     else ChromeType.GOOGLE)
            svc = Service(ChromeDriverManager(chrome_type=ctype).install())
        except Exception:
            svc = Service(ChromeDriverManager().install())
        return webdriver.Chrome(service=svc, options=opts)


def _replay_login_macro(driver, macro, *, pass_value=None, wait_seconds=15,
                        log=lambda *_: None) -> bool:
    """Replay every recorded step in order, handling:
    - Dynamic IDs (XenForo _xfUid-*, React :r0:) via fallback_selectors chain
      then role-based last-resort (input[type=password] etc.)
    - Dropdown menus: scroll into view + JS dispatch if click intercepted
    - Logout links with CSRF tokens: read live href from DOM, navigate directly
    Returns True when a password was successfully typed (login proxy).
    """
    import time as _t
    from selenium.webdriver.common.by import By
    from selenium.webdriver.common.keys import Keys

    if not isinstance(macro, list) or not macro:
        return False

    def _vis(css, timeout):
        """First visible element matching css (main doc + iframes).
        Uses getBoundingClientRect so position:fixed overlays are found."""
        deadline = _t.time() + max(timeout, 0.5)
        while _t.time() < deadline:
            try:
                driver.switch_to.default_content()
                for el in driver.find_elements(By.CSS_SELECTOR, css):
                    try:
                        r = driver.execute_script(
                            "var r=arguments[0].getBoundingClientRect(),"
                            "s=window.getComputedStyle(arguments[0]);"
                            "return {w:r.width,h:r.height,"
                            "v:s.visibility,d:s.display,o:s.opacity};", el)
                        if (r and r.get("w",0)>0 and r.get("h",0)>0
                                and r.get("v")!="hidden"
                                and r.get("d")!="none"
                                and r.get("o")!="0"):
                            return el
                    except Exception:
                        try:
                            if el.is_displayed(): return el
                        except Exception:
                            pass
                for fr in driver.find_elements(By.TAG_NAME, "iframe"):
                    try:
                        driver.switch_to.default_content()
                        driver.switch_to.frame(fr)
                        for el in driver.find_elements(By.CSS_SELECTOR, css):
                            try:
                                if el.is_displayed(): return el
                            except Exception:
                                pass
                    except Exception:
                        pass
                driver.switch_to.default_content()
            except Exception:
                pass
            _t.sleep(0.15)
        try: driver.switch_to.default_content()
        except Exception: pass
        return None

    # Last-resort selectors when all recorded ones fail (dynamic-ID sites).
    _ROLE_SEL = {
        "password": ["input[type=password]"],
        "username": [
            "input[type=email]",
            "input[autocomplete=username]",
            "input[autocomplete=email]",
            "input[type=text][name*=user]",
            "input[type=text][name*=email]",
            "input[type=text][name*=login]",
            "input[type=text]",
        ],
    }

    def _find_field(step, timeout):
        """Try: primary selector → fallback_selectors → role-based."""
        primary = step.get("selector")
        candidates = []
        if primary:
            candidates.append(("primary", primary))
        for fb in (step.get("fallback_selectors") or []):
            if fb and fb != primary:
                candidates.append(("fallback", fb))
        for label, css in candidates:
            el = _vis(css, timeout)
            if el:
                if label != "primary":
                    log(f"[replay] {label} matched: {css}")
                return el
            log(f"[replay] {label} not visible: {css}")
        # Role-based last resort
        role_k = None
        if step.get("role") == "password" or step.get("ftype") == "password":
            role_k = "password"
        elif step.get("role") == "username":
            role_k = "username"
        if role_k:
            for css in _ROLE_SEL.get(role_k, []):
                el = _vis(css, max(timeout * 0.4, 1.5))
                if el:
                    log(f"[replay] role-fallback ({role_k}): {css}")
                    return el
        return None

    def _type(el, val):
        try: el.click()
        except Exception: pass
        try: el.clear()
        except Exception: pass
        try: el.send_keys(val)
        except Exception as e:
            log(f"[replay] send_keys failed: {e!r}")
        try:
            if (el.get_attribute("value") or "") == str(val):
                return True
            driver.execute_script(
                "arguments[0].value=arguments[1];"
                "arguments[0].dispatchEvent(new Event('input',{bubbles:true}));"
                "arguments[0].dispatchEvent(new Event('change',{bubbles:true}));",
                el, str(val))
            return (el.get_attribute("value") or "") != ""
        except Exception:
            return False

    _LOGOUT_KW = ("logout","log-out","signout","sign-out","cerrar","salir",
                  "log out","sign out")

    typed_password = False
    per_wait = max(3, min(int(wait_seconds or 15), 15))

    for step in macro:
        if not isinstance(step, dict):
            continue
        kind = step.get("kind")
        sel  = step.get("selector")
        try:
            # ── field ───────────────────────────────────────────────────────
            if kind == "field":
                if not sel and not step.get("fallback_selectors"):
                    continue
                is_pass = (step.get("role") == "password"
                           or step.get("ftype") == "password")
                val = step.get("value")
                if is_pass and (val in (None, "")) and pass_value:
                    val = pass_value
                if val in (None, ""):
                    continue
                el = _find_field(step, per_wait)
                if not el:
                    log(f"[replay] field not found: {sel}")
                    continue
                if _type(el, val):
                    if is_pass:
                        typed_password = True
                        log("[replay] typed password ✓")
                    else:
                        log(f"[replay] typed into {sel[:60]}")

            # ── click ────────────────────────────────────────────────────────
            elif kind == "click":
                if not sel:
                    continue
                step_href = step.get("href", "")
                step_text = (step.get("text") or "").lower()
                # Also check el_id, el_cls, data_action captured by the richer
                # recorder so logout buttons without href (SPAs, menus) are found.
                step_id       = (step.get("el_id") or "").lower()
                step_cls      = (step.get("el_cls") or "").lower()
                step_data_act = (step.get("data_action") or "").lower()
                _combined     = " ".join([step_href.lower(), step_text,
                                           step_id, step_cls, step_data_act])
                is_logout = any(k in _combined for k in _LOGOUT_KW)

                el = _vis(sel, per_wait)

                if el and is_logout:
                    # Logout element: try to read a live href first (handles CSRF
                    # tokens that change every session), then fall back to a plain
                    # click so SPA logout buttons without any href still work.
                    live_href = ""
                    try:
                        live_href = driver.execute_script(
                            """
                            var el = arguments[0];
                            // Check the element itself and the nearest <a> ancestor.
                            if (el.tagName === 'A') return el.getAttribute('href') || '';
                            var anc = el.closest ? el.closest('a') : null;
                            return anc ? (anc.getAttribute('href') || '') : '';
                            """, el)
                    except Exception:
                        pass
                    if live_href and live_href not in ('#', 'javascript:void(0)',
                                                       'javascript:;', ''):
                        try:
                            from urllib.parse import urljoin
                            full = urljoin(driver.current_url, live_href)
                            log(f"[replay] logout → navigating: {full}")
                            driver.get(full)
                            _t.sleep(1.5)
                        except Exception as ex:
                            log(f"[replay] logout nav failed ({ex!r}), clicking")
                            try:
                                driver.execute_script(
                                    "arguments[0].scrollIntoView({block:'nearest'});", el)
                                _t.sleep(0.1)
                                el.click()
                            except Exception: pass
                    else:
                        # SPA / menu button — no href, must click
                        try:
                            driver.execute_script(
                                "arguments[0].scrollIntoView({block:'nearest'});", el)
                            _t.sleep(0.1)
                        except Exception: pass
                        try:
                            el.click()
                        except Exception:
                            try:
                                driver.execute_script(
                                    "arguments[0].dispatchEvent("                                    "new MouseEvent('click',{"                                    "bubbles:true,cancelable:true,view:window}));", el)
                            except Exception: pass
                        _t.sleep(1.0)
                    log("[replay] logout done")

                elif el:
                    # Regular click — scroll into view, JS fallback if intercepted
                    try:
                        driver.execute_script(
                            "arguments[0].scrollIntoView({block:'nearest'});", el)
                        _t.sleep(0.1)
                    except Exception:
                        pass
                    try:
                        el.click()
                    except Exception:
                        try:
                            driver.execute_script(
                                "arguments[0].dispatchEvent("
                                "new MouseEvent('click',{"
                                "bubbles:true,cancelable:true,view:window}));", el)
                        except Exception:
                            pass
                    log(f"[replay] clicked {sel[:60]}")
                    _t.sleep(0.8)

                else:
                    # Not found — JS click as absolute last resort
                    try:
                        driver.execute_script(
                            "var el=document.querySelector(arguments[0]);"
                            "if(el) el.dispatchEvent(new MouseEvent('click',"
                            "{bubbles:true,cancelable:true,view:window}));", sel)
                        log(f"[replay] JS-clicked (not visible): {sel[:60]}")
                        _t.sleep(0.8)
                    except Exception:
                        log(f"[replay] click target not found: {sel[:60]}")

            # ── enter ────────────────────────────────────────────────────────
            elif kind == "enter":
                el = _vis(sel, 2) if sel else None
                if el:
                    el.send_keys(Keys.ENTER)
                    log("[replay] pressed Enter")
                    _t.sleep(0.6)
                elif step.get("form"):
                    driver.switch_to.default_content()
                    driver.execute_script(
                        "var f=document.querySelector(arguments[0]);"
                        "if(f){if(f.requestSubmit)f.requestSubmit();"
                        "else f.submit();}", step["form"])
                    log("[replay] submitted form (enter→form)")
                    _t.sleep(0.6)

            # ── submit ───────────────────────────────────────────────────────
            elif kind == "submit":
                btn = step.get("button")
                frm = step.get("form")
                done = False
                if btn:
                    el = _vis(btn, 2)
                    if el:
                        try:
                            el.click()
                        except Exception:
                            try:
                                driver.execute_script(
                                    "arguments[0].scrollIntoView({block:'nearest'});",
                                    el)
                                _t.sleep(0.1)
                                el.click()
                            except Exception:
                                driver.execute_script(
                                    "arguments[0].dispatchEvent("
                                    "new MouseEvent('click',{bubbles:true,"
                                    "cancelable:true,view:window}));", el)
                        done = True
                        log("[replay] clicked submit button")
                        _t.sleep(0.8)
                if not done and frm:
                    driver.switch_to.default_content()
                    driver.execute_script(
                        "var fs=document.querySelectorAll(arguments[0]);"
                        "for(var i=0;i<fs.length;i++){"
                        "  if(fs[i].offsetParent!==null){"
                        "    if(fs[i].requestSubmit) fs[i].requestSubmit();"
                        "    else fs[i].submit(); return;}}", frm)
                    log("[replay] submitted form")
                    _t.sleep(0.8)

        except Exception as e:
            log(f"[replay] step {step!r} failed: {e!r}")

    try: driver.switch_to.default_content()
    except Exception: pass
    return typed_password



def _selenium_login(cfg: DastConfig,
                    log: Callable[[str], None]) -> list[dict]:
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    driver = _make_driver(cfg, headless=cfg.selenium_headless, log=log)
    try:
        wait      = WebDriverWait(driver, cfg.selenium_wait_seconds)
        login_url = cfg.selenium_login_url or cfg.login_url or cfg.url
        log(f"[dast] selenium: GET {login_url}")
        driver.get(login_url)

        # Preferred path: replay the full recording literally, in order. This is
        # how it survives overlay/iframe logins (XenForo etc.) — the recorded
        # "open login" click runs first, exactly as the user did it.
        used_macro = False
        if (cfg.selenium_macro or "").strip():
            try:
                macro = json.loads(cfg.selenium_macro)
            except Exception as e:
                log(f"[dast] selenium_macro JSON invalid: {e!r}"); macro = None
            if macro:
                _replay_login_macro(
                    driver, macro,
                    pass_value=(cfg.selenium_pass_value or cfg.password),
                    wait_seconds=cfg.selenium_wait_seconds, log=log)
                used_macro = True

        if not used_macro:
            # Legacy field-based path (older saved conditions without a macro).
            if cfg.selenium_user_selector:
                el = wait.until(EC.presence_of_element_located(
                    (By.CSS_SELECTOR, cfg.selenium_user_selector)))
                el.clear(); el.send_keys(cfg.selenium_user_value or cfg.username)
            if cfg.selenium_pass_selector:
                el = driver.find_element(By.CSS_SELECTOR, cfg.selenium_pass_selector)
                el.clear()
                el.send_keys(cfg.selenium_pass_value or cfg.password)
            if cfg.selenium_extra_steps.strip():
                try: steps = json.loads(cfg.selenium_extra_steps)
                except Exception as e:
                    log(f"[dast] extra_steps JSON invalid: {e!r}"); steps = []
                for s in steps or []:
                    try:
                        if "selector" in s and "value" in s:
                            el = driver.find_element(By.CSS_SELECTOR, s["selector"])
                            el.clear(); el.send_keys(str(s["value"]))
                        elif "click" in s:
                            driver.find_element(By.CSS_SELECTOR, s["click"]).click()
                        elif "key" in s and str(s["key"]).lower() == "enter":
                            from selenium.webdriver.common.keys import Keys
                            tgt = (s.get("selector") or cfg.selenium_pass_selector
                                   or cfg.selenium_user_selector)
                            if tgt:
                                driver.find_element(By.CSS_SELECTOR, tgt).send_keys(Keys.ENTER)
                        elif "submit" in s:
                            driver.execute_script(
                                "var f=document.querySelector(arguments[0]);"
                                "if(f){if(f.requestSubmit)f.requestSubmit();else f.submit();}",
                                s["submit"])
                        elif "wait"  in s: time.sleep(float(s["wait"]))
                        elif "js"    in s: driver.execute_script(s["js"])
                    except Exception as e:
                        log(f"[dast] step {s!r} failed: {e!r}")
            if cfg.selenium_submit_selector:
                driver.find_element(
                    By.CSS_SELECTOR, cfg.selenium_submit_selector).click()
        if cfg.login_success_selector:
            wait.until(EC.presence_of_element_located(
                (By.CSS_SELECTOR, cfg.login_success_selector)))
            log("[dast] selenium login OK (selector present)")
        elif cfg.login_success_text:
            wait.until(lambda d: cfg.login_success_text in d.page_source)
            log("[dast] selenium login OK (success text detected)")
        else:
            time.sleep(2); log("[dast] selenium login completed")
        cookies = driver.get_cookies() or []
        log(f"[dast] selenium captured {len(cookies)} cookie(s)")
        return cookies
    finally:
        try: driver.quit()
        except Exception: pass


# ── Auto-detect login ─────────────────────────────────────────────────────────
#
# auth_type == "auto" drives a real browser to a page, finds the login form on
# its own (no recorded macro, no CSS selectors), types the credentials, submits,
# verifies, and hands back the session cookies — same contract as
# _selenium_login. The detection mirrors what OWASP ZAP "browser-based / auto
# auth", Chromium's own password-manager and 1Password/Bitwarden do:
#
#   1. ANCHOR ON THE PASSWORD FIELD. The single most reliable signal of a login
#      form is a visible input[type=password]. Everything keys off it.
#   2. USERNAME = the field paired with that password — preferring explicit
#      signals (autocomplete=username/email, type=email) then the nearest
#      *preceding* visible text/email/tel input, then name/id/placeholder/aria
#      keyword matching (multilingual: user, email, login, usuario, correo…).
#   3. SUBMIT = an in-form submit control, else a button whose text reads like
#      "log in / sign in / entrar / acceder / continuar", else ENTER in the
#      password field, else form.requestSubmit()/submit().
#
# Hard problems handled (all observed in the wild):
#   • Cookie / GDPR consent overlays that swallow the first click → dismissed.
#   • Login hidden behind a "Sign in" trigger (modal / dropdown) → trigger
#     clicked, then the page is re-scanned.
#   • Shadow DOM (web components) → querySelector is pierced recursively.
#   • Same-origin iframes (some SSO widgets) → every frame is scanned.
#   • Identifier-first / multi-step logins (Google/Microsoft/Okta style, where
#     the password field only appears after you submit the username) → username
#     submitted first, then we poll for the password field to materialise.
#   • Honeypot traps (hidden/off-screen/aria-hidden/tabindex=-1 inputs) → never
#     filled; they only exist to catch bots and break a real login.
#   • React / Vue / Angular controlled inputs that ignore Selenium's send_keys
#     (their value-tracker de-dups the change) → native value setter +
#     input/change events, the documented work-around.
#   • CAPTCHA / 2FA / OTP → detected and surfaced; in a headed browser the run
#     pauses so a human can solve it, in headless we log a clear warning.
#
# The detector returns live WebElements (Selenium serialises DOM nodes found by
# execute_script — including inside shadow roots — straight back as elements we
# can click / send_keys), so there's no brittle selector round-trip.

# Recursive, shadow-DOM-piercing form detector. Returns the password input, its
# paired username input, an in-form submit control, and a few diagnostic flags.
# Runs inside whatever frame the driver is currently focused on.
_AUTO_DETECT_JS = r"""
return (function(){
  // Flatten the DOM across open shadow roots so web-component logins are seen.
  function deepQueryAll(sel, root, out){
    root = root || document; out = out || [];
    try { root.querySelectorAll(sel).forEach(function(e){ out.push(e); }); } catch(e){}
    var all;
    try { all = root.querySelectorAll('*'); } catch(e){ all = []; }
    for (var i=0;i<all.length;i++){ if (all[i].shadowRoot) deepQueryAll(sel, all[i].shadowRoot, out); }
    return out;
  }
  function visible(el){
    if (!el) return false;
    try {
      var r = el.getBoundingClientRect();
      var s = window.getComputedStyle(el);
      if (s.visibility==='hidden' || s.display==='none' || s.opacity==='0') return false;
      if ((el.offsetWidth||0)<=1 && (el.offsetHeight||0)<=1 && r.width<=1 && r.height<=1) return false;
      // off-screen / honeypot positioning
      if (r.bottom < -50 || r.right < -50) return false;
      return true;
    } catch(e){ return false; }
  }
  // Honeypot / bot-trap heuristics: real users never see these, so filling them
  // fails the login and may flag the account.
  function honeypot(el){
    try {
      if (el.type==='hidden') return true;
      if (el.getAttribute('aria-hidden')==='true') return true;
      if (String(el.getAttribute('tabindex'))==='-1') return true;
      var hay = ((el.name||'')+' '+(el.id||'')+' '+(el.className||'')).toLowerCase();
      if (/honeypot|hp-|nobot|no-bot|bot-?trap|tohp|winnie/.test(hay)) return true;
      if (el.autocomplete==='off' && !visible(el)) return true;
    } catch(e){}
    return false;
  }
  function role(el){
    var type = (el.type||'').toLowerCase();
    var ac   = (el.getAttribute('autocomplete')||'').toLowerCase();
    if (type==='password' || ac==='current-password' || ac==='new-password') return 'password';
    if (ac==='username' || ac==='email' || type==='email') return 'username';
    var hay = ((el.name||'')+' '+(el.id||'')+' '+(el.placeholder||'')+' '+
               (el.getAttribute('aria-label')||'')).toLowerCase();
    // Password by name/id/placeholder — English + Spanish + Portuguese. Checked
    // BEFORE username so a field like "login-password" reads as password.
    if (/(contrase|contrasena|password|passwd|pass-?word|passcode|\bpwd\b|\bpass\b|clave|senha)/.test(hay)) return 'password';
    if (/(user|email|e-?mail|login|logon|correo|usuario|account|cuenta|nick|handle|phone|tel|m[oó]vil|dni|nif|rfc|curp)/.test(hay)) return 'username';
    return 'other';
  }

  var passwords = deepQueryAll('input[type=password]').filter(function(e){
    return visible(e) && !honeypot(e);
  });
  var pwd = passwords[0] || null;
  // Fallback for sites that mask a custom input WITHOUT type=password: accept a
  // visible, non-honeypot input whose name/id reads like a password (contraseña,
  // clave, password…). Conservative on purpose — used only as a last resort.
  if (!pwd) {
    var maskedPwd = deepQueryAll('input').filter(function(e){
      return e.type!=='password' && visible(e) && !honeypot(e) && role(e)==='password';
    });
    pwd = maskedPwd[0] || null;
  }

  // Candidate username inputs: visible text-likes that aren't the password.
  var textSel = 'input[type=text],input[type=email],input[type=tel],input:not([type]),'+
                'input[autocomplete=username],input[autocomplete=email]';
  function userEligible(e){
    if (e===pwd) return false;                 // never the password element
    if (e.type==='password') return false;
    if (!visible(e) || honeypot(e)) return false;
    if (role(e)==='password') return false;    // skip keyword-masked passwords
    return true;
  }
  var users = deepQueryAll(textSel).filter(function(e){
    if (!userEligible(e)) return false;
    var ac=(e.getAttribute('autocomplete')||'').toLowerCase();
    return role(e)!=='other' || e.type==='email' || ac==='username';
  });
  // Broaden: any visible text-like input, used only as a fallback below.
  var anyText = deepQueryAll(textSel).filter(userEligible);

  function pickUser(){
    if (!users.length && !anyText.length) return null;
    // Strong explicit signals win outright.
    var strong = (users.length?users:anyText).filter(function(e){
      var ac=(e.getAttribute('autocomplete')||'').toLowerCase();
      return ac==='username'||ac==='email'||(e.type||'').toLowerCase()==='email';
    });
    var pool = strong.length ? strong : (users.length ? users : anyText);
    if (!pwd) return pool[0] || null;
    // With a password present, prefer the candidate that sits JUST BEFORE the
    // password in document order (classic stacked login form).
    var best=null, bestScore=-1;
    var docOrder = deepQueryAll('input,button');
    var pIdx = docOrder.indexOf(pwd);
    pool.forEach(function(e){
      var idx = docOrder.indexOf(e);
      var score = 0;
      var ac=(e.getAttribute('autocomplete')||'').toLowerCase();
      if (ac==='username'||ac==='email') score += 100;
      if ((e.type||'').toLowerCase()==='email') score += 40;
      if (role(e)==='username') score += 20;
      // Closer-and-before beats far / after.
      if (idx>=0 && pIdx>=0){
        if (idx < pIdx) score += 30 - Math.min(29, pIdx-idx);
        else            score += 5  - Math.min(5, idx-pIdx);
      }
      // Same form as the password is a strong pairing signal.
      try { if (e.form && pwd.form && e.form===pwd.form) score += 25; } catch(_){}
      if (score>bestScore){ bestScore=score; best=e; }
    });
    return best || pool[0] || null;
  }
  var user = pickUser();

  // In-form submit control next to the password (or username for step-1).
  function pickSubmit(){
    var anchor = pwd || user;
    var form = anchor && anchor.form ? anchor.form : null;
    var btns = [];
    if (form) btns = deepQueryAll('button,input[type=submit],input[type=button],[role=button]', form);
    if (!btns.length) btns = deepQueryAll('button,input[type=submit],input[type=button],[role=button]');
    btns = btns.filter(visible);
    if (!btns.length) return null;
    var KW=/(log\s*in|login|log-in|sign\s*in|signin|sign-in|submit|continue|next|entrar|iniciar|acceder|ingresar|continuar|siguiente|enviar|acceso)/i;
    // type=submit first.
    var explicit = btns.filter(function(b){
      return (b.type||'').toLowerCase()==='submit' ||
             (b.tagName==='BUTTON' && !b.getAttribute('type'));
    });
    var kw = btns.filter(function(b){
      var t=(b.innerText||b.value||b.getAttribute('aria-label')||'');
      return KW.test(t);
    });
    return kw[0] || explicit[0] || btns[0] || null;
  }
  var submit = pickSubmit();

  // Login trigger (when the form is hidden behind a "Sign in" button/link).
  function pickTrigger(){
    if (pwd) return null;
    var cands = deepQueryAll('a,button,[role=button],input[type=button],input[type=submit]').filter(visible);
    var KW=/(log\s*in|login|log-in|sign\s*in|signin|sign-in|entrar|iniciar sesi|acceder|ingresar|mi cuenta|my account|account)/i;
    // Never treat a logout / "cerrar sesión" control as a login trigger.
    var LOGOUT=/(log\s*out|logout|log-out|sign\s*out|signout|sign-out|cerrar\s*sesi|cerrar-?sesion|salir|desconect|logoff)/i;
    for (var i=0;i<cands.length;i++){
      var t=(cands[i].innerText||cands[i].value||cands[i].getAttribute('aria-label')||'')+' '+
            (cands[i].getAttribute('href')||'')+' '+(cands[i].id||'')+' '+(cands[i].className||'');
      if (LOGOUT.test(t)) continue;
      if (KW.test(t)) return cands[i];
    }
    return null;
  }

  // CAPTCHA / 2FA / OTP signals.
  var hasCaptcha = !!(deepQueryAll('iframe[src*=recaptcha],iframe[src*=hcaptcha],'+
                     'iframe[title*=captcha],.g-recaptcha,.h-captcha,[data-sitekey]').filter(visible).length);
  var otp = deepQueryAll('input[autocomplete=one-time-code],input[name*=otp],input[name*=mfa],'+
                         'input[name*=2fa],input[id*=otp],input[inputmode=numeric][maxlength="1"]').filter(visible);
  var hasOTP = !!otp.length;

  // Visible error / invalid-credential text (used after submit to detect failure).
  var errText='';
  try {
    var en = deepQueryAll('[class*=error],[class*=invalid],[role=alert],[class*=danger],[id*=error]').filter(visible);
    for (var j=0;j<en.length && j<4;j++){ var s=(en[j].innerText||'').trim(); if(s){ errText+=' '+s.slice(0,120);} }
  } catch(e){}

  return {
    password: pwd, username: user, submit: submit, trigger: pickTrigger(),
    has_password: !!pwd, has_username: !!user,
    has_captcha: hasCaptcha, has_otp: hasOTP,
    error_text: errText.trim().slice(0,400)
  };
})();
"""

# Consent / cookie-banner dismissal. Returns True if it clicked something.
_AUTO_CONSENT_JS = r"""
return (function(){
  function deepAll(sel, root, out){
    root=root||document; out=out||[];
    try{ root.querySelectorAll(sel).forEach(function(e){out.push(e);}); }catch(e){}
    var all; try{ all=root.querySelectorAll('*'); }catch(e){ all=[]; }
    for(var i=0;i<all.length;i++){ if(all[i].shadowRoot) deepAll(sel, all[i].shadowRoot, out); }
    return out;
  }
  function visible(el){ try{ var r=el.getBoundingClientRect(); var s=getComputedStyle(el);
    return s.display!=='none'&&s.visibility!=='hidden'&&r.width>0&&r.height>0; }catch(e){ return false; } }
  // Only act inside a consent-ish container so we never click the real login button.
  var KW=/^(accept|accept all|agree|i agree|allow all|got it|ok|entendido|aceptar|acepto|permitir|de acuerdo|consent|continue|continuar)$/i;
  var CTX=/(cookie|consent|gdpr|privacy|banner|onetrust|cmp|truste|didomi|cookiebot|usercentrics)/i;
  var btns = deepAll('button,a,[role=button],input[type=button],input[type=submit]').filter(visible);
  for (var i=0;i<btns.length;i++){
    var b=btns[i];
    var t=(b.innerText||b.value||b.getAttribute('aria-label')||'').trim();
    if (!KW.test(t)) continue;
    // climb up to 6 ancestors looking for a consent context.
    var ok=false, p=b;
    for (var d=0; d<6 && p; d++, p=p.parentElement){
      var hay=((p.id||'')+' '+(p.className||'')+' '+(p.getAttribute&&p.getAttribute('aria-label')||'')).toLowerCase();
      if (CTX.test(hay)){ ok=true; break; }
    }
    if (ok){ try{ b.click(); return true; }catch(e){} }
  }
  return false;
})();
"""

# Native-value-setter typing: the documented fix for React/Vue/Angular controlled
# inputs whose framework value-tracker ignores Selenium's send_keys.
_AUTO_SET_VALUE_JS = r"""
var el=arguments[0], val=arguments[1];
try{ el.focus(); }catch(e){}
try{
  var proto = el.tagName==='TEXTAREA' ? window.HTMLTextAreaElement.prototype
                                      : window.HTMLInputElement.prototype;
  var setter = Object.getOwnPropertyDescriptor(proto,'value').set;
  setter.call(el, val);
}catch(e){ try{ el.value=val; }catch(_){} }
el.dispatchEvent(new Event('input',  {bubbles:true}));
el.dispatchEvent(new Event('change', {bubbles:true}));
try{ el.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true})); }catch(e){}
return (el.value||'');
"""


def _auto_type(driver, el, value, log) -> bool:
    """Type *value* into *el* so it sticks even on controlled SPA inputs.

    Strategy: focus+clear+send_keys first (most faithful to a real user), then
    verify the value actually landed; if the framework swallowed it, fall back
    to the native value-setter + input/change dispatch work-around.
    """
    if not value:
        return False
    try:
        try: el.click()
        except Exception: pass
        try: el.clear()
        except Exception: pass
        try: el.send_keys(value)
        except Exception: pass
        if (el.get_attribute("value") or "") == str(value):
            return True
    except Exception:
        pass
    # Controlled-input fallback (React/Vue/Angular value-tracker work-around).
    try:
        got = driver.execute_script(_AUTO_SET_VALUE_JS, el, str(value))
        ok = (got or "") == str(value) or (el.get_attribute("value") or "") == str(value)
        if not ok:
            log("[auto] value did not stick after JS setter")
        return ok
    except Exception as e:
        log(f"[auto] type failed: {e!r}")
        return False


def _auto_detect_in_frames(driver, log):
    """Run the detector in the default content, then each same-origin iframe.

    Returns (fields_dict, frame_path) where frame_path is the list of iframe
    WebElements to switch into to reach the form (empty == main document).
    Leaves the driver focused on the frame where the form was found.
    """
    from selenium.webdriver.common.by import By

    def _run():
        try:
            return driver.execute_script(_AUTO_DETECT_JS) or {}
        except Exception as e:
            log(f"[auto] detect error: {e!r}")
            return {}

    driver.switch_to.default_content()
    fields = _run()
    if fields.get("has_password") or fields.get("has_username") or fields.get("trigger"):
        return fields, []

    # Descend into iframes one level (covers the common SSO-widget case).
    try:
        frames = driver.find_elements(By.TAG_NAME, "iframe")
    except Exception:
        frames = []
    for fr in frames:
        try:
            driver.switch_to.default_content()
            driver.switch_to.frame(fr)
            f = _run()
            if f.get("has_password") or f.get("has_username"):
                log("[auto] login form found inside an iframe")
                return f, [fr]
        except Exception:
            continue
    driver.switch_to.default_content()
    return fields, []


def _auto_submit(driver, fields, *, password_el=None, log=lambda *_: None) -> None:
    """Submit the login form: button → ENTER → form.requestSubmit/submit."""
    from selenium.webdriver.common.keys import Keys
    btn = fields.get("submit")
    if btn:
        try:
            driver.execute_script("arguments[0].scrollIntoView({block:'center'});", btn)
        except Exception: pass
        try:
            btn.click(); log("[auto] clicked submit button"); time.sleep(1.0); return
        except Exception:
            try:
                driver.execute_script(
                    "arguments[0].dispatchEvent(new MouseEvent('click',"
                    "{bubbles:true,cancelable:true,view:window}));", btn)
                log("[auto] JS-clicked submit"); time.sleep(1.0); return
            except Exception as e:
                log(f"[auto] submit click failed: {e!r}")
    # ENTER in the password (or username) field — the most universal submit.
    anchor = password_el or fields.get("password") or fields.get("username")
    if anchor:
        try:
            anchor.send_keys(Keys.ENTER); log("[auto] pressed Enter to submit")
            time.sleep(1.0); return
        except Exception: pass
    # Last resort: programmatic form submit.
    try:
        driver.execute_script(
            "var a=arguments[0]; var f=a&&a.form?a.form:document.querySelector('form');"
            "if(f){ if(f.requestSubmit) f.requestSubmit(); else f.submit(); }",
            anchor)
        log("[auto] form.submit() fallback"); time.sleep(1.0)
    except Exception as e:
        log(f"[auto] no submit path worked: {e!r}")


def _auto_verify(cfg: "DastConfig", driver, log) -> bool:
    """Best-effort 'are we logged in now?' check after submitting.

    Success if any of: an explicit success selector/text matched, the URL left
    the login page, the password field disappeared, or a logout/account control
    appeared — and no visible error message is present.
    """
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC

    wait = WebDriverWait(driver, max(3, min(int(cfg.selenium_wait_seconds or 15), 30)))
    driver.switch_to.default_content()

    if cfg.login_success_selector:
        try:
            wait.until(EC.presence_of_element_located(
                (By.CSS_SELECTOR, cfg.login_success_selector)))
            log("[auto] login OK (success selector present)"); return True
        except Exception:
            log("[auto] success selector never appeared")
    if cfg.login_success_text:
        try:
            wait.until(lambda d: cfg.login_success_text in d.page_source)
            log("[auto] login OK (success text detected)"); return True
        except Exception:
            log("[auto] success text never appeared")

    start_url = (cfg.selenium_login_url or cfg.url or "").rstrip("/")
    deadline = time.time() + 6
    while time.time() < deadline:
        try:
            f = driver.execute_script(_AUTO_DETECT_JS) or {}
        except Exception:
            f = {}
        cur = (driver.current_url or "").rstrip("/")
        moved = bool(start_url) and cur != start_url and "login" not in cur.lower()
        gone  = not f.get("has_password")
        err   = (f.get("error_text") or "")
        if err and any(k in err.lower() for k in
                       ("invalid", "incorrect", "incorrecto", "errón", "wrong",
                        "failed", "no coincide", "denied", "bloque")):
            log(f"[auto] credential error reported: {err[:120]}"); return False
        # Logout/account control showing up is a strong logged-in signal.
        try:
            logged = driver.execute_script(
                "return !!document.querySelector("
                "'a[href*=logout],a[href*=signout],a[href*=cerrar],"
                "[class*=logout],[id*=logout],[class*=avatar],[class*=account-menu]');")
        except Exception:
            logged = False
        if (moved or gone or logged):
            log("[auto] login appears successful "
                f"(url_moved={moved} pwd_gone={gone} logout_seen={bool(logged)})")
            return True
        time.sleep(0.8)
    log("[auto] could not positively confirm login (continuing with whatever "
        "session cookies were set)")
    return False


def _auto_login(cfg: DastConfig, log: Callable[[str], None]) -> list[dict]:
    """Zero-config login: auto-detect the form, fill it, submit, return cookies.

    Same return contract as _selenium_login (a list of Selenium cookie dicts),
    so run_dast can inject them identically.
    """
    user_val = (cfg.selenium_user_value or cfg.username or "").strip()
    pass_val = (cfg.selenium_pass_value or cfg.password or "")
    if not (user_val or pass_val):
        log("[auto] no username/password supplied — nothing to auto-fill")

    driver = _make_driver(cfg, headless=cfg.selenium_headless, log=log)
    try:
        url = cfg.selenium_login_url or cfg.url
        log(f"[auto] GET {url}")
        driver.get(url)
        time.sleep(1.0)  # let SPA hydrate

        # 1) Dismiss any cookie/consent overlay that would eat our clicks.
        try:
            if driver.execute_script(_AUTO_CONSENT_JS):
                log("[auto] dismissed a consent/cookie banner"); time.sleep(0.6)
        except Exception:
            pass

        # 2) Detect the form (main doc → iframes).
        fields, _frame = _auto_detect_in_frames(driver, log)

        # 3) Form hidden behind a "Sign in" trigger? Click it and re-scan.
        if not fields.get("has_password") and not fields.get("has_username"):
            trig = fields.get("trigger")
            if trig:
                log("[auto] no form visible — clicking a login trigger")
                try: trig.click()
                except Exception:
                    try: driver.execute_script(
                        "arguments[0].dispatchEvent(new MouseEvent('click',"
                        "{bubbles:true,cancelable:true,view:window}));", trig)
                    except Exception: pass
                time.sleep(1.2)
                try:
                    if driver.execute_script(_AUTO_CONSENT_JS): time.sleep(0.4)
                except Exception: pass
                fields, _frame = _auto_detect_in_frames(driver, log)

        if not fields.get("has_password") and not fields.get("has_username"):
            raise RuntimeError("no login form detected on the page")

        # 4) CAPTCHA / 2FA awareness.
        if fields.get("has_captcha"):
            if cfg.selenium_headless:
                log("[auto] ⚠ CAPTCHA detected — cannot auto-solve in headless "
                    "mode; login will likely fail. Re-run with Headless off to "
                    "solve it manually.")
            else:
                log("[auto] ⚠ CAPTCHA detected — solve it in the open browser; "
                    "waiting up to the login timeout…")

        # 5) Type username.
        if fields.get("username") and user_val:
            if _auto_type(driver, fields["username"], user_val, log):
                log("[auto] typed username ✓")

        # 6) Identifier-first / multi-step: password not on this page yet.
        if not fields.get("has_password") and fields.get("username"):
            log("[auto] no password field yet — submitting username (multi-step)")
            _auto_submit(driver, fields, log=log)
            deadline = time.time() + max(3, min(int(cfg.selenium_wait_seconds or 15), 30))
            while time.time() < deadline:
                time.sleep(0.7)
                try:
                    if driver.execute_script(_AUTO_CONSENT_JS): time.sleep(0.3)
                except Exception: pass
                fields, _frame = _auto_detect_in_frames(driver, log)
                if fields.get("has_password"):
                    log("[auto] password field appeared after step 1"); break

        # 7) Type password.
        if fields.get("password") and pass_val:
            if _auto_type(driver, fields["password"], pass_val, log):
                log("[auto] typed password ✓")

        # If a CAPTCHA/OTP is in play and we have a head, give the human time.
        if (fields.get("has_captcha") or fields.get("has_otp")) and not cfg.selenium_headless:
            grace = max(5, min(int(cfg.selenium_wait_seconds or 15), 60))
            log(f"[auto] waiting ~{grace}s for manual CAPTCHA/2FA before submit…")
            time.sleep(grace)

        # 8) Submit and verify.
        _auto_submit(driver, fields, password_el=fields.get("password"), log=log)
        _auto_verify(cfg, driver, log)

        driver.switch_to.default_content()
        cookies = driver.get_cookies() or []
        log(f"[auto] captured {len(cookies)} cookie(s)")
        return cookies
    finally:
        try: driver.quit()
        except Exception: pass


# ── DAST engine ───────────────────────────────────────────────────────────────
def _derive_logout_guard(cfg: "DastConfig",
                         log: Callable[[str], None] = lambda *_: None) -> dict:
    """Build a set of logout-protection signals from the recorded logout macro.

    The recorded logout macro carries the full properties of every clicked
    element (href, selector, el_id, el_cls, data_action, text). Even when the
    logout has NO distinct URL (SPA whose root stays the same), we can still
    protect the scanner from triggering it by:

      • extracting concrete hrefs/paths the logout navigated to (e.g.
        /usuarios/logout, /ajax/logout?token=…) → added to the skip list, and
      • collecting selectors / element ids / data-actions that identify the
        logout control, so any DOM-based interaction layer can avoid them.

    Returns a dict with:
      - 'paths':     set of URL path prefixes to skip (lowercased)
      - 'hrefs':     set of full/relative hrefs seen on logout clicks
      - 'selectors': set of CSS selectors of logout controls
      - 'el_ids':    set of element ids of logout controls
      - 'keywords':  the logout keyword list used for matching
    """
    _LOGOUT_KW = ("logout", "log-out", "signout", "sign-out", "cerrar",
                  "salir", "log out", "sign out", "cerrar-sesion",
                  "cerrar_sesion", "logoff", "log-off", "desconectar")
    guard = {"paths": set(), "hrefs": set(), "selectors": set(),
             "el_ids": set(), "keywords": _LOGOUT_KW}

    raw = (getattr(cfg, "selenium_logout_macro", "") or "").strip()
    if not raw:
        return guard
    try:
        macro = json.loads(raw)
    except Exception as e:
        log(f"[dast] logout macro JSON invalid (guard): {e!r}")
        return guard
    if not isinstance(macro, list):
        return guard

    from urllib.parse import urlparse, urljoin

    def _kw(text: str) -> bool:
        t = (text or "").lower()
        return any(k in t for k in _LOGOUT_KW)

    for step in macro:
        if not isinstance(step, dict) or step.get("kind") != "click":
            continue
        href  = (step.get("href")        or "").strip()
        sel   = (step.get("selector")    or "").strip()
        eid   = (step.get("el_id")       or "").strip()
        ecls  = (step.get("el_cls")      or "").strip()
        dact  = (step.get("data_action") or "").strip()
        text  = (step.get("text")        or "").strip()
        combined = " ".join([href, eid, ecls, dact, text]).lower()
        # Only treat as a logout control if a keyword appears somewhere, OR it's
        # the last click (the macro's final action is the logout itself).
        is_logout_ctrl = _kw(combined)
        if href and href not in ("#", "javascript:void(0)", "javascript:;"):
            # Real navigable href — derive its path for URL-based skipping.
            try:
                p = urlparse(href if "://" in href else urljoin("https://x/", href)).path
                p = (p or "").rstrip("/").lower()
                if p and (is_logout_ctrl or _kw(p)):
                    guard["paths"].add(p)
                    guard["hrefs"].add(href)
            except Exception:
                pass
        if is_logout_ctrl:
            if sel: guard["selectors"].add(sel)
            if eid: guard["el_ids"].add(eid)

    # Always include the very last click's href even without a keyword — the
    # final action of a logout recording IS the logout.
    for step in reversed(macro):
        if isinstance(step, dict) and step.get("kind") == "click":
            href = (step.get("href") or "").strip()
            if href and href not in ("#", "javascript:void(0)", "javascript:;"):
                try:
                    p = urlparse(href if "://" in href
                                 else urljoin("https://x/", href)).path.rstrip("/").lower()
                    if p:
                        guard["paths"].add(p)
                        guard["hrefs"].add(href)
                except Exception:
                    pass
            sel = (step.get("selector") or "").strip()
            eid = (step.get("el_id")    or "").strip()
            if sel: guard["selectors"].add(sel)
            if eid: guard["el_ids"].add(eid)
            break

    if guard["paths"] or guard["selectors"]:
        log(f"[dast] logout guard derived: paths={sorted(guard['paths'])} "
            f"selectors={sorted(guard['selectors'])[:3]} "
            f"el_ids={sorted(guard['el_ids'])[:3]}")
    return guard


def run_dast(cfg: DastConfig, out_dir: Path,
             log: Callable[[str], None],
             cancel: Optional[threading.Event] = None) -> tuple[dict, Path]:
    findings: list[dict] = []
    visited:  set[str]   = set()
    queued:   list[str]  = []
    forms:    list[tuple[str, dict]] = []
    cancel   = cancel or threading.Event()
    throttle = _Throttle(cfg.rate_limit_rps)
    stopped  = cancel.is_set
    _flock   = threading.Lock()

    def write_out(summary: dict) -> Path:
        out = out_dir / "dast.json"
        out.write_text(json.dumps(summary, indent=2), encoding="utf-8")
        return out

    if not cfg.url:
        s = {"findings": [], "target": "", "profile": cfg.profile}
        return s, write_out({"findings": []})

    base = cfg.url.strip()
    if not base.startswith(("http://", "https://")): base = "http://" + base
    workers = max(1, min(int(getattr(cfg, "concurrency", 4) or 1), 16))
    log(f"[dast] target={base}  profile={cfg.profile}  max_pages={cfg.max_pages}  "
        f"rps={cfg.rate_limit_rps}  workers={workers}  proxy={cfg.proxy or 'none'}")

    exclude_re = None
    if cfg.exclude_re:
        try: exclude_re = _re.compile(cfg.exclude_re)
        except _re.error as e: log(f"[dast] invalid exclude_re: {e}")

    # Derive extra logout-protection signals from the recorded logout macro so
    # the scanner never triggers a logout even when there's NO distinct logout
    # URL (SPA staying at /) and the user left "Logout URL regex" blank.
    logout_guard = _derive_logout_guard(cfg, log)

    def is_excluded(u: str) -> bool:
        if exclude_re and exclude_re.search(u): return True
        if cfg.logout_url_re:
            try:
                if _re.search(cfg.logout_url_re, u): return True
            except _re.error: pass
        # Macro-derived guard: skip any URL whose path matches a logout path we
        # recorded (covers SPA logouts with no regex, and logout endpoints that
        # share the site root).
        if logout_guard["paths"]:
            try:
                from urllib.parse import urlparse as _up
                up = (_up(u).path or "").rstrip("/").lower()
                if up:
                    for lp in logout_guard["paths"]:
                        # Exact path or the logout path as a prefix segment.
                        if up == lp or up.startswith(lp + "/"):
                            return True
            except Exception:
                pass
        return False

    opener, jar, hdrs = _make_opener(cfg)

    def form_login():
        if not cfg.login_url or not cfg.login_data: return
        log(f"[dast] form login → {cfg.login_url}")
        _fetch(opener, hdrs, cfg.login_url, method="POST",
               data=cfg.login_data.encode(), timeout=cfg.timeout,
               extra={"Content-Type": "application/x-www-form-urlencoded"})

    if   cfg.auth_type == "form":     form_login()
    elif cfg.auth_type in ("selenium", "auto"):
        _login_fn = _auto_login if cfg.auth_type == "auto" else _selenium_login
        try: _inject_cookies(jar, _login_fn(cfg, log))
        except Exception as e:
            log(f"[dast] {cfg.auth_type} login FAILED: {e!r}")
            findings.append({"severity": "high",
                             "title": f"{cfg.auth_type.capitalize()} login failed",
                             "url": cfg.selenium_login_url or cfg.url,
                             "evidence": repr(e), "cwe": "CWE-287",
                             "category": "auth"})

    relogins = {"count": 0}; MAX_RELOGINS = 2

    def looks_logged_out(body: bytes, fu: str) -> bool:
        if cfg.logout_url_re:
            try:
                if _re.search(cfg.logout_url_re, fu): return True
            except _re.error: pass
        if cfg.login_success_text and body:
            try: return cfg.login_success_text not in body.decode("utf-8", errors="replace")
            except Exception: return False
        return False

    def fetch(url, *, method="GET", data=None, extra=None):
        throttle.wait()
        st, hh, bb, fu = _fetch(opener, hdrs, url, method=method, data=data,
                                 timeout=cfg.timeout, extra=extra)
        if cfg.auto_relogin and cfg.auth_type in ("form", "selenium", "auto") and \
                relogins["count"] < MAX_RELOGINS and looks_logged_out(bb, fu):
            log(f"[dast] session lost — re-authenticating ({cfg.auth_type})")
            relogins["count"] += 1
            try:
                if cfg.auth_type in ("selenium", "auto"):
                    _relogin = _auto_login if cfg.auth_type == "auto" else _selenium_login
                    cookies = _relogin(cfg, log)
                    jar.clear(); _inject_cookies(jar, cookies)
                else:
                    jar.clear(); form_login()
            except Exception as e:
                log(f"[dast] re-login failed: {e!r}")
                with _flock:
                    findings.append({"severity": "high",
                                     "title": "Re-authentication failed",
                                     "url": fu, "evidence": repr(e),
                                     "cwe": "CWE-287", "category": "auth"})
                return st, hh, bb, fu
            throttle.wait()
            st, hh, bb, fu = _fetch(opener, hdrs, url, method=method,
                                     data=data, timeout=cfg.timeout,
                                     extra=extra)
        return st, hh, bb, fu

    _tl = threading.local()

    def probe(url, *, method="GET", data=None, extra=None):
        o = getattr(_tl, "opener", None)
        if o is None:
            o = _clone_opener(cfg, jar); _tl.opener = o
        throttle.wait()
        return _fetch(o, hdrs, url, method=method, data=data,
                      timeout=cfg.timeout, extra=extra)

    keep_seq   = cfg.auto_relogin and cfg.auth_type in ("form", "selenium", "auto")
    parallel   = workers > 1 and not keep_seq
    scan_fetch = fetch if keep_seq else probe

    def _pool_map(fn, items):
        items = list(items)
        if parallel and len(items) > 1:
            with ThreadPoolExecutor(max_workers=workers) as ex_:
                for _ in ex_.map(fn, items): pass
        else:
            for it in items:
                if stopped(): break
                fn(it)

    def add(sev, title, url, evidence="", cwe="", category="general"):
        with _flock:
            findings.append({"severity": sev, "title": title, "url": url,
                             "evidence": (evidence or "")[:600],
                             "cwe": cwe, "category": category})

    parsed = urlparse(base)
    if parsed.scheme == "http":
        add("medium", "Application served over plain HTTP", base,
            "Traffic is unencrypted.", "CWE-319", "transport")

    status, hdrs_r, body, final_url = fetch(base)
    log(f"[dast] {status} GET {base} ({len(body)} bytes)")
    if status == 0:
        add("high", "Target unreachable or TLS handshake failed", base,
            final_url, "", "transport")
        s = {"target": base, "final_url": final_url, "profile": cfg.profile,
             "auth_type": cfg.auth_type, "pages_visited": 0,
             "forms_discovered": 0, "relogins": 0,
             "cancelled": stopped(), "findings": findings}
        return s, write_out(s)

    lower_hdrs = {k.lower(): v for k, v in hdrs_r.items()}
    if parsed.scheme == "https":
        for hname, title, sev in _SEC_HEADERS:
            if hname not in lower_hdrs:
                add(sev, title, final_url,
                    f"Response headers: {sorted(lower_hdrs.keys())}",
                    "CWE-693", "headers")
    _passive_header_findings(lower_hdrs, final_url, add)

    for c in jar:
        flags = []
        if not c.secure: flags.append("missing Secure")
        if not getattr(c, "_rest", {}).get("HttpOnly") and \
                "httponly" not in [k.lower() for k in (c._rest or {}).keys()]:
            flags.append("missing HttpOnly")
        if not next((v for k, v in (c._rest or {}).items()
                     if k.lower() == "samesite"), None):
            flags.append("missing SameSite")
        if flags:
            add("medium" if "Secure" in " ".join(flags) else "low",
                f"Cookie '{c.name}' has weak flags: {', '.join(flags)}",
                final_url, f"{c.name}={c.value[:30]}…",
                "CWE-614", "cookies")

    # ── Sensitive-path disclosure ─────────────────────────────────────────────
    def _disc(item):
        p, title, sev = item
        if stopped(): return
        u = urljoin(base, p)
        if is_excluded(u): return
        st, _, bb, _ = probe(u)
        if st and 200 <= st < 300 and len(bb) > 0:
            add(sev, title, u, f"HTTP {st}, {len(bb)} bytes",
                "CWE-538", "disclosure")

    if workers > 1:
        with ThreadPoolExecutor(max_workers=workers) as ex_:
            list(ex_.map(_disc, _DISC_PATHS))
    else:
        for it in _DISC_PATHS:
            if stopped(): break
            _disc(it)

    # ── Crawl ─────────────────────────────────────────────────────────────────
    def _looks_like_dirlist(low_text: str) -> bool:
        head = low_text[:600]
        return any(m in head for m in _DIRLIST_MARKERS)

    def _ingest(u, st, hh2, bb2, fu2):
        if st == 0 or not bb2: return
        ctype = (hh2.get("Content-Type") or
                 hh2.get("content-type") or "").lower()
        if "html" not in ctype: return
        try: text = bb2.decode("utf-8", errors="replace")
        except Exception: return
        if _looks_like_dirlist(text.lower()):
            add("low", "Directory listing enabled", fu2,
                "Auto-generated index page returned.", "CWE-548", "disclosure")
        ex = _LinkExtractor()
        try: ex.feed(text)
        except Exception: pass

        # Build a fast lookup of hrefs that belong to a logout control, judged
        # by the anchor's visible text / id / class / rel / data-action — this
        # catches "Salir" / "Cerrar sesión" links whose href has no keyword
        # (the exact SPA case where the logout URL == site root).
        _lo_kw = logout_guard["keywords"]
        logout_hrefs_by_meta = set()
        for m in ex.link_meta:
            hay = " ".join([
                m.get("text", ""), m.get("id", ""), m.get("cls", ""),
                m.get("rel", ""), m.get("aria", ""), m.get("data_action", ""),
            ]).lower()
            if any(k in hay for k in _lo_kw):
                logout_hrefs_by_meta.add(m.get("href", ""))

        for href in ex.links:
            # Skip anchors identified as logout by their text/attributes.
            if href in logout_hrefs_by_meta:
                log(f"[dast] skip logout link (text/attr match): {href[:80]}")
                continue
            nxt = urljoin(fu2, href).split("#", 1)[0]
            if (nxt in visited
                    or not _same_origin(base, nxt, cfg.include_subdomains)
                    or is_excluded(nxt)):
                continue
            visited.add(nxt); queued.append(nxt)
        for fm in ex.forms:
            # Skip forms whose action is a logout endpoint.
            faction = (fm.get("action") or "")
            if faction and is_excluded(urljoin(fu2, faction)):
                log(f"[dast] skip logout form action: {faction[:80]}")
                continue
            forms.append((fu2, fm))

    queued.append(final_url); visited.add(final_url)
    pages = 0
    while queued and pages < cfg.max_pages and not stopped():
        remaining = cfg.max_pages - pages
        batch = []
        while (queued and len(batch) < (workers if parallel else 1)
               and len(batch) < remaining):
            cu = queued.pop(0)
            if is_excluded(cu): continue
            batch.append(cu)
        if not batch: break

        def _grab(u):
            if u == final_url:
                return (u, status, hdrs_r, body, final_url)
            st2, hh2, bb2, fu2 = scan_fetch(u)
            return (u, st2, hh2, bb2, fu2)

        if parallel and len(batch) > 1:
            with ThreadPoolExecutor(max_workers=workers) as ex_:
                results = list(ex_.map(_grab, batch))
        else:
            results = [_grab(u) for u in batch]

        for (_u, st2, hh2, bb2, fu2) in results:
            if stopped(): break
            pages += 1
            _ingest(_u, st2, hh2, bb2, fu2)

    log(f"[dast] crawl: {pages} pages, {len(forms)} forms")

    # ── Active probes ─────────────────────────────────────────────────────────
    if cfg.profile == "active":
        log(f"[dast] active probes: XSS / SQLi / open-redirect "
            f"({'concurrent' if parallel else 'sequential'})")

        def _probe_url(u):
            if stopped() or is_excluded(u): return
            p2 = urlparse(u); qs = parse_qsl(p2.query, keep_blank_values=True)
            if not qs: return
            for idx, (qk, _qv) in enumerate(qs):
                if stopped(): break
                base_qs = list(qs)
                # XSS
                xss = base_qs[:]; xss[idx] = (qk, _XSS_PROBE)
                xurl = urlunparse(p2._replace(query=urlencode(xss)))
                st3, _, bb3, _ = probe(xurl)
                if st3 and bb3 and _XSS_PROBE in bb3.decode("utf-8", errors="replace"):
                    add("high", f"Reflected XSS in param '{qk}'", xurl,
                        "Payload reflected.", "CWE-79", "xss")
                # SQLi
                sqli = base_qs[:]; sqli[idx] = (qk, str(_qv) + "'\"")
                surl = urlunparse(p2._replace(query=urlencode(sqli)))
                sts, _, bbs, _ = probe(surl)
                if sts and bbs:
                    low_s = bbs.decode("utf-8", errors="replace").lower()
                    hit = next((e for e in _SQL_ERRORS if e in low_s), None)
                    if hit:
                        add("critical", f"SQLi in param '{qk}'", surl,
                            f"DB error: {hit!r}", "CWE-89", "sqli")
                # Open redirect
                if qk.lower() in _API_REDIRECT:
                    rq = base_qs[:]; rq[idx] = (qk, "https://example.com/")
                    rurl = urlunparse(p2._replace(query=urlencode(rq)))
                    str_, rh, _, _ = probe(rurl)
                    loc = rh.get("Location") or rh.get("location") or ""
                    if (str_ in (301, 302, 303, 307, 308)
                            and loc.startswith("https://example.com")):
                        add("high", f"Open redirect via '{qk}'", rurl,
                            f"Location: {loc}", "CWE-601", "redirect")

        _pool_map(_probe_url, list(visited))

        def _probe_form(item):
            fu2, fm = item
            if stopped() or is_excluded(fu2): return
            action = urljoin(fu2, fm["action"]) if fm["action"] else fu2
            if is_excluded(action): return
            for inp in fm["inputs"]:
                if stopped(): break
                orig  = {i["name"]: i.get("value", "test")
                         for i in fm["inputs"] if i["name"]}
                probe_d = dict(orig)
                probe_d[inp["name"]] = _XSS_PROBE
                data = urlencode(probe_d).encode()
                st4, _, bb4, _ = probe(action, method=fm["method"].upper(),
                                       data=data,
                                       extra={"Content-Type":
                                              "application/x-www-form-urlencoded"})
                if st4 and bb4 and _XSS_PROBE in bb4.decode("utf-8", errors="replace"):
                    add("high", f"Form XSS in field '{inp['name']}'", action,
                        "Payload reflected.", "CWE-79", "xss")

        _pool_map(_probe_form, forms)

    findings.sort(key=lambda x: -_DAST_SVR.get(x["severity"], 0))
    summary = {
        "target": base, "final_url": final_url,
        "profile": cfg.profile, "auth_type": cfg.auth_type,
        "pages_visited": pages, "forms_discovered": len(forms),
        "relogins": relogins["count"],
        "cancelled": stopped(), "findings": findings,
    }
    if stopped(): log("[dast] scan cancelled by user")
    out_p = write_out(summary)
    log(f"[dast] complete: {len(findings)} findings → {out_p}")
    return summary, out_p


# ── API scanner helpers ───────────────────────────────────────────────────────
def _api_load_spec(opener, hdrs, cfg: ApiConfig,
                   log) -> Optional[dict]:
    src = (cfg.spec_source or "").strip()
    if not src: return None
    raw: Optional[str] = None
    if src.startswith(("http://", "https://")):
        log(f"[api] fetching spec: {src}")
        st, _, bb, _ = _fetch(opener, hdrs, src, timeout=cfg.timeout)
        if st and bb: raw = bb.decode("utf-8", errors="replace")
        else: log(f"[api] could not fetch spec (HTTP {st})"); return None
    else:
        p = Path(src)
        if not p.exists():
            log(f"[api] spec not found: {src}"); return None
        raw = p.read_text(encoding="utf-8", errors="replace")
    try: return json.loads(raw)
    except json.JSONDecodeError: pass
    try:
        import importlib
        yaml = importlib.import_module("yaml")
        return yaml.safe_load(raw)
    except Exception as e:
        log(f"[api] spec is neither JSON nor YAML: {e!r}"); return None


def _api_deref(spec: dict, node: Any, _seen=None) -> Any:
    seen = _seen or set()
    while isinstance(node, dict) and "$ref" in node:
        ref = node["$ref"]
        if not isinstance(ref, str) or not ref.startswith("#/") or ref in seen:
            return node
        seen.add(ref); cur: Any = spec
        for part in ref[2:].split("/"):
            part = part.replace("~1", "/").replace("~0", "~")
            if isinstance(cur, dict) and part in cur: cur = cur[part]
            else: return node
        node = cur
    return node


def _api_sample(spec: dict, schema: Any, depth: int = 0) -> Any:
    schema = _api_deref(spec, schema) or {}
    if not isinstance(schema, dict) or depth > 4: return "test"
    for k in ("example", "default"):
        if k in schema: return schema[k]
    if schema.get("enum"): return schema["enum"][0]
    t = schema.get("type")
    if t == "object" or "properties" in schema:
        props = schema.get("properties") or {}
        req = set(schema.get("required") or [])
        keys = [k for k in props if not req or k in req] or list(props)[:3]
        return {k: _api_sample(spec, props[k], depth + 1) for k in keys}
    if t == "array":   return [_api_sample(spec, schema.get("items") or {}, depth + 1)]
    if t in ("integer", "number"): return 1
    if t == "boolean": return True
    return {"date-time": "2020-01-01T00:00:00Z", "date": "2020-01-01",
            "email": "test@example.com",
            "uuid": "00000000-0000-0000-0000-000000000000"}.get(
                schema.get("format"), "test")


def _api_base_url(spec: dict, cfg: ApiConfig, spec_src: str) -> str:
    if cfg.base_url.strip(): base = cfg.base_url.strip()
    elif isinstance(spec.get("servers"), list) and spec["servers"]:
        base = (spec["servers"][0] or {}).get("url", "") or ""
    elif spec.get("host"):
        scheme = (spec.get("schemes") or ["https"])[0]
        base = f"{scheme}://{spec['host']}{spec.get('basePath', '')}"
    else: base = ""
    if base.startswith("/") or not base:
        if spec_src.startswith(("http://", "https://")):
            base = urljoin(spec_src, base or "/")
    if base and not base.startswith(("http://", "https://")):
        base = "https://" + base
    return base.rstrip("/")


def _api_ops_postman(coll: dict, base: str) -> list[dict]:
    ops: list[dict] = []

    def walk(items):
        for it in items or []:
            if "item" in it: walk(it["item"]); continue
            req = it.get("request")
            if not isinstance(req, dict): continue
            method = (req.get("method") or "GET").upper()
            u = req.get("url")
            if isinstance(u, dict):
                url   = u.get("raw") or ""
                query = [(q.get("key"), q.get("value") or "test")
                         for q in (u.get("query") or []) if q.get("key")]
            else: url = u or ""; query = []
            url = url.split("#", 1)[0]
            for var in _re.findall(r"\{\{(\w+)\}\}", url):
                url = url.replace("{{" + var + "}}", "test")
            url = _re.sub(r"/:(\w+)", "/test", url)
            if url and not url.startswith(("http://", "https://")) and base:
                url = base + ("/" + url.lstrip("/"))
            secured = bool(req.get("auth")) or any(
                (h.get("key") or "").lower() == "authorization"
                for h in (req.get("header") or []))
            body = ctype = json_body = None
            b = req.get("body") or {}
            if b.get("mode") == "raw" and b.get("raw"):
                try:
                    json_body = json.loads(b["raw"])
                    body = b["raw"].encode(); ctype = "application/json"
                except Exception: pass
            ops.append({"method": method, "url": url, "secured": secured,
                        "query": query, "body": body, "ctype": ctype,
                        "json_body": json_body})

    walk(coll.get("item")); return ops


def _api_operations(spec: dict, base: str, spec_src: str) -> list[dict]:
    if "item" in spec and "paths" not in spec:
        return _api_ops_postman(spec, base)
    ops: list[dict] = []; global_sec = spec.get("security")
    methods = ("get", "post", "put", "patch", "delete", "options", "head")
    for path, item in (spec.get("paths") or {}).items():
        item = _api_deref(spec, item) or {}
        common = [_api_deref(spec, p) for p in (item.get("parameters") or [])]
        for method in methods:
            op = item.get(method)
            if not isinstance(op, dict): continue
            params = common + [_api_deref(spec, p)
                               for p in (op.get("parameters") or [])]
            sec = op.get("security", global_sec)
            secured = bool(sec) and sec != [{}]
            filled = path; query: list[tuple[str, str]] = []
            for p in params:
                if not isinstance(p, dict) or not p.get("name"): continue
                schema = p.get("schema") or {
                    k: p[k] for k in ("type", "enum", "format") if k in p}
                val = _api_sample(spec, schema)
                if not isinstance(val, (str, int, float, bool)): val = "test"
                loc = p.get("in")
                if   loc == "path":  filled = filled.replace("{" + p["name"] + "}", str(val))
                elif loc == "query": query.append((p["name"], str(val)))
            rb = (_api_deref(spec, op.get("requestBody"))
                  if op.get("requestBody") else None)
            body = ctype = json_body = None
            if isinstance(rb, dict):
                content = rb.get("content") or {}
                if "application/json" in content:
                    sample = _api_sample(
                        spec, (content["application/json"] or {}).get("schema") or {})
                    body = json.dumps(sample).encode()
                    ctype = "application/json"; json_body = sample
                else:
                    for ct in ("application/x-www-form-urlencoded",
                               "multipart/form-data"):
                        if ct in content:
                            sample = _api_sample(
                                spec, (content[ct] or {}).get("schema") or {})
                            if isinstance(sample, dict):
                                body = urlencode(
                                    {k: v for k, v in sample.items()}).encode()
                                ctype = "application/x-www-form-urlencoded"
                                break
            url = base + (filled if filled.startswith("/") else "/" + filled)
            if query: url += ("&" if "?" in url else "?") + urlencode(query)
            ops.append({"method": method.upper(), "url": url,
                        "secured": secured, "query": query,
                        "body": body, "ctype": ctype, "json_body": json_body})
    return ops


# ── API engine ────────────────────────────────────────────────────────────────
def run_api(cfg: ApiConfig, out_dir: Path,
            log: Callable[[str], None],
            cancel: Optional[threading.Event] = None) -> tuple[dict, Path]:
    findings: list[dict] = []
    cancel   = cancel or threading.Event()
    stopped  = cancel.is_set
    throttle = _Throttle(cfg.rate_limit_rps)

    def add(sev, title, url, evidence="", cwe="", category="api"):
        findings.append({"severity": sev, "title": title, "url": url,
                         "evidence": (evidence or "")[:600],
                         "cwe": cwe, "category": category})

    def write_out(s: dict) -> Path:
        out = out_dir / "api.json"
        out.write_text(json.dumps(s, indent=2), encoding="utf-8"); return out

    opener, jar, hdrs = _make_opener(cfg)
    noauth = {"User-Agent": _DAST_UA, "Accept": "*/*"}
    spec = _api_load_spec(opener, hdrs, cfg, log)
    if not spec or not isinstance(spec, dict):
        add("high", "Could not load or parse the API spec",
            cfg.spec_source, "", "", "spec")
        s = {"target": "", "spec_source": cfg.spec_source,
             "profile": cfg.profile, "endpoints_total": 0,
             "endpoints_tested": 0, "cancelled": stopped(),
             "findings": findings}
        return s, write_out(s)

    base = _api_base_url(spec, cfg, cfg.spec_source.strip())
    if not base:
        add("medium", "No server/base URL found in spec",
            cfg.spec_source, "", "", "spec")
        s = {"target": "", "spec_source": cfg.spec_source,
             "profile": cfg.profile, "endpoints_total": 0,
             "endpoints_tested": 0, "cancelled": stopped(),
             "findings": findings}
        return s, write_out(s)
    if base.startswith("http://"):
        add("medium", "API served over plain HTTP", base,
            "Unencrypted.", "CWE-319", "transport")

    ops = _api_operations(spec, base, cfg.spec_source.strip())
    log(f"[api] base={base}  profile={cfg.profile}  operations={len(ops)}")
    excl_re = None
    if cfg.exclude_re:
        try: excl_re = _re.compile(cfg.exclude_re)
        except _re.error as e: log(f"[api] invalid exclude_re: {e}")

    def fetch(url, *, method="GET", data=None, req_hdrs=None, extra=None):
        throttle.wait()
        return _fetch(opener, req_hdrs if req_hdrs is not None else hdrs,
                      url, method=method, data=data,
                      timeout=cfg.timeout, extra=extra)

    workers = max(1, min(int(getattr(cfg, "concurrency", 6) or 1), 16))
    to_test = [op for op in ops
               if not (excl_re and excl_re.search(op["url"]))
               ][:cfg.max_endpoints]
    log(f"[api] testing {len(to_test)}/{len(ops)} endpoints  workers={workers}")

    _tl      = threading.local()
    _flock   = threading.Lock()
    passive_state = {"done": False}

    def add(sev, title, url, evidence="", cwe="", category="api"):   # noqa: F811
        with _flock:
            findings.append({"severity": sev, "title": title, "url": url,
                             "evidence": (evidence or "")[:600],
                             "cwe": cwe, "category": category})

    def wfetch(url, *, method="GET", data=None, req_hdrs=None, extra=None):
        o = getattr(_tl, "opener", None)
        if o is None:
            o = _clone_opener(cfg, jar); _tl.opener = o
        throttle.wait()
        return _fetch(o, req_hdrs if req_hdrs is not None else hdrs,
                      url, method=method, data=data,
                      timeout=cfg.timeout, extra=extra)

    def _do_passive(lower, fu, url):
        with _flock:
            if passive_state["done"]: return
            passive_state["done"] = True
        for hname, title, sev in _SEC_HEADERS:
            if hname not in lower:
                add(sev, title, fu,
                    f"Headers: {sorted(lower.keys())}", "CWE-693", "headers")
        _passive_header_findings(lower, fu, add)
        try:
            sto, hho, _, _ = wfetch(url.split("?", 1)[0], method="OPTIONS")
            allow = ""
            for k, v in (hho or {}).items():
                if k.lower() in ("allow", "access-control-allow-methods"):
                    allow = (allow + "," + v) if allow else v
            risky = [m for m in ("PUT", "DELETE", "PATCH", "TRACE", "CONNECT")
                     if m in allow.upper()]
            if risky:
                add("low",
                    f"State-changing HTTP methods advertised: {', '.join(risky)}",
                    fu, f"Allow: {allow}", "CWE-650", "methods")
        except Exception:
            pass

    def _test_op(op):
        if stopped(): return
        url, method = op["url"], op["method"]
        extra = {"Content-Type": op["ctype"]} if op["ctype"] else None
        st, hh2, bb, fu = wfetch(url, method=method, data=op["body"],
                                  extra=extra)
        log(f"[api] {st} {method} {url}")
        if st == 0: return
        lower = {k.lower(): v for k, v in hh2.items()}

        if not passive_state["done"] and 200 <= st < 500:
            _do_passive(lower, fu, url)

        if (op["secured"] and cfg.auth_type in ("basic", "bearer", "header")
                and 200 <= st < 300):
            st2, _, _, _ = wfetch(url, method=method, data=op["body"],
                                   req_hdrs=noauth, extra=extra)
            if st2 and 200 <= st2 < 300:
                add("critical", f"Auth bypass on {method} {url}", fu,
                    f"Without auth returned HTTP {st2}.", "CWE-287", "auth")

        if op["query"]:
            qk, _ = op["query"][0]
            bad = op["url"].replace(f"{qk}=", f"{qk}=%00%27%22", 1)
            st3, _, bb3, _ = wfetch(bad, method=method)
            if st3 >= 500 and bb3:
                low_b = bb3.decode("utf-8", errors="replace").lower()
                if any(m in low_b for m in ("traceback", "stack trace",
                                            "exception", "at java.",
                                            "syntaxerror")):
                    add("medium", f"Stack trace exposed on {method}", bad,
                        "Malformed input triggered internal error.",
                        "CWE-209", "errors")

        if cfg.profile == "active":
            for idx, (qk, _qv) in enumerate(op["query"]):
                if stopped(): break
                base_qs = list(op["query"])
                xss = base_qs[:]; xss[idx] = (qk, _XSS_PROBE)
                xurl = op["url"].split("?", 1)[0] + "?" + urlencode(xss)
                stx, _, bbx, _ = wfetch(xurl, method=method,
                                         data=op["body"], extra=extra)
                if stx and bbx and _XSS_PROBE in bbx.decode("utf-8", errors="replace"):
                    add("high", f"Reflected XSS in query param '{qk}'", xurl,
                        "Payload reflected.", "CWE-79", "xss")
                sqi = base_qs[:]; sqi[idx] = (qk, str(_qv) + "'\"")
                surl = op["url"].split("?", 1)[0] + "?" + urlencode(sqi)
                sts, _, bbs, _ = wfetch(surl, method=method,
                                         data=op["body"], extra=extra)
                if sts and bbs:
                    low_s = bbs.decode("utf-8", errors="replace").lower()
                    hit = next((e for e in _SQL_ERRORS if e in low_s), None)
                    if hit:
                        add("critical", f"SQLi in param '{qk}'", surl,
                            f"DB error: {hit!r}", "CWE-89", "sqli")
                if qk.lower() in _API_REDIRECT:
                    rq = base_qs[:]; rq[idx] = (qk, "https://example.com/")
                    rurl = op["url"].split("?", 1)[0] + "?" + urlencode(rq)
                    str_, rh, _, _ = wfetch(rurl, method=method)
                    loc = rh.get("Location") or rh.get("location") or ""
                    if (str_ in (301, 302, 303, 307, 308)
                            and loc.startswith("https://example.com")):
                        add("high", f"Open redirect via '{qk}'", rurl,
                            f"Location: {loc}", "CWE-601", "redirect")
            if isinstance(op["json_body"], dict):
                for k, v in list(op["json_body"].items()):
                    if not isinstance(v, str) or stopped(): continue
                    mutated = dict(op["json_body"]); mutated[k] = _XSS_PROBE
                    stx, _, bbx, _ = wfetch(url, method=method,
                                             data=json.dumps(mutated).encode(),
                                             extra=extra)
                    if stx and bbx and _XSS_PROBE in bbx.decode("utf-8", errors="replace"):
                        add("high", f"Reflected XSS in JSON body field '{k}'",
                            url, "Payload reflected.", "CWE-79", "xss")

    if workers > 1 and len(to_test) > 1:
        with ThreadPoolExecutor(max_workers=workers) as ex_:
            list(ex_.map(_test_op, to_test))
    else:
        for op in to_test:
            if stopped(): break
            _test_op(op)
    tested = len(to_test)

    findings.sort(key=lambda x: -_DAST_SVR.get(x["severity"], 0))
    s = {"target": base, "spec_source": cfg.spec_source,
         "profile": cfg.profile,
         "endpoints_total": len(ops), "endpoints_tested": tested,
         "cancelled": stopped(), "findings": findings}
    if stopped(): log("[api] scan cancelled")
    out_p = write_out(s)
    log(f"[api] complete: {tested}/{len(ops)} endpoints, "
        f"{len(findings)} findings → {out_p}")
    return s, out_p


# ── Login macro analysis ──────────────────────────────────────────────────────
def analyze_login_macro(macro: list) -> tuple:
    """Industry-standard credential-field detection from recorded events.

    Returns (user_selector, user_value, pass_selector, pass_value,
    submit_selector). submit_selector is only set when a real submit *button*
    was clicked; Enter / form submits are handled by the caller.

    This is the pure-logic counterpart of ScannerApp._analyze_login_macro;
    it has no GUI dependency and can be called from any context.
    """
    # Last password field wins (handles retries / value corrections).
    pass_entry = None
    for s in macro:
        if s.get("kind") == "field" and s.get("selector") and (
                s.get("role") == "password" or s.get("ftype") == "password"):
            pass_entry = s
    pass_sel = pass_entry.get("selector") if pass_entry else None
    pass_val = pass_entry.get("value") if pass_entry else None

    # Username: prefer an explicit username-role field that occurs before the
    # password; fall back to the last non-password field before it.
    user_sel = user_val = None
    pass_pos = macro.index(pass_entry) if pass_entry in macro else len(macro)
    import re as _re2
    role_user = [s for s in macro[:pass_pos]
                 if s.get("kind") == "field" and s.get("role") == "username"
                 and s.get("selector")]
    if role_user:
        user_sel = role_user[-1]["selector"]; user_val = role_user[-1].get("value")
    else:
        for s in reversed(macro[:pass_pos]):
            if s.get("kind") == "field" and s.get("selector") \
                    and s.get("role") != "password" and s.get("ftype") != "password":
                user_sel = s["selector"]; user_val = s.get("value"); break

    # Submit button: a click after the password on a submit-ish element.
    submit_sel = None
    for s in macro[pass_pos + 1:]:
        if s.get("kind") == "click" and s.get("selector"):
            submit_sel = s["selector"]; break
    if not submit_sel:
        sub = next((s for s in macro if s.get("kind") == "submit"
                    and s.get("button")), None)
        if sub: submit_sel = sub["button"]
    return user_sel, user_val, pass_sel, pass_val, submit_sel


# ── Browser recorder worker functions (Selenium, no GUI) ──────────────────────
# These callables are meant to be passed as the `work` argument to a
# browser-launcher wrapper (e.g. ScannerApp._record_in_browser).  They receive:
#   driver        — a live Selenium WebDriver instance
#   url           — the starting URL
#   done          — threading.Event; set by the HUD when the user captures
#   result        — dict to write outputs into
#   set_status    — callable(str) to relay live status to the HUD label
# and are executed inside a daemon thread that already owns the driver.

def record_macro_work(cfg: DastConfig,
                      emit_log: Callable[[str], None] = lambda _: None):
    """Return a `work` callable that records a login macro.

    Usage::

        work = record_macro_work(cfg, emit_log=my_log)
        # pass `work` to _record_in_browser / your own browser launcher
    """
    def _work(driver, url, done, result, set_status=lambda _: None):
        emit_log(f"[macro] opening {url} — log in, then press "
                 "Ctrl+Shift+F12 to capture")
        driver.get(url)
        set_status("✅  Log in normally, then press Ctrl+Shift+F12")
        acc: list = []
        try:
            driver.execute_script(_MACRO_JS)
        except Exception:
            pass
        while not done.is_set():
            try:
                driver.execute_script(
                    "if(!window.__macro_installed){" + _MACRO_JS + "}")
            except Exception:
                pass
            try:
                chunk = json.loads(driver.execute_script(_MACRO_DRAIN_JS) or "[]")
                if chunk:
                    acc.extend(chunk)
            except Exception:
                pass
            if done.wait(0.4):
                break
        # Final drain after the user hits capture.
        try:
            chunk = json.loads(driver.execute_script(_MACRO_DRAIN_JS) or "[]")
            if chunk:
                acc.extend(chunk)
        except Exception:
            pass
        result["macro"] = json.dumps(acc)
        try:
            result["cookies"] = driver.get_cookies() or []
        except Exception:
            result["cookies"] = []
    return _work


def record_logout_work(cfg: DastConfig,
                       emit_log: Callable[[str], None] = lambda _: None):
    """Return a `work` callable that replays login then records the logout state.

    The returned function opens the login page, replays the saved macro to reach
    the authenticated state, then waits for the user to navigate to the
    logged-out page and press the capture hotkey.
    """
    import re as _re2
    _LOGOUT_KW = ("logout", "log-out", "signout", "sign-out", "cerrar", "salir")

    def _work(driver, url, done, result, set_status=lambda _: None):
        import time as _t
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC
        from selenium.webdriver.common.by import By

        login_url  = (cfg.selenium_login_url or url).strip()
        pass_val   = cfg.selenium_pass_value.strip()
        macro_raw  = cfg.selenium_macro.strip()
        succ_sel   = cfg.login_success_selector.strip()
        succ_txt   = cfg.login_success_text.strip()

        password_missing = bool(cfg.selenium_pass_selector and not pass_val)
        can_replay = bool(
            (macro_raw or cfg.selenium_user_selector or
             (cfg.selenium_pass_selector and pass_val) or
             cfg.selenium_submit_selector or cfg.selenium_extra_steps)
            and not password_missing)

        per_wait = max(2, min(int(cfg.selenium_wait_seconds or 15), 8))

        emit_log(f"[logout-rec] navigating to login page: {login_url}")
        set_status("⏳  Opening login page…")
        try:
            driver.get(login_url)
        except Exception as e:
            emit_log(f"[logout-rec] navigation error: {e!r}")
        _t.sleep(1.0)

        if not can_replay:
            emit_log("[logout-rec] no replayable login — waiting for MANUAL login")
            set_status("👤  Log in by hand, then go to the logged-OUT page "
                       "→ Ctrl+Shift+F12")
        else:
            emit_log("[logout-rec] replaying saved login (literal)…")
            set_status("🔁  Replaying saved login…")
            try:
                macro = json.loads(macro_raw) if macro_raw else []
            except Exception as ex:
                macro = []
                emit_log(f"[logout-rec] macro JSON invalid: {ex!r}")

            typed_password = False
            if macro:
                typed_password = _replay_login_macro(
                    driver, macro, pass_value=(pass_val or None),
                    wait_seconds=cfg.selenium_wait_seconds, log=emit_log)
            else:
                # Field-based fallback
                def _find(sel, timeout=per_wait):
                    try:
                        return WebDriverWait(driver, timeout).until(
                            EC.presence_of_element_located((By.CSS_SELECTOR, sel)))
                    except Exception:
                        emit_log(f"[logout-rec] selector not found: {sel}")
                        return None

                if cfg.selenium_user_selector and cfg.selenium_user_value:
                    el = _find(cfg.selenium_user_selector)
                    if el:
                        try: el.clear(); el.send_keys(cfg.selenium_user_value)
                        except Exception: pass
                if cfg.selenium_pass_selector and pass_val:
                    el = _find(cfg.selenium_pass_selector)
                    if el:
                        try:
                            el.clear(); el.send_keys(pass_val)
                            typed_password = True
                        except Exception: pass
                if cfg.selenium_submit_selector:
                    el = _find(cfg.selenium_submit_selector)
                    if el:
                        try: el.click()
                        except Exception: pass
                elif cfg.selenium_pass_selector and pass_val:
                    try:
                        from selenium.webdriver.common.keys import Keys as _K
                        driver.find_element(
                            By.CSS_SELECTOR, cfg.selenium_pass_selector).send_keys(_K.ENTER)
                    except Exception: pass

            try: driver.switch_to.default_content()
            except Exception: pass

            # Confirm logged-in state
            set_status("⏳  Waiting for login to complete…")

            def _confirm_logged_in():
                if done.is_set():
                    emit_log("[logout-rec] capture requested early — skipping login confirmation")
                    return False
                try:
                    if succ_sel:
                        WebDriverWait(driver, per_wait).until(
                            EC.presence_of_element_located((By.CSS_SELECTOR, succ_sel)))
                        emit_log("[logout-rec] login confirmed (selector present)")
                        return True
                    if succ_txt:
                        WebDriverWait(driver, per_wait).until(
                            lambda d: succ_txt in d.page_source)
                        emit_log("[logout-rec] login confirmed (text present)")
                        return True
                    _t.sleep(2.5)
                    gone = not driver.execute_script(
                        "var ps=document.querySelectorAll('input[type=password]');"
                        "for(var i=0;i<ps.length;i++){"
                        "  var r=ps[i].getBoundingClientRect();"
                        "  var st=window.getComputedStyle(ps[i]);"
                        "  var visible=(r.width>0&&r.height>0"
                        "    &&st.visibility!=='hidden'"
                        "    &&st.display!=='none'"
                        "    &&st.opacity!=='0');"
                        "  if(visible) return true;"
                        "}"
                        "return false;")
                    emit_log(f"[logout-rec] login replayed (heuristic logged_in={gone})")
                    return gone
                except Exception:
                    emit_log("[logout-rec] login confirmation timed out — continuing anyway")
                    return False

            logged_in = _confirm_logged_in()
            if logged_in:
                set_status("✅  Logged in — go to the logged-OUT page, then Ctrl+Shift+F12")
            else:
                set_status("🔓  Login replayed — navigate to the logged-OUT page, then Ctrl+Shift+F12")

        set_status("✅  Logged in — open user menu, click Log Out, then Ctrl+Shift+F12")
        emit_log("[logout-rec] recording started — click Log Out now")

        # Record logout interactions
        logout_acc: list = []
        try: driver.execute_script(_MACRO_JS)
        except Exception: pass

        while not done.is_set():
            try:
                driver.execute_script(
                    "if(!window.__macro_installed){" + _MACRO_JS + "}")
            except Exception: pass
            try:
                chunk = json.loads(driver.execute_script(_MACRO_DRAIN_JS) or "[]")
                if chunk:
                    logout_acc.extend(chunk)
                    emit_log(
                        f"[logout-rec] {len(logout_acc)} steps so far: "
                        + str([s.get("kind") for s in logout_acc]))
            except Exception: pass
            # Poll fast (0.15s) so a click that triggers an immediate navigation
            # is drained from sessionStorage before the page tears down.
            if done.wait(0.15): break

        # Final drain — pull anything captured right before done was set.
        try:
            chunk = json.loads(driver.execute_script(_MACRO_DRAIN_JS) or "[]")
            if chunk: logout_acc.extend(chunk)
        except Exception: pass

        emit_log(
            f"[logout-rec] recorded {len(logout_acc)} steps: "
            + str([s.get("kind") + ":" + str(s.get("selector", ""))[:30]
                   for s in logout_acc]))

        # Extract href candidates and the "last click" logout button properties.
        # We now look at href, text, el_id, el_cls, and data_action so that
        # SPA logout buttons (no href, no URL change) are still captured.
        logout_href_candidates: list = []
        result["last_logout_click"] = {}   # properties of the final click step
        for s in logout_acc:
            if s.get("kind") == "click":
                h    = s.get("href", "")
                txt  = (s.get("text",        "") or "").lower()
                eid  = (s.get("el_id",       "") or "").lower()
                ecls = (s.get("el_cls",      "") or "").lower()
                dact = (s.get("data_action", "") or "").lower()
                combined = " ".join([h.lower(), txt, eid, ecls, dact])
                is_kw = any(k in combined for k in _LOGOUT_KW)
                # Always store href if keyword found
                if h and is_kw:
                    if h not in logout_href_candidates:
                        logout_href_candidates.append(h)
        # The very last click is almost certainly the logout action regardless
        # of keywords — store it so the test/replay can target it directly.
        for s in reversed(logout_acc):
            if s.get("kind") == "click":
                result["last_logout_click"] = {
                    "selector":          s.get("selector",    ""),
                    "fallback_selectors": s.get("fallback_selectors", []),
                    "href":              s.get("href",         ""),
                    "text":              s.get("text",         ""),
                    "el_id":             s.get("el_id",        ""),
                    "el_cls":            s.get("el_cls",       ""),
                    "data_action":       s.get("data_action",  ""),
                }
                emit_log(
                    f"[logout-rec] last click → sel={s.get('selector','')[:60]!r} "                    f"text={s.get('text','')!r} id={s.get('el_id','')!r}"
                )
                break

        # Capture the logged-out page snapshot
        set_status("📸  Capturing logout state…")
        snap = {}
        try:
            raw = driver.execute_script(_LOGOUT_CAPTURE_JS)
            if raw: snap = json.loads(raw)
        except Exception as e:
            emit_log(f"[logout-rec] JS capture error: {e!r}")
        result["snapshot"] = snap if isinstance(snap, dict) else {}
        result["logout_macro"] = logout_acc
        result["logout_href_candidates"] = logout_href_candidates
        try: result["final_url"] = driver.current_url
        except Exception:
            result["final_url"] = snap.get("url", "") if isinstance(snap, dict) else ""
        try: result["cookies"] = driver.get_cookies() or []
        except Exception: result["cookies"] = []
        emit_log(
            f"[logout-rec] done. final_url={result.get('final_url', '')!r} "
            f"steps={len(logout_acc)} hrefs={logout_href_candidates!r}")

    return _work


def test_logout_work(cfg: DastConfig,
                     emit_log: Callable[[str], None] = lambda _: None):
    """Return a `work` callable that tests login + logout end-to-end.

    Replays the recorded login macro, then replays the logout macro and
    closes the browser automatically.  Sets ``done`` when finished so the
    HUD framework closes without requiring a manual Ctrl+Shift+F12.
    """
    def _work(driver, url, done, result, set_status=lambda _: None):
        import time as _t
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC
        from selenium.webdriver.common.by import By

        login_url  = (cfg.selenium_login_url or url).strip()
        pass_val   = cfg.selenium_pass_value.strip()
        macro_raw  = cfg.selenium_macro.strip()
        succ_sel   = cfg.login_success_selector.strip()
        succ_txt   = cfg.login_success_text.strip()
        logout_macro_raw = (getattr(cfg, "selenium_logout_macro", "") or "").strip()

        per_wait = max(2, min(int(cfg.selenium_wait_seconds or 15), 10))

        # Step 1: navigate to login page
        emit_log(f"[test-logout] navigating to login page: {login_url}")
        set_status("⏳  Opening login page…")
        try:
            driver.get(login_url)
        except Exception as e:
            emit_log(f"[test-logout] navigation error: {e!r}")
        _t.sleep(1.0)

        # Step 2: replay login
        set_status("🔁  Replaying login condition…")
        typed_ok = False
        try:
            macro = json.loads(macro_raw) if macro_raw else []
        except Exception as ex:
            macro = []
            emit_log(f"[test-logout] macro JSON invalid: {ex!r}")

        if macro:
            typed_ok = _replay_login_macro(
                driver, macro, pass_value=(pass_val or None),
                wait_seconds=cfg.selenium_wait_seconds, log=emit_log)
        elif cfg.selenium_user_selector or cfg.selenium_pass_selector:
            def _find(sel, timeout=per_wait):
                try:
                    return WebDriverWait(driver, timeout).until(
                        EC.presence_of_element_located((By.CSS_SELECTOR, sel)))
                except Exception:
                    return None
            if cfg.selenium_user_selector and cfg.selenium_user_value:
                el = _find(cfg.selenium_user_selector)
                if el:
                    try: el.clear(); el.send_keys(cfg.selenium_user_value)
                    except Exception: pass
            if cfg.selenium_pass_selector and pass_val:
                el = _find(cfg.selenium_pass_selector)
                if el:
                    try:
                        el.clear(); el.send_keys(pass_val)
                        typed_ok = True
                    except Exception: pass
            if cfg.selenium_submit_selector:
                el = _find(cfg.selenium_submit_selector)
                if el:
                    try: el.click()
                    except Exception: pass
            elif cfg.selenium_pass_selector and pass_val:
                try:
                    from selenium.webdriver.common.keys import Keys as _K
                    driver.find_element(
                        By.CSS_SELECTOR, cfg.selenium_pass_selector).send_keys(_K.ENTER)
                except Exception: pass

        try: driver.switch_to.default_content()
        except Exception: pass

        # Step 3: confirm login
        set_status("⏳  Waiting for login to complete…")
        logged_in = False
        try:
            if succ_sel:
                WebDriverWait(driver, per_wait).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, succ_sel)))
                logged_in = True
                emit_log("[test-logout] login confirmed (selector)")
            elif succ_txt:
                WebDriverWait(driver, per_wait).until(
                    lambda d: succ_txt in d.page_source)
                logged_in = True
                emit_log("[test-logout] login confirmed (text)")
            else:
                _t.sleep(2)
                gone = not driver.execute_script(
                    "var ps=document.querySelectorAll('input[type=password]');"
                    "for(var i=0;i<ps.length;i++)"
                    " if(ps[i].offsetParent!==null) return true;"
                    "return false;")
                logged_in = gone
                emit_log(f"[test-logout] login heuristic logged_in={gone}")
        except Exception as e:
            emit_log(f"[test-logout] login confirmation error: {e!r}")

        if logged_in:
            set_status("✅  Logged in — navigating to logout URL…")
        else:
            set_status("⚠️  Login uncertain — attempting logout navigation anyway…")
            emit_log("[test-logout] login could not be confirmed; proceeding")

        _t.sleep(1.0)

        # Step 4: replay logout macro
        replayed_logout = False
        emit_log(f"[test-logout] logout_macro_raw length={len(logout_macro_raw)}")
        if logout_macro_raw:
            try:
                lo_macro = json.loads(logout_macro_raw)
            except Exception as ex:
                lo_macro = []
                emit_log(f"[test-logout] logout macro JSON invalid: {ex!r}")
            if lo_macro:
                set_status("🚪  Replaying logout steps…")
                emit_log(
                    f"[test-logout] replaying logout macro ({len(lo_macro)} steps): "
                    + str([s.get("kind") + ":" + str(s.get("selector", ""))[:30]
                           for s in lo_macro]))
                url_before = driver.current_url
                try:
                    _replay_login_macro(
                        driver, lo_macro, pass_value=None,
                        wait_seconds=cfg.selenium_wait_seconds, log=emit_log)
                    _t.sleep(2.5)
                    url_after = driver.current_url
                    replayed_logout = True
                    result["logout_url_reached"] = url_after
                    result["logout_replayed"]    = True
                    url_changed = (url_after.rstrip("/") != url_before.rstrip("/"))
                    emit_log(
                        f"[test-logout] after logout: {url_after!r} "
                        f"(url_changed={url_changed})")
                except Exception as ex:
                    emit_log(f"[test-logout] logout macro replay raised: {ex!r}")
            else:
                emit_log("[test-logout] logout macro parsed but empty (0 steps)")
        else:
            emit_log("[test-logout] selenium_logout_macro is EMPTY — "
                     "the Logout Condition was never saved into the config")
        if not replayed_logout:
            emit_log("[test-logout] no logout macro — re-record Logout Condition")

        if replayed_logout:
            set_status("✅  Logout replayed — closing browser…")
        else:
            set_status("⚠️  Logout not completed — re-record Logout Condition")

        _t.sleep(1.5)
        result["test_done"] = True
        done.set()   # signal the HUD framework to close the browser

    return _work
