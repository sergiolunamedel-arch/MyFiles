"""static_scanner.py — unified Static-analysis engine.

Fusion of the former ``snyk_sca_sast.py`` (SCA via ``snyk test`` + SAST via
``snyk code``) and ``secrets_scanner.py`` (hard-coded credential scanning).
This single module now backs the GUI's **Static** tab, which runs all three
static analyses (SCA, SAST, Secrets) against one target folder.

Public surface (unchanged names, so callers keep working):

  SCA / SAST / environment
    CheckResult, check_python, check_node, check_npm, check_snyk, check_auth
    install_node, install_snyk, start_snyk_auth
    run_snyk_test, run_snyk_code
    export_sarif, export_merged_json

  Secrets
    ensure_git_secrets, get_git_secrets_status, get_engine_label
    scan_path, write_secrets_report, render_secrets_html, redact

The SARIF / merged-JSON exporters already fold every scanner's raw output
(SCA, SAST, DAST, API) together, so reporting is unaffected by the fusion.
"""

from __future__ import annotations

import json, os, re, sys, shutil, subprocess, platform, tempfile, time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Optional


# ══ SCA + SAST (Snyk) ════════════════════════════════════════════════════════
# ── Platform flags ────────────────────────────────────────────────────────────
IS_WIN   = os.name == "nt"
IS_MAC   = sys.platform == "darwin"
IS_LINUX = not IS_WIN and not IS_MAC


def _augment_path() -> None:
    """When launched from Finder/Dock (.app) or a desktop launcher, the process
    PATH is often minimal and misses Homebrew / user bin dirs, so tools like
    node, npm, snyk and brew become invisible. Prepend the usual locations
    (only those that exist) so _which() can find them on macOS / Linux."""
    if IS_WIN:
        return
    home = Path.home()
    candidates = [
        "/opt/homebrew/bin", "/opt/homebrew/sbin",   # Apple-silicon Homebrew
        "/usr/local/bin", "/usr/local/sbin",          # Intel Homebrew / common
        str(home / ".local" / "bin"), str(home / "bin"),
        "/opt/local/bin",                             # MacPorts
        str(home / ".nvm" / "current" / "bin"),       # nvm symlink (if present)
    ]
    cur = os.environ.get("PATH", "")
    parts = cur.split(os.pathsep)
    extra = [c for c in candidates if c and c not in parts and os.path.isdir(c)]
    if extra:
        os.environ["PATH"] = os.pathsep.join(extra + parts)


_augment_path()



# ── Re-export bootstrap helpers so callers don't need to import the main file ─
def _pip(args: list[str]) -> None:
    cmd = [sys.executable, "-m", "pip", "install", "--user",
           "--disable-pip-version-check"] + args
    try:
        subprocess.check_call(cmd, stdout=subprocess.DEVNULL,
                              stderr=subprocess.DEVNULL)
    except subprocess.CalledProcessError:
        env = os.environ.copy()
        env["PIP_TRUSTED_HOST"] = "pypi.org files.pythonhosted.org pypi.python.org"
        hosts = ["--trusted-host", "pypi.org",
                 "--trusted-host", "files.pythonhosted.org",
                 "--trusted-host", "pypi.python.org"]
        subprocess.check_call(cmd + hosts, env=env,
                              stdout=subprocess.DEVNULL,
                              stderr=subprocess.DEVNULL)
    import site
    us = site.getusersitepackages()
    if us not in sys.path:
        sys.path.insert(0, us)


# ── Platform utils (minimal subset needed here) ───────────────────────────────
def _which(cmd: str) -> Optional[str]:
    if (f := shutil.which(cmd)):
        return f
    if os.name == "nt":
        for ext in (".cmd", ".bat", ".exe"):
            if (f := shutil.which(cmd + ext)):
                return f
    return None


def _run(args, cwd=None, env=None, timeout=600) -> subprocess.CompletedProcess:
    return subprocess.run(
        args, cwd=str(cwd) if cwd else None,
        env=env if env is not None else os.environ.copy(),
        timeout=timeout, capture_output=True, text=True,
        encoding="utf-8", errors="replace", shell=False)


def _run_tls(args, cwd=None, timeout=900,
             log: Callable[[str], None] = lambda _: None) -> subprocess.CompletedProcess:
    env = os.environ.copy()
    log(f"$ {' '.join(args)}")
    r = _run(args, cwd=cwd, env=env, timeout=timeout)
    combined = ((r.stdout or "") + (r.stderr or "")).lower()
    if r.returncode != 0 and any(
            m in combined for m in ("self signed certificate", "unable to verify",
                                    "ssl", "cert_", "econnreset")):
        log("[tls-retry] retrying with NODE_TLS_REJECT_UNAUTHORIZED=0")
        env["NODE_TLS_REJECT_UNAUTHORIZED"] = "0"
        r = _run(args, cwd=cwd, env=env, timeout=timeout)
    return r


# ── Package-manager / tool resolvers ──────────────────────────────────────────
def _brew() -> Optional[str]:
    """Locate Homebrew even when it's not on the (possibly minimal) PATH."""
    if p := shutil.which("brew"):
        return p
    for cand in ("/opt/homebrew/bin/brew", "/usr/local/bin/brew"):
        if Path(cand).exists():
            return cand
    return None


def _snyk_bin() -> str:
    """Resolved snyk executable (snyk.cmd on Windows), falling back to 'snyk'."""
    return _which("snyk") or "snyk"


def _linux_pkg_mgr() -> Optional[tuple[str, list[str]]]:
    """Return (manager, install-prefix-args) for the host Linux distro."""
    if shutil.which("apt-get"):
        return "apt-get", ["apt-get", "install", "-y"]
    if shutil.which("dnf"):
        return "dnf", ["dnf", "install", "-y"]
    if shutil.which("yum"):
        return "yum", ["yum", "install", "-y"]
    if shutil.which("zypper"):
        return "zypper", ["zypper", "--non-interactive", "install"]
    if shutil.which("pacman"):
        return "pacman", ["pacman", "-S", "--noconfirm"]
    return None


def _sudo_prefix() -> list[str]:
    """Non-interactive sudo prefix when needed and available, else empty."""
    if os.geteuid() == 0 if hasattr(os, "geteuid") else False:
        return []
    if shutil.which("sudo"):
        return ["sudo", "-n"]   # -n: never prompt; fail fast if a password is required
    return []


def _download_file(url: str, dest: Path, log: Callable[[str], None],
                   timeout: int = 120) -> bool:
    import urllib.request
    try:
        log(f"[download] {url}")
        req = urllib.request.Request(url, headers={"User-Agent": "vuln-scanner/1.0"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:  # nosec - fixed host
            data = resp.read()
        if not data:
            log("[download] empty response"); return False
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        log(f"[download] saved {len(data)//1024} KB → {dest}")
        return True
    except Exception as e:
        log(f"[download] failed: {e!r}")
        return False


def _standalone_snyk_asset() -> Optional[str]:
    """Asset name for Snyk's npm-free standalone CLI binary for this host."""
    arch = (platform.machine() or "").lower()
    is_arm = arch in ("arm64", "aarch64")
    if IS_WIN:
        return "snyk-win.exe"
    if IS_MAC:
        return "snyk-macos-arm64" if is_arm else "snyk-macos"
    # Linux: detect musl (Alpine) vs glibc.
    if Path("/etc/alpine-release").exists():
        return "snyk-alpine-arm64" if is_arm else "snyk-alpine"
    return "snyk-linux-arm64" if is_arm else "snyk-linux"


def _install_standalone_snyk(log: Callable[[str], None]) -> bool:
    """Universal npm-free fallback: download the official Snyk CLI binary to
    ~/.local/bin (or %LOCALAPPDATA% on Windows) and make it executable."""
    asset = _standalone_snyk_asset()
    if not asset:
        return False
    if IS_WIN:
        bindir = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "snyk" / "bin"
        target = bindir / "snyk.exe"
    else:
        bindir = Path.home() / ".local" / "bin"
        target = bindir / "snyk"
    url = f"https://static.snyk.io/cli/latest/{asset}"
    log(f"[snyk] installing standalone CLI ({asset})…")
    if not _download_file(url, target, log, timeout=180):
        return False
    if not IS_WIN:
        try: os.chmod(target, 0o755)
        except Exception: pass
    # Make sure the freshly-installed binary is visible to this process now.
    os.environ["PATH"] = str(bindir) + os.pathsep + os.environ.get("PATH", "")
    if _which("snyk"):
        log(f"[snyk] standalone CLI ready → {target}")
        return True
    log(f"[snyk] installed to {target}, but {bindir} is not on PATH. "
        f"Add it to your shell profile (e.g. export PATH=\"{bindir}:$PATH\").")
    return target.exists()


# ── Environment checks ────────────────────────────────────────────────────────
@dataclass
class CheckResult:
    name: str; ok: bool; detail: str = ""; fixable: bool = False


def check_python() -> CheckResult:
    v = sys.version_info
    return CheckResult("Python ≥ 3.9",
                       (v.major, v.minor) >= (3, 9),
                       f"Python {v.major}.{v.minor}.{v.micro}")


def _check_tool(label: str, cmd: str) -> CheckResult:
    real = "npm.cmd" if (cmd == "npm" and os.name == "nt") else cmd
    if not _which(cmd):
        return CheckResult(label, False, "not found in PATH", fixable=True)
    try:
        r = _run([real, "--version"])
        return CheckResult(label, r.returncode == 0,
                           (r.stdout or "").strip(), fixable=True)
    except Exception as e:
        return CheckResult(label, False, str(e), fixable=True)


def check_node() -> CheckResult: return _check_tool("Node.js", "node")
def check_npm()  -> CheckResult: return _check_tool("npm", "npm")
def check_snyk() -> CheckResult: return _check_tool("Snyk CLI", "snyk")


def _snyk_cfg(key: str) -> str:
    try:
        v = (_run(["snyk", "config", "get", key]).stdout or "").strip()
        return "" if v.lower() in ("", "undefined", "null", "not set") else v
    except Exception:
        return ""


def check_auth() -> CheckResult:
    if not _which("snyk"):
        return CheckResult("Snyk auth", False, "Snyk CLI missing")
    if tok := _snyk_cfg("api"):
        m = tok[:4] + "…" + tok[-4:] if len(tok) > 8 else "set"
        return CheckResult("Snyk auth", True, f"token: {m}", fixable=True)
    if _snyk_cfg("INTERNAL_OAUTH_TOKEN_STORAGE"):
        return CheckResult("Snyk auth", True, "SSO/OAuth active", fixable=True)
    try:
        r = _run(["snyk", "whoami", "--experimental"], timeout=30)
        if r.returncode == 0:
            lines = ((r.stdout or "") + (r.stderr or "")).strip().splitlines()
            label = next((ln for ln in lines if ln.strip()), "authenticated")
            return CheckResult("Snyk auth", True, label[:40], fixable=True)
    except Exception:
        pass
    return CheckResult("Snyk auth", False, "not authenticated", fixable=True)


# ── Installers ────────────────────────────────────────────────────────────────
def install_node(log: Callable[[str], None]) -> bool:
    if _which("node") and _which("npm"):
        log("[node] already installed"); return True

    if IS_WIN:
        if not _which("winget"):
            log("[node] install Node.js LTS from https://nodejs.org/"); return False
        log("[node] installing via winget…")
        r = _run(["winget", "install", "--id", "OpenJS.NodeJS.LTS", "-e",
                  "--silent", "--accept-package-agreements",
                  "--accept-source-agreements"], timeout=1800)
        log((r.stdout or "") + (r.stderr or ""))
        return r.returncode == 0

    if IS_MAC:
        brew = _brew()
        if not brew:
            log("[node] Homebrew not found. Install it from https://brew.sh "
                "then re-run, or install Node.js LTS from https://nodejs.org/.")
            return False
        log("[node] installing via Homebrew (brew install node)…")
        r = _run([brew, "install", "node"], timeout=1800)
        if r.stdout: log(r.stdout.strip()[-2000:])
        if r.stderr: log(r.stderr.strip()[-2000:])
        _augment_path()
        return _which("node") is not None and _which("npm") is not None

    # Linux
    mgr = _linux_pkg_mgr()
    if not mgr:
        log("[node] no supported package manager found. Install Node.js LTS via "
            "your distro or nvm (https://github.com/nvm-sh/nvm).")
        return False
    name, install_args = mgr
    # Debian/Ubuntu ship the binary as 'nodejs'; most distros also provide 'npm'.
    pkgs = ["nodejs", "npm"] if name in ("apt-get", "dnf", "yum") else ["nodejs", "npm"]
    sudo = _sudo_prefix()
    if name == "apt-get":
        log("[node] apt-get update…")
        _run(sudo + ["apt-get", "update"], timeout=600)
    log(f"[node] installing via {name} ({' '.join(pkgs)})…")
    r = _run(sudo + install_args + pkgs, timeout=1800)
    if r.stdout: log(r.stdout.strip()[-2000:])
    if r.stderr: log(r.stderr.strip()[-2000:])
    if r.returncode != 0 and sudo and "-n" in sudo:
        log("[node] automatic install needs elevated rights. Run manually:\n"
            f"    sudo {' '.join(install_args + pkgs)}")
    _augment_path()
    return _which("node") is not None and _which("npm") is not None


def install_snyk(log: Callable[[str], None]) -> bool:
    if _which("snyk"):
        log("[snyk] already installed"); return True

    # Preferred path: npm (works on every OS when Node is present).
    if _which("npm"):
        npm = "npm.cmd" if IS_WIN else "npm"
        log("[snyk] npm install -g snyk")
        r = _run_tls([npm, "install", "-g", "snyk"], log=log, timeout=1800)
        if r.stdout: log(r.stdout)
        if r.stderr: log(r.stderr)
        _augment_path()
        if _which("snyk"):
            return True
        log("[snyk] npm install did not expose 'snyk' on PATH; trying fallback…")

    # No npm (or it failed): use a native package manager where possible.
    if IS_MAC and _brew():
        brew = _brew()
        log("[snyk] installing via Homebrew (brew install snyk-cli)…")
        r = _run([brew, "install", "snyk-cli"], timeout=1800)
        if r.returncode != 0:                      # older tap name
            r = _run([brew, "install", "snyk"], timeout=1800)
        if r.stdout: log(r.stdout.strip()[-2000:])
        if r.stderr: log(r.stderr.strip()[-2000:])
        _augment_path()
        if _which("snyk"):
            return True

    if IS_WIN and _which("winget"):
        log("[snyk] installing via winget (Snyk.SnykCLI)…")
        r = _run(["winget", "install", "--id", "Snyk.SnykCLI", "-e", "--silent",
                  "--accept-package-agreements", "--accept-source-agreements"],
                 timeout=1800)
        log((r.stdout or "") + (r.stderr or ""))
        if _which("snyk"):
            return True

    # Universal npm-free fallback: official standalone binary.
    log("[snyk] falling back to the standalone Snyk CLI binary…")
    return _install_standalone_snyk(log)


def start_snyk_auth(log: Callable[[str], None]) -> subprocess.Popen:
    log("[auth] launching `snyk auth` — browser will open shortly.")
    kwargs: dict = {}
    if IS_WIN:
        kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP  # type: ignore[attr-defined]
    return subprocess.Popen([_snyk_bin(), "auth"],
                            stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True,
                            encoding="utf-8", errors="replace",
                            **kwargs)


# ── JSON helpers ──────────────────────────────────────────────────────────────
def _parse_json_loose(stdout: str) -> Any:
    if not stdout or not stdout.strip():
        return None
    try:
        return json.loads(stdout)
    except json.JSONDecodeError:
        docs = []
        for line in stdout.splitlines():
            line = line.strip()
            if line:
                try: docs.append(json.loads(line))
                except json.JSONDecodeError: pass
        return docs or None


def _count_vulns(data: Any) -> int:
    projects = (data if isinstance(data, list) else [data]) if data else []
    return sum(
        len((p or {}).get("vulnerabilities") or [])
        for p in projects if isinstance(p, dict))


# ── Python sandbox helper ─────────────────────────────────────────────────────
def _prepare_pip_sandbox(target: Path,
                         log: Callable[[str], None]) -> Optional[dict]:
    req = target / "requirements.txt"
    if not req.exists():
        return None
    venv_dir   = target / ".snyk-venv"
    wheels_dir = target / ".snyk-wheels"
    wheels_dir.mkdir(exist_ok=True)
    scripts = venv_dir / ("Scripts" if os.name == "nt" else "bin")
    py_exe  = scripts  / ("python.exe" if os.name == "nt" else "python")
    if not py_exe.exists():
        log(f"[sandbox] creating isolated venv at {venv_dir}…")
        r = _run([sys.executable, "-m", "venv", str(venv_dir)], timeout=300)
        if r.returncode != 0:
            log(f"[sandbox] venv failed: {(r.stderr or r.stdout).strip()}")
            return None
        _run([str(py_exe), "-m", "pip", "install", "--upgrade", "pip",
              "--disable-pip-version-check"], timeout=600)
    log("[sandbox] downloading wheels (wheels-only, no code executes)…")
    dl = _run([str(py_exe), "-m", "pip", "download", "--only-binary=:all:",
               "--dest", str(wheels_dir), "-r", str(req),
               "--disable-pip-version-check"], timeout=900)
    if dl.stdout: log(dl.stdout.strip()[-1500:])
    if dl.stderr: log(dl.stderr.strip()[-1500:])
    if not list(wheels_dir.glob("*.whl")):
        log("[sandbox] no wheels downloaded; skipping sandbox."); return None
    inst = _run([str(py_exe), "-m", "pip", "install", "--no-index",
                 "--find-links", str(wheels_dir), "--only-binary=:all:",
                 "--no-build-isolation", "-r", str(req),
                 "--disable-pip-version-check"], timeout=900)
    if inst.stdout: log(inst.stdout.strip()[-1500:])
    if inst.stderr: log(inst.stderr.strip()[-1500:])
    installed = (_run([str(py_exe), "-m", "pip", "list", "--format=freeze"],
                      timeout=60).stdout or "").strip()
    if not installed:
        log("[sandbox] venv empty; SCA may report 0."); return None
    log(f"[sandbox] ready ({len(installed.splitlines())} packages visible to Snyk).")
    env = os.environ.copy()
    env["VIRTUAL_ENV"] = str(venv_dir)
    env["PATH"] = str(scripts) + os.pathsep + env.get("PATH", "")
    env.pop("PYTHONHOME", None)
    return env


# ── Core scan runner ──────────────────────────────────────────────────────────
def _snyk_json_scan(args, *, target, out_dir, out_name, log, env=None,
                    timeout=1800, write_raw=False,
                    count_label="") -> tuple[Any, Path]:
    log(f"[scan] $ snyk {' '.join(args[1:])}  (cwd={target})")
    r = _run(args, cwd=target, env=env, timeout=timeout)
    if r.stderr:
        log(r.stderr.strip()[-2000:])
    data = _parse_json_loose(r.stdout or "")
    out_path = out_dir / out_name
    out_path.write_text(
        r.stdout or "" if write_raw else json.dumps(data, indent=2),
        encoding="utf-8")
    if count_label:
        log(f"[scan] {count_label} total vulnerabilities: {_count_vulns(data)}")
    log(f"[scan] raw JSON → {out_path}")
    return data, out_path


def run_snyk_test(target: Path, out_dir: Path,
                  log: Callable[[str], None]) -> tuple[Any, Path]:
    """SCA scan via `snyk test --all-projects`."""
    sb_env = _prepare_pip_sandbox(target, log)
    args = ["snyk", "test", "--all-projects", "--detection-depth=10",
            "--strict-out-of-sync=false", "--skip-unresolved", "--json"]
    return _snyk_json_scan(args, target=target, out_dir=out_dir,
                           out_name="snyk_test.json", log=log, env=sb_env,
                           count_label="SCA")


def run_snyk_code(target: Path, out_dir: Path,
                  log: Callable[[str], None]) -> tuple[Any, Path]:
    """SAST scan via `snyk code test`."""
    return _snyk_json_scan(["snyk", "code", "test", "--json"],
                           target=target, out_dir=out_dir,
                           out_name="snyk_code.json",
                           log=log, write_raw=True)


# ── SARIF / merged-JSON exporters ─────────────────────────────────────────────
_SARIF_LEVEL = {"critical": "error", "high": "error",
                "medium": "warning", "low": "note", "info": "note"}


def _sarif_run(tool_name: str, results: list[dict]) -> dict:
    rules: dict[str, dict] = {}
    out_results = []
    for r in results:
        rule_id  = r.get("rule_id") or r.get("title") or "finding"
        rules.setdefault(rule_id, {
            "id": rule_id,
            "name": rule_id[:120],
            "shortDescription": {"text": (r.get("title") or rule_id)[:200]},
            "properties": {k: v for k, v in (("cwe", r.get("cwe")),) if v},
        })
        sev = (r.get("severity") or "low").lower()
        msg = r.get("title") or rule_id
        ev  = r.get("evidence") or ""
        loc_uri = r.get("url") or r.get("location") or ""
        res = {
            "ruleId": rule_id,
            "level": _SARIF_LEVEL.get(sev, "note"),
            "message": {"text": f"{msg}\n{ev}".strip()},
            "properties": {"severity": sev,
                           "category": r.get("category", "")},
        }
        if loc_uri:
            res["locations"] = [{"physicalLocation": {
                "artifactLocation": {"uri": loc_uri}}}]
        out_results.append(res)
    return {
        "tool": {"driver": {
            "name": tool_name,
            "informationUri": "https://snyk.io",
            "rules": list(rules.values())}},
        "results": out_results,
    }


def _collect_sca_findings(data) -> list[dict]:
    projects = (data if isinstance(data, list) else [data]) if data else []
    out = []
    for p in projects:
        if not isinstance(p, dict): continue
        for v in (p.get("vulnerabilities") or []):
            if not isinstance(v, dict): continue
            pkg = v.get("packageName") or v.get("package") or ""
            ver = v.get("version") or ""
            out.append({
                "rule_id":  v.get("id") or v.get("title") or "snyk-sca",
                "title":    v.get("title") or v.get("id") or "Vulnerability",
                "severity": (v.get("severity") or "low").lower(),
                "evidence": f"{pkg}@{ver}  " + (
                    " > ".join(map(str, (v.get("from") or [])[:6]))),
                "location": (p.get("displayTargetFile") or p.get("targetFile")
                             or p.get("path") or pkg),
                "cwe": ",".join(
                    v.get("identifiers", {}).get("CWE", []) or []),
                "category": "sca",
            })
    return out


def export_sarif(out_dir: Path) -> Optional[Path]:
    """Build a single SARIF 2.1.0 log from every scanner's raw output in
    out_dir. Returns the path, or None if nothing could be assembled."""
    runs: list[dict] = []

    def _load(name):
        f = out_dir / name
        if not f.exists(): return None
        try: return json.loads(f.read_text(encoding="utf-8"))
        except Exception: return None

    sca = _load("snyk_test.json")
    if sca is not None:
        sca_findings = _collect_sca_findings(sca)
        if sca_findings:
            runs.append(_sarif_run("Snyk Open Source (SCA)", sca_findings))

    # snyk code --json already emits SARIF — merge its runs verbatim.
    code = _load("snyk_code.json")
    if isinstance(code, dict) and isinstance(code.get("runs"), list):
        runs.extend(code["runs"])
    elif isinstance(code, list):
        for doc in code:
            if isinstance(doc, dict) and isinstance(doc.get("runs"), list):
                runs.extend(doc["runs"])

    for name, tool in (("dast.json", "DAST Crawler"),
                       ("api.json",  "API Scanner")):
        d = _load(name)
        if isinstance(d, dict) and d.get("findings"):
            runs.append(_sarif_run(tool, d["findings"]))

    if not runs:
        return None
    sarif = {
        "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
        "version": "2.1.0",
        "runs": runs,
    }
    path = out_dir / "findings.sarif"
    path.write_text(json.dumps(sarif, indent=2), encoding="utf-8")
    return path


def export_merged_json(out_dir: Path) -> Optional[Path]:
    """One flat JSON array of all non-SAST findings (DAST + API + SCA).
    Snyk Code SARIF stays in snyk_code.json."""
    merged: list[dict] = []

    def _load(name):
        f = out_dir / name
        if not f.exists(): return None
        try: return json.loads(f.read_text(encoding="utf-8"))
        except Exception: return None

    sca = _load("snyk_test.json")
    if sca is not None:
        merged.extend(_collect_sca_findings(sca))
    for name in ("dast.json", "api.json"):
        d = _load(name)
        if isinstance(d, dict):
            merged.extend(d.get("findings") or [])
    if not merged:
        return None
    order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
    merged.sort(
        key=lambda x: order.get((x.get("severity") or "low").lower(), 5))
    path = out_dir / "findings_merged.json"
    path.write_text(json.dumps(merged, indent=2), encoding="utf-8")
    return path


# ══ Secrets scanner ══════════════════════════════════════════════════════════
SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}

# Module-level status cache — populated by ensure_git_secrets(), read via get_git_secrets_status().
_GIT_SECRETS_STATUS: dict = {}


def get_git_secrets_status() -> dict:
    """Return the cached git-secrets bootstrap status (set by ensure_git_secrets)."""
    return _GIT_SECRETS_STATUS


def get_engine_label(status: "Optional[dict]" = None) -> "tuple[str, str]":
    """Return (label_text, color_key) for the current engine status.

    color_key is ``'ok'`` when git-secrets is available, ``'muted'`` otherwise.
    The GUI maps these keys to its own theme colours.
    """
    st = status if status is not None else _GIT_SECRETS_STATUS
    if st.get("method") == "git-secrets" and st.get("available"):
        return f"git-secrets ready ({st.get('note', '')}) + built-in patterns", "ok"
    return "Built-in pattern engine (git-secrets download unavailable)", "muted"


GIT_SECRETS_RAW_URL = (
    "https://raw.githubusercontent.com/awslabs/git-secrets/master/git-secrets"
)

# Where we cache the downloaded git-secrets script.
def _cache_dir() -> Path:
    base = Path(os.environ.get("LOCALAPPDATA") or
                os.environ.get("XDG_CACHE_HOME") or
                (Path.home() / ".cache"))
    d = base / "vuln-scanner" / "git-secrets"
    try:
        d.mkdir(parents=True, exist_ok=True)
    except Exception:
        d = Path(tempfile.gettempdir()) / "vuln-scanner-git-secrets"
        d.mkdir(parents=True, exist_ok=True)
    return d


def _log(cb: Optional[Callable[[str], None]], msg: str) -> None:
    if cb:
        try: cb(msg)
        except Exception: pass


# ── Built-in providers (modelled on git-secrets defaults + common formats) ─────
# Each: (rule, secret_type, severity, compiled regex)
def _p(pattern: str, flags: int = 0) -> "re.Pattern[str]":
    return re.compile(pattern, flags)

_PROVIDERS: list[tuple[str, str, str, "re.Pattern[str]"]] = [
    ("aws-access-key-id", "AWS Access Key ID", "critical",
     _p(r"(?<![A-Z0-9])(?:AKIA|ASIA|AGPA|AIDA|AROA|AIPA|ANPA|ANVA|ABIA|ACCA)[A-Z0-9]{16}(?![A-Z0-9])")),
    ("aws-secret-access-key", "AWS Secret Access Key", "critical",
     _p(r"(?i)aws.{0,24}?(?:secret|private).{0,24}?['\"`]([0-9a-zA-Z/+]{40})['\"`]")),
    ("aws-session-token", "AWS Session Token", "high",
     _p(r"(?i)aws.{0,24}?session.{0,24}?token.{0,4}?['\"`]([0-9a-zA-Z/+=]{100,})['\"`]")),
    ("private-key", "Private key block", "critical",
     _p(r"-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP |ENCRYPTED )?PRIVATE KEY-----")),
    ("gcp-api-key", "Google API key", "high",
     _p(r"\bAIza[0-9A-Za-z\-_]{35}\b")),
    ("gcp-oauth", "Google OAuth client id", "medium",
     _p(r"\b[0-9]+-[0-9A-Za-z_]{32}\.apps\.googleusercontent\.com\b")),
    ("github-token", "GitHub token", "high",
     _p(r"\bgh[pousr]_[0-9A-Za-z]{36,255}\b")),
    ("slack-token", "Slack token", "high",
     _p(r"\bxox[baprs]-[0-9A-Za-z-]{10,48}\b")),
    ("slack-webhook", "Slack webhook URL", "medium",
     _p(r"https://hooks\.slack\.com/services/[A-Za-z0-9/_-]{30,}")),
    ("stripe-secret", "Stripe live secret key", "critical",
     _p(r"\b(?:sk|rk)_live_[0-9a-zA-Z]{20,}\b")),
    ("twilio-key", "Twilio API key", "high",
     _p(r"\bSK[0-9a-fA-F]{32}\b")),
    ("sendgrid-key", "SendGrid API key", "high",
     _p(r"\bSG\.[0-9A-Za-z\-_]{22}\.[0-9A-Za-z\-_]{43}\b")),
    ("jwt", "JSON Web Token", "medium",
     _p(r"\beyJ[A-Za-z0-9_-]{8,}\.eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b")),
    ("basic-auth-url", "Credentials embedded in URL", "high",
     _p(r"\b[a-zA-Z][a-zA-Z0-9+.\-]*://[^/\s:@]{1,64}:([^/\s:@]{3,64})@")),
    ("generic-secret", "Generic hard-coded secret", "medium",
     _p(r"(?i)\b(?:api[_-]?key|apikey|secret(?:[_-]?key)?|access[_-]?token|auth[_-]?token|client[_-]?secret|passwd|password|pwd)\b\s*[:=]\s*['\"`]([^'\"`\s]{12,128})['\"`]")),
]

# Strong, unambiguous placeholder markers — a hit is downgraded to "low" only
# when the matched token itself (not the whole line) contains one of these.
_EXAMPLE_MARKERS = (
    "EXAMPLE", "your-api-key", "your_api_key", "changeme", "change-me",
    "placeholder", "dummy", "redacted", "xxxxxxxx", "test-key", "testkey",
    "notreal", "fakekey", "sample",
)

# Directories / files never worth scanning.
_SKIP_DIRS = {
    ".git", ".hg", ".svn", "node_modules", "bower_components", "vendor",
    "venv", ".venv", "env", ".env.d", "__pycache__", ".mypy_cache",
    ".pytest_cache", "dist", "build", ".idea", ".vscode", ".gradle",
    "site-packages", "target", ".next", ".nuxt", "coverage", ".tox",
    "Reports", "reports",
}
_SKIP_EXT = {
    ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico", ".webp", ".svg",
    ".pdf", ".zip", ".gz", ".tar", ".tgz", ".bz2", ".7z", ".rar",
    ".mp3", ".mp4", ".avi", ".mov", ".mkv", ".wav", ".ogg", ".flac",
    ".woff", ".woff2", ".ttf", ".otf", ".eot",
    ".class", ".jar", ".war", ".so", ".dll", ".dylib", ".exe", ".bin",
    ".pyc", ".pyo", ".o", ".a", ".lib", ".obj", ".wasm",
    ".lock",
}
_MAX_BYTES = 1_500_000   # skip files larger than ~1.5 MB
_BINARY_SNIFF = 4096


# ── Redaction ─────────────────────────────────────────────────────────────────
def redact(secret: str, keep_head: int = 4, keep_tail: int = 2) -> str:
    s = secret.strip()
    if len(s) <= keep_head + keep_tail:
        return "•" * len(s)
    return f"{s[:keep_head]}{'•' * max(4, len(s) - keep_head - keep_tail)}{s[-keep_tail:]}"


def _looks_like_example(text: str) -> bool:
    up = text.upper()
    return any(m.upper() in up for m in _EXAMPLE_MARKERS)


# ── git-secrets bootstrap (auto-download) ─────────────────────────────────────
def ensure_git_secrets(log: Optional[Callable[[str], None]] = None) -> dict:
    """Best-effort download of the real git-secrets script into the cache.

    Returns a status dict: {available, method, path, has_git, has_bash, note}.
    Scanning never depends on this succeeding — the built-in engine always runs.
    """
    global _GIT_SECRETS_STATUS  # single declaration at the top; must precede all assignments
    status: dict[str, Any] = {
        "available": False, "method": "builtin", "path": None,
        "has_git": bool(shutil.which("git")),
        "has_bash": bool(shutil.which("bash")) or IS_MAC or IS_LINUX,
        "note": "",
    }
    target = _cache_dir() / "git-secrets"

    if target.exists() and target.stat().st_size > 1000:
        status.update(available=True, method="git-secrets", path=str(target),
                      note="cached")
        _log(log, f"[secrets] git-secrets ready (cached): {target}")
        _GIT_SECRETS_STATUS = status
        return status

    _log(log, "[secrets] downloading git-secrets from GitHub…")
    try:
        import urllib.request
        req = urllib.request.Request(
            GIT_SECRETS_RAW_URL,
            headers={"User-Agent": "vuln-scanner/1.0"})
        with urllib.request.urlopen(req, timeout=25) as resp:  # nosec - fixed URL
            data = resp.read()
        if not data or len(data) < 1000:
            raise ValueError("downloaded script looks empty")
        target.write_bytes(data)
        if not IS_WIN:
            try: os.chmod(target, 0o755)
            except Exception: pass
        status.update(available=True, method="git-secrets", path=str(target),
                      note="downloaded")
        _log(log, f"[secrets] git-secrets downloaded → {target} "
                  f"({len(data)//1024} KB)")
    except Exception as e:
        status["note"] = f"download failed: {e!r} — using built-in engine"
        _log(log, f"[secrets] git-secrets download failed ({e!r}); "
                  f"built-in engine will be used.")
    _GIT_SECRETS_STATUS = status
    return status


# ── Real git-secrets execution (optional, when environment allows) ────────────
def _run_git_secrets(script: Path, target: Path,
                     log: Optional[Callable[[str], None]] = None) -> list[dict]:
    """Try to run the downloaded git-secrets against a git repo.

    Returns findings or [] on any problem. Heavily defensive: this is a bonus
    layer on top of the always-on built-in engine.
    """
    if not (target / ".git").exists():
        return []
    git = shutil.which("git")
    if not git:
        return []
    bash = shutil.which("bash")
    # Register AWS provider into an isolated config, then scan the repo.
    findings: list[dict] = []
    try:
        env = os.environ.copy()
        tmp_cfg = _cache_dir() / "gs_global.gitconfig"
        env["GIT_CONFIG_GLOBAL"] = str(tmp_cfg)        # git ≥ 2.32
        env["GIT_CONFIG_NOSYSTEM"] = "1"
        runner = [bash, str(script)] if bash else [str(script)]
        # --register-aws loads the canonical AWS patterns into the global config.
        subprocess.run(runner + ["--register-aws", "--global"],
                       cwd=str(target), env=env, timeout=60,
                       capture_output=True, text=True)
        proc = subprocess.run(runner + ["--scan", "-r", "."],
                              cwd=str(target), env=env, timeout=300,
                              capture_output=True, text=True)
        # git-secrets prints "path:line:matched-text" to stderr on a hit.
        out = (proc.stderr or "") + "\n" + (proc.stdout or "")
        for line in out.splitlines():
            m = re.match(r"^(.*?):(\d+):(.*)$", line)
            if not m:
                continue
            fp, ln, txt = m.group(1), int(m.group(2)), m.group(3)
            if "Possible mistakes" in txt or not txt.strip():
                continue
            sev = "low" if _looks_like_example(txt) else "critical"
            findings.append({
                "file": fp, "line": ln, "severity": sev,
                "rule": "git-secrets/aws", "title": "AWS credential (git-secrets)",
                "secret_type": "AWS credential", "match": redact(txt.strip()),
                "engine": "git-secrets",
            })
    except Exception as e:
        _log(log, f"[secrets] git-secrets run skipped: {e!r}")
        return []
    if findings:
        _log(log, f"[secrets] git-secrets reported {len(findings)} hit(s).")
    return findings


# ── Built-in cross-platform engine ────────────────────────────────────────────
def _is_binary(path: Path) -> bool:
    try:
        with open(path, "rb") as fh:
            chunk = fh.read(_BINARY_SNIFF)
        return b"\x00" in chunk
    except Exception:
        return True


def _iter_files(root: Path):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in _SKIP_DIRS
                       and not d.startswith(".") or d in (".github",)]
        for name in filenames:
            ext = os.path.splitext(name)[1].lower()
            if ext in _SKIP_EXT:
                continue
            yield Path(dirpath) / name


def _scan_builtin(target: Path, log: Optional[Callable[[str], None]] = None,
                  cancel=None) -> tuple[list[dict], int]:
    findings: list[dict] = []
    scanned = 0
    seen: set[tuple] = set()
    for fp in _iter_files(target):
        if cancel is not None and getattr(cancel, "is_set", lambda: False)():
            _log(log, "[secrets] scan cancelled.")
            break
        try:
            if fp.stat().st_size > _MAX_BYTES or _is_binary(fp):
                continue
            text = fp.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        scanned += 1
        rel = str(fp.relative_to(target)) if _is_relative(fp, target) else str(fp)
        for lineno, line in enumerate(text.splitlines(), start=1):
            if len(line) > 4000:
                continue
            for rule, stype, sev, rx in _PROVIDERS:
                m = rx.search(line)
                if not m:
                    continue
                raw = m.group(m.lastindex) if m.lastindex else m.group(0)
                eff_sev = "low" if _looks_like_example(raw) else sev
                key = (rel, lineno, rule, raw[:12])
                if key in seen:
                    continue
                seen.add(key)
                findings.append({
                    "file": rel, "line": lineno, "severity": eff_sev,
                    "rule": rule, "title": stype, "secret_type": stype,
                    "match": redact(raw),
                    "context": redact_line(line, raw),
                    "engine": "builtin",
                })
    return findings, scanned


def _is_relative(p: Path, root: Path) -> bool:
    try:
        p.relative_to(root); return True
    except Exception:
        return False


def redact_line(line: str, secret: str) -> str:
    snippet = line.strip()
    if len(snippet) > 160:
        idx = snippet.find(secret.strip())
        if idx >= 0:
            start = max(0, idx - 40)
            snippet = ("…" if start else "") + snippet[start:idx + len(secret) + 40] + "…"
        else:
            snippet = snippet[:160] + "…"
    try:
        snippet = snippet.replace(secret.strip(), redact(secret))
    except Exception:
        pass
    return snippet


# ── Public scan entry point ───────────────────────────────────────────────────
def scan_path(target, log: Optional[Callable[[str], None]] = None, *,
              cancel=None, git_secrets_status: Optional[dict] = None) -> dict:
    target = Path(target).resolve()
    _log(log, f"[secrets] scanning {target}")
    t0 = time.time()
    findings: list[dict] = []

    # Bonus layer: real git-secrets if available and target is a repo.
    gss = git_secrets_status or {}
    script = gss.get("path")
    if script and Path(script).exists():
        try:
            findings.extend(_run_git_secrets(Path(script), target, log))
        except Exception as e:
            _log(log, f"[secrets] git-secrets layer error: {e!r}")

    # Always-on built-in engine.
    builtin, scanned = _scan_builtin(target, log, cancel=cancel)

    # Merge (avoid double counting same file/line/rule).
    seen = {(f["file"], f["line"], f["rule"]) for f in findings}
    for f in builtin:
        if (f["file"], f["line"], f["rule"]) not in seen:
            findings.append(f)

    findings.sort(key=lambda x: (SEVERITY_ORDER.get(x["severity"], 99),
                                 x["file"], x["line"]))
    counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}
    for f in findings:
        counts[f["severity"]] = counts.get(f["severity"], 0) + 1

    dt = time.time() - t0
    engine = "git-secrets + built-in" if (script and Path(script).exists()) else "built-in"
    _log(log, f"[secrets] done — {len(findings)} finding(s) across "
              f"{scanned} file(s) in {dt:.1f}s")
    return {
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "target": str(target), "engine": engine,
        "scanned_files": scanned, "elapsed": round(dt, 2),
        "counts": counts, "total": len(findings), "findings": findings,
    }


# ── Separate report file (HTML + JSON) ────────────────────────────────────────
_SECRETS_HTML = r"""<!doctype html><html lang="en"><head><meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Secrets Report — {generated_at}</title><style>
:root{{--bg:#0d1b2a;--panel:#13243a;--bd:#21364f;--tx:#e8eef7;--mu:#90a4bd;
--ac:#F5A800;--crit:#ff5d6c;--high:#ff944d;--med:#ffd23f;--low:#5fe0a0}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--tx);
font:14px/1.55 -apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif}}
.shell{{max-width:1280px;margin:0 auto;padding:30px clamp(16px,4vw,48px) 80px}}
.top{{display:flex;align-items:center;gap:14px;margin-bottom:22px;flex-wrap:wrap}}
.logo{{width:42px;height:42px;border-radius:11px;background:var(--ac);color:#111;
display:grid;place-items:center;font-weight:800;font-size:20px}}
h1{{margin:0;font-size:22px}}.sub{{color:var(--mu);font-size:12px}}
.pill{{margin-left:auto;display:flex;gap:8px;flex-wrap:wrap}}
.tag{{background:var(--panel);border:1px solid var(--bd);border-radius:999px;
padding:6px 12px;font-size:12px;color:var(--mu)}}.tag b{{color:var(--tx)}}
.kpis{{display:grid;grid-template-columns:repeat(5,1fr);gap:12px;margin:8px 0 26px}}
@media(max-width:760px){{.kpis{{grid-template-columns:repeat(2,1fr)}}}}
.kpi{{background:var(--panel);border:1px solid var(--bd);border-left:4px solid var(--ac);
border-radius:12px;padding:16px}}.kpi .l{{color:var(--mu);font-size:11px;
text-transform:uppercase;letter-spacing:.1em}}.kpi .v{{font-size:30px;font-weight:800;margin-top:6px}}
.kpi.critical{{border-left-color:var(--crit)}}.kpi.high{{border-left-color:var(--high)}}
.kpi.medium{{border-left-color:var(--med)}}.kpi.low{{border-left-color:var(--low)}}
table{{width:100%;border-collapse:collapse;background:var(--panel);
border:1px solid var(--bd);border-radius:12px;overflow:hidden;font-size:13px}}
th{{text-align:left;color:var(--mu);font-size:11px;text-transform:uppercase;
letter-spacing:.07em;padding:12px 14px;border-bottom:1px solid var(--bd)}}
td{{padding:11px 14px;border-bottom:1px solid var(--bd);vertical-align:top}}
tr:last-child td{{border-bottom:0}}tr:hover td{{background:#16294250}}
code{{font-family:ui-monospace,Menlo,Consolas,monospace;background:#0b1626;
border:1px solid var(--bd);border-radius:6px;padding:1px 6px;font-size:12px}}
.sev{{display:inline-block;padding:3px 10px;border-radius:999px;font-size:11px;
font-weight:800;text-transform:uppercase}}
.sev.critical{{background:#ff5d6c22;color:var(--crit)}}.sev.high{{background:#ff944d22;color:var(--high)}}
.sev.medium{{background:#ffd23f22;color:var(--med)}}.sev.low{{background:#5fe0a022;color:var(--low)}}
.empty{{text-align:center;padding:48px;color:var(--mu);background:var(--panel);
border:1px dashed var(--bd);border-radius:12px}}
.note{{margin:18px 0;color:var(--mu);font-size:12px}}
footer{{text-align:center;color:var(--mu);font-size:12px;padding:34px 0 0}}
</style></head><body><div class="shell">
<div class="top"><div class="logo">🔑</div>
<div><h1>Secrets Report</h1><div class="sub">git-secrets · hard-coded credential scan</div></div>
<div class="pill"><span class="tag">Engine <b>{engine}</b></span>
<span class="tag">Target <b>{target}</b></span>
<span class="tag">Files <b>{scanned_files}</b></span>
<span class="tag">Generated <b>{generated_at}</b></span></div></div>
<div class="kpis">
<div class="kpi"><div class="l">Total</div><div class="v">{total}</div></div>
<div class="kpi critical"><div class="l">Critical</div><div class="v">{c_critical}</div></div>
<div class="kpi high"><div class="l">High</div><div class="v">{c_high}</div></div>
<div class="kpi medium"><div class="l">Medium</div><div class="v">{c_medium}</div></div>
<div class="kpi low"><div class="l">Low</div><div class="v">{c_low}</div></div>
</div>
{body}
<p class="note">Matched secrets are redacted. Treat any flagged credential as
compromised: rotate it and purge it from version-control history.</p>
<footer>Vulnerability Scanner · Secrets module · {generated_at}</footer>
</div></body></html>"""


def render_secrets_html(result: dict) -> str:
    import html as _html
    findings = result.get("findings", [])
    if findings:
        rows = []
        for f in findings:
            rows.append(
                "<tr>"
                f"<td><span class='sev {f['severity']}'>{f['severity']}</span></td>"
                f"<td>{_html.escape(f.get('secret_type', f.get('rule','')))}</td>"
                f"<td><code>{_html.escape(str(f['file']))}</code></td>"
                f"<td>{f.get('line','?')}</td>"
                f"<td><code>{_html.escape(str(f.get('match','')))}</code></td>"
                f"<td><code>{_html.escape(str(f.get('engine','')))}</code></td>"
                "</tr>")
        body = ("<table><thead><tr><th>Severity</th><th>Type</th><th>File</th>"
                "<th>Line</th><th>Secret (redacted)</th><th>Engine</th></tr></thead>"
                "<tbody>" + "".join(rows) + "</tbody></table>")
    else:
        body = ("<div class='empty'>No hard-coded secrets detected. "
                "Nothing to rotate — nice.</div>")
    counts = result.get("counts", {})
    return _SECRETS_HTML.format(
        generated_at=result.get("generated_at", ""),
        engine=result.get("engine", ""),
        target=_safe(result.get("target", "")),
        scanned_files=result.get("scanned_files", 0),
        total=result.get("total", 0),
        c_critical=counts.get("critical", 0), c_high=counts.get("high", 0),
        c_medium=counts.get("medium", 0), c_low=counts.get("low", 0),
        body=body)


def _safe(s: str) -> str:
    import html as _html
    return _html.escape(str(s))


def write_secrets_report(result: dict, out_dir) -> Path:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "secrets.json").write_text(
        json.dumps(result, indent=2), encoding="utf-8")
    html_path = out_dir / "secrets.html"
    html_path.write_text(render_secrets_html(result), encoding="utf-8")
    return html_path


# Allow quick manual testing: python secrets_scanner.py <folder>


# ── CLI smoke test: python static_scanner.py <folder> ─────────────────────────
if __name__ == "__main__":
    tgt = sys.argv[1] if len(sys.argv) > 1 else "."
    st = ensure_git_secrets(print)
    res = scan_path(tgt, print, git_secrets_status=st)
    out = write_secrets_report(res, Path(tgt) / "_secrets_out")
    print("secrets report:", out)

