from __future__ import annotations

# Stage A: bootstrap. Heavy deps are installed at runtime against a live splash
# (see BootSplash / run_boot), then the engine modules are imported.
import os, sys, shutil, subprocess
from pathlib import Path

IS_WIN   = os.name == "nt"
IS_MAC   = sys.platform == "darwin"
IS_LINUX = not IS_WIN and not IS_MAC



def _pip(args: list[str], log=None) -> None:
    """pip install --user, streaming output lines to `log`."""
    cmd = [sys.executable, "-m", "pip", "install", "--user",
           "--disable-pip-version-check"] + args

    def _stream(command, env=None):
        proc = subprocess.Popen(command, env=env, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, text=True,
                                encoding="utf-8", errors="replace", bufsize=1)
        for line in iter(proc.stdout.readline, ""):
            line = line.rstrip()
            if line and log:
                try: log(line)
                except Exception: pass
        proc.stdout.close()
        return proc.wait()

    if _stream(cmd) != 0:
        env = os.environ.copy()
        env["PIP_TRUSTED_HOST"] = "pypi.org files.pythonhosted.org pypi.python.org"
        hosts = ["--trusted-host", "pypi.org", "--trusted-host",
                 "files.pythonhosted.org", "--trusted-host", "pypi.python.org"]
        if log: log("pip: retrying via trusted-host (corporate TLS proxy?)")
        if _stream(cmd + hosts, env=env) != 0:
            raise subprocess.CalledProcessError(1, cmd)
    import site
    us = site.getusersitepackages()
    if us not in sys.path:
        sys.path.insert(0, us)


def _ensure(import_name: str, pip_name: str | None = None, log=None) -> None:
    pip_name = pip_name or import_name

    def _drop():
        for m in list(sys.modules):
            if (m == import_name or m.startswith(import_name + ".")
                    or m == "markupsafe" or m.startswith("markupsafe.")):
                sys.modules.pop(m, None)

    for attempt in range(2):
        try:
            __import__(import_name)
            if log: log(f"{import_name}: already satisfied")
            return
        except ImportError as e:
            msg = str(e).lower()
            if log: log(f"{import_name}: not found — installing {pip_name}…")
            if import_name == "jinja2" and ("soft_unicode" in msg or "markupsafe" in msg):
                _pip(["--upgrade", "--force-reinstall", "Jinja2>=3.1", "MarkupSafe>=2.1"], log=log)
            elif attempt == 0:
                _pip(["--upgrade", pip_name], log=log)
            else:
                _pip(["--upgrade", "--force-reinstall", pip_name], log=log)
            _drop()
    __import__(import_name)


# NOTE: Snyk CLI installation used to be duplicated here (a GitHub-release
# binary downloader) *and* in static_scanner.install_snyk() (npm/brew/winget/
# standalone-binary). Consolidated: static_scanner.install_snyk() is now the
# single installer, called from _load_runtime() below (boot) and reused by
# ScannerApp._fix() (re-runs the whole boot splash instead of installing
# inline), so every dependency install — pip packages, Node/npm, git-secrets,
# Snyk CLI — always happens in the one BootSplash window (the globe splash).


# Splash steps: (import_name, pip_name, human label)
_BOOT_DEPS = [
    ("jinja2",            "Jinja2",            "Report templating engine"),
    ("selenium",          "selenium",          "Browser automation (DAST)"),
    ("webdriver_manager", "webdriver-manager", "WebDriver downloader"),
    ("pynput",            "pynput",            "Global hotkey listener (recorder)"),
    ("yaml",              "PyYAML",            "OpenAPI/Swagger YAML spec parsing"),
    ("requests",          "requests",          "HTTP client"),
]
_RUNTIME_READY = False


def _load_runtime(progress=None) -> None:
    """Ensure heavy deps + Node.js/npm + git-secrets + snyk CLI, then import engine
    modules into this module's namespace. `progress(kind, payload)` callback is optional.

    Every line logged during this boot is also mirrored to a plain-text log file
    next to this script (``boot_dependencies.log``), overwritten on every launch,
    so dependency-install problems can be diagnosed after the splash closes."""
    global _RUNTIME_READY

    _log_lines: list[str] = []
    _boot_started = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    _boot_log_path = SCRIPT_DIR / "boot_dependencies.log"

    def _log(text):
        stamp = datetime.now().strftime("%H:%M:%S")
        _log_lines.append(f"[{stamp}] {text}")
        if progress:
            try: progress("log", text)
            except Exception: pass

    def _flush_log(status: str = "in progress"):
        try:
            header = (f"{APP_BRAND_NAME} — dependency boot log\n"
                      f"Run started : {_boot_started}\n"
                      f"Status      : {status}\n" + ("-" * 60) + "\n")
            _boot_log_path.write_text(header + "\n".join(_log_lines) + "\n", encoding="utf-8")
        except Exception:
            pass  # logging the boot must never crash the boot itself

    _flush_log()
    try:
        total = len(_BOOT_DEPS) + 4
        step = 0
        for import_name, pip_name, label in _BOOT_DEPS:
            step += 1
            if progress: progress("step", (step, total, f"{label} ({import_name})"))
            _ensure(import_name, pip_name, log=_log)
            _flush_log()

        step += 1
        if progress: progress("step", (step, total, "Node.js + npm (JS runtime)"))
        try:
            import static_scanner
            if static_scanner.check_node().ok and static_scanner.check_npm().ok:
                _log("node/npm: already satisfied")
            else:
                static_scanner.install_node(log=_log)
        except Exception as e:
            _log(f"node/npm: bootstrap skipped — {e!r}")
        _flush_log()

        step += 1
        if progress: progress("step", (step, total, "git-secrets (secret scanner)"))
        try:
            import static_scanner
            static_scanner.ensure_git_secrets(log=_log)
        except Exception as e:
            _log(f"secrets: git-secrets bootstrap skipped — {e!r}")
        _flush_log()

        step += 1
        if progress: progress("step", (step, total, "Snyk CLI (vulnerability scanner)"))
        try:
            import static_scanner
            if static_scanner.check_snyk().ok:
                _log("snyk-cli: already satisfied")
            else:
                static_scanner.install_snyk(log=_log)
        except Exception as e:
            _log(f"snyk-cli: bootstrap skipped — {e!r}")
        _flush_log()

        step += 1
        if progress: progress("step", (step, total, "Loading scanner engine…"))
        g = globals()
        # SCA + SAST + Secrets now live in one fused module (static_scanner).
        import static_scanner as _ss
        for n in ("CheckResult", "check_python", "check_node", "check_npm",
                  "check_snyk", "check_auth", "install_node", "install_snyk",
                  "start_snyk_auth", "run_snyk_test", "run_snyk_code",
                  "clear_snyk_credentials",
                  "SnykScanError", "ensure_snyk_ready", "setup_proxy_tls_env",
                  "export_sarif", "export_merged_json",
                  "scan_path", "write_secrets_report", "ensure_git_secrets",
                  "get_git_secrets_status", "get_engine_label"):
            g[n] = getattr(_ss, n)
        g["static_scanner"] = _ss
        g["secrets_scanner"] = _ss  # backward-compat alias
        import dast_api as _dast
        for n in ("DastConfig", "ApiConfig", "run_dast", "run_api", "_make_driver",
                  "_MACRO_JS", "_MACRO_DRAIN_JS", "_LOGOUT_CAPTURE_JS", "detect_browsers",
                  "_replay_login_macro", "analyze_login_macro",
                  "record_macro_work", "record_logout_work", "test_logout_work",
                  "_api_load_spec", "_api_base_url", "_api_operations", "_make_opener"):
            g[n] = getattr(_dast, n)
        import report_engine as _rep
        for n in ("build_cumulative_context", "export_csv", "render_html",
                  "update_history_after_scan", "render_remediation_history",
                  "add_remediation_action", "load_history", "ScanStateStore"):
            g[n] = getattr(_rep, n)
        _RUNTIME_READY = True
        _log("Runtime ready.")
        _flush_log("completed successfully")
    except Exception as e:
        _log(f"FATAL: {e!r}")
        _flush_log("failed")
        raise


# Stage B: regular imports (stdlib + tkinter, always available).
import json, queue, getpass, re as _re, threading, time, webbrowser
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from typing import Any, Callable, Optional

import tkinter as tk
from tkinter import ttk, messagebox, filedialog


def _open_path(path) -> None:
    """Open a folder/file with the OS default handler."""
    p = str(path)
    try:
        if IS_WIN:    os.startfile(p)  # type: ignore[attr-defined]
        elif IS_MAC:  subprocess.Popen(["open", p])
        else:         subprocess.Popen(["xdg-open", p])
    except Exception:
        try: webbrowser.open(Path(p).as_uri())
        except Exception: pass


def _detect_user() -> str:
    """Best-effort current-user detection (whoami-style)."""
    for getter in (lambda: getpass.getuser(),
                   lambda: os.environ.get("USER") or os.environ.get("USERNAME") or os.environ.get("LOGNAME")):
        try:
            name = getter()
            if name: return str(name)
        except Exception:
            pass
    try:
        out = subprocess.run(["whoami"], capture_output=True, text=True, timeout=4)
        name = (out.stdout or "").strip()
        if name: return name.split("\\")[-1]
    except Exception:
        pass
    return "user"


# Constants
SCRIPT_DIR         = Path(__file__).resolve().parent
APP_BRAND_NAME      = "SecDevOps Banco Base"
DEFAULT_TARGET     = SCRIPT_DIR / "Vulnerable"
DEFAULT_REPORTS    = SCRIPT_DIR / "Reports"
SETTINGS_FILE      = SCRIPT_DIR / ".scanner_settings.json"
AUTH_POLL_INTERVAL = 2
AUTH_POLL_TIMEOUT  = 300

# Fonts (platform-aware)
if IS_MAC:     _FUI, _FMONO = "SF Pro Text", "Menlo"
elif IS_LINUX: _FUI, _FMONO = "DejaVu Sans", "DejaVu Sans Mono"
else:          _FUI, _FMONO = "Segoe UI", "Cascadia Mono"

# Palette (Banco Base)
_PALETTE_LIGHT = {
    "bg":        "#f5f6f8", "panel_bg":  "#ffffff", "surface2":  "#eef1f7",
    "accent":    "#F5A800", "accent_hi": "#c48700", "button_fg": "#ffffff",
    "accent2":   "#c8102e", "accent2_hi":"#a00d24",
    "text":      "#0d1b2a", "muted":     "#5a6475", "border":    "#dde2ec",
    "ok":        "#1a7a4a", "err":       "#c8102e", "card_hover":"#eef1f7",
    "pill_run_bg":"#002060","pill_run_fg":"#c0ccee",
    "pill_ok_bg": "#0c4a2b","pill_ok_fg": "#a7f0c8",
    "pill_bad_bg":"#7a0c1c","pill_bad_fg":"#fdb8c0",
    "pill_idle_bg":"#dde2ec","pill_idle_fg":"#5a6475",
}
_PALETTE_DARK = {
    "bg":        "#1a1d23", "panel_bg":  "#23272e", "surface2":  "#2c3038",
    "accent":    "#F5A800", "accent_hi": "#c48700", "button_fg": "#ffffff",
    "accent2":   "#c8102e", "accent2_hi":"#a00d24",
    "text":      "#e8eaf0", "muted":     "#8892a4", "border":    "#383d48",
    "ok":        "#2ecc71", "err":       "#e74c3c", "card_hover":"#2c3038",
    "pill_run_bg":"#0a1840","pill_run_fg":"#7a9cee",
    "pill_ok_bg": "#0a3020","pill_ok_fg": "#5fe0a0",
    "pill_bad_bg":"#4a0a10","pill_bad_fg":"#f08090",
    "pill_idle_bg":"#383d48","pill_idle_fg":"#8892a4",
}
T = dict(_PALETTE_LIGHT)
T["highlight"] = T["accent"]; T["highlight_text"] = T["button_fg"]
T["tree_bg"] = T["panel_bg"]; T["button_hover"] = T["accent_hi"]

_SEV_RANK = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}


def _sev_norm(s) -> str:
    s = (str(s) if s is not None else "").strip().lower()
    if s in ("critical", "crit"):          return "critical"
    if s == "high":                        return "high"
    if s in ("medium", "med", "moderate"): return "medium"
    if s == "low":                         return "low"
    return "info"


def _which(cmd: str) -> Optional[str]:
    if (f := shutil.which(cmd)):
        return f
    if os.name == "nt":
        for ext in (".cmd", ".bat", ".exe"):
            if (f := shutil.which(cmd + ext)):
                return f
    return None


def _run(args, cwd=None, env=None, timeout=600) -> subprocess.CompletedProcess:
    return subprocess.run(args, cwd=str(cwd) if cwd else None,
                          env=env if env is not None else os.environ.copy(),
                          timeout=timeout, capture_output=True, text=True,
                          encoding="utf-8", errors="replace", shell=False)


def _ts() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def _report_basename(user: str, mode: str) -> str:
    """Build the report file base name: '<service>+<user>_<YYYYMMDD>'.
    `mode` is the scan-type/service combination (e.g. 'secrets' or 'code+sca')."""
    date = datetime.now().strftime("%Y%m%d")
    raw = f"{mode}+{user}_{date}"
    return _re.sub(r"[^A-Za-z0-9+\-_]", "_", raw)


def _find_report_html(d) -> Optional[Path]:
    """Return the main HTML report inside a report folder, supporting both the
    new '<service>+<user>_<date>.html' naming and the legacy 'report.html'."""
    d = Path(d)
    if not d.is_dir():
        return None
    legacy = d / "report.html"
    if legacy.exists():
        return legacy
    cands = [p for p in d.glob("*.html")
             if p.name != "remediation_history.html" and not p.name.endswith("_secrets.html")]
    if cands:
        return max(cands, key=lambda p: p.stat().st_mtime)
    return None


# Theme role maps (old colour -> palette role) used by _recolour_widget.
_ROLE_BG = {_PALETTE_LIGHT[k]: k for k in ("bg", "panel_bg", "surface2")}
_ROLE_BG.update({_PALETTE_DARK[k]: k for k in ("bg", "panel_bg", "surface2")})
_ROLE_FG = {_PALETTE_LIGHT[k]: k for k in ("text", "muted", "ok")}
_ROLE_FG.update({_PALETTE_DARK[k]: k for k in ("text", "muted", "ok")})
_ROLE_BTN_BG = {_PALETTE_LIGHT[k]: k for k in ("panel_bg", "surface2")}
_ROLE_BTN_BG.update({_PALETTE_DARK[k]: k for k in ("panel_bg", "surface2")})
_ROLE_ACCENT = {_PALETTE_LIGHT[k]: k for k in ("accent", "accent2")}
_ROLE_ACCENT.update({_PALETTE_DARK[k]: k for k in ("accent", "accent2")})
_BORDERS = (_PALETTE_LIGHT["border"], _PALETTE_DARK["border"])


def _apply_palette(dark: bool) -> None:
    T.update(_PALETTE_DARK if dark else _PALETTE_LIGHT)
    T["highlight"] = T["accent"]; T["highlight_text"] = T["button_fg"]
    T["tree_bg"] = T["panel_bg"]; T["button_hover"] = T["accent_hi"]


def _fill_tree_row(tree: "ttk.Treeview", d: Path, app: Optional[str] = None) -> None:
    meta: dict = {}
    mf = d / "meta.json"
    if mf.exists():
        try: meta = json.loads(mf.read_text(encoding="utf-8"))
        except Exception: pass
    counts = meta.get("counts") or {}
    vals = (
        meta.get("generated_at") or d.name.replace("report_", ""),
        meta.get("mode", "?"), meta.get("total", "?"),
        counts.get("critical", "?"), counts.get("high", "?"),
        counts.get("medium", "?"), counts.get("low", "?"), meta.get("target", ""))
    if app is not None:
        vals = (app,) + vals
    tree.insert("", "end", iid=str(d), values=vals)


def _make_tree(parent, cols, headings, height) -> "ttk.Treeview":
    outer = tk.Frame(parent, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["accent"])
    outer.pack(side="left", fill="both", expand=True)
    tk.Frame(outer, bg=T["accent"], height=2).pack(fill="x", side="top")
    tf = tk.Frame(outer, bg=T["panel_bg"]); tf.pack(fill="both", expand=True)
    tree = ttk.Treeview(tf, columns=cols, show="headings", height=height)
    for c, (txt, w) in zip(cols, headings):
        tree.heading(c, text=txt); tree.column(c, width=w, anchor="w")
    tree.pack(side="left", fill="both", expand=True)
    ttk.Scrollbar(tf, command=tree.yview, orient="vertical").pack(side="right", fill="y")
    return tree


def _tree_selected_dir(tree: "ttk.Treeview") -> Optional[Path]:
    """Report folder currently selected in a reports Treeview (used by both
    the Recent Scans card and the ReportsViewer popup)."""
    sel = tree.selection()
    return Path(sel[0]) if sel else None


def _delete_selected_report(app, tree: "ttk.Treeview", *on_done: Callable[[], None]) -> None:
    """Delete the report folder selected in `tree`, then run `on_done`
    refresh callbacks. Shared by the Recent Scans card and ReportsViewer so
    both keep one copy of the delete + error-handling behaviour."""
    d = _tree_selected_dir(tree)
    if not d: return
    try:
        shutil.rmtree(d)
    except Exception as e:
        app._show_error_popup("Delete", f"Failed:\n{e}"); return
    for cb in on_done: cb()


def _open_selected_report_folder(app, tree: "ttk.Treeview") -> None:
    """Open the folder of the report selected in `tree` (never the reports
    root) — shared by the Recent Scans card and ReportsViewer."""
    d = _tree_selected_dir(tree)
    if not d:
        app._show_info_popup("Open Folder", "Select a report first."); return
    _open_path(d)


def _center_over(master, win, w_pct: float, h_pct: float) -> None:
    """Size and centre *win* using percentages of the screen."""
    master.update_idletasks()
    sw, sh = master.winfo_screenwidth(), master.winfo_screenheight()
    w, h = int(sw * w_pct), int(sh * h_pct)
    win.geometry(f"{w}x{h}+{(sw - w) // 2}+{(sh - h) // 2}")


def _popup_follow_parent(win: tk.Toplevel, parent: tk.Misc) -> dict:
    """Keep an overrideredirect popup above *parent* across alt-tab cycles.
    On Windows, re-establish the Win32 owner that overrideredirect drops; on all
    platforms, lift on focus and withdraw/restore with the parent. Returns the
    {event: bind_id} map for cleanup."""
    if IS_WIN:
        try:
            import ctypes
            win.update_idletasks()
            child_hwnd  = int(win.wm_frame(), 16)
            parent_hwnd = int(parent.wm_frame(), 16)
            ctypes.windll.user32.SetWindowLongPtrW(child_hwnd, -8, parent_hwnd)
        except Exception:
            pass

    def _on_focus(e):
        if win.winfo_exists():
            try: win.lift()
            except Exception: pass

    def _on_unmap(e):
        if e.widget is parent and win.winfo_exists():
            try: win.withdraw()
            except Exception: pass

    def _on_map(e):
        if e.widget is parent and win.winfo_exists():
            try: win.deiconify(); win.lift()
            except Exception: pass

    return {"<FocusIn>": parent.bind("<FocusIn>", _on_focus, "+"),
            "<Unmap>":   parent.bind("<Unmap>",   _on_unmap, "+"),
            "<Map>":     parent.bind("<Map>",      _on_map,   "+")}


def _themed_btn(parent, text, cmd, *, font, bg, fg, hover_bg, hover_fg, **kw):
    """A flat hand2 tk.Button used by ReportsViewer header/footer rows."""
    return tk.Button(parent, text=text, command=cmd, bg=bg, fg=fg,
                     activebackground=hover_bg, activeforeground=hover_fg,
                     font=font, relief="flat", cursor="hand2", bd=0, **kw)


class ReportsViewer(tk.Toplevel):
    def __init__(self, master, root_path: Path):
        super().__init__(master)
        self._root_path = root_path
        self._app = master
        self.transient(master)
        _center_over(master, self, 0.75, 0.75)
        self.overrideredirect(True)
        self.update_idletasks(); self.lift(); self.focus_force()
        try: self.grab_set()
        except tk.TclError: pass
        _bind_ids: dict = {}

        def _close():
            try: self.grab_release()
            except Exception: pass
            for evt, bid in _bind_ids.items():
                try: master.unbind(evt, bid)
                except Exception: pass
            self.destroy()
            try: master.focus_force()
            except Exception: pass

        self.bind("<Escape>", lambda e: _close())
        _bind_ids.update(_popup_follow_parent(self, master))
        border = tk.Frame(self, bg=T["accent"], padx=2, pady=2); border.pack(fill="both", expand=True)
        content = tk.Frame(border, bg=T["bg"]); content.pack(fill="both", expand=True)

        hb = T["panel_bg"]
        hdr = tk.Frame(content, bg=hb, padx=30, pady=14); hdr.pack(fill="x")
        row = tk.Frame(hdr, bg=hb); row.pack(fill="x")
        xbtn = tk.Label(row, text="✕", font=(_FUI, 13, "bold"), bg=hb, fg=T["muted"], cursor="hand2", padx=6)
        xbtn.pack(side="right")
        xbtn.bind("<Button-1>", lambda e: _close())
        xbtn.bind("<Enter>", lambda e: xbtn.config(fg=T["err"]))
        xbtn.bind("<Leave>", lambda e: xbtn.config(fg=T["muted"]))
        tk.Label(row, text="📋  Report History", font=(_FUI, 15, "bold"), bg=hb, fg=T["accent"]).pack(side="left")
        tk.Label(row, text=str(root_path), font=(_FUI, 10, "italic"), bg=hb, fg=T["muted"]).pack(side="left", padx=(12, 0))
        tk.Frame(content, bg=T["border"], height=1).pack(fill="x")

        tree_wrap = tk.Frame(content, bg=T["bg"]); tree_wrap.pack(fill="both", expand=True, padx=18, pady=(14, 6))
        cols = ("app", "when", "mode", "total", "critical", "high", "medium", "low", "target")
        self._tree = _make_tree(tree_wrap, cols, [
            ("App", 130), ("Generated", 150), ("Mode", 80), ("Total", 55), ("Crit", 45),
            ("High", 45), ("Med", 45), ("Low", 45), ("Target", 300)], height=16)
        self._tree.bind("<Double-1>", lambda _: self._open_html())

        tk.Frame(content, bg=T["border"], height=1).pack(fill="x")
        foot = tk.Frame(content, bg=T["panel_bg"], padx=20, pady=10); foot.pack(fill="x")
        self._app._btn(foot, "✕  Close", _close, kind="accent").pack(side="right", padx=(6, 0))
        for txt, cmd in [("🗑 Delete", self._delete), ("🧬 Export SARIF…", self._export_sarif),
                         ("💾 Export CSV…", self._export_csv), ("📁 Open folder", self._open_selected),
                         ("▶ Open HTML", self._open_html)]:
            self._app._btn(foot, txt, cmd, kind="flat").pack(side="left", padx=(0, 6))
        self._refresh()

    def _scan_dirs(self) -> list[tuple[Path, dict, str]]:
        """Collect report folders across every app profile under the root.
        Report folders live at <root>/<app>/report_*, with legacy ones possibly
        directly under <root>/report_*. Returns (dir, meta, app_label) tuples
        sorted newest-first."""
        root = self._root_path
        if not root.exists():
            return []
        found: list[tuple[Path, str]] = []
        try:
            entries = sorted(root.iterdir())
        except OSError:
            return []
        for entry in entries:
            if not entry.is_dir():
                continue
            if entry.name.startswith("report_"):
                found.append((entry, "—"))  # legacy report directly under root
                continue
            app_label = "(none)" if entry.name == "_unscoped" else entry.name
            try:
                for d in entry.iterdir():
                    if d.is_dir() and d.name.startswith("report_"):
                        found.append((d, app_label))
            except OSError:
                continue
        found.sort(key=lambda t: t[0].stat().st_mtime, reverse=True)
        out = []
        for d, app_label in found:
            meta: dict = {}
            mf = d / "meta.json"
            if mf.exists():
                try: meta = json.loads(mf.read_text(encoding="utf-8"))
                except Exception: pass
            out.append((d, meta, app_label))
        return out

    def _refresh(self):
        for iid in self._tree.get_children(): self._tree.delete(iid)
        for d, _, app in self._scan_dirs(): _fill_tree_row(self._tree, d, app=app)

    def _sel(self):
        return _tree_selected_dir(self._tree)

    def _open_selected(self):
        _open_selected_report_folder(self._app, self._tree)

    def _open_html(self):
        d = self._sel()
        if not d: return
        html = _find_report_html(d)
        if html: _open_path(html)
        else: self._app._show_warn_popup("Open HTML", f"No HTML report in:\n{d}")

    def _export_csv(self):
        d = self._sel()
        if not d: return
        # New naming is '<service>+<user>_<date>.csv' (+ matching .zip bundle);
        # fall back to the legacy 'findings.csv'. Prefer the richer .zip bundle.
        src = next(iter(sorted(d.glob("*.zip"))), None) \
            or (d / "findings.csv" if (d / "findings.csv").exists() else None) \
            or next(iter(sorted(d.glob("*.csv"))), None)
        if not src or not src.exists():
            self._app._show_warn_popup("Export CSV", f"No CSV/ZIP export in:\n{d}"); return
        ext = src.suffix
        path = filedialog.asksaveasfilename(title="Export CSV", defaultextension=ext,
            initialdir=str(d), initialfile=src.name,
            filetypes=[("ZIP bundle", "*.zip"), ("CSV", "*.csv"), ("All", "*.*")])
        if not path: return
        shutil.copyfile(src, path)
        self._app._show_info_popup("Export CSV", f"Wrote {path}")

    def _export_sarif(self):
        d = self._sel()
        if not d: return
        if not any((d / n).exists() for n in ("snyk_test.json", "snyk_code.json", "dast.json", "api.json")):
            self._app._show_warn_popup("Export SARIF", f"No raw scan output in:\n{d}"); return
        try:
            sarif = export_sarif(d); export_merged_json(d)
        except Exception as e:
            self._app._show_error_popup("Export SARIF", f"Failed:\n{e}"); return
        if not sarif:
            self._app._show_warn_popup("Export SARIF", "Nothing to export — no findings were assembled."); return
        path = filedialog.asksaveasfilename(title="Export SARIF", defaultextension=".sarif",
            initialdir=str(d), initialfile="findings.sarif", filetypes=[("SARIF", "*.sarif *.json"), ("All", "*.*")])
        if not path:
            self._app._show_info_popup("Export SARIF", f"SARIF written in report folder:\n{sarif}"); return
        try:
            shutil.copyfile(sarif, path)
        except Exception as e:
            self._app._show_error_popup("Export SARIF", f"Could not copy:\n{e}"); return
        self._app._show_info_popup("Export SARIF", f"Wrote {path}")

    def _delete(self):
        _delete_selected_report(self._app, self._tree, self._refresh)


class ScannerApp(tk.Tk):
    """SecDevOps Banco Base — Integrated.py look & feel."""

    _CRED_KEYS = [
        "username", "password", "token", "cookie", "header_name", "header_value",
        "login_url", "login_data", "selenium_login_url", "selenium_user_selector",
        "selenium_user_value", "selenium_pass_selector", "selenium_pass_value",
        "selenium_submit_selector", "selenium_extra_steps", "selenium_macro",
        "login_success_selector", "login_success_text", "logout_url_re",
        "selenium_logout_macro",
    ]
    _DAST_AUTH_FIELDS = {
        "auto":     [("username", "Username", False), ("password", "Password", True),
                     ("selenium_login_url", "Login page URL (optional)", False)],
        "none":     [],
        "basic":    [("username", "Username", False), ("password", "Password", True)],
        "bearer":   [("token", "Bearer token", True)],
        "cookie":   [("cookie", "Cookie header value", False)],
        "header":   [("header_name", "Header name", False), ("header_value", "Header value", True)],
        "form":     [("username", "Username", False), ("password", "Password", True),
                     ("login_url", "Login POST URL", False), ("login_data", "POST body", False)],
        "selenium": [("selenium_login_url", "Login page URL", False),
                     ("selenium_user_selector", "Username CSS selector", False),
                     ("selenium_user_value", "Username value", False),
                     ("selenium_pass_selector", "Password CSS selector", False),
                     ("selenium_pass_value", "Password value", True),
                     ("selenium_submit_selector", "Submit CSS selector", False),
                     ("selenium_extra_steps", "Extra steps JSON", False)],
    }
    _SESSION_FIELDS = [
        ("login_success_selector", "Logged-in CSS selector"),
        ("login_success_text",     "Logged-in text marker"),
        ("logout_url_re",          "Logout URL regex"),
    ]
    _LOGIN_CONDITION_KEYS = [
        "selenium_login_url", "selenium_user_selector", "selenium_user_value",
        "selenium_pass_selector", "selenium_submit_selector", "selenium_extra_steps",
        "selenium_macro", "login_success_selector", "login_success_text",
    ]
    _LOGOUT_CONDITION_KEYS = ["logout_url_re", "login_success_selector",
                              "login_success_text", "selenium_logout_macro"]

    def __init__(self):
        super().__init__()
        self.title(APP_BRAND_NAME)
        self.configure(bg=T["bg"])
        self._user = _detect_user()
        try: self.protocol("WM_DELETE_WINDOW", self._on_app_close)
        except Exception: pass
        try:
            if IS_WIN:
                self.state("zoomed")
            elif IS_MAC:
                sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
                self.geometry(f"{sw}x{sh}+0+0")
                try: self.state("zoomed")
                except Exception: pass
            else:
                self.attributes("-zoomed", True)
        except Exception:
            self.geometry("1400x900")

        self.fonts = {
            "title": (_FUI, 28, "bold"), "heading": (_FUI, 18, "bold"),
            "sub": (_FUI, 13, "bold"), "body": (_FUI, 12), "small": (_FUI, 11),
            "caption": (_FUI, 10), "mono": (_FMONO, 11), "tab": (_FUI, 11, "bold"),
            "emoji": (_FUI, 14),
        }
        self._event_queue: queue.Queue = queue.Queue()
        self._auth_proc: Optional[subprocess.Popen] = None
        self._auth_deadline = 0.0
        self._target = DEFAULT_TARGET
        self._reports_root = DEFAULT_REPORTS
        self._last_report: Optional[Path] = None
        self._last_context: Optional[dict] = None
        self._last_report_dir: Optional[Path] = None
        self._last_static_report: Optional[Path] = None
        self._static_busy = False
        self._checks: dict[str, CheckResult] = {}
        self._busy = False
        self._cancel_evt = threading.Event()
        self._console_visible = False
        self._unread_log = 0
        self._active_tab: str = "scan"
        self._inv_tab: Optional[Any] = None
        self._active_app: Optional[dict] = None
        self._last_app_id: Optional[str] = None
        self._dark_mode = False
        self._auto_open = True
        self._max_log_lines = 2000
        self._load_settings()

        from app_inventory import AppInventoryStore
        self._inv_store = AppInventoryStore(self._reports_root)
        from report_engine import ScanStateStore
        self._scan_state = ScanStateStore(self._reports_root)

        self._setup_styles()
        self._build_vars()
        self._build_ui()
        self.after(150, self._drain_events)
        self.after(200, self._auto_load_last_app)
        self.after(300, lambda: self._run_async(self._recheck, label="initial env check"))

    # Settings persistence
    def _load_settings(self):
        if not SETTINGS_FILE.exists(): return
        try: data = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        except Exception: return
        if "dark_mode" in data:
            self._dark_mode = bool(data["dark_mode"]); _apply_palette(self._dark_mode)
        if data.get("reports_root"): self._reports_root = Path(data["reports_root"])
        if "auto_open"     in data: self._auto_open     = bool(data["auto_open"])
        if data.get("last_app_id"): self._last_app_id   = str(data["last_app_id"])

    def _save_settings(self):
        data = {"dark_mode": self._dark_mode, "reports_root": str(self._reports_root),
                "auto_open": self._auto_open,
                "last_app_id": getattr(self, "_last_app_id", None)}
        try: SETTINGS_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
        except Exception as e: self._emit_log(f"[settings] could not save: {e}")

    # Theme
    def _apply_theme_to_app(self):
        _apply_palette(self._dark_mode)
        self._setup_styles()
        self._recolour_widget(self)
        self._recolour_ribbon_tabs()
        for _attr in ("_static_sca_tree", "_static_sast_tree"):
            _t = getattr(self, _attr, None)
            if _t is not None:
                try: self._apply_group_tags(_t)   # ttk tree tags aren't caught by _recolour_widget
                except Exception: pass
        inv_tab = getattr(self, "_inv_tab", None)
        if inv_tab:
            try: inv_tab.apply_theme()
            except Exception:
                try: inv_tab.refresh()
                except Exception: pass

    def _recolour_widget(self, w):
        cls = w.__class__.__name__
        try:
            if cls in ("Frame", "Canvas"):
                role = _ROLE_BG.get(w.cget("bg"))
                if role: w.configure(bg=T[role])
                if cls == "Frame":
                    try:
                        if w.cget("highlightbackground") in _BORDERS:
                            w.configure(highlightbackground=T["border"])
                    except Exception: pass
            elif cls == "Label":
                new_fg = _ROLE_ACCENT.get(w.cget("fg")) or _ROLE_FG.get(w.cget("fg"))
                new_bg = _ROLE_ACCENT.get(w.cget("bg")) or _ROLE_BG.get(w.cget("bg"))
                if new_fg: w.configure(fg=T[new_fg])
                if new_bg: w.configure(bg=T[new_bg])
            elif cls == "Button":
                acc = _ROLE_ACCENT.get(w.cget("bg"))
                if acc:
                    w.configure(bg=T[acc], activebackground=T[acc + "_hi"])
                else:
                    role = _ROLE_BTN_BG.get(w.cget("bg"))
                    if role: w.configure(bg=T[role], activebackground=T["card_hover"])
                new_fg = _ROLE_ACCENT.get(w.cget("fg")) or _ROLE_FG.get(w.cget("fg"))
                if new_fg: w.configure(fg=T[new_fg])
            elif cls == "Radiobutton":
                bg_role = _ROLE_BG.get(w.cget("bg"))
                if bg_role: w.configure(bg=T[bg_role])
                fg_role = _ROLE_FG.get(w.cget("fg"))
                if fg_role: w.configure(fg=T[fg_role])
                w.configure(activebackground=T["card_hover"], selectcolor=T["surface2"])
            elif cls == "Checkbutton":
                bg_role = _ROLE_BG.get(w.cget("bg"))
                if bg_role: w.configure(bg=T[bg_role], activebackground=T["card_hover"])
                fg_role = _ROLE_FG.get(w.cget("fg"))
                if fg_role: w.configure(fg=T[fg_role])
            elif cls == "Text":
                w.configure(bg=T["surface2"], fg=T["text"], insertbackground=T["text"])
            elif cls == "Listbox":
                w.configure(bg=T["surface2"], fg=T["text"],
                            selectbackground=T["accent"], selectforeground=T["button_fg"])
        except Exception: pass
        for child in w.winfo_children():
            self._recolour_widget(child)

    def _recolour_ribbon_tabs(self):
        active = getattr(self, "_active_tab", "scan")
        for k, btn in getattr(self, "_ribbon_tabs", {}).items():
            try:
                if k == active:
                    btn.config(bg=T["accent"], fg=T["button_fg"])
                else:
                    btn.config(bg=T["panel_bg"], fg=T["text"],
                               activebackground=T["card_hover"], activeforeground=T["accent"])
            except Exception: pass
        run_wrap = getattr(self, "_run_icon_wrap", None)
        if run_wrap:
            try:
                run_wrap.configure(bg=T["accent"])
                run_btn = getattr(self, "_run_icon_btn", None)
                if run_btn: run_btn.configure(fg=T["accent"])
            except Exception: pass
        self._update_stop_btn_style()

    def _setup_styles(self):
        s = ttk.Style(self)
        try: s.theme_use("clam")
        except tk.TclError: pass
        f = (_FUI, 12)
        s.configure(".", background=T["bg"], foreground=T["text"], font=f)
        for name, bg in [("TFrame", T["bg"]), ("Card.TFrame", T["panel_bg"]), ("Surface.TFrame", T["panel_bg"])]:
            s.configure(name, background=bg)
        for name, bg, fg in [
            ("TLabel", T["bg"], T["text"]), ("Surface.TLabel", T["panel_bg"], T["text"]),
            ("Muted.TLabel", T["bg"], T["muted"]), ("MutedS.TLabel", T["panel_bg"], T["muted"]),
            ("Section.TLabel", T["panel_bg"], T["muted"])]:
            s.configure(name, background=bg, foreground=fg)
        s.configure("Section.TLabel", font=(_FUI, 10, "bold"))
        s.configure("TButton", background=T["surface2"], foreground=T["text"],
                    bordercolor=T["border"], padding=(10, 6), relief="flat")
        s.map("TButton", background=[("active", T["card_hover"]), ("disabled", T["surface2"])],
              foreground=[("disabled", T["muted"])])
        for name, bg, bga in [("Accent.TButton", T["accent"], T["accent_hi"]),
                              ("Danger.TButton", T["accent2"], T["accent2_hi"])]:
            s.configure(name, background=bg, foreground=T["button_fg"], font=(_FUI, 11, "bold"), padding=(14, 8))
            s.map(name, background=[("active", bga), ("disabled", T["surface2"])], foreground=[("disabled", T["muted"])])
        s.configure("Ghost.TButton", background=T["panel_bg"], foreground=T["text"],
                    bordercolor=T["border"], relief="solid", borderwidth=1, padding=(8, 5))
        s.map("Ghost.TButton", background=[("active", T["surface2"]), ("disabled", T["panel_bg"])],
              foreground=[("disabled", T["muted"])])
        s.configure("TEntry", fieldbackground=T["surface2"], foreground=T["text"], bordercolor=T["border"], padding=5)
        s.map("TEntry", bordercolor=[("focus", T["accent"])])
        s.configure("TCombobox", fieldbackground=T["surface2"], foreground=T["text"], arrowcolor=T["accent"])
        s.map("TCombobox", fieldbackground=[("readonly", T["surface2"])],
              selectbackground=[("readonly", T["accent"])], selectforeground=[("readonly", T["button_fg"])])
        s.configure("TCheckbutton", background=T["panel_bg"], foreground=T["text"])
        s.map("TCheckbutton", background=[("active", T["card_hover"])])
        s.configure("TSpinbox", fieldbackground=T["surface2"], foreground=T["text"])
        s.configure("Treeview", background=T["tree_bg"], foreground=T["text"], fieldbackground=T["tree_bg"],
                    rowheight=26, selectbackground=T["accent"], selectforeground=T["button_fg"])
        s.map("Treeview", background=[("selected", T["accent"])], foreground=[("selected", T["button_fg"])])
        s.configure("Treeview.Heading", background=T["tree_bg"], foreground=T["accent"],
                    font=(_FUI, 11, "bold"), relief="flat", borderwidth=0)
        s.map("Treeview.Heading", background=[("active", T["surface2"]), ("pressed", T["surface2"])],
              foreground=[("active", T["accent"])])
        s.configure("Vertical.TScrollbar", background=T["panel_bg"], troughcolor=T["bg"], bordercolor=T["border"])

    def _build_vars(self):
        self._target_var = tk.StringVar(value=str(self._target))
        self._reports_var = tk.StringVar(value=str(self._reports_root))
        self._scan_vars = {k: tk.BooleanVar(value=(k in ("sca", "code")))
                           for k in ("sca", "code", "dast", "api", "secrets")}
        self._dast_url_var = tk.StringVar(value="https://")
        self._dast_auth_var = tk.StringVar(value="auto")
        self._dast_profile_var = tk.StringVar(value="passive")
        self._dast_pages_var = tk.IntVar(value=30)
        self._dast_subs_var = tk.BooleanVar(value=False)
        self._dast_tls_var = tk.BooleanVar(value=True)
        self._dast_relogin_var = tk.BooleanVar(value=True)
        self._dast_exclude_var = tk.StringVar(value=(
            r"(?i)/(logout|log-?out|log-?off|signout|sign-?out|cerrar[-_]?sesion|"
            r"cerrarsesion|cerrar[-_]?session|salir|desconectar|desconexion|"
            r"deslog\w*|api/logout)\b"))
        self._dast_rps_var = tk.DoubleVar(value=8.0)
        self._dast_workers_var = tk.IntVar(value=4)
        self._dast_proxy_var = tk.StringVar(value="")
        self._dast_browser_var = tk.StringVar(value="chrome")
        self._dast_browser_label_var = tk.StringVar(value="Google Chrome")
        self._browser_catalog = {}
        self._browser_label_key = {}
        self._dast_headless_var = tk.BooleanVar(value=True)
        self._dast_selwait_var = tk.IntVar(value=15)
        self._dast_cred_vars = {k: tk.StringVar() for k in self._CRED_KEYS}
        self._api_spec_var = tk.StringVar(value="")
        self._api_base_var = tk.StringVar(value="")
        self._api_auth_var = tk.StringVar(value="none")
        self._api_profile_var = tk.StringVar(value="passive")
        self._api_pages_var = tk.IntVar(value=80)
        self._api_tls_var = tk.BooleanVar(value=True)
        self._api_rps_var = tk.DoubleVar(value=8.0)
        self._api_workers_var = tk.IntVar(value=6)
        self._api_proxy_var = tk.StringVar(value="")
        self._api_exclude_var = tk.StringVar(value=(
            r"(?i)/(logout|log-?out|log-?off|signout|sign-?out|cerrar[-_]?sesion|"
            r"cerrarsesion|cerrar[-_]?session|salir|desconectar|desconexion|"
            r"deslog\w*)\b"))
        self._api_cred_vars = {k: tk.StringVar() for k in
                               ("username", "password", "token", "cookie", "header_name", "header_value")}
        self._status_var = tk.StringVar(value='Initialising…')
        self._stage_pills: dict[str, tk.Label] = {}
        self._stage_apply: dict[str, Callable[[bool], None]] = {}
        self._recent_paths: list[Path] = []

    # Top-level UI
    def _build_ui(self):
        self._build_ribbon(); self._build_body(); self._build_status_bar(); self._show_tab("scan")

    def _build_ribbon(self):
        self._ribbon = tk.Frame(self, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"])
        self._ribbon.pack(side="top", fill="x")
        tk.Frame(self._ribbon, bg=T["accent"], height=2).pack(fill="x", side="top")
        inner_row = tk.Frame(self._ribbon, bg=T["panel_bg"]); inner_row.pack(fill="x", side="top")
        self._ribbon_tabs: dict[str, tk.Button] = {}
        tabs = [("scan", "▶ Scan"), ("static", "🔍 Static"), ("dast", "🌐 DAST"), ("api", "🔌 API"),
                ("reports", "📋 Reports"), ("apps", "📦 Apps")]
        tab_area = tk.Frame(inner_row, bg=T["panel_bg"]); tab_area.pack(side="left", fill="y", padx=(10, 0))
        for key, label in tabs:
            btn = tk.Button(tab_area, text=label, command=lambda k=key: self._show_tab(k),
                            bg=T["panel_bg"], fg=T["text"], font=(_FUI, 10, "bold"), relief="flat", bd=0,
                            padx=10, pady=6, cursor="hand2", justify="center",
                            activebackground=T["card_hover"], activeforeground=T["accent"])
            btn.bind("<Enter>", lambda e, b=btn: b.config(bg=T["card_hover"])
                     if b != self._ribbon_tabs.get(self._active_tab) else None)
            btn.bind("<Leave>", lambda e, b=btn: b.config(bg=T["panel_bg"])
                     if b != self._ribbon_tabs.get(self._active_tab) else None)
            btn.pack(side="left", fill="y", padx=1)
            self._ribbon_tabs[key] = btn
        right = tk.Frame(inner_row, bg=T["panel_bg"]); right.pack(side="right", padx=8)
        _run_wrap = tk.Frame(right, bg=T["accent"], padx=2, pady=2); _run_wrap.pack(side="left", padx=(0, 4))
        self._run_icon_btn = tk.Button(_run_wrap, text="▶", font=(_FUI, 14, "bold"), command=self._start_scan,
                                       bg="#ffffff", fg=T["accent"], activebackground=T["surface2"],
                                       activeforeground=T["accent"], relief="flat", bd=0, padx=8, pady=4,
                                       cursor="hand2", disabledforeground=T["muted"], state="disabled")
        self._run_icon_btn.pack(fill="both", expand=True)
        self._run_icon_wrap = _run_wrap
        _stop_wrap = tk.Frame(right, bg=T["muted"], padx=2, pady=2); _stop_wrap.pack(side="left", padx=(0, 8))
        self._stop_icon_btn = tk.Button(_stop_wrap, text="■", font=(_FUI, 14, "bold"), command=self._request_cancel,
                                        bg="#ffffff", fg=T["muted"], activebackground="#fff0f0",
                                        activeforeground=T["err"], relief="flat", bd=0, padx=8, pady=4,
                                        cursor="hand2", disabledforeground=T["muted"], state="disabled")
        self._stop_icon_btn.pack(fill="both", expand=True)
        self._stop_icon_wrap = _stop_wrap
        tk.Frame(self._ribbon, bg=T["border"], height=1).pack(fill="x", side="bottom")

    def _show_tab(self, key: str):
        self._active_tab = key
        for k, btn in self._ribbon_tabs.items():
            btn.config(bg=T["accent"], fg=T["button_fg"]) if k == key else btn.config(bg=T["panel_bg"], fg=T["text"])
        for k, frame in self._tab_frames.items():
            if k == key: frame.tkraise()

    def _build_body(self):
        body = tk.Frame(self, bg=T["bg"]); body.pack(side="top", fill="both", expand=True)
        self._console_frame = tk.Frame(body, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"])
        self._build_console(self._console_frame)
        stack = tk.Frame(body, bg=T["bg"]); stack.pack(side="top", fill="both", expand=True)
        self._tab_frames: dict[str, tk.Frame] = {}
        builders = {"scan": self._build_tab_scan, "dast": self._build_tab_dast, "api": self._build_tab_api,
                    "static": self._build_tab_static, "reports": self._build_tab_reports,
                    "apps": self._build_tab_apps}
        for key, builder in builders.items():
            f = tk.Frame(stack, bg=T["bg"]); f.place(x=0, y=0, relwidth=1, relheight=1)
            builder(f); self._tab_frames[key] = f

    def _build_status_bar(self):
        bar = tk.Frame(self, bg=T["panel_bg"], pady=5, highlightthickness=1, highlightbackground=T["border"])
        bar.pack(side="bottom", fill="x")
        self._theme_btn = tk.Button(bar, text=("🌙" if self._dark_mode else "☀"), command=self._toggle_theme,
                                    font=(_FUI, 13), bg=T["panel_bg"], fg=T["muted"], relief="flat",
                                    padx=8, pady=0, cursor="hand2", activebackground=T["card_hover"])
        self._theme_btn.pack(side="left", padx=(8, 0))
        self._console_btn = tk.Button(bar, text="▥  Console", command=self._toggle_console,
                                      font=self.fonts["caption"], bg=T["panel_bg"], fg=T["muted"], relief="flat",
                                      padx=8, pady=0, cursor="hand2", activebackground=T["card_hover"])
        self._console_btn.pack(side="left", padx=8)
        os_tag = "macOS" if IS_MAC else ("Windows" if IS_WIN else "Linux")
        user_box = tk.Frame(bar, bg=T["panel_bg"]); user_box.pack(side="right", padx=10)
        tk.Label(user_box, text=f"  ·  {os_tag}", font=self.fonts["caption"], bg=T["panel_bg"], fg=T["muted"]).pack(side="right")
        tk.Label(user_box, text=f"👤 {self._user}", font=self.fonts["caption"], bg=T["panel_bg"], fg=T["text"]).pack(side="right")
        tk.Label(bar, textvariable=self._status_var, font=self.fonts["caption"],
                 bg=T["panel_bg"], fg=T["accent"], anchor="center").pack(expand=True)

    def _toggle_theme(self):
        self._dark_mode = not self._dark_mode
        self._apply_theme_to_app(); self._save_settings()
        self._theme_btn.configure(text="🌙" if self._dark_mode else "☀")


    def _build_console(self, parent):
        hdr = tk.Frame(parent, bg=T["accent"], padx=10, pady=6); hdr.pack(fill="x")
        tk.Label(hdr, text="ACTIVITY LOG", font=(_FUI, 11, "bold"), bg=T["accent"], fg=T["button_fg"]).pack(side="left")
        _themed_btn(hdr, "✕ Close", self._toggle_console, font=self.fonts["small"], bg=T["accent"],
                    fg=T["button_fg"], hover_bg=T["button_hover"], hover_fg=T["button_fg"], padx=8).pack(side="right")
        inner = tk.Frame(parent, bg=T["surface2"]); inner.pack(fill="both", expand=True)
        self._log_widget = tk.Text(inner, wrap="word", font=self.fonts["mono"], bg=T["surface2"], fg=T["text"],
                                   insertbackground=T["text"], relief="flat", padx=12, pady=8, height=10, state="disabled")
        self._log_widget.pack(side="left", fill="both", expand=True)
        sb = ttk.Scrollbar(inner, command=self._log_widget.yview); sb.pack(side="right", fill="y")
        self._log_widget.configure(yscrollcommand=sb.set)

    def _toggle_console(self):
        if self._console_visible:
            self._console_frame.pack_forget(); self._console_visible = False
        else:
            self._console_frame.pack(side="bottom", fill="x"); self._console_visible = True; self._unread_log = 0
        self._console_btn.configure(text="▥  Console", fg=T["text"])

    # Shared UI helpers
    def _scrollable(self, parent, pad=(18, 12, 18, 8)) -> tk.Frame:
        canvas = tk.Canvas(parent, bg=T["bg"], highlightthickness=0, bd=0)
        vsb = ttk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        canvas.pack(side="left", fill="both", expand=True); vsb.pack(side="right", fill="y")
        holder = tk.Frame(canvas, bg=T["bg"])
        win = canvas.create_window((0, 0), window=holder, anchor="nw")
        holder.bind("<Configure>", lambda _: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(win, width=e.width))
        def wheel(e): canvas.yview_scroll(int(-e.delta / 120), "units")
        canvas.bind("<Enter>", lambda _: canvas.bind_all("<MouseWheel>", wheel))
        canvas.bind("<Leave>", lambda _: canvas.unbind_all("<MouseWheel>"))
        inner = tk.Frame(holder, bg=T["bg"], padx=pad[0], pady=pad[1]); inner.pack(fill="both", expand=True)
        return inner

    def _section_header(self, parent, text: str) -> tk.Frame:
        f = tk.Frame(parent, bg=T["panel_bg"], padx=14, pady=6); f.pack(fill="x")
        tk.Label(f, text=text, font=(_FUI, 13, "bold"), bg=T["panel_bg"], fg=T["accent"], anchor="w").pack(side="left")
        return f

    def _card(self, parent, title="", *, pady=(0, 10)) -> tk.Frame:
        outer = tk.Frame(parent, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"])
        outer.pack(fill="x", pady=pady)
        if title:
            hdr = tk.Frame(outer, bg=T["accent"], padx=14, pady=5); hdr.pack(fill="x")
            tk.Label(hdr, text=title, font=(_FUI, 10, "bold"), bg=T["accent"], fg=T["button_fg"], anchor="w").pack(side="left")
        inner = tk.Frame(outer, bg=T["panel_bg"], padx=14, pady=10); inner.pack(fill="both", expand=True)
        return inner

    # ── Static-analysis presentation (each area rendered to suit its data) ──────
    def _panel(self, parent, title, *, pady=(0, 10)):
        """Like _card but returns (inner_body, header_right) so callers can drop a
        live summary on the right of the gold header. Same brand chrome as _card."""
        outer = tk.Frame(parent, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"])
        outer.pack(fill="x", pady=pady)
        hdr = tk.Frame(outer, bg=T["accent"], padx=14, pady=5); hdr.pack(fill="x")
        tk.Label(hdr, text=title, font=(_FUI, 10, "bold"), bg=T["accent"], fg=T["button_fg"], anchor="w").pack(side="left")
        right = tk.Frame(hdr, bg=T["accent"]); right.pack(side="right")
        inner = tk.Frame(outer, bg=T["panel_bg"], padx=14, pady=10); inner.pack(fill="both", expand=True)
        return inner, right

    def _sev_brand_color(self, sev):
        sev = _sev_norm(sev)
        if sev in ("critical", "high"): return T["err"]     # brand red
        if sev == "medium":             return T["accent"]  # brand gold
        return T["muted"]                                   # low / info

    def _sev_leaf_tag(self, sev):
        sev = _sev_norm(sev)
        if sev in ("critical", "high"): return "crit"
        if sev == "medium":             return "med"
        return "muted"

    def _apply_group_tags(self, tree):
        tree.tag_configure("group", foreground=T["text"], font=(_FUI, 10, "bold"))
        tree.tag_configure("crit",  foreground=T["err"])
        tree.tag_configure("med",   foreground=T["text"])
        tree.tag_configure("muted", foreground=T["muted"])

    def _group_tree(self, parent, tree_col, cols, headings, height):
        """A collapsible 2-level tree (group → findings) with brand chrome."""
        outer = tk.Frame(parent, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["accent"])
        outer.pack(fill="both", expand=True)
        tk.Frame(outer, bg=T["accent"], height=2).pack(fill="x", side="top")
        tf = tk.Frame(outer, bg=T["panel_bg"]); tf.pack(fill="both", expand=True)
        tree = ttk.Treeview(tf, columns=cols, show="tree headings", height=height)
        tcol_txt, tcol_w = tree_col
        tree.heading("#0", text=tcol_txt, anchor="w"); tree.column("#0", width=tcol_w, stretch=True, anchor="w")
        for c, (txt, w, anchor, stretch) in zip(cols, headings):
            tree.heading(c, text=txt, anchor=anchor); tree.column(c, width=w, anchor=anchor, stretch=stretch)
        tree.pack(side="left", fill="both", expand=True)
        ttk.Scrollbar(tf, command=tree.yview, orient="vertical").pack(side="right", fill="y")
        self._apply_group_tags(tree)
        return tree

    def _tree_empty(self, tree, msg="No findings — run a scan."):
        for iid in tree.get_children(): tree.delete(iid)
        tree.insert("", "end", text="  " + msg, tags=("muted",))

    def _set_panel_summary(self, lbl, total, worst):
        if lbl is None: return
        if total == 0:
            lbl.config(text="no findings")
        else:
            lbl.config(text=f"{total} finding{'' if total == 1 else 's'}  ·  worst: {worst.upper()}")

    def _render_sca(self, projects):
        """SCA is about *which dependency to upgrade* — group by package, surface
        the fix version, collapse the individual CVEs underneath."""
        tree = self._static_sca_tree
        for iid in tree.get_children(): tree.delete(iid)
        groups: dict = {}
        for proj in projects or []:
            for i in proj.get("issues", []):
                groups.setdefault(i.get("package", "—"), []).append(i)
        total = 0; worst = "info"
        for pkg in sorted(groups):
            issues = groups[pkg]; total += len(issues)
            gw = "info"; fix = ""
            for i in issues:
                s = _sev_norm(i.get("severity"))
                if _SEV_RANK[s] > _SEV_RANK[gw]: gw = s
                if not fix and i.get("fixedIn") not in (None, "", "—"): fix = str(i.get("fixedIn"))
            if _SEV_RANK[gw] > _SEV_RANK[worst]: worst = gw
            p = tree.insert("", "end", text=f"{pkg}   ({len(issues)})",
                            values=(gw.upper(), ("→ " + fix) if fix else "—"), tags=("group",), open=False)
            for i in issues:
                s = _sev_norm(i.get("severity"))
                fx = i.get("fixedIn"); fx = ("→ " + str(fx)) if fx not in (None, "", "—") else "—"
                tree.insert(p, "end", text="   " + (i.get("title", "") or ""),
                            values=(s.upper(), fx), tags=(self._sev_leaf_tag(s),))
        if total == 0: self._tree_empty(tree)
        self._set_panel_summary(self._sca_summary, total, worst)

    def _render_sast(self, files):
        """SAST is about *where in the code* — group by file (data already is),
        collapse the per-line findings underneath."""
        tree = self._static_sast_tree
        for iid in tree.get_children(): tree.delete(iid)
        total = 0; worst = "info"
        for fobj in files or []:
            issues = fobj.get("issues", [])
            if not issues: continue
            total += len(issues); gw = "info"
            for i in issues:
                s = _sev_norm(i.get("severity"))
                if _SEV_RANK[s] > _SEV_RANK[gw]: gw = s
            if _SEV_RANK[gw] > _SEV_RANK[worst]: worst = gw
            p = tree.insert("", "end", text=f"{fobj.get('file', '—')}   ({len(issues)})",
                            values=(gw.upper(), ""), tags=("group",), open=False)
            for i in issues:
                s = _sev_norm(i.get("severity"))
                tree.insert(p, "end", text="   " + (i.get("title", "") or ""),
                            values=(s.upper(), str(i.get("line", "?"))), tags=(self._sev_leaf_tag(s),))
        if total == 0: self._tree_empty(tree)
        self._set_panel_summary(self._sast_summary, total, worst)

    def _secret_card(self, parent, sev, stype, file, line, redacted):
        card = tk.Frame(parent, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"])
        card.pack(fill="x", pady=(0, 6))
        tk.Frame(card, bg=T["accent"], width=4).pack(side="left", fill="y")
        body = tk.Frame(card, bg=T["panel_bg"], padx=12, pady=8); body.pack(side="left", fill="both", expand=True)
        top = tk.Frame(body, bg=T["panel_bg"]); top.pack(fill="x")
        tk.Label(top, text="🔑", font=(_FUI, 11), bg=T["panel_bg"], fg=T["accent"]).pack(side="left", padx=(0, 6))
        tk.Label(top, text=stype, font=(_FUI, 10, "bold"), bg=T["panel_bg"], fg=T["text"]).pack(side="left")
        tk.Label(top, text=_sev_norm(sev).upper(), font=(_FUI, 9, "bold"),
                 bg=T["panel_bg"], fg=self._sev_brand_color(sev)).pack(side="right")
        self._lbl(body, f"📄 {file}   :   {line}", size=9, fg=T["muted"], anchor="w").pack(fill="x", pady=(2, 0))
        if redacted:
            tk.Label(body, text=redacted, font=(_FMONO, 9), bg=T["surface2"], fg=T["text"],
                     anchor="w", padx=8, pady=3).pack(fill="x", pady=(4, 0))

    def _render_secrets(self, findings):
        """Secrets are few and urgent — one alert card each, redacted value in mono."""
        box = self._secrets_box
        for w in box.winfo_children(): w.destroy()
        findings = findings or []; worst = "info"
        if not findings:
            self._lbl(box, "No secrets found — run a scan.", size=10, fg=T["muted"], anchor="w").pack(fill="x")
        else:
            for s in findings:
                sev = _sev_norm(s.get("severity"))
                if _SEV_RANK[sev] > _SEV_RANK[worst]: worst = sev
                self._secret_card(box, sev,
                                  s.get("secret_type", s.get("rule", "Secret")) or "Secret",
                                  s.get("file", "—"), s.get("line", "?"), s.get("match", ""))
        self._set_panel_summary(self._secrets_summary, len(findings), worst)

    def _side_card(self, row, title, *, padx=(0, 0), pad=14, ipady=10) -> tk.Frame:
        outer = tk.Frame(row, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"])
        outer.pack(side="left", fill="both", expand=True, padx=padx)
        hdr = tk.Frame(outer, bg=T["accent"], padx=pad, pady=5); hdr.pack(fill="x")
        tk.Label(hdr, text=title, font=(_FUI, 10, "bold"), bg=T["accent"], fg=T["button_fg"], anchor="w").pack(side="left")
        inner = tk.Frame(outer, bg=T["panel_bg"], padx=pad, pady=ipady); inner.pack(fill="both", expand=True)
        return inner

    def _lbl(self, parent, text="", size=11, bold=False, bg=None, fg=None, **kw) -> tk.Label:
        return tk.Label(parent, text=text, font=(_FUI, size, "bold" if bold else "normal"),
                        bg=bg or T["panel_bg"], fg=fg or T["text"], **kw)

    def _btn(self, parent, text, cmd, kind="accent", **kw) -> tk.Button:
        _base_pad, _base_font = (12, 7), (_FUI, 11, "bold")
        p, is_in_ribbon = parent, False
        try:
            while p is not None:
                if getattr(self, "_ribbon", None) is p:
                    is_in_ribbon = True; break
                p = getattr(p, "master", None)
        except Exception:
            is_in_ribbon = False
        if is_in_ribbon:
            kinds = {
                "accent":  dict(bg=T["accent"], fg=T["button_fg"], activebackground=T["accent_hi"],
                                activeforeground=T["button_fg"], font=_base_font, padx=_base_pad[0], pady=_base_pad[1]),
                "danger":  dict(bg=T["accent2"], fg=T["button_fg"], activebackground=T["accent2_hi"],
                                activeforeground=T["button_fg"], font=_base_font, padx=_base_pad[0], pady=_base_pad[1]),
                "outline": dict(bg=T["panel_bg"], fg=T["accent"], activebackground=T["card_hover"],
                                activeforeground=T["accent_hi"], font=_base_font, padx=_base_pad[0],
                                pady=_base_pad[1], borderwidth=1, relief="solid"),
                "flat":    dict(bg=T["surface2"], fg=T["text"], activebackground=T["card_hover"],
                                activeforeground=T["accent"], font=(_FUI, 11), padx=10, pady=5),
            }
            cfg = kinds.get(kind, kinds["flat"])
        else:
            container = tk.Frame(parent, bg=T["accent"])
            inner_btn = tk.Button(container, text=text, command=cmd, bg=T["panel_bg"], fg=T["accent"],
                                  activebackground=T["card_hover"], activeforeground=T["accent_hi"],
                                  font=_base_font, padx=_base_pad[0], pady=_base_pad[1],
                                  cursor="hand2", bd=0, relief="flat", **kw)
            inner_btn.pack(fill="both", expand=True, padx=1, pady=1)
            inner_btn.pack = lambda *a, **kwa: container.pack(*a, **kwa)
            inner_btn.grid = lambda *a, **kwa: container.grid(*a, **kwa)
            inner_btn.container = container
            return inner_btn
        if "relief" not in cfg: cfg["relief"] = "flat"
        return tk.Button(parent, text=text, command=cmd, cursor="hand2", bd=0, **cfg, **kw)

    def _glabel(self, parent, text: str, row: int, col: int, tip: str = "") -> tk.Label:
        w = self._lbl(parent, text, size=10, fg=T["muted"], anchor="e")
        w.grid(row=row, column=col, sticky="e", padx=(0, 6), pady=3)
        if tip: return w

    def _spin(self, parent, label, var, frm, to, *, inc=None, width=6, padx=(0, 0)):
        if label:
            self._lbl(parent, label, size=10, fg=T["muted"]).pack(side="left", padx=(0, 4))
        kw = dict(from_=frm, to=to, textvariable=var, width=width)
        if inc is not None: kw["increment"] = inc
        sp = ttk.Spinbox(parent, **kw); sp.pack(side="left", padx=padx)
        return sp

    def _gentry(self, parent, var, row, col, tip="", *, span=1, **grid_kw):
        e = ttk.Entry(parent, textvariable=var)
        e.grid(row=row, column=col, columnspan=span, sticky="ew", pady=3, **grid_kw)
        if tip: return e

    def _hdiv(self, parent, **pk) -> tk.Frame:
        f = tk.Frame(parent, bg=T["border"], height=1); f.pack(fill="x", **pk)
        return f

    def _create_popup(self, title: str = "Window", w_pct: float = 0.75, h_pct: float = 0.75) -> tk.Frame:
        win = tk.Toplevel(self)
        win.title(title); win.configure(bg=T["bg"]); win.transient(self)
        _center_over(self, win, w_pct, h_pct)
        win.overrideredirect(True)
        win.update_idletasks(); win.lift(); win.focus_force()
        try: win.grab_set()
        except tk.TclError: pass
        _bind_ids: dict = {}

        def _close():
            try: win.grab_release()
            except Exception: pass
            for evt, bid in _bind_ids.items():
                try: self.unbind(evt, bid)
                except Exception: pass
            win.destroy()
            try: self.focus_force()
            except Exception: pass

        win.bind("<Escape>", lambda e: _close())
        _bind_ids.update(_popup_follow_parent(win, self))
        border = tk.Frame(win, bg=T["accent"], padx=2, pady=2); border.pack(fill="both", expand=True)
        content = tk.Frame(border, bg=T["bg"]); content.pack(fill="both", expand=True)
        content.close = _close   # type: ignore[attr-defined]
        content._win = win       # type: ignore[attr-defined]
        return content

    def _popup_hdr(self, popup: tk.Frame, title: str, subtitle: str = "", icon: str = "") -> tk.Frame:
        bg = T["panel_bg"]
        hdr = tk.Frame(popup, bg=bg, padx=30, pady=16); hdr.pack(fill="x")
        row = tk.Frame(hdr, bg=bg); row.pack(fill="x")
        tk.Label(row, text=f"{icon}  {title}" if icon else title, font=(_FUI, 15, "bold"),
                 bg=bg, fg=T["accent"]).pack(side="left")
        if subtitle:
            tk.Label(row, text=subtitle, font=(_FUI, 11, "italic"), bg=bg, fg=T["muted"]).pack(side="left", padx=(12, 0))
        _close_fn = getattr(popup, "close", None)
        if _close_fn:
            xbtn = tk.Label(row, text="✕", font=(_FUI, 13, "bold"), bg=bg, fg=T["muted"], cursor="hand2", padx=6)
            xbtn.pack(side="right")
            xbtn.bind("<Button-1>", lambda e: _close_fn())
            xbtn.bind("<Enter>", lambda e: xbtn.config(fg=T["err"]))
            xbtn.bind("<Leave>", lambda e: xbtn.config(fg=T["muted"]))
        self._hdiv(popup)
        return hdr

    def _popup_foot(self, popup: tk.Frame, *items, padx: int = 40, pady: int = 16, with_status: bool = False):
        bg = T["panel_bg"]
        self._hdiv(popup)
        bar = tk.Frame(popup, bg=bg, padx=padx, pady=pady); bar.pack(fill="x")
        status_lbl = None
        if with_status:
            status_lbl = tk.Label(bar, text="", font=(_FUI, 10), bg=bg, fg=T["muted"]); status_lbl.pack(side="left")
        for text, cmd, kind in items:
            self._btn(bar, text, cmd, kind).pack(side="right", padx=(6, 0))
        return (bar, status_lbl) if with_status else bar

    def _centered_msg(self, popup, icon, icon_color, title, message, msg_fg):
        """Shared centred icon + title + message body used by message/confirm popups."""
        bg = T["bg"]
        body = tk.Frame(popup, bg=bg); body.pack(fill="both", expand=True)
        tk.Frame(body, bg=bg).pack(fill="both", expand=True)
        row = tk.Frame(body, bg=bg); row.pack(padx=60)
        tk.Frame(body, bg=bg).pack(fill="both", expand=True)
        tk.Label(row, text=icon, font=(_FUI, 64), bg=bg, fg=icon_color).pack(side="left", padx=(0, 44))
        tk.Frame(row, bg=T["border"], width=1).pack(side="left", fill="y", padx=(0, 40))
        txt = tk.Frame(row, bg=bg); txt.pack(side="left", fill="x", expand=True)
        tk.Label(txt, text=title, font=(_FUI, 20, "bold"), bg=bg, fg=T["text"], anchor="w").pack(anchor="w")
        tk.Frame(txt, bg=T["border"], height=1).pack(fill="x", pady=(10, 12))
        tk.Label(txt, text=message, font=(_FUI, 13), bg=bg, fg=msg_fg, justify="left",
                 wraplength=1050, anchor="w").pack(anchor="w")

    def _choice_card(self, parent, icon, title, desc, *, enabled=True, icon_size=40, title_size=14,
                     desc_size=10, desc_wrap=None, ipadx=20, ipady=14, padx=12,
                     icon_pady=(18, 8), desc_pady=(6, 18)) -> tk.Frame:
        """Build one clickable choice card (icon/title/desc). Callers wire click & hover."""
        panel = T["panel_bg"]
        card = tk.Frame(parent, bg=panel, highlightthickness=2, highlightbackground=T["border"],
                        cursor="hand2" if enabled else "arrow")
        card.pack(side="left", padx=padx, ipadx=ipadx, ipady=ipady, fill="both", expand=True)
        tk.Label(card, text=icon, font=(_FUI, icon_size), bg=panel,
                 fg=T["accent"] if enabled else T["muted"]).pack(pady=icon_pady)
        tk.Label(card, text=title, font=(_FUI, title_size, "bold"), bg=panel,
                 fg=T["text"] if enabled else T["muted"]).pack()
        dkw = dict(justify="center")
        if desc_wrap: dkw["wraplength"] = desc_wrap
        tk.Label(card, text=desc, font=(_FUI, desc_size), bg=panel,
                 fg=T["muted"] if enabled else T["border"], **dkw).pack(pady=desc_pady)
        return card

    def _show_popup(self, title: str, message: str, kind: str = "info"):
        icon = {"info": "ℹ", "warn": "⚠", "error": "✕"}.get(kind, "ℹ")
        icon_color = {"info": T["accent"], "warn": T["accent"], "error": T["err"]}.get(kind, T["accent"])
        popup = self._create_popup(title)
        self._popup_hdr(popup, title, icon=icon)
        self._centered_msg(popup, icon, icon_color, title, message, T["err"] if kind == "error" else T["text"])
        self._popup_foot(popup, ("  OK  ", popup.close, "accent"))

    def _show_info_popup(self, title, message):  self._show_popup(title, message, "info")
    def _show_warn_popup(self, title, message):  self._show_popup(title, message, "warn")
    def _show_error_popup(self, title, message): self._show_popup(title, message, "error")


    # Tab: Scan
    def _build_tab_scan(self, parent):
        self._section_header(parent, '▶  Scan Dashboard')
        pad = self._scrollable(parent)

        app_banner = tk.Frame(pad, bg=T["surface2"], highlightthickness=1, highlightbackground=T["border"])
        app_banner.pack(fill="x", pady=(0, 8))
        banner_inner = tk.Frame(app_banner, bg=T["surface2"], padx=14, pady=7); banner_inner.pack(fill="x")
        tk.Label(banner_inner, text="📦  Active App:", font=(_FUI, 10, "bold"), bg=T["surface2"], fg=T["muted"]).pack(side="left")
        self._active_app_lbl = tk.Label(banner_inner, text="None — go to 📦 Apps tab to load a profile",
                                        font=(_FUI, 10), bg=T["surface2"], fg=T["muted"])
        self._active_app_lbl.pack(side="left", padx=(8, 0))
        tk.Button(banner_inner, text="📦 Switch App", command=lambda: self._show_tab("apps"),
                  bg=T["surface2"], fg=T["accent"], font=(_FUI, 10), relief="flat", padx=8, cursor="hand2",
                  activebackground=T["card_hover"], activeforeground=T["accent_hi"]).pack(side="right")

        cards_row = tk.Frame(pad, bg=T["bg"]); cards_row.pack(fill="x", pady=(0, 0))

        pipe_outer = tk.Frame(cards_row, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"])
        pipe_outer.pack(side="left", fill="both", expand=True, padx=(0, 6))
        ph = tk.Frame(pipe_outer, bg=T["accent"], padx=14, pady=6); ph.pack(fill="x")
        tk.Label(ph, text="PIPELINE", font=(_FUI, 10, "bold"), bg=T["accent"], fg=T["button_fg"]).pack(side="left")
        tk.Label(ph, text="Click a stage to toggle", font=(_FUI, 9), bg=T["accent"], fg=T["button_fg"]).pack(side="right")
        pipe = tk.Frame(pipe_outer, bg=T["panel_bg"], padx=10, pady=10); pipe.pack(fill="both", expand=True)
        pipe.columnconfigure(0, weight=1, uniform="sc"); pipe.columnconfigure(1, weight=1, uniform="sc")

        _STAGES = [
            ("sca",     "1", "Open-source (SCA)",  "CVE scan on\ndependency manifests"),
            ("code",    "2", "Static code (SAST)", "Security issues\nin source files"),
            ("secrets", "3", "Secret Scanning",    "Hard-coded keys\n& tokens (CWE-798)"),
            ("dast",    "4", "Dynamic (DAST)",     "Live URL crawl\n& probe injection"),
            ("api",     "5", "API Security",       "OpenAPI/Swagger\nendpoint probing"),
        ]

        def _make_stage_card(key, num, name, desc, grid_row, col):
            bg_off, bg_on, fg_on = T["surface2"], T["accent"], T["button_fg"]
            cell = tk.Frame(pipe, bg=bg_off, highlightthickness=1, highlightbackground=T["border"], cursor="hand2")
            cell.grid(row=grid_row, column=col, padx=4, pady=4, sticky="nsew")
            top = tk.Frame(cell, bg=bg_off, padx=8, pady=6); top.pack(fill="x")
            badge = tk.Label(top, text=num, font=(_FUI, 12, "bold"), bg=T["accent"], fg=T["button_fg"], padx=6)
            badge.pack(side="left")
            name_lbl = tk.Label(top, text=name, font=(_FUI, 10, "bold"), bg=bg_off, fg=T["text"]); name_lbl.pack(side="left", padx=8)
            pill = tk.Label(top, text="● IDLE", font=(_FUI, 8), bg=T["pill_idle_bg"], fg=T["pill_idle_fg"], padx=6, pady=2)
            pill.pack(side="right")
            desc_lbl = tk.Label(cell, text=desc, font=(_FUI, 8), bg=bg_off, fg=T["muted"], anchor="w", justify="left", padx=8)
            desc_lbl.pack(fill="x", pady=(0, 8))

            def _apply_state(active):
                if active:
                    cell.configure(bg=bg_on, highlightbackground=bg_on); top.configure(bg=bg_on)
                    badge.configure(text="✓", bg="#ffffff", fg=bg_on)
                    name_lbl.configure(bg=bg_on, fg=fg_on); desc_lbl.configure(bg=bg_on, fg=fg_on)
                else:
                    cell.configure(bg=bg_off, highlightbackground=T["border"]); top.configure(bg=bg_off)
                    badge.configure(text=num, bg=T["accent"], fg=T["button_fg"])
                    name_lbl.configure(bg=bg_off, fg=T["text"]); desc_lbl.configure(bg=bg_off, fg=T["muted"])

            def _toggle(_evt=None):
                v = self._scan_vars[key]; v.set(0 if v.get() else 1)
                _apply_state(bool(v.get())); self._refresh_scan_btn()

            def _on_enter(e):
                if not self._scan_vars[key].get(): cell.configure(highlightbackground=T["accent"])

            def _on_leave(e):
                if not self._scan_vars[key].get(): cell.configure(highlightbackground=T["border"])

            for w in cell.winfo_children() + [cell]:
                w.bind("<Button-1>", _toggle); w.bind("<Enter>", _on_enter); w.bind("<Leave>", _on_leave)
            self._stage_pills[key] = pill
            # Remember this card's paint function and sync it to the *actual*
            # BooleanVar value right away — without this, a stage whose var
            # defaults/was set to True (e.g. SCA + SAST) would still be drawn
            # "off", so the pipeline would silently run more (or fewer) stages
            # than the cards visually showed.
            self._stage_apply[key] = _apply_state
            _apply_state(bool(self._scan_vars[key].get()))

        for i, (k, n, nm, ds) in enumerate(_STAGES):
            _make_stage_card(k, n, nm, ds, i // 2, i % 2)

        prereq_outer = tk.Frame(cards_row, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"])
        prereq_outer.pack(side="left", fill="both", expand=True)
        self._prereq_hdr_frame = tk.Frame(prereq_outer, bg=T["accent"], padx=14, pady=5); self._prereq_hdr_frame.pack(fill="x")
        self._prereq_hdr_lbl = tk.Label(self._prereq_hdr_frame, text="PREREQUISITES", font=(_FUI, 10, "bold"),
                                        bg=T["accent"], fg=T["button_fg"], anchor="w"); self._prereq_hdr_lbl.pack(side="left")
        self._prereq_warn_lbl = tk.Label(self._prereq_hdr_frame, text="", font=(_FUI, 9, "bold"),
                                         bg=T["accent"], fg=T["button_fg"], anchor="e"); self._prereq_warn_lbl.pack(side="right")
        env_card = tk.Frame(prereq_outer, bg=T["panel_bg"], padx=10, pady=8); env_card.pack(fill="both", expand=True)

        # Python / Node / npm / Snyk-CLI are already installed by the boot
        # splash (_load_runtime) on every launch, so re-verifying them here is
        # redundant. Only authentication is left — the boot installer cannot log
        # you in, so a live Snyk session stays a mandatory, GUI-checked prereq.
        self._check_rows: dict[str, dict] = {}
        for key, name in [("auth", "Snyk authentication")]:
            row = tk.Frame(env_card, bg=T["panel_bg"]); row.pack(fill="x", pady=2)
            status = tk.Label(row, text="●", font=(_FUI, 12, "bold"), bg=T["panel_bg"], fg=T["muted"], width=2); status.pack(side="left")
            self._lbl(row, name, size=10, bold=True, width=16, anchor="w").pack(side="left")
            detail = self._lbl(row, "…", size=9, fg=T["muted"], anchor="w"); detail.pack(side="left", fill="x", expand=True, padx=(4, 4))
            fix = self._btn(row, "Fix", lambda k=key: self._fix(k), kind="outline"); fix.pack(side="right"); fix.config(state="disabled")
            self._check_rows[key] = {"status": status, "detail": detail, "fix": fix}

        btn_row_env = tk.Frame(env_card, bg=T["panel_bg"]); btn_row_env.pack(fill="x", pady=(4, 0))

        # SSO instruction note — sits between the auth status row and the buttons
        sso_note = tk.Frame(env_card, bg="#fffbef", highlightthickness=1, highlightbackground="#f0e0a0")
        sso_note.pack(fill="x", pady=(6, 4))
        sso_inner = tk.Frame(sso_note, bg="#fffbef", padx=10, pady=6); sso_inner.pack(fill="x")
        tk.Label(sso_inner, text="ℹ️", font=(_FUI, 11), bg="#fffbef", fg="#7a5c00").pack(side="left")
        tk.Label(sso_inner,
                 text="  Debes iniciar sesión usando SSO: en la ventana de Snyk que se abre, "
                      "selecciona 'Login via SSO' (opción en gris, debajo de 'Log in with Google').",
                 font=(_FUI, 9), bg="#fffbef", fg="#7a5c00", wraplength=360, justify="left",
                 anchor="w").pack(side="left", fill="x", expand=True)

        btn_row_env2 = tk.Frame(env_card, bg=T["panel_bg"]); btn_row_env2.pack(fill="x", pady=(2, 0))
        self._btn(btn_row_env2, '🔄 Re-check', lambda: self._run_async(self._recheck, label="env check"), kind="outline").pack(side="left")
        self._login_btn = self._btn(btn_row_env2, '🔑 Login via SSO',
                                    lambda: self._run_async(self._do_login, label="snyk auth"), kind="accent")
        self._login_btn.pack(side="left", padx=(8, 0)); self._login_btn.config(state="disabled")
        # Always-available re-login: a saved token can silently expire while the
        # panel still shows "logged in", so the user needs a way to force a fresh
        # SSO sign-in regardless of the panel's state.
        self._relogin_btn = self._btn(btn_row_env2, '🔁 Re-login (SSO)',
                                      lambda: self._run_async(self._do_login, label="snyk re-auth"),
                                      kind="outline")
        self._relogin_btn.pack(side="left", padx=(8, 0))

        self._scan_btn = tk.Button(pad, state="disabled")
        self._open_btn = tk.Button(pad, state="disabled")
        self._csv_btn = tk.Button(pad, state="disabled")
        self._recent_lb = tk.Listbox(pad); self._recent_lb.pack_forget()

    def _build_tab_dast(self, parent):
        self._section_header(parent, '🌐  Dynamic Application Security Testing (DAST)')
        pad = self._scrollable(parent)
        body = self._card(pad, 'TARGET & PROFILE'); body.columnconfigure(1, weight=1)
        def gl(text, r, c): return self._glabel(body, text, r, c)
        gl('Target URL', 0, 0); self._gentry(body, self._dast_url_var, 0, 1, span=3)
        gl('Auth type', 1, 0)
        ac = ttk.Combobox(body, textvariable=self._dast_auth_var,
                          values=["auto","none","basic","bearer","cookie","header","form","selenium"],
                          state="readonly", width=12)
        ac.grid(row=1, column=1, sticky="w", pady=3)
        def _on_dast_auth_change(_evt=None): self._refresh_dast_creds(); self._refresh_dast_sel_card()
        ac.bind("<<ComboboxSelected>>", _on_dast_auth_change)
        gl('Profile', 2, 0)
        pc = ttk.Combobox(body, textvariable=self._dast_profile_var, values=["passive","active"],
                          state="readonly", width=10)
        pc.grid(row=2, column=1, sticky="w", pady=3, padx=(0, 4))
        self._dast_cred_frame = tk.Frame(body, bg=T["panel_bg"])
        self._dast_cred_frame.grid(row=3, column=0, columnspan=4, sticky="ew", pady=(4, 0))
        self._dast_cred_frame.columnconfigure(1, weight=1)
        scope = tk.Frame(body, bg=T["panel_bg"]); scope.grid(row=4, column=0, columnspan=4, sticky="ew", pady=(8, 0))
        self._spin(scope, 'Max pages', self._dast_pages_var, 1, 500, width=5, padx=(0, 14))
        for text, var, _ in [
            ("Include subdomains", self._dast_subs_var,    'Also crawl links on subdomains of the target host.'),
            ("Verify TLS",         self._dast_tls_var,     'Validate HTTPS certificate. Untick for self-signed / staging certs.'),
            ("Auto re-login",      self._dast_relogin_var, 'Re-authenticate automatically if the session expires mid-scan.'),
        ]:
            ttk.Checkbutton(scope, text=text, variable=var).pack(side="left", padx=(0, 14))
        adv = tk.Frame(body, bg=T["panel_bg"]); adv.grid(row=5, column=0, columnspan=4, sticky="ew", pady=(6, 0))
        adv.columnconfigure(1, weight=2); adv.columnconfigure(3, weight=1)
        self._lbl(adv, 'Exclude URL regex', size=10, fg=T["muted"]).grid(row=0, column=0, sticky="w", padx=(0, 6))
        self._gentry(adv, self._dast_exclude_var, 0, 1, span=3)
        rps_row = tk.Frame(body, bg=T["panel_bg"]); rps_row.grid(row=6, column=0, columnspan=4, sticky="ew", pady=(4, 0))
        self._spin(rps_row, 'Rate (req/s)', self._dast_rps_var, 0.5, 100, inc=0.5, padx=(0, 16))
        self._spin(rps_row, 'Workers', self._dast_workers_var, 1, 16, width=4, padx=(0, 16))
        self._lbl(rps_row, 'HTTP proxy', size=10, fg=T["muted"]).pack(side="left", padx=(0, 4))
        ttk.Entry(rps_row, textvariable=self._dast_proxy_var, width=28).pack(side="left")
        sel_card = self._card(pad, 'BROWSER LOGIN  (auth = auto / selenium)', pady=(0, 14)); sel_card.columnconfigure(1, weight=1)
        self._lbl(sel_card, 'Browser', size=10, fg=T["muted"]).grid(row=1, column=0, sticky="e", padx=(0, 6))
        labels = self._refresh_browser_catalog()  # only browsers installed on this machine
        sel_browser_cb = ttk.Combobox(sel_card, textvariable=self._dast_browser_label_var,
                                      values=labels, state="readonly", width=18)
        sel_browser_cb.grid(row=1, column=1, sticky="w"); self._dast_browser_cb = sel_browser_cb
        def _on_browser_pick(_=None):
            key = self._browser_label_key.get(self._dast_browser_label_var.get())
            if key: self._dast_browser_var.set(key)
        sel_browser_cb.bind("<<ComboboxSelected>>", _on_browser_pick)
        sel_opts = tk.Frame(sel_card, bg=T["panel_bg"]); sel_opts.grid(row=2, column=0, columnspan=4, sticky="ew", pady=(4, 0))
        ttk.Checkbutton(sel_opts, text="Headless", variable=self._dast_headless_var)
        self._spin(sel_opts, 'Login timeout (s)', self._dast_selwait_var, 1, 180, width=5, padx=(0, 16))
        macro_row = tk.Frame(sel_card, bg=T["panel_bg"]); macro_row.grid(row=3, column=0, columnspan=4, sticky="ew", pady=(8, 0))
        self._dast_macro_row = macro_row
        tk.Frame(macro_row, bg=T["border"], height=1).pack(fill="x", pady=(0, 8))
        self._lbl(macro_row, "MACROS", size=9, fg=T["muted"], bold=True).pack(anchor="w")
        macro_btns = tk.Frame(macro_row, bg=T["panel_bg"]); macro_btns.pack(fill="x", pady=(4, 0))
        self._macro_recorded = {"login": False, "logout": False}
        self._macro_check_vars = {"login": tk.StringVar(value=""), "logout": tk.StringVar(value="")}

        def _refresh_macro_ui():
            for flag, var in self._macro_check_vars.items():
                var.set("  ✔" if self._macro_recorded[flag] else "")
            lo_btn = getattr(self, "_macro_logout_btn", None)
            if lo_btn: lo_btn.config(state="normal" if self._macro_recorded["login"] else "disabled")

        def _macro_popup(flag, title, icon, desc, record_fn, save_fn, load_fn, rec_tip, save_tip, load_tip):
            popup = self._create_popup(title)
            self._popup_hdr(popup, title, icon=icon)
            body2 = tk.Frame(popup, bg=T["bg"]); body2.pack(fill="both", expand=True)
            tk.Frame(body2, bg=T["bg"]).pack(fill="both", expand=True)
            recorded_now = self._macro_recorded[flag]
            badge_var = tk.StringVar(value="✔  Recorded" if recorded_now else "⬜  Not recorded")
            badge_fg = T["ok"] if recorded_now else T["muted"]
            stat_frame = tk.Frame(body2, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"])
            stat_frame.pack(fill="x", padx=60)
            stat_inner = tk.Frame(stat_frame, bg=T["panel_bg"], padx=28, pady=14); stat_inner.pack(fill="x")
            badge_lbl = tk.Label(stat_inner, textvariable=badge_var, font=(_FUI, 16, "bold"), bg=T["panel_bg"], fg=badge_fg)
            badge_lbl.pack(side="left")
            tk.Label(stat_inner, text=desc, font=(_FUI, 11), bg=T["panel_bg"], fg=T["muted"],
                     justify="left", wraplength=900).pack(side="left", padx=(28, 0))
            card_row = tk.Frame(body2, bg=T["bg"]); card_row.pack(padx=60, pady=28)
            tk.Frame(body2, bg=T["bg"]).pack(fill="both", expand=True)

            def _do_record():
                popup.close(); ok = record_fn()
                if ok:
                    self._macro_recorded[flag] = True; _refresh_macro_ui()

            def _do_load():
                popup.close(); load_fn()
                check_key = "selenium_login_url" if flag == "login" else "logout_url_re"
                if self._dast_cred_vars.get(check_key, tk.StringVar()).get().strip():
                    self._macro_recorded[flag] = True; _refresh_macro_ui()

            def _do_clear():
                _CLEAR_KEYS = {
                    "login":  ["selenium_login_url","selenium_user_selector","selenium_user_value",
                               "selenium_pass_selector","selenium_pass_value","selenium_submit_selector",
                               "selenium_extra_steps","selenium_macro","login_success_selector","login_success_text"],
                    "logout": ["logout_url_re","login_success_selector","login_success_text"],
                }
                for k in _CLEAR_KEYS.get(flag, []):
                    if k in self._dast_cred_vars: self._dast_cred_vars[k].set("")
                self._macro_recorded[flag] = True   # keep logic compatible
                self._macro_recorded[flag] = False
                if flag == "login":
                    for k in _CLEAR_KEYS["logout"]:
                        if k in self._dast_cred_vars: self._dast_cred_vars[k].set("")
                    self._macro_recorded["logout"] = False
                _refresh_macro_ui(); self._refresh_dast_creds()
                badge_var.set("⬜  Not recorded"); badge_lbl.config(fg=T["muted"]); popup.close()

            def _do_test_logout():
                popup.close(); self._dast_test_logout()

            _actions = [
                ("⏺", "Record new", rec_tip, _do_record, True, "accent"),
                ("💾", "Save…", save_tip, lambda: (popup.close(), save_fn()), recorded_now, "outline"),
                ("📂", "Load…", load_tip, _do_load, True, "outline"),
                ("🗑", "Clear", f"Reset the {flag} condition and clear all stored selectors.",
                 _do_clear, recorded_now, "flat"),
            ]
            if flag == "logout":
                _actions.append(("🧪", "Test",
                    "Open a browser, replay login, navigate to the logout URL, then close automatically.",
                    _do_test_logout, self._macro_recorded["logout"], "outline"))
            for ico, lbl, tip, cmd, enabled, _kind in _actions:
                card = self._choice_card(card_row, ico, lbl, tip, enabled=enabled, icon_size=32,
                                         title_size=13, desc_size=9, desc_wrap=170, ipadx=18, ipady=12,
                                         padx=10, icon_pady=(16, 6), desc_pady=(4, 16))
                if enabled:
                    def _mk(c=cmd):
                        def _fn(e=None): c()
                        return _fn
                    fn = _mk(); card.bind("<Button-1>", fn)
                    for child in card.winfo_children(): child.bind("<Button-1>", fn)
                    card.bind("<Enter>", lambda e, c=card: c.configure(highlightbackground=T["accent"]))
                    card.bind("<Leave>", lambda e, c=card: c.configure(highlightbackground=T["border"]))
            self._popup_foot(popup, ("  Close  ", popup.close, "flat"))

        login_wrap = tk.Frame(macro_btns, bg=T["panel_bg"]); login_wrap.pack(side="left", padx=(0, 4))
        login_args = ("login", "Login Macro", "⏺",
                      "Record a new macro, or save/load a previously recorded one.",
                      self._dast_record_macro, self._dast_save_login_condition, self._dast_load_login_condition,
                      "Opens a real browser and records your login clicks and form inputs.",
                      "Save the recorded login selectors + session-detection fields.\nPasswords are never written to disk.",
                      "Load a previously saved login-condition file.")
        login_btn = self._btn(login_wrap, "⏺  Record Login Condition", lambda a=login_args: _macro_popup(*a), kind="outline")
        login_btn.pack(side="left")
        tk.Label(login_wrap, textvariable=self._macro_check_vars["login"], font=(_FUI, 11, "bold"),
                 bg=T["panel_bg"], fg=T["ok"]).pack(side="left")
        logout_wrap = tk.Frame(macro_btns, bg=T["panel_bg"]); logout_wrap.pack(side="left", padx=(4, 0))
        logout_args = ("logout", "Logout Condition", "🚪",
                       "Record a logout condition, or save/load a previously recorded one.",
                       self._dast_record_logout, self._dast_save_logout_condition, self._dast_load_logout_condition,
                       "Opens a browser, replays your login, then records the logout state.",
                       "Save the logout URL regex + logged-in selector & text marker.",
                       "Load a saved logout-condition file.")
        logout_btn = self._btn(logout_wrap, "🚪  Record Logout Condition", lambda a=logout_args: _macro_popup(*a), kind="outline")
        logout_btn.pack(side="left"); logout_btn.config(state="disabled")
        tk.Label(logout_wrap, textvariable=self._macro_check_vars["logout"], font=(_FUI, 11, "bold"),
                 bg=T["panel_bg"], fg=T["ok"]).pack(side="left")
        self._macro_logout_btn = logout_btn
        prof_row = tk.Frame(pad, bg=T["bg"])
        self._btn(prof_row, "💾  Save Profile…", self._dast_save_profile, kind="flat").pack(side="left", padx=(0, 8))
        self._btn(prof_row, "📂  Load Profile…", self._dast_load_profile, kind="flat").pack(side="left")
        self._dast_sel_card = sel_card; self._dast_prof_row = prof_row
        self._refresh_dast_creds(); self._refresh_dast_sel_card()

    def _refresh_creds(self, frame, auth_var, cred_vars, *, session_fields=False):
        for w in frame.winfo_children(): w.destroy()
        frame.columnconfigure(1, weight=1)
        kind = auth_var.get()
        base = 0
        if kind == "auto":
            self._lbl(frame,
                      "Auto-detects the login form in a real browser, fills these "
                      "credentials, submits and verifies — no selectors or macro needed.",
                      size=9, fg=T["muted"], anchor="w", wraplength=520
                      ).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 4))
            base = 1
        fields = [f for f in self._DAST_AUTH_FIELDS.get(kind, []) if f[0] in cred_vars]
        for i, (key, label, secret) in enumerate(fields):
            r = base + i
            self._lbl(frame, label, size=10, fg=T["muted"], anchor="e").grid(row=r, column=0, sticky="e", padx=(0, 6), pady=2)
            ttk.Entry(frame, textvariable=cred_vars[key], show="*" if secret else "").grid(row=r, column=1, sticky="ew", pady=2)
        if session_fields:
            r0 = base + len(fields)
            tk.Frame(frame, bg=T["border"], height=1).grid(row=r0, column=0, columnspan=2, sticky="ew", pady=6); r0 += 1
            self._lbl(frame, "SESSION DETECTION", size=9, fg=T["muted"], bold=True).grid(row=r0, column=0, columnspan=2, sticky="w"); r0 += 1
            for key, label in self._SESSION_FIELDS:
                self._lbl(frame, label, size=10, fg=T["muted"], anchor="e").grid(row=r0, column=0, sticky="e", padx=(0, 6), pady=2)
                ttk.Entry(frame, textvariable=cred_vars[key]).grid(row=r0, column=1, sticky="ew", pady=2); r0 += 1

    def _refresh_dast_creds(self):
        self._refresh_creds(self._dast_cred_frame, self._dast_auth_var, self._dast_cred_vars, session_fields=True)

    def _refresh_dast_sel_card(self):
        kind = self._dast_auth_var.get()
        show = kind in ("selenium", "auto")
        outer = self._dast_sel_card.master
        self._dast_prof_row.pack_forget()  # always remove first so it ends up after sel_card
        if show: outer.pack(fill="x", pady=(0, 14))
        else:    outer.pack_forget()
        # MACROS (record login/logout) only make sense for the manual selenium
        # flow — "auto" detects everything on its own, so hide them there.
        mrow = getattr(self, "_dast_macro_row", None)
        if mrow is not None:
            if kind == "selenium": mrow.grid()
            else:                  mrow.grid_remove()
        self._dast_prof_row.pack(fill="x", pady=(6, 12))

    def _build_tab_api(self, parent):
        self._section_header(parent, '🔌  API Security Scanning (OpenAPI / Swagger / Postman)')
        pad = self._scrollable(parent)
        body = self._card(pad, 'SPEC & TARGET'); body.columnconfigure(1, weight=1); body.columnconfigure(3, weight=1)
        def gl(text, r, c): return self._glabel(body, text, r, c)
        gl('Spec (URL or file)', 0, 0); self._gentry(body, self._api_spec_var, 0, 1, span=2)
        self._btn(body, 'Browse…', self._browse_api_spec, kind="flat").grid(row=0, column=3, sticky="w", padx=(4, 0))
        gl('Base URL override', 1, 0); self._gentry(body, self._api_base_var, 1, 1, span=3)
        gl('Auth type', 2, 0)
        api_ac = ttk.Combobox(body, textvariable=self._api_auth_var, values=["none","basic","bearer","cookie","header"],
                              state="readonly", width=10)
        api_ac.grid(row=2, column=1, sticky="w", pady=3)
        api_ac.bind("<<ComboboxSelected>>", lambda _: self._refresh_api_creds())
        gl('Profile', 3, 0)
        api_pc = ttk.Combobox(body, textvariable=self._api_profile_var, values=["passive","active"], state="readonly", width=10)
        api_pc.grid(row=3, column=1, sticky="w", pady=3)
        self._api_cred_frame = tk.Frame(body, bg=T["panel_bg"])
        self._api_cred_frame.grid(row=4, column=0, columnspan=4, sticky="ew", pady=(4, 0))
        self._api_cred_frame.columnconfigure(1, weight=1)
        scope = tk.Frame(body, bg=T["panel_bg"]); scope.grid(row=5, column=0, columnspan=4, sticky="ew", pady=(8, 0))
        self._spin(scope, 'Max endpoints', self._api_pages_var, 1, 1000, padx=(0, 14))
        ttk.Checkbutton(scope, text="Verify TLS", variable=self._api_tls_var).pack(side="left", padx=(0, 14))
        self._spin(scope, 'Rate (req/s)', self._api_rps_var, 0.5, 100, inc=0.5)
        self._lbl(scope, 'Workers', size=10, fg=T["muted"]).pack(side="left", padx=(14, 4))
        self._spin(scope, "", self._api_workers_var, 1, 16, width=4)
        adv = tk.Frame(body, bg=T["panel_bg"]); adv.grid(row=6, column=0, columnspan=4, sticky="ew", pady=(6, 0))
        adv.columnconfigure(1, weight=2); adv.columnconfigure(4, weight=1)
        self._lbl(adv, 'Exclude regex', size=10, fg=T["muted"]).grid(row=0, column=0, sticky="w", padx=(0, 6))
        self._gentry(adv, self._api_exclude_var, 0, 1, span=2)
        self._lbl(adv, 'HTTP proxy', size=10, fg=T["muted"]).grid(row=0, column=3, sticky="w", padx=(8, 6))
        self._gentry(adv, self._api_proxy_var, 0, 4)
        conv_card = self._card(pad, 'SPEC CONVERTER & ENDPOINT PREVIEW', pady=(0, 14))
        btn_row_conv = tk.Frame(conv_card, bg=T["panel_bg"]); btn_row_conv.pack(fill="x", pady=(0, 6))
        self._btn(btn_row_conv, '🔍 Preview', self._api_preview_spec, kind="accent").pack(side="left")
        self._btn(btn_row_conv, '📥 Import…', self._api_import_popup, kind="flat").pack(side="left", padx=(8, 0))
        self._btn(btn_row_conv, "💾 Export…", self._api_export_popup, kind="flat").pack(side="left", padx=(8, 0))
        tree_wrap = tk.Frame(conv_card, bg=T["panel_bg"]); tree_wrap.pack(fill="both", expand=True)
        self._ep_tree = _make_tree(tree_wrap, ("method","url","secured","body"),
                                   [("Method",70),("Endpoint URL",480),("Auth req.",70),("Body type",120)], height=10)
        self._ep_count_lbl = self._lbl(conv_card, "", size=10, fg=T["muted"]); self._ep_count_lbl.pack(anchor="w", pady=(4, 0))
        self._refresh_api_creds()

    def _refresh_api_creds(self):
        self._refresh_creds(self._api_cred_frame, self._api_auth_var, self._api_cred_vars)

    def _browse_api_spec(self):
        p = filedialog.askopenfilename(title="Choose API spec",
            filetypes=[("Spec files","*.json *.yaml *.yml"),("All","*.*")])
        if p: self._api_spec_var.set(p)

    def _api_load_spec_file(self, title: str, filetypes: list, log_label: str):
        p = filedialog.askopenfilename(title=title, filetypes=filetypes)
        if p:
            self._api_spec_var.set(p); self._emit_log(f"[api] {log_label} loaded: {p}"); self._api_preview_spec()

    def _api_import_postman(self):
        self._api_load_spec_file("Import Postman Collection",
            [("Postman collection", "*.json"), ("All", "*.*")], "Postman collection")

    def _api_import_openapi(self):
        self._api_load_spec_file("Import OpenAPI / Swagger spec",
            [("OpenAPI/Swagger", "*.json *.yaml *.yml"), ("All", "*.*")], "OpenAPI/Swagger spec")

    def _api_import_popup(self):
        popup = self._create_popup("Import spec")
        self._popup_hdr(popup, "Import spec", icon="📥")
        body = tk.Frame(popup, bg=T["bg"]); body.pack(fill="both", expand=True)
        tk.Frame(body, bg=T["bg"]).pack(fill="both", expand=True)
        tk.Label(body, text="Choose the spec format to import:", font=(_FUI, 13), bg=T["bg"], fg=T["muted"]).pack(pady=(0, 28))
        card_row = tk.Frame(body, bg=T["bg"]); card_row.pack(padx=80)
        tk.Frame(body, bg=T["bg"]).pack(fill="both", expand=True)
        def _pick(kind):
            popup.close()
            (self._api_import_postman if kind == "postman" else self._api_import_openapi)()
        for icon_txt, label, desc, kind in [
            ("📦", "Postman Collection", "Import a Postman v2.1 collection (.json)", "postman"),
            ("📄", "Swagger / OpenAPI", "Import an OpenAPI v2/v3 or Swagger spec\n(.json or .yaml)", "openapi"),
        ]:
            card = self._choice_card(card_row, icon_txt, label, desc, ipadx=28, ipady=22, padx=20, desc_pady=(6, 20))
            def _mk_click(k=kind):
                def _fn(e=None): _pick(k)
                return _fn
            click_fn = _mk_click(); card.bind("<Button-1>", click_fn)
            for child in card.winfo_children(): child.bind("<Button-1>", click_fn)
            card.bind("<Enter>", lambda e, c=card: c.configure(highlightbackground=T["accent"]))
            card.bind("<Leave>", lambda e, c=card: c.configure(highlightbackground=T["border"]))
        self._popup_foot(popup, ("  Cancel  ", popup.close, "flat"))

    def _api_export_popup(self):
        rows = self._ep_tree.get_children()
        if not rows:
            self._show_warn_popup("Export endpoints", "No endpoints to export — run 🔍 Preview first."); return
        ops = [{"method": self._ep_tree.set(iid, "method"), "url": self._ep_tree.set(iid, "url"),
                "secured": self._ep_tree.set(iid, "secured"), "body": self._ep_tree.set(iid, "body")} for iid in rows]
        popup = self._create_popup("Export endpoints")
        self._popup_hdr(popup, "Export endpoints", icon="💾", subtitle=f"{len(ops)} endpoint(s)")
        body = tk.Frame(popup, bg=T["bg"]); body.pack(fill="both", expand=True)
        tk.Frame(body, bg=T["bg"]).pack(fill="both", expand=True)
        tk.Label(body, text="Choose export format:", font=(_FUI, 13), bg=T["bg"], fg=T["muted"]).pack(pady=(0, 20))
        card_row = tk.Frame(body, bg=T["bg"]); card_row.pack(padx=60)
        tk.Frame(body, bg=T["bg"]).pack(fill="both", expand=True)
        fmt_var = tk.StringVar(value="CSV"); _cards = {}
        _FORMAT_META = [
            ("CSV", "📊", "Comma-separated values\nExcel / Sheets"),
            ("JSON", "📋", "Raw JSON array\nScripts / APIs"),
            ("YAML", "📄", "YAML format\nOpenAPI tooling"),
            ("Postman v2.1", "📦", "Postman Collection v2.1\nDirect Postman import"),
        ]
        def _refresh_cards(*_):
            for f, c in _cards.items():
                c.configure(highlightbackground=T["accent"] if f == fmt_var.get() else T["border"])
        for fmt, icon_txt, desc in _FORMAT_META:
            card = self._choice_card(card_row, icon_txt, fmt, desc, title_size=13, ipadx=20, ipady=14, padx=12, desc_pady=(6, 18))
            _cards[fmt] = card
            def _mk_click(f=fmt):
                def _click(e=None): fmt_var.set(f)
                return _click
            click_fn = _mk_click(); card.bind("<Button-1>", click_fn)
            for child in card.winfo_children(): child.bind("<Button-1>", click_fn)
            def _enter(e, c=card, f=fmt):
                if f != fmt_var.get(): c.configure(highlightbackground=T["accent_hi"])
            card.bind("<Enter>", _enter)
            card.bind("<Leave>", lambda e: _refresh_cards())
        fmt_var.trace_add("write", _refresh_cards); _refresh_cards()
        def _do_export():
            fmt = fmt_var.get(); popup.close(); self._api_export_converted_with(ops, fmt)
        self._popup_foot(popup, ("  Cancel  ", popup.close, "flat"), ("💾  Export  ", _do_export, "accent"))

    def _api_preview_spec(self):
        src = self._api_spec_var.get().strip()
        if not src:
            self._show_warn_popup("Preview", "Set a Spec URL or file path first."); return
        def _load_and_render():
            cfg = self._collect_api_cfg()
            opener, _, hdrs = _make_opener(cfg)
            spec = _api_load_spec(opener, hdrs, cfg, self._emit_log)
            if not spec or not isinstance(spec, dict):
                self._event_queue.put(("log","[api-preview] could not load or parse spec.")); return
            if "item" in spec and "paths" not in spec: fmt = "Postman Collection"
            elif spec.get("openapi","").startswith("3"): fmt = f"OpenAPI {spec.get('openapi','3.x')}"
            elif spec.get("swagger","").startswith("2"): fmt = f"Swagger {spec.get('swagger','2.x')}"
            else: fmt = "Unknown format"
            base = _api_base_url(spec, cfg, src)
            ops = _api_operations(spec, base or "https://example.com", src)
            self._event_queue.put(("api_preview", (fmt, ops, len(ops))))
        self._run_async(_load_and_render, label="spec preview")

    def _api_export_converted_with(self, ops, fmt):
        if fmt == "CSV":
            path = filedialog.asksaveasfilename(title="Export endpoints as CSV", defaultextension=".csv",
                initialfile="endpoints.csv", filetypes=[("CSV","*.csv"),("All","*.*")])
            if not path: return
            import csv
            with open(path,"w",newline="",encoding="utf-8") as f:
                w = csv.DictWriter(f, fieldnames=["method","url","secured","body"]); w.writeheader(); w.writerows(ops)
        elif fmt == "JSON":
            path = filedialog.asksaveasfilename(title="Export endpoints as JSON", defaultextension=".json",
                initialfile="endpoints.json", filetypes=[("JSON","*.json"),("All","*.*")])
            if not path: return
            Path(path).write_text(json.dumps(ops, indent=2), encoding="utf-8")
        elif fmt == "YAML":
            path = filedialog.asksaveasfilename(title="Export endpoints as YAML", defaultextension=".yaml",
                initialfile="endpoints.yaml", filetypes=[("YAML","*.yaml *.yml"),("All","*.*")])
            if not path: return
            lines = ["endpoints:\n"]
            for op in ops:
                lines += [f"  - method: {op['method']}\n", f"    url: '{op['url']}'\n",
                          f"    secured: '{op['secured']}'\n", f"    body: '{op['body']}'\n"]
            Path(path).write_text("".join(lines), encoding="utf-8")
        elif fmt == "Postman v2.1":
            path = filedialog.asksaveasfilename(title="Export as Postman Collection v2.1", defaultextension=".json",
                initialfile="endpoints_postman.json", filetypes=[("JSON / Postman","*.json"),("All","*.*")])
            if not path: return
            items = []
            for op in ops:
                url_parts = op["url"].split("://",1); raw_url = op["url"]
                items.append({"name": f"{op['method']} {raw_url}",
                              "request": {"method": op["method"], "header": [],
                                          "url": {"raw": raw_url,
                                                  "protocol": url_parts[0] if len(url_parts)>1 else "https",
                                                  "host": (url_parts[1].split("/")[0].split(".") if len(url_parts)>1 else []),
                                                  "path": (url_parts[1].split("/")[1:] if len(url_parts)>1 else [])},
                                          "description": f"Auth required: {op['secured']}  Body type: {op['body']}"},
                              "response": []})
            collection = {"info": {"name":"Exported Endpoints",
                                   "schema":"https://schema.getpostman.com/json/collection/v2.1.0/collection.json"},
                          "item": items}
            Path(path).write_text(json.dumps(collection, indent=2), encoding="utf-8")
        else:
            self._show_warn_popup("Export endpoints", f"Unknown format: {fmt}"); return
        self._log_line(f"[api-export] {fmt} → {path}")
        self._show_info_popup("Export complete", f"Saved {len(ops)} endpoint(s) to:\n{path}")

    def _build_tab_static(self, parent):
        self._section_header(parent, "🔍  Static Analysis  (SCA · SAST · Secrets)")
        pad = self._scrollable(parent)

        # ── Top row: target path(s) (left half) + run buttons (right half) ───────
        top_row = tk.Frame(pad, bg=T["bg"]); top_row.pack(fill="x", pady=(0, 8))

        fold = self._side_card(top_row, "TARGET  ·  carpeta(s), archivo(s) o .csproj")
        # Multi-path listbox + scrollbar
        lb_frame = tk.Frame(fold, bg=T["panel_bg"]); lb_frame.pack(fill="x")
        self._static_paths_lb = tk.Listbox(lb_frame, height=4, font=(_FMONO, 9),
                                           bg=T["surface2"], fg=T["text"], selectmode="extended",
                                           highlightthickness=1, highlightbackground=T["border"],
                                           activestyle="none", selectbackground=T["accent"],
                                           selectforeground=T["button_fg"], relief="flat")
        _sb = ttk.Scrollbar(lb_frame, orient="vertical", command=self._static_paths_lb.yview)
        self._static_paths_lb.configure(yscrollcommand=_sb.set)
        self._static_paths_lb.pack(side="left", fill="both", expand=True)
        _sb.pack(side="right", fill="y")

        # Buttons row for path management
        path_btns = tk.Frame(fold, bg=T["panel_bg"]); path_btns.pack(fill="x", pady=(4, 0))

        def _add_folder():
            initial = self._target_var.get() or str(SCRIPT_DIR)
            d = filedialog.askdirectory(title="Agregar carpeta al escaneo", initialdir=initial)
            if d:
                existing = list(self._static_paths_lb.get(0, "end"))
                if d not in existing:
                    self._static_paths_lb.insert("end", d)
                self._target_var.set(d)  # keep _target_var pointing to last selected

        def _add_files():
            initial = self._target_var.get() or str(SCRIPT_DIR)
            files = filedialog.askopenfilenames(
                title="Agregar archivos o .csproj al escaneo",
                initialdir=initial,
                filetypes=[
                    ("Todos los soportados", "*.csproj *.sln *.json *.py *.js *.ts *.cs *.java *.go *.rb *.php"),
                    ("Proyectos Visual Studio", "*.csproj *.sln"),
                    ("Manifiestos de dependencias", "*.json *.xml *.lock *.toml *.gradle"),
                    ("Código fuente", "*.py *.js *.ts *.cs *.java *.go *.rb *.php *.cpp *.c *.h"),
                    ("Todos los archivos", "*.*"),
                ])
            if files:
                existing = list(self._static_paths_lb.get(0, "end"))
                for f in files:
                    # If it's a .csproj, auto-add the containing folder too
                    p = Path(f)
                    if p.suffix.lower() == ".csproj":
                        folder = str(p.parent)
                        if folder not in existing:
                            self._static_paths_lb.insert("end", folder)
                            existing.append(folder)
                            self._log_line(f"[static] .csproj detectado: usando carpeta '{folder}'")
                    else:
                        if f not in existing:
                            self._static_paths_lb.insert("end", f)
                            existing.append(f)
                if files:
                    self._target_var.set(str(Path(files[-1]).parent))

        def _remove_selected():
            # Remove selected items in reverse order to keep indices valid
            sel = list(self._static_paths_lb.curselection())
            for idx in reversed(sel):
                self._static_paths_lb.delete(idx)
            # Update target_var to last remaining
            items = self._static_paths_lb.get(0, "end")
            if items: self._target_var.set(items[-1])

        def _clear_all():
            self._static_paths_lb.delete(0, "end")
            self._target_var.set("")

        # Placeholder text when empty
        def _on_lb_change(*_):
            items = self._static_paths_lb.get(0, "end")
            if not items:
                self._static_paths_lb.insert("end", "  (vacío — agrega carpetas o archivos con los botones de abajo)")
                self._static_paths_lb.itemconfig(0, fg=T["muted"])

        self._btn(path_btns, "📂 + Carpeta", _add_folder, kind="outline").pack(side="left", padx=(0, 4))
        self._btn(path_btns, "📄 + Archivo(s) / .csproj", _add_files, kind="outline").pack(side="left", padx=(0, 4))
        self._btn(path_btns, "✕ Quitar", _remove_selected, kind="flat").pack(side="left", padx=(0, 4))
        self._btn(path_btns, "🗑 Limpiar todo", _clear_all, kind="flat").pack(side="left")

        # If _target_var already has a value (e.g. from app profile), pre-populate
        if self._target_var.get():
            self._static_paths_lb.insert("end", self._target_var.get())

        run_row = tk.Frame(fold, bg=T["panel_bg"]); run_row.pack(fill="x", pady=(8, 0))
        self._lbl(run_row, "Tip: puedes agregar varias carpetas/archivos a la vez.", size=9, fg=T["muted"]).pack(side="left")
        self._static_run_btns = []
        run_btn = self._btn(run_row, "▶  Run Static", lambda: self._start_static_scan({"sca", "code", "secrets"}), kind="accent")
        run_btn.pack(side="right")
        self._static_run_btns.append(run_btn)

        # ── RESULTS — each analysis rendered in the form that suits its data ────
        results_row = tk.Frame(pad, bg=T["bg"]); results_row.pack(fill="x", pady=(0, 8))
        sca_half = tk.Frame(results_row, bg=T["bg"]); sca_half.pack(side="left", fill="both", expand=True, padx=(0, 6))
        sast_half = tk.Frame(results_row, bg=T["bg"]); sast_half.pack(side="left", fill="both", expand=True, padx=(6, 0))

        # SCA → grouped by package (the unit you actually upgrade), fix version surfaced.
        sca_inner, sca_right = self._panel(sca_half, "OPEN-SOURCE (SCA)  ·  grouped by package", pady=(0, 0))
        self._sca_summary = tk.Label(sca_right, text="no findings", font=(_FUI, 9, "bold"),
                                     bg=T["accent"], fg=T["button_fg"]); self._sca_summary.pack(side="right")
        self._static_sca_tree = self._group_tree(
            sca_inner, ("Package  /  Vulnerability", 220), ("sev", "fix"),
            [("Severity", 90, "w", False), ("Fix available", 140, "w", False)], height=7)
        self._tree_empty(self._static_sca_tree)

        # SAST → grouped by file (where the weakness lives), line surfaced on each leaf.
        sast_inner, sast_right = self._panel(sast_half, "STATIC CODE (SAST)  ·  grouped by file", pady=(0, 0))
        self._sast_summary = tk.Label(sast_right, text="no findings", font=(_FUI, 9, "bold"),
                                      bg=T["accent"], fg=T["button_fg"]); self._sast_summary.pack(side="right")
        self._static_sast_tree = self._group_tree(
            sast_inner, ("File  /  Finding", 220), ("sev", "line"),
            [("Severity", 90, "w", False), ("Line", 70, "center", False)], height=7)
        self._tree_empty(self._static_sast_tree)

        # Secrets → few + urgent: one alert card each, redacted value in monospace.
        sec_inner, sec_right = self._panel(pad, "SECRETS  ·  exposed credentials", pady=(0, 0))
        self._secrets_summary = tk.Label(sec_right, text="no findings", font=(_FUI, 9, "bold"),
                                         bg=T["accent"], fg=T["button_fg"]); self._secrets_summary.pack(side="right")
        self._secrets_box = tk.Frame(sec_inner, bg=T["panel_bg"]); self._secrets_box.pack(fill="both", expand=True)
        self._lbl(self._secrets_box, "No secrets found — run a scan.", size=10, fg=T["muted"], anchor="w").pack(fill="x")

    def _start_static_scan(self, sel: set):
        if self._static_busy:
            self._log_line("[static] a scan is already running"); return

        # Collect paths from the multi-path listbox
        raw_paths = list(getattr(self, "_static_paths_lb", None) and
                         self._static_paths_lb.get(0, "end") or [])
        # Filter out the placeholder text
        paths = [p for p in raw_paths if p.strip() and not p.strip().startswith("(vacío")]
        if not paths:
            # Fallback to _target_var for backward compat (e.g. loaded from app profile)
            tv = self._target_var.get().strip()
            if tv: paths = [tv]
        if not paths:
            self._show_warn_popup("Static analysis",
                "No hay carpetas o archivos seleccionados.\n\n"
                "Usa '📂 + Carpeta' o '📄 + Archivo(s) / .csproj' para agregar destinos."); return

        # Validate paths
        valid_paths = []
        for p in paths:
            pp = Path(p).resolve()
            if pp.exists():
                valid_paths.append(pp)
            else:
                self._log_line(f"[static] ⚠ ruta no encontrada, se omite: {p}")
        if not valid_paths:
            self._show_warn_popup("Static analysis",
                "Ninguna de las rutas seleccionadas existe en disco.\n\n"
                "Verifica las rutas y vuelve a intentarlo."); return

        # Use first valid path as the primary target for the scan engine
        # (scan_path supports one dir; for multi-path we run it per-path)
        target = valid_paths[0]
        self._target_var.set(str(target))

        # Store multi-paths for multi-pass scanning
        self._static_scan_paths = valid_paths

        # SCA/SAST need a logged-in Snyk session (the CLI itself is installed at boot).
        if {"sca", "code"} & sel:
            checks = self._checks or {}
            auth_ok = bool(checks.get("auth") and checks["auth"].ok)
            if not auth_ok:
                self._show_warn_popup("Static analysis",
                    "SCA y SAST necesitan una sesión SSO activa en Snyk.\n\n"
                    "Ve al tab ▶ Scan → Prerequisites y haz clic en '🔑 Login via SSO'.")
                return
        self._static_run_sel = sel
        self._static_busy = True
        for b in getattr(self, "_static_run_btns", []):
            b.config(state="disabled")
        if hasattr(self, "_static_count_lbl"):
            self._static_count_lbl.config(text="Scanning… (" + " + ".join(sorted(sel)).upper() + ")")
        self._run_async(self._static_scan, label="static analysis")

    def _static_scan(self):
        """Run the selected folder-based analyses (SCA / SAST / Secrets) through
        the same unified report pipeline used by the Scan-tab pipeline."""
        self._cancel_evt.clear()
        sel = getattr(self, "_static_run_sel", {"sca", "code", "secrets"})
        target = Path(self._target_var.get()).resolve()
        reports_root = Path(self._reports_var.get()).resolve(); reports_root.mkdir(parents=True, exist_ok=True)
        active_app = getattr(self, "_active_app", None)
        _report_label, app_reports_root = self._scoped_report_paths(reports_root)
        mode = "+".join(sorted(sel))
        out_dir = app_reports_root / f"report_{_ts()}_{mode}"; out_dir.mkdir(parents=True, exist_ok=True)
        self._emit_log(f"[static] pipeline: {mode.upper()}")
        self._emit_log(f"[static] output → {out_dir}")
        _snyk_usable = True
        if {"sca", "code"} & sel:
            try:
                if not ensure_snyk_ready(self._emit_log):
                    _snyk_usable = False
                    self._emit_log("[static] Snyk CLI is not runnable — "
                                   "skipping SCA/SAST. Click Fix to repair it.")
            except Exception as e:
                self._emit_log(f"[static] snyk readiness check error: {e!r}")
        try: v = _run(["snyk", "--version"]).stdout.strip()
        except Exception: v = "?"

        results: dict[str, Any] = {"sca": None, "code": None, "dast": None, "api": None, "secrets": None}
        for k in ("sca", "code", "secrets"):
            running = k in sel and (_snyk_usable or k == "secrets")
            self._event_queue.put(("stage", (k, "running" if running else "skipped")))

        jobs: list[tuple[str, Callable[[], None]]] = []
        if "sca" in sel and _snyk_usable:
            jobs.append(("sca", lambda: results.__setitem__(
                "sca", run_snyk_test(target, out_dir, self._emit_log)[0])))
        if "code" in sel and _snyk_usable:
            jobs.append(("code", lambda: results.__setitem__(
                "code", run_snyk_code(target, out_dir, self._emit_log)[0])))
        if "secrets" in sel:
            def _run_secrets_stage():
                self._emit_log("[secrets] running secret scan…")
                result = scan_path(target, self._emit_log, cancel=self._cancel_evt,
                                   git_secrets_status=get_git_secrets_status())
                sec_dir = out_dir / "secrets"
                write_secrets_report(result, sec_dir)
                self._emit_log(f"[secrets] {result['total']} finding(s) across "
                               f"{result['scanned_files']} file(s)")
                results["secrets"] = result
            jobs.append(("secrets", _run_secrets_stage))

        def run_stage(item):
            key, fn = item
            try:
                fn(); self._event_queue.put(("stage", (key, "done")))
            except Exception as e:
                self._event_queue.put(("stage", (key, "failed")))
                self._emit_log(f"[static] {key} failed: {e!r}")
                if getattr(e, "is_auth", False):
                    self._event_queue.put(("auth_required", None))

        try:
            if len(jobs) > 1:
                self._emit_log(f"[static] running {len(jobs)} analyses concurrently")
                with ThreadPoolExecutor(max_workers=len(jobs)) as ex_:
                    list(ex_.map(run_stage, jobs))
            else:
                for j in jobs: run_stage(j)

            # Persist each completed kind so later cumulative reports stay complete.
            state = self._scan_state
            for kind in ("sca", "code", "secrets"):
                raw = results.get(kind)
                if raw is not None:
                    try:
                        state.save_kind(kind, raw, target=str(target), snyk_version=v, mode=mode)
                        self._emit_log(f"[state] {kind} result persisted")
                    except Exception as e:
                        self._emit_log(f"[state] could not save {kind}: {e!r}")

            ctx = build_cumulative_context(state, target_hint=target,
                                           snyk_version_hint=v, current_results=results)
            ctx["scan_mode"] = mode
            self._emit_log("[report] building cumulative report (all scan types merged)")
            _base = _report_basename(self._user, mode)
            report_html = render_html(ctx, out_dir, filename=f"{_base}.html")
            self._emit_log(f"[report] HTML → {report_html}")
            try:
                csv_path = export_csv(ctx, out_dir / f"{_base}.csv", report_label=_report_label)
                self._emit_log(f"[report] CSV bundle (ZIP): {csv_path}")
            except Exception as e:
                self._emit_log(f"[report] CSV export skipped: {e!r}")
            sec_html_src = out_dir / "secrets" / "secrets.html"
            if sec_html_src.exists():
                try:
                    sec_html_dst = out_dir / f"{_base}_secrets.html"
                    shutil.copyfile(sec_html_src, sec_html_dst)
                    self._emit_log(f"[report] Secrets HTML → {sec_html_dst}")
                except Exception as e:
                    self._emit_log(f"[report] secrets HTML copy skipped: {e!r}")
            try:
                sarif_path = export_sarif(out_dir)
                if sarif_path: self._emit_log(f"[report] SARIF: {sarif_path}")
            except Exception as e:
                self._emit_log(f"[report] SARIF export skipped: {e!r}")
            try:
                merged_path = export_merged_json(out_dir)
                if merged_path: self._emit_log(f"[report] merged JSON: {merged_path}")
            except Exception as e:
                self._emit_log(f"[report] merged JSON skipped: {e!r}")

            meta = {
                "generated_at": ctx["generated_at"], "target": ctx["target"], "mode": mode,
                "counts": ctx["counts"], "total": ctx["total"],
                "sca_total": ctx.get("sca_total", 0), "code_total": ctx.get("code_total", 0),
                "dast_total": ctx.get("dast_total", 0), "api_total": ctx.get("api_total", 0),
                "secrets_total": ctx.get("secrets_total", 0), "snyk_version": ctx.get("snyk_version", ""),
            }
            (out_dir / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
            try:
                rec = update_history_after_scan(reports_root, ctx, meta,
                                                actor=getattr(self, "_user", ""), report_dir=out_dir)
                self._emit_log(f"[history] recorded — remediated {rec.get('remediated_count', 0)}, "
                               f"new {rec.get('introduced_count', 0)}")
            except Exception as e:
                self._emit_log(f"[history] could not update: {e!r}")
            if active_app and active_app.get("id"):
                try:
                    self._inv_store.record_scan(active_app["id"], meta)
                    self._event_queue.put(("inv_refresh", active_app["id"]))
                except Exception as e:
                    self._emit_log(f"[inventory] could not update: {e!r}")

            self._last_context = ctx; self._last_report_dir = out_dir
            self._last_static_report = Path(report_html)
            self._event_queue.put(("static_results", ctx))
            self._event_queue.put(("report", str(report_html)))
        except Exception as e:
            self._emit_log(f"[static] scan failed: {e!r}")
            self._event_queue.put(("static_results", None))

    def _build_tab_reports(self, parent):
        self._section_header(parent, '📋  Reports')
        pad = self._scrollable(parent)

        folder_card = self._card(pad, 'REPORTS FOLDER', pady=(0, 14))
        fr = tk.Frame(folder_card, bg=T["panel_bg"]); fr.pack(fill="x")
        self._reports_entry = ttk.Entry(fr, textvariable=self._reports_var)
        self._reports_entry.pack(side="left", fill="x", expand=True, padx=(0, 6))
        def _browse_rep():
            d = filedialog.askdirectory(title="Select reports folder",
                                        initialdir=self._reports_var.get() or str(SCRIPT_DIR))
            if d: self._reports_var.set(d); self._reports_root = Path(d)
        self._btn(fr, "Browse…", _browse_rep, kind="flat").pack(side="left")
        self._auto_open_var = tk.BooleanVar(value=self._auto_open)
        def _on_auto_open_change():
            self._auto_open = bool(self._auto_open_var.get()); self._save_settings()
        auto_row = tk.Frame(folder_card, bg=T["panel_bg"]); auto_row.pack(fill="x", pady=(8, 0))
        self._btn(auto_row, '📋 Reports viewer', lambda: ReportsViewer(self, Path(self._reports_var.get()).resolve()),
                  kind="accent").pack(side="left")
        self._btn(auto_row, "🌐 Open HTML", self._open_selected_html_report, kind="accent").pack(side="left", padx=(8, 0))
        self._btn(auto_row, "🩹 Remediation history", self._open_remediation_history, kind="flat").pack(side="left", padx=(8, 0))
        ttk.Checkbutton(auto_row, text='Auto-open report after scan',
                        variable=self._auto_open_var, command=_on_auto_open_change).pack(side="left", padx=(14, 0))

        rec_card = self._card(pad, 'RECENT SCANS', pady=(0, 0))
        rec_actions = tk.Frame(rec_card, bg=T["panel_bg"]); rec_actions.pack(side="bottom", fill="x", pady=(8, 0))
        self._btn(rec_actions, '🗑 Delete selected', self._delete_rep_tree_sel, kind="flat").pack(side="left")
        self._btn(rec_actions, '📁 Open Folder', self._open_rep_tree_sel_folder, kind="flat").pack(side="left", padx=(8, 0))
        tree_frame = tk.Frame(rec_card, bg=T["panel_bg"]); tree_frame.pack(fill="both", expand=True)
        cols = ("when","mode","total","crit","high","med","low","target")
        self._rep_tree = _make_tree(tree_frame, cols,
            [("Generated",150),("Mode",80),("Total",55),("Crit",45),("High",45),("Med",45),("Low",45),("Target",300)], height=6)
        self._rep_tree.bind("<Double-1>", lambda _: self._open_rep_tree_sel())
        self._refresh_rep_tree()

    @staticmethod
    def _list_report_dirs(root: Path, limit: int = 0) -> list[Path]:
        if not root.exists(): return []
        try:
            items = sorted([p for p in root.iterdir() if p.is_dir() and p.name.startswith("report_")],
                           key=lambda p: p.stat().st_mtime, reverse=True)
            return items[:limit] if limit else items
        except OSError: return []

    def _refresh_recent(self):
        if not hasattr(self, "_recent_lb"): return
        self._recent_lb.delete(0, "end")
        root = Path(self._reports_var.get())
        items = self._list_report_dirs(root, limit=6); self._recent_paths = items
        if not items:
            self._recent_lb.insert("end", '(no reports yet — run a scan)'); return
        for p in items: self._recent_lb.insert("end", p.name)

    def _refresh_rep_tree(self):
        if not hasattr(self, "_rep_tree"): return
        for iid in self._rep_tree.get_children(): self._rep_tree.delete(iid)
        root = Path(self._reports_var.get())
        active_app = getattr(self, "_active_app", None)
        if active_app and active_app.get("name"):
            _app_slug = _re.sub(r"[^A-Za-z0-9\-_]", "_", active_app["name"].strip())
            scoped_root = root / _app_slug
        else:
            scoped_root = root / "_unscoped"
        for d in self._list_report_dirs(scoped_root, limit=50):
            _fill_tree_row(self._rep_tree, d)

    def _open_rep_tree_sel(self):
        sel = self._rep_tree.selection()
        if not sel: return
        html = _find_report_html(Path(sel[0]))
        if html: _open_path(html)

    def _open_selected_html_report(self):
        """Open HTML report for selected report in recent scans tree, or warn if none selected."""
        sel = self._rep_tree.selection()
        if not sel:
            self._show_warn_popup("Open HTML",
                "Selecciona primero un reporte en la lista 'Recent Scans' y luego haz clic en 'Open HTML'.")
            return
        d = Path(sel[0])
        html = _find_report_html(d)
        if html:
            _open_path(html)
        else:
            self._show_warn_popup("Open HTML", f"No se encontró archivo HTML en:\n{d}")

    def _open_rep_tree_sel_folder(self):
        _open_selected_report_folder(self, self._rep_tree)

    def _delete_rep_tree_sel(self):
        _delete_selected_report(self, self._rep_tree, self._refresh_rep_tree, self._refresh_recent)

    def _open_remediation_history(self):
        root = Path(self._reports_var.get()).resolve()
        try:
            hist = load_history(root)
            if not hist.get("scans") and not hist.get("actions"):
                self._show_info_popup("Remediation history",
                    "No history yet. Run a scan first — each scan is recorded and "
                    "compared against the previous one to track remediations.")
                return
            out = render_remediation_history(root)
            self._log_line(f"[history] {out}")
            _open_path(out)
        except Exception as e:
            self._show_error_popup("Remediation history", f"Could not build:\n{e!r}")

    def _build_tab_apps(self, parent):
        """Build the Application Inventory tab using the app_inventory module."""
        from app_inventory import AppInventoryTab
        self._inv_tab = AppInventoryTab(parent=parent, master=self, store=self._inv_store,
                                        on_load_app=self._load_app_profile)

    def _load_app_profile(self, app: dict, *, silent: bool = False) -> None:
        """Called by AppInventoryTab on '▶ Load into Scanner' — push the app config into the scanner vars."""
        self._active_app = app
        if app.get("target_path"): self._target_var.set(app["target_path"])
        if app.get("dast_url"): self._dast_url_var.set(app["dast_url"])
        if app.get("api_spec"): self._api_spec_var.set(app["api_spec"])
        for k, var in self._scan_vars.items():
            var.set(k in app.get("scan_stages", ["sca", "code"]))
        self._refresh_stage_cards()
        self._refresh_scan_btn()
        self._refresh_active_app_banner()
        self._update_window_title()
        self._last_app_id = app.get("id")
        self._save_settings()
        if silent:
            return
        self._show_tab("scan")
        self._show_info_popup("App Profile Loaded",
            f"Profile '{app['name']}' is now active.\n\n"
            f"Target: {app.get('target_path') or '(not set)'}\n"
            f"DAST URL: {app.get('dast_url') or '(not set)'}\n"
            f"API Spec: {app.get('api_spec') or '(not set)'}\n"
            f"Stages: {', '.join(app.get('scan_stages', []))}\n\n"
            "Scan results will be recorded in the app's inventory record.")

    def _update_window_title(self) -> None:
        """Window title is the brand name, plus the active app once one is loaded."""
        app = getattr(self, "_active_app", None)
        name = app.get("name") if app else None
        self.title(f"{APP_BRAND_NAME} - ({name})" if name else APP_BRAND_NAME)

    def _auto_load_last_app(self) -> None:
        """On startup, silently reload whichever app profile was active last time."""
        app_id = getattr(self, "_last_app_id", None)
        if not app_id:
            self._update_window_title(); return
        try:
            app = self._inv_store.get_app(app_id)
        except Exception:
            app = None
        if app:
            self._load_app_profile(app, silent=True)
            self._log_line(f"[apps] auto-loaded last profile: {app.get('name')}")
        else:
            self._update_window_title()

    def _refresh_active_app_banner(self) -> None:
        """Refresh the Active App banner on the Scan tab (after profile load and after each scan)."""
        lbl = getattr(self, "_active_app_lbl", None)
        if not lbl: return
        app = getattr(self, "_active_app", None)
        if not app:
            lbl.config(text="None — go to 📦 Apps tab to load a profile", fg=T["muted"]); return
        try:
            tier = app.get("risk_tier", "None")
            from app_inventory import _RISK_COLORS_LIGHT
            colour = _RISK_COLORS_LIGHT.get(tier, T["accent"])
            ctx = getattr(self, "_last_context", None)
            if ctx:
                c = ctx.get("counts", {})
                crit = c.get("critical", app.get("vuln_critical", 0)); high = c.get("high", app.get("vuln_high", 0))
                med = c.get("medium", app.get("vuln_medium", 0)); low = c.get("low", app.get("vuln_low", 0))
            else:
                crit = app.get("vuln_critical", 0); high = app.get("vuln_high", 0)
                med = app.get("vuln_medium", 0); low = app.get("vuln_low", 0)
            lbl.config(text=f"{app['name']}  ·  {app.get('criticality', '')}  ·  Risk: {tier}  ·  "
                            f"C:{crit} H:{high} M:{med} L:{low}", fg=colour)
        except Exception:
            lbl.config(text=app.get("name", ""), fg=T["accent"])

    def _refresh_stage_cards(self):
        """Re-paint every pipeline stage card so it visually matches its
        BooleanVar — used after something other than a click changes
        _scan_vars (e.g. loading an app profile)."""
        for key, apply_fn in getattr(self, "_stage_apply", {}).items():
            try:
                apply_fn(bool(self._scan_vars[key].get()))
            except Exception:
                pass

    def _refresh_scan_btn(self):
        if not hasattr(self, "_scan_btn"): return
        sel = {k for k, v in self._scan_vars.items() if v.get()}
        if not sel:
            self._scan_btn.config(state="disabled")
            if hasattr(self, "_run_icon_btn"):
                self._run_icon_btn.config(state="disabled", fg=T["muted"], highlightbackground=T["muted"],
                                          highlightcolor=T["muted"], bg="#ffffff")
            return
        needs_snyk = bool({"sca","code"} & sel)
        checks = self._checks or {}
        auth_ok = bool(checks.get("auth") and checks["auth"].ok)
        ready = (not needs_snyk) or auth_ok
        self._scan_btn.config(state="normal" if ready else "disabled")
        if hasattr(self, "_run_icon_btn"):
            if ready:
                self._run_icon_btn.config(state="normal", fg=T["accent"], highlightbackground=T["accent"],
                                          highlightcolor=T["accent"], bg="#ffffff",
                                          activebackground=T["surface2"], activeforeground=T["accent"])
            else:
                self._run_icon_btn.config(state="disabled", fg=T["muted"], highlightbackground=T["muted"],
                                          highlightcolor=T["muted"], bg="#ffffff")

    def _recheck(self):
        # Deps (python/node/npm/snyk) are installed by the boot splash; only the
        # login state can change at runtime, so that's all we re-verify here.
        self._event_queue.put(("checks", {"auth": check_auth()}))

    def _apply_checks(self, results: dict[str, CheckResult]):
        self._checks = results
        for key, res in results.items():
            row = self._check_rows.get(key)
            if not row: continue
            row["status"].config(text="●", fg=T["ok"] if res.ok else (
                T["muted"] if not res.detail or res.detail == "…" else T["err"]))
            row["detail"].config(text=res.detail or ("ready" if res.ok else "not configured"))
            row["fix"].config(state="disabled" if (res.ok or not res.fixable) else "normal")

        auth_res = results.get("auth")
        auth_ok = bool(auth_res and auth_res.ok)

        # ── SSO enforcement: if authenticated but NOT via SSO/OAuth, reject it ──
        sso_ok = False
        if auth_ok:
            detail_low = (auth_res.detail or "").lower()
            if "sso" in detail_low or "oauth" in detail_low:
                sso_ok = True
            else:
                # Non-SSO token detected — treat as not-authenticated and warn
                auth_ok = False
                sso_ok = False
                row = self._check_rows.get("auth")
                if row:
                    row["status"].config(text="●", fg=T["err"])
                    row["detail"].config(text="⚠ Token detected — se requiere SSO")
                    row["fix"].config(state="normal")
                self._log_line(
                    "[auth] ⚠ Se detectó un token API pero NO una sesión SSO/OAuth. "
                    "Haz clic en '🔁 Re-login (SSO)' y en la ventana de Snyk elige "
                    "'Login via SSO' (la opción en gris, debajo de 'Log in with Google'). "
                    "Un token normal no es suficiente para escaneos de organización.")

        prereq_hdr = getattr(self, "_prereq_hdr_frame", None)
        prereq_warn = getattr(self, "_prereq_warn_lbl", None)
        if prereq_hdr and prereq_warn:
            if not auth_ok:
                prereq_hdr.config(bg=T["err"]); prereq_warn.config(bg=T["err"], text="⚠ Action needed")
                hdr_lbl = getattr(self, "_prereq_hdr_lbl", None)
                if hdr_lbl: hdr_lbl.config(bg=T["err"])
            else:
                prereq_hdr.config(bg=T["accent"]); prereq_warn.config(bg=T["accent"], text="✔ Ready")
                hdr_lbl = getattr(self, "_prereq_hdr_lbl", None)
                if hdr_lbl: hdr_lbl.config(bg=T["accent"])
        if not auth_ok:
            self._login_btn.config(state="normal", text="🔑 Login via SSO")
        else:
            self._login_btn.config(state="disabled", text="✓ SSO Logged in")
        self._refresh_scan_btn()

    def _fix(self, key: str):
        if key in ("node", "npm", "snyk"):
            self._reinstall_missing_deps(key)
        elif key == "auth":
            self._run_async(self._do_login, label="snyk auth")

    def _reinstall_missing_deps(self, key: str):
        """Re-run the *full* boot installer (pip deps + Node/npm + git-secrets
        + Snyk CLI) inside the same BootSplash window used at startup, instead
        of installing just `key` inline/silently in the main window. Anything
        already satisfied is skipped quickly inside _load_runtime, so this
        stays cheap — but every install, first launch or later fix, always
        happens in that one globe-animation window."""
        if self._busy:
            self._log_line(f"[busy] ignoring fix for '{key}' — another op in progress"); return
        self._busy = True; self._update_stop_btn_style()
        self._set_status(f"Reinstalling dependencies ({key})…")
        try:
            err = run_boot(master=self)  # blocks here, but keeps the UI responsive
        finally:
            self._busy = False; self._update_stop_btn_style()
            self._set_status('Ready.'); self._refresh_scan_btn()
        if err:
            self._log_line(f"[fix] dependency install failed: {err.splitlines()[0]}")
        else:
            self._log_line(f"[fix] dependency check/install finished for '{key}'.")
        self._recheck()

    def _prompt_relogin(self):
        """Called (on the UI thread) when a scan fails because Snyk auth is
        stale/expired. Surface it loudly and point the user at re-login. Runs
        at most once per scan run so concurrent SCA+SAST failures don't stack."""
        if getattr(self, "_relogin_prompted", False):
            return
        self._relogin_prompted = True
        self._set_status("Snyk session expired — click 🔁 Re-login")
        self._log_line("[auth] ⚠ Snyk rejected the saved credential (expired or "
                       "invalid). Click 🔁 Re-login under ▶ Scan → Prerequisites "
                       "to sign in again through your organization's SSO, then "
                       "re-run the scan.")
        # Draw attention to the prereq panel + re-login button.
        try:
            hdr = getattr(self, "_prereq_hdr_frame", None)
            warn = getattr(self, "_prereq_warn_lbl", None)
            if hdr and warn:
                hdr.config(bg=T["err"]); warn.config(bg=T["err"], text="⚠ Re-login needed")
                lbl = getattr(self, "_prereq_hdr_lbl", None)
                if lbl: lbl.config(bg=T["err"])
            if getattr(self, "_relogin_btn", None):
                self._relogin_btn.config(state="normal")
        except Exception:
            pass

    def _do_login(self):
        # Each explicit login resets the one-shot re-login prompt guard.
        self._relogin_prompted = False
        # The only Fix button on the prereq panel triggers login. But login is
        # useless if the Snyk CLI binary itself can't run (the common corporate
        # case: npm wrapper present, but its one-time binary download is blocked
        # by a TLS-inspecting proxy). So repair the CLI first, then auth.
        if not _which("snyk") or not ensure_snyk_ready(self._emit_log):
            self._emit_log("[auth] Snyk CLI is not runnable yet — could not "
                           "repair it automatically. If your network uses a "
                           "TLS-inspecting proxy, set NODE_EXTRA_CA_CERTS to "
                           "your company root CA .pem and retry.")
            return
        if self._auth_proc and self._auth_proc.poll() is None:
            self._emit_log("[auth] auth already in progress"); return
        # Force a clean sign-in: clear any stale/expired credential first so the
        # org's SSO/OAuth flow takes precedence over a leftover manual API token
        # (which otherwise keeps overriding SSO and failing every scan).
        clear_snyk_credentials(self._emit_log)
        self._auth_proc = start_snyk_auth(self._emit_log)
        self._auth_deadline = time.time() + AUTH_POLL_TIMEOUT
        self._event_queue.put(("status","Waiting for Snyk auth in browser…"))

    def _tick_auth_poll(self):
        proc = self._auth_proc
        if proc is None: return
        try:
            if proc.stdout and not proc.stdout.closed:
                line = proc.stdout.readline()
                if line: self._log_line(line.rstrip())
        except Exception: pass
        now = time.time()
        if not hasattr(self, "_next_auth_check") or now >= self._next_auth_check:
            self._next_auth_check = now + AUTH_POLL_INTERVAL
            if check_auth().ok:
                self._log_line("[auth] authenticated.")
                try: proc.terminate()
                except Exception: pass
                self._auth_proc = None; self._recheck(); return
        if proc.poll() is not None:
            self._log_line(f"[auth] snyk auth exited ({proc.returncode})")
            self._auth_proc = None
            self._run_async(self._recheck, label="post-auth recheck"); return
        if now > self._auth_deadline:
            self._log_line("[auth] timeout — cancelling.")
            try: proc.terminate()
            except Exception: pass
            self._auth_proc = None

    def _on_app_close(self):
        """Scrub runtime-only secrets (recorded password, tokens) before exit."""
        try:
            for k in ("password", "token", "selenium_pass_value"):
                if k in self._dast_cred_vars: self._dast_cred_vars[k].set("")
            for k in ("password", "token"):
                if k in getattr(self, "_api_cred_vars", {}): self._api_cred_vars[k].set("")
            self._runtime_pass = ""
        except Exception:
            pass
        try: self.destroy()
        except Exception: pass

    def _refresh_browser_catalog(self) -> list[str]:
        """Detect installed browsers, refresh label↔key maps, return friendly labels for the combobox."""
        catalog = {}
        try:
            catalog = detect_browsers() or {}
        except Exception:
            try:
                from dast_api import detect_browsers as _db
                catalog = _db() or {}
            except Exception:
                catalog = {}
        if not catalog:  # never leave the dropdown empty
            catalog = {"chrome": {"name": "Google Chrome", "binary": "", "engine": "chromium"}}
        self._browser_catalog = catalog
        self._browser_label_key = {info["name"]: key for key, info in catalog.items()}
        labels = [info["name"] for info in catalog.values()]
        cur_key = self._dast_browser_var.get()
        if cur_key not in catalog:
            cur_key = next(iter(catalog)); self._dast_browser_var.set(cur_key)
        self._dast_browser_label_var.set(catalog[cur_key]["name"])
        return labels

    def _collect_dast_cfg(self) -> DastConfig:
        v = self._dast_cred_vars; g = lambda k: v[k].get()
        browser_key = self._dast_browser_var.get() or "chrome"
        browser_bin = (self._browser_catalog.get(browser_key, {}) or {}).get("binary", "")
        return DastConfig(
            url=self._dast_url_var.get().strip(), auth_type=self._dast_auth_var.get(),
            username=g("username"), password=g("password"), token=g("token"),
            cookie=g("cookie"), header_name=g("header_name"), header_value=g("header_value"),
            login_url=g("login_url"), login_data=g("login_data"), profile=self._dast_profile_var.get(),
            max_pages=int(self._dast_pages_var.get() or 30), verify_tls=bool(self._dast_tls_var.get()),
            include_subdomains=bool(self._dast_subs_var.get()), selenium_browser=browser_key,
            selenium_binary=browser_bin, selenium_headless=bool(self._dast_headless_var.get()),
            selenium_wait_seconds=int(self._dast_selwait_var.get() or 15),
            selenium_login_url=g("selenium_login_url"), selenium_user_selector=g("selenium_user_selector"),
            selenium_user_value=g("selenium_user_value"), selenium_pass_selector=g("selenium_pass_selector"),
            selenium_pass_value=g("selenium_pass_value"), selenium_submit_selector=g("selenium_submit_selector"),
            selenium_extra_steps=g("selenium_extra_steps"), selenium_macro=g("selenium_macro"),
            selenium_logout_macro=g("selenium_logout_macro"), login_success_selector=g("login_success_selector"),
            login_success_text=g("login_success_text"), logout_url_re=g("logout_url_re"),
            auto_relogin=bool(self._dast_relogin_var.get()), exclude_re=self._dast_exclude_var.get(),
            rate_limit_rps=float(self._dast_rps_var.get() or 8.0),
            concurrency=int(self._dast_workers_var.get() or 4), proxy=self._dast_proxy_var.get())

    def _collect_api_cfg(self) -> ApiConfig:
        v = self._api_cred_vars
        return ApiConfig(
            spec_source=self._api_spec_var.get().strip(), base_url=self._api_base_var.get().strip(),
            auth_type=self._api_auth_var.get(), username=v["username"].get(), password=v["password"].get(),
            token=v["token"].get(), cookie=v["cookie"].get(), header_name=v["header_name"].get(),
            header_value=v["header_value"].get(), profile=self._api_profile_var.get(),
            max_endpoints=int(self._api_pages_var.get() or 80), verify_tls=bool(self._api_tls_var.get()),
            rate_limit_rps=float(self._api_rps_var.get() or 8.0), concurrency=int(self._api_workers_var.get() or 6),
            proxy=self._api_proxy_var.get(), exclude_re=self._api_exclude_var.get())

    def _dast_save_profile(self):
        cfg = self._collect_dast_cfg()
        data = {k: v for k, v in cfg.__dict__.items() if k not in ("password","token","selenium_pass_value")}
        path = filedialog.asksaveasfilename(title="Save DAST profile", defaultextension=".json",
            initialfile="dast_profile.json", filetypes=[("DAST profile","*.json"),("All","*.*")])
        if not path: return
        Path(path).write_text(json.dumps(data, indent=2), encoding="utf-8")
        self._emit_log(f"[dast] profile saved → {path}  (secrets stripped)")

    def _dast_load_profile(self):
        path = filedialog.askopenfilename(title="Load DAST profile", filetypes=[("DAST profile","*.json"),("All","*.*")])
        if not path: return
        try:
            data = json.loads(Path(path).read_text(encoding="utf-8"))
        except Exception as e:
            self._show_error_popup("Load Profile", f"Cannot read file:\n{e}"); return
        _load_map = [
            (self._dast_url_var,"url",str,""), (self._dast_auth_var,"auth_type",str,"none"),
            (self._dast_profile_var,"profile",str,"passive"), (self._dast_pages_var,"max_pages",int,30),
            (self._dast_subs_var,"include_subdomains",bool,False), (self._dast_tls_var,"verify_tls",bool,True),
            (self._dast_relogin_var,"auto_relogin",bool,True), (self._dast_browser_var,"selenium_browser",str,"chrome"),
            (self._dast_headless_var,"selenium_headless",bool,True), (self._dast_selwait_var,"selenium_wait_seconds",int,15),
            (self._dast_exclude_var,"exclude_re",str,""), (self._dast_rps_var,"rate_limit_rps",float,8.0),
            (self._dast_workers_var,"concurrency",int,4), (self._dast_proxy_var,"proxy",str,""),
        ]
        for var, key, cast, dflt in _load_map:
            var.set(cast(data.get(key, dflt)))
        try:  # re-detect so a profile saved elsewhere still resolves to a local browser
            self._refresh_browser_catalog()
            if getattr(self, "_dast_browser_cb", None) is not None:
                self._dast_browser_cb.config(values=[i["name"] for i in self._browser_catalog.values()])
            bkey = self._dast_browser_var.get()
            if bkey in self._browser_catalog:
                self._dast_browser_label_var.set(self._browser_catalog[bkey]["name"])
        except Exception:
            pass
        for k, var in self._dast_cred_vars.items():
            var.set(str(data.get(k,"")))
        self._refresh_dast_creds()
        self._emit_log(f"[dast] profile loaded ← {path}")

    def _dast_save_condition(self, keys, name, initialfile, note=""):
        data = {k: self._dast_cred_vars[k].get() for k in keys if k in self._dast_cred_vars}
        # Passwords are NEVER written to disk — strip any typed password from the recorded macro too.
        if data.get("selenium_macro"):
            try:
                steps = json.loads(data["selenium_macro"])
                for s in steps:
                    if isinstance(s, dict) and s.get("kind") == "field" and (
                            s.get("role") == "password" or s.get("ftype") == "password"):
                        s["value"] = ""  # re-injected at runtime
                data["selenium_macro"] = json.dumps(steps)
            except Exception:
                pass
        path = filedialog.asksaveasfilename(title=f"Save {name}", defaultextension=".json",
            initialfile=initialfile, filetypes=[(name.capitalize(),"*.json"),("All","*.*")])
        if not path: return
        Path(path).write_text(json.dumps(data, indent=2), encoding="utf-8")
        self._emit_log(f"[dast] {name} saved → {path}{note}")

    def _dast_load_condition(self, keys, name):
        path = filedialog.askopenfilename(title=f"Load {name}", filetypes=[(name.capitalize(),"*.json"),("All","*.*")])
        if not path: return
        try:
            data = json.loads(Path(path).read_text(encoding="utf-8"))
        except Exception as e:
            self._show_error_popup(f"Load {name.title()}", f"Cannot read file:\n{e}"); return
        applied = [k for k in keys if k in data and k in self._dast_cred_vars
                   and (self._dast_cred_vars[k].set(str(data[k])) or True)]
        self._refresh_dast_creds()
        self._emit_log(f"[dast] {name} loaded ← {path}  (fields: {', '.join(applied) or 'none'})")

    def _dast_save_login_condition(self):
        self._dast_save_condition(self._LOGIN_CONDITION_KEYS, "login condition",
                                  "dast_login_condition.json", "  (password value excluded)")
    def _dast_load_login_condition(self):
        self._dast_load_condition(self._LOGIN_CONDITION_KEYS, "login condition")
    def _dast_save_logout_condition(self):
        self._dast_save_condition(self._LOGOUT_CONDITION_KEYS, "logout condition", "dast_logout_condition.json")
    def _dast_load_logout_condition(self):
        self._dast_load_condition(self._LOGOUT_CONDITION_KEYS, "logout condition")

    def _record_in_browser(self, err_title, popup_title, instructions, work, *, w_pct=0.32, h_pct=0.30):
        """Launch browser + a small evasive floating HUD (non-modal; dodges the mouse) for recording."""
        url = (self._dast_cred_vars["selenium_login_url"].get().strip() or self._dast_url_var.get().strip())
        if not url or url == "https://":
            self._show_error_popup(err_title, "Set a Target URL or Login page URL first."); return None
        done = threading.Event(); result: dict = {}
        # Worker thread never touches Tk; it writes the latest message here and a Tk poller copies it.
        status_box: dict = {"msg": None, "shown": None}
        def _emit_status(msg: str): status_box["msg"] = msg
        driver_ready = threading.Event()

        def runner():
            try:
                drv = _make_driver(self._collect_dast_cfg(), headless=False, log=self._emit_log)
                result["_driver"] = drv; driver_ready.set()
                try:
                    work(drv, url, done, result, _emit_status)
                finally:
                    try: drv.quit()
                    except Exception: pass
            except Exception as e:
                result["error"] = repr(e); driver_ready.set()
            finally:
                done.set()

        t = threading.Thread(target=runner, daemon=True); t.start()
        HUD_W, HUD_H = 360, 105
        PADDING = 14
        CORNERS = ["ne", "nw", "sw", "se"]
        hud = tk.Toplevel(self)
        hud.overrideredirect(True); hud.attributes("-topmost", True)
        hud.attributes("-alpha", 0.90); hud.resizable(False, False)
        hud._corner_idx = [0]  # starts at NE

        def _place_hud(corner: str):
            sw = hud.winfo_screenwidth(); sh = hud.winfo_screenheight()
            if corner == "ne":   x, y = sw - HUD_W - PADDING, PADDING
            elif corner == "nw": x, y = PADDING, PADDING
            elif corner == "sw": x, y = PADDING, sh - HUD_H - PADDING
            else:                x, y = sw - HUD_W - PADDING, sh - HUD_H - PADDING
            hud.geometry(f"{HUD_W}x{HUD_H}+{x}+{y}")

        def _dodge(event=None):
            idx = (hud._corner_idx[0] + 1) % len(CORNERS)
            hud._corner_idx[0] = idx; _place_hud(CORNERS[idx])

        _place_hud(CORNERS[0])
        outer = tk.Frame(hud, bg=T["accent"], padx=1, pady=1); outer.pack(fill="both", expand=True)
        inner = tk.Frame(outer, bg=T["panel_bg"], padx=10, pady=8); inner.pack(fill="both", expand=True)
        tk.Label(inner, text=popup_title, font=(_FUI, 10, "bold"), bg=T["panel_bg"], fg=T["accent"]).pack(anchor="w")
        status_var = tk.StringVar(value="⏳  Opening browser…")
        tk.Label(inner, textvariable=status_var, font=(_FUI, 9), bg=T["panel_bg"], fg=T["muted"],
                 wraplength=HUD_W - 24).pack(anchor="w", pady=(2, 4))
        hotkey_lbl = tk.Label(inner, text="Ctrl+Shift+F12  →  capture     Ctrl+Shift+F11  →  cancel",
                              font=(_FUI, 8), bg=T["panel_bg"], fg=T["muted"])
        hotkey_lbl.pack(anchor="w")
        for widget in (hud, outer, inner, hotkey_lbl): widget.bind("<Enter>", _dodge, "+")
        cancelled = [False]; ready = [False]
        _hotkey_stop = threading.Event(); _hotkey_cancel = threading.Event()

        # Global hotkey via pynput (works even when browser has focus): Ctrl+Shift+F12 capture, F11 cancel.
        def _pynput_listener():
            try:
                from pynput import keyboard as _kb
                _pressed = set()
                def _on_press(key):
                    _pressed.add(key)
                    ctrl = any(k in _pressed for k in (_kb.Key.ctrl, _kb.Key.ctrl_l, _kb.Key.ctrl_r))
                    shift = any(k in _pressed for k in (_kb.Key.shift, _kb.Key.shift_l, _kb.Key.shift_r))
                    if ctrl and shift:
                        if key == _kb.Key.f12: _hotkey_stop.set()
                        elif key == _kb.Key.f11: _hotkey_cancel.set()
                def _on_release(key): _pressed.discard(key)
                with _kb.Listener(on_press=_on_press, on_release=_on_release) as lst:
                    while not done.is_set():
                        if done.wait(0.2): break
                    lst.stop()
            except Exception as ex:
                self._emit_log(f"[hotkey] pynput unavailable ({ex!r}) — "
                               "press Ctrl+Shift+F12 while the Scanner window is focused")

        threading.Thread(target=_pynput_listener, daemon=True).start()

        def _on_key_tk(event):  # fallback binding when Scanner window has focus
            ctrl = bool(event.state & 0x4); shift = bool(event.state & 0x1)
            if ctrl and shift and event.keysym == "F12": _hotkey_stop.set()
            elif ctrl and shift and event.keysym == "F11": _hotkey_cancel.set()

        _key_bind_id = self.bind("<KeyPress>", _on_key_tk, "+")
        hud.bind("<KeyPress>", _on_key_tk, "+")

        def _poll_hotkeys():
            if _hotkey_cancel.is_set():
                cancelled[0] = True; done.set(); return
            if _hotkey_stop.is_set() and ready[0]:
                done.set(); return
            hud.after(150, _poll_hotkeys)

        hud.after(150, _poll_hotkeys)

        def _poll_ready():
            if driver_ready.is_set():
                if "error" not in result:
                    if status_box.get("msg") is None:  # don't stomp a worker-emitted status
                        status_var.set("✅  Browser open — interact freely")
                    ready[0] = True
                else:
                    status_var.set("❌  Browser failed")
                return
            hud.after(200, _poll_ready)

        hud.after(200, _poll_ready)

        def _poll_status():
            m = status_box.get("msg")
            if m is not None and m != status_box.get("shown"):
                status_var.set(m); status_box["shown"] = m
            if not (done.is_set() or cancelled[0]): hud.after(180, _poll_status)

        hud.after(180, _poll_status)

        def _poll_done():
            if done.is_set() or cancelled[0]:
                try: self.unbind("<KeyPress>", _key_bind_id)
                except Exception: pass
                try: hud.destroy()
                except Exception: pass
                return
            hud.after(300, _poll_done)

        hud.after(300, _poll_done)
        self.wait_window(hud)  # block until recording is done
        t.join(timeout=10)
        if cancelled[0] or "error" in result:
            if "error" in result:
                self._show_error_popup(err_title, f"Browser failed:\n{result['error']}")
            return None
        result["_url"] = url
        return result

    def _dast_record_macro(self):
        work = record_macro_work(self._collect_dast_cfg(), emit_log=self._emit_log)  # engine-side factory, no GUI
        result = self._record_in_browser("Record Login Condition", "⏺ Login Condition",
                                         [], work, w_pct=0.32, h_pct=0.30)
        if result is None: return False  # cancelled or error — no palomita
        url = result["_url"]
        try: macro = json.loads(result.get("macro") or "[]")
        except Exception: macro = []
        if not isinstance(macro, list): macro = []
        macro = [s for s in macro if isinstance(s, dict)]
        user_sel, user_val, pass_sel, pass_val, submit_sel = self._analyze_login_macro(macro)
        # A login submitted with Enter (or whose button can't be pinned) is replayed via the form, not a click.
        submit_extra = None
        if not submit_sel:
            sub = next((s for s in macro if s.get("kind") == "submit"), None)
            ent = next((s for s in macro if s.get("kind") == "enter"), None)
            if sub and sub.get("button"): submit_sel = sub["button"]
            elif sub and sub.get("form"): submit_extra = {"submit": sub["form"]}
            elif ent and ent.get("form"): submit_extra = {"submit": ent["form"]}
            elif ent: submit_extra = {"key": "Enter", "selector": ent.get("selector") or pass_sel}
        if user_sel: self._dast_cred_vars["selenium_user_selector"].set(user_sel)
        if user_val: self._dast_cred_vars["selenium_user_value"].set(user_val)
        if pass_sel: self._dast_cred_vars["selenium_pass_selector"].set(pass_sel)
        if pass_val: self._dast_cred_vars["selenium_pass_value"].set(pass_val)  # session-only; stripped from saves
        self._dast_cred_vars["selenium_submit_selector"].set(submit_sel or "")
        if not self._dast_cred_vars["selenium_login_url"].get():
            self._dast_cred_vars["selenium_login_url"].set(url)
        # Extra steps = other meaningful fields/clicks minus user/pass/submit and minus anything logout-like.
        _LOGOUT_RE = _re.compile(
            r"(?i)(logout|log[\s_-]?out|sign[\s_-]?out|signoff|cerrar[\s_-]?sesi[oó]n|salir)")
        extras: list = []
        for s in macro:
            kind = s.get("kind"); sel = s.get("selector")
            if kind == "field" and sel and sel not in (user_sel, pass_sel) \
                    and s.get("role") != "password" and s.get("value"):
                extras.append({"selector": sel, "value": s["value"]})
            elif kind == "click" and sel and sel != submit_sel:
                blob = f"{sel} {s.get('text','')}"
                if _LOGOUT_RE.search(blob): continue  # never replay a logout click
                extras.append({"click": sel})
        if submit_extra: extras.append(submit_extra)
        self._dast_cred_vars["selenium_extra_steps"].set(json.dumps(extras) if extras else "")
        # Save the FULL recording too (literal step-by-step replay), dropping only logout-like clicks.
        literal: list = []
        for s in macro:
            if s.get("kind") == "click":
                blob = f"{s.get('selector','')} {s.get('text','')}"
                if _LOGOUT_RE.search(blob): continue
            literal.append(s)
        self._dast_cred_vars["selenium_macro"].set(json.dumps(literal) if literal else "")
        submit_desc = (submit_sel if submit_sel else "Enter / form submit" if submit_extra else "(not detected)")
        self._emit_log(f"[macro] captured {len(macro)} interactions — "
                       f"user={user_sel!r} pass={pass_sel!r} submit={submit_desc!r}")
        pass_note = ("✔ captured (runtime only)" if pass_val
                     else "(type it in Password value before recording Logout)")
        self._show_info_popup("Login Condition",
            f"Captured {len(macro)} interactions.\n\n"
            f"Username selector:  {user_sel or '(not detected)'}\n"
            f"Password selector:  {pass_sel or '(not detected)'}\n"
            f"Password value:     {pass_note}\n"
            f"Submit:             {submit_desc}\n\n"
            "Submit is the action that sends the login form — a button click, "
            "or an Enter / form submit when there's no button.\n"
            "The password is held only in this session and is wiped when you "
            "close the program; it's never written to any saved file.")
        self._refresh_dast_creds()
        return True  # signal success to _macro_popup → palomita

    @staticmethod
    def _analyze_login_macro(macro: list) -> tuple:
        """Delegate to dast_api.analyze_login_macro (pure-logic, no GUI)."""
        return analyze_login_macro(macro)

    def _dast_record_logout(self):
        """Replay the login macro to reach the logged-in state, then capture the logged-out state."""
        cfg = self._collect_dast_cfg()
        pass_sel = cfg.selenium_pass_selector
        pass_val = cfg.selenium_pass_value
        password_missing = bool(pass_sel and not pass_val)
        if password_missing:  # non-blocking heads-up; browser opens right after for manual login + capture
            self._show_info_popup("Logout Condition — manual login needed",
                "Your login was recorded, but the password wasn't saved "
                "(passwords are never written to disk).\n\n"
                "The browser will open at the login page. Log in by hand, go to "
                "the logged-OUT page, then press Ctrl+Shift+F12 to capture.\n\n"
                "Tip: type your password into the “Password value” field of the "
                "credentials section first and the login will replay itself "
                "automatically next time.")
        work = record_logout_work(cfg, emit_log=self._emit_log)  # engine-side factory, no GUI
        result = self._record_in_browser("Record Logout Condition", "⏺ Logout Condition",
                                         [], work, w_pct=0.34, h_pct=0.32)
        if result is None: return False  # cancelled or browser error — no palomita
        final_url = result.get("final_url","").strip()
        logout_macro = result.get("logout_macro", [])
        logout_hrefs = result.get("logout_href_candidates", [])
        last_click = result.get("last_logout_click", {})
        snapshot = result.get("snapshot", {})
        hints = snapshot.get("hints", [])
        page_title = snapshot.get("title","")
        # Ensure the last click is in the macro so replay has something to execute (SPA buttons w/o href/kw).
        if logout_macro and last_click and last_click.get("selector"):
            last_sel = last_click["selector"]
            macro_sels = [s.get("selector","") for s in logout_macro if s.get("kind") == "click"]
            if last_sel not in macro_sels:
                logout_macro = list(logout_macro) + [{
                    "kind": "click", "selector": last_click.get("selector", ""),
                    "fallback_selectors": last_click.get("fallback_selectors", []),
                    "href": last_click.get("href", ""), "text": last_click.get("text", ""),
                    "el_id": last_click.get("el_id", ""), "el_cls": last_click.get("el_cls", ""),
                    "data_action": last_click.get("data_action", ""),
                }]
                self._emit_log("[logout-rec] appended last click to macro (no kw match)")
        elif not logout_macro and last_click and last_click.get("selector"):
            logout_macro = [{
                "kind": "click", "selector": last_click.get("selector", ""),
                "fallback_selectors": last_click.get("fallback_selectors", []),
                "href": last_click.get("href", ""), "text": last_click.get("text", ""),
                "el_id": last_click.get("el_id", ""), "el_cls": last_click.get("el_cls", ""),
                "data_action": last_click.get("data_action", ""),
            }]
            self._emit_log("[logout-rec] built 1-step macro from last click (no macro recorded)")
        _LOGOUT_KW = ("logout","log-out","signout","sign-out","cerrar","salir")
        def _path_of(u):
            try:
                from urllib.parse import urlparse as _up2
                p = _up2(u if "://" in u else "https://x" + u).path.rstrip("/") or "/"
                return p if p != "/" else None
            except Exception:
                return None
        proposed_re = ""; best_path = None
        for h in logout_hrefs:
            p = _path_of(h)
            if p and any(k in p.lower() for k in _LOGOUT_KW): best_path = p; break
        if not best_path:
            for h in logout_hrefs:
                p = _path_of(h)
                if p: best_path = p; break
        if not best_path and final_url: best_path = _path_of(final_url)
        if not best_path and last_click.get("href"): best_path = _path_of(last_click["href"])
        if best_path: proposed_re = _re.escape(best_path) + r"(\?|$)"
        self._emit_log(f"[logout-rec] proposed_re={proposed_re!r} from path={best_path!r}")
        confirm = self._create_popup("Logout condition — review & confirm")
        self._popup_hdr(confirm, "Logout Condition", subtitle="review captured signals", icon="🔓")
        # Footer pinned to the bottom FIRST so Apply/Cancel can never be pushed off-screen.
        _cb: dict = {"apply": lambda: None}
        foot = tk.Frame(confirm, bg=T["panel_bg"], padx=28, pady=12); foot.pack(side="bottom", fill="x")
        self._btn(foot, "Apply", lambda: _cb["apply"](), "accent").pack(side="right", padx=(6, 0))
        self._btn(foot, "Cancel", lambda: confirm.close(), "flat").pack(side="right", padx=(6, 0))
        tk.Frame(confirm, bg=T["border"], height=1).pack(side="bottom", fill="x")
        canvas = tk.Canvas(confirm, bg=T["bg"], highlightthickness=0, bd=0)
        vsb = ttk.Scrollbar(confirm, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y"); canvas.pack(side="left", fill="both", expand=True)
        cbody = tk.Frame(canvas, bg=T["bg"], padx=28, pady=14)
        cwin = canvas.create_window((0, 0), window=cbody, anchor="nw")
        def _sync_scroll(_e=None): canvas.configure(scrollregion=canvas.bbox("all"))
        def _sync_width(e): canvas.itemconfigure(cwin, width=e.width)
        cbody.bind("<Configure>", _sync_scroll); canvas.bind("<Configure>", _sync_width)
        def _wheel(e):
            try: canvas.yview_scroll(-1 * int(e.delta / 120), "units")
            except Exception: pass
        canvas.bind("<MouseWheel>", _wheel); cbody.bind("<MouseWheel>", _wheel)
        cbody.columnconfigure(1, weight=1)
        row_idx = [0]
        def _row(widget_or_text, *, col=0, span=1, sticky="w", advance=True, **gkw):
            w = widget_or_text
            if isinstance(w, str):
                w = self._lbl(cbody, w, size=9, fg=T["muted"], wraplength=430, anchor="w"); span = 2
            w.grid(row=row_idx[0], column=col, columnspan=span, sticky=sticky, **gkw)
            if advance: row_idx[0] += 1
            return w
        def _field(label, value_var):
            _row(self._lbl(cbody, label, size=10, fg=T["muted"], anchor="e"),
                 sticky="e", advance=False, padx=(0, 8), pady=3)
            e = ttk.Entry(cbody, textvariable=value_var); _row(e, col=1, sticky="ew", pady=3); return e
        _row(self._lbl(cbody, "Captured URL", size=10, fg=T["muted"], anchor="e"),
             sticky="e", advance=False, padx=(0, 8), pady=3)
        _row(self._lbl(cbody, final_url or "(none)", size=10, fg=T["text"], anchor="w", wraplength=420), col=1)
        re_var = tk.StringVar(value=proposed_re)
        _row(self._lbl(cbody, "Logout URL regex", size=10, fg=T["muted"], anchor="e"),
             sticky="e", advance=False, padx=(0, 8), pady=3)
        _re_entry = ttk.Entry(cbody, textvariable=re_var); _row(_re_entry, col=1, sticky="ew", pady=3)
        regex_hint = (
            "URLs matching this regex are SKIPPED so the scanner never logs itself out.\n"
            + ("⚠  Captured URL was root (/). Enter the path the app redirects to after "
               "logout (e.g. /login or /signin). Leave blank if the app stays at / — "
               "use Logged-in selector/text below for session detection instead."
               if not proposed_re else
               "Regex must match a specific path (e.g. /login or /logout). "
               "Avoid patterns that match / — they are too broad and will be rejected."))
        _row(regex_hint)
        _row(tk.Frame(cbody, bg=T["border"], height=1), span=2, sticky="ew", pady=10)
        _row(self._lbl(cbody, "SESSION DETECTION", size=9, fg=T["muted"], bold=True, anchor="w"), span=2)
        _row("Optionally tell the scanner what a LOGGED-IN page looks like "
             "so it can detect session loss mid-scan and re-authenticate.")
        sel_var = tk.StringVar(value=self._dast_cred_vars["login_success_selector"].get())
        _field("Logged-in selector", sel_var)
        _row("CSS selector present ONLY when logged in (e.g. #user-avatar).")
        txt_var = tk.StringVar(value=self._dast_cred_vars["login_success_text"].get())
        _field("Logged-in text", txt_var)
        _row("Text ONLY visible when logged in (e.g. 'My Account').")
        # Recorded logout action + protection summary — answers "how does it avoid logging itself out?".
        if logout_macro:
            _row(tk.Frame(cbody, bg=T["border"], height=1), span=2, sticky="ew", pady=(10, 4))
            _row(self._lbl(cbody, "LOGOUT ACTION RECORDED", size=9, fg=T["muted"], bold=True, anchor="w"), span=2)
            click_steps = [s for s in logout_macro if s.get("kind") == "click"]
            _row(f"✓ {len(logout_macro)} step(s) recorded "
                 f"({len(click_steps)} click(s)). The last click is treated as the logout action.")
            if last_click and last_click.get("selector"):
                lc_text = (last_click.get("text") or "").strip()
                lc_sel = (last_click.get("selector") or "").strip()
                lc_id = (last_click.get("el_id") or "").strip()
                lc_href = (last_click.get("href") or "").strip()
                lc_data = (last_click.get("data_action") or "").strip()
                if lc_text: _row(f"  · Button text: “{lc_text}”")
                if lc_sel: _row(f"  · CSS selector: {lc_sel[:70]}")
                if lc_id: _row(f"  · Element id: {lc_id}")
                if lc_data: _row(f"  · data-action: {lc_data}")
                if lc_href and lc_href not in ("#", "javascript:void(0)", "javascript:;"):
                    _row(f"  · Navigates to: {lc_href[:70]}")
                else:
                    _row("  · No navigation URL (SPA button) — protection is "
                         "by element identity, not URL.")
            _row(tk.Frame(cbody, bg=T["border"], height=1), span=2, sticky="ew", pady=(8, 4))
            _row(self._lbl(cbody, "HOW THE SCANNER AVOIDS LOGGING OUT", size=9, fg=T["muted"], bold=True, anchor="w"), span=2)
            if proposed_re:
                _row("✓ A logout URL path was found and pre-filled above. The "
                     "scanner SKIPS any URL matching it during the crawl.")
            else:
                _row("✓ No distinct logout URL (button stays at /). The scanner "
                     "still protects itself: it reads the recorded button’s "
                     "text/id/class and SKIPS any link or form on each page whose "
                     "text or attributes match logout keywords "
                     "(Salir, Cerrar sesión, logout, signout…). It never clicks "
                     "buttons during a crawl — only follows <a href> links and "
                     "submits forms — so a JS-only logout button is never "
                     "triggered.")
            _row("The default exclude pattern also blocks any URL containing "
                 "/logout, /signout, /sign-out, /log-out, /api/logout.")
        if hints or page_title or snapshot.get("has_password_field") or snapshot.get("has_login_form"):
            _row(tk.Frame(cbody, bg=T["border"], height=1), span=2, sticky="ew", pady=(10, 4))
            _row("Signals detected on logout page (for reference):")
            strong = []
            if snapshot.get("has_password_field"): strong.append("password field present (typical of a login page)")
            if snapshot.get("has_login_form"): strong.append("login form present")
            for s in strong: _row(f"  ✓ {s}")
            # Collapse whitespace defensively — old captures could embed a whole <form> innerText.
            clean_hints = []
            for h in hints:
                h = _re.sub(r"\s+", " ", str(h)).strip()[:80]
                if h and h not in clean_hints: clean_hints.append(h)
            for h in ([f"Page title: {page_title}"] if page_title else []) + clean_hints[:8]:
                _row(f"  · {h}")
        elif not final_url:
            _row(tk.Frame(cbody, bg=T["border"], height=1), span=2, sticky="ew", pady=(10, 4))
            _row("⚠️  No page data was captured. Make sure you pressed "
                 "Ctrl+Shift+F12 *while on the logged-out page* (the browser "
                 "must still be open). You can type the Logout URL regex above "
                 "by hand and Apply.")
        applied: list[bool] = [False]
        def _apply():
            re_val = re_var.get().strip(); sel_val = sel_var.get().strip(); txt_val = txt_var.get().strip()
            if re_val: self._dast_cred_vars["logout_url_re"].set(re_val)
            if sel_val: self._dast_cred_vars["login_success_selector"].set(sel_val)
            if txt_val: self._dast_cred_vars["login_success_text"].set(txt_val)
            if logout_macro:
                self._dast_cred_vars["selenium_logout_macro"].set(json.dumps(logout_macro))
                self._emit_log(f"[logout-rec] logout macro saved ({len(logout_macro)} steps)")
            else:
                self._emit_log("[logout-rec] WARNING: 0 logout steps recorded — "
                               "open user menu and click Log Out while recorder is running")
            applied[0] = True
            self._emit_log(f"[logout-rec] applied — regex={re_val!r} selector={sel_val!r} text={txt_val!r}")
            self._refresh_dast_creds(); confirm.close()
        _cb["apply"] = _apply  # footer Apply button → this handler
        def _bind_wheel_rec(w):  # wheel must work over labels/entries too, not just the canvas
            try: w.bind("<MouseWheel>", _wheel)
            except Exception: pass
            for child in w.winfo_children(): _bind_wheel_rec(child)
        _bind_wheel_rec(cbody)
        self.wait_window(confirm._win)
        if not applied[0]:
            self._emit_log("[logout-rec] cancelled — no changes applied"); return False
        return True  # signal success to _macro_popup → palomita

    def _dast_test_logout(self):
        """Replay the login macro, navigate to the logout URL, then close the browser — end-to-end check."""
        cfg = self._collect_dast_cfg()
        login_url = cfg.selenium_login_url.strip() or self._dast_url_var.get().strip()
        if not login_url or login_url == "https://":
            self._show_error_popup("Test Logout", "Set a Target URL or Login page URL before running the test.")
            return
        work = test_logout_work(cfg, emit_log=self._emit_log)  # engine-side factory drives done.set() itself
        result = self._record_in_browser("Test Logout Condition", "🧪 Test Logout",
                                         [], work, w_pct=0.34, h_pct=0.28)
        if result is None:
            self._emit_log("[test-logout] cancelled or browser error"); return
        reached = result.get("logout_url_reached", "")
        logout_replayed = result.get("logout_replayed", False)
        if result.get("test_done"):
            if logout_replayed:
                url_line = (f"\n\nFinal URL:\n{reached}" if reached else "")  # SPA: URL may not change
                self._show_info_popup("Test Logout — ✅ Success",
                    f"Login and logout completed successfully.{url_line}")
            else:
                self._show_info_popup("Test Logout — ⚠️ Incomplete",
                    "Login replayed but logout could not be completed.\n\n"
                    "Re-record the Logout Condition:\n"
                    "open user menu → click Log Out → Ctrl+Shift+F12.")
        else:
            self._emit_log("[test-logout] test did not complete normally")

    def _start_scan(self):
        self._run_async(self._do_scan, label="full pipeline scan")

    def _request_cancel(self):
        if self._busy:
            self._cancel_evt.set(); self._emit_log("[scan] cancel requested…"); self._set_status('Cancelling…')
        else:
            self._emit_log("[scan] nothing to cancel.")

    def _scoped_report_paths(self, reports_root: Path):
        """Return (report_label, app_reports_root) scoped to the active app.

        Centralises the slug/label/folder logic previously duplicated across the
        scan pipelines. app_reports_root is created on disk before returning.
        """
        active_app = getattr(self, "_active_app", None)
        slug = (_re.sub(r"[^A-Za-z0-9\-_]", "_", active_app["name"].strip())
                if active_app and active_app.get("name") else "")
        label = f"{self._user}+{slug}" if slug else self._user
        app_reports_root = reports_root / (slug if slug else "_unscoped")
        app_reports_root.mkdir(parents=True, exist_ok=True)
        return label, app_reports_root

    def _do_scan(self):
        selected = {k for k, v in self._scan_vars.items() if v.get()}
        if not selected:
            self._emit_log("[scan] nothing selected"); return
        self._cancel_evt.clear()
        target = Path(self._target_var.get()).resolve()
        reports_root = Path(self._reports_var.get()).resolve(); reports_root.mkdir(parents=True, exist_ok=True)
        if bool({"sca","code"} & selected) and (not target.exists() or not target.is_dir()):
            self._emit_log(f"[scan] target folder missing: {target}"); return
        mode = "+".join(sorted(selected))
        active_app = getattr(self, "_active_app", None)  # report label: "user+AppName" when an app is loaded
        _report_label, app_reports_root = self._scoped_report_paths(reports_root)
        out_dir = app_reports_root / f"report_{_ts()}_{mode}"; out_dir.mkdir(parents=True, exist_ok=True)
        self._emit_log(f"[scan] pipeline: {mode.upper()}")
        self._emit_log(f"[scan] output → {out_dir}")
        _snyk_usable = True
        if {"sca", "code"} & selected:
            try:
                if not ensure_snyk_ready(self._emit_log):
                    _snyk_usable = False
                    self._emit_log("[scan] Snyk CLI is not runnable — skipping "
                                   "SCA/SAST. Click Fix to repair it.")
            except Exception as e:
                self._emit_log(f"[scan] snyk readiness check error: {e!r}")
        try: v = _run(["snyk","--version"]).stdout.strip()
        except Exception: v = "?"
        results: dict[str, Any] = {"sca":None,"code":None,"dast":None,"api":None,"secrets":None}
        for k in ("sca","code","dast","api","secrets"):
            running = k in selected and (_snyk_usable or k not in ("sca", "code"))
            self._event_queue.put(("stage", (k, "running" if running else "skipped")))
        jobs: list[tuple[str, Callable[[], None]]] = []
        def _stage(key, fn, *a, **kw):
            jobs.append((key, lambda: results.__setitem__(key, fn(*a, **kw)[0])))
        if "sca" in selected and _snyk_usable: _stage("sca", run_snyk_test, target, out_dir, self._emit_log)
        if "code" in selected and _snyk_usable: _stage("code", run_snyk_code, target, out_dir, self._emit_log)
        if "dast" in selected:
            dast_cfg = self._collect_dast_cfg()
            if not dast_cfg.url or dast_cfg.url == "https://":
                self._emit_log("[dast] no URL configured — skipping DAST")
                self._event_queue.put(("stage",("dast","skipped")))
            else:
                _stage("dast", run_dast, dast_cfg, out_dir, self._emit_log, cancel=self._cancel_evt)
        if "api" in selected:
            api_cfg = self._collect_api_cfg()
            if not api_cfg.spec_source:
                self._emit_log("[api] no spec configured — skipping API scan")
                self._event_queue.put(("stage",("api","skipped")))
            else:
                _stage("api", run_api, api_cfg, out_dir, self._emit_log, cancel=self._cancel_evt)
        if "secrets" in selected:
            def _run_secrets_stage():
                try:
                    self._emit_log("[secrets] running secret scan as pipeline stage…")
                    result = scan_path(target, self._emit_log, cancel=self._cancel_evt,
                                       git_secrets_status=get_git_secrets_status())
                    sec_dir = out_dir / "secrets"
                    write_secrets_report(result, sec_dir)
                    self._emit_log(f"[secrets] {result['total']} finding(s) across {result['scanned_files']} file(s)")
                    results["secrets"] = result
                except Exception as e:
                    self._emit_log(f"[secrets] stage failed: {e!r}"); results["secrets"] = None
            jobs.append(("secrets", _run_secrets_stage))
        def run_stage(item):
            key, fn = item
            try:
                fn(); self._event_queue.put(("stage",(key,"done")))
            except Exception as e:
                self._event_queue.put(("stage",(key,"failed"))); self._emit_log(f"[scan] {key} failed: {e!r}")
                if getattr(e, "is_auth", False):
                    self._event_queue.put(("auth_required", None))
        if len(jobs) > 1:
            self._emit_log(f"[scan] running {len(jobs)} stages concurrently")
            with ThreadPoolExecutor(max_workers=len(jobs)) as ex_:
                list(ex_.map(run_stage, jobs))
        else:
            for j in jobs: run_stage(j)
        # Persist each completed stage so the next report always includes the last run of EVERY type.
        dast_url_hint = ""; api_spec_hint = ""
        try: dast_url_hint = self._dast_url_var.get().strip()
        except Exception: pass
        try: api_spec_hint = self._api_spec_var.get().strip()
        except Exception: pass
        _kind_targets = {
            "sca": str(target), "code": str(target), "dast": dast_url_hint or str(target),
            "api": api_spec_hint or str(target), "secrets": str(target),
        }
        state = self._scan_state
        for kind in ("sca", "code", "dast", "api", "secrets"):
            raw = results.get(kind)
            if raw is not None:
                try:
                    state.save_kind(kind, raw, target=_kind_targets.get(kind, str(target)),
                                    snyk_version=v, mode=mode)
                    self._emit_log(f"[state] {kind} result persisted to cumulative store")
                except Exception as e:
                    self._emit_log(f"[state] could not save {kind}: {e!r}")
        ctx = build_cumulative_context(state, target_hint=target, snyk_version_hint=v, current_results=results)
        self._emit_log("[report] building cumulative report (all scan types merged)")
        ctx["scan_mode"] = mode
        self._emit_log(f"[scan] cumulative total: {ctx['total']}  "
                       f"crit={ctx['counts']['critical']}  high={ctx['counts']['high']}  "
                       f"med={ctx['counts']['medium']}  low={ctx['counts']['low']}  "
                       f"secrets={ctx.get('secrets_total',0)}")
        _base = _report_basename(self._user, mode)
        report = render_html(ctx, out_dir, filename=f"{_base}.html")
        csv_path = export_csv(ctx, out_dir / f"{_base}.csv", report_label=_report_label)
        self._emit_log(f"[report] CSV bundle (ZIP): {csv_path}  (sca/sast/dast/api/secrets sheets + summary)")
        sec_html_src = out_dir / "secrets" / "secrets.html"
        if sec_html_src.exists():
            try:
                sec_html_dst = out_dir / f"{_base}_secrets.html"
                shutil.copyfile(sec_html_src, sec_html_dst)
                self._emit_log(f"[report] Secrets HTML → {sec_html_dst}")
            except Exception as e:
                self._emit_log(f"[report] secrets HTML copy skipped: {e!r}")
        try:
            sarif_path = export_sarif(out_dir)
            if sarif_path: self._emit_log(f"[report] SARIF: {sarif_path}")
        except Exception as e:
            self._emit_log(f"[report] SARIF export skipped: {e!r}")
        try:
            merged_path = export_merged_json(out_dir)
            if merged_path: self._emit_log(f"[report] merged JSON: {merged_path}")
        except Exception as e:
            self._emit_log(f"[report] merged JSON skipped: {e!r}")
        meta = {
            "generated_at": ctx["generated_at"], "target": ctx["target"], "mode": mode,
            "counts": ctx["counts"], "total": ctx["total"], "sca_total": ctx["sca_total"],
            "code_total": ctx["code_total"], "dast_total": ctx.get("dast_total",0),
            "api_total": ctx.get("api_total",0), "snyk_version": ctx["snyk_version"],
            "secrets_total": ctx.get("secrets_total", 0),
        }
        (out_dir / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
        try:
            rec = update_history_after_scan(reports_root, ctx, meta,
                                            actor=getattr(self, "_user", ""), report_dir=out_dir)
            self._emit_log(f"[history] recorded scan — remediated {rec.get('remediated_count',0)}, "
                           f"new {rec.get('introduced_count',0)} since last {mode.upper()} run")
        except Exception as e:
            self._emit_log(f"[history] could not update remediation history: {e!r}")
        active_app = getattr(self, "_active_app", None)
        if active_app and active_app.get("id"):
            try:
                self._inv_store.record_scan(active_app["id"], meta)
                self._emit_log(f"[inventory] scan recorded for app '{active_app['name']}'")
                self._event_queue.put(("inv_refresh", active_app["id"]))
            except Exception as e:
                self._emit_log(f"[inventory] could not update app record: {e!r}")
        c = ctx["counts"]
        secrets_crit = sum(1 for s in ctx.get("secrets", {}).get("findings", [])
                           if s.get("severity") in ("critical", "high"))
        gate = "FAIL" if (c.get("critical",0) or c.get("high",0) or secrets_crit) else "PASS"
        self._emit_log(f"[gate] {gate}  (critical={c.get('critical',0)} high={c.get('high',0)} "
                       f"medium={c.get('medium',0)} low={c.get('low',0)} "
                       f"secrets_crit_high={secrets_crit})")
        self._last_context = ctx; self._last_report_dir = out_dir
        self._last_static_report = Path(report)
        self._emit_log(f"[report] HTML: {report}")
        self._emit_log(f"[report] CSV:  {csv_path}")
        self._event_queue.put(("static_results", ctx))  # refresh Static-tab trees
        self._event_queue.put(("report", str(report)))

    def _run_async(self, fn: Callable[[], None], label: str = ""):
        if self._busy:
            self._log_line(f"[busy] ignoring '{label}' — another op in progress"); return
        self._busy = True; self._update_stop_btn_style(); self._set_status(f"Running: {label}…")
        def wrap():
            try: fn()
            except Exception as e: self._log_line(f"[error] {e!r}")
            finally: self._event_queue.put(("__done__", label))
        threading.Thread(target=wrap, daemon=True).start()

    def _drain_events(self):
        try:
            while True:
                kind, payload = self._event_queue.get_nowait()
                if kind == "log":
                    self._log_line(payload)
                elif kind == "status":
                    self._set_status(payload)
                elif kind == "checks":
                    self._apply_checks(payload)
                elif kind == "stage":
                    key, label = payload
                    pill = self._stage_pills.get(key)
                    if pill:
                        style_map = {
                            "running": (T["pill_run_bg"], T["pill_run_fg"]),
                            "done":    (T["pill_ok_bg"],  T["pill_ok_fg"]),
                            "failed":  (T["pill_bad_bg"], T["pill_bad_fg"]),
                            "skipped": (T["pill_idle_bg"],T["pill_idle_fg"]),
                        }
                        bg, fg = style_map.get(label, (T["pill_idle_bg"], T["pill_idle_fg"]))
                        _pill_labels = {"running": "● RUN", "done": "● OK", "failed": "● FAIL", "skipped": "● SKIP"}
                        pill.config(text=_pill_labels.get(label, f"● {label.upper()[:4]}"), bg=bg, fg=fg)
                elif kind == "auth_required":
                    self._prompt_relogin()
                elif kind == "report":
                    self._last_report = Path(payload)
                    self._open_btn.config(state="normal"); self._csv_btn.config(state="normal")
                    self._refresh_recent(); self._refresh_rep_tree()
                    self._refresh_active_app_banner()  # vuln counts update immediately
                    if self._auto_open: _open_path(self._last_report)
                elif kind == "api_preview":
                    fmt, ops, count = payload
                    for iid in self._ep_tree.get_children(): self._ep_tree.delete(iid)
                    for op in ops:
                        ctype = op.get("ctype") or "—"; secured = "✓" if op.get("secured") else "—"
                        self._ep_tree.insert("","end", values=(op["method"], op["url"], secured, ctype))
                    self._ep_count_lbl.config(text=f"Format: {fmt}  ·  {count} endpoint(s) detected")
                    self._emit_log(f"[api-preview] {fmt} — {count} endpoints")
                elif kind == "static_results":
                    ctx = payload
                    self._static_busy = False
                    for b in getattr(self, "_static_run_btns", []):
                        b.config(state="normal")
                    if ctx is None:
                        if hasattr(self, "_static_count_lbl"):
                            self._static_count_lbl.config(text="Scan failed — see console.")
                    else:
                        if hasattr(self, "_static_sca_tree"):
                            self._render_sca(ctx.get("projects", []))
                        if hasattr(self, "_static_sast_tree"):
                            self._render_sast(ctx.get("files", []))
                        if hasattr(self, "_secrets_box"):
                            self._render_secrets(ctx.get("secrets", {}).get("findings", []))
                        if hasattr(self, "_static_count_lbl"):
                            self._static_count_lbl.config(
                                text=f"SCA {ctx.get('sca_total',0)} · "
                                     f"SAST {ctx.get('code_total',0)} · "
                                     f"Secrets {ctx.get('secrets_total',0)}")
                        if hasattr(self, "_static_open_btn"):
                            self._static_open_btn.config(
                                state="normal" if self._last_static_report else "disabled")
                elif kind == "__done__":
                    self._busy = False; self._update_stop_btn_style()
                    self._set_status('Ready.'); self._refresh_scan_btn()
                elif kind == "inv_refresh":
                    inv_tab = getattr(self, "_inv_tab", None)
                    if inv_tab:
                        try: inv_tab.refresh()
                        except Exception: pass
        except queue.Empty: pass
        if self._auth_proc is not None: self._tick_auth_poll()
        self.after(150, self._drain_events)

    def _log_line(self, s: str):
        self._log_widget.configure(state="normal")
        self._log_widget.insert("end", s.rstrip() + "\n")
        max_lines = getattr(self, "_max_log_lines", 2000)
        lines = int(self._log_widget.index("end-1c").split(".")[0])
        if lines > max_lines:
            self._log_widget.delete("1.0", f"{lines - max_lines}.0")
        self._log_widget.see("end")
        self._log_widget.configure(state="disabled")
        if not self._console_visible:
            self._unread_log += 1
            self._console_btn.configure(text=f"▥  Console ({self._unread_log})", fg=T["err"])

    def _update_stop_btn_style(self):
        """Update stop button appearance based on scan state."""
        btn = getattr(self, "_stop_icon_btn", None); wrap = getattr(self, "_stop_icon_wrap", None)
        if not btn: return
        if self._busy:  # active: red border (via wrapper), red text, white bg
            if wrap:
                try: wrap.configure(bg=T["err"])
                except Exception: pass
            btn.configure(fg=T["err"], activeforeground=T["err"], activebackground="#fff0f0",
                          bg="#ffffff", state="normal")
        else:  # idle: grayed out and disabled — match the bg/fg pattern other disabled buttons use
            if wrap:
                try: wrap.configure(bg=T["muted"])
                except Exception: pass
            btn.configure(fg=T["muted"], activeforeground=T["muted"], activebackground=T["surface2"],
                          bg=T["surface2"], state="disabled")

    def _set_status(self, s: str): self._status_var.set(s)
    def _emit_log(self, s: str):   self._event_queue.put(("log", s))


# ── Loading splash ────────────────────────────────────────────────────────────
def _splash_read_dark_pref() -> bool:
    """Read dark_mode from .scanner_settings.json without importing the app (False if absent/unreadable)."""
    try:
        data = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        return bool(data.get("dark_mode", False))
    except Exception:
        return False


class BootSplash(tk.Toplevel):
    """Borderless boot splash mirroring ScannerApp's look (ribbon, amber stripe,
    themed log console). Used both for the initial app launch (own throwaway
    root, see run_boot()) and to re-run the full dependency installer later
    from ScannerApp._fix(), so every install always happens in this one
    window — never inline/silently elsewhere."""

    def __init__(self, master: tk.Misc, modal: bool = True):
        super().__init__(master)
        self.overrideredirect(True)
        try: self.attributes("-topmost", True)
        except Exception: pass
        if modal:
            # NOTE: only do this when `master` is a real, visible window (the
            # _fix() reuse case, master=ScannerApp). If master is the
            # throwaway hidden root used at initial boot (master.withdraw()),
            # calling transient() against a withdrawn master makes Tk/the
            # window manager hide this splash too -- no error, it just never
            # appears on screen. See run_boot(): modal=False for that case.
            try:
                self.transient(master)
            except Exception:
                pass
        _apply_palette(_splash_read_dark_pref())  # palette into T before building widgets
        w, h = 600, 400
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry(f"{w}x{h}+{(sw - w) // 2}+{(sh - h) // 2}")
        self.configure(bg=T["accent"])
        outer = tk.Frame(self, bg=T["accent"], padx=2, pady=2); outer.pack(fill="both", expand=True)
        c = tk.Frame(outer, bg=T["bg"]); c.pack(fill="both", expand=True)
        # Ribbon header (mirrors ScannerApp._build_ribbon)
        ribbon = tk.Frame(c, bg=T["panel_bg"]); ribbon.pack(fill="x")
        tk.Frame(ribbon, bg=T["accent"], height=2).pack(fill="x", side="top")
        inner_row = tk.Frame(ribbon, bg=T["panel_bg"]); inner_row.pack(fill="x", side="top")
        os_tag = "macOS" if IS_MAC else ("Windows" if IS_WIN else "Linux")
        right_lbl = tk.Frame(inner_row, bg=T["panel_bg"]); right_lbl.pack(side="right", padx=12)
        tk.Label(right_lbl, text=f"{os_tag}  ·  {_detect_user()}", font=(_FUI, 9),
                 bg=T["panel_bg"], fg=T["muted"]).pack(pady=6)
        tk.Frame(ribbon, bg=T["border"], height=1).pack(fill="x", side="bottom")
        body = tk.Frame(c, bg=T["bg"]); body.pack(fill="both", expand=True, padx=22, pady=(10, 14))
        # Rotating globe animation — atmosphere glow, starfield and a soft
        # sphere sheen are drawn once (static); only the meridians, the
        # highlight dot and an orbiting "data packet" satellite redraw each
        # frame, so the extra polish costs almost nothing per tick.
        import math as _math, random as _random
        GR, PAD = 48, 14
        GW = GH = GR * 2 + PAD * 2
        cx, cy = GW // 2, GH // 2
        self._globe_cv = tk.Canvas(body, width=GW, height=GH, bg=T["bg"], bd=0, highlightthickness=0)
        self._globe_cv.pack(side="left", padx=(0, 14))
        self._globe_angle = 0.0

        rnd = _random.Random(7)
        for _ in range(26):  # static starfield
            sx, sy = rnd.randint(0, GW), rnd.randint(0, GH)
            if (sx - cx) ** 2 + (sy - cy) ** 2 < (GR + PAD - 2) ** 2:
                continue
            r = rnd.choice((1, 1, 2))
            self._globe_cv.create_oval(sx - r, sy - r, sx + r, sy + r, fill=T["muted"], outline="")
        for i, stip in enumerate(("gray12", "gray25", "gray50")):  # atmosphere glow rings
            rr = GR + (3 - i) * 4
            self._globe_cv.create_oval(cx - rr, cy - rr, cx + rr, cy + rr, outline=T["accent"], outlinestipple=stip)
        self._globe_cv.create_oval(cx - GR, cy - GR, cx + GR, cy + GR, fill=T["panel_bg"], outline="")
        self._globe_cv.create_oval(cx - GR + 6, cy - GR + 4, cx + GR - 24, cy + GR - 36,
                                   fill=T["accent"], outline="", stipple="gray12")  # glossy sheen

        def _draw_globe(angle):
            cv = self._globe_cv; cv.delete("globe")
            cv.create_oval(cx - GR, cy - GR, cx + GR, cy + GR, outline=T["accent"], width=2, tags="globe")
            for lat_frac in (-0.55, -0.25, 0, 0.25, 0.55):  # fixed latitude lines
                ry = int(GR * _math.sqrt(max(0, 1 - lat_frac**2))); yy = cy + int(GR * lat_frac)
                if ry > 2:
                    cv.create_oval(cx - ry, yy - 4, cx + ry, yy + 4, outline=T["muted"], width=1, tags="globe")
            N = 40
            for lon_offset in (0, 0.5, 1.0, 1.5):  # longitude meridians rotate with angle
                pts = []
                for i in range(N + 1):
                    lat = _math.pi * (i / N - 0.5); lon = angle + _math.pi * lon_offset
                    x3 = _math.cos(lat) * _math.cos(lon); y3 = _math.sin(lat)
                    if _math.cos(lat) * _math.sin(lon) < 0:  # back-face cull
                        continue
                    pts.append((int(cx + GR * x3), int(cy - GR * y3)))
                for j in range(len(pts) - 1):
                    cv.create_line(pts[j], pts[j + 1], fill=T["muted"], width=1, tags="globe")
            hx = cx - int(GR * 0.35); hy = cy - int(GR * 0.38)  # highlight dot
            cv.create_oval(hx - 5, hy - 5, hx + 5, hy + 5, fill=T["accent"], outline="", tags="globe")
            for k, fade in ((3, "gray25"), (2, "gray50"), (1, None), (0, None)):  # orbiting satellite + comet trail
                a = angle * 2.2 - k * 0.22
                ox = cx + (GR + 11) * _math.cos(a); oy = cy + (GR + 11) * 0.32 * _math.sin(a)
                r = 3 if k == 0 else 2
                cv.create_oval(ox - r, oy - r, ox + r, oy + r, fill=T["accent"], outline="",
                               stipple=fade, tags="globe")

        def _spin_globe():
            if self._done or self._error is not None: return
            self._globe_angle = (self._globe_angle + 0.06) % (2 * _math.pi)
            _draw_globe(self._globe_angle); self.after(40, _spin_globe)  # ~25 fps

        _draw_globe(0.0); self.after(40, _spin_globe)
        right_col = tk.Frame(body, bg=T["bg"]); right_col.pack(side="left", fill="both", expand=True)
        self._step_var = tk.StringVar(value="Preparing…")
        tk.Label(right_col, textvariable=self._step_var, font=(_FUI, 11, "bold"),
                 bg=T["bg"], fg=T["accent"], anchor="w").pack(fill="x")
        pb_style = ttk.Style(self)
        try: pb_style.theme_use("clam")
        except tk.TclError: pass
        pb_style.configure("Splash.Horizontal.TProgressbar", troughcolor=T["surface2"], background=T["accent"],
                           bordercolor=T["border"], lightcolor=T["accent"], darkcolor=T["accent"])
        self._pb = ttk.Progressbar(right_col, style="Splash.Horizontal.TProgressbar", mode="determinate", maximum=100)
        self._pb.pack(fill="x", pady=(6, 10))
        logwrap = tk.Frame(right_col, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"])
        logwrap.pack(fill="both", expand=True)
        tk.Frame(logwrap, bg=T["accent"], height=1).pack(fill="x", side="top")
        self._log = tk.Text(logwrap, bg=T["panel_bg"], fg=T["muted"], relief="flat", font=(_FMONO, 9),
                            padx=10, pady=8, height=8, state="disabled", wrap="none",
                            insertbackground=T["text"], selectbackground=T["accent"], selectforeground=T["button_fg"])
        sb = tk.Scrollbar(logwrap, command=self._log.yview, bg=T["panel_bg"], troughcolor=T["surface2"],
                          relief="flat", bd=0)
        self._log.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y"); self._log.pack(fill="both", expand=True)
        self._q: queue.Queue = queue.Queue()
        self._done = False
        self._error: Optional[str] = None
        self.after(60, self._pump)

    def progress(self, kind, payload):  # progress callback used by _load_runtime (worker thread)
        self._q.put((kind, payload))

    def _append(self, text: str):
        self._log.configure(state="normal")
        self._log.insert("end", text.rstrip() + "\n")
        lines = int(self._log.index("end-1c").split(".")[0])  # keep the last ~200 lines
        if lines > 200:
            self._log.delete("1.0", f"{lines - 200}.0")
        self._log.see("end"); self._log.configure(state="disabled")

    def _pump(self):
        try:
            while True:
                kind, payload = self._q.get_nowait()
                if kind == "step":
                    i, total, label = payload
                    self._step_var.set(f"[{i}/{total}]  {label}")
                    self._pb.configure(value=int(i / max(total, 1) * 100))
                elif kind == "log":
                    self._append(str(payload))
                elif kind == "error":
                    self._error = str(payload)
                elif kind == "done":
                    self._step_var.set("✔  Ready — launching…"); self._pb.configure(value=100); self._done = True
        except queue.Empty:
            pass
        if self._done or self._error is not None:
            self.after(280, self.destroy); return  # close just this splash window
        self.after(60, self._pump)


def run_boot(master: Optional[tk.Misc] = None) -> Optional[str]:
    """Show the boot splash, run _load_runtime in a worker thread, and block
    until done — returns None on success or an error string on failure.

    `master`:
      - None (initial app launch, see main() below): a throwaway hidden Tk
        root is created to host the splash.
      - an existing widget/root (e.g. ScannerApp itself, from _fix()): the
        splash becomes a modal Toplevel over it, so re-installing missing
        dependencies after the app is already open reuses this exact same
        window/animation instead of installing things inline elsewhere.

    Every dependency this program installs — pip packages, Node.js/npm,
    git-secrets, Snyk CLI — funnels through _load_runtime(), so this single
    function is the only place any installer ever runs.
    """
    own_root = master is None
    if own_root:
        master = tk.Tk()
        master.withdraw()
    splash = BootSplash(master, modal=not own_root)
    holder: dict = {"error": None}

    def worker():
        try:
            _load_runtime(progress=splash.progress)
        except Exception as e:
            import traceback
            holder["error"] = f"{e!r}\n\n{traceback.format_exc()}"
            splash.progress("log", f"ERROR: {e!r}")
            splash.progress("error", str(e))
        else:
            splash.progress("done", None)

    threading.Thread(target=worker, daemon=True).start()
    master.wait_window(splash)  # blocks (processing events) until the splash closes
    if own_root:
        try: master.destroy()
        except Exception: pass
    return holder["error"]


# ── Entry point ───────────────────────────────────────────────────────────────
def main():
    err = run_boot()  # 1) real loading splash while heavy deps + git-secrets are fetched
    if err:
        msg = ("Scanner could not load its dependencies:\n\n" + err +
               "\n\nUsually a missing package or corporate TLS proxy.")
        try:
            root = tk.Tk(); root.withdraw()
            messagebox.showerror(f"{APP_BRAND_NAME} — startup failed", msg)
        except Exception:
            print(msg, file=sys.stderr)
        return
    try:  # 2) launch the main application
        app = ScannerApp()
    except Exception as e:
        import traceback
        msg = (f"Scanner could not start:\n\n{e!r}\n\n"
               "Usually a missing package or corporate TLS proxy.\n\n" + traceback.format_exc())
        try:
            root = tk.Tk(); root.withdraw()
            messagebox.showerror(f"{APP_BRAND_NAME} — startup failed", msg)
        except Exception:
            print(msg, file=sys.stderr)
        raise
    app.mainloop()


if __name__ == "__main__":
    main()