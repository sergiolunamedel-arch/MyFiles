#!/usr/bin/env python3
"""
gui_servicenow_tester.py

Interfaz gráfica (Tkinter) para test_servicenow_ticket.py. Permite elegir
qué ramas del formulario probar (SAST/SCA, DAST, API, Secretos), ejecutar
las pruebas contra la API de Service Catalog de ServiceNow, ver los
resultados en una tabla, y cancelar automáticamente los tickets de prueba
al terminar.

Uso:
    python3 gui_servicenow_tester.py
"""

from __future__ import annotations

import queue
import threading
import tkinter as tk
from tkinter import ttk, messagebox

import test_servicenow_ticket as core


class ServiceNowTesterGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ServiceNow Ticket Tester — Plataformas DEV")
        self.geometry("880x640")
        self.minsize(760, 560)

        self.msg_queue: queue.Queue = queue.Queue()
        self.scenario_vars: dict[str, tk.BooleanVar] = {}
        self.running = False

        self._build_widgets()
        self.after(100, self._poll_queue)

    # ------------------------------------------------------------------
    # UI
    # ------------------------------------------------------------------
    def _build_widgets(self):
        pad = {"padx": 8, "pady": 6}

        # --- Credenciales ---
        creds = ttk.LabelFrame(self, text="Credenciales")
        creds.pack(fill="x", **pad)

        ttk.Label(creds, text="Usuario:").grid(row=0, column=0, sticky="e", padx=4, pady=4)
        self.user_entry = ttk.Entry(creds, width=28)
        self.user_entry.grid(row=0, column=1, sticky="w", padx=4, pady=4)

        ttk.Label(creds, text="Password:").grid(row=0, column=2, sticky="e", padx=4, pady=4)
        self.pass_entry = ttk.Entry(creds, width=28, show="•")
        self.pass_entry.grid(row=0, column=3, sticky="w", padx=4, pady=4)

        ttk.Label(creds, text="Token (opcional, sustituye user/pass):").grid(
            row=1, column=0, columnspan=2, sticky="e", padx=4, pady=4)
        self.token_entry = ttk.Entry(creds, width=40, show="•")
        self.token_entry.grid(row=1, column=2, columnspan=2, sticky="w", padx=4, pady=4)

        # --- Escenarios ---
        scen_frame = ttk.LabelFrame(self, text="Ramas a probar")
        scen_frame.pack(fill="x", **pad)
        for i, name in enumerate(core.SCENARIOS.keys()):
            var = tk.BooleanVar(value=True)
            self.scenario_vars[name] = var
            ttk.Checkbutton(scen_frame, text=name, variable=var).grid(
                row=0, column=i, sticky="w", padx=10, pady=6)

        # --- Opciones ---
        opts = ttk.LabelFrame(self, text="Opciones")
        opts.pack(fill="x", **pad)

        ttk.Label(opts, text="Ambiente (opcional, ej. Producción):").grid(
            row=0, column=0, sticky="e", padx=4, pady=4)
        self.ambiente_entry = ttk.Entry(opts, width=20)
        self.ambiente_entry.grid(row=0, column=1, sticky="w", padx=4, pady=4)

        self.dry_run_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(opts, text="Dry run (no envía nada)", variable=self.dry_run_var).grid(
            row=0, column=2, sticky="w", padx=10, pady=4)

        self.cleanup_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(opts, text="Cancelar tickets de prueba al terminar",
                         variable=self.cleanup_var).grid(row=0, column=3, sticky="w", padx=10, pady=4)

        # --- Botón ejecutar ---
        run_frame = ttk.Frame(self)
        run_frame.pack(fill="x", **pad)
        self.run_button = ttk.Button(run_frame, text="Ejecutar pruebas", command=self._on_run)
        self.run_button.pack(side="left")
        self.status_label = ttk.Label(run_frame, text="Listo")
        self.status_label.pack(side="left", padx=12)

        # --- Resultados (tabla) ---
        table_frame = ttk.LabelFrame(self, text="Resultados")
        table_frame.pack(fill="both", expand=False, **pad)

        columns = ("scenario", "status", "request_number", "cleanup_status")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=6)
        headings = {"scenario": "Escenario", "status": "Status", "request_number": "Request #",
                    "cleanup_status": "Limpieza"}
        for col in columns:
            self.tree.heading(col, text=headings[col])
            self.tree.column(col, width=180 if col == "request_number" else 140, anchor="w")
        self.tree.pack(fill="x")

        # --- Consola de log ---
        log_frame = ttk.LabelFrame(self, text="Log")
        log_frame.pack(fill="both", expand=True, **pad)

        self.log_text = tk.Text(log_frame, wrap="word", state="disabled", height=10)
        scrollbar = ttk.Scrollbar(log_frame, command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=scrollbar.set)
        self.log_text.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        ttk.Label(self, text=f"Log CSV: {core.LOG_FILE}   ·   Endpoint: {core.ORDER_URL}",
                  foreground="#555").pack(fill="x", padx=8, pady=(0, 6))

    # ------------------------------------------------------------------
    # Logging thread-safe
    # ------------------------------------------------------------------
    def _log(self, message: str):
        self.msg_queue.put(("log", message))

    def _poll_queue(self):
        try:
            while True:
                kind, payload = self.msg_queue.get_nowait()
                if kind == "log":
                    self.log_text.configure(state="normal")
                    self.log_text.insert("end", payload + "\n")
                    self.log_text.see("end")
                    self.log_text.configure(state="disabled")
                elif kind == "row":
                    self.tree.insert("", "end", values=(
                        payload["scenario"], payload["status"],
                        payload.get("request_number", ""), payload.get("cleanup_status", "…")))
                elif kind == "row_update":
                    # payload = (scenario, cleanup_status)
                    for item in self.tree.get_children():
                        vals = list(self.tree.item(item, "values"))
                        if vals[0] == payload[0]:
                            vals[3] = payload[1]
                            self.tree.item(item, values=vals)
                elif kind == "done":
                    self.running = False
                    self.run_button.configure(state="normal")
                    self.status_label.configure(text="Listo")
                elif kind == "error":
                    messagebox.showerror("Error", payload)
        except queue.Empty:
            pass
        self.after(100, self._poll_queue)

    # ------------------------------------------------------------------
    # Ejecución
    # ------------------------------------------------------------------
    def _on_run(self):
        if self.running:
            return

        selected = [name for name, var in self.scenario_vars.items() if var.get()]
        if not selected:
            messagebox.showwarning("Sin ramas", "Selecciona al menos una rama a probar.")
            return

        token = self.token_entry.get().strip()
        user = self.user_entry.get().strip()
        password = self.pass_entry.get()
        dry_run = self.dry_run_var.get()

        if not dry_run and not token and not (user and password):
            messagebox.showwarning("Credenciales", "Ingresa usuario+password o un token.")
            return

        self.tree.delete(*self.tree.get_children())
        self.log_text.configure(state="normal")
        self.log_text.delete("1.0", "end")
        self.log_text.configure(state="disabled")

        self.running = True
        self.run_button.configure(state="disabled")
        self.status_label.configure(text="Ejecutando…")

        ambiente = self.ambiente_entry.get().strip() or None
        cleanup = self.cleanup_var.get()

        thread = threading.Thread(
            target=self._worker,
            args=(selected, user, password, token, ambiente, dry_run, cleanup),
            daemon=True,
        )
        thread.start()

    def _worker(self, selected, user, password, token, ambiente, dry_run, cleanup):
        if token:
            auth, extra_headers = None, {"Authorization": f"Bearer {token}"}
        else:
            auth, extra_headers = (user, password), {}

        results = []
        for name in selected:
            payload = core.build_payload(name, ambiente=ambiente)
            row = core.send_request(name, payload, auth, extra_headers, dry_run, log=self._log)
            results.append(row)
            self.msg_queue.put(("row", row))

        if dry_run:
            self._log("\n(dry-run: nada se envió ni se guardó en el log)")
            self.msg_queue.put(("done", None))
            return

        if cleanup:
            self._log("\nLimpiando tickets de prueba...")
            core.cleanup_results(results, auth, extra_headers, log=self._log)
            for row in results:
                self.msg_queue.put(("row_update", (row["scenario"], row.get("cleanup_status", ""))))
        else:
            for row in results:
                row["cleanup_status"] = "omitido"
                row["cleanup_error"] = ""
                self.msg_queue.put(("row_update", (row["scenario"], "omitido")))

        try:
            core.log_results(results)
            self._log(f"Resultados agregados a {core.LOG_FILE}")
        except OSError as exc:
            self._log(f"No se pudo escribir el log CSV: {exc}")

        self.msg_queue.put(("done", None))


def launch():
    app = ServiceNowTesterGUI()
    app.mainloop()


if __name__ == "__main__":
    launch()
