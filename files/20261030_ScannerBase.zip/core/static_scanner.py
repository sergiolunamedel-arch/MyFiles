from __future__ import annotations

import re
import tempfile
import time
from dataclasses import dataclass

from ui_common import *
from secrets_scanner import _SecretsPanelMixin, download_file


def _augment_path() -> None:
    cands = [Path(os.environ[k]) / sub for k, sub in (("LOCALAPPDATA", "snyk"), ("LOCALAPPDATA", "snyk/bin"),
                                                         ("APPDATA", "npm")) if os.environ.get(k)]
    parts = os.environ.get("PATH", "").split(os.pathsep)
    extra = [str(c) for c in cands if str(c) not in parts and c.is_dir()]
    if extra:
        os.environ["PATH"] = os.pathsep.join(extra + parts)


_augment_path()

_TLS_MARKERS = ("self-signed certificate", "self signed certificate", "self_signed_cert", "unable to verify",
                "unable to get local issuer", "cert_in_chain", "cert_has_expired", "err_tls", "certificate chain",
                "econnreset", "tunneling socket", "depth_zero_self_signed", "ssl")
_AUTH_MARKERS = ("use `snyk auth`", "use 'snyk auth'", "snyk auth` to authenticate", "snyk auth' to authenticate",
                 "not authenticated", "must be authenticated", "authentication error", "unauthorized",
                 "token is invalid", "invalid auth", "re-authenticate", "401")
# Org corporativa preferida (banco-base-default). Ya NO es la única: cada escaneo usa la primera organización de la
# empresa a la que la cuenta de quien escanea tenga acceso (ver snyk_org_candidates). SNYK_ORG (variable de entorno)
# fuerza una org concreta como primera opción.
DEFAULT_SNYK_ORG = "7c545e26-1865-4ce9-a2e5-2b8c1c215e62"
SNYK_ORG = os.environ.get("SNYK_ORG", "").strip()
_ORG_ERR_MARKERS = ("permissions to access the org", "was not found or you may not have",
                    "is not supported for your current organization", "not a member of the org",
                    "org not found", "organization not found")
_ORG_CACHE_TTL = 1800
_org_lock = threading.Lock()
_org_state: dict = {"fp": None, "at": 0.0, "cands": None, "names": {}, "ok": {}, "last": None}
_works_cache: tuple = (None, 0.0)
_cfg_cache: dict = {"path": None, "data": {}, "mtime": 0.0}
_VERSION_CACHE = Path(tempfile.gettempdir()) / "bbscanner_snyk_version_check.json"
_STANDALONE_DIR = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "snyk" / "bin"
_STANDALONE = _STANDALONE_DIR / "snyk.exe"
_CRED_KEYS = ("api", "INTERNAL_OAUTH_TOKEN_STORAGE", "oauth_token")


def _has(text: str, markers) -> bool:
    low = (text or "").lower()
    return any(m in low for m in markers)


def snyk_bin() -> str:
    return which("snyk") or "snyk"


def _npm() -> str:
    return "npm.cmd"


def find_ca_bundle() -> Optional[str]:
    for var in ("NODE_EXTRA_CA_CERTS", "SSL_CERT_FILE", "REQUESTS_CA_BUNDLE", "CURL_CA_BUNDLE", "SNYK_CA_BUNDLE"):
        p = os.environ.get(var)
        if p and Path(p).is_file() and Path(p).stat().st_size > 0:
            return p
    return None


def export_windows_ca_bundle(log) -> Optional[str]:
    out = Path(tempfile.gettempdir()) / "bbscanner_corp_ca.pem"
    if out.exists() and out.stat().st_size > 0:
        return str(out)
    ps = ("$ErrorActionPreference='SilentlyContinue';$o=@();foreach($s in 'Root','CA'){"
          "  Get-ChildItem \"Cert:\\LocalMachine\\$s\" | ForEach-Object {"
          "    $b=[Convert]::ToBase64String($_.RawData,'InsertLineBreaks');"
          "    $o+=\"-----BEGIN CERTIFICATE-----`n$b`n-----END CERTIFICATE-----\"}};"
          f"$o -join \"`n\" | Out-File -FilePath '{out}' -Encoding ascii")
    try:
        r = run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], timeout=120)
        if out.exists() and "BEGIN CERTIFICATE" in out.read_text(encoding="ascii", errors="ignore"):
            log(f"[tls] almacén de certificados de Windows exportado → {out}")
            return str(out)
        if r.stderr:
            log(f"[tls] no se pudo exportar el almacén de certificados: {r.stderr.strip()[:200]}")
    except Exception as e:
        log(f"[tls] falló la exportación de certificados: {e!r}")
    return None


def _ca(log) -> Optional[str]:
    return find_ca_bundle() or export_windows_ca_bundle(log)


def run_tls(args, cwd=None, timeout=900, log=lambda _: None) -> subprocess.CompletedProcess:
    log(f"$ {' '.join(args)}")
    r = run(args, cwd=cwd, timeout=timeout)
    if r.returncode and _has(r.stdout + r.stderr, _TLS_MARKERS):
        if ca := _ca(log):
            log(f"[tls] reintentando con NODE_EXTRA_CA_CERTS={ca}")
            r = run(args, cwd=cwd, env=dict(os.environ, NODE_EXTRA_CA_CERTS=ca), timeout=timeout)
            if not r.returncode or not _has(r.stdout + r.stderr, _TLS_MARKERS):
                return r
        log("[tls] CA no disponible/insuficiente — reintentando con verificación TLS DESACTIVADA "
            "(NODE_TLS_REJECT_UNAUTHORIZED=0). Es un ajuste local solo para el certificado del proxy.")
        r = run(args, cwd=cwd, env=dict(os.environ, NODE_TLS_REJECT_UNAUTHORIZED="0"), timeout=timeout)
    return r


def setup_proxy_tls_env(log=lambda _: None, prefer_insecure: bool = False) -> str:
    if not prefer_insecure:
        if os.environ.get("NODE_TLS_REJECT_UNAUTHORIZED") == "0" or (
                os.environ.get("NODE_EXTRA_CA_CERTS") and Path(os.environ["NODE_EXTRA_CA_CERTS"]).is_file()):
            return "preset"
        if ca := _ca(log):
            os.environ["NODE_EXTRA_CA_CERTS"] = ca
            log(f"[tls] confiando en el proxy corporativo vía NODE_EXTRA_CA_CERTS={ca}")
            return "ca-bundle"
    os.environ["NODE_TLS_REJECT_UNAUTHORIZED"] = "0"
    os.environ.pop("NODE_EXTRA_CA_CERTS", None)
    log("[tls] se desactiva la verificación TLS de Node (NODE_TLS_REJECT_UNAUTHORIZED=0) para que la CLI de Snyk "
        "funcione detrás del proxy. Solo aplica a los procesos de esta app; configure NODE_EXTRA_CA_CERTS con la CA "
        "de su empresa como alternativa segura.")
    return "insecure"


def _snyk_works(timeout: int = 90) -> tuple[bool, str]:
    global _works_cache
    cached, at = _works_cache
    if cached is not None and time.time() - at < 300:
        return cached
    if not which("snyk"):
        return False, "No se encontró la CLI de Snyk en PATH"
    try:
        r = run([snyk_bin(), "--version"], timeout=timeout)
        if not r.returncode and re.search(r"\d+\.\d+\.\d+", r.stdout or ""):
            _works_cache = ((True, r.stdout.strip().splitlines()[0][:60]), time.time())
            return _works_cache[0]
        return False, (r.stdout + r.stderr).strip()[:300] or f"código de salida {r.returncode}"
    except Exception as e:
        return False, repr(e)


def _install_standalone(log) -> bool:
    if _STANDALONE.exists() and _STANDALONE.stat().st_size > 1024:
        log(f"[snyk] CLI independiente ya en caché → {_STANDALONE} (use 'Reinstalar (limpio)' para forzar la última)")
    else:
        log("[snyk] instalando la CLI independiente (snyk-win.exe)…")
        if not download_file("https://static.snyk.io/cli/latest/snyk-win.exe", _STANDALONE, log, timeout=180):
            return False
    os.environ["PATH"] = str(_STANDALONE_DIR) + os.pathsep + os.environ.get("PATH", "")
    return _STANDALONE.exists()


def ensure_snyk_ready(log) -> bool:
    ok, detail = _snyk_works(30)
    if ok:
        log(f"[snyk] CLI lista ({detail})")
        return True
    log(f"[snyk] CLI presente pero aún no ejecutable: {detail}")
    mode = setup_proxy_tls_env(log)
    if (r := _snyk_works(180))[0]:
        log(f"[snyk] CLI lista tras configurar TLS [{mode}] ({r[1]})")
        return True
    if mode == "ca-bundle":
        setup_proxy_tls_env(log, prefer_insecure=True)
        if (r := _snyk_works(180))[0]:
            log(f"[snyk] CLI lista tras desactivar la verificación TLS ({r[1]})")
            return True
    log("[snyk] reparando con el binario independiente de Snyk (evita la descarga bloqueada del wrapper de npm)…")
    if _install_standalone(log):
        if (r := _snyk_works(180))[0]:
            log(f"[snyk] CLI independiente lista ({r[1]})")
            return True
        log(f"[snyk] la CLI independiente sigue sin ejecutarse: {r[1]}")
    log("[snyk] no se pudo obtener una CLI de Snyk ejecutable automáticamente. Si su red usa un proxy con inspección "
        "TLS, pida a TI el .pem de la CA raíz, configure NODE_EXTRA_CA_CERTS y reintente.")
    return False


@dataclass
class CheckResult:
    name: str
    ok: bool
    detail: str = ""
    fixable: bool = False


def _check_tool(label: str, cmd: str) -> CheckResult:
    exe = which(cmd)
    if not exe:
        return CheckResult(label, False, "no se encontró en PATH", True)
    try:
        r = run([exe, "--version"])
        return CheckResult(label, not r.returncode, r.stdout.strip(), True)
    except Exception as e:
        return CheckResult(label, False, str(e), True)


def check_node() -> CheckResult:
    return _check_tool("Node.js", "node")


def check_npm() -> CheckResult:
    return _check_tool("npm", "npm")


def check_snyk() -> CheckResult:
    if not which("snyk"):
        return CheckResult("Snyk CLI", False, "no se encontró en PATH", True)
    ok, detail = _snyk_works(30)
    if ok:
        return CheckResult("Snyk CLI", True, detail, True)
    if _has(detail, _TLS_MARKERS) or any(k in detail for k in ("download", "ENOENT", "código de salida")):
        return CheckResult("Snyk CLI", False, "presente pero no inicia (el proxy/certificado bloquea su descarga)", True)
    return CheckResult("Snyk CLI", False, detail[:120], True)


def _semver(v: str) -> tuple:
    m = re.search(r"(\d+)\.(\d+)\.(\d+)", v or "")
    return tuple(map(int, m.groups())) if m else (0, 0, 0)


def check_snyk_version_current(log=lambda *_: None, *, force: bool = False) -> tuple[bool, str]:
    now = time.time()
    c = read_json(_VERSION_CACHE) if not force else None
    if c and now - c.get("checked_at", 0) < 7 * 24 * 3600:
        return bool(c.get("is_current", True)), c.get("detail", "en caché")
    ok, inst = _snyk_works(10)
    if not ok:
        return True, "snyk no ejecutable — nada que comparar (la reparación normal se encarga)"
    installed = (m.group(1) if (m := re.search(r"(\d+\.\d+\.\d+)", inst)) else "")
    latest = None
    if which("npm"):
        setup_proxy_tls_env(log)
        try:
            v = run([_npm(), "view", "snyk", "version"], timeout=15).stdout.strip()
            latest = v if re.match(r"^\d+\.\d+\.\d+", v) else None
        except Exception as e:
            log(f"[snyk] no se pudo consultar la última versión vía npm: {e!r}")
    if not latest or not installed:
        return True, "no se pudo determinar la última versión (sin red o sin npm) — se omite la verificación"
    cur, detail = _semver(installed) >= _semver(latest), f"instalada {installed}, última {latest}"
    try:
        write_json(_VERSION_CACHE, {"checked_at": now, "is_current": cur, "detail": detail})
    except Exception:
        pass
    return cur, detail


def _cfg_path() -> Optional[Path]:
    if _cfg_cache["path"] is None:
        cands = [Path(os.environ[k]) / "configstore" / "snyk.json" for k in ("APPDATA", "LOCALAPPDATA")
                 if os.environ.get(k)]
        cands += [Path.home() / ".config" / "configstore" / "snyk.json", Path.home() / ".snyk" / "config.json"]
        _cfg_cache["path"] = next((p for p in cands if p.exists()), False)
    return _cfg_cache["path"] or None


def _snyk_cfg(key: str) -> str:
    try:
        if p := _cfg_path():
            mt = p.stat().st_mtime
            if mt != _cfg_cache["mtime"]:
                _cfg_cache.update(data=json.loads(p.read_text(encoding="utf-8")), mtime=mt)
            v = _cfg_cache["data"].get(key)
            return "" if v is None or str(v).lower() in ("", "undefined", "null", "not set") else str(v)
    except Exception:
        pass
    try:
        v = run([snyk_bin(), "config", "get", key]).stdout.strip()
        return "" if v.lower() in ("", "undefined", "null", "not set") else v
    except Exception:
        return ""


def check_auth() -> CheckResult:
    if not which("snyk"):
        return CheckResult("Snyk auth", False, "Falta la CLI de Snyk", True)
    if _snyk_cfg("api"):
        return CheckResult("Snyk auth", True, "token configurado", True)
    if _snyk_cfg("INTERNAL_OAUTH_TOKEN_STORAGE") or _snyk_cfg("oauth_token"):
        return CheckResult("Snyk auth", True, "SSO/OAuth configurado", True)
    return CheckResult("Snyk auth", False, "sin autenticación", True)


def _reset_cfg_cache(full: bool = False) -> None:
    _cfg_cache.update(data={}, mtime=0.0, **({"path": None} if full else {}))


def clear_snyk_credentials(log) -> None:
    reset_org_cache()
    if p := _cfg_path():
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            if any(data.pop(k, None) is not None for k in list(_CRED_KEYS)):
                p.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
                _reset_cfg_cache()
            log("[auth] credenciales de Snyk eliminadas — iniciando un nuevo inicio de sesión vía el SSO de su organización.")
            return
        except Exception as e:
            log(f"[auth] no se pudo limpiar el archivo directamente ({e!r}); se usa la CLI.")
    for k in _CRED_KEYS:
        try:
            run([snyk_bin(), "config", "unset", k], timeout=20)
        except Exception:
            pass
    log("[auth] credenciales de Snyk eliminadas — iniciando un nuevo inicio de sesión vía el SSO de su organización.")


def _winget(args: list, log, timeout=1800) -> bool:
    r = run(["winget", *args, "-e", "--source", "winget", "--silent", "--accept-package-agreements",
             "--accept-source-agreements"], timeout=timeout)
    log((r.stdout or "") + (r.stderr or ""))
    return not r.returncode


def install_node(log) -> bool:
    if which("node") and which("npm"):
        log("[node] ya instalado")
        return True
    if not which("winget"):
        log("[node] instale Node.js LTS desde https://nodejs.org/")
        return False
    log("[node] instalando vía winget (origen: winget, no msstore)…")
    return _winget(["install", "--id", "OpenJS.NodeJS.LTS"], log)


def install_snyk(log, *, force: bool = False) -> bool:
    setup_proxy_tls_env(log)
    if which("snyk") and not force:
        if _snyk_works(30)[0]:
            log("[snyk] ya instalado y ejecutable")
            return True
        log("[snyk] está en PATH pero no se ejecuta — reparando…")
        if ensure_snyk_ready(log):
            return True
        log("[snyk] la reparación no funcionó; intentando una instalación nueva…")
    elif which("snyk"):
        log(f"[snyk] reinstalación forzada: 'snyk' sigue en PATH ({which('snyk')}) — un paso de desinstalación "
            "pudo omitirlo. Se instala de nuevo de todas formas.")
    if which("npm"):
        r = run_tls([_npm(), "install", "-g", "snyk"], log=log, timeout=1800)
        log((r.stdout or "") + (r.stderr or ""))
        _augment_path()
        if which("snyk") and ensure_snyk_ready(log):
            return True
        log("[snyk] npm install no produjo un 'snyk' ejecutable; probando alternativa…")
    if which("winget"):
        log("[snyk] instalando vía winget (Snyk.SnykCLI)…")
        _winget(["install", "--id", "Snyk.SnykCLI"], log)
        _augment_path()
        if which("snyk") and ensure_snyk_ready(log):
            return True
    log("[snyk] se recurre al binario independiente de la CLI de Snyk…")
    return _install_standalone(log) and ensure_snyk_ready(log)


def reinstall_snyk_clean(log) -> bool:
    global _works_cache
    log("[snyk] === reinstalación limpia solicitada — esto cerrará la sesión de Snyk ===")
    steps = []
    if which("npm"):
        steps.append([_npm(), "uninstall", "-g", "snyk"])
    if which("winget"):
        steps.append(["winget", "uninstall", "--id", "Snyk.SnykCLI", "-e", "--source", "winget", "--silent"])
    if scoop := which("scoop"):
        steps.append([scoop, "uninstall", "snyk"])
    for cmd in steps:
        try:
            log(f"[snyk] {' '.join(cmd[:3])}")
            r = run(cmd, timeout=300)
            log(((r.stdout or "") + (r.stderr or "")).strip()[-800:])
        except Exception as e:
            log(f"[snyk] omitido: {e!r}")
    for f in (_STANDALONE, Path(os.environ.get("SCOOP") or Path.home() / "scoop") / "shims" / "snyk.exe", _cfg_path()):
        try:
            if f and f.exists():
                f.unlink()
                log(f"[snyk] eliminado: {f}")
        except Exception as e:
            log(f"[snyk] no se pudo eliminar {f}: {e!r}")
    _reset_cfg_cache(full=True)
    _works_cache = (None, 0.0)
    ok = install_snyk(log, force=True)
    if ok:
        log(f"[snyk] reinstalación limpia completa — binario activo: {which('snyk')} ({_snyk_works(30)[1]}) — inicie "
            "sesión de nuevo antes de escanear.")
        try:
            log(f"[snyk] caché de versión actualizada: {check_snyk_version_current(log, force=True)[1]}")
        except Exception as e:
            log(f"[snyk] no se pudo actualizar la caché de versión: {e!r}")
    else:
        log("[snyk] la reinstalación limpia no terminó con una CLI funcional — revise el registro anterior "
            "(puede requerir instalación manual).")
    return ok


def start_snyk_auth(log) -> subprocess.Popen:
    setup_proxy_tls_env(log)
    log("[auth] ejecutando `snyk auth` — el navegador se abrirá en breve.")
    flags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0) | getattr(subprocess, "CREATE_NO_WINDOW", 0)
    return subprocess.Popen([snyk_bin(), "auth"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                            encoding="utf-8", errors="replace", creationflags=flags,
                            env=dict(os.environ, SNYK_DISABLE_ANALYTICS="1", DISABLE_ANALYTICS="1"))


def _parse_json_loose(text: str) -> Any:
    if not (text or "").strip():
        return None
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        docs = []
        for line in text.splitlines():
            try:
                docs.append(json.loads(line))
            except json.JSONDecodeError:
                pass
        return docs or None


def _items(d) -> list:
    return d if isinstance(d, list) else [d]


def _error_envelope(data) -> str:
    items = _items(data)
    if any(isinstance(i, dict) and (i.get("ok") is True or any(k in i for k in (
            "vulnerabilities", "dependencyCount", "packageManager", "uniqueCount", "runs"))) for i in items):
        return ""
    return next((str(i["error"]) for i in items if isinstance(i, dict) and i.get("ok") is False and i.get("error")
                 and not _has(str(i["error"]), _AUTH_MARKERS)), "")


def _prepare_pip_sandbox(target: Path, log) -> Optional[dict]:
    req = target / "requirements.txt"
    if not req.exists():
        return None
    venv, wheels = target / ".snyk-venv", target / ".snyk-wheels"
    wheels.mkdir(exist_ok=True)
    py = venv / "Scripts" / "python.exe"
    if not py.exists():
        log(f"[sandbox] creando venv aislado en {venv}…")
        r = run([sys.executable, "-m", "venv", str(venv)], timeout=300)
        if r.returncode:
            log(f"[sandbox] falló el venv: {(r.stderr or r.stdout).strip()}")
            return None
        run([str(py), "-m", "pip", "install", "--upgrade", "pip", "--disable-pip-version-check"], timeout=600)
    log("[sandbox] descargando wheels (solo binarios, no se ejecuta código)…")
    for args in (["download", "--only-binary=:all:", "--dest", str(wheels)],
                 ["install", "--no-index", "--find-links", str(wheels), "--only-binary=:all:", "--no-build-isolation"]):
        r = run([str(py), "-m", "pip", *args, "-r", str(req), "--disable-pip-version-check"], timeout=900)
        log(((r.stdout or "") + (r.stderr or "")).strip()[-3000:])
        if args[0] == "download" and not list(wheels.glob("*.whl")):
            log("[sandbox] no se descargaron wheels; se omite el sandbox.")
            return None
    pkgs = run([str(py), "-m", "pip", "list", "--format=freeze"], timeout=60).stdout.strip()
    if not pkgs:
        log("[sandbox] venv vacío; SCA podría reportar 0.")
        return None
    log(f"[sandbox] listo ({len(pkgs.splitlines())} paquetes visibles para Snyk).")
    env = dict(os.environ, VIRTUAL_ENV=str(venv), PATH=str(py.parent) + os.pathsep + os.environ.get("PATH", ""))
    env.pop("PYTHONHOME", None)
    return env


class SnykScanError(RuntimeError):
    def __init__(self, *args, is_auth: bool = False):
        super().__init__(*args)
        self.is_auth = is_auth


def _snyk_json_scan(args, *, target, out_dir, out_name, log, env=None, timeout=1800, write_raw=False, label="Snyk"):
    log(f"[escaneo] $ snyk {' '.join(args[1:])}  (cwd={target})")
    env = env or os.environ.copy()
    r = run(args, cwd=target, env=env, timeout=timeout)
    data = _parse_json_loose(r.stdout)
    if data is None and _has(r.stdout + r.stderr, _TLS_MARKERS):
        if ca := _ca(log):
            log(f"[escaneo][tls] reintentando con NODE_EXTRA_CA_CERTS={ca}")
            r = run(args, cwd=target, env=dict(env, NODE_EXTRA_CA_CERTS=ca), timeout=timeout)
            data = _parse_json_loose(r.stdout)
        if data is None and _has(r.stdout + r.stderr, _TLS_MARKERS):
            log("[escaneo][tls] CA no disponible/insuficiente — reintentando con verificación TLS DESACTIVADA "
                "(NODE_TLS_REJECT_UNAUTHORIZED=0) + snyk --insecure.")
            r = run([*args, *(["--insecure"] if "--insecure" not in args else [])], cwd=target,
                    env=dict(env, NODE_TLS_REJECT_UNAUTHORIZED="0"), timeout=timeout)
            data = _parse_json_loose(r.stdout)
    combined = r.stdout + r.stderr
    if r.stderr:
        log(r.stderr.strip()[-2000:])
        if data is None:
            data = _parse_json_loose(r.stderr)
    out = out_dir / out_name
    out.write_text(r.stdout if write_raw else json.dumps(data, indent=2), encoding="utf-8")
    auth_fail = any(isinstance(i, dict) and i.get("ok") is False and _has(str(i.get("error", "")), _AUTH_MARKERS)
                    for i in _items(data))
    if auth_fail or (data is None and _has(combined, _AUTH_MARKERS)):
        raise SnykScanError(f"El escaneo {label} falló: sin autenticación en Snyk. La credencial guardada falta o "
                            "expiró. Use «Snyk» → Re-iniciar sesión y elija «Log in with SSO» (no su correo "
                            "y contraseña).", is_auth=True)
    if err := _error_envelope(data):
        if is_org_error(err):
            raise SnykScanError(f"El escaneo {label} no pudo usar la organización: {err}")
        try:
            diag = json.dumps(data, indent=2, ensure_ascii=False)[:2000]
        except Exception:
            diag = repr(data)[:2000]
        log(f"[escaneo][diag] respuesta de error de Snyk (detalle completo — ayuda a distinguir un problema de "
            f"versión/organización/proxy de uno del código): {diag}")
        try:
            v = run([snyk_bin(), "--version"], timeout=15)
            log(f"[escaneo][diag] binario snyk: {which('snyk')}  versión: {(v.stdout or v.stderr or '?').strip()}")
        except Exception as e:
            log(f"[escaneo][diag] no se pudo leer snyk --version: {e!r}")
        raise SnykScanError(f"El escaneo {label} no pudo analizar el objetivo (nada escaneable aquí): {err}")
    if data is None:
        tail = " ".join((combined.strip() or "sin salida").splitlines()[-6:])[:600]
        if _has(combined, _TLS_MARKERS):
            raise SnykScanError(f"El escaneo {label} falló: la CLI de Snyk no pudo conectarse por la red (error "
                                "TLS/certificado autofirmado de un proxy corporativo). Configure NODE_EXTRA_CA_CERTS "
                                f"con la CA de su empresa o ejecute con --insecure. Detalle: {tail}")
        raise SnykScanError(f"El escaneo {label} falló — no devolvió JSON. Detalle: {tail}")
    if label == "SCA":
        n = sum(len(p.get("vulnerabilities") or []) for p in _items(data) if isinstance(p, dict))
        log(f"[escaneo] SCA vulnerabilidades totales: {n}")
        _warn_missing_build_tools(combined, log)
    log(f"[escaneo] JSON crudo → {out}")
    return data, out


_BUILD_TOOLS = {"mvn": ("Maven", "pom.xml", "winget install Apache.Maven"),
                "gradle": ("Gradle", "build.gradle", "winget install Gradle.Gradle"),
                "dotnet": (".NET SDK", "*.csproj / *.sln", "winget install Microsoft.DotNet.SDK.8"),
                "go": ("Go", "go.mod", "winget install GoLang.Go"),
                "pip": ("Python/pip", "requirements.txt", "winget install Python.Python.3.12")}


def _warn_missing_build_tools(output: str, log) -> None:
    """Snyk necesita la herramienta de build del proyecto para resolver sus dependencias. Si falta, ese proyecto se
    omite del SCA en silencio («✗ 1/4 potential projects failed»): aquí se avisa qué falta y cómo instalarlo."""
    low = (output or "").lower()
    for exe, (name, manifest, fix) in _BUILD_TOOLS.items():
        if re.search(rf'["\']?{exe}["\']?\s+(no se reconoce|is not recognized|: command not found|not found)', low):
            m = re.search(r"(\d+)/(\d+) potential projects failed", low)
            cnt = f" ({m.group(1)} de {m.group(2)} proyectos)" if m else ""
            log(f"[snyk] ⚠ SCA PARCIAL{cnt}: los proyectos con {manifest} NO se analizaron porque {name} no está "
                f"instalado en esta PC ('{exe}' no está en el PATH). Sus dependencias no aparecen en el reporte. "
                f"Instálelo ({fix}), abra de nuevo el escáner y repita el escaneo. Los demás proyectos sí se analizaron.")


# ── Organización de Snyk ─────────────────────────────────────────────────────────────────────────────────────────
# Antes cada escaneo iba fijo a --org=<banco-base-default>. Si la cuenta de quien escanea no es miembro de ESA org
# (aunque sea de otra org de la empresa, o esté en el grupo), Snyk responde «Org … was not found or you may not have the
# correct permissions» y SCA/SAST fallan. Las versiones anteriores no pasaban --org (usaban la org por defecto de la
# cuenta), por eso a esos usuarios sí les funcionaban.
# Ahora: se consulta a la API de Snyk, con la misma sesión de la CLI, a qué organizaciones (no personales) tiene acceso
# la cuenta, y se prueban en orden; la que funcione se recuerda durante la sesión. Si la API no responde, se prueba la
# org corporativa y, como último recurso, la org por defecto de la cuenta (lo que hacían las versiones anteriores).
def reset_org_cache() -> None:
    with _org_lock:
        _org_state.update(fp=None, at=0.0, cands=None, ok={}, last=None)


def is_org_error(text: str) -> bool:
    return _has(text, _ORG_ERR_MARKERS)


def org_label(org: Optional[str]) -> str:
    if not org:
        return "por defecto de la cuenta"
    name = _org_state["names"].get(org)
    return f"«{name}» ({org})" if name else org


def last_used_org() -> str:
    """Org con la que se completó el último escaneo de Snyk (para tickets/reportes)."""
    org = _org_state.get("last")
    if org is None:
        return SNYK_ORG or DEFAULT_SNYK_ORG
    return _org_state["names"].get(org, org) if org else "org por defecto de la cuenta Snyk"


def _oauth_token() -> dict:
    raw = _snyk_cfg("INTERNAL_OAUTH_TOKEN_STORAGE") or _snyk_cfg("oauth_token")
    if not raw:
        return {}
    try:
        tok = json.loads(raw)
        return tok if isinstance(tok, dict) else {}
    except Exception:
        return {"access_token": raw}


def _token_expired(tok: dict) -> bool:
    exp = str(tok.get("expiry") or "")
    if not exp:
        return False
    try:
        from datetime import timezone
        m = re.match(r"(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(?:\.\d+)?(Z|[+-]\d{2}:\d{2})?", exp)
        if not m:
            return False
        dt = datetime.fromisoformat(m.group(1) + ((m.group(2) or "+00:00").replace("Z", "+00:00")))
        return dt.timestamp() - time.time() < 90
    except Exception:
        return False


def _jwt_claims(token: str) -> dict:
    try:
        import base64
        part = token.split(".")[1]
        return json.loads(base64.urlsafe_b64decode(part + "=" * (-len(part) % 4)))
    except Exception:
        return {}


def _api_base(access_token: str = "") -> str:
    if v := os.environ.get("SNYK_API", "").strip():
        return v.rstrip("/").removesuffix("/v1").removesuffix("/api").replace("://app.", "://api.")
    cl = _jwt_claims(access_token) if access_token else {}
    for v in [*(cl.get("aud") if isinstance(cl.get("aud"), list) else [cl.get("aud")]), cl.get("iss")]:
        if isinstance(v, str) and (m := re.match(r"(https://api\.[\w.-]*snyk\.io)", v)):
            return m.group(1)
    if ep := _snyk_cfg("endpoint"):
        if m := re.match(r"(https://)(?:app|api)\.([\w.-]*snyk\.io)", ep):
            return f"{m.group(1)}api.{m.group(2)}"
    return "https://api.snyk.io"


def _snyk_auth_header(log) -> tuple[str, str, str]:
    """(encabezado Authorization, base de la API, huella de la credencial) a partir de la sesión de la CLI."""
    if api := _snyk_cfg("api"):
        return f"token {api}", _api_base(), "api:" + api[-12:]
    tok = _oauth_token()
    if tok and _token_expired(tok):
        # La CLI renueva el token OAuth sola al usarse; un comando ligero basta para refrescarlo.
        try:
            run([snyk_bin(), "whoami", "--experimental"], timeout=60)
            _reset_cfg_cache()
            tok = _oauth_token() or tok
        except Exception as e:
            log(f"[snyk] no se pudo renovar el token OAuth para consultar organizaciones: {e!r}")
    at = tok.get("access_token", "")
    if not at:
        return "", "", ""
    return f"Bearer {at}", _api_base(at), "oauth:" + str(tok.get("refresh_token") or at)[-12:]


def _api_get(url: str, auth: str):
    import ssl
    import urllib.request
    req = urllib.request.Request(url, headers={"Authorization": auth, "Accept": "application/vnd.api+json",
                                               "User-Agent": "ScannerBase"})
    ctx = ssl.create_default_context()
    for ca in (find_ca_bundle(), os.environ.get("NODE_EXTRA_CA_CERTS")):
        if ca and Path(ca).is_file():
            try:
                ctx.load_verify_locations(ca)
            except Exception:
                pass
    insecure = ssl.create_default_context()
    insecure.check_hostname, insecure.verify_mode = False, ssl.CERT_NONE
    last = None
    for c in (ctx, insecure):  # mismo criterio que la CLI: CA corporativa y, si el proxy la rompe, sin verificación
        try:
            with urllib.request.urlopen(req, timeout=25, context=c) as r:
                return json.loads(r.read().decode("utf-8", "replace"))
        except Exception as e:
            last = e
            if not _has(repr(e), ("ssl", "certificate")):
                break
    raise last


def _fetch_orgs(log) -> Optional[tuple[list, str, str]]:
    """([{id,name,personal,group}], org por defecto de la cuenta, huella) o None si no se pudo consultar."""
    auth, base, fp = _snyk_auth_header(log)
    if not auth:
        return None
    ver = "version=2024-10-15"
    try:
        default_ctx = ""
        try:
            me = _api_get(f"{base}/rest/self?{ver}", auth)
            default_ctx = str(((me or {}).get("data") or {}).get("attributes", {}).get("default_org_context") or "")
        except Exception:
            pass
        orgs, url = [], f"{base}/rest/orgs?{ver}&limit=100"
        for _ in range(10):
            d = _api_get(url, auth) or {}
            for o in d.get("data") or []:
                a = o.get("attributes") or {}
                orgs.append({"id": o.get("id", ""), "name": a.get("name") or a.get("slug") or "",
                             "personal": bool(a.get("is_personal")), "group": a.get("group_id") or ""})
            nxt = (d.get("links") or {}).get("next")
            if not nxt:
                break
            url = nxt if nxt.startswith("http") else base + (nxt if nxt.startswith("/rest") else "/rest" + nxt)
        return orgs, default_ctx, fp
    except Exception as e:
        log(f"[snyk] no se pudo consultar las organizaciones de la cuenta en la API de Snyk ({e!r}) — se usará la "
            "org corporativa y, si falla, la org por defecto de la cuenta.")
        return None


def snyk_org_candidates(log) -> list:
    """Orden en que se prueban las orgs: forzada (SNYK_ORG) → corporativa → la por defecto de la cuenta → demás orgs
    de la empresa → "" (sin --org: org por defecto de la cuenta, como las versiones anteriores)."""
    with _org_lock:
        if _org_state["cands"] is not None and time.time() - _org_state["at"] < _ORG_CACHE_TTL:
            return list(_org_state["cands"])
        res = _fetch_orgs(log)
        cands = [SNYK_ORG] if SNYK_ORG else []
        if res is None:
            cands.append(DEFAULT_SNYK_ORG)
        else:
            orgs, default_ctx, fp = res
            company = [o for o in orgs if o["id"] and not o["personal"]]
            _org_state["names"].update({o["id"]: o["name"] for o in orgs if o["id"]})
            groups = {o["group"] for o in company if o["id"] == DEFAULT_SNYK_ORG and o["group"]}
            rank = {DEFAULT_SNYK_ORG: 0, default_ctx: 1}
            company.sort(key=lambda o: (rank.get(o["id"], 2), bool(groups) and o["group"] not in groups,
                                        o["name"].lower()))
            cands += [o["id"] for o in company]
            if company:
                log("[snyk] organizaciones de la empresa disponibles para esta cuenta: "
                    + ", ".join(org_label(o["id"]) for o in company[:6]) + (" …" if len(company) > 6 else ""))
            else:
                log("[snyk] ⚠ esta cuenta de Snyk no tiene acceso a ninguna organización de la empresa (solo a su "
                    "org personal). Normalmente significa que inició sesión con correo y contraseña en vez de "
                    "«Log in with SSO», o que la cuenta aún no fue agregada a una organización.")
            _org_state["fp"] = fp
        cands.append("")
        seen: set = set()
        cands = [c for c in cands if not (c in seen or seen.add(c))]
        _org_state.update(cands=cands, at=time.time())
        return list(cands)


def _scan_with_org(kind: str, label: str, make_args, log, **kw):
    cands = snyk_org_candidates(log)
    if (ok := _org_state["ok"].get(kind)) is not None and ok in cands:
        cands.remove(ok)
        cands.insert(0, ok)
    last_err = None
    for i, org in enumerate(cands):
        try:
            res = _snyk_json_scan(make_args([f"--org={org}"] if org else []), log=log, label=label, **kw)
        except SnykScanError as e:
            if e.is_auth or not is_org_error(str(e)):
                raise
            last_err = e
            nxt = cands[i + 1] if i + 1 < len(cands) else None
            log(f"[snyk] {label}: la organización {org_label(org)} no está disponible para esta sesión "
                f"({str(e).split('organización: ', 1)[-1][:160]}). "
                + (f"Se intenta con la organización {org_label(nxt)}…" if nxt is not None else
                   "No quedan más organizaciones por probar."))
            continue
        with _org_lock:
            _org_state["ok"][kind] = org
            _org_state["last"] = org
        if i:
            log(f"[snyk] {label} completado en la organización {org_label(org)}.")
        return res
    raise last_err or SnykScanError(f"El escaneo {label} no encontró una organización de Snyk utilizable.")


def run_snyk_test(target: Path, out_dir: Path, log):
    setup_proxy_tls_env(log)
    env = _prepare_pip_sandbox(target, log)
    return _scan_with_org("sca", "SCA", lambda org: [snyk_bin(), "test", "--all-projects", "--detection-depth=10",
                                                     "--strict-out-of-sync=false", "--skip-unresolved", *org,
                                                     "--json"],
                          log, target=target, out_dir=out_dir, out_name="snyk_test.json", env=env)


def run_snyk_code(target: Path, out_dir: Path, log):
    setup_proxy_tls_env(log)
    return _scan_with_org("code", "SAST", lambda org: [snyk_bin(), "code", "test", *org, "--json"], log,
                          target=target, out_dir=out_dir, out_name="snyk_code.json", write_raw=True)


def _context_from_dir(out_dir: Path) -> dict:
    """Reconstruye el contexto del reporte a partir de los JSON crudos de una carpeta de reporte."""
    from report_engine import build_context
    d = Path(out_dir)
    sec = read_json(d / "secrets" / "secrets.json")
    meta = read_json(d / "meta.json") or {}
    return build_context(read_json(d / "snyk_test.json"), read_json(d / "snyk_code.json"), meta.get("target", str(d)),
                         meta.get("snyk_version", ""), read_json(d / "dast.json"), read_json(d / "api.json"), sec,
                         container_data=read_json(d / "container.json"), iac_data=read_json(d / "iac.json"))


def export_sarif(out_dir: Path, ctx: Optional[dict] = None) -> Optional[Path]:
    """SARIF 2.1.0 unificado (un run por herramienta) desde el modelo común de hallazgos."""
    import findings
    return findings.export_sarif(Path(out_dir), ctx if ctx is not None else _context_from_dir(out_dir))


def export_merged_json(out_dir: Path, ctx: Optional[dict] = None) -> Optional[Path]:
    """JSON unificado de todas las etapas, con CWE/OWASP, herramientas que lo detectaron y correlación."""
    import findings
    return findings.export_unified_json(Path(out_dir), ctx if ctx is not None else _context_from_dir(out_dir))


class _StaticTabMixin(_SecretsPanelMixin):
    def _sev_color(self, sev):
        sev = sev_norm(sev)
        return T["err"] if sev in ("critical", "high") else T["accent"] if sev == "medium" else T["muted"]

    def _group_tree(self, parent, tree_col, cols, headings):
        tree = make_tree(parent, cols, headings, 7, tree_col=tree_col)
        tree.tag_configure("group", foreground=T["text"], font=(FUI, 12))
        tree.tag_configure("crit", foreground=T["err"])
        tree.tag_configure("med", foreground=T["text"])
        tree.tag_configure("muted", foreground=T["muted"])
        return tree

    @staticmethod
    def _leaf_tag(sev):
        return {"critical": "crit", "high": "crit", "medium": "med"}.get(sev, "muted")

    def _fill_group_tree(self, tree, summary, groups: dict, extra):
        clear_tree(tree)
        total = 0
        for name in sorted(groups):
            issues = groups[name]
            total += len(issues)
            worst = max((sev_norm(i.get("severity")) for i in issues), key=SEV_RANK.get)
            p = tree.insert("", "end", text=f"{name}   ({len(issues)})", values=(SEV_ES[worst], extra(issues, None)),
                            tags=("group",))
            for i in issues:
                s = sev_norm(i.get("severity"))
                tree.insert(p, "end", text="   " + (i.get("title") or ""), values=(SEV_ES[s], extra(None, i)),
                            tags=(self._leaf_tag(s),))
        if not total:
            tree.insert("", "end", text="  Sin hallazgos — ejecute un escaneo.", tags=("muted",))
        summary.config(text="sin hallazgos" if not total else f"{total} hallazgo{'' if total == 1 else 's'}")

    @staticmethod
    def _fix_txt(v) -> str:
        return f"→ {v}" if v not in (None, "", "—") else "—"

    def _render_sca(self, projects):
        groups: dict = {}
        for proj in projects or []:
            for i in proj.get("issues", []):
                groups.setdefault(i.get("package", "—"), []).append(i)

        def extra(issues, leaf):
            if leaf is not None:
                return self._fix_txt(leaf.get("fixedIn"))
            return self._fix_txt(next((i["fixedIn"] for i in issues if i.get("fixedIn") not in (None, "", "—")), None))
        self._fill_group_tree(self._static_sca_tree, self._sca_summary, groups, extra)

    def _render_sast(self, files):
        groups = {f.get("file", "—"): f["issues"] for f in files or [] if f.get("issues")}
        self._fill_group_tree(self._static_sast_tree, self._sast_summary, groups,
                              lambda _g, leaf: "" if leaf is None else str(leaf.get("line", "?")))

    def _build_tab_static(self, parent):
        pad = self._scrollable(parent)
        row = tk.Frame(pad, bg=T["bg"])
        row.pack(fill="x", pady=(0, CARD_GAP), anchor="w")
        run_btn = PillButton(row, "Escanear código", lambda: self._start_static_scan(set(STATIC_STAGES)), icon="play",
                             variant="primary", tooltip="SCA + SAST + Secretos sobre las rutas de la lista")
        run_btn.pack(side="left")
        self._static_run_btns = [run_btn]
        tk.Frame(row, bg=T["border"], width=1).pack(side="left", fill="y", padx=px(12), pady=px(4))
        self._btn(row, "+ Carpeta", self._add_static_folder).pack(side="left", padx=(0, px(6)))
        self._btn(row, "+ Archivo", self._add_static_files).pack(side="left", padx=(0, px(6)))
        PillButton(row, "Quitar seleccionadas", self._remove_static_paths, icon="delete", variant="danger_ghost").pack(
            side="left")
        tk.Label(row, text="Ctrl / Mayús + clic para seleccionar varias", font=(FUI, 9), bg=T["bg"],
                 fg=T["muted"]).pack(side="right")
        fold = self._card(pad, "Carpetas y archivos a analizar", collapsible=False, pady=(0, CARD_GAP))
        self._static_paths_box = tk.Frame(fold, bg=T["panel_bg"])
        self._static_paths_box.pack(fill="x")
        self._static_sel: set[int] = set()
        self._static_anchor = None
        self._render_static_paths()
        self._static_results_row = tk.Frame(pad, bg=T["bg"])
        halves = []
        for title, tree_col, cols, heads in (
                ("SCA", ("Paquete  /  Vulnerabilidad", 220), ("sev", "fix"),
                 [("Severidad", 90, "w", False), ("Corrección disponible", 140, "w", False)]),
                ("SAST", ("Archivo  /  Hallazgo", 220), ("sev", "line"),
                 [("Severidad", 90, "w", False), ("Línea", 70, "center", False)])):
            half = tk.Frame(self._static_results_row, bg=T["bg"])
            half.pack(side="left", fill="both", expand=True, padx=CARD_GAP // 2)
            inner = self._card(half, title, pady=(0, 0))
            summary = tk.Label(inner.right, text="sin hallazgos", font=(FUI, 12), bg=T["panel_bg"], fg=T["muted"])
            summary.pack(side="right")
            halves.append((self._group_tree(inner, tree_col, cols, heads), summary))
        (self._static_sca_tree, self._sca_summary), (self._static_sast_tree, self._sast_summary) = halves
        self._render_sca([])
        self._render_sast([])
        self._static_secrets_wrap = self._build_secrets_panel(pad)
        self._static_results_visible = False

    def _render_static_paths(self):
        box = getattr(self, "_static_paths_box", None)
        if box is None or not box.winfo_exists():
            return
        for w in box.winfo_children():
            w.destroy()
        if not self._static_paths:
            tk.Label(box, text="Ninguna ruta agregada. Use «+ Carpeta» para elegir la raíz de su repositorio.",
                     font=(FUI, 10), bg=T["panel_bg"], fg=T["muted"], anchor="w").pack(fill="x", pady=px(4))
        for i, path in enumerate(self._static_paths):
            sel = i in self._static_sel
            bg = T["select"] if sel else T["panel_bg"]
            row = tk.Frame(box, bg=bg, cursor="hand2")
            row.pack(fill="x", pady=(0, px(2)))
            ic = tk.Label(row, text=ico("folder" if Path(path).is_dir() else "document"), font=icon_font(11), bg=bg,
                          fg=T["accent"] if sel else T["muted"])
            ic.pack(side="left", padx=(px(8), px(10)), pady=px(5))
            lbl = tk.Label(row, text=path, font=(FMONO, 10), anchor="w", fg=T["card_fg"], bg=bg)
            lbl.pack(side="left", fill="x", expand=True)
            for w in (row, ic, lbl):
                w.bind("<Button-1>", lambda e, i=i: self._click_static_path(i, e))

    def _click_static_path(self, idx, event):
        if event.state & 0x0001 and self._static_anchor is not None:
            lo, hi = sorted((self._static_anchor, idx))
            self._static_sel = set(range(lo, hi + 1))
        elif event.state & 0x0004:
            self._static_sel ^= {idx}
            self._static_anchor = idx
        else:
            self._static_sel, self._static_anchor = {idx}, idx
        self._render_static_paths()

    def _add_static_paths(self, paths):
        for p in paths:
            if p not in self._static_paths:
                self._static_paths.append(p)
        self._static_sel = set()
        self._render_static_paths()
        self._persist_static_paths()

    def _add_static_folder(self):
        with dialog_guard(self):
            d = filedialog.askdirectory(title="Agregar carpeta al escaneo", initialdir=self._target_var.get() or APP_DIR)
        if d:
            self._target_var.set(d)
            self._add_static_paths([d])

    def _add_static_files(self):
        with dialog_guard(self):
            files = filedialog.askopenfilenames(
                title="Agregar archivos o .csproj al escaneo", initialdir=self._target_var.get() or APP_DIR,
                filetypes=[("Todos los compatibles", "*.csproj *.sln *.json *.py *.js *.ts *.cs *.java *.go *.rb *.php"),
                           ("Proyectos Visual Studio", "*.csproj *.sln"),
                           ("Manifiestos de dependencias", "*.json *.xml *.lock *.toml *.gradle"),
                           ("Código fuente", "*.py *.js *.ts *.cs *.java *.go *.rb *.php *.cpp *.c *.h"),
                           ("Todos los archivos", "*.*")])
        if not files:
            return
        paths = []
        for f in files:
            if Path(f).suffix.lower() == ".csproj":
                paths.append(str(Path(f).parent))
                self._log_line(f"[estático] .csproj detectado: se usa la carpeta '{paths[-1]}'")
            else:
                paths.append(f)
        self._target_var.set(str(Path(files[-1]).parent))
        self._add_static_paths(paths)

    def _remove_static_paths(self):
        sel = sorted(self._static_sel)
        if not sel:
            return

        def remove():
            for i in reversed(sel):
                del self._static_paths[i]
            self._static_sel = set()
            self._target_var.set(self._static_paths[-1] if self._static_paths else "")
            self._render_static_paths()
            self._persist_static_paths()

        if not self._static_results_visible:
            return remove()
        popup = self._popup("Quitar ruta")
        self._popup_hdr(popup, "Quitar ruta", icon="⚠")
        self._centered_msg(popup, "⚠", T["accent"], "Quitar ruta",
                           "Esta ruta tiene resultados de un escaneo anterior en pantalla.\n\nSi los deja y luego "
                           "escanea otra carpeta, el reporte combinará ambos resultados (SCA/SAST/Secretos se muestran "
                           "acumulados por diseño, no solo del último escaneo).\n\n¿Desea limpiar esos resultados antes "
                           "de continuar?", T["text"])
        self._popup_foot(popup, ("  Limpiar resultados anteriores y quitar  ",
                                 lambda: (popup.close(), self._clear_static_results(), remove())),
                         ("  Solo quitar la ruta  ", lambda: (popup.close(), remove())),
                         ("  Cancelar  ", popup.close))

    def _reveal_static_results(self) -> None:
        if not self._static_results_visible:
            self._static_secrets_wrap.pack(fill="x")
            self._static_results_row.pack(fill="x", pady=(0, CARD_GAP), before=self._static_secrets_wrap)
            self._static_results_visible = True

    def _on_static_results(self, ctx, rerender: bool = False):
        if ctx is None:
            return
        self._static_ctx = ctx
        self._render_sca(ctx.get("projects", []))
        self._render_sast(ctx.get("files", []))
        if not rerender:
            sec = ctx.get("secrets") or {}
            self._render_secrets(sec.get("findings", []), sec.get("target"), sec.get("baseline_suppressed", []))
        self._reveal_static_results()

    def _clear_static_results(self) -> None:
        self._static_ctx = None
        self._render_sca([])
        self._render_sast([])
        self._render_secrets([])
        self._last_static_report = self._last_context = None
        try:
            self._scan_state.clear_kinds(STATIC_STAGES)
        except Exception as e:
            self._emit_log(f"[estático] no se pudo limpiar el estado persistido: {e!r}")
        self._emit_log("[estático] resultados del escaneo anterior eliminados.")

    def _start_static_scan(self, sel: set):
        if self._static_busy:
            return self._log_line("[estático] ya hay un escaneo en ejecución")
        self._confirm_scan_without_app(lambda: self._run_static_scan_now(sel))

    def _run_static_scan_now(self, sel: set):
        changed = [k for k in STATIC_STAGES if k in sel and not self._scan_vars[k].get()]
        for k in changed:
            self._scan_vars[k].set(True)
        if changed:
            self._persist_scan_stages()
            self._refresh_scan_btn()
        paths = [p for p in self._static_paths if p.strip()] or (
            [self._target_var.get().strip()] if self._target_var.get().strip() else [])
        if not paths:
            return self._show_warn_popup("Análisis estático", "Sin carpetas ni archivos seleccionados.\n\nUse "
                                         "'+ Carpeta' o '+ Archivo' para agregar objetivos.")
        valid = []
        for p in paths:
            if Path(p).exists():
                valid.append(Path(p).resolve())
            else:
                self._log_line(f"[estático] ⚠ ruta no encontrada, se omite: {p}")
        if not valid:
            return self._show_warn_popup("Análisis estático", "Ninguna de las rutas seleccionadas existe en disco."
                                         "\n\nVerifique las rutas e intente de nuevo.")
        if {"sca", "code"} & sel and not self._snyk_auth_ok():
            return self._show_warn_popup("Análisis estático", "SCA y SAST requieren una sesión de Snyk con el SSO "
                                         "del banco.\n\nHaga clic en «Snyk» (arriba a la derecha) → Iniciar sesión."
                                         "\n\n" + SNYK_SSO_WARNING)
        self._target_var.set(str(valid[0]))
        for b in self._static_run_btns:
            self._set_icon_btn_enabled(b, False)
        self._run_async(lambda: self._static_scan(valid, sel), "análisis estático", busy_attr="_static_busy")

    def _static_scan(self, targets: list, sel: set):
        self._static_cancel_evt.clear()
        self._ui(self._pipeline_reset)
        summaries = []
        for i, t in enumerate(targets):
            if self._static_cancel_evt.is_set():
                self._emit_log("[estático] cancelado — se omiten los objetivos restantes")
                break
            reason = "ruta inexistente" if not t.exists() else "carpeta vacía" if not dir_has_files(t) else ""
            if reason:
                self._emit_log(f"[estático] ⚠ {reason}, se omite: {t}")
                summaries.append({"path": str(t), "scanned": False, "reason": reason})
                continue
            self._emit_log(f"[estático] === objetivo {i + 1}/{len(targets)}: {t} ===")
            summaries.append(self._execute_scan(lane="static", target=t, sel=sel, cancel=self._static_cancel_evt,
                                                batch=targets, route=(i, len(targets))))
        if not any(s.get("scanned") for s in summaries):
            return self._emit_log("[estático] ningún objetivo escaneable (todas las carpetas vacías o inexistentes)")
        if len(targets) > 1:
            try:
                from report_engine import render_static_batch_index
                _, root = self._scoped_report_paths(Path(self._reports_var.get()).resolve())
                idx = render_static_batch_index(summaries, root, filename=f"index_{ts()}.html")
                self._emit_log(f"[reporte] índice del análisis por carpetas ({len(summaries)}) → {idx}")
                self._last_static_report = idx
                self._ui(self._on_report, idx, True)
            except Exception as e:
                self._emit_log(f"[reporte] no se pudo construir el índice del lote: {e!r}")


if __name__ == "__main__":
    from secrets_scanner import ensure_git_secrets, scan_path, write_secrets_report
    tgt = sys.argv[1] if len(sys.argv) > 1 else "."
    res = scan_path(tgt, print, git_secrets_status=ensure_git_secrets(print))
    print("reporte de secretos:", write_secrets_report(res, Path(tgt) / "_secrets_out"))
