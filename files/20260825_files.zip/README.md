# Tenable SC Scanner

Herramienta para el entorno Tenable on-prem de Banco Base:

1. **Buscar** si una IP/hostname ya fue escaneada antes, revisando los 3
   Nessus Manager (Querétaro, Monterrey, Torre Base) vía una **caché local**
   (instantánea) que se sincroniza manualmente.
2. **Lanzar** un scan on-demand contra Security Center (Tenable.sc).

Hay dos formas de usarla: una **GUI** (`gui.py`) para configurar y probar
cómodamente, y un **CLI** (`cli.py`) para scripting. Ambas comparten la misma
base de datos SQLite (`tenable_sc_scanner.db`), así que lo que configures o
sincronices en una lo ve la otra.

## Archivos

| Archivo | Qué es |
|---|---|
| `gui.py` | GUI de escritorio (Tkinter) — configuración, búsqueda, lanzar scan, historial |
| `cli.py` | CLI para scripting, misma base de datos que la GUI |
| `tenable_core.py` | Clientes REST puros (Nessus Manager y Security Center), sin persistencia |
| `db.py` | Capa de persistencia SQLite (config, caché de búsqueda, historial) |
| `tenable_sc_scanner.db` | Se crea solo al primer arranque — **contiene tus llaves en texto plano** |

## 1. Instalación

```bash
pip install -r requirements.txt
```

Requiere `tkinter` para la GUI (en Linux normalmente `sudo apt install python3-tk`;
en Windows/Mac ya viene con el instalador oficial de Python).

## 2. Primer arranque — configurar llaves (vía GUI)

```bash
python gui.py
```

La ventana abre maximizada. La pestaña **Configuración** trae precargadas las
4 URLs (Security Center + los 3 Nessus Manager). Llena el access key y
secret key de cada uno y da **Guardar todo**.

> ⚠️ **Las llaves se guardan en texto plano** en `tenable_sc_scanner.db`,
> junto a los scripts — así lo pediste para agilizar las pruebas. No subas
> ese archivo a ningún repositorio; en Linux/Mac considera
> `chmod 600 tenable_sc_scanner.db`.

Recuerda que son **4 juegos de llaves independientes** — las de Security
Center no sirven para autenticarte contra la API de cada Nessus Manager
directamente, aunque SC los administre como scanners:

| Sistema | Dónde generar la API key |
|---|---|
| Security Center | Users → tu usuario → Generate API Key (o My Account → API Keys) |
| Cada Nessus Manager (x3) | Settings → My Account → API Keys, en cada una de las 3 consolas |

### Indicador de conexión ("foco") por cada sistema

Cada uno de los 4 bloques (Security Center + 3 Nessus Manager) tiene un
punto de color, un mensaje y un botón **Probar conexión**:

- 🔘 gris = sin probar todavía
- 🟡 amarillo = probando (máx. 8 segundos)
- 🟢 verde "Conectado" = credenciales y conectividad OK
- 🔴 rojo = error, con el motivo (401/403 = llave inválida, timeout = host
  inalcanzable, DNS, conexión rechazada, error SSL, etc.)

Si ya tienes llaves guardadas de una sesión anterior, **la GUI las prueba
sola al abrir** (sin que tengas que hacer nada) — así ves de un vistazo cuál
de los 4 sistemas está bien y cuál no, antes de intentar buscar o lanzar
nada. Esta prueba usa un timeout corto (8s) específicamente para no
quedarse "colgada" — es independiente y más rápida que sincronizar la caché
o cargar catálogos.

## 3. Uso — GUI

- **Buscar**: escribe una IP/hostname y da *Buscar en caché* (instantáneo,
  no toca la red). Los botones *Sincronizar* sí van contra los 3 Nessus
  Manager en un hilo aparte (no congela la ventana) y van imprimiendo
  progreso scan por scan. Abajo se muestra cuándo se sincronizó cada uno
  por última vez y con cuántos hosts.
- **Lanzar Scan**: los catálogos de Política/Repositorio/Zona se cargan
  solos al entrar a la pestaña (si Security Center está configurado) — el
  status junto al botón *Cargar catálogos de SC* muestra "cargando...",
  el resultado, o el error si algo falló. Llena nombre + IPs y *Lanzar
  scan*. Si "Buscar primero en caché" está activo, avisa si alguna IP ya
  tiene historial antes de pedir confirmación. Con "Seguir estado" va
  mostrando el progreso cada 30s — ya no como el dict crudo de Security
  Center (ilegible), sino resumido: `IPs 1/1 | checks 317284/317284 (100%)
  | scanner: X`. Cuando el scan termina, aparece un banner claro en el log
  (`✅ SCAN FINALIZADO`) y una etiqueta de estado persistente arriba del log
  (`✅ Último scan: Completed`), para que no parezca que se quedó colgado.
  Con "Detectar zona por IP" activo (default), al salir del campo de IPs
  (o Enter) se busca automáticamente en qué zona de Security Center cae la
  primera IP escrita, usando el `ipList` de cada zona — si no hay match, lo
  dice ("sin zona automática para X") y puedes elegir manualmente en el
  combo igual que antes.
- **Historial**: scans lanzados desde esta herramienta (registro local, no
  reemplaza el historial real que vive en Security Center).

## 4. Uso — CLI

```bash
# Buscar en la caché local (no toca la red)
python cli.py buscar 10.20.30.40

# Refrescar la caché contra los 3 Nessus Manager (o uno en específico)
python cli.py sincronizar
python cli.py sincronizar --nessus Queretaro

# Ver qué políticas / repositorios / zonas tienes en SC
python cli.py politicas
python cli.py repositorios
python cli.py zonas

# Lanzar un scan, buscando primero en caché y siguiendo el progreso
python cli.py scan "Scan ad-hoc servidor X" 10.20.30.40 \
    --policy-id 1000001 --repository-id 4 --buscar-primero --seguir
```

## Notas / límites conocidos

- `sincronizar` recorre **todos** los scans de cada Nessus Manager y su
  lista de hosts (no hay endpoint tipo "workbench de assets" garantizado en
  todas las versiones de Nessus Manager on-prem, a diferencia de Tenable.io).
  Por eso se cachea en SQLite en vez de repetir esa consulta cada vez que
  buscas — la búsqueda en sí es instantánea, y tú decides cuándo refrescar.
- El match de búsqueda es por substring, case-insensitive, contra el campo
  `hostname` que Nessus reporta por host (puede ser IP o nombre resuelto,
  según cómo se definió el target del scan).
- `scan` crea un scan **nuevo** en SC cada vez (tipo `policy`) y lo lanza de
  inmediato; no reutiliza un scan definido previamente.
- Las 4 URLs usan certificados internos, así que `verify_ssl` viene
  desactivado por default (tanto en la fila de SC como en cada Nessus
  Manager, editable en la pestaña Configuración o directamente en la BD).
- Timeouts diferenciados: 8s para "Probar conexión" (diagnóstico rápido),
  15s para listar scans/políticas/repos/zonas, 30s para crear/lanzar un scan
  y consultar su estado (operaciones que legítimamente pueden tardar más).
- La detección automática de zona depende de que tu Security Center exponga
  el campo `ipList` en `/rest/zone` (rangos asignados a cada zona). Si tu
  versión/config no lo trae, simplemente no detecta nada automáticamente
  (no truena) y sigues eligiendo la zona a mano en el combo, igual que
  antes. Solo mira la primera IP de la lista si mandas varias — si tus IPs
  caen en zonas distintas, ajusta la zona manualmente después de lanzar el
  detector.
- **Resolución automática de hostname → IP.** Si escribes un hostname (no
  una IP) en el campo de IPs, se intenta resolver por DNS ANTES de mandarlo
  a Security Center — un hostname que SC no reconozca como IP produce
  "Entered IPs and Assets are empty" con 0 IPs escaneadas, sin relación
  alguna con el repositorio o la zona elegidos. Si no se puede resolver, se
  manda tal cual (por si SC lo resuelve por su cuenta) pero se avisa en el
  log. Aplica tanto al lanzar el scan como a la detección automática de
  zona.
- **Repositorios de tipo Agent — causa raíz real, confirmada.** El proceso
  correcto (según lo confirmó el usuario revisando cómo lo hace el
  front-end) es: 1) crear/tener un **grupo de agente** en el Nessus
  Manager correspondiente (Querétaro/Monterrey/Torre Base, detectado por
  la nomenclatura del hostname — ver abajo) con ese host agregado; 2)
  Security Center sincroniza ese grupo como un **Asset**; 3) el scan se
  lanza contra ese Asset (`type: "agent"`), no contra una IP suelta
  (`type: "policy"`). Mandar una IP directa contra un repositorio de
  Agent (lo que hacía la herramienta antes) crea y lanza el scan sin
  error, pero el resultado siempre termina en `errorDetails: "Scan IPs
  are not within your accessible range"` — confirmado con evidencia real
  contra este entorno.

  La pestaña **Lanzar Scan** ahora tiene una sección **"Grupo de agente"**
  con dos botones:
  1. **Preparar grupo en Nessus Manager** — detecta a cuál de los 3
     Nessus Manager pertenece el primer host escrito en IPs (por prefijo
     del hostname: `mty`→Monterrey, `qro`→Querétaro, `tob`→Torre Base; si
     escribiste una IP, intenta resolver el hostname por DNS inverso
     primero), busca si ya existe un grupo de agente que coincida (para
     NO crear uno duplicado) y, si no existe, pide confirmación antes de
     crear uno nuevo. Después busca el agente ya registrado que coincida
     y, si no pertenece aún al grupo, pide confirmación antes de
     agregarlo.
  2. **Cargar activos de SC** — lista los Assets de Security Center
     (`/rest/asset`), donde debería aparecer el grupo ya sincronizado.
     Elígelo en el combo y activa "Usar este activo/grupo en vez de IP
     directa" antes de lanzar — con eso, `crear_scan` manda `type:
     "agent"` y `assets: [{"id": ...}]` en vez de `ipList`, y **no** sale
     el aviso de "repositorio tipo Agent" (porque ya estás usando la
     forma correcta).

  ⚠️ **Esto es nuevo y no se ha probado contra el Security Center/Nessus
  Manager reales del usuario.** Las rutas de la API (`/agent-groups`,
  `/agents`, `/rest/asset`) son las estándar documentadas para Nessus
  Manager/Tenable.io, pero pueden no coincidir exactamente con esta
  versión/instalación. Con "Debug detallado" activado (default ON) vas a
  ver el JSON crudo de cada paso — si algo da 404 o un error raro, ese
  volcado dice exactamente qué ruta/payload falló, para ajustarlo.

- **Detección de Nessus Manager por nombre de host.** `mty`→Monterrey,
  `qro`→Querétaro, `tob`→Torre Base (ver `PREFIJO_NESSUS_MANAGER` en
  `tenable_core.py` si la convención cambia). Si el campo de IPs tiene una
  IP en vez de hostname, se intenta resolver por DNS inverso (PTR) antes
  de aplicar la convención — si no hay PTR configurado, no se puede
  detectar automáticamente y hay que escribir el hostname directamente.
- **Un scan lanzado por Security Center no necesariamente aparece en "My
  Scans" / "All Scans" del front-end web del Nessus Manager que lo
  ejecutó.** Esto es esperado en esta arquitectura: SC trata a cada Nessus
  Manager como un motor de escaneo registrado y le empuja el job
  directamente, sin crear un "scan" con nombre propio en la interfaz local
  de ese Nessus Manager — el resultado se recolecta de vuelta hacia SC, no
  hacia la vista de scans del Nessus Manager. La fuente de verdad para un
  scan lanzado así es **Security Center mismo** (sus propios resultados /
  análisis de vulnerabilidades), no el front-end del Nessus Manager.
