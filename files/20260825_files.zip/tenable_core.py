"""
tenable_core.py - Clientes mínimos para las APIs REST de Nessus Manager y
Tenable Security Center. No conoce SQLite ni la GUI: solo hace requests.
Compartido entre cli.py y gui.py.
"""

import ipaddress
import sys

import requests
import urllib3

# Las 4 URLs (SC + 3 Nessus Manager) usan certificados internos.
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def _mensaje_connection_error(e):
    """El texto crudo de un ConnectionError de urllib3 es larguísimo (para
    log, no para una etiqueta de GUI). Lo reducimos a algo legible."""
    texto = str(e)
    if "Connection refused" in texto:
        return "Conexión rechazada (host alcanzable, pero nada escucha en ese puerto)"
    if "Name or service not known" in texto or "nodename nor servname" in texto:
        return "No se pudo resolver el hostname (DNS)"
    if "No route to host" in texto:
        return "Sin ruta al host (revisa VPN/red)"
    return f"Sin conectividad: {texto[:160]}"


def _normalizar_lista_sc(respuesta):
    """
    Varios endpoints de listado de Security Center (/policy, /repository,
    /zone, /scan, ...) NO siempre devuelven una lista plana: según el
    alcance de permisos de la cuenta/API key, pueden devolver un dict con
    "buckets" -- típicamente {"usable": [...], "manageable": [...]} -- en
    vez de una lista de objetos. Iterar ese dict directamente itera sus
    LLAVES (strings), no los objetos, lo que revienta con
    "string indices must be integers, not 'str'" en cuanto se intenta leer
    p['id']. Esta función normaliza ambos casos a una sola lista de dicts,
    sin duplicados por id.
    """
    if isinstance(respuesta, list):
        return respuesta
    if isinstance(respuesta, dict):
        vistos = set()
        resultado = []
        for valor in respuesta.values():
            if not isinstance(valor, list):
                continue
            for item in valor:
                if not isinstance(item, dict):
                    continue
                clave = item.get("id", id(item))
                if clave in vistos:
                    continue
                vistos.add(clave)
                resultado.append(item)
        return resultado
    return []


def resumir_progreso(progress):
    """
    El campo 'progress' que devuelve /scanResult de Security Center es un
    dict grande y anidado (incluye desglose por scanner y por chunk) --
    útil para debug pero ilegible como una línea de log. Esta función saca
    lo que realmente importa para seguir un scan desde la GUI/CLI.
    """
    if not isinstance(progress, dict) or not progress:
        return "(sin detalle todavía)"

    completed_checks = progress.get("completedChecks")
    total_checks = progress.get("totalChecks")
    completed_ips = progress.get("completedIPs")
    total_ips = progress.get("totalIPs")
    scanning_ips = progress.get("scanningIPs") or ""

    partes = []
    if total_ips not in (None, ""):
        partes.append(f"IPs {completed_ips}/{total_ips}")
    if total_checks not in (None, "", "0", 0):
        try:
            pct = round(int(completed_checks) / int(total_checks) * 100)
            partes.append(f"checks {completed_checks}/{total_checks} ({pct}%)")
        except (TypeError, ValueError, ZeroDivisionError):
            partes.append(f"checks {completed_checks}/{total_checks}")
    if scanning_ips:
        partes.append(f"escaneando {scanning_ips}")

    scanners = progress.get("scanners") or []
    nombres_scanners = [s.get("name") for s in scanners if isinstance(s, dict) and s.get("name")]
    if nombres_scanners:
        partes.append(f"scanner: {', '.join(nombres_scanners)}")

    return " | ".join(partes) if partes else "(sin detalle todavía)"


def _parsear_rangos_ip(ip_list_str):
    """
    Parsea el campo de rangos de IP de una zona de Security Center (coma o
    salto de línea separado). Acepta IPs sueltas, CIDR (10.48.0.0/16) y
    rangos con guión (10.48.0.1-10.48.0.255). Entradas que no se puedan
    interpretar se ignoran en silencio (mejor detectar de menos que tronar).
    """
    rangos = []
    if not ip_list_str:
        return rangos
    for parte in str(ip_list_str).replace("\n", ",").split(","):
        parte = parte.strip()
        if not parte:
            continue
        try:
            if "-" in parte and "/" not in parte:
                inicio, fin = parte.split("-", 1)
                rangos.append((ipaddress.ip_address(inicio.strip()), ipaddress.ip_address(fin.strip())))
            else:
                rangos.append(ipaddress.ip_network(parte, strict=False))
        except ValueError:
            continue
    return rangos


def _ip_en_rango(ip_obj, rango):
    if isinstance(rango, tuple):
        inicio, fin = rango
        return inicio <= ip_obj <= fin
    return ip_obj in rango


def zona_para_ip(zonas, ip_str):
    """
    zonas: lista de dicts de listar_zonas() (deben incluir 'ipList', el
    campo de Security Center con los rangos asignados a cada zona).
    Devuelve el primer dict de zona cuyo ipList incluya la IP dada, o None
    si ninguna zona coincide (o si el campo ipList no viene en la
    respuesta -- depende de la versión/config del SC).
    """
    try:
        ip_obj = ipaddress.ip_address(ip_str.strip())
    except ValueError:
        return None
    for zona in zonas:
        rangos = _parsear_rangos_ip(zona.get("ipList", ""))
        for rango in rangos:
            if _ip_en_rango(ip_obj, rango):
                return zona
    return None


TIMEOUT = 30  # crear/lanzar scan, consultar estado: operaciones que pueden tardar más
LIST_TIMEOUT = 15  # listar scans/políticas/repos/zonas: deben responder rápido si hay conectividad
CONNECT_TEST_TIMEOUT = 8  # "Probar conexión": queremos un sí/no rápido, no esperar el timeout largo


class NessusManagerClient:
    def __init__(self, nombre, url, access_key, secret_key, verify_ssl=False):
        self.nombre = nombre
        self.url = url.rstrip("/")
        self.headers = {
            "X-ApiKeys": f"accessKey={access_key}; secretKey={secret_key}",
            "Content-Type": "application/json",
        }
        self.verify_ssl = bool(verify_ssl)

    def _get(self, path, timeout=None, **kwargs):
        r = requests.get(
            f"{self.url}{path}",
            headers=self.headers,
            verify=self.verify_ssl,
            timeout=timeout or TIMEOUT,
            **kwargs,
        )
        r.raise_for_status()
        return r.json()

    def listar_scans(self):
        return self._get("/scans", timeout=LIST_TIMEOUT).get("scans") or []

    def detalle_scan(self, scan_id):
        return self._get(f"/scans/{scan_id}", timeout=LIST_TIMEOUT)

    def probar_conexion(self):
        """
        Prueba rápida de conectividad + credenciales (timeout corto, no
        arrastra el timeout largo de las operaciones normales).
        Devuelve (ok: bool, mensaje: str).
        """
        try:
            r = requests.get(
                f"{self.url}/scans",
                headers=self.headers,
                verify=self.verify_ssl,
                timeout=CONNECT_TEST_TIMEOUT,
            )
        except requests.exceptions.SSLError as e:
            return False, f"Error SSL: {e}"
        except requests.exceptions.ConnectTimeout:
            return False, f"Sin respuesta en {CONNECT_TEST_TIMEOUT}s (host/puerto inalcanzable o bloqueado)"
        except requests.exceptions.ReadTimeout:
            return False, f"Conectó pero no respondió en {CONNECT_TEST_TIMEOUT}s"
        except requests.exceptions.ConnectionError as e:
            return False, _mensaje_connection_error(e)
        except requests.RequestException as e:
            return False, str(e)

        if r.status_code == 401:
            return False, "401 no autorizado — revisa access/secret key"
        if r.status_code == 403:
            return False, "403 prohibido — revisa permisos de la cuenta/API key"
        if not r.ok:
            return False, f"HTTP {r.status_code}"
        return True, "Conectado"

    def indexar_hosts(self, progreso_cb=None):
        """
        Recorre TODOS los scans de este Nessus Manager y devuelve
        (filas, total_scans), donde filas es una lista de dicts
        {scan_id, scan_name, host, last_modification} lista para meterse
        en la caché SQLite.

        progreso_cb(actual, total, scan_name) es opcional, para reportar
        avance (p.ej. a una barra de progreso en la GUI).
        """
        filas = []
        scans = self.listar_scans()
        total = len(scans)
        for i, scan in enumerate(scans, start=1):
            scan_id = scan.get("id")
            scan_name = scan.get("name", "")
            if progreso_cb:
                progreso_cb(i, total, scan_name)
            try:
                detalle = self.detalle_scan(scan_id)
            except requests.RequestException as e:
                print(f"  [{self.nombre}] error en scan {scan_id} ({scan_name}): {e}", file=sys.stderr)
                continue
            for h in detalle.get("hosts") or []:
                hostname = str(h.get("hostname", ""))
                if not hostname:
                    continue
                filas.append(
                    {
                        "scan_id": scan_id,
                        "scan_name": scan_name,
                        "host": hostname,
                        "last_modification": scan.get("last_modification_date"),
                    }
                )
        return filas, total


class SecurityCenterClient:
    def __init__(self, url, access_key, secret_key, verify_ssl=False):
        self.url = url.rstrip("/")
        self.headers = {
            "x-apikey": f"accesskey={access_key}; secretkey={secret_key}",
            "Content-Type": "application/json",
        }
        self.verify_ssl = bool(verify_ssl)

    def _get(self, path, timeout=None, **kwargs):
        r = requests.get(
            f"{self.url}/rest{path}",
            headers=self.headers,
            verify=self.verify_ssl,
            timeout=timeout or TIMEOUT,
            **kwargs,
        )
        r.raise_for_status()
        return r.json().get("response")

    def _post(self, path, payload, timeout=None, **kwargs):
        r = requests.post(
            f"{self.url}/rest{path}",
            headers=self.headers,
            json=payload,
            verify=self.verify_ssl,
            timeout=timeout or TIMEOUT,
            **kwargs,
        )
        r.raise_for_status()
        return r.json().get("response")

    def listar_politicas(self):
        return _normalizar_lista_sc(self._get("/policy?fields=id,name,type,description", timeout=LIST_TIMEOUT))

    def listar_repositorios(self):
        return _normalizar_lista_sc(
            self._get("/repository?fields=id,name,type,dataFormat", timeout=LIST_TIMEOUT)
        )

    def listar_zonas(self):
        return _normalizar_lista_sc(self._get("/zone?fields=id,name,ipList", timeout=LIST_TIMEOUT))

    def probar_conexion(self):
        """
        Prueba rápida de conectividad + credenciales contra /rest/currentUser
        (timeout corto). Devuelve (ok: bool, mensaje: str).
        """
        try:
            r = requests.get(
                f"{self.url}/rest/currentUser",
                headers=self.headers,
                verify=self.verify_ssl,
                timeout=CONNECT_TEST_TIMEOUT,
            )
        except requests.exceptions.SSLError as e:
            return False, f"Error SSL: {e}"
        except requests.exceptions.ConnectTimeout:
            return False, f"Sin respuesta en {CONNECT_TEST_TIMEOUT}s (host/puerto inalcanzable o bloqueado)"
        except requests.exceptions.ReadTimeout:
            return False, f"Conectó pero no respondió en {CONNECT_TEST_TIMEOUT}s"
        except requests.exceptions.ConnectionError as e:
            return False, _mensaje_connection_error(e)
        except requests.RequestException as e:
            return False, str(e)

        if r.status_code == 401:
            return False, "401 no autorizado — revisa access/secret key"
        if r.status_code == 403:
            return False, "403 prohibido — revisa permisos de la cuenta/API key"
        if not r.ok:
            return False, f"HTTP {r.status_code}"
        return True, "Conectado"

    def crear_scan(self, nombre, ips, policy_id, repository_id, zone_id=None, descripcion=""):
        payload = {
            "name": nombre,
            "description": descripcion,
            "type": "policy",
            "ipList": ",".join(ips) if isinstance(ips, list) else ips,
            "policy": {"id": str(policy_id)},
            "repository": {"id": str(repository_id)},
        }
        if zone_id:
            payload["zone"] = {"id": str(zone_id)}
        return self._post("/scan", payload)

    def lanzar_scan(self, scan_id):
        return self._post(f"/scan/{scan_id}/launch", {})

    def estado_resultado(self, scan_result_id):
        return self._get(
            f"/scanResult/{scan_result_id}"
            "?fields=id,name,status,progress,scannedIPs,startTime,finishTime"
        )
