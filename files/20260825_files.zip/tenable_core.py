"""
tenable_core.py - Clientes mínimos para las APIs REST de Nessus Manager y
Tenable Security Center. No conoce SQLite ni la GUI: solo hace requests.
Compartido entre cli.py y gui.py.
"""

import ipaddress
import json
import socket
import sys

import requests
import urllib3

# Las 4 URLs (SC + 3 Nessus Manager) usan certificados internos.
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def _mensaje_connection_error(e):
    """El texto crudo de un ConnectionError de urllib3 es larguísimo (para
    log, no para una etiqueta de GUI). Lo reducimos a algo legible."""
    texto = str(e)
    if "Connection refused" in texto:
        return "Conexión rechazada (host alcanzable, pero nada escucha en ese puerto)"
    if "Name or service not known" in texto or "nodename nor servname" in texto:
        return "No se pudo resolver el hostname (DNS)"
    if "No route to host" in texto:
        return "Sin ruta al host (revisa VPN/red)"
    return f"Sin conectividad: {texto[:160]}"


def _normalizar_lista_sc(respuesta):
    """
    Varios endpoints de listado de Security Center (/policy, /repository,
    /zone, /scan, ...) NO siempre devuelven una lista plana: según el
    alcance de permisos de la cuenta/API key, pueden devolver un dict con
    "buckets" -- típicamente {"usable": [...], "manageable": [...]} -- en
    vez de una lista de objetos. Iterar ese dict directamente itera sus
    LLAVES (strings), no los objetos, lo que revienta con
    "string indices must be integers, not 'str'" en cuanto se intenta leer
    p['id']. Esta función normaliza ambos casos a una sola lista de dicts,
    sin duplicados por id.
    """
    if isinstance(respuesta, list):
        return respuesta
    if isinstance(respuesta, dict):
        vistos = set()
        resultado = []
        for valor in respuesta.values():
            if not isinstance(valor, list):
                continue
            for item in valor:
                if not isinstance(item, dict):
                    continue
                clave = item.get("id", id(item))
                if clave in vistos:
                    continue
                vistos.add(clave)
                resultado.append(item)
        return resultado
    return []


def resumir_progreso(progress):
    """
    El campo 'progress' que devuelve /scanResult de Security Center es un
    dict grande y anidado (incluye desglose por scanner y por chunk) --
    útil para debug pero ilegible como una línea de log. Esta función saca
    lo que realmente importa para seguir un scan desde la GUI/CLI.
    """
    if not isinstance(progress, dict) or not progress:
        return "(sin detalle todavía)"

    completed_checks = progress.get("completedChecks")
    total_checks = progress.get("totalChecks")
    completed_ips = progress.get("completedIPs")
    total_ips = progress.get("totalIPs")
    scanning_ips = progress.get("scanningIPs") or ""

    partes = []
    if total_ips not in (None, ""):
        partes.append(f"IPs {completed_ips}/{total_ips}")
    if total_checks not in (None, "", "0", 0):
        try:
            pct = round(int(completed_checks) / int(total_checks) * 100)
            partes.append(f"checks {completed_checks}/{total_checks} ({pct}%)")
        except (TypeError, ValueError, ZeroDivisionError):
            partes.append(f"checks {completed_checks}/{total_checks}")
    if scanning_ips:
        partes.append(f"escaneando {scanning_ips}")

    scanners = progress.get("scanners") or []
    nombres_scanners = [s.get("name") for s in scanners if isinstance(s, dict) and s.get("name")]
    if nombres_scanners:
        partes.append(f"scanner: {', '.join(nombres_scanners)}")

    return " | ".join(partes) if partes else "(sin detalle todavía)"


def resumir_estado_scan(estado):
    """
    Arma una línea de log legible a partir de la respuesta COMPLETA de
    /scanResult (no solo 'progress'): incluye el detalle de error de
    Security Center cuando lo hay (p.ej. "Scan IPs are not within your
    accessible range"). Sin esto, un scan que termina en estado Error no
    deja ninguna pista de POR QUÉ -- hay que ir a buscarlo a mano en la web
    de Security Center.
    """
    if not isinstance(estado, dict):
        return str(estado)
    resumen = resumir_progreso(estado.get("progress"))
    detalle = estado.get("errorDetails")
    if detalle:
        return f"{resumen}\n    ❌ Detalle de Security Center: {detalle}"
    return resumen


def es_repositorio_de_agente(repo):
    """
    Best-effort: True si el repositorio parece ser de tipo Agent. Como no
    hay certeza en qué campo expone esto tu versión de Security Center (el
    heurístico anterior, limitado a 'type'/'dataFormat', no detectó nada en
    un caso real), esta versión revisa TODOS los valores string del objeto
    repositorio -- y un nivel adentro de cualquier sub-dict (p.ej.
    'typeFields') -- buscando la palabra 'agent' (case-insensitive). Si tu
    SC tampoco lo distingue así, esto no marca nada (no rompe nada); usa el
    volcado crudo que se imprime en el log al cargar catálogos para ver los
    campos reales y, si hace falta, decirme cuál es el campo correcto.
    """

    def _contiene_agent(valor, llave=""):
        if "agent" in llave.lower():
            return True
        if isinstance(valor, str):
            return "agent" in valor.lower()
        if isinstance(valor, dict):
            return any(_contiene_agent(v, k) for k, v in valor.items())
        return False

    return any(_contiene_agent(v, k) for k, v in repo.items())


def explicar_error_http(e):
    """
    Pista corta en español para los códigos HTTP más comunes al
    crear/lanzar un scan en Security Center. Devuelve None si no hay nada
    útil que agregar (el mensaje de la excepción ya se muestra tal cual).
    """
    resp = getattr(e, "response", None)
    codigo = getattr(resp, "status_code", None)
    if codigo == 401:
        return "401: la API key no es válida o expiró — revisa la pestaña Configuración."
    if codigo == 403:
        return (
            "403: la cuenta/API key no tiene permiso sobre ese repositorio, política "
            "o zona -- puede ser el tipo de repositorio, o simplemente que el usuario/"
            "grupo de esa API key no tiene acceso a ese repositorio específico en SC. "
            "Revisa el detalle de la respuesta cruda abajo, suele traer el motivo exacto."
        )
    return None


def detalle_respuesta_http(e):
    """
    Extrae el CUERPO de la respuesta HTTP de un error, cuando lo hay.
    Security Center normalmente manda un JSON con 'error_msg' (o similar)
    bastante más específico que el mensaje genérico de requests ("403
    Client Error: Forbidden for url: ..."), pero ese mensaje genérico es
    todo lo que se mostraba antes -- esta función recupera el resto.
    Devuelve un string legible, o None si no hay respuesta que inspeccionar.
    """
    resp = getattr(e, "response", None)
    if resp is None:
        return None
    try:
        data = resp.json()
    except ValueError:
        texto = (resp.text or "").strip()
        return texto[:500] if texto else None
    if isinstance(data, dict):
        for campo in ("error_msg", "errorDetails", "message", "warnings"):
            if data.get(campo):
                return f"{campo}: {data[campo]}"
        return json.dumps(data, ensure_ascii=False)[:500]
    return str(data)[:500]


def _parsear_rangos_ip(ip_list_str):
    """
    Parsea el campo de rangos de IP de una zona de Security Center (coma o
    salto de línea separado). Acepta IPs sueltas, CIDR (10.48.0.0/16) y
    rangos con guión (10.48.0.1-10.48.0.255). Entradas que no se puedan
    interpretar se ignoran en silencio (mejor detectar de menos que tronar).
    """
    rangos = []
    if not ip_list_str:
        return rangos
    for parte in str(ip_list_str).replace("\n", ",").split(","):
        parte = parte.strip()
        if not parte:
            continue
        try:
            if "-" in parte and "/" not in parte:
                inicio, fin = parte.split("-", 1)
                rangos.append((ipaddress.ip_address(inicio.strip()), ipaddress.ip_address(fin.strip())))
            else:
                rangos.append(ipaddress.ip_network(parte, strict=False))
        except ValueError:
            continue
    return rangos


def _ip_en_rango(ip_obj, rango):
    if isinstance(rango, tuple):
        inicio, fin = rango
        return inicio <= ip_obj <= fin
    return ip_obj in rango


def zona_para_ip(zonas, ip_str):
    """
    zonas: lista de dicts de listar_zonas() (deben incluir 'ipList', el
    campo de Security Center con los rangos asignados a cada zona).
    Devuelve el primer dict de zona cuyo ipList incluya la IP dada, o None
    si ninguna zona coincide (o si el campo ipList no viene en la
    respuesta -- depende de la versión/config del SC).
    """
    try:
        ip_obj = ipaddress.ip_address(ip_str.strip())
    except ValueError:
        return None
    for zona in zonas:
        rangos = _parsear_rangos_ip(zona.get("ipList", ""))
        for rango in rangos:
            if _ip_en_rango(ip_obj, rango):
                return zona
    return None


def resolver_targets(entradas, timeout_dns=5):
    """
    Para cada entrada (IPs y/o hostnames mezclados): si ya es una IP válida
    se deja tal cual; si es un hostname, se intenta resolver por DNS a una
    IP ANTES de mandarla a Security Center.

    Por qué: el campo ipList de un scan en Security Center espera IPs/CIDR
    reconocibles -- un hostname corto sin dominio (o que esta máquina no
    pueda resolver) se traduce en "Entered IPs and Assets are empty" con
    0 IPs escaneadas, sin relación alguna con el repositorio o los
    permisos elegidos (fue exactamente lo que pasó al probar con
    'mty-ale-pvol005' en vez de la IP real).

    Devuelve (resueltos, notas): 'resueltos' es la lista final a mandar a
    SC (mismo orden/tamaño que 'entradas' -- si no se pudo resolver, se
    manda la entrada original tal cual, por si SC sí la reconoce por su
    cuenta); 'notas' es una lista de strings para log, una por cada
    entrada que se resolvió o que falló al resolver.

    Nota de implementación: usa socket.setdefaulttimeout de forma
    temporal (afecta todo el proceso mientras dura la resolución, no solo
    esta llamada) -- aceptable para una herramienta de un solo scan a la
    vez, pero no ideal si en el futuro se paraleliza algo más.
    """
    resueltos = []
    notas = []
    for entrada in entradas:
        entrada = entrada.strip()
        try:
            ipaddress.ip_address(entrada)
            resueltos.append(entrada)
            continue
        except ValueError:
            pass

        anterior = socket.getdefaulttimeout()
        try:
            socket.setdefaulttimeout(timeout_dns)
            ip_resuelta = socket.gethostbyname(entrada)
            resueltos.append(ip_resuelta)
            notas.append(f"'{entrada}' no es una IP — resuelto por DNS a {ip_resuelta}")
        except (socket.gaierror, socket.timeout, OSError):
            resueltos.append(entrada)
            notas.append(
                f"⚠️ '{entrada}' no es una IP y no se pudo resolver por DNS desde esta máquina. "
                'Security Center puede rechazarlo con "Entered IPs and Assets are empty" — '
                "si conoces la IP real, escríbela directamente."
            )
        finally:
            socket.setdefaulttimeout(anterior)
    return resueltos, notas


# Nomenclatura observada en los hostnames de este entorno: el primer
# segmento del nombre (antes del primer '.') indica a qué Nessus Manager
# pertenece el host. Ajusta este mapeo si la convención cambia.
PREFIJO_NESSUS_MANAGER = {
    "mty": "Monterrey",
    "qro": "Queretaro",
    "tob": "Torre Base",
}


def detectar_nessus_manager_por_nombre(objetivo, nessus_managers, timeout_dns=5):
    """
    Detecta a cuál de los Nessus Manager configurados pertenece un host,
    según el prefijo de su hostname (mty/qro/tob -> Monterrey/Querétaro/
    Torre Base, ver PREFIJO_NESSUS_MANAGER).

    'objetivo': hostname o IP. Si es una IP, se intenta resolver el
    hostname por DNS INVERSO (PTR) primero, con timeout acotado -- si eso
    falla o tarda demasiado (muy común si no hay PTR configurado), no se
    puede detectar nada desde el nombre.

    'nessus_managers': lista de dicts de db.list_nessus_managers(), para
    hacer match contra los nombres REALES configurados (no hardcodeados).

    Devuelve (nessus_manager_dict_o_None, hostname_usado, nota) -- 'nota'
    es un string para log explicando qué se hizo (útil incluso cuando no
    se detectó nada, para saber por qué).
    """
    hostname = objetivo.strip()
    try:
        ipaddress.ip_address(hostname)
        anterior = socket.getdefaulttimeout()
        try:
            socket.setdefaulttimeout(timeout_dns)
            hostname, _, _ = socket.gethostbyaddr(hostname)
        except (socket.herror, socket.gaierror, socket.timeout, OSError) as e:
            return None, None, f"'{objetivo}' es una IP y no se pudo resolver su hostname por DNS inverso: {e}"
        finally:
            socket.setdefaulttimeout(anterior)
    except ValueError:
        pass  # ya era un hostname, no una IP

    primer_segmento = hostname.lower().split(".")[0]
    for prefijo, nombre_nm in PREFIJO_NESSUS_MANAGER.items():
        if primer_segmento.startswith(prefijo):
            for nm in nessus_managers:
                if nombre_nm.lower().replace(" ", "") in nm["name"].lower().replace(" ", ""):
                    return nm, hostname, f"'{hostname}' empieza con '{prefijo}' -> {nm['name']}"
            return None, hostname, (
                f"'{hostname}' empieza con '{prefijo}' ({nombre_nm}) pero no hay ningún Nessus "
                f"Manager configurado con ese nombre — revisa Configuración."
            )
    return None, hostname, f"'{hostname}' no coincide con ningún prefijo conocido ({', '.join(PREFIJO_NESSUS_MANAGER)})"


def filtrar_agentes(agentes, candidatos):
    """
    agentes: lista cruda de /agents.
    candidatos: un string o una lista de strings (IP, hostname corto,
    FQDN...) -- se prueban TODOS contra 'name' e 'ip' de cada agente
    (substring, case-insensitive), porque no hay certeza de qué formato
    guarda Nessus Manager en el campo 'name' de un agente.
    """
    if isinstance(candidatos, str):
        candidatos = [candidatos]
    candidatos_l = [c.lower() for c in candidatos if c]
    return [
        a
        for a in agentes
        if any(c in str(a.get("name", "")).lower() or c in str(a.get("ip", "")).lower() for c in candidatos_l)
    ]


def detectar_scanner_por_nombre(hostname, scanners):
    """
    Entre los "Agent Scanner" de un Nessus Manager (el campo obligatorio
    al crear un grupo/scan de agente -- en este entorno hay uno por sitio,
    p.ej. MTY-ALE-PTNE002/MTY-TOB-PTNE002/QRO-ALE-PTNE002), intenta
    encontrar el que corresponde al sitio del host, comparando los dos
    primeros segmentos del hostname (p.ej. "mty-ale" de
    "mty-ale-pvol005") contra el nombre de cada scanner -- sin asumir un
    catálogo fijo de nombres, porque puede variar según el entorno.

    Devuelve (scanner_dict_o_None, nota) -- 'nota' explica qué pasó
    incluso cuando no hay una detección clara (útil para el log): ningún
    scanner coincide, más de uno coincide (ambiguo), o se detectó exactamente
    uno.
    """
    segmentos = hostname.lower().split(".")[0].split("-")
    clave_sitio = "-".join(segmentos[:2]) if len(segmentos) >= 2 else (segmentos[0] if segmentos else "")
    if not clave_sitio:
        return None, "No se pudo derivar una clave de sitio del hostname para elegir el Agent Scanner."

    clave_sin_guiones = clave_sitio.replace("-", "")
    candidatos = [
        s for s in scanners if clave_sin_guiones in str(s.get("name", "")).lower().replace("-", "")
    ]
    if len(candidatos) == 1:
        return candidatos[0], f"Agent Scanner detectado por '{clave_sitio}': {candidatos[0].get('name')}"
    if len(candidatos) > 1:
        nombres = ", ".join(str(s.get("name")) for s in candidatos)
        return None, f"'{clave_sitio}' coincide con varios Agent Scanners ({nombres}) -- elige uno manualmente."
    return None, f"Ningún Agent Scanner coincide con '{clave_sitio}' entre los {len(scanners)} disponibles -- elige uno manualmente."


# Nombres de los "Assets" que Security Center trae de fábrica en TODA
# instalación (no son nada que haya creado un usuario ni un grupo
# sincronizado de un Nessus Manager). Lanzar un scan contra cualquiera de
# estos casi siempre significa "escanear todo lo que ve esa definición" --
# de ahí errores como "The number of Scan IPs is too large". Observados en
# una instancia real; puede que la tuya tenga más/menos según la versión.
ACTIVOS_GENERICOS_SC = frozenset({
    "all defined ranges",
    "systems discovered passively",
    "systems that have been scanned",
    "windows hosts",
    "voice or mobile client devices",
    "device type vpn",
    "device type switch",
    "device type router",
})


TIMEOUT = 30  # crear/lanzar scan, consultar estado: operaciones que pueden tardar más
LIST_TIMEOUT = 15  # listar scans/políticas/repos/zonas: deben responder rápido si hay conectividad
CONNECT_TEST_TIMEOUT = 8  # "Probar conexión": queremos un sí/no rápido, no esperar el timeout largo


class NessusManagerClient:
    def __init__(self, nombre, url, access_key, secret_key, verify_ssl=False):
        self.nombre = nombre
        self.url = url.rstrip("/")
        self.headers = {
            "X-ApiKeys": f"accessKey={access_key}; secretKey={secret_key}",
            "Content-Type": "application/json",
        }
        self.verify_ssl = bool(verify_ssl)

    def _get(self, path, timeout=None, **kwargs):
        r = requests.get(
            f"{self.url}{path}",
            headers=self.headers,
            verify=self.verify_ssl,
            timeout=timeout or TIMEOUT,
            **kwargs,
        )
        r.raise_for_status()
        return r.json()

    def _post(self, path, payload=None, timeout=None, **kwargs):
        r = requests.post(
            f"{self.url}{path}",
            headers=self.headers,
            json=payload or {},
            verify=self.verify_ssl,
            timeout=timeout or TIMEOUT,
            **kwargs,
        )
        r.raise_for_status()
        try:
            return r.json()
        except ValueError:
            return {}

    def _put(self, path, payload=None, timeout=None, **kwargs):
        r = requests.put(
            f"{self.url}{path}",
            headers=self.headers,
            json=payload or {},
            verify=self.verify_ssl,
            timeout=timeout or TIMEOUT,
            **kwargs,
        )
        r.raise_for_status()
        try:
            return r.json()
        except ValueError:
            return {}

    def listar_scans(self):
        return self._get("/scans", timeout=LIST_TIMEOUT).get("scans") or []

    def detalle_scan(self, scan_id):
        return self._get(f"/scans/{scan_id}", timeout=LIST_TIMEOUT)

    def probar_conexion(self):
        """
        Prueba rápida de conectividad + credenciales (timeout corto, no
        arrastra el timeout largo de las operaciones normales).
        Devuelve (ok: bool, mensaje: str).
        """
        try:
            r = requests.get(
                f"{self.url}/scans",
                headers=self.headers,
                verify=self.verify_ssl,
                timeout=CONNECT_TEST_TIMEOUT,
            )
        except requests.exceptions.SSLError as e:
            return False, f"Error SSL: {e}"
        except requests.exceptions.ConnectTimeout:
            return False, f"Sin respuesta en {CONNECT_TEST_TIMEOUT}s (host/puerto inalcanzable o bloqueado)"
        except requests.exceptions.ReadTimeout:
            return False, f"Conectó pero no respondió en {CONNECT_TEST_TIMEOUT}s"
        except requests.exceptions.ConnectionError as e:
            return False, _mensaje_connection_error(e)
        except requests.RequestException as e:
            return False, str(e)

        if r.status_code == 401:
            return False, "401 no autorizado — revisa access/secret key"
        if r.status_code == 403:
            return False, "403 prohibido — revisa permisos de la cuenta/API key"
        if not r.ok:
            return False, f"HTTP {r.status_code}"
        return True, "Conectado"

    # --- Grupos de agentes -----------------------------------------------
    # ADVERTENCIA: /agent-groups, /agents y /scanners son las rutas
    # ESTÁNDAR documentadas para Nessus Manager/Tenable.io, pero no se han
    # verificado del todo contra esta instancia real -- si algo da 404, es
    # la primera pista de que esta versión usa una ruta distinta (revisa
    # el volcado de debug).
    def listar_scanners(self):
        """
        Los "Agent Scanner" que ves como campo obligatorio al crear un
        grupo/scan de agente en la interfaz de Nessus Manager -- en este
        entorno hay exactamente uno por sitio (p.ej. MTY-ALE-PTNE002,
        MTY-TOB-PTNE002, QRO-ALE-PTNE002). Sin especificar el correcto al
        crear un grupo, este puede quedar sin agentes asociados aunque la
        creación en sí no falle.
        """
        return self._get("/scanners", timeout=LIST_TIMEOUT).get("scanners") or []

    def listar_grupos_agentes(self, scanner_id=None):
        path = f"/scanners/{scanner_id}/agent-groups" if scanner_id else "/agent-groups"
        return self._get(path, timeout=LIST_TIMEOUT).get("groups") or []

    def buscar_grupos_agentes(self, patron, scanner_id=None):
        """Substring, case-insensitive, sobre el nombre del grupo."""
        patron_l = patron.lower()
        return [
            g for g in self.listar_grupos_agentes(scanner_id=scanner_id) if patron_l in str(g.get("name", "")).lower()
        ]

    def crear_grupo_agente(self, nombre, scanner_id=None):
        path = f"/scanners/{scanner_id}/agent-groups" if scanner_id else "/agent-groups"
        resultado = self._post(path, {"name": nombre})
        # La respuesta real solo trae {"id": ...}, sin 'name' -- sin este
        # fallback, el log mostraba "Grupo creado: 'None'".
        if isinstance(resultado, dict) and not resultado.get("name"):
            resultado["name"] = nombre
        return resultado

    def listar_agentes(self, scanner_id=None):
        path = f"/scanners/{scanner_id}/agents" if scanner_id else "/agents"
        return self._get(path, timeout=LIST_TIMEOUT).get("agents") or []

    def buscar_agentes_por_host(self, candidatos, scanner_id=None):
        """
        candidatos: un string o una lista de strings (IP, hostname corto,
        FQDN...) -- se prueban TODOS, porque no hay certeza de si el campo
        'name' de un agente en Nessus Manager guarda el hostname corto, el
        FQDN, o la IP. Busca (substring, case-insensitive) contra 'name' e
        'ip' de cada agente YA REGISTRADO en este Nessus Manager (o, si se
        da scanner_id, solo entre los agentes de ese Agent Scanner).
        """
        return filtrar_agentes(self.listar_agentes(scanner_id=scanner_id), candidatos)

    def agregar_agente_a_grupo(self, group_id, agent_id, scanner_id=None):
        path = (
            f"/scanners/{scanner_id}/agent-groups/{group_id}/agents/{agent_id}"
            if scanner_id
            else f"/agent-groups/{group_id}/agents/{agent_id}"
        )
        return self._put(path)

    def indexar_hosts(self, progreso_cb=None):
        """
        Recorre TODOS los scans de este Nessus Manager y devuelve
        (filas, total_scans), donde filas es una lista de dicts
        {scan_id, scan_name, host, last_modification} lista para meterse
        en la caché SQLite.

        progreso_cb(actual, total, scan_name) es opcional, para reportar
        avance (p.ej. a una barra de progreso en la GUI).
        """
        filas = []
        scans = self.listar_scans()
        total = len(scans)
        for i, scan in enumerate(scans, start=1):
            scan_id = scan.get("id")
            scan_name = scan.get("name", "")
            if progreso_cb:
                progreso_cb(i, total, scan_name)
            try:
                detalle = self.detalle_scan(scan_id)
            except requests.RequestException as e:
                print(f"  [{self.nombre}] error en scan {scan_id} ({scan_name}): {e}", file=sys.stderr)
                continue
            for h in detalle.get("hosts") or []:
                hostname = str(h.get("hostname", ""))
                if not hostname:
                    continue
                filas.append(
                    {
                        "scan_id": scan_id,
                        "scan_name": scan_name,
                        "host": hostname,
                        "last_modification": scan.get("last_modification_date"),
                    }
                )
        return filas, total


class SecurityCenterClient:
    def __init__(self, url, access_key, secret_key, verify_ssl=False):
        self.url = url.rstrip("/")
        self.headers = {
            "x-apikey": f"accesskey={access_key}; secretkey={secret_key}",
            "Content-Type": "application/json",
        }
        self.verify_ssl = bool(verify_ssl)

    def _get(self, path, timeout=None, **kwargs):
        r = requests.get(
            f"{self.url}/rest{path}",
            headers=self.headers,
            verify=self.verify_ssl,
            timeout=timeout or TIMEOUT,
            **kwargs,
        )
        r.raise_for_status()
        return r.json().get("response")

    def _post(self, path, payload, timeout=None, **kwargs):
        r = requests.post(
            f"{self.url}/rest{path}",
            headers=self.headers,
            json=payload,
            verify=self.verify_ssl,
            timeout=timeout or TIMEOUT,
            **kwargs,
        )
        r.raise_for_status()
        return r.json().get("response")

    def listar_politicas(self):
        return _normalizar_lista_sc(self._get("/policy?fields=id,name,type,description", timeout=LIST_TIMEOUT))

    def listar_repositorios(self):
        # Sin filtrar 'fields': queremos el objeto completo que devuelva tu SC
        # (no solo id/name/type/dataFormat) para depurar qué campo distingue
        # de verdad un repositorio de agente en tu instancia -- ver el volcado
        # crudo en el log de la GUI/CLI al cargar catálogos.
        return _normalizar_lista_sc(self._get("/repository", timeout=LIST_TIMEOUT))

    def listar_zonas(self):
        return _normalizar_lista_sc(self._get("/zone?fields=id,name,ipList", timeout=LIST_TIMEOUT))

    def listar_activos(self):
        """
        Lista los "Asset Tags" (grupos/definiciones dinámicas o estáticas,
        p.ej. "All Defined Ranges", "Windows Hosts") de Security Center --
        NO son los "Host Assets" individuales (hosts ya escaneados,
        potencialmente decenas de miles). Para encontrar un host puntual
        usa buscar_host_asset() en vez de este método.
        """
        return _normalizar_lista_sc(self._get("/asset", timeout=LIST_TIMEOUT))

    def buscar_host_asset(self, ip, limite=50):
        """
        Busca en el inventario de HOSTS YA ESCANEADOS por Security Center
        (la vista "Host Assets" de la interfaz -- puede tener decenas de
        miles de registros) el/los que coinciden con esta IP, sin traer
        el inventario completo. Usa /rest/analysis con el tool 'sumip'
        (resumen por IP), el mecanismo estándar de Tenable.sc para
        consultar hosts individuales.

        EXPERIMENTAL: no verificado todavía contra una instancia real --
        revisa el volcado de debug si la respuesta no trae lo esperado.
        """
        payload = {
            "type": "vuln",
            "sourceType": "cumulative",
            "query": {
                "type": "vuln",
                "tool": "sumip",
                "sourceType": "cumulative",
                "filters": [{"filterName": "ip", "operator": "=", "value": ip}],
            },
            "sortField": "score",
            "sortDir": "desc",
            "startOffset": 0,
            "endOffset": limite,
        }
        resultado = self._post("/analysis", payload, timeout=LIST_TIMEOUT)
        return (resultado or {}).get("results") or []

    def buscar_activo_estatico(self, patron):
        """Substring, case-insensitive, sobre el nombre -- para no duplicar un Asset ya creado por esta herramienta."""
        patron_l = patron.lower()
        return [a for a in self.listar_activos() if patron_l in str(a.get("name", "")).lower()]

    def crear_activo_estatico(self, nombre, ip):
        """
        Crea un Asset Tag ESTÁTICO en Security Center con una sola IP
        definida -- CONFIRMADO como el tipo de objeto correcto para el
        campo 'assets' al crear un scan (a diferencia de un Host Asset
        individual, que SC rechaza con "Asset #<uuid> does not exist"):
        un scan type=agent contra el Asset de fábrica "All Defined Ranges"
        (id=0, también type=static) SÍ pasó la validación de rango sin
        problema -- solo falló después por traer demasiadas IPs, lo que
        confirma que un Asset estático del mismo tipo mío, con una sola IP,
        debería funcionar.

        EXPERIMENTAL: el nombre exacto del campo 'definedIPs' no se ha
        verificado contra tu instancia real -- revisa el debug si SC lo
        rechaza.
        """
        payload = {"name": nombre, "type": "static", "definedIPs": ip}
        return self._post("/asset", payload)

    def probar_conexion(self):
        """
        Prueba rápida de conectividad + credenciales contra /rest/currentUser
        (timeout corto). Devuelve (ok: bool, mensaje: str).
        """
        try:
            r = requests.get(
                f"{self.url}/rest/currentUser",
                headers=self.headers,
                verify=self.verify_ssl,
                timeout=CONNECT_TEST_TIMEOUT,
            )
        except requests.exceptions.SSLError as e:
            return False, f"Error SSL: {e}"
        except requests.exceptions.ConnectTimeout:
            return False, f"Sin respuesta en {CONNECT_TEST_TIMEOUT}s (host/puerto inalcanzable o bloqueado)"
        except requests.exceptions.ReadTimeout:
            return False, f"Conectó pero no respondió en {CONNECT_TEST_TIMEOUT}s"
        except requests.exceptions.ConnectionError as e:
            return False, _mensaje_connection_error(e)
        except requests.RequestException as e:
            return False, str(e)

        if r.status_code == 401:
            return False, "401 no autorizado — revisa access/secret key"
        if r.status_code == 403:
            return False, "403 prohibido — revisa permisos de la cuenta/API key"
        if not r.ok:
            return False, f"HTTP {r.status_code}"
        return True, "Conectado"

    def crear_scan(self, nombre, ips=None, policy_id=None, repository_id=None, zone_id=None, descripcion="", asset_id=None, tipo=None):
        """
        Dos modos de targeting, EXCLUYENTES entre sí:
          - Por IP (el de siempre): pasa 'ips', deja asset_id=None. type="policy".
          - Por activo/grupo (para repositorios de Agent, donde SC exige
            escanear un grupo de agentes en vez de una IP suelta): pasa
            'asset_id' (el id de un Asset de SC, ver listar_activos()) y
            deja ips=None. type="agent".
        'tipo' fuerza el type si hace falta (poco probable, pero por si tu
        SC usa un nombre distinto); si no se pasa, se infiere de si viene
        asset_id o ips.

        ADVERTENCIA: el modo por activo/grupo (asset_id) es EXPERIMENTAL --
        el payload exacto que espera Security Center para lanzar un scan
        de agente contra un grupo sincronizado desde un Nessus Manager
        vinculado no se ha verificado todavía contra una instancia real.
        Actívalo con 'Debug detallado' encendido y revisa la respuesta
        cruda si SC lo rechaza.
        """
        tipo_final = tipo or ("agent" if asset_id else "policy")
        payload = {
            "name": nombre,
            "description": descripcion,
            "type": tipo_final,
            "policy": {"id": str(policy_id)},
            "repository": {"id": str(repository_id)},
        }
        if asset_id:
            payload["assets"] = [{"id": str(asset_id)}]
        else:
            payload["ipList"] = ",".join(ips) if isinstance(ips, list) else (ips or "")
        if zone_id:
            payload["zone"] = {"id": str(zone_id)}
        return self._post("/scan", payload)

    def lanzar_scan(self, scan_id):
        return self._post(f"/scan/{scan_id}/launch", {})

    def estado_resultado(self, scan_result_id):
        return self._get(
            f"/scanResult/{scan_result_id}"
            "?fields=id,name,status,progress,scannedIPs,startTime,finishTime,errorDetails"
        )
