#!/usr/bin/env python3
"""
cli.py - CLI para Tenable SC Scanner.

Usa la MISMA base de datos SQLite que la GUI (tenable_sc_scanner.db, en esta
misma carpeta). Configura tus llaves primero desde la GUI (gui.py) — es la
forma más cómoda — o edita directamente los campos con las funciones de
db.py si prefieres scriptearlo.

Comandos:
    python cli.py sincronizar [--nessus Queretaro Monterrey]
    python cli.py buscar 10.20.30.40
    python cli.py politicas
    python cli.py repositorios
    python cli.py zonas
    python cli.py scan "Scan ad-hoc servidor X" 10.20.30.40 \
        --policy-id 1000001 --repository-id 4 --buscar-primero --seguir
"""

import argparse
import sys
import time

import db
from tenable_core import NessusManagerClient, SecurityCenterClient


def construir_clientes():
    nessus_managers = [
        NessusManagerClient(m["name"], m["url"], m["access_key"], m["secret_key"], m["verify_ssl"])
        for m in db.list_nessus_managers()
    ]
    sc_cfg = db.get_sc_config()
    sc = None
    if sc_cfg and sc_cfg["access_key"] and sc_cfg["secret_key"]:
        sc = SecurityCenterClient(sc_cfg["url"], sc_cfg["access_key"], sc_cfg["secret_key"], sc_cfg["verify_ssl"])
    return nessus_managers, sc


def cmd_sincronizar(nessus_managers, nombres=None):
    for nm in nessus_managers:
        if nombres and nm.nombre not in nombres:
            continue
        print(f"Sincronizando caché de '{nm.nombre}' ({nm.url}) ...")
        try:
            filas, total_scans = nm.indexar_hosts(
                progreso_cb=lambda i, t, n: print(f"  scan {i}/{t}: {n}", end="\r")
            )
            db.reemplazar_cache_manager(nm.nombre, filas, total_scans)
            print(f"\n  OK: {total_scans} scans revisados, {len(filas)} hosts indexados.")
        except Exception as e:
            db.reemplazar_cache_manager(nm.nombre, [], 0, error=str(e))
            print(f"\n  ERROR: {e}", file=sys.stderr)


def cmd_buscar(objetivo):
    resultados = db.buscar_en_cache(objetivo)
    if not resultados:
        print("Sin coincidencias en la caché local. Corre 'sincronizar' si la caché está vacía o vieja.")
    else:
        print(f"{len(resultados)} coincidencia(s) en caché:\n")
        for r in resultados:
            print(
                f"  - {r['nessus_manager']}: scan '{r['scan_name']}' (id={r['scan_id']}) "
                f"-> host={r['host']} (últ. mod scan: {r['last_modification']})"
            )

    estados = db.estado_cache()
    if estados:
        print("\nÚltima sincronización de caché por Nessus Manager:")
        for e in estados:
            estado_txt = f"ERROR: {e['error']}" if e["error"] else f"{e['hosts_indexados']} hosts indexados"
            print(f"  {e['nessus_manager']}: {estado_txt} ({e['synced_at']})")


def main():
    db.init_db()
    parser = argparse.ArgumentParser(description="Tenable SC Scanner (CLI)")
    sub = parser.add_subparsers(dest="comando", required=True)

    p_buscar = sub.add_parser("buscar", help="Buscar un host en la caché local")
    p_buscar.add_argument("objetivo", help="IP o hostname a buscar")

    p_sync = sub.add_parser("sincronizar", help="Refrescar la caché local consultando los Nessus Manager")
    p_sync.add_argument("--nessus", nargs="*", default=None, help="Nombres específicos (default: los 3)")

    sub.add_parser("politicas", help="Listar políticas de scan en Security Center")
    sub.add_parser("repositorios", help="Listar repositorios en Security Center")
    sub.add_parser("zonas", help="Listar zonas de escaneo en Security Center")

    p_scan = sub.add_parser("scan", help="Crear y lanzar un scan en Security Center")
    p_scan.add_argument("nombre")
    p_scan.add_argument("ips", nargs="+")
    p_scan.add_argument("--policy-id", required=True)
    p_scan.add_argument("--repository-id", required=True)
    p_scan.add_argument("--zone-id", default=None)
    p_scan.add_argument("--buscar-primero", action="store_true")
    p_scan.add_argument("--seguir", action="store_true")

    args = parser.parse_args()
    nessus_managers, sc = construir_clientes()

    if args.comando == "buscar":
        cmd_buscar(args.objetivo)

    elif args.comando == "sincronizar":
        cmd_sincronizar(nessus_managers, args.nessus)

    elif args.comando in ("politicas", "repositorios", "zonas"):
        if not sc:
            sys.exit("Configura Security Center primero (llaves vacías) — usa la GUI (gui.py).")
        if args.comando == "politicas":
            for p in sc.listar_politicas():
                print(f"  {p['id']:>8}  {p['name']}  ({p.get('type', '')})")
        elif args.comando == "repositorios":
            for r in sc.listar_repositorios():
                print(f"  {r['id']:>8}  {r['name']}  ({r.get('dataFormat', '')})")
        else:
            for z in sc.listar_zonas():
                print(f"  {z['id']:>8}  {z['name']}")

    elif args.comando == "scan":
        if not sc:
            sys.exit("Configura Security Center primero (llaves vacías) — usa la GUI (gui.py).")
        if args.buscar_primero:
            for objetivo in args.ips:
                cmd_buscar(objetivo)
            resp = input("¿Continuar y lanzar el scan de todas formas? [s/N]: ")
            if resp.strip().lower() != "s":
                print("Cancelado.")
                return

        creado = sc.crear_scan(args.nombre, args.ips, args.policy_id, args.repository_id, args.zone_id)
        scan_id = creado["id"]
        print(f"Scan creado: id={scan_id}")

        lanzado = sc.lanzar_scan(scan_id)
        scan_result_id = (lanzado.get("scanResult") or {}).get("id") or lanzado.get("id")
        print(f"Scan lanzado. scanResultID={scan_result_id}")
        db.registrar_scan_lanzado(
            args.nombre, args.ips, args.policy_id, args.repository_id, args.zone_id, scan_id, scan_result_id
        )

        if args.seguir and scan_result_id:
            print("Consultando estado cada 30s (Ctrl+C para dejar de seguir sin detener el scan)...")
            try:
                while True:
                    estado = sc.estado_resultado(scan_result_id)
                    status = estado.get("status")
                    print(f"  status={status}  progress={estado.get('progress')}")
                    db.actualizar_estado_scan(scan_result_id, status)
                    if status in ("Completed", "Canceled", "Aborted", "Error"):
                        break
                    time.sleep(30)
            except KeyboardInterrupt:
                print("\nSe dejó de seguir (el scan sigue corriendo en SC).")


if __name__ == "__main__":
    main()
