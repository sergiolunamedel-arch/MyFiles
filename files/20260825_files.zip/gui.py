#!/usr/bin/env python3
"""
gui.py - GUI (Tkinter) para configurar, probar búsquedas y lanzar scans en
el entorno Tenable on-prem (Security Center + 3 Nessus Manager).

Toda la configuración (URLs, access key, secret key) se guarda en SQLite
(tenable_sc_scanner.db, junto a este script) EN TEXTO PLANO -- decisión
aceptada explícitamente para agilizar las pruebas. No subas ese archivo .db
a ningún repositorio; en Linux/Mac considera "chmod 600 tenable_sc_scanner.db".

Pestañas:
  - Configuración : URLs y llaves de Security Center + los 3 Nessus Manager.
  - Buscar        : busca un host en la caché local (instantáneo) y permite
                    sincronizar esa caché contra los 3 Nessus Manager.
  - Lanzar Scan   : crea y lanza un scan en Security Center.
  - Historial     : scans lanzados desde esta herramienta.
"""

import json
import platform
import queue
import threading
import time
import tkinter as tk
from tkinter import messagebox, ttk

import db
from tenable_core import (
    ACTIVOS_GENERICOS_SC,
    NessusManagerClient,
    SecurityCenterClient,
    detalle_respuesta_http,
    detectar_nessus_manager_por_nombre,
    detectar_scanner_por_nombre,
    es_repositorio_de_agente,
    explicar_error_http,
    filtrar_agentes,
    resolver_targets,
    resumir_estado_scan,
    zona_para_ip,
)


def construir_nessus_clientes():
    return [
        NessusManagerClient(m["name"], m["url"], m["access_key"], m["secret_key"], m["verify_ssl"])
        for m in db.list_nessus_managers()
    ]


def construir_sc_cliente():
    sc_cfg = db.get_sc_config()
    if not sc_cfg or not sc_cfg["access_key"] or not sc_cfg["secret_key"]:
        return None
    return SecurityCenterClient(sc_cfg["url"], sc_cfg["access_key"], sc_cfg["secret_key"], sc_cfg["verify_ssl"])


# ---------------------------------------------------------------------------
# Pestaña Configuración
# ---------------------------------------------------------------------------
class LabeledEntry(ttk.Frame):
    def __init__(self, parent, label, show=None, width=50):
        super().__init__(parent)
        ttk.Label(self, text=label, width=14, anchor="w").pack(side="left")
        self.var = tk.StringVar()
        self.entry = ttk.Entry(self, textvariable=self.var, show=show, width=width)
        self.entry.pack(side="left", fill="x", expand=True, padx=(4, 0))

    def get(self):
        return self.var.get().strip()

    def set(self, value):
        self.var.set(value or "")


class CredBlock(ttk.LabelFrame):
    """Bloque reusable: URL + access key + secret key (mostrar/ocultar) + verify_ssl."""

    def __init__(self, parent, titulo, on_probar=None):
        super().__init__(parent, text=titulo, padding=8)
        self._on_probar = on_probar

        self.url = LabeledEntry(self, "URL")
        self.url.pack(fill="x", pady=2)

        self.access_key = LabeledEntry(self, "Access Key")
        self.access_key.pack(fill="x", pady=2)

        self.secret_key = LabeledEntry(self, "Secret Key", show="*")
        self.secret_key.pack(fill="x", pady=2)

        fila = ttk.Frame(self)
        fila.pack(fill="x", pady=2)
        self.mostrar_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(fila, text="Mostrar secret key", variable=self.mostrar_var, command=self._toggle_show).pack(
            side="left"
        )
        self.verify_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(fila, text="Verificar certificado SSL", variable=self.verify_var).pack(
            side="left", padx=(16, 0)
        )

        estado_fila = ttk.Frame(self)
        estado_fila.pack(fill="x", pady=(6, 0))
        self.foco_lbl = ttk.Label(estado_fila, text="●", foreground="#888888")
        self.foco_lbl.pack(side="left")
        self.estado_lbl = ttk.Label(estado_fila, text="sin probar", foreground="#888888")
        self.estado_lbl.pack(side="left", padx=(4, 10))
        ttk.Button(estado_fila, text="Probar conexión", command=self._probar).pack(side="left")

    def _toggle_show(self):
        self.secret_key.entry.configure(show="" if self.mostrar_var.get() else "*")

    def cargar(self, row):
        self.url.set(row["url"])
        self.access_key.set(row["access_key"])
        self.secret_key.set(row["secret_key"])
        self.verify_var.set(bool(row["verify_ssl"]))

    def valores(self):
        return self.url.get(), self.access_key.get(), self.secret_key.get(), self.verify_var.get()

    def _probar(self):
        if self._on_probar:
            self.set_estado_probando()
            self._on_probar(self)

    def set_estado_probando(self):
        self.foco_lbl.config(foreground="#d4a017")
        self.estado_lbl.config(text="probando...", foreground="#d4a017")

    def set_estado(self, ok, mensaje):
        color = "#2e7d32" if ok else "#b03a2e"
        self.foco_lbl.config(foreground=color)
        self.estado_lbl.config(text=mensaje, foreground=color)


class ConfigTab(ttk.Frame):
    def __init__(self, parent, on_guardado=None):
        super().__init__(parent, padding=10)
        self._on_guardado = on_guardado
        self._queue = queue.Queue()

        aviso = (
            "Las llaves se guardan en TEXTO PLANO en tenable_sc_scanner.db, junto a estos scripts.\n"
            "No lo subas a ningún repositorio."
        )
        ttk.Label(self, text=aviso, foreground="#b03a2e", wraplength=900, justify="left").pack(
            fill="x", pady=(0, 10)
        )

        contenedor = ttk.Frame(self)
        contenedor.pack(fill="both", expand=True)
        canvas = tk.Canvas(contenedor, highlightthickness=0)
        scroll = ttk.Scrollbar(contenedor, orient="vertical", command=canvas.yview)
        inner = ttk.Frame(canvas)
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        self.bloque_sc = CredBlock(inner, "Security Center", on_probar=self._probar_sc)
        self.bloque_sc.pack(fill="x", pady=6, padx=2)

        self.bloques_nessus = {}
        for m in db.list_nessus_managers():
            nombre = m["name"]
            bloque = CredBlock(
                inner, f"Nessus Manager — {nombre}", on_probar=lambda b, n=nombre: self._probar_nessus(b, n)
            )
            bloque.pack(fill="x", pady=6, padx=2)
            self.bloques_nessus[nombre] = bloque

        self._cargar_desde_db()

        botones = ttk.Frame(self)
        botones.pack(fill="x", pady=(10, 0))
        ttk.Button(botones, text="Guardar todo", command=self._guardar).pack(side="left")
        self.status_lbl = ttk.Label(botones, text="")
        self.status_lbl.pack(side="left", padx=10)

        self.after(150, self._poll_queue)
        # Persistencia de llaves -> probar conectividad sola al abrir el programa,
        # sin que el usuario tenga que pulsar nada (solo para bloques con llaves ya guardadas).
        self.after(300, self._auto_probar_todos)

    def _cargar_desde_db(self):
        sc = db.get_sc_config()
        if sc:
            self.bloque_sc.cargar(sc)
        for m in db.list_nessus_managers():
            self.bloques_nessus[m["name"]].cargar(m)

    def _guardar(self):
        url, ak, sk, vs = self.bloque_sc.valores()
        db.save_sc_config(url, ak, sk, vs)
        for nombre, bloque in self.bloques_nessus.items():
            url, ak, sk, vs = bloque.valores()
            db.save_nessus_manager(nombre, url, ak, sk, vs)
        self.status_lbl.config(text="Guardado.")
        self.after(2500, lambda: self.status_lbl.config(text=""))
        if self._on_guardado:
            self._on_guardado()

    def _probar_sc(self, bloque):
        url, ak, sk, vs = bloque.valores()

        def trabajo():
            cliente = SecurityCenterClient(url, ak, sk, vs)
            ok, msg = cliente.probar_conexion()
            self._queue.put((bloque, ok, msg))

        threading.Thread(target=trabajo, daemon=True).start()

    def _probar_nessus(self, bloque, nombre):
        url, ak, sk, vs = bloque.valores()

        def trabajo():
            cliente = NessusManagerClient(nombre, url, ak, sk, vs)
            ok, msg = cliente.probar_conexion()
            self._queue.put((bloque, ok, msg))

        threading.Thread(target=trabajo, daemon=True).start()

    def _auto_probar_todos(self):
        if self.bloque_sc.access_key.get() and self.bloque_sc.secret_key.get():
            self.bloque_sc.set_estado_probando()
            self._probar_sc(self.bloque_sc)
        for nombre, bloque in self.bloques_nessus.items():
            if bloque.access_key.get() and bloque.secret_key.get():
                bloque.set_estado_probando()
                self._probar_nessus(bloque, nombre)

    def _poll_queue(self):
        try:
            while True:
                bloque, ok, msg = self._queue.get_nowait()
                bloque.set_estado(ok, msg)
        except queue.Empty:
            pass
        self.after(150, self._poll_queue)


# ---------------------------------------------------------------------------
# Pestaña Buscar
# ---------------------------------------------------------------------------
class BuscarTab(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent, padding=10)
        self._queue = queue.Queue()

        top = ttk.Frame(self)
        top.pack(fill="x")
        ttk.Label(top, text="Host / IP:").pack(side="left")
        self.objetivo_var = tk.StringVar()
        entry = ttk.Entry(top, textvariable=self.objetivo_var, width=30)
        entry.pack(side="left", padx=6)
        entry.bind("<Return>", lambda e: self._buscar())
        ttk.Button(top, text="Buscar en caché", command=self._buscar).pack(side="left")

        sync_frame = ttk.LabelFrame(self, text="Caché local", padding=8)
        sync_frame.pack(fill="x", pady=10)
        self.estado_lbl = ttk.Label(sync_frame, text="", justify="left")
        self.estado_lbl.pack(anchor="w")

        btns = ttk.Frame(sync_frame)
        btns.pack(fill="x", pady=(6, 0))
        ttk.Button(btns, text="Sincronizar los 3 Nessus Manager", command=lambda: self._sincronizar(None)).pack(
            side="left"
        )
        for nombre in [m["name"] for m in db.list_nessus_managers()]:
            ttk.Button(btns, text=f"Sincronizar {nombre}", command=lambda n=nombre: self._sincronizar([n])).pack(
                side="left", padx=(6, 0)
            )

        self.progress = ttk.Progressbar(sync_frame, mode="indeterminate")
        self.log_txt = tk.Text(sync_frame, height=5, state="disabled")
        self.log_txt.pack(fill="x", pady=(6, 0))

        cols = ("nessus_manager", "scan_name", "host", "last_modification")
        headers = ("Nessus Manager", "Scan", "Host", "Última mod. scan")
        self.tree = ttk.Treeview(self, columns=cols, show="headings", height=15)
        for c, h, w in zip(cols, headers, (120, 260, 200, 180)):
            self.tree.heading(c, text=h)
            self.tree.column(c, width=w)
        self.tree.pack(fill="both", expand=True, pady=(10, 0))

        self._refrescar_estado_cache()
        self.after(150, self._poll_queue)

    def on_show(self):
        self._refrescar_estado_cache()

    def _refrescar_estado_cache(self):
        estados = db.estado_cache()
        if not estados:
            self.estado_lbl.config(text="Caché vacía. Sincroniza al menos una vez antes de buscar.")
            return
        partes = []
        for e in estados:
            if e["error"]:
                partes.append(f"{e['nessus_manager']}: ERROR ({e['error']}) — últ. intento {e['synced_at']}")
            else:
                partes.append(
                    f"{e['nessus_manager']}: {e['hosts_indexados']} hosts / {e['scans_revisados']} scans "
                    f"— {e['synced_at']}"
                )
        self.estado_lbl.config(text="\n".join(partes))

    def _log(self, msg):
        self.log_txt.configure(state="normal")
        self.log_txt.insert("end", msg + "\n")
        self.log_txt.see("end")
        self.log_txt.configure(state="disabled")

    def _buscar(self):
        objetivo = self.objetivo_var.get().strip()
        if not objetivo:
            return
        for item in self.tree.get_children():
            self.tree.delete(item)
        resultados = db.buscar_en_cache(objetivo)
        if not resultados:
            messagebox.showinfo("Buscar", "Sin coincidencias en la caché local.")
            return
        for r in resultados:
            self.tree.insert(
                "", "end", values=(r["nessus_manager"], r["scan_name"], r["host"], r["last_modification"])
            )

    def _sincronizar(self, nombres):
        self.progress.pack(fill="x", pady=(6, 0))
        self.progress.start(10)
        self._log("Iniciando sincronización...")

        def trabajo():
            for nm in construir_nessus_clientes():
                if nombres and nm.nombre not in nombres:
                    continue
                self._queue.put(("log", f"[{nm.nombre}] consultando scans..."))
                try:
                    def progreso_cb(i, t, nombre_scan, nm=nm):
                        self._queue.put(("log", f"[{nm.nombre}] scan {i}/{t}: {nombre_scan}"))

                    filas, total = nm.indexar_hosts(progreso_cb=progreso_cb)
                    db.reemplazar_cache_manager(nm.nombre, filas, total)
                    self._queue.put(("log", f"[{nm.nombre}] OK: {total} scans, {len(filas)} hosts indexados."))
                except Exception as e:
                    db.reemplazar_cache_manager(nm.nombre, [], 0, error=str(e))
                    self._queue.put(("log", f"[{nm.nombre}] ERROR: {e}"))
            self._queue.put(("done", None))

        threading.Thread(target=trabajo, daemon=True).start()

    def _poll_queue(self):
        try:
            while True:
                kind, payload = self._queue.get_nowait()
                if kind == "log":
                    self._log(payload)
                elif kind == "done":
                    self.progress.stop()
                    self.progress.pack_forget()
                    self._refrescar_estado_cache()
        except queue.Empty:
            pass
        self.after(150, self._poll_queue)


# ---------------------------------------------------------------------------
# Pestaña Lanzar Scan
# ---------------------------------------------------------------------------
class ScanTab(ttk.Frame):
    def __init__(self, parent, on_scan_registrado=None):
        super().__init__(parent, padding=10)
        self._queue = queue.Queue()
        self._on_scan_registrado = on_scan_registrado
        self._catalogos_cargados = False
        self._cargando_catalogos = False
        self._zonas_cache = []
        self._repos_por_id = {}
        self._activos_por_id = {}
        self._grupo_actual = None
        self._host_assets_por_id = {}
        self._scanner_id_actual = None

        form = ttk.Frame(self)
        form.pack(fill="x")
        form.columnconfigure(1, weight=1)

        ttk.Label(form, text="Nombre del scan:").grid(row=0, column=0, sticky="w")
        self.nombre_var = tk.StringVar()
        ttk.Entry(form, textvariable=self.nombre_var).grid(row=0, column=1, sticky="we", padx=6, pady=2)

        ttk.Label(form, text="IPs/hosts (coma):").grid(row=1, column=0, sticky="w")
        self.ips_var = tk.StringVar()
        self.ips_entry = ttk.Entry(form, textvariable=self.ips_var)
        self.ips_entry.grid(row=1, column=1, sticky="we", padx=6, pady=2)
        self.ips_entry.bind("<FocusOut>", self._detectar_zona)
        self.ips_entry.bind("<Return>", self._detectar_zona)

        ttk.Label(form, text="Política:").grid(row=2, column=0, sticky="w")
        self.politica_cb = ttk.Combobox(form, state="readonly")
        self.politica_cb.grid(row=2, column=1, sticky="we", padx=6, pady=2)

        ttk.Label(form, text="Repositorio:").grid(row=3, column=0, sticky="w")
        self.repo_cb = ttk.Combobox(form, state="readonly")
        self.repo_cb.grid(row=3, column=1, sticky="we", padx=6, pady=2)

        ttk.Label(form, text="Zona (opcional):").grid(row=4, column=0, sticky="w")
        zona_row = ttk.Frame(form)
        zona_row.grid(row=4, column=1, sticky="we", padx=6, pady=2)
        self.zona_cb = ttk.Combobox(zona_row, state="readonly")
        self.zona_cb.pack(side="left", fill="x", expand=True)
        self.zona_auto_lbl = ttk.Label(zona_row, text="", foreground="#888888")
        self.zona_auto_lbl.pack(side="left", padx=(8, 0))

        grupo_frame = ttk.LabelFrame(self, text="Target para repositorios de Agent", padding=8)
        grupo_frame.pack(fill="x", pady=(0, 8))

        target_fila = ttk.Frame(grupo_frame)
        target_fila.pack(fill="x")
        ttk.Button(
            target_fila,
            text="Preparar target y usar al lanzar",
            command=self._preparar_target_sc,
        ).pack(side="left")
        self.target_cb = ttk.Combobox(target_fila, state="readonly")
        self.target_cb.pack(side="left", padx=(8, 0), fill="x", expand=True)
        self.target_status_lbl = ttk.Label(target_fila, text="", foreground="#888888")
        self.target_status_lbl.pack(side="left", padx=(8, 0))

        self.usar_grupo_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            grupo_frame,
            text="Usar el target preparado en vez de IP directa al lanzar",
            variable=self.usar_grupo_var,
        ).pack(anchor="w", pady=(6, 0))

        ttk.Label(
            grupo_frame,
            foreground="#888888",
            justify="left",
            wraplength=900,
            text=(
                "Crea (o reutiliza si ya existe) un Asset estático en Security Center con solo la IP de "
                "este host, y lo deja listo para lanzar -- confirmado que este tipo de Asset SÍ es el que "
                "Security Center acepta como target de un scan de agente (a diferencia de un Host Asset "
                "individual, que SC rechaza)."
            ),
        ).pack(anchor="w", pady=(4, 0))

        avanzado_frame = ttk.LabelFrame(self, text="Avanzado / diagnóstico (no necesario para lanzar)", padding=8)
        avanzado_frame.pack(fill="x", pady=(0, 8))

        grupo_fila1 = ttk.Frame(avanzado_frame)
        grupo_fila1.pack(fill="x")
        ttk.Button(
            grupo_fila1,
            text="Preparar grupo en Nessus Manager",
            command=self._preparar_grupo_agente,
        ).pack(side="left")
        self.grupo_nm_status_lbl = ttk.Label(grupo_fila1, text="", foreground="#888888")
        self.grupo_nm_status_lbl.pack(side="left", padx=(8, 0))

        grupo_fila_host = ttk.Frame(avanzado_frame)
        grupo_fila_host.pack(fill="x", pady=(6, 0))
        ttk.Button(
            grupo_fila_host, text="Buscar Host Asset (solo para verificar)", command=self._buscar_host_asset
        ).pack(side="left")
        self.host_asset_cb = ttk.Combobox(grupo_fila_host, state="readonly")
        self.host_asset_cb.pack(side="left", padx=(8, 0), fill="x", expand=True)
        self.host_asset_status_lbl = ttk.Label(grupo_fila_host, text="", foreground="#888888")
        self.host_asset_status_lbl.pack(side="left", padx=(8, 0))

        grupo_fila2 = ttk.Frame(avanzado_frame)
        grupo_fila2.pack(fill="x", pady=(6, 0))
        ttk.Button(
            grupo_fila2, text="Cargar Asset Tags de SC", command=self._cargar_activos_sc
        ).pack(side="left")
        self.activo_cb = ttk.Combobox(grupo_fila2, state="readonly")
        self.activo_cb.pack(side="left", padx=(8, 0), fill="x", expand=True)

        ttk.Label(
            avanzado_frame,
            foreground="#888888",
            justify="left",
            wraplength=900,
            text=(
                "El grupo de Nessus Manager y el Host Asset son informativos/de diagnóstico -- no se usan "
                "para lanzar (Security Center rechazó un Host Asset como target real: \"Asset ... does not "
                "exist\"). Los 'Asset Tags' (p.ej. 'Windows Hosts') son grupos/dashboards genéricos de SC, "
                "no representan un host puntual -- déjalos así salvo que sepas que necesitas uno específico."
            ),
        ).pack(anchor="w", pady=(4, 0))

        ttk.Label(
            avanzado_frame,
            foreground="#b08600",
            justify="left",
            wraplength=900,
            text=(
                "Experimental: la API de grupos de agentes de Nessus Manager, la búsqueda de Host Asset, y "
                "cómo Security Center referencia un grupo sincronizado no se han verificado todavía contra "
                "tu instancia real -- revisa el log con 'Debug detallado' activado."
            ),
        ).pack(anchor="w", pady=(4, 0))

        botones = ttk.Frame(self)
        botones.pack(fill="x", pady=8)
        ttk.Button(botones, text="Cargar catálogos de SC", command=lambda: self._cargar_catalogos(False)).pack(
            side="left"
        )
        self.catalogos_status_lbl = ttk.Label(botones, text="Catálogos: sin cargar", foreground="#888888")
        self.catalogos_status_lbl.pack(side="left", padx=(8, 0))

        self.buscar_primero_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(botones, text="Buscar primero en caché", variable=self.buscar_primero_var).pack(
            side="left", padx=10
        )
        self.seguir_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(botones, text="Seguir estado tras lanzar", variable=self.seguir_var).pack(side="left")
        self.auto_zona_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(botones, text="Detectar zona por IP", variable=self.auto_zona_var).pack(
            side="left", padx=10
        )
        self.debug_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(botones, text="Debug detallado", variable=self.debug_var).pack(side="left")

        ttk.Button(botones, text="Lanzar scan", command=self._lanzar).pack(side="right")

        estado_row = ttk.Frame(self)
        estado_row.pack(fill="x", pady=(0, 4))
        self.estado_scan_lbl = ttk.Label(estado_row, text="Estado del scan: —", foreground="#888888")
        self.estado_scan_lbl.pack(side="left")

        self.log_txt = tk.Text(self, height=18, state="disabled")
        self.log_txt.pack(fill="both", expand=True, pady=(6, 0))

        self.after(150, self._poll_queue)

    def on_show(self):
        if not self._catalogos_cargados and not self._cargando_catalogos:
            self._cargar_catalogos(silencioso=True)

    def invalidar_catalogos(self):
        """Llamado cuando se guarda la pestaña Configuración: las llaves de SC
        pudieron cambiar, así que hay que volver a cargar los catálogos la
        próxima vez que se muestre esta pestaña."""
        self._catalogos_cargados = False
        self._zonas_cache = []
        self._repos_por_id = {}
        self.politica_cb["values"] = []
        self.repo_cb["values"] = []
        self.zona_cb["values"] = []
        self.politica_cb.set("")
        self.repo_cb.set("")
        self.zona_cb.set("")
        self.zona_auto_lbl.config(text="")
        self.catalogos_status_lbl.config(text="Catálogos: sin cargar", foreground="#888888")

    def _detectar_zona(self, *_args):
        if not self.auto_zona_var.get() or not self._zonas_cache:
            return
        ips = [x.strip() for x in self.ips_var.get().split(",") if x.strip()]
        if not ips:
            return
        # timeout corto: esto corre en el hilo de la UI (evento FocusOut/Return),
        # un DNS lento no debe congelar la ventana.
        resueltos, _notas = resolver_targets(ips[:1], timeout_dns=2)
        ip_para_zona = resueltos[0] if resueltos else ips[0]
        zona = zona_para_ip(self._zonas_cache, ip_para_zona)
        if zona:
            etiqueta = f"{zona['id']} — {zona['name']}"
            if etiqueta in self.zona_cb["values"]:
                self.zona_cb.set(etiqueta)
            sufijo = f" (+{len(ips) - 1} más)" if len(ips) > 1 else ""
            self.zona_auto_lbl.config(text=f"detectada por {ip_para_zona}{sufijo}", foreground="#2e7d32")
        else:
            self.zona_auto_lbl.config(text=f"sin zona automática para {ip_para_zona}", foreground="#888888")

    def _log(self, msg):
        self.log_txt.configure(state="normal")
        self.log_txt.insert("end", msg + "\n")
        self.log_txt.see("end")
        self.log_txt.configure(state="disabled")

    # --- Flujo de grupo de agente ---------------------------------------
    def _preparar_grupo_agente(self):
        ips = [x.strip() for x in self.ips_var.get().split(",") if x.strip()]
        if not ips:
            messagebox.showwarning("Grupo de agente", "Escribe al menos una IP/hostname primero.")
            return
        objetivo = ips[0]
        nessus_managers_cfg = db.list_nessus_managers()
        debug = self.debug_var.get()

        self.grupo_nm_status_lbl.config(text="Detectando Nessus Manager...", foreground="#888888")

        def trabajo():
            # TODO lo que pueda tocar la red (incluyendo el DNS inverso de
            # detectar_nessus_manager_por_nombre) vive en este hilo -- nunca
            # en el principal, para no congelar la ventana.
            nm_detectado, hostname_usado, nota = detectar_nessus_manager_por_nombre(objetivo, nessus_managers_cfg)
            self._queue.put(("log", f"[Grupo] {nota}"))
            if not nm_detectado:
                self._queue.put(("grupo_no_detectado", nota))
                return
            if not nm_detectado["access_key"] or not nm_detectado["secret_key"]:
                self._queue.put(("grupo_sin_llaves", nm_detectado["name"]))
                return

            cliente_nm = NessusManagerClient(
                nm_detectado["name"],
                nm_detectado["url"],
                nm_detectado["access_key"],
                nm_detectado["secret_key"],
                nm_detectado["verify_ssl"],
            )
            # Confirmado con captura real del front-end: los grupos de agente
            # se nombran con la IP cruda (p.ej. "10.48.49.29"), no el
            # hostname/FQDN -- se resuelve aquí si hace falta.
            resueltos, notas_resolucion = resolver_targets([objetivo])
            for nota_r in notas_resolucion:
                self._queue.put(("log", nota_r))
            ip_grupo = resueltos[0] if resueltos else objetivo
            patron = ip_grupo

            # No hay certeza de en qué formato Nessus Manager guarda el 'name'
            # de un agente (FQDN, hostname corto, IP, o algo distinto) -- se
            # prueban varios candidatos en vez de uno solo.
            candidatos = [ip_grupo]
            if hostname_usado:
                candidatos.append(hostname_usado)
                corto = hostname_usado.split(".")[0]
                if corto.lower() != hostname_usado.lower():
                    candidatos.append(corto)
            candidatos.append(objetivo)
            vistos = set()
            candidatos = [c for c in candidatos if c and not (c.lower() in vistos or vistos.add(c.lower()))]

            try:
                grupos = cliente_nm.buscar_grupos_agentes(patron)
                agentes_todos = cliente_nm.listar_agentes()
                agentes = filtrar_agentes(agentes_todos, candidatos)
                if debug:
                    self._queue.put(("log", f"[Grupo][DEBUG] grupos que coinciden con '{patron}': {json.dumps(grupos, ensure_ascii=False)[:1500]}"))
                    self._queue.put(("log", f"[Grupo][DEBUG] total de agentes en {nm_detectado['name']}: {len(agentes_todos)}"))
                    self._queue.put(("log", f"[Grupo][DEBUG] agentes crudos (primeros 5 de {len(agentes_todos)}): {json.dumps(agentes_todos[:5], ensure_ascii=False)[:1500]}"))
                    self._queue.put(("log", f"[Grupo][DEBUG] candidatos de búsqueda: {candidatos} -> coinciden: {json.dumps(agentes, ensure_ascii=False)[:1500]}"))
                self._queue.put(("grupo_busqueda", (cliente_nm, patron, objetivo, candidatos, grupos, agentes)))
            except Exception as e:
                pista = explicar_error_http(e)
                detalle = detalle_respuesta_http(e)
                msg = f"[Grupo] ERROR buscando en {nm_detectado['name']}: {e}"
                if pista:
                    msg += f"\n    💡 {pista}"
                if detalle:
                    msg += f"\n    📄 {detalle}"
                self._queue.put(("log", msg))
                self._queue.put(("grupo_status", f"Nessus Manager: {nm_detectado['name']} — error"))

        threading.Thread(target=trabajo, daemon=True).start()

    def _continuar_preparacion_grupo(self, cliente_nm, patron, objetivo, candidatos, grupos, agentes):
        if grupos:
            grupo = grupos[0]
            self._log(
                f"[Grupo] Ya existe un grupo que coincide: '{grupo.get('name')}' (id={grupo.get('id')}) "
                "— se usará ese, no se crea uno nuevo."
            )
            self._continuar_con_agente(cliente_nm, grupo, objetivo, candidatos, agentes)
            return

        crear = messagebox.askyesno(
            "Crear grupo de agente",
            f"No se encontró ningún grupo existente en {cliente_nm.nombre} que coincida con '{patron}'.\n\n"
            f"¿Crear un grupo nuevo llamado '{patron}'?",
        )
        if not crear:
            self._log("[Grupo] Cancelado por el usuario — no se creó ningún grupo.")
            self.grupo_nm_status_lbl.config(text=f"Nessus Manager: {cliente_nm.nombre} — sin grupo", foreground="#888888")
            return

        debug = self.debug_var.get()

        def trabajo():
            try:
                nuevo = cliente_nm.crear_grupo_agente(patron)
                if debug:
                    self._queue.put(("log", f"[Grupo][DEBUG] respuesta cruda crear_grupo_agente: {json.dumps(nuevo, ensure_ascii=False)[:1000]}"))
                self._queue.put(("grupo_creado", (cliente_nm, nuevo, objetivo, candidatos, agentes)))
            except Exception as e:
                pista = explicar_error_http(e)
                detalle = detalle_respuesta_http(e)
                msg = f"[Grupo] ERROR creando el grupo: {e}"
                if pista:
                    msg += f"\n    💡 {pista}"
                if detalle:
                    msg += f"\n    📄 {detalle}"
                self._queue.put(("log", msg))

        threading.Thread(target=trabajo, daemon=True).start()

    def _continuar_con_agente(self, cliente_nm, grupo, objetivo, candidatos, agentes):
        self._grupo_actual = grupo
        self.grupo_nm_status_lbl.config(
            text=f"Nessus Manager: {cliente_nm.nombre} — grupo '{grupo.get('name')}' (id={grupo.get('id')})",
            foreground="#2e7d32",
        )
        if not agentes:
            self._log(
                f"[Grupo] No se encontró ningún agente en {cliente_nm.nombre} que coincida con "
                f"{candidatos} — el agente debe existir ya instalado/registrado; esta herramienta no instala "
                "agentes, solo agrupa los que ya están. El grupo quedó creado pero VACÍO (informativo — usa "
                "'Preparar target y usar al lanzar' arriba para el scan)."
            )
            return

        agente = agentes[0]
        ya_en_grupo = any(
            str(g.get("id")) == str(grupo.get("id")) for g in (agente.get("groups") or []) if isinstance(g, dict)
        )
        if ya_en_grupo:
            self._log(f"[Grupo] El agente '{agente.get('name')}' ya pertenece al grupo — listo, no hace falta nada más.")
            return

        agregar = messagebox.askyesno(
            "Agregar agente al grupo",
            f"Se encontró el agente '{agente.get('name', objetivo)}' en {cliente_nm.nombre}.\n\n"
            f"¿Agregarlo al grupo '{grupo.get('name')}'?",
        )
        if not agregar:
            self._log("[Grupo] Cancelado por el usuario — agente no agregado al grupo.")
            return

        debug = self.debug_var.get()

        def trabajo():
            try:
                r = cliente_nm.agregar_agente_a_grupo(grupo.get("id"), agente.get("id"))
                if debug:
                    self._queue.put(("log", f"[Grupo][DEBUG] respuesta cruda agregar_agente_a_grupo: {json.dumps(r, ensure_ascii=False)[:500]}"))
                self._queue.put(("log", f"[Grupo] Agente '{agente.get('name')}' agregado al grupo '{grupo.get('name')}'."))
                self._queue.put(("grupo_agente_agregado", objetivo))
            except Exception as e:
                pista = explicar_error_http(e)
                detalle = detalle_respuesta_http(e)
                msg = f"[Grupo] ERROR agregando el agente al grupo: {e}"
                if pista:
                    msg += f"\n    💡 {pista}"
                if detalle:
                    msg += f"\n    📄 {detalle}"
                self._queue.put(("log", msg))

        threading.Thread(target=trabajo, daemon=True).start()

    def _preparar_target_sc(self):
        ips = [x.strip() for x in self.ips_var.get().split(",") if x.strip()]
        if not ips:
            messagebox.showwarning("Preparar target", "Escribe al menos una IP/hostname primero.")
            return
        objetivo = ips[0]
        sc = construir_sc_cliente()
        if not sc:
            messagebox.showwarning("Security Center", "Configura Security Center primero (pestaña Configuración).")
            return
        debug = self.debug_var.get()
        repository_id = (self.repo_cb.get().split(" — ")[0].strip() or None) if self.repo_cb.get() else None
        self.target_status_lbl.config(text="preparando...", foreground="#888888")

        def trabajo():
            # resolver_targets también resuelve DNS -- correr en el hilo de fondo.
            resueltos, notas = resolver_targets([objetivo])
            for nota in notas:
                self._queue.put(("log", nota))
            ip = resueltos[0] if resueltos else objetivo

            # Agent Scanner: confirmado con captura real que vive en Security
            # Center (no en Nessus Manager, como se pensó antes). Se detecta
            # igual que el Nessus Manager: por el prefijo de sitio del hostname.
            _, hostname_para_scanner, _ = detectar_nessus_manager_por_nombre(objetivo, db.list_nessus_managers())
            scanner_id = None
            try:
                scanners = sc.listar_scanners()
                if debug:
                    self._queue.put(("log", f"[Target][DEBUG] Scanners en Security Center: {json.dumps(scanners, ensure_ascii=False)[:1500]}"))
                scanner_obj, nota_scanner = detectar_scanner_por_nombre(hostname_para_scanner or objetivo, scanners)
                self._queue.put(("log", f"[Target] {nota_scanner}"))
                if scanner_obj:
                    scanner_id = scanner_obj.get("id")
            except Exception as e:
                self._queue.put(("log", f"[Target] No se pudo listar Agent Scanners de SC: {e}"))

            nombre_propio = f"{ip} (auto)"
            try:
                # Buscar por la IP cruda primero -- si el grupo ya existe en
                # Nessus Manager y sincronizó a SC (confirmado con captura real
                # que los grupos se llaman así, p.ej. "10.48.49.29"), debería
                # aparecer aquí sin que esta herramienta tenga que crear nada.
                candidatos_activo = sc.buscar_activo_estatico(ip)
                if debug:
                    self._queue.put(("log", f"[Target][DEBUG] Assets existentes que coinciden con '{ip}': {json.dumps(candidatos_activo, ensure_ascii=False)[:1500]}"))

                propio = next((a for a in candidatos_activo if a.get("name") == nombre_propio), None)
                externo = next((a for a in candidatos_activo if a is not propio), None)

                if externo:
                    activo = externo
                    self._queue.put(("log", f"[Target] Ya existe un Asset en SC que coincide con '{ip}': '{activo.get('name')}' (id={activo.get('id')}) — se usará tal cual (probablemente sincronizado desde Nessus Manager)."))
                elif propio:
                    self._queue.put(("log", f"[Target] Reparando/actualizando el Asset propio '{propio.get('name')}' (id={propio.get('id')}) con repository_id={repository_id}..."))
                    activo = sc.actualizar_activo_estatico(propio.get("id"), ip, repository_id=repository_id)
                    if debug:
                        self._queue.put(("log", f"[Target][DEBUG] respuesta cruda actualizar_activo_estatico: {json.dumps(activo, ensure_ascii=False)[:1000]}"))
                    if not isinstance(activo, dict) or not activo.get("id"):
                        activo = propio  # algunas APIs de PATCH devuelven vacío; nos quedamos con el id conocido
                    if isinstance(activo, dict) and not activo.get("name"):
                        activo["name"] = propio.get("name")
                        activo["id"] = propio.get("id")
                else:
                    self._queue.put(("log", f"[Target] Creando Asset estático en Security Center con IP {ip} (repository_id={repository_id})..."))
                    activo = sc.crear_activo_estatico(nombre_propio, ip, repository_id=repository_id)
                    if debug:
                        self._queue.put(("log", f"[Target][DEBUG] respuesta cruda crear_activo_estatico: {json.dumps(activo, ensure_ascii=False)[:1000]}"))
                    if isinstance(activo, dict) and not activo.get("name"):
                        activo["name"] = nombre_propio
                    self._queue.put(("log", f"[Target] Asset creado: '{activo.get('name')}' (id={activo.get('id')})."))

                self._queue.put(("target_listo", (activo, scanner_id)))
            except Exception as e:
                pista = explicar_error_http(e)
                detalle = detalle_respuesta_http(e)
                msg = f"[Target] ERROR preparando el Asset en Security Center: {e}"
                if pista:
                    msg += f"\n    💡 {pista}"
                if detalle:
                    msg += f"\n    📄 {detalle}"
                self._queue.put(("log", msg))
                self._queue.put(("target_error", None))

        threading.Thread(target=trabajo, daemon=True).start()

    def _cargar_activos_sc(self):
        sc = construir_sc_cliente()
        if not sc:
            messagebox.showwarning("Security Center", "Configura Security Center primero (pestaña Configuración).")
            return
        debug = self.debug_var.get()

        def trabajo():
            try:
                activos = sc.listar_activos()
                if debug:
                    self._queue.put(("log", f"[Activos SC][DEBUG] {json.dumps(activos, ensure_ascii=False)[:2000]}"))
                self._queue.put(("activos_sc", activos))
            except Exception as e:
                pista = explicar_error_http(e)
                detalle = detalle_respuesta_http(e)
                msg = f"[Activos SC] ERROR: {e}"
                if pista:
                    msg += f"\n    💡 {pista}"
                if detalle:
                    msg += f"\n    📄 {detalle}"
                self._queue.put(("log", msg))

        threading.Thread(target=trabajo, daemon=True).start()

    def _buscar_host_asset(self, objetivo=None, auto=False):
        if objetivo is None:
            ips = [x.strip() for x in self.ips_var.get().split(",") if x.strip()]
            if not ips:
                if not auto:
                    messagebox.showwarning("Host Asset", "Escribe al menos una IP/hostname primero.")
                return
            objetivo = ips[0]
        sc = construir_sc_cliente()
        if not sc:
            if not auto:
                messagebox.showwarning("Security Center", "Configura Security Center primero (pestaña Configuración).")
            return
        debug = self.debug_var.get()

        self.host_asset_status_lbl.config(text="buscando...", foreground="#888888")

        def trabajo():
            # resolver_targets también resuelve DNS -- correr en el hilo de
            # fondo, no en el principal.
            resueltos, notas = resolver_targets([objetivo])
            for nota in notas:
                self._queue.put(("log", nota))
            ip = resueltos[0] if resueltos else objetivo
            try:
                resultados = sc.buscar_host_asset(ip)
                if debug:
                    self._queue.put(("log", f"[Host Asset][DEBUG] búsqueda por ip={ip!r}: {json.dumps(resultados, ensure_ascii=False)[:2000]}"))
                self._queue.put(("host_asset_resultado", resultados))
            except Exception as e:
                pista = explicar_error_http(e)
                detalle = detalle_respuesta_http(e)
                msg = f"[Host Asset] ERROR buscando '{ip}': {e}"
                if pista:
                    msg += f"\n    💡 {pista}"
                if detalle:
                    msg += f"\n    📄 {detalle}"
                self._queue.put(("log", msg))
                self._queue.put(("host_asset_error", None))

        threading.Thread(target=trabajo, daemon=True).start()

    def _cargar_catalogos(self, silencioso=False):
        sc = construir_sc_cliente()
        if not sc:
            if not silencioso:
                messagebox.showwarning(
                    "Security Center",
                    "Configura la URL y las llaves de Security Center primero (pestaña Configuración).",
                )
            return
        if self._cargando_catalogos:
            return

        self._cargando_catalogos = True
        self.catalogos_status_lbl.config(text="Catálogos: cargando...", foreground="#888888")

        def trabajo():
            try:
                politicas = sc.listar_politicas()
                repos = sc.listar_repositorios()
                zonas = sc.listar_zonas()
                self._queue.put(("catalogos", (politicas, repos, zonas)))
            except Exception as e:
                self._queue.put(("catalogos_error", str(e)))

        threading.Thread(target=trabajo, daemon=True).start()

    def _lanzar(self):
        nombre = self.nombre_var.get().strip()
        ips_originales = [x.strip() for x in self.ips_var.get().split(",") if x.strip()]
        politica = self.politica_cb.get()
        repo = self.repo_cb.get()
        zona = self.zona_cb.get()

        faltantes = []
        if not nombre:
            faltantes.append("nombre")
        if not ips_originales:
            faltantes.append("IPs")
        if not politica:
            faltantes.append("política")
        if not repo:
            faltantes.append("repositorio")

        if faltantes:
            extra = ""
            if not self.politica_cb["values"] or not self.repo_cb["values"]:
                extra = (
                    "\n\nLos combos de política/repositorio están vacíos: pulsa "
                    "'Cargar catálogos de SC' (o revisa Configuración). El botón "
                    "'Sincronizar' de la pestaña Buscar solo prueba las llaves de "
                    "los Nessus Manager, no las de Security Center."
                )
            messagebox.showwarning("Lanzar scan", f"Falta: {', '.join(faltantes)}.{extra}")
            return

        # Resolver cualquier hostname a IP ANTES de mandarlo a Security Center: un
        # hostname que SC no reconozca como IP produce "Entered IPs and Assets are
        # empty" sin relación alguna con repositorio/zona (ya pasó con este caso real).
        ips, notas_resolucion = resolver_targets(ips_originales)
        for nota in notas_resolucion:
            self._log(nota)

        policy_id = politica.split(" — ")[0]
        repository_id = repo.split(" — ")[0]
        zone_id = zona.split(" — ")[0] if zona else None

        asset_id = None
        if self.usar_grupo_var.get():
            target_sel = self.target_cb.get()
            activo_sel = self.activo_cb.get()

            if target_sel:
                candidato_id = target_sel.split(" — ")[0].strip()
                origen = "target preparado"
            elif activo_sel:
                candidato_id, _, nombre_activo = activo_sel.partition(" — ")
                candidato_id = candidato_id.strip()
                origen = "Asset Tag"
                if nombre_activo.strip().lower() in ACTIVOS_GENERICOS_SC:
                    proceder_generico = messagebox.askyesno(
                        "Activo genérico de Security Center",
                        f"'{nombre_activo}' es un activo GENÉRICO de fábrica de Security Center — representa "
                        "TODO lo que ve esa definición (todas las zonas, todo lo descubierto, etc.), no un host "
                        "puntual. Lanzar un scan contra esto normalmente falla con \"demasiadas IPs\" o escanea "
                        "cosas que no quieres (fue justo la causa del error anterior).\n\n"
                        "¿Seguro que quieres usar este activo de todas formas?",
                    )
                    if not proceder_generico:
                        return
            else:
                candidato_id, origen = None, None

            # BUG real corregido: si el id queda vacío, esto NUNCA debe caer en
            # silencio a IP directa (ipList) -- el usuario pidió explícitamente
            # que el programa jamás escanee por IP sola cuando se activa esta
            # opción. Se detiene con un aviso claro en vez de lanzar de todas formas.
            if not candidato_id:
                messagebox.showwarning(
                    "Sin target válido",
                    "Activaste 'usar el target preparado' pero no hay un identificador utilizable "
                    "(el campo seleccionado está vacío o no elegiste nada). NO se va a lanzar por IP "
                    "directa. Pulsa 'Preparar target y usar al lanzar' de nuevo.",
                )
                return

            asset_id = candidato_id
            self._log(f"[Lanzar] Usando {origen} como target: {target_sel or activo_sel}")

        repo_obj = self._repos_por_id.get(repository_id)
        if not asset_id and repo_obj and es_repositorio_de_agente(repo_obj):
            proceder = messagebox.askyesno(
                "Repositorio de tipo Agent",
                f"'{repo_obj.get('name', repository_id)}' parece ser un repositorio de tipo "
                "Agent (se llena con los check-ins del Nessus Agent instalado en cada host, "
                "no con scans activos push-por-IP).\n\n"
                "Si ya probaste este mismo repositorio antes y Security Center respondió "
                "\"Scan IPs are not within your accessible range\" o un 403 -- eso confirma "
                "que este repositorio en particular no acepta scans activos por IP en tu "
                "Security Center.\n\n"
                "Usa el botón 'Preparar target y usar al lanzar' arriba para lanzarlo contra "
                "un target válido en vez de una IP directa, o cambia al repositorio 'activo' "
                "correspondiente.\n\n"
                "¿Continuar de todas formas (por IP)?",
            )
            if not proceder:
                return

        sc = construir_sc_cliente()
        if not sc:
            messagebox.showwarning("Security Center", "Configura Security Center primero.")
            return

        if self.buscar_primero_var.get():
            hay_historial = False
            for objetivo in ips:
                resultados = db.buscar_en_cache(objetivo)
                if resultados:
                    hay_historial = True
                    self._log(
                        f"'{objetivo}' ya tiene {len(resultados)} coincidencia(s) en caché "
                        f"— revisa la pestaña Buscar para el detalle."
                    )
            if hay_historial and not messagebox.askyesno("Confirmar", "Ya hay historial. ¿Lanzar de todas formas?"):
                return

        seguir = self.seguir_var.get()  # leer las variables Tk en el hilo principal, no dentro de trabajo()
        debug = self.debug_var.get()
        scanner_id = self._scanner_id_actual if asset_id else None
        self.estado_scan_lbl.config(text="Estado del scan: lanzando...", foreground="#888888")

        def trabajo():
            try:
                if debug:
                    self._queue.put((
                        "log",
                        "[DEBUG] POST /rest/scan payload -> "
                        f"nombre={nombre!r} ips={ips!r} asset_id={asset_id!r} scanner_id={scanner_id!r} "
                        f"policy_id={policy_id!r} repository_id={repository_id!r} zone_id={zone_id!r}",
                    ))

                creado = sc.crear_scan(nombre, ips, policy_id, repository_id, zone_id, asset_id=asset_id, scanner_id=scanner_id)
                scan_id = creado["id"]
                self._queue.put(("log", f"Scan creado: id={scan_id}"))
                if debug:
                    self._queue.put(("log", f"    [DEBUG] respuesta cruda crear_scan: {json.dumps(creado, ensure_ascii=False)[:1500]}"))

                lanzado = sc.lanzar_scan(scan_id)
                scan_result_id = (lanzado.get("scanResult") or {}).get("id") or lanzado.get("id")
                self._queue.put(("log", f"Scan lanzado. scanResultID={scan_result_id}"))
                if debug:
                    self._queue.put(("log", f"    [DEBUG] respuesta cruda lanzar_scan: {json.dumps(lanzado, ensure_ascii=False)[:1500]}"))

                db.registrar_scan_lanzado(nombre, ips, policy_id, repository_id, zone_id, scan_id, scan_result_id)
                self._queue.put(("historial_actualizado", None))

                if seguir and scan_result_id:
                    while True:
                        estado = sc.estado_resultado(scan_result_id)
                        status = estado.get("status")
                        self._queue.put(("log", f"  [{status}] {resumir_estado_scan(estado)}"))
                        if debug and status not in ("Running", "Queued", "Pending"):
                            self._queue.put(("log", f"    [DEBUG] scanResult crudo: {json.dumps(estado, ensure_ascii=False)[:2000]}"))
                        db.actualizar_estado_scan(scan_result_id, status)
                        if status in ("Completed", "Canceled", "Aborted", "Error"):
                            self._queue.put(("scan_finalizado", status))
                            self._queue.put(("historial_actualizado", None))
                            break
                        time.sleep(30)
            except Exception as e:
                pista = explicar_error_http(e)
                detalle = detalle_respuesta_http(e)
                mensaje = f"ERROR: {e}"
                if pista:
                    mensaje += f"\n    💡 {pista}"
                if detalle:
                    mensaje += f"\n    📄 Respuesta de Security Center: {detalle}"
                self._queue.put(("log", mensaje))
                self._queue.put(("scan_finalizado", "Error"))

        threading.Thread(target=trabajo, daemon=True).start()

    def _poll_queue(self):
        try:
            while True:
                kind, payload = self._queue.get_nowait()
                if kind == "log":
                    self._log(payload)
                elif kind == "catalogos":
                    politicas, repos, zonas = payload
                    self.politica_cb["values"] = [f"{p['id']} — {p['name']}" for p in politicas]
                    self.repo_cb["values"] = [
                        f"{r['id']} — {r['name']}" + (" [agente]" if es_repositorio_de_agente(r) else "")
                        for r in repos
                    ]
                    self.zona_cb["values"] = [""] + [f"{z['id']} — {z['name']}" for z in zonas]
                    self._zonas_cache = zonas
                    self._repos_por_id = {str(r["id"]): r for r in repos}
                    self._catalogos_cargados = True
                    self._cargando_catalogos = False
                    self.catalogos_status_lbl.config(
                        text=f"Catálogos: {len(politicas)} políticas, {len(repos)} repos, {len(zonas)} zonas",
                        foreground="#2e7d32",
                    )
                    self._log("Catálogos cargados. Los repositorios marcados [agente] son un best-effort (revisa el volcado abajo).")
                    self._log("[DEBUG] Repositorios crudos tal cual los devuelve Security Center:")
                    for r in repos:
                        marca = " <- marcado [agente]" if es_repositorio_de_agente(r) else ""
                        self._log(f"    {json.dumps(r, ensure_ascii=False)}{marca}")
                    self._detectar_zona()
                elif kind == "catalogos_error":
                    self._cargando_catalogos = False
                    self.catalogos_status_lbl.config(text="Catálogos: error al cargar", foreground="#b03a2e")
                    self._log(f"ERROR cargando catálogos: {payload}")
                elif kind == "scan_finalizado":
                    status = payload
                    simbolo = "✅" if status == "Completed" else "⚠️"
                    self._log(f"\n{simbolo} SCAN FINALIZADO — estado final: {status}\n")
                    self.estado_scan_lbl.config(
                        text=f"{simbolo} Último scan: {status}",
                        foreground="#2e7d32" if status == "Completed" else "#b03a2e",
                    )
                elif kind == "target_listo":
                    activo, scanner_id = payload
                    self._scanner_id_actual = scanner_id
                    etiqueta = f"{activo.get('id')} — {activo.get('name')}"
                    self.target_cb["values"] = [etiqueta]
                    self.target_cb.set(etiqueta)
                    texto_status = "listo" if scanner_id else "listo (sin Agent Scanner detectado)"
                    color_status = "#2e7d32" if scanner_id else "#b08600"
                    self.target_status_lbl.config(text=texto_status, foreground=color_status)
                    self.usar_grupo_var.set(True)
                elif kind == "target_error":
                    self.target_status_lbl.config(text="error", foreground="#b03a2e")
                elif kind == "grupo_status":
                    self.grupo_nm_status_lbl.config(text=payload, foreground="#b03a2e")
                elif kind == "grupo_no_detectado":
                    self.grupo_nm_status_lbl.config(text="Nessus Manager: no detectado", foreground="#b03a2e")
                    messagebox.showwarning("Grupo de agente", f"No se pudo detectar a qué Nessus Manager pertenece el host.\n\n{payload}")
                elif kind == "grupo_sin_llaves":
                    self.grupo_nm_status_lbl.config(text=f"Nessus Manager: {payload} — sin llaves", foreground="#b03a2e")
                    messagebox.showwarning(
                        "Grupo de agente",
                        f"Se detectó Nessus Manager '{payload}' pero no tiene llaves configuradas (pestaña Configuración).",
                    )
                elif kind == "grupo_busqueda":
                    cliente_nm, patron, objetivo, candidatos, grupos, agentes = payload
                    self._continuar_preparacion_grupo(cliente_nm, patron, objetivo, candidatos, grupos, agentes)
                elif kind == "grupo_creado":
                    cliente_nm, grupo, objetivo, candidatos, agentes = payload
                    self._log(f"[Grupo] Grupo creado: '{grupo.get('name')}' (id={grupo.get('id')})")
                    self._continuar_con_agente(cliente_nm, grupo, objetivo, candidatos, agentes)
                elif kind == "activos_sc":
                    activos = payload
                    self.activo_cb["values"] = [f"{a.get('id')} — {a.get('name')}" for a in activos]
                    self._activos_por_id = {str(a.get("id")): a for a in activos}
                    self._log(f"[Activos SC] {len(activos)} activos cargados. Son grupos/dashboards genéricos de SC -- no busques que coincidan con un host puntual.")
                    # Nunca dejar un valor previo/heredado (p.ej. el primer item de la lista)
                    # seleccionado a ciegas -- eso fue justo lo que causó lanzar contra
                    # "All Defined Ranges" por accidente.
                    self.activo_cb.set("")
                elif kind == "host_asset_resultado":
                    resultados = payload
                    if not resultados:
                        self.host_asset_cb["values"] = []
                        self.host_asset_status_lbl.config(text="sin coincidencias", foreground="#b03a2e")
                        self._log("[Host Asset] Sin coincidencias en el inventario de Security Center (esto es solo informativo).")
                    else:
                        etiquetas = []
                        self._host_assets_por_id = {}
                        for h in resultados:
                            # hostUUID es el "Host ID" real que muestra la interfaz de SC; 'uuid' es un campo
                            # distinto que SC rechazó como target de scan ("Asset ... does not exist") -- este
                            # combo es solo informativo, no se usa para lanzar.
                            hid = str(h.get("hostUUID") or h.get("uuid") or "")
                            repo = (h.get("repository") or {}).get("name", "")
                            etiqueta = f"{hid} — {h.get('ip', '')} ({h.get('dnsName') or h.get('netbiosName') or 'sin nombre'}, repo={repo})"
                            etiquetas.append(etiqueta)
                            self._host_assets_por_id[hid] = h
                        self.host_asset_cb["values"] = etiquetas
                        self.host_asset_cb.set(etiquetas[0])
                        self.host_asset_status_lbl.config(text=f"{len(resultados)} encontrado(s) (informativo)", foreground="#2e7d32")
                        self._log(
                            f"[Host Asset] {len(resultados)} coincidencia(s) en el inventario de SC (solo para "
                            "verificar que el host existe -- Security Center rechaza esto como target real de "
                            "un scan; usa 'Preparar target y usar al lanzar' arriba)."
                        )
                elif kind == "host_asset_error":
                    self.host_asset_status_lbl.config(text="error", foreground="#b03a2e")
                elif kind == "grupo_agente_agregado":
                    self._log(f"[Grupo] Listo — agente agregado a '{self._grupo_actual.get('name') if self._grupo_actual else ''}'.")
                elif kind == "historial_actualizado" and self._on_scan_registrado:
                    self._on_scan_registrado()
        except queue.Empty:
            pass
        self.after(150, self._poll_queue)


# ---------------------------------------------------------------------------
# Pestaña Historial
# ---------------------------------------------------------------------------
class HistorialTab(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent, padding=10)
        top = ttk.Frame(self)
        top.pack(fill="x")
        ttk.Button(top, text="Actualizar", command=self._refrescar).pack(side="left")

        cols = ("id", "nombre", "ips", "estado", "sc_scan_id", "lanzado_at")
        headers = ("ID", "Nombre", "IPs", "Estado", "SC scan id", "Lanzado")
        self.tree = ttk.Treeview(self, columns=cols, show="headings", height=20)
        for c, h, w in zip(cols, headers, (40, 200, 220, 100, 90, 180)):
            self.tree.heading(c, text=h)
            self.tree.column(c, width=w)
        self.tree.pack(fill="both", expand=True, pady=(10, 0))

        self._refrescar()

    def on_show(self):
        self._refrescar()

    def _refrescar(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        for r in db.listar_historial():
            self.tree.insert(
                "", "end", values=(r["id"], r["nombre"], r["ips"], r["estado"], r["sc_scan_id"], r["lanzado_at"])
            )


# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Tenable SC Scanner")
        self.geometry("1000x700")
        self._maximizar()

        db.init_db()

        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True, padx=8, pady=8)

        # tab_historial y tab_scan se crean primero porque tab_config necesita
        # poder avisarle a tab_scan cuando se guardan llaves nuevas.
        self.tab_historial = HistorialTab(nb)
        self.tab_scan = ScanTab(nb, on_scan_registrado=self.tab_historial.on_show)
        self.tab_config = ConfigTab(nb, on_guardado=self.tab_scan.invalidar_catalogos)
        self.tab_buscar = BuscarTab(nb)

        nb.add(self.tab_config, text="Configuración")
        nb.add(self.tab_buscar, text="Buscar")
        nb.add(self.tab_scan, text="Lanzar Scan")
        nb.add(self.tab_historial, text="Historial")

        nb.bind("<<NotebookTabChanged>>", self._on_tab_changed)

    def _maximizar(self):
        """
        Abre la ventana maximizada (pantalla completa, con barra de título).

        En Windows, self.state('zoomed') es confiable. En Linux/Mac se intenta
        el atributo '-zoomed', pero algunos entornos sin gestor de ventanas
        (o gestores minimalistas) lo ignoran EN SILENCIO -- sin lanzar
        TclError -- y la ventana se queda en su tamaño chico. Por eso, en vez
        de confiar únicamente en el try/except, se verifica el resultado real
        y si la ventana sigue del tamaño original se fuerza la geometría al
        tamaño de pantalla como respaldo.
        """
        ancho_inicial, alto_inicial = 1000, 700
        try:
            if platform.system() == "Windows":
                self.state("zoomed")
            else:
                self.attributes("-zoomed", True)
        except tk.TclError:
            pass

        self.update_idletasks()
        if self.winfo_width() <= ancho_inicial and self.winfo_height() <= alto_inicial:
            w = self.winfo_screenwidth()
            h = self.winfo_screenheight()
            self.geometry(f"{w}x{h}+0+0")

    def _on_tab_changed(self, event):
        nb = event.widget
        tab = nb.nametowidget(nb.select())
        if hasattr(tab, "on_show"):
            tab.on_show()


if __name__ == "__main__":
    App().mainloop()
