from __future__ import annotations



class _ApiTabMixin:
    def _build_tab_api(self, parent):
        self._section_header(parent, '🔌  Seguridad de APIs')
        pad = self._scrollable(parent)
        self._safety_banner(pad,
            "Esta pestaña envía solicitudes HTTP reales a cada operación de la especificación — "
            "incluyendo POST/PUT/DELETE con datos de prueba — a la URL base configurada. "
            "Confirme que apunta a un entorno que NO sea producción antes de ejecutar un escaneo.")
        body = self._card(pad, 'ESPECIFICACIÓN Y OBJETIVO'); body.columnconfigure(1, weight=1); body.columnconfigure(3, weight=1)
        def gl(text, r, c): return self._glabel(body, text, r, c)
        gl('Especificación (URL o archivo)', 0, 0); self._gentry(body, self._api_spec_var, 0, 1, span=2)
        self._btn(body, 'Explorar…', self._browse_api_spec, kind="flat").grid(row=0, column=3, sticky="w", padx=(4, 0))
        gl('URL base personalizada', 1, 0); self._gentry(body, self._api_base_var, 1, 1, span=3)
        gl('Tipo de autenticación', 2, 0)
        api_ac = ttk.Combobox(body, textvariable=self._api_auth_var, values=["none","basic","bearer","cookie","header"],
                              state="readonly", width=10)
        api_ac.grid(row=2, column=1, sticky="w", pady=3)
        api_ac.bind("<<ComboboxSelected>>", lambda _: self._refresh_api_creds())
        gl('Perfil', 3, 0)
        api_pc = ttk.Combobox(body, textvariable=self._api_profile_var, values=["passive","active"], state="readonly", width=10)
        api_pc.grid(row=3, column=1, sticky="w", pady=3)
        self._api_cred_frame = tk.Frame(body, bg=T["panel_bg"])
        self._api_cred_frame.grid(row=4, column=0, columnspan=4, sticky="ew", pady=(4, 0))
        self._api_cred_frame.columnconfigure(1, weight=1)
        scope = tk.Frame(body, bg=T["panel_bg"]); scope.grid(row=5, column=0, columnspan=4, sticky="ew", pady=(8, 0))
        self._spin(scope, 'Máx. endpoints', self._api_pages_var, 1, 1000, padx=(0, 14))
        ttk.Checkbutton(scope, text="Verificar TLS", variable=self._api_tls_var).pack(side="left", padx=(0, 14))
        self._spin(scope, 'Tasa (req/s)', self._api_rps_var, 0.5, 100, inc=0.5)
        self._lbl(scope, 'Trabajadores', size=10, fg=T["muted"]).pack(side="left", padx=(14, 4))
        self._spin(scope, "", self._api_workers_var, 1, 16, width=4)
        adv = tk.Frame(body, bg=T["panel_bg"]); adv.grid(row=6, column=0, columnspan=4, sticky="ew", pady=(6, 0))
        adv.columnconfigure(1, weight=2); adv.columnconfigure(4, weight=1)
        self._lbl(adv, 'Regex de exclusión', size=10, fg=T["muted"]).grid(row=0, column=0, sticky="w", padx=(0, 6))
        self._gentry(adv, self._api_exclude_var, 0, 1, span=2)
        self._lbl(adv, 'Proxy HTTP', size=10, fg=T["muted"]).grid(row=0, column=3, sticky="w", padx=(8, 6))
        self._gentry(adv, self._api_proxy_var, 0, 4)
        conv_card = self._card(pad, 'CONVERSOR Y VISTA PREVIA DE ENDPOINTS', pady=(0, 14))
        btn_row_conv = tk.Frame(conv_card, bg=T["panel_bg"]); btn_row_conv.pack(fill="x", pady=(0, 6))
        self._btn(btn_row_conv, '🔍 Vista previa', self._api_preview_spec, kind="accent").pack(side="left")
        self._btn(btn_row_conv, '📥 Importar…', self._api_import_popup, kind="flat").pack(side="left", padx=(8, 0))
        self._btn(btn_row_conv, "💾 Exportar…", self._api_export_popup, kind="flat").pack(side="left", padx=(8, 0))
        tree_wrap = tk.Frame(conv_card, bg=T["panel_bg"]); tree_wrap.pack(fill="both", expand=True)
        self._ep_tree = _make_tree(tree_wrap, ("method","url","secured","body"),
                                   [("Método",70),("URL del endpoint",480),("Auth req.",70),("Tipo de cuerpo",120)], height=10)
        self._ep_count_lbl = self._lbl(conv_card, "", size=10, fg=T["muted"]); self._ep_count_lbl.pack(anchor="w", pady=(4, 0))
        self._refresh_api_creds()
        self._setup_api_field_persistence()

    def _refresh_api_creds(self):
        self._refresh_creds(self._api_cred_frame, self._api_auth_var, self._api_cred_vars)

    def _browse_api_spec(self):
        p = filedialog.askopenfilename(title="Seleccionar especificación de API",
            filetypes=[("Archivos de especificación","*.json *.yaml *.yml"),("Todos","*.*")])
        if p: self._api_spec_var.set(p)

    def _api_load_spec_file(self, title: str, filetypes: list, log_label: str):
        p = filedialog.askopenfilename(title=title, filetypes=filetypes)
        if p:
            self._api_spec_var.set(p); self._emit_log(f"[api] cargado {log_label}: {p}"); self._api_preview_spec()

    def _api_import_postman(self):
        self._api_load_spec_file("Importar colección Postman",
            [("Colección Postman", "*.json"), ("Todos", "*.*")], "Colección Postman")

    def _api_import_openapi(self):
        self._api_load_spec_file("Importar especificación OpenAPI / Swagger",
            [("OpenAPI/Swagger", "*.json *.yaml *.yml"), ("Todos", "*.*")], "especificación OpenAPI/Swagger")

    def _api_import_popup(self):
        popup = self._create_popup("Importar especificación")
        self._popup_hdr(popup, "Importar especificación", icon="📥")
        body = tk.Frame(popup, bg=T["bg"]); body.pack(fill="both", expand=True)
        tk.Frame(body, bg=T["bg"]).pack(fill="both", expand=True)
        tk.Label(body, text="Elija el formato a importar:", font=(_FUI, 13), bg=T["bg"], fg=T["muted"]).pack(pady=(0, 28))
        card_row = tk.Frame(body, bg=T["bg"]); card_row.pack(padx=80)
        tk.Frame(body, bg=T["bg"]).pack(fill="both", expand=True)
        def _pick(kind):
            popup.close()
            (self._api_import_postman if kind == "postman" else self._api_import_openapi)()
        for icon_txt, label, desc, kind in [
            ("📦", "Colección Postman", "Importar una colección Postman v2.1 (.json)", "postman"),
            ("📄", "Swagger / OpenAPI", "Importar una especificación OpenAPI v2/v3 o Swagger\n(.json o .yaml)", "openapi"),
        ]:
            card = self._choice_card(card_row, icon_txt, label, desc, ipadx=28, ipady=22, padx=20, desc_pady=(6, 20))
            def _mk_click(k=kind):
                def _fn(e=None): _pick(k)
                return _fn
            click_fn = _mk_click(); card.bind("<Button-1>", click_fn)
            for child in card.winfo_children(): child.bind("<Button-1>", click_fn)
            card.bind("<Enter>", lambda e, c=card: c.configure(highlightbackground=T["accent"]))
            card.bind("<Leave>", lambda e, c=card: c.configure(highlightbackground=T["border"]))
        self._popup_foot(popup, ("  Cancelar  ", popup.close, "flat"))

    def _api_export_popup(self):
        rows = self._ep_tree.get_children()
        if not rows:
            self._show_warn_popup("Exportar endpoints", "Sin endpoints — ejecute Vista previa primero."); return
        ops = [{"method": self._ep_tree.set(iid, "method"), "url": self._ep_tree.set(iid, "url"),
                "secured": self._ep_tree.set(iid, "secured"), "body": self._ep_tree.set(iid, "body")} for iid in rows]
        popup = self._create_popup("Exportar endpoints")
        self._popup_hdr(popup, "Exportar endpoints", icon="💾", subtitle=f"{len(ops)} endpoint(s)")
        body = tk.Frame(popup, bg=T["bg"]); body.pack(fill="both", expand=True)
        tk.Frame(body, bg=T["bg"]).pack(fill="both", expand=True)
        tk.Label(body, text="Elija el formato de exportación:", font=(_FUI, 13), bg=T["bg"], fg=T["muted"]).pack(pady=(0, 20))
        card_row = tk.Frame(body, bg=T["bg"]); card_row.pack(padx=60)
        tk.Frame(body, bg=T["bg"]).pack(fill="both", expand=True)
        fmt_var = tk.StringVar(value="CSV"); _cards = {}
        _FORMAT_META = [
            ("CSV", "📊", "Valores separados por comas\nExcel / Sheets"),
            ("JSON", "📋", "Arreglo JSON sin formato\nScripts / APIs"),
            ("YAML", "📄", "Formato YAML\nHerramientas OpenAPI"),
            ("Postman v2.1", "📦", "Colección Postman v2.1\nImportación directa en Postman"),
        ]
        def _refresh_cards(*_):
            for f, c in _cards.items():
                c.configure(highlightbackground=T["accent"] if f == fmt_var.get() else T["border"])
        for fmt, icon_txt, desc in _FORMAT_META:
            card = self._choice_card(card_row, icon_txt, fmt, desc, title_size=13, ipadx=20, ipady=14, padx=12, desc_pady=(6, 18))
            _cards[fmt] = card
            def _mk_click(f=fmt):
                def _click(e=None): fmt_var.set(f)
                return _click
            click_fn = _mk_click(); card.bind("<Button-1>", click_fn)
            for child in card.winfo_children(): child.bind("<Button-1>", click_fn)
            def _enter(e, c=card, f=fmt):
                if f != fmt_var.get(): c.configure(highlightbackground=T["accent_hi"])
            card.bind("<Enter>", _enter)
            card.bind("<Leave>", lambda e: _refresh_cards())
        fmt_var.trace_add("write", _refresh_cards); _refresh_cards()
        def _do_export():
            fmt = fmt_var.get(); popup.close(); self._api_export_converted_with(ops, fmt)
        self._popup_foot(popup, ("  Cancelar  ", popup.close, "flat"), ("💾  Exportar  ", _do_export, "accent"))

    def _api_preview_spec(self):
        src = self._api_spec_var.get().strip()
        if not src:
            self._show_warn_popup("Vista previa", "Configure una especificación primero."); return
        def _load_and_render():
            cfg = self._collect_api_cfg()
            opener, _, hdrs = _make_opener(cfg)
            spec = _api_load_spec(opener, hdrs, cfg, self._emit_log)
            if not spec or not isinstance(spec, dict):
                self._event_queue.put(("log","[api-preview] no se pudo cargar o parsear la especificación.")); return
            if "item" in spec and "paths" not in spec: fmt = "Colección Postman"
            elif spec.get("openapi","").startswith("3"): fmt = f"OpenAPI {spec.get('openapi','3.x')}"
            elif spec.get("swagger","").startswith("2"): fmt = f"Swagger {spec.get('swagger','2.x')}"
            else: fmt = "Formato desconocido"
            base = _api_base_url(spec, cfg, src)
            ops = _api_operations(spec, base or "https://example.com", src)
            self._event_queue.put(("api_preview", (fmt, ops, len(ops))))
        self._run_async(_load_and_render, label="vista previa de especificación")

    def _api_export_converted_with(self, ops, fmt):
        if fmt == "CSV":
            path = filedialog.asksaveasfilename(title="Exportar endpoints como CSV", defaultextension=".csv",
                initialfile="endpoints.csv", filetypes=[("CSV","*.csv"),("Todos","*.*")])
            if not path: return
            import csv
            with open(path,"w",newline="",encoding="utf-8") as f:
                w = csv.DictWriter(f, fieldnames=["method","url","secured","body"]); w.writeheader(); w.writerows(ops)
        elif fmt == "JSON":
            path = filedialog.asksaveasfilename(title="Exportar endpoints como JSON", defaultextension=".json",
                initialfile="endpoints.json", filetypes=[("JSON","*.json"),("Todos","*.*")])
            if not path: return
            Path(path).write_text(json.dumps(ops, indent=2), encoding="utf-8")
        elif fmt == "YAML":
            path = filedialog.asksaveasfilename(title="Exportar endpoints como YAML", defaultextension=".yaml",
                initialfile="endpoints.yaml", filetypes=[("YAML","*.yaml *.yml"),("Todos","*.*")])
            if not path: return
            lines = ["endpoints:\n"]
            for op in ops:
                lines += [f"  - method: {op['method']}\n", f"    url: '{op['url']}'\n",
                          f"    secured: '{op['secured']}'\n", f"    body: '{op['body']}'\n"]
            Path(path).write_text("".join(lines), encoding="utf-8")
        elif fmt == "Postman v2.1":
            path = filedialog.asksaveasfilename(title="Exportar como Colección Postman v2.1", defaultextension=".json",
                initialfile="endpoints_postman.json", filetypes=[("JSON / Postman","*.json"),("Todos","*.*")])
            if not path: return
            items = []
            for op in ops:
                url_parts = op["url"].split("://",1); raw_url = op["url"]
                items.append({"name": f"{op['method']} {raw_url}",
                              "request": {"method": op["method"], "header": [],
                                          "url": {"raw": raw_url,
                                                  "protocol": url_parts[0] if len(url_parts)>1 else "https",
                                                  "host": (url_parts[1].split("/")[0].split(".") if len(url_parts)>1 else []),
                                                  "path": (url_parts[1].split("/")[1:] if len(url_parts)>1 else [])},
                                          "description": f"Auth requerida: {op['secured']}  Tipo de cuerpo: {op['body']}"},
                              "response": []})
            collection = {"info": {"name":"Endpoints exportados",
                                   "schema":"https://schema.getpostman.com/json/collection/v2.1.0/collection.json"},
                          "item": items}
            Path(path).write_text(json.dumps(collection, indent=2), encoding="utf-8")
        else:
            self._show_warn_popup("Exportar endpoints", f"Formato desconocido: {fmt}"); return
        self._log_line(f"[api-export] {fmt} → {path}")
        self._show_info_popup("Exportación completada", f"Se guardaron {len(ops)} endpoint(s) en:\n{path}")

    def _collect_api_cfg(self) -> ApiConfig:
        v = self._api_cred_vars
        return ApiConfig(
            spec_source=self._api_spec_var.get().strip(), base_url=self._api_base_var.get().strip(),
            auth_type=self._api_auth_var.get(), username=v["username"].get(), password=v["password"].get(),
            token=v["token"].get(), cookie=v["cookie"].get(), header_name=v["header_name"].get(),
            header_value=v["header_value"].get(), profile=self._api_profile_var.get(),
            max_endpoints=int(self._api_pages_var.get() or 80), verify_tls=bool(self._api_tls_var.get()),
            rate_limit_rps=float(self._api_rps_var.get() or 8.0), concurrency=int(self._api_workers_var.get() or 6),
            proxy=self._api_proxy_var.get(), exclude_re=self._api_exclude_var.get())

    def _setup_api_field_persistence(self):
        delay = [None]
        def _on_change(*_):
            if delay[0] is not None:
                try: self.after_cancel(delay[0])
                except Exception: pass
            delay[0] = self.after(800, self._save_settings)
        for v in [self._api_spec_var, self._api_base_var, self._api_auth_var,
                  self._api_profile_var, self._api_pages_var, self._api_tls_var,
                  self._api_rps_var, self._api_workers_var, self._api_proxy_var,
                  self._api_exclude_var]:
            try: v.trace_add("write", _on_change)
            except Exception: pass
        for k, v in self._api_cred_vars.items():
            if k not in self._SECRET_KEYS:
                try: v.trace_add("write", _on_change)
                except Exception: pass

    def _restore_api_fields(self):
        saved = getattr(self, "_saved_api_fields", None)
        if not isinstance(saved, dict): return
        try:
            if saved.get("spec"):         self._api_spec_var.set(saved["spec"])
            if "base"     in saved:       self._api_base_var.set(saved["base"])
            if saved.get("auth"):         self._api_auth_var.set(saved["auth"])
            if saved.get("profile"):      self._api_profile_var.set(saved["profile"])
            if "pages"    in saved:       self._api_pages_var.set(int(saved["pages"]))
            if "tls"      in saved:       self._api_tls_var.set(bool(saved["tls"]))
            if "rps"      in saved:       self._api_rps_var.set(float(saved["rps"]))
            if "workers"  in saved:       self._api_workers_var.set(int(saved["workers"]))
            if "proxy"    in saved:       self._api_proxy_var.set(saved["proxy"])
            if "exclude"  in saved:       self._api_exclude_var.set(saved["exclude"])
            for k, val in (saved.get("creds") or {}).items():
                if k in self._api_cred_vars and k not in self._SECRET_KEYS:
                    self._api_cred_vars[k].set(str(val))
        except Exception:
            pass
