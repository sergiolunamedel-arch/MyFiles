from __future__ import annotations



class _AppsTabMixin:
    def _build_tab_apps(self, parent):
        from app_inventory import AppInventoryTab
        self._inv_tab = AppInventoryTab(parent=parent, master=self, store=self._inv_store,
                                        on_load_app=self._load_app_profile)

    def _load_app_profile(self, app: dict, *, silent: bool = False) -> None:
        self._active_app = app
        if app.get("target_path"): self._target_var.set(app["target_path"])
        if app.get("dast_url"): self._dast_url_var.set(app["dast_url"])
        if app.get("api_spec"): self._api_spec_var.set(app["api_spec"])
        for k, var in self._scan_vars.items():
            var.set(k in app.get("scan_stages", ["sca", "code"]))
        if hasattr(self, "_static_paths_lb"):
            self._static_paths_lb.delete(0, "end")
            for p in app.get("static_paths") or ([app["target_path"]] if app.get("target_path") else []):
                self._static_paths_lb.insert("end", p)
        self._refresh_stage_cards()
        self._refresh_scan_btn()
        self._refresh_active_app_banner()
        self._update_window_title()
        self._last_app_id = app.get("id")
        self._save_settings()
        if silent:
            return
        self._show_tab("scan")
        self._show_info_popup("Perfil de aplicación cargado",
            f"Nombre: {app['name']}\n"
            f"Descripción: {app.get('description') or '(no configurado)'}\n"
            f"Tipo: {app.get('app_type') or '(no configurado)'}\n"
            f"Criticidad de negocio: {app.get('criticality') or '(no configurado)'}\n"
            f"URL: {app.get('dast_url') or '(no configurado)'}")

    def _update_window_title(self) -> None:
        app = getattr(self, "_active_app", None)
        name = app.get("name") if app else None
        self.title(f"{APP_BRAND_NAME} - ({name})" if name else APP_BRAND_NAME)

    def _auto_load_last_app(self) -> None:
        app_id = getattr(self, "_last_app_id", None)
        if not app_id:
            self._update_window_title(); return
        try:
            app = self._inv_store.get_app(app_id)
        except Exception:
            app = None
        if app:
            self._load_app_profile(app, silent=True)
            self._log_line(f"[apps] perfil recargado automáticamente: {app.get('name')}")
        else:
            self._update_window_title()

    def _refresh_active_app_banner(self) -> None:
        lbl = getattr(self, "_active_app_lbl", None)
        app = getattr(self, "_active_app", None)
        if lbl:
            if not app:
                lbl.config(text="Ninguna — vaya a 📦 Aplicaciones para cargar un perfil", fg=T["muted"])
            else:
                try:
                    tier = app.get("risk_tier", "Ninguno")
                    from app_inventory import _RISK_COLORS_LIGHT
                    colour = _RISK_COLORS_LIGHT.get(tier, T["accent"])
                    ctx = getattr(self, "_last_context", None)
                    if ctx:
                        c = ctx.get("counts", {})
                        crit = c.get("critical", app.get("vuln_critical", 0))
                        high = c.get("high", app.get("vuln_high", 0))
                        med  = c.get("medium", app.get("vuln_medium", 0))
                        low  = c.get("low", app.get("vuln_low", 0))
                    else:
                        crit = app.get("vuln_critical", 0); high = app.get("vuln_high", 0)
                        med  = app.get("vuln_medium", 0);  low  = app.get("vuln_low", 0)
                    lbl.config(text=f"{app['name']}  ·  {app.get('criticality', '')}  ·  Riesgo: {tier}  ·  "
                                    f"C:{crit} A:{high} M:{med} B:{low}", fg=colour)
                except Exception:
                    lbl.config(text=app.get("name", ""), fg=T["accent"])

        chip_lbl    = getattr(self, "_app_chip_lbl", None)
        chip_counts = getattr(self, "_app_chip_counts", None)
        chip_frame  = getattr(self, "_app_chip_frame", None)
        if not chip_lbl:
            return
        if not app:
            chip_lbl.config(text="Sin aplicación cargada", fg=T["muted"])
            if chip_counts: chip_counts.config(text="")
            return
        try:
            chip_lbl.config(text=app.get("name", "?"), fg=T["text"])
            ctx = getattr(self, "_last_context", None)
            if ctx:
                c    = ctx.get("counts", {})
                crit = c.get("critical", app.get("vuln_critical", 0))
                high = c.get("high",     app.get("vuln_high", 0))
                med  = c.get("medium",   app.get("vuln_medium", 0))
                low  = c.get("low",      app.get("vuln_low", 0))
            else:
                crit = app.get("vuln_critical", 0); high = app.get("vuln_high", 0)
                med  = app.get("vuln_medium", 0);  low  = app.get("vuln_low", 0)
            if chip_counts:
                chip_counts.config(
                    text=f"  C:{crit}  A:{high}  M:{med}  B:{low}",
                    fg=T["muted"] if (crit == 0 and high == 0) else T["accent"]
                )
        except Exception:
            try: chip_lbl.config(text=app.get("name", ""), fg=T["text"])
            except Exception: pass
