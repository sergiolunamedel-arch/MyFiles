"""Instalación y verificación de los motores de código abierto (descarga automática, sin Docker ni permisos de admin).

Motores: Nuclei (web/API), OWASP ZAP + Java portátil (web/API), Trivy (contenedores + IaC), Checkov (IaC),
git-secrets (secretos en el código y el historial de git; corre con el Git Bash de Git para Windows).

Seguridad de la cadena de suministro:
  · Versiones fijadas (PINNED). El administrador puede cambiarlas en admin_policy.json → tools.versions.
  · Cada descarga se verifica con SHA-256: el «digest» que GitHub publica por asset, el archivo de checksums del
    proyecto, el checksum de la API de Adoptium o, para git-secrets (que no publica checksums), el hash fijado
    en este archivo. Si no hay forma de verificar, la instalación se rechaza.
  · Versiones comprometidas conocidas se bloquean siempre (Trivy 0.69.4–0.69.6, incidente de marzo de 2026).
  · Los zip se extraen con validación de rutas (sin path traversal).

Red corporativa (mismo criterio que el arranque):
  1) espejo interno si el admin lo configuró (tools.mirror_base) — para sitios bloqueados;
  2) HTTPS normal (en Windows, Python confía en el almacén de certificados del sistema → proxy TLS corporativo);
  3) si falla la verificación TLS: reintento sin verificar SOLO para el binario, que igual debe pasar el SHA-256;
  4) winget (origen «winget», nunca msstore) como alternativa para Trivy, ZAP y Java.
"""
from __future__ import annotations

import hashlib
import io
import ssl
import time
import urllib.error
import urllib.request
from urllib.parse import urlparse
import zipfile
from dataclasses import dataclass, field

from ui_common import *

PINNED = {"nuclei": "3.11.0", "zap": "2.17.0", "trivy": "0.76.1", "jre": "21", "checkov": "3.2", "gitsecrets": "1.3.0"}
MIN_VERSION = {"nuclei": "3.10.0"}  # 3.10.0 corrige CVE-2026-76805 (fuga de variables de entorno en modo DAST)
BLOCKED = {"trivy": {"0.69.4", "0.69.5", "0.69.6"}}
LABELS = {"nuclei": "Nuclei", "zap": "OWASP ZAP", "jre": "Java (Temurin JRE)", "trivy": "Trivy", "checkov": "Checkov",
          "gitsecrets": "git-secrets"}
PURPOSE = {"nuclei": "Web y API — plantillas de vulnerabilidades conocidas",
           "zap": "Web y API — rastreo y escaneo activo (OWASP)",
           "jre": "Requerido por ZAP",
           "trivy": "Contenedores e IaC — CVE, secretos y configuración",
           "checkov": "IaC — Terraform, Kubernetes, Helm, CloudFormation, ARM",
           "gitsecrets": "Secretos — credenciales en el código y en el historial de git"}
NEEDS = {"zap": ("jre",)}
STAGE_TOOLS = {"dast": ("nuclei", "zap"), "api": ("nuclei", "zap"), "container": ("trivy",), "iac": ("checkov", "trivy"),
               "secrets": ("gitsecrets",)}
ORDER = ("nuclei", "zap", "jre", "trivy", "checkov", "gitsecrets")          # orden de presentación
INSTALLABLE = ("nuclei", "zap", "trivy", "checkov", "gitsecrets")           # lo que instala «Preparar todos»
# git-secrets no publica checksums: el SHA-256 del script de cada versión aprobada se fija aquí.
_GITSECRETS_SHA = {"1.3.0": "df9a5d2beeda1c83e23105f46efe464bb4c97f8328e1e66754d7daacfaf7272b"}
_GITSECRETS_URL = "https://raw.githubusercontent.com/awslabs/git-secrets/{v}/git-secrets"
_REPO = {"nuclei": "projectdiscovery/nuclei", "zap": "zaproxy/zaproxy", "trivy": "aquasecurity/trivy"}
_ASSET = {"nuclei": "nuclei_{v}_windows_amd64.zip", "zap": "ZAP_{v}_Crossplatform.zip",
          "trivy": "trivy_{v}_windows-64bit.zip"}
_CHECKSUMS = {"nuclei": "nuclei_{v}_checksums.txt", "trivy": "trivy_{v}_checksums.txt"}
_WINGET = {"trivy": "AquaSecurity.Trivy", "zap": "ZAP.ZAP", "jre": "EclipseAdoptium.Temurin.21.JRE"}
MANIFEST = TOOLS_DIR / "manifest.json"
_LOCKS: dict[str, threading.Lock] = {k: threading.Lock() for k in LABELS}
_MANIFEST_LOCK = threading.Lock()
UA = {"User-Agent": "BBScanner/0.8 (tool-manager)", "Accept": "application/vnd.github+json"}


class ToolError(RuntimeError):
    pass


@dataclass
class ToolStatus:
    key: str
    label: str
    installed: bool = False
    version: str = ""
    path: str = ""
    source: str = ""
    detail: str = ""
    deps: list = field(default_factory=list)


# ── Política y manifiesto ────────────────────────────────────────────────────
def _policy_tools() -> dict:
    try:
        import admin_policy
        return admin_policy.load().get("tools") or {}
    except Exception:
        return {}


def wanted_version(key: str) -> str:
    v = str((_policy_tools().get("versions") or {}).get(key) or PINNED[key]).lstrip("v")
    if v in BLOCKED.get(key, set()):
        raise ToolError(f"{LABELS[key]} {v} está bloqueada (versión comprometida conocida). Elija otra en Administración.")
    return v


def _manifest() -> dict:
    return read_json(MANIFEST, {}) or {}


def _save_manifest(key: str, entry: Optional[dict]) -> None:
    with _MANIFEST_LOCK:
        m = _manifest()
        if entry is None:
            m.pop(key, None)
        else:
            m[key] = {**entry, "installed_at": now_human()}
        write_json(MANIFEST, m)


def touch(key: str, field_name: str) -> None:
    with _MANIFEST_LOCK:
        m = _manifest()
        m.setdefault(key, {})[field_name] = time.time()
        write_json(MANIFEST, m)


def stamp(key: str, field_name: str) -> float:
    return float((_manifest().get(key) or {}).get(field_name) or 0)


def _vtuple(v: str) -> tuple:
    return tuple(int(x) for x in re.findall(r"\d+", v or "")[:3]) or (0,)


# ── Red ──────────────────────────────────────────────────────────────────────
def _open(url: str, *, insecure=False, timeout=60, accept=None):
    ctx = ssl.create_default_context()
    if insecure:
        ctx.check_hostname, ctx.verify_mode = False, ssl.CERT_NONE
    hdrs = dict(UA)
    if accept:
        hdrs["Accept"] = accept
    opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx))
    return opener.open(urllib.request.Request(url, headers=hdrs), timeout=timeout)


def _is_tls_error(e: Exception) -> bool:
    return isinstance(getattr(e, "reason", e), ssl.SSLError) or "CERTIFICATE_VERIFY_FAILED" in repr(e)


def http_bytes(url: str, log, *, allow_insecure: bool, timeout=60, accept=None, progress=None) -> tuple[bytes, bool]:
    """Devuelve (contenido, verificado_tls). Solo reintenta sin TLS si allow_insecure (el llamador verifica SHA-256)."""
    def read(r):
        total, buf, done = int(r.headers.get("Content-Length") or 0), io.BytesIO(), 0
        while chunk := r.read(1 << 16):
            buf.write(chunk)
            done += len(chunk)
            if progress and total:
                progress(done, total)
        return buf.getvalue()
    try:
        with _open(url, timeout=timeout, accept=accept) as r:
            return read(r), True
    except urllib.error.URLError as e:
        if not (allow_insecure and _is_tls_error(e)):
            raise
        log(f"[motores] verificación TLS falló contra {urlparse(url).netloc} (proxy corporativo); "
            "reintento sin verificar — el archivo igual debe coincidir con su SHA-256 publicado.")
        with _open(url, insecure=True, timeout=timeout, accept=accept) as r:
            return read(r), False


def _gh_release(key: str, version: str, log) -> dict:
    url = f"https://api.github.com/repos/{_REPO[key]}/releases/tags/v{version}"
    try:
        data, _ = http_bytes(url, log, allow_insecure=True, timeout=30)
        return json.loads(data)
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise ToolError(f"{LABELS[key]} v{version} no existe en GitHub — revise la versión en Administración.")
        raise ToolError(f"GitHub respondió HTTP {e.code} al consultar {LABELS[key]} (¿límite de la API o proxy?).")
    except Exception as e:
        raise ToolError(f"No se pudo consultar GitHub para {LABELS[key]}: {e!r}")


def _checksum_from_file(key: str, version: str, rel: dict, asset: str, log) -> str:
    name = _CHECKSUMS.get(key, "").format(v=version)
    a = next((x for x in rel.get("assets") or [] if x.get("name") == name), None)
    if not a:
        return ""
    try:
        txt = http_bytes(a["browser_download_url"], log, allow_insecure=True, timeout=30)[0].decode("utf-8", "replace")
    except Exception:
        return ""
    return next((ln.split()[0].lower() for ln in txt.splitlines() if ln.strip().endswith(asset)), "")


def _download_verified(key: str, url: str, sha256: str, log, progress=None, mirror_name: str = "") -> tuple[bytes, str]:
    mirror = (_policy_tools().get("mirror_base") or "").rstrip("/")
    tries = ([(f"{mirror}/{mirror_name}", "espejo interno")] if mirror and mirror_name else []) + [(url, "origen oficial")]
    last = None
    for u, label in tries:
        try:
            log(f"[motores] descargando {LABELS[key]} desde {label}…")
            data, _ = http_bytes(u, log, allow_insecure=True, timeout=600, accept="application/octet-stream",
                                 progress=progress)
            got = hashlib.sha256(data).hexdigest()
            if sha256 and got.lower() != sha256.lower():
                raise ToolError(f"SHA-256 no coincide para {LABELS[key]} (esperado {sha256[:12]}…, obtenido {got[:12]}…). "
                                "Descarga rechazada — puede ser un proxy que modifica archivos o un artefacto alterado.")
            log(f"[motores] {LABELS[key]}: {len(data) // (1 << 20)} MB, SHA-256 verificado ✓")
            return data, got
        except ToolError:
            raise
        except Exception as e:
            last = e
            log(f"[motores] {label} no disponible: {e!r}")
    raise ToolError(f"No se pudo descargar {LABELS[key]}: {last!r}")


def _safe_extract(data: bytes, dest: Path) -> None:
    dest.mkdir(parents=True, exist_ok=True)
    root = dest.resolve()
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        for m in z.infolist():
            target = (dest / m.filename).resolve()
            if root not in target.parents and target != root:
                raise ToolError(f"Archivo comprimido inseguro (ruta fuera del destino): {m.filename}")
        z.extractall(dest)


def _winget_install(key: str, log) -> bool:
    if key not in _WINGET or not which("winget"):
        return False
    log(f"[motores] intentando {LABELS[key]} vía winget ({_WINGET[key]}, origen winget)…")
    for scope in (["--scope", "user"], []):
        r = run(["winget", "install", "--id", _WINGET[key], "-e", "--source", "winget", "--silent",
                 "--accept-package-agreements", "--accept-source-agreements", *scope], timeout=1800)
        out = ((r.stdout or "") + (r.stderr or "")).strip()
        if not r.returncode or "already installed" in out.lower() or "ya está instalado" in out.lower():
            return True
        log(out[-400:])
    return False


# ── Localizadores ────────────────────────────────────────────────────────────
def _pf_dirs() -> list[Path]:
    return [Path(os.environ[k]) for k in ("ProgramFiles", "ProgramFiles(x86)", "LOCALAPPDATA") if os.environ.get(k)]


def _find_java() -> tuple[str, str]:
    cands = []
    m = _manifest().get("jre") or {}
    if m.get("path"):
        cands.append(m["path"])
    for base in _pf_dirs():
        for pat in ("Eclipse Adoptium/jre-*/bin/java.exe", "Eclipse Adoptium/jdk-*/bin/java.exe",
                    "Microsoft/jdk-*/bin/java.exe", "Java/jdk-*/bin/java.exe", "Programs/Eclipse Adoptium/*/bin/java.exe"):
            cands += [str(p) for p in sorted(base.glob(pat), reverse=True)]
    if j := which("java"):
        cands.append(j)
    for c in cands:
        try:
            r = run([c, "-version"], timeout=20)
            out = (r.stderr or "") + (r.stdout or "")
            mv = re.search(r'version "(\d+)', out)
            if mv and int(mv.group(1)) >= 17:
                return c, mv.group(1)
        except Exception:
            continue
    return "", ""


def _find_zap() -> str:
    m = _manifest().get("zap") or {}
    cands = [Path(m["path"])] if m.get("path") else []
    for base in _pf_dirs():
        cands += sorted(base.glob("ZAP/Zed Attack Proxy/zap-*.jar"), reverse=True)
    return next((str(c) for c in cands if Path(c).is_file()), "")


def _exe_version(exe: str, args=("-version",)) -> str:
    try:
        r = run([exe, *args], timeout=30)
        m = re.search(r"(\d+\.\d+\.\d+)", (r.stdout or "") + (r.stderr or ""))
        return m.group(1) if m else ""
    except Exception:
        return ""


def git_bash() -> str:
    """Bash de Git para Windows. Se evita a propósito el «bash.exe» de System32 (WSL), que no entiende rutas de Windows."""
    if os.name != "nt":
        return which("bash") or ""
    cands: list[Path] = []
    if g := which("git"):
        gp = Path(g).resolve()
        for up in (gp.parent.parent, gp.parent.parent.parent):
            cands += [up / "bin" / "bash.exe", up / "usr" / "bin" / "bash.exe"]
    for base in _pf_dirs():
        cands += [base / "Git" / "bin" / "bash.exe", base / "Programs" / "Git" / "bin" / "bash.exe"]
    return next((str(c) for c in cands if c.is_file()), "")


def checkov_python() -> Path:
    return TOOLS_DIR / "checkov-venv" / ("Scripts" if os.name == "nt" else "bin") / ("python.exe" if os.name == "nt" else "python")


# ── Estado ───────────────────────────────────────────────────────────────────
def status(key: str) -> ToolStatus:
    st = ToolStatus(key, LABELS[key], deps=list(NEEDS.get(key, ())))
    m = _manifest().get(key) or {}
    try:
        if key == "jre":
            path, ver = _find_java()
            st.installed, st.path, st.version = bool(path), path, ver
        elif key == "zap":
            path = _find_zap()
            st.installed, st.path = bool(path), path
            st.version = (re.search(r"zap-(\d+\.\d+\.\d+)", path) or [None, ""])[1] if path else ""
        elif key == "checkov":
            py = checkov_python()
            st.installed = py.exists() and bool(m.get("version"))
            st.path, st.version = str(py), m.get("version", "")
        else:
            path = m.get("path") if m.get("path") and Path(m["path"]).is_file() else (which(key) or "")
            st.installed, st.path = bool(path), path
            st.version = m.get("version") or (_exe_version(path, ("-version",) if key == "nuclei" else ("--version",))
                                               if path else "")
            if st.installed and key in MIN_VERSION and _vtuple(st.version) < _vtuple(MIN_VERSION[key]):
                st.installed, st.detail = False, f"versión {st.version} desactualizada (mínimo {MIN_VERSION[key]})"
            if st.installed and st.version in BLOCKED.get(key, set()):
                st.installed, st.detail = False, f"versión {st.version} COMPROMETIDA — se reinstalará"
            if st.installed and key == "gitsecrets" and not git_bash():
                st.detail = f"v{st.version} · falta Git para Windows (Git Bash) — solo se usa el motor integrado"
        st.source = m.get("source", "sistema" if st.installed else "")
        if st.installed and not st.detail:
            st.detail = f"v{st.version}" if st.version else "instalado"
        elif not st.detail:
            st.detail = "se descargará al primer uso"
    except Exception as e:
        st.detail = f"error al verificar: {e!r}"
    return st


def all_status() -> list[ToolStatus]:
    return [status(k) for k in ORDER]


def ready_for(stage: str) -> bool:
    return all(status(t).installed for t in STAGE_TOOLS.get(stage, ()))


# ── Instalación ──────────────────────────────────────────────────────────────
def _install_github(key: str, log, progress=None) -> dict:
    v = wanted_version(key)
    rel = _gh_release(key, v, log)
    asset = _ASSET[key].format(v=v)
    a = next((x for x in rel.get("assets") or [] if x.get("name") == asset), None)
    if not a:
        raise ToolError(f"La versión {v} de {LABELS[key]} no publica '{asset}'.")
    sha = (a.get("digest") or "").split(":", 1)[-1] if str(a.get("digest", "")).startswith("sha256:") else ""
    sha = sha or _checksum_from_file(key, v, rel, asset, log)
    if not sha:
        raise ToolError(f"No hay checksum publicado para {asset}; por seguridad no se instala sin verificación.")
    data, got = _download_verified(key, a["browser_download_url"], sha, log, progress, mirror_name=asset)
    dest = TOOLS_DIR / key / v
    if dest.exists():
        shutil.rmtree(dest, ignore_errors=True)
    _safe_extract(data, dest)
    if key == "zap":
        jar = next(iter(sorted(dest.rglob("zap-*.jar"))), None)
        if not jar:
            raise ToolError("El paquete de ZAP no contiene zap-*.jar")
        return {"version": v, "path": str(jar), "sha256": got, "source": "GitHub (verificado)"}
    exe = next(iter(sorted(dest.rglob(f"{key}.exe" if os.name == "nt" else key))), None)
    if not exe:
        raise ToolError(f"El paquete de {LABELS[key]} no contiene el ejecutable esperado")
    return {"version": v, "path": str(exe), "sha256": got, "source": "GitHub (verificado)"}


def _install_jre(log, progress=None) -> dict:
    major = wanted_version("jre")
    api = (f"https://api.adoptium.net/v3/assets/latest/{major}/hotspot?os=windows&architecture=x64&image_type=jre"
           "&vendor=eclipse")
    try:
        meta = json.loads(http_bytes(api, log, allow_insecure=True, timeout=30)[0])
        pkg = meta[0]["binary"]["package"]
    except Exception as e:
        raise ToolError(f"No se pudo consultar Adoptium para Java {major}: {e!r}")
    if not pkg.get("checksum"):
        raise ToolError("Adoptium no publicó checksum para el JRE; instalación rechazada.")
    data, got = _download_verified("jre", pkg["link"], pkg["checksum"], log, progress, mirror_name=pkg["name"])
    dest = TOOLS_DIR / "jre" / major
    shutil.rmtree(dest, ignore_errors=True)
    _safe_extract(data, dest)
    java = next(iter(sorted(dest.rglob("java.exe" if os.name == "nt" else "java"))), None)
    if not java:
        raise ToolError("El paquete del JRE no contiene java.exe")
    return {"version": meta[0].get("release_name", major), "path": str(java), "sha256": got,
            "source": "Adoptium (verificado)"}


def _install_gitsecrets(log, progress=None) -> dict:
    v = wanted_version("gitsecrets")
    sha = _GITSECRETS_SHA.get(v)
    if not sha:
        raise ToolError(f"git-secrets {v} no tiene un SHA-256 aprobado en este programa (versiones aprobadas: "
                        f"{', '.join(_GITSECRETS_SHA)}). Deje la versión vacía en Administración.")
    dest = TOOLS_DIR / "gitsecrets" / v / "git-secrets"
    legacy = Path(os.environ.get("LOCALAPPDATA") or Path.home() / ".cache") / "vuln-scanner" / "git-secrets" / "git-secrets"
    if legacy.is_file() and hashlib.sha256(legacy.read_bytes()).hexdigest() == sha:
        data, source = legacy.read_bytes(), "caché anterior (verificado)"
        log("[motores] git-secrets: se reutiliza la copia ya descargada (SHA-256 verificado ✓)")
    else:
        data, _ = _download_verified("gitsecrets", _GITSECRETS_URL.format(v=v), sha, log, progress,
                                     mirror_name="git-secrets")
        source = "GitHub awslabs (verificado)"
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    return {"version": v, "path": str(dest), "sha256": sha, "source": source}


def _venv_pip(py: Path, args: list, log) -> int:
    base = [str(py), "-m", "pip", "install", "--disable-pip-version-check", "--no-input", *args]
    r = run(base, timeout=2400)
    if r.returncode:
        log("[motores] pip: reintentando con trusted-host (¿proxy TLS corporativo?)")
        hosts = ("pypi.org", "files.pythonhosted.org", "pypi.python.org")
        r = run(base + [a for h in hosts for a in ("--trusted-host", h)], timeout=2400)
    log(((r.stdout or "") + (r.stderr or "")).strip()[-1500:])
    return r.returncode


def _install_checkov(log, progress=None) -> dict:
    spec = wanted_version("checkov")
    venv = TOOLS_DIR / "checkov-venv"
    py = checkov_python()
    if not py.exists():
        log("[motores] creando entorno aislado para Checkov (no afecta a sus paquetes de Python)…")
        r = run([sys.executable, "-m", "venv", str(venv)], timeout=600)
        if r.returncode:
            raise ToolError(f"No se pudo crear el entorno de Checkov: {(r.stderr or r.stdout).strip()[:300]}")
    req = f"checkov=={spec}.*" if re.fullmatch(r"\d+\.\d+", spec) else f"checkov=={spec}"
    log(f"[motores] instalando {req} (puede tardar varios minutos la primera vez)…")
    if progress:
        progress(1, 3)
    if _venv_pip(py, ["--upgrade", req], log):
        raise ToolError("pip no pudo instalar Checkov — revise el registro.")
    v = run([str(py), "-c", "import checkov.version as v; print(v.version)"], timeout=120).stdout.strip()
    return {"version": v or spec, "path": str(py), "source": "PyPI (entorno aislado)"}


def _locate_after_winget(key: str) -> dict:
    if key == "jre":
        path, ver = _find_java()
        return {"version": ver, "path": path, "source": "winget"} if path else {}
    if key == "zap":
        path = _find_zap()
        return {"version": (re.search(r"zap-(\d+\.\d+\.\d+)", path) or [None, ""])[1], "path": path,
                "source": "winget"} if path else {}
    os.environ["PATH"] = os.pathsep.join([str(Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft" / "WinGet" / "Links"),
                                          os.environ.get("PATH", "")])
    path = which(key)
    return {"version": _exe_version(path, ("--version",)), "path": path, "source": "winget"} if path else {}


def ensure(key: str, log=print, progress=None, *, force: bool = False) -> str:
    """Garantiza que el motor esté instalado y devuelve la ruta del ejecutable (o del .jar en ZAP)."""
    for dep in NEEDS.get(key, ()):
        ensure(dep, log, None)
    with _LOCKS[key]:
        st = status(key)
        if st.installed and not force:
            return st.path
        TOOLS_DIR.mkdir(parents=True, exist_ok=True)
        log(f"[motores] preparando {LABELS[key]} ({PURPOSE[key]})…")
        errors = []
        installers = {"jre": _install_jre, "checkov": _install_checkov, "gitsecrets": _install_gitsecrets}
        try:
            entry = installers.get(key, _install_github)(*((log, progress) if key in installers else (key, log, progress)))
        except ToolError as e:
            errors.append(str(e))
            entry = {}
        except Exception as e:
            errors.append(repr(e))
            entry = {}
        if not entry and _winget_install(key, log):
            entry = _locate_after_winget(key)
        if not entry or not entry.get("path"):
            raise ToolError(f"{LABELS[key]} no está disponible: " + ("; ".join(errors) or "sin fuente de instalación") +
                            ". Si su red bloquea GitHub, pida a Ciberseguridad configurar un espejo interno.")
        _save_manifest(key, entry)
        log(f"[motores] {LABELS[key]} listo ✓ ({entry.get('version', '?')}, {entry.get('source', '')})")
        return entry["path"]


def ensure_for(stages, log=print) -> dict:
    out, errors = {}, {}
    for t in dict.fromkeys(t for s in stages for t in STAGE_TOOLS.get(s, ())):
        try:
            out[t] = ensure(t, log)
        except ToolError as e:
            errors[t] = str(e)
    return {"ok": out, "errors": errors}


def remove(key: str, log=print) -> None:
    with _LOCKS[key]:
        shutil.rmtree(TOOLS_DIR / key, ignore_errors=True)
        if key == "checkov":
            shutil.rmtree(TOOLS_DIR / "checkov-venv", ignore_errors=True)
        _save_manifest(key, None)
        log(f"[motores] {LABELS[key]} eliminado de la carpeta de herramientas.")
