from __future__ import annotations

import ctypes
import getpass
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import tkinter as tk
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from tkinter import ttk, filedialog, messagebox
from typing import Any, Callable, Optional

APP_DIR = Path(__file__).resolve().parent
if APP_DIR.name.lower() == "core":
    APP_DIR = APP_DIR.parent
IMAGES_DIR = APP_DIR / "images"
DATA_DIR = APP_DIR / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)
LOGO_PATH = IMAGES_DIR / "Logo.png"
DARK_LOGO_PATH = IMAGES_DIR / "LogoDark.png"
ICON_DIR = IMAGES_DIR / "icon"
DEFAULT_REPORTS = APP_DIR / "Reports"
TOOLS_DIR = APP_DIR / "tools"
SETTINGS_FILE = DATA_DIR / ".scanner_settings.json"
SESSION_FILE = DATA_DIR / ".scanner_session.json"
GUI_PID_FILE = DATA_DIR / ".gui_running.pid"
OWNER_FILE = DATA_DIR / ".scan_engine_owner.pid"

APP_BRAND_NAME = "SecDevOps Banco Base"
APP_VERSION = "0.8"
SUPPORT_EMAIL = "slunam@bancobase.com"
AUTH_POLL_INTERVAL = 2
AUTH_POLL_TIMEOUT = 300


# ── DPI / escala ─────────────────────────────────────────────────────────────
def _init_dpi() -> float:
    """Declara la app DPI-aware (texto nítido en pantallas 125–200 %) y devuelve el factor de escala."""
    if os.name != "nt" or os.environ.get("BBSCANNER_DPI_UNAWARE") == "1":
        return 1.0
    try:
        if ctypes.windll.shcore.SetProcessDpiAwareness(1) not in (0, -2147024891):
            ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            return 1.0
    try:
        return max(1.0, ctypes.windll.user32.GetDpiForSystem() / 96)
    except Exception:
        return 1.0


UI_SCALE = _init_dpi()
FONT_SCALE = 0.86


def px(n: float) -> int:
    """Convierte píxeles lógicos (diseñados a 100 %) a píxeles reales según el DPI del sistema."""
    return int(round(n * UI_SCALE))


def init_root(root: tk.Misc) -> None:
    """Ajusta la escala de fuentes una sola vez por raíz Tk (los tamaños heredados en pt se ven proporcionados)."""
    if getattr(root, "_bb_scaled", False):
        return
    try:
        root.tk.call("tk", "scaling", float(root.tk.call("tk", "scaling")) * FONT_SCALE)
    except Exception:
        pass
    root._bb_scaled = True


# ── Tipografía e iconos ──────────────────────────────────────────────────────
_FONT_DIRS = [Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts",
              Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft" / "Windows" / "Fonts"]


def _has_font(*names: str) -> bool:
    return any((d / n).exists() for d in _FONT_DIRS for n in names)


_VARIABLE_UI = _has_font("SegUIVar.ttf")
FUI = "Segoe UI Variable Text" if _VARIABLE_UI else "Segoe UI"
FUI_TITLE = "Segoe UI Variable Display" if _VARIABLE_UI else "Segoe UI Semibold"
FMONO = "Cascadia Mono" if _has_font("CascadiaMono.ttf") else "Consolas"
ICON_FONT = "Segoe Fluent Icons" if _has_font("SegoeIcons.ttf") else \
    "Segoe MDL2 Assets" if _has_font("segmdl2.ttf") else None

CONTENT_INSET = 0.04
CARD_GAP = px(12)
SQ_ICON = 13
NO_APP_STAGES = ("sca", "code", "secrets")
STATIC_STAGES = ("sca", "code", "secrets")
INFRA_STAGES = ("container", "iac")
WEB_STAGES = ("dast", "api")
STAGES = STATIC_STAGES + INFRA_STAGES + WEB_STAGES
# Instrucción única de inicio de sesión en Snyk: se repite en cada lugar donde el usuario puede iniciar sesión.
SNYK_SSO_TITLE = "Inicie sesión SOLO con «Log in with SSO»"
SNYK_SSO_WARNING = ("En la página de Snyk haga clic en «Log in with SSO». NO escriba su correo y contraseña en el "
                    "formulario principal ni use Google, GitHub o Microsoft: eso crea una cuenta PERSONAL de Snyk, "
                    "sin acceso a la organización del banco, y SCA y SAST fallarán.")
SNYK_SSO_SHORT = "Elija «Log in with SSO» — no use correo/contraseña, Google ni GitHub."

STAGE_LABELS = {"sca": "SCA", "code": "SAST", "secrets": "Secretos", "container": "Contenedores", "iac": "IaC",
                "dast": "DAST", "api": "API"}

NOWIN = {"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}

ICONS = {
    "menu": ("\uE700", "☰"), "sun": ("\uE706", "☀"), "moon": ("\uE708", "☾"), "chev_down": ("\uE70D", "▾"),
    "chev_right": ("\uE76C", "▸"), "edit": ("\uE70F", "✏"), "add": ("\uE710", "+"), "close": ("\uE711", "✕"),
    "settings": ("\uE713", "⚙"), "mail": ("\uE715", "✉"), "stop": ("\uE71A", "■"), "link": ("\uE71B", "⬡"),
    "apps": ("\uE71D", "▦"), "search": ("\uE721", "🔎"), "back": ("\uE72B", "◀"), "refresh": ("\uE72C", "↻"),
    "lock": ("\uE72E", "🔒"), "remove": ("\uE738", "−"), "check": ("\uE73E", "✓"), "delete": ("\uE74D", "🗑"),
    "save": ("\uE74E", "💾"), "cloud": ("\uE753", "☁"), "console": ("\uE756", "▥"), "play": ("\uE768", "▶"),
    "globe": ("\uE774", "🌐"), "person": ("\uE77B", "👤"), "calendar": ("\uE787", "📅"), "package": ("\uE7B8", "📦"),
    "warn": ("\uE7BA", "⚠"), "record": ("\uE7C8", "⏺"), "power": ("\uE7E8", "⏻"), "clock": ("\uE823", "🕒"),
    "download": ("\uE896", "📥"), "help": ("\uE897", "?"), "document": ("\uE8A5", "📄"), "folder": ("\uE8B7", "📂"),
    "copy": ("\uE8C8", "⧉"), "key": ("\uE8D7", "🔑"), "accept": ("\uE8FB", "✔"), "repair": ("\uE90F", "🧹"),
    "code": ("\uE943", "⌨"), "info": ("\uE946", "ℹ"), "error": ("\uE711", "✕"),
    "container": ("\uEA86", "🧩"), "iac": ("\uE81E", "🗂"), "shield": ("\uEA18", "🛡"), "engine": ("\uE945", "⚡"),
    "filter": ("\uE71C", "⏷"), "open": ("\uE8A7", "↗"), "flag": ("\uE7C1", "⚑"), "target": ("\uE81D", "◎"),
    "chev_left": ("\uE76B", "◂"), "star": ("\uE734", "★"),
}

# Los botones heredados usan emoji como prefijo; se traducen a glifos Fluent para un set de iconos coherente.
EMOJI_ICON = {
    "📂": "folder", "📁": "folder", "🗑": "delete", "▶": "play", "■": "stop", "🔄": "refresh", "↻": "refresh",
    "🔁": "refresh", "📄": "document", "📋": "document", "✏": "edit", "💾": "save", "🔑": "key", "🌐": "globe",
    "✉": "mail", "+": "add", "✓": "check", "✔": "check", "✕": "close", "🔍": "search", "🔎": "search",
    "📥": "download", "🧬": "code", "⏺": "record", "🧹": "repair", "🚀": "play", "🩹": "repair", "🧙": "settings",
    "?": "help", "☀": "sun", "🌙": "moon", "⏻": "power", "−": "remove", "◀": "back", "📦": "package",
    "▥": "console", "🕒": "clock", "🛡": "shield", "⚡": "engine", "🧩": "container", "🗂": "iac",
}


def ico(name: str) -> str:
    glyph, fallback = ICONS.get(name, ("", "•"))
    return glyph if ICON_FONT else fallback


def icon_font(size: int = 11) -> tuple:
    return (ICON_FONT or FUI, size)


def split_icon(text: str) -> tuple[Optional[str], str]:
    s = (text or "").strip()
    if not s:
        return None, ""
    parts = s.split(maxsplit=1)
    name = EMOJI_ICON.get(parts[0]) or EMOJI_ICON.get(parts[0].rstrip("\ufe0f"))
    if name and ICON_FONT:
        return name, parts[1].strip() if len(parts) > 1 else ""
    return None, s


# ── Paleta (tokens de diseño) ────────────────────────────────────────────────
PALETTE_LIGHT = {
    "bg": "#F4F5F7", "panel_bg": "#FFFFFF", "surface2": "#F7F8FA", "surface3": "#EEF0F3",
    "accent": "#F5A800", "accent_hi": "#DB9600", "accent_soft": "#FFF7E0", "button_fg": "#1F1500",
    "accent2": "#C8102E", "accent2_hi": "#A50D26",
    "text": "#111827", "muted": "#6B7280", "border": "#E2E5EA", "border_strong": "#C9CED6", "card_fg": "#111827",
    "border2": "#2F5D9A", "shadow": "#000000", "ok": "#15803D", "err": "#C8102E", "warn": "#B45309",
    "ok_soft": "#E8F5EC", "err_soft": "#FDECEE", "warn_soft": "#FEF4E2", "info_soft": "#EAF1FB",
    "hover": "#EEF0F3", "select": "#FFF1CC", "select_fg": "#111827", "toggle_off": "#C3C9D2", "scrim": "#000000",
    "sb_bg": "#0F1E33", "sb_fg": "#D5DEEA", "sb_muted": "#8496AE", "sb_hover": "#18304F", "sb_active": "#1F3A5F",
    "sev_critical": "#B3261E", "sev_high": "#C2410C", "sev_medium": "#A16207", "sev_low": "#15803D",
}
PALETTE_DARK = {
    "bg": "#111318", "panel_bg": "#191C22", "surface2": "#1F232A", "surface3": "#252A32",
    "accent": "#F5A800", "accent_hi": "#FFBE2E", "accent_soft": "#2A2312", "button_fg": "#1F1500",
    "accent2": "#E5484D", "accent2_hi": "#C93C41",
    "text": "#E8EAED", "muted": "#9AA3AF", "border": "#2C323C", "border_strong": "#3B4350", "card_fg": "#E8EAED",
    "border2": "#7BA7E0", "shadow": "#000000", "ok": "#4ADE80", "err": "#F87171", "warn": "#FBBF24",
    "ok_soft": "#14261B", "err_soft": "#2D1618", "warn_soft": "#2B2210", "info_soft": "#16223A",
    "hover": "#232831", "select": "#3A3014", "select_fg": "#F5F5F5", "toggle_off": "#4B5260", "scrim": "#000000",
    "sb_bg": "#0B0D11", "sb_fg": "#D5DAE1", "sb_muted": "#7D8794", "sb_hover": "#171B22", "sb_active": "#1E242D",
    "sev_critical": "#F87171", "sev_high": "#FB923C", "sev_medium": "#FACC15", "sev_low": "#4ADE80",
}
T: dict = dict(PALETTE_LIGHT)
_THEME = {"dark": False}

RISK_COLORS = {
    False: {"Crítico": "#c8102e", "Alto": "#e26020", "Medio": "#b8860b", "Bajo": "#1a7a4a", "Ninguno": "#6B7280"},
    True: {"Crítico": "#f08090", "Alto": "#f4a460", "Medio": "#f0d060", "Bajo": "#5fe0a0", "Ninguno": "#9AA3AF"},
}
SEV_RANK = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}
SEV_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}
SEV_ES = {"critical": "CRÍTICA", "high": "ALTA", "medium": "MEDIA", "low": "BAJA", "info": "INFO"}


def apply_palette(dark: bool) -> None:
    _THEME["dark"] = bool(dark)
    T.clear()
    T.update(PALETTE_DARK if dark else PALETTE_LIGHT)


def is_dark() -> bool:
    return _THEME["dark"]


def progress_color() -> str:
    return T["accent"]


def sev_norm(s) -> str:
    s = str(s or "").strip().lower()
    return {"crit": "critical", "med": "medium", "moderate": "medium"}.get(s, s if s in SEV_RANK else "info")


def ts() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def now_human() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def slug(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9\-_]", "_", (name or "").strip())


def report_basename(user: str, mode: str) -> str:
    return re.sub(r"[^A-Za-z0-9+\-_]", "_", f"{mode}+{user}_{datetime.now():%Y%m%d}")


def read_json(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return default


def write_json(path, data, **kw) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(data, indent=2, ensure_ascii=False, default=str, **kw), encoding="utf-8")


def which(cmd: str) -> Optional[str]:
    return shutil.which(cmd) or next((p for p in (shutil.which(cmd + e) for e in (".cmd", ".bat", ".exe")) if p), None)


def run(args, cwd=None, env=None, timeout=600, **kw) -> subprocess.CompletedProcess:
    return subprocess.run(args, cwd=str(cwd) if cwd else None, env=env if env is not None else os.environ.copy(),
                          timeout=timeout, capture_output=True, text=True, encoding="utf-8",
                          errors="replace", **NOWIN, **kw)


def open_path(path) -> None:
    try:
        os.startfile(str(path))
    except Exception:
        import webbrowser
        webbrowser.open(Path(path).as_uri())


def detect_user() -> str:
    try:
        return getpass.getuser()
    except Exception:
        return os.environ.get("USERNAME") or "user"


def kill_process_tree(proc: Optional[subprocess.Popen]) -> None:
    if proc is None:
        return
    try:
        subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)], capture_output=True, timeout=5, **NOWIN)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass
    try:
        proc.wait(timeout=3)
    except Exception:
        pass


def pid_alive(pid: Optional[int]) -> bool:
    if not pid or pid <= 0:
        return False
    k32 = ctypes.windll.kernel32
    h = k32.OpenProcess(0x1000, False, int(pid))
    if not h:
        return False
    code = ctypes.c_ulong()
    try:
        return bool(k32.GetExitCodeProcess(h, ctypes.byref(code))) and code.value == 259
    finally:
        k32.CloseHandle(h)


def read_pid(path: Path) -> Optional[int]:
    try:
        return int(path.read_text(encoding="utf-8").strip())
    except Exception:
        return None


def claim_owner() -> bool:
    pid = read_pid(OWNER_FILE)
    if pid and pid != os.getpid() and pid_alive(pid):
        return False
    try:
        OWNER_FILE.write_text(str(os.getpid()), encoding="utf-8")
        return True
    except Exception:
        return False


def release_owner() -> None:
    if read_pid(OWNER_FILE) == os.getpid():
        OWNER_FILE.unlink(missing_ok=True)


def trash_path(path: Path, log: Optional[Callable[[str], None]] = None) -> None:
    try:
        from send2trash import send2trash
        send2trash(str(path))
    except Exception as e:
        if log:
            log(f"[papelera] send2trash falló ({e!r}) — se elimina permanentemente")
        shutil.rmtree(path)


def dir_has_files(p) -> bool:
    try:
        p = Path(p)
        return p.is_file() or any(c.is_file() for c in p.rglob("*"))
    except Exception:
        return True


def find_report_html(d) -> Optional[Path]:
    d = Path(d)
    if not d.is_dir():
        return None
    if (d / "report.html").exists():
        return d / "report.html"
    cands = [p for p in d.glob("*.html") if p.name != "remediation_history.html" and not p.name.endswith("_secrets.html")]
    return max(cands, key=lambda p: p.stat().st_mtime) if cands else None


_audit_lock = threading.Lock()


def audit(reports_root, event: str, *, actor: str = "", app: str = "", log=None, **fields: Any) -> None:
    rec = {"ts": datetime.now().isoformat(timespec="seconds"), "event": event,
           "actor": actor or os.environ.get("USERNAME", ""), "app": app, **fields}
    try:
        d = Path(reports_root) / ".audit"
        d.mkdir(parents=True, exist_ok=True)
        with _audit_lock, open(d / f"audit-{datetime.now():%Y%m}.jsonl", "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, default=str) + "\n")
    except Exception as e:
        if log:
            log(f"[auditoría] no se pudo escribir el evento {event!r}: {e!r}")


def icon_dir(dark: bool) -> Path:
    return ICON_DIR / ("dark" if dark else "light")


def load_image(path: Path, max_px: int = 0) -> Optional[tk.PhotoImage]:
    if not path.exists():
        return None
    try:
        img = tk.PhotoImage(file=str(path))
    except Exception:
        return None
    if max_px:
        f = max(1, -(-max(img.width(), img.height()) // max_px))
        if f > 1:
            img = img.subsample(f, f)
    return img


def set_window_icon(win: tk.Misc, dark: bool, names=("favicon-16x16.png", "favicon-32x32.png",
                                                     "apple-touch-icon.png", "android-chrome-192x192.png")) -> None:
    d = icon_dir(dark)
    imgs = [i for i in (load_image(d / n) for n in names) if i]
    if not imgs and (img := load_image(LOGO_PATH)):
        imgs = [img]
    if imgs:
        win._icon_imgs = imgs
        try:
            win.iconphoto(True, *imgs)
        except Exception:
            pass
    ico_file = d / "favicon.ico"
    if not ico_file.exists():
        return
    try:
        win.iconbitmap(default=str(ico_file))
        win.update_idletasks()
        u32 = ctypes.windll.user32
        hwnd = u32.GetParent(win.winfo_id()) or win.winfo_id()
        for kind, size in ((0, 16), (1, 32)):
            h = u32.LoadImageW(0, str(ico_file), 1, size, size, 0x10)
            if h:
                u32.SendMessageW(hwnd, 0x0080, kind, h)
    except Exception:
        pass


def _hwnd(win: tk.Misc) -> int:
    try:
        return int(win.wm_frame(), 16)
    except Exception:
        return 0


def round_corners(win: tk.Misc) -> None:
    """Esquinas redondeadas nativas de Windows 11 (sin efecto en Windows 10)."""
    try:
        v = ctypes.c_int(2)
        ctypes.windll.dwmapi.DwmSetWindowAttribute(_hwnd(win), 33, ctypes.byref(v), 4)
    except Exception:
        pass


def set_titlebar_theme(win: tk.Misc, dark: bool) -> None:
    """Barra de título nativa en modo oscuro/claro según el tema de la app."""
    try:
        h, v = _hwnd(win), ctypes.c_int(1 if dark else 0)
        if ctypes.windll.dwmapi.DwmSetWindowAttribute(h, 20, ctypes.byref(v), 4):
            ctypes.windll.dwmapi.DwmSetWindowAttribute(h, 19, ctypes.byref(v), 4)
    except Exception:
        pass


def monitor_rect(widget) -> tuple:
    try:
        import struct
        hmon = ctypes.windll.user32.MonitorFromWindow(int(widget.wm_frame(), 16), 2)
        mi = (ctypes.c_uint32 * 10)()
        mi[0] = ctypes.sizeof(mi)
        ctypes.windll.user32.GetMonitorInfoW(hmon, mi)
        l, t, r, b = struct.unpack_from("<iiii", bytes(mi), 4)
        return l, t, r - l, b - t
    except Exception:
        return 0, 0, widget.winfo_screenwidth(), widget.winfo_screenheight()


def last_window_anchor() -> tuple:
    data = read_json(SETTINGS_FILE, {}) or {}
    x, y = data.get("window_x"), data.get("window_y")
    return (x, y) if isinstance(x, int) and isinstance(y, int) else (None, None)


def center_over(master, win, w_pct: float, h_pct: float) -> None:
    master.update_idletasks()
    _, _, mw, mh = monitor_rect(master)
    w, h = int(mw * w_pct), int(mh * h_pct)
    x = master.winfo_rootx() + (master.winfo_width() - w) // 2
    y = master.winfo_rooty() + (master.winfo_height() - h) // 2
    win.geometry(f"{w}x{h}+{x}+{y}")


# Despachador de eventos por ventana: evita que un unbind() borre los enlaces de otro diálogo.
_HOOKS: dict = {}


def _hook(master: tk.Misc, seq: str, fn) -> Callable[[], None]:
    key = (str(master), seq)
    lst = _HOOKS.get(key)
    if lst is None:
        lst = _HOOKS[key] = []
        master.bind(seq, lambda e, l=lst: [f(e) for f in list(l)], "+")
    lst.append(fn)
    return lambda: fn in lst and lst.remove(fn)


def follow_parent(win: tk.Toplevel, parent: tk.Misc, scrim: Optional[tk.Toplevel] = None) -> list:
    try:
        ctypes.windll.user32.SetWindowLongPtrW(int(win.wm_frame(), 16), -8, int(parent.wm_frame(), 16))
    except Exception:
        pass

    def show():
        if scrim is not None and scrim.winfo_exists():
            scrim.deiconify()
            scrim.lift()
        if win.winfo_exists():
            win.deiconify()
            win.lift()

    def hide():
        if win.winfo_exists():
            win.withdraw()
        if scrim is not None and scrim.winfo_exists():
            scrim.withdraw()

    def on_focus_out(_e):
        def check():
            if not win.winfo_exists() or getattr(win, "_dialog_guard", False):
                return
            try:
                w = win.focus_displayof()
                while w is not None:
                    if w is win:
                        return
                    w = w.master
                if parent.focus_get() is None:
                    hide()
            except Exception:
                pass
        parent.after(100, check)

    return [_hook(parent, "<FocusIn>", lambda _e: show()), _hook(parent, "<FocusOut>", on_focus_out),
            _hook(parent, "<Unmap>", lambda e: e.widget is parent and hide()),
            _hook(parent, "<Map>", lambda e: e.widget is parent and show())]


_SCRIMS: list = []


def _make_scrim(master: tk.Misc) -> Optional[tk.Toplevel]:
    """Velo semitransparente sobre la ventana principal mientras hay un diálogo modal abierto."""
    if _SCRIMS:
        return None
    try:
        if not master.winfo_viewable():
            return None
        s = tk.Toplevel(master)
        s.withdraw()
        s.overrideredirect(True)
        s.configure(bg=T["scrim"])
        s.attributes("-alpha", 0.45 if is_dark() else 0.30)
        s.transient(master)
    except tk.TclError:
        return None

    def sync(_e=None):
        if s.winfo_exists() and master.winfo_exists():
            s.geometry(f"{max(master.winfo_width(), 1)}x{max(master.winfo_height(), 1)}"
                       f"+{master.winfo_rootx()}+{master.winfo_rooty()}")
    sync()
    s._unhook = _hook(master, "<Configure>", sync)
    _SCRIMS.append(s)
    return s


def _drop_scrim(s: Optional[tk.Toplevel]) -> None:
    if s is None:
        return
    try:
        s._unhook()
    except Exception:
        pass
    if s in _SCRIMS:
        _SCRIMS.remove(s)
    try:
        s.destroy()
    except Exception:
        pass


def make_modal(win: tk.Toplevel, master: tk.Misc, w_pct=None, h_pct=None, on_escape=None) -> tk.Frame:
    """Diálogo modal. Sin w_pct/h_pct se dimensiona a su contenido (con mínimo y máximo razonables)."""
    win.withdraw()
    win.transient(master)
    win.overrideredirect(True)
    content = panel_chrome(win)
    scrim = _make_scrim(master)
    unhooks: list = []
    state = {"closed": False}

    def place():
        if state["closed"] or not win.winfo_exists():
            return
        win.update_idletasks()
        win.update_idletasks()
        mx, my, mw, mh = monitor_rect(master)
        if w_pct and h_pct:
            w, h = int(mw * w_pct), int(mh * h_pct)
        else:
            w = min(max(win.winfo_reqwidth(), px(560)), int(mw * 0.9))
            h = min(max(win.winfo_reqheight(), px(180)), int(mh * 0.88))
        x = master.winfo_rootx() + (master.winfo_width() - w) // 2
        y = master.winfo_rooty() + (master.winfo_height() - h) // 2
        x, y = min(max(x, mx), mx + mw - w), min(max(y, my), my + mh - h)
        win.geometry(f"{w}x{h}+{x}+{y}")
        if scrim is not None and scrim.winfo_exists():
            scrim.deiconify()
            scrim.lift()
        win.deiconify()
        win.lift()
        round_corners(win)
        try:
            win.focus_force()
            win.grab_set()
        except tk.TclError:
            pass
        unhooks.extend(follow_parent(win, master, scrim))

    def close():
        if state["closed"]:
            return
        state["closed"] = True
        try:
            win.grab_release()
        except Exception:
            pass
        for u in unhooks:
            u()
        _drop_scrim(scrim)
        try:
            win.destroy()
        except Exception:
            pass
        try:
            master.focus_force()
        except Exception:
            pass

    win.bind("<Escape>", lambda _e: (on_escape or close)(), add="+")
    win.bind("<Destroy>", lambda e: e.widget is win and not state["closed"] and (
        state.update(closed=True), [u() for u in unhooks], _drop_scrim(scrim)), add="+")
    win.after_idle(place)
    content.close = close
    content._win = win
    return content


@contextmanager
def dialog_guard(win: tk.Toplevel):
    win._dialog_guard = True
    try:
        yield
    finally:
        win._dialog_guard = False
        if win.winfo_exists():
            win.deiconify()
            win.lift()
            win.focus_force()


def panel_chrome(win: tk.Toplevel) -> tk.Frame:
    win.configure(bg=T["border_strong"])
    content = tk.Frame(win, bg=T["bg"])
    content.pack(fill="both", expand=True, padx=1, pady=1)
    return content


def scroll_frame(parent, bg=None, inset: float = 0.0, pad=(0, 0)) -> tk.Frame:
    bg = bg or T["bg"]
    canvas = tk.Canvas(parent, bg=bg, highlightthickness=0, bd=0)
    vsb = ttk.Scrollbar(parent, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=vsb.set)
    vsb.pack(side="right", fill="y")
    canvas.pack(side="left", fill="both", expand=True)
    holder = tk.Frame(canvas, bg=bg)
    win = canvas.create_window((0, 0), window=holder, anchor="nw")

    def on_holder(_e=None):
        canvas.configure(scrollregion=canvas.bbox("all"))
        want = min(holder.winfo_reqheight(), int(canvas.winfo_screenheight() * 0.62))
        try:
            if abs(int(float(canvas.cget("height"))) - want) > 2:
                canvas.configure(height=want)
        except (tk.TclError, ValueError):
            pass

    holder.bind("<Configure>", on_holder)

    def on_conf(e):
        m = e.width * inset
        canvas.coords(win, m, 0)
        canvas.itemconfigure(win, width=max(e.width - 2 * m, 1))

    canvas.bind("<Configure>", on_conf)

    def wheel(e):
        if canvas.yview() != (0.0, 1.0):
            canvas.yview_scroll(int(-e.delta / 120), "units")
    canvas.bind("<Enter>", lambda _e: canvas.bind_all("<MouseWheel>", wheel))
    canvas.bind("<Leave>", lambda _e: canvas.unbind_all("<MouseWheel>"))
    inner = tk.Frame(holder, bg=bg, padx=pad[0], pady=pad[1])
    inner.pack(fill="both", expand=True)
    return inner


def autowrap(lbl: tk.Label, margin: int = 4, minimum: int = 120) -> tk.Label:
    lbl.bind("<Configure>", lambda e: lbl.config(wraplength=max(minimum, e.width - margin)))
    return lbl


def rounded_rect(canvas: tk.Canvas, x1, y1, x2, y2, r, **kw):
    pts = [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2, x2 - r, y2, x1 + r, y2, x1, y2,
           x1, y2 - r, x1, y1 + r, x1, y1]
    return canvas.create_polygon(pts, smooth=True, **kw)


def _bg_of(widget) -> str:
    try:
        return widget.cget("bg")
    except Exception:
        return T["bg"]


class Tooltip:
    def __init__(self, widget: tk.Misc, text, delay: int = 450):
        self.widget, self.text, self.delay = widget, text, delay
        self._after = self._tip = None
        widget.bind("<Enter>", self._schedule, add="+")
        widget.bind("<Leave>", self._leave, add="+")
        widget.bind("<ButtonPress>", self._hide, add="+")

    def _leave(self, e=None):
        # Pasar del contenedor a uno de sus hijos no debe ocultar la ayuda.
        try:
            w = self.widget.winfo_containing(self.widget.winfo_pointerx(), self.widget.winfo_pointery())
            while w is not None:
                if w is self.widget:
                    return
                w = w.master
        except Exception:
            pass
        self._hide()

    def _schedule(self, _e=None):
        self._hide()
        self._after = self.widget.after(self.delay, self._show)

    def _show(self):
        text = self.text() if callable(self.text) else self.text
        if not text or not self.widget.winfo_exists():
            return
        self._tip = tw = tk.Toplevel(self.widget)
        tw.overrideredirect(True)
        tw.attributes("-topmost", True)
        tk.Label(tw, text=text, font=(FUI, 10), bg="#1F2937", fg="#F9FAFB", padx=px(10), pady=px(6),
                 justify="left", wraplength=px(360)).pack()
        tw.update_idletasks()
        # Se mantiene dentro del monitor donde está la ventana (también en configuraciones multi-monitor).
        mx, my, mw, mh = monitor_rect(self.widget.winfo_toplevel())
        w, h, m = tw.winfo_reqwidth(), tw.winfo_reqheight(), px(8)
        x = self.widget.winfo_rootx() + min(px(12), self.widget.winfo_width() // 2)
        y = self.widget.winfo_rooty() + self.widget.winfo_height() + px(6)
        if y + h > my + mh - m:
            y = self.widget.winfo_rooty() - h - px(6)
        x = max(mx + m, min(x, mx + mw - w - m))
        y = max(my + m, min(y, my + mh - h - m))
        tw.geometry(f"+{x}+{y}")
        round_corners(tw)

    def _hide(self, _e=None):
        if self._after:
            try:
                self.widget.after_cancel(self._after)
            except Exception:
                pass
            self._after = None
        if self._tip is not None:
            try:
                self._tip.destroy()
            except Exception:
                pass
            self._tip = None


class PillButton(tk.Frame):
    """Botón moderno con variantes (primary / secondary / ghost / danger / danger_outline / danger_ghost),
    estado hover y deshabilitado. Compatible con la API de tk.Button que usa el código heredado
    (config(text=, state=, bg=, command=), cget, pack/grid)."""

    def __init__(self, parent, text: str = "", command=None, *, icon: Optional[str] = None, variant: str = "secondary",
                 size: int = 11, square: bool = False, tooltip=None, soft_disabled: bool = False):
        self._pbg = _bg_of(parent)
        super().__init__(parent, bg=self._pbg, bd=0, highlightthickness=0)
        self._cmd, self._variant, self._size, self._square, self._soft = command, variant, size, square, soft_disabled
        self._enabled, self._hover, self._override_bg = True, False, None
        self._fixed_icon = icon
        if icon is None:
            icon, text = split_icon(text)
        self._icon_name, self._text = icon, (text or "").strip()
        self._box = tk.Frame(self, bd=0, highlightthickness=1)
        self._box.pack(fill="both", expand=True)
        self._ic = tk.Label(self._box, bd=0, font=icon_font(size))
        self._tx = tk.Label(self._box, bd=0, font=self._font())
        for w in (self, self._box, self._ic, self._tx):
            w.bind("<Enter>", self._enter, add="+")
            w.bind("<Leave>", self._leave, add="+")
            w.bind("<ButtonRelease-1>", self._click, add="+")
            tk.Frame.configure(w, cursor="hand2") if w is self else w.configure(cursor="hand2")
        self._tip = Tooltip(self, tooltip) if tooltip else None
        if square:
            tk.Frame.configure(self, width=px(34), height=px(34))
            self.pack_propagate(False)
            self.grid_propagate(False)
        self.container = self
        self._layout()
        self._paint()

    def _font(self):
        return (FUI, self._size, "bold" if self._variant in ("primary", "danger") else "normal")

    def _layout(self):
        self._ic.pack_forget()
        self._tx.pack_forget()
        self._tx.configure(font=self._font())
        if self._square:
            if self._icon_name:
                self._ic.configure(text=ico(self._icon_name))
                self._ic.pack(expand=True)
            else:
                self._tx.configure(text=self._text)
                self._tx.pack(expand=True)
            return
        p = px(14)
        if self._icon_name:
            self._ic.configure(text=ico(self._icon_name))
            self._ic.pack(side="left", padx=(p - px(2), px(7) if self._text else p - px(2)), pady=px(6))
        if self._text:
            self._tx.configure(text=self._text)
            self._tx.pack(side="left", padx=(0 if self._icon_name else p, p), pady=px(6))

    def _colors(self):
        pb = self._pbg
        if not self._enabled:
            return T["surface3"], T["muted"], T["surface3"]
        table = {
            "primary": (T["accent"], T["button_fg"], T["accent"], T["accent_hi"]),
            "secondary": (T["panel_bg"], T["text"], T["border_strong"], T["hover"]),
            "ghost": (pb, T["text"], pb, T["hover"]),
            "danger": (T["accent2"], "#FFFFFF", T["accent2"], T["accent2_hi"]),
            "danger_outline": (T["panel_bg"], T["err"], T["border_strong"], T["err_soft"]),
            "danger_ghost": (pb, T["err"], pb, T["err_soft"]),
        }
        bg, fg, bd, hv = table.get(self._variant, table["secondary"])
        if self._override_bg:
            bg = hv = bd = self._override_bg
        if self._hover:
            bg = hv
            if self._variant in ("primary", "danger"):
                bd = hv
        return bg, fg, bd

    def _paint(self):
        if not tk.Frame.winfo_exists(self):
            return
        bg, fg, bd = self._colors()
        self._box.configure(bg=bg, highlightbackground=bd, highlightcolor=bd)
        for w in (self._ic, self._tx):
            w.configure(bg=bg, fg=fg)

    def _enter(self, _e=None):
        if self._enabled and not self._hover:
            self._hover = True
            self._paint()

    def _leave(self, e=None):
        if not self._hover:
            return
        try:
            w = self.winfo_containing(e.x_root, e.y_root) if e is not None else None
        except Exception:
            w = None
        if w is not None and str(w).startswith(str(self)):
            return
        self._hover = False
        self._paint()

    def _click(self, e):
        try:
            w = self.winfo_containing(e.x_root, e.y_root)
        except Exception:
            w = None
        if w is None or not str(w).startswith(str(self)):
            return
        if (self._enabled or self._soft) and self._cmd:
            self._cmd()

    def set(self, text=None, icon=None, variant=None, enabled=None):
        if text is not None:
            self._text = text
        if icon is not None:
            self._icon_name = icon or None
        if variant is not None:
            self._variant = variant
        if enabled is not None:
            self._enabled = bool(enabled)
            if not self._enabled:
                self._hover = False
        self._layout()
        self._paint()

    def configure(self, cnf=None, **kw):
        if isinstance(cnf, dict):
            kw = {**cnf, **kw}
        elif cnf is not None:
            return tk.Frame.configure(self, cnf)
        relayout = False
        if "text" in kw:
            icon, text = split_icon(str(kw.pop("text")))
            self._icon_name, self._text = icon or self._fixed_icon, text
            relayout = True
        if "state" in kw:
            self._enabled = kw.pop("state") != "disabled"
            if not self._enabled:
                self._hover = False
        if "command" in kw:
            self._cmd = kw.pop("command")
        for k in ("bg", "background"):
            if k in kw:
                v = kw.pop(k)
                self._override_bg = None if not v or v == T["accent"] else v
        for k in ("fg", "foreground", "activebackground", "activeforeground", "font", "padx", "pady", "relief",
                  "bd", "borderwidth", "disabledforeground", "cursor", "image"):
            kw.pop(k, None)
        if kw:
            tk.Frame.configure(self, **kw)
        if relayout:
            self._layout()
        self._paint()

    config = configure

    def cget(self, key):
        if key == "text":
            return self._text
        if key == "state":
            return "normal" if self._enabled else "disabled"
        return tk.Frame.cget(self, key)


class ToggleSwitch(tk.Frame):
    def __init__(self, parent, text: str = "", variable: Optional[tk.Variable] = None,
                 command: Optional[Callable[[], None]] = None, bg: Optional[str] = None,
                 fg: Optional[str] = None, font=None):
        self.W, self.H = px(36), px(20)
        self._bg = bg or _bg_of(parent)
        super().__init__(parent, bg=self._bg)
        self.variable = variable if variable is not None else tk.BooleanVar(value=False)
        self._command = command
        self._canvas = tk.Canvas(self, width=self.W, height=self.H, highlightthickness=0, bd=0,
                                 bg=self._bg, cursor="hand2")
        self._canvas.pack(side="left")
        self._canvas.bind("<Button-1>", self._click)
        self._lbl = None
        if text:
            self._lbl = tk.Label(self, text=text, font=font or (FUI, 11), bg=self._bg, fg=fg or T["card_fg"],
                                 anchor="w", cursor="hand2")
            self._lbl.pack(side="left", padx=(px(8), 0))
            self._lbl.bind("<Button-1>", self._click)
        tid = self.variable.trace_add("write", lambda *_: self.winfo_exists() and self._redraw())
        self.bind("<Destroy>", lambda e: e.widget is self and self.variable.trace_remove("write", tid), add="+")
        self._redraw()

    def set_bg(self, color: str) -> None:
        self._bg = color
        self.configure(bg=color)
        self._canvas.configure(bg=color)
        if self._lbl is not None:
            self._lbl.configure(bg=color)

    def _click(self, _e=None):
        self.variable.set(not bool(self.variable.get()))
        if self._command:
            self._command()

    def _redraw(self):
        c, W, H = self._canvas, self.W, self.H
        c.delete("all")
        on = bool(self.variable.get())
        track = T["accent"] if on else T["toggle_off"]
        r = H // 2
        c.create_oval(0, 0, H, H, fill=track, outline=track)
        c.create_oval(W - H, 0, W, H, fill=track, outline=track)
        c.create_rectangle(r, 0, W - r, H, fill=track, outline=track)
        kr = r - px(3)
        kx = (W - r) if on else r
        c.create_oval(kx - kr, r - kr, kx + kr, r + kr, fill="#FFFFFF", outline="#FFFFFF")


def progress_strip(canvas: tk.Canvas, height: int) -> Callable[[float, str], None]:
    canvas.create_rectangle(0, 0, 4000, height, fill=T["border"], outline="", tags="bar_bg")
    canvas.create_rectangle(0, 0, 0, height, fill=progress_color(), outline="", tags="bar_fill")
    state = {"pct": 0.0}

    def draw(_e=None):
        canvas.coords("bar_fill", 0, 0, int(max(canvas.winfo_width(), 1) * state["pct"]), height)

    canvas.bind("<Configure>", draw)

    def update(pct: float, color: str) -> None:
        state["pct"] = pct
        if canvas.winfo_exists():
            draw()
            canvas.itemconfigure("bar_fill", fill=color)
    return update


def _sort_key(v):
    try:
        return 0, float(v)
    except (ValueError, TypeError):
        return 1, str(v).lower()


def tree_sort(tree: ttk.Treeview, col: str, reverse: bool = False) -> None:
    def get(iid):
        return tree.item(iid, "text") if col == "#0" else tree.set(iid, col)

    def level(parent):
        for idx, iid in enumerate(sorted(tree.get_children(parent), key=lambda i: _sort_key(get(i)), reverse=reverse)):
            tree.move(iid, parent, idx)
            level(iid)

    level("")
    tree.heading(col, command=lambda: tree_sort(tree, col, not reverse))


def make_tree(parent, cols, headings, height, *, tree_col=None) -> ttk.Treeview:
    outer = tk.Frame(parent, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"])
    outer.pack(fill="both", expand=True)
    tree = ttk.Treeview(outer, columns=cols, show="tree headings" if tree_col else "headings", height=height)
    if tree_col:
        tree.heading("#0", text=tree_col[0], anchor="w", command=lambda: tree_sort(tree, "#0"))
        tree.column("#0", width=px(tree_col[1]), stretch=True, anchor="w")
    for c, h in zip(cols, headings):
        txt, w, *rest = h
        anchor = rest[0] if rest else "w"
        tree.heading(c, text=txt, anchor=anchor, command=lambda col=c: tree_sort(tree, col))
        tree.column(c, width=px(w), anchor=anchor, stretch=rest[1] if len(rest) > 1 else True)
    tree.tag_configure("even", background=T["panel_bg"])
    tree.tag_configure("odd", background=T["surface2"])
    tree.pack(side="left", fill="both", expand=True)
    sb = ttk.Scrollbar(outer, command=tree.yview, orient="vertical")
    sb.pack(side="right", fill="y")
    tree.configure(yscrollcommand=sb.set)
    return tree


def clear_tree(tree: ttk.Treeview) -> None:
    tree.delete(*tree.get_children())


def stripe(tree: ttk.Treeview) -> str:
    return "odd" if len(tree.get_children()) % 2 else "even"


def tip(widget, text):
    """Ayuda contextual al pasar el mouse. Úsela para explicar lo que no es obvio, no para repetir la etiqueta."""
    if widget is not None and text:
        Tooltip(widget, text)
    return widget


def middle_ellipsis(text: str, limit: int = 48) -> str:
    """Acorta rutas largas conservando el inicio y el final (C:\\repos\\…\\servicio\\src)."""
    text = str(text or "")
    if len(text) <= limit:
        return text
    keep = max(4, (limit - 1) // 2)
    return text[:keep] + "…" + text[-(limit - keep - 1):]


def pill_label(parent, text: str, fg_role: str, bg_role: str, size: int = 9) -> tk.Label:
    """Etiqueta tipo «chip» con color semántico (severidad, estado, motor)."""
    return tk.Label(parent, text=text, font=(FUI, size, "bold"), bg=T[bg_role], fg=T[fg_role], padx=px(8), pady=px(2))


SEV_ROLES = {"critical": ("sev_critical", "err_soft"), "high": ("sev_high", "warn_soft"),
             "medium": ("sev_medium", "surface3"), "low": ("sev_low", "ok_soft"), "info": ("muted", "surface3")}
