from __future__ import annotations

import os
import sys
from datetime import datetime
from pathlib import Path

BASE = Path(__file__).resolve().parent
for p in (BASE / "core", BASE):
    if p.is_dir() and str(p) not in sys.path:
        sys.path.insert(0, str(p))

LOG_PATH = None


def log(msg: str) -> None:
    line = f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {msg}"
    print(line, flush=True)
    try:
        if LOG_PATH.exists() and LOG_PATH.stat().st_size > 512_000:
            LOG_PATH.write_text(LOG_PATH.read_text(encoding="utf-8", errors="replace")[-256_000:], encoding="utf-8")
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def main() -> int:
    global LOG_PATH
    if "--tick" not in sys.argv and "--force" not in sys.argv:
        print("Uso: scheduled_runner.py --tick   (invocado por el Programador de tareas — no se ejecuta manualmente "
              "salvo pruebas con --force)")
        return 2
    from ui_common import (DATA_DIR, DEFAULT_REPORTS, GUI_PID_FILE, SETTINGS_FILE, audit, claim_owner, pid_alive,
                           read_json, read_pid, release_owner)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    LOG_PATH = DATA_DIR / "scheduled_runner.log"
    if pid_alive(read_pid(GUI_PID_FILE)):
        return 0
    lock = DATA_DIR / ".scheduler_runner.lock"
    if pid_alive(read_pid(lock)):
        log("[scheduler] un tick anterior sigue en ejecución (escaneo largo en curso) — se omite éste.")
        return 0
    lock.write_text(str(os.getpid()), encoding="utf-8")
    try:
        root = Path((read_json(SETTINGS_FILE) or {}).get("reports_root") or DEFAULT_REPORTS)
        root.mkdir(parents=True, exist_ok=True)
        import gui_schedule_tab as sched
        store = sched.ScheduleStore(root)
        due = sorted((s for s in store.list_schedules() if s.get("enabled") and sched.is_due(s)),
                     key=lambda s: s.get("next_run_at") or "")
        if not due:
            return 0
        log(f"[scheduler] {len(due)} horario(s) vencido(s) — iniciando motor…")
        import INICIAR_SnykScannerGUI as main_mod
        try:
            main_mod.load_runtime()
        except Exception as e:
            log(f"[scheduler] no se pudieron preparar las dependencias del motor: {e!r} — se omite este tick.")
            return 0
        try:
            app = main_mod.ScannerApp(boot_warnings=[], headless=True)
        except Exception as e:
            log(f"[scheduler] no se pudo iniciar el motor en modo oculto: {e!r}")
            return 0
        try:
            for s in due:
                if not claim_owner():
                    log("[scheduler] la aplicación se abrió durante este ciclo — se cede el control al motor interno; "
                        "se detienen los horarios restantes de este tick.")
                    break
                try:
                    rec = app._inv_store.get_app(s.get("app_id", ""))
                    ok = False
                    if not rec:
                        log(f"[scheduler] la aplicación '{s.get('app_name', '?')}' ya no existe en el inventario — se "
                            "omite esta ejecución")
                    else:
                        app._apply_schedule_target(rec, s)
                        audit(root, "schedule_fire_headless", actor=app._user, app=rec.get("name", ""),
                              schedule_id=s.get("id"), stages=s.get("stages"), log=log)
                        log(f"[scheduler] disparando escaneo programado (app cerrada) para '{rec.get('name')}' "
                            f"({'+'.join(s.get('stages') or [])})")
                        try:
                            app._do_scan()
                            ok = True
                        except Exception as e:
                            log(f"[scheduler] error inesperado durante el escaneo programado: {e!r}")
                    sched.mark_run(store, s, ok)
                finally:
                    release_owner()
        finally:
            app.destroy()
        log("[scheduler] tick finalizado.")
        return 0
    except Exception as e:
        log(f"[scheduler] error no controlado en el tick: {e!r}")
        return 1
    finally:
        if read_pid(lock) == os.getpid():
            lock.unlink(missing_ok=True)


if __name__ == "__main__":
    sys.exit(main())
