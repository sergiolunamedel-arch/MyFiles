from __future__ import annotations

import queue
import time
from concurrent.futures import ThreadPoolExecutor

from ui_common import *
import admin_policy
import findings as fz
import infra_scanner
import static_scanner as ss
import tool_manager as tm
from secrets_scanner import ensure_git_secrets, scan_path, write_secrets_report

STAGE_CARDS = [("sca", "Dependencias (SCA)"), ("code", "Código (SAST)"), ("secrets", "Secretos"),
               ("container", "Contenedores"), ("iac", "Infraestructura (IaC)"), ("dast", "Web (DAST)"), ("api", "API")]
STAGE_NAMES = dict(STAGE_CARDS)
STAGE_META = {"sca": ("package", "Librerías de terceros con vulnerabilidades conocidas."),
              "code": ("code", "Fallas de seguridad en su propio código."),
              "secrets": ("key", "Contraseñas, llaves y tokens dentro del repositorio."),
              "container": ("container", "CVE y secretos en imágenes (registro, .tar o SBOM)."),
              "iac": ("iac", "Terraform, Kubernetes, Helm, Dockerfile, CloudFormation."),
              "dast": ("globe", "Ataques simulados contra la app web en ejecución."),
              "api": ("link", "Pruebas al API desde su especificación OpenAPI/Postman/GraphQL.")}
STAGE_GROUPS = (("Código fuente · repositorio", ("sca", "code", "secrets")),
                ("Infraestructura", ("container", "iac")),
                ("Aplicación en ejecución", ("dast", "api")))
STAGE_TIPS = {
    "sca": "Revisa las librerías que declara su proyecto (package.json, pom.xml, *.csproj, requirements.txt…) contra "
           "la base de vulnerabilidades de Snyk.\nNecesita: carpeta del repositorio y sesión de Snyk.",
    "code": "Analiza su código fuente en busca de inyecciones, XSS, criptografía débil, etc. (Snyk Code).\n"
            "Necesita: carpeta del repositorio y sesión de Snyk.",
    "secrets": "Busca contraseñas, llaves y tokens escritos en el código o en el historial de git. Corre en su PC, "
               "no envía el código a ningún lado.",
    "container": "Lista los paquetes del sistema operativo y librerías dentro de la imagen y los compara con CVE "
                 "conocidos. Configure las imágenes en «Contenedores».",
    "iac": "Revisa archivos de infraestructura (Terraform, Kubernetes, Helm, Dockerfile…) en busca de "
           "configuraciones inseguras: buckets públicos, contenedores como root, puertos abiertos…",
    "dast": "Navega su sitio como lo haría un atacante y prueba ataques reales. Úselo solo contra ambientes de "
            "desarrollo o QA. Configure la URL y el inicio de sesión en «Web (DAST)».",
    "api": "Llama cada endpoint de su especificación OpenAPI/Postman con datos maliciosos. Úselo solo contra "
           "ambientes de desarrollo o QA.",
}
ENGINE_TIPS = {
    "ZAP + NUCLEI": "Dos motores de código abierto en paralelo: ZAP rastrea el sitio y prueba ataques; Nuclei "
                    "busca miles de vulnerabilidades conocidas. Si ambos encuentran lo mismo, se muestra una sola vez.",
    "PROBELY": "Ciberseguridad asignó una licencia de Probely a esta aplicación. Si no está disponible, se usa "
               "ZAP + Nuclei automáticamente.",
    "TRIVY": "Trivy descarga la imagen directamente del registro (no requiere Docker instalado) y revisa sus paquetes.",
    "CHECKOV + TRIVY": "Dos motores revisan las mismas carpetas. Si ambos marcan el mismo recurso, aparece una vez "
                       "con las descripciones de los dos.",
}
_TARGET_TAB = {"container": "container", "iac": "iac", "dast": "dast", "api": "api"}
STAGE_STATUS = {"running": ("●  Ejecutando…", "warn"), "done": ("✓  Completado", "ok"),
                "failed": ("✕  Falló", "err"), "skipped": ("—  Omitido", "muted")}


class _ScanTabMixin:
    # ── Pantalla «Escanear» ──────────────────────────────────────────────────
    def _build_tab_scan(self, parent):
        pad = tk.Frame(parent, bg=T["bg"])
        pad.pack(fill="both", expand=True)
        self._auth_banner, _ = self._alert(pad, "error", "Snyk no está conectado",
                                           "SCA y SAST requieren una sesión SSO de la organización. " + SNYK_SSO_SHORT,
                                           "Iniciar sesión", self._show_auth_status_popup)
        self._cards_row = tk.Frame(pad, bg=T["bg"])
        right = tk.Frame(self._cards_row, bg=T["bg"], width=px(340))
        right.pack(side="right", fill="y", padx=(px(20), 0))
        right.pack_propagate(False)
        left_host = tk.Frame(self._cards_row, bg=T["bg"])
        left_host.pack(side="left", fill="both", expand=True)
        left = scroll_frame(left_host)
        self._stage_bar_update, self._stage_status_lbl, self._engine_chips = {}, {}, {}
        for gi, (gtitle, keys) in enumerate(STAGE_GROUPS):
            tk.Label(left, text=gtitle.upper(), font=(FUI, 9, "bold"), bg=T["bg"], fg=T["muted"]).pack(
                anchor="w", pady=(px(14) if gi else 0, px(6)))
            grid = tk.Frame(left, bg=T["bg"])
            grid.pack(fill="x")
            for c in range(3):
                grid.columnconfigure(c, weight=1, uniform="stage")
            for i, k in enumerate(keys):
                self._make_stage_card(grid, k, STAGE_NAMES[k], 0, i)
        prio = self._card(left, "Qué corregir primero", collapsible=False, pady=(px(14), px(6)))
        tip(prio.header, "Los hallazgos de todas las herramientas, unificados y ordenados: severidad, confirmados en "
                         "ejecución, secretos expuestos y los que ya tienen corrección disponible.")
        self._prio_box = tk.Frame(prio, bg=T["panel_bg"])
        self._prio_box.pack(fill="x")
        PillButton(prio.right, "Ver reporte completo", lambda: self._last_report and open_path(self._last_report),
                   icon="open", variant="ghost", size=10).pack(side="right")
        ready = self._card(right, "Preparación", collapsible=False)
        self._ready_box = tk.Frame(ready, bg=T["panel_bg"])
        self._ready_box.pack(fill="x")
        summary = self._card(right, "Último resultado", collapsible=False)
        self._build_summary(summary)
        self._cards_row.pack(fill="both", expand=True)
        for k, state in self._pipe_stage_states.items():
            self._paint_stage_status(k, state)
        self._refresh_engine_cards()

    def _make_stage_card(self, grid, key, name, row, col):
        icon, desc = STAGE_META[key]
        var = self._scan_vars[key]
        p = T["panel_bg"]
        tile = tk.Frame(grid, bg=p, highlightthickness=1, highlightbackground=T["border"], cursor="hand2")
        tile.grid(row=row, column=col, padx=(0, px(10)), pady=(0, px(10)), sticky="nsew")
        inner = tk.Frame(tile, bg=p, padx=px(14), pady=px(12))
        inner.pack(fill="both", expand=True)
        top = tk.Frame(inner, bg=p)
        top.pack(fill="x")
        ic = tk.Label(top, text=ico(icon), font=icon_font(16), bg=p, fg=T["muted"])
        ic.pack(side="left")

        def toggled():
            self._refresh_scan_btn()
            self._persist_scan_stages()

        sw = ToggleSwitch(top, variable=var, command=toggled, bg=p)
        sw.pack(side="right")
        nm = tk.Label(top, text=name, font=(FUI_TITLE, 12, "bold"), bg=p, fg=T["text"], anchor="w")
        nm.pack(side="left", padx=(px(10), 0))
        tip(nm, STAGE_TIPS.get(key))
        ds = autowrap(tk.Label(inner, text=desc, font=(FUI, 10), bg=p, fg=T["muted"], anchor="w", justify="left"),
                      4, 100)
        ds.pack(fill="x")
        ds.pack_configure(pady=(px(8), 0))
        foot = tk.Frame(inner, bg=p)
        foot.pack(fill="x", pady=(px(8), px(4)))
        st = tk.Label(foot, text="", font=(FUI, 9, "bold"), bg=p, fg=T["muted"], anchor="w")
        st.pack(side="left")
        chip = tk.Label(foot, text="", font=(FUI, 8, "bold"), bg=T["surface3"], fg=T["muted"], padx=px(6), pady=px(1))
        if key in ("dast", "api", "container", "iac"):
            chip.pack(side="right")
            self._engine_chips[key] = chip
            tip(chip, lambda c=chip: ENGINE_TIPS.get(c.cget("text"), ""))
        bar = tk.Canvas(inner, height=px(4), highlightthickness=0, bd=0, bg=p)
        bar.pack(fill="x")
        self._stage_bar_update[key] = progress_strip(bar, px(4))
        self._stage_status_lbl[key] = st
        parts = [tile, inner, top, ic, nm, ds, foot, st, bar]
        hover = {"on": False}

        def restyle(*_):
            if not tile.winfo_exists():
                return
            on = bool(var.get())
            bg = T["accent_soft"] if on else T["panel_bg"]
            tile.configure(highlightbackground=T["accent"] if on else T["border_strong"] if hover["on"] else T["border"])
            for w in parts:
                w.configure(bg=bg)
            ic.configure(fg=T["accent"] if on else T["muted"])
            sw.set_bg(bg)

        def click(_e=None):
            var.set(not var.get())
            toggled()

        def set_hover(on):
            hover["on"] = on
            restyle()

        tid = var.trace_add("write", restyle)
        tile.bind("<Destroy>", lambda e: e.widget is tile and var.trace_remove("write", tid), add="+")
        for w in parts:
            w.bind("<Button-1>", click)
            w.bind("<Enter>", lambda _e: set_hover(True))
            w.bind("<Leave>", lambda _e: set_hover(False))
        restyle()

    def _paint_stage_status(self, key, state):
        lbl = getattr(self, "_stage_status_lbl", {}).get(key)
        if lbl is None or not lbl.winfo_exists():
            return
        text, role = STAGE_STATUS.get(state, ("", "muted"))
        lbl.configure(text=text, fg=T[role])

    def _build_summary(self, parent):
        grid = tk.Frame(parent, bg=T["panel_bg"])
        grid.pack(fill="x")
        self._sum_vals = {}
        for i, (k, label) in enumerate((("critical", "Críticas"), ("high", "Altas"), ("medium", "Medias"),
                                         ("low", "Bajas"))):
            grid.columnconfigure(i, weight=1, uniform="sum")
            cell = tk.Frame(grid, bg=T["surface2"])
            cell.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else px(6), 0))
            v = tk.Label(cell, text="—", font=(FUI_TITLE, 17, "bold"), bg=T["surface2"], fg=T[f"sev_{k}"])
            v.pack(pady=(px(8), 0))
            tk.Label(cell, text=label, font=(FUI, 9), bg=T["surface2"], fg=T["muted"]).pack(pady=(0, px(8)))
            self._sum_vals[k] = v
        self._sum_meta = tk.Label(parent, text="", font=(FUI, 10), bg=T["panel_bg"], fg=T["muted"], anchor="w",
                                  justify="left", wraplength=px(290))
        self._sum_meta.pack(fill="x", pady=(px(12), 0))
        self._sum_open = self._btn(parent, "Abrir último reporte", lambda: self._last_report and open_path(
            self._last_report), icon="document")
        self._sum_open.pack(anchor="w", pady=(px(12), 0))

    def _refresh_summary(self):
        vals = getattr(self, "_sum_vals", None)
        if not vals or not next(iter(vals.values())).winfo_exists():
            return
        ctx, app = self._last_context, self._active_app
        counts, meta = None, "Aún no hay resultados en esta sesión."
        if ctx:
            counts = ctx.get("counts") or {}
            meta = (f"{ctx.get('generated_at', '')}  ·  {(ctx.get('scan_mode') or '').upper()}  ·  "
                    f"{ctx.get('total', 0)} hallazgo(s)" + ("  ·  INCOMPLETO" if ctx.get("incomplete") else ""))
        elif app and app.get("last_scan"):
            counts = {k: app.get(f"vuln_{k}", 0) for k in vals}
            meta = f"{app.get('name')}  ·  {str(app.get('last_scan'))[:16].replace('T', ' ')}  ·  " \
                   f"{(app.get('last_mode') or '').upper()}"
        for k, lbl in vals.items():
            lbl.configure(text=str(counts.get(k, 0)) if counts is not None else "—")
        self._sum_meta.configure(text=meta)
        self._sum_open.configure(state="normal" if self._last_report else "disabled")
        self._render_priorities()

    def _render_priorities(self):
        box = getattr(self, "_prio_box", None)
        if box is None or not box.winfo_exists():
            return
        for w in box.winfo_children():
            w.destroy()
        p = T["panel_bg"]
        items = fz.priorities(self._last_context, 6) if self._last_context else []
        if not items:
            msg = ("Sin hallazgos críticos, altos ni medios en el último escaneo. ✓" if self._last_context else
                   "Ejecute un escaneo: aquí verá lo más importante que corregir, sin importar qué herramienta lo "
                   "encontró.")
            tk.Label(box, text=msg, font=(FUI, 10), bg=p, fg=T["muted"], anchor="w", justify="left").pack(fill="x")
            return
        kind_es = {"sca": "Dependencia", "code": "Código", "secrets": "Secreto", "container": "Contenedor",
                   "iac": "IaC", "dast": "Web", "api": "API"}
        for i, u in enumerate(items):
            row = tk.Frame(box, bg=p)
            row.pack(fill="x", pady=(0 if not i else px(8), 0))
            if i:
                tk.Frame(box, bg=T["border"], height=1).pack(fill="x", before=row, pady=(px(8), 0))
            fg, bg = SEV_ROLES.get(u["severity"], SEV_ROLES["low"])
            left = tk.Frame(row, bg=p, width=px(84))
            left.pack(side="left", fill="y")
            left.pack_propagate(False)
            pill_label(left, SEV_ES.get(u["severity"], u["severity"]), fg, bg).pack(anchor="w")
            tk.Label(left, text=kind_es.get(u["kind"], u["kind"]).upper(), font=(FUI, 8, "bold"), bg=p,
                     fg=T["muted"]).pack(anchor="w", pady=(px(4), 0))
            col = tk.Frame(row, bg=p)
            col.pack(side="left", fill="x", expand=True)
            autowrap(tk.Label(col, text=u["title"], font=(FUI, 10, "bold"), bg=p, fg=T["text"], anchor="w",
                              justify="left"), 8, 160).pack(fill="x")
            tk.Label(col, text=middle_ellipsis(u["location"], 80), font=(FMONO, 9), bg=p, fg=T["muted"],
                     anchor="w").pack(fill="x")
            if u["fix"]:
                autowrap(tk.Label(col, text="→ " + u["fix"][:220], font=(FUI, 9), bg=p, fg=T["ok"], anchor="w",
                                  justify="left"), 8, 160).pack(fill="x", pady=(px(2), 0))
            tags = tk.Frame(row, bg=p)
            tags.pack(side="right", anchor="n")
            if u.get("confirmed"):
                tip(pill_label(tags, "Confirmado en ejecución", "select_fg", "select", 8),
                    "El mismo tipo de falla (CWE) apareció en el código y también en la aplicación en ejecución: "
                    "es explotable. Corríjalo primero.").pack(anchor="e", pady=(0, px(3)))
            tk.Label(tags, text=" · ".join(u["detected_by"][:3]), font=(FUI, 8), bg=p, fg=T["muted"]).pack(anchor="e")

    def _readiness(self) -> list:
        sel = {k for k, v in self._scan_vars.items() if v.get()}
        out = [("ok" if sel else "fail", "Al menos una etapa seleccionada", None)]
        if {"sca", "code"} & sel:
            ok = self._snyk_auth_ok()
            out.append(("ok" if ok else "fail", "Sesión SSO de Snyk activa" if ok else "Inicie sesión en Snyk (SSO)",
                        self._show_auth_status_popup, "Iniciar sesión",
                        "SCA y SAST usan la organización de Snyk del banco. " + SNYK_SSO_WARNING))
        if set(STATIC_STAGES) & sel:
            ok = self._has_static_target()
            out.append(("ok" if ok else "fail", "Carpeta del repositorio" if ok else
                        "Agregue la carpeta del repositorio", lambda: self._show_tab("static"), "Agregar",
                        "La carpeta raíz de su proyecto (donde está el package.json, pom.xml o .sln)."))
        if "container" in sel:
            n = len(self._container_sources_clean())
            out.append(("ok" if n else "fail", f"{n} imagen(es) a analizar" if n else "Agregue una imagen, .tar o SBOM",
                        lambda: self._show_tab("container"), "Agregar"))
        if "iac" in sel:
            paths = self._iac_paths_effective()
            out.append(("ok" if paths else "fail", "Carpeta de IaC" + (" (la del repositorio)" if paths and not
                                                                      self._iac_paths else "") if paths else
                        "Agregue la carpeta de IaC", lambda: self._show_tab("iac"), "Agregar"))
        if "dast" in sel:
            url = getattr(self, "_dast_url_var", None)
            ok = bool(url and url.get().strip() not in ("", "https://", "http://"))
            out.append(("ok" if ok else "fail", "URL de la aplicación web" if ok else "Indique la URL de la aplicación web",
                        lambda: self._show_tab("dast"), "Configurar"))
        if "api" in sel:
            spec, base = getattr(self, "_api_spec_var", None), getattr(self, "_api_base_var", None)
            ok = bool((spec and spec.get().strip()) or (base and base.get().strip()))
            out.append(("ok" if ok else "fail", "Especificación o URL del API" if ok else
                        "Indique la especificación o URL del API", lambda: self._show_tab("api"), "Configurar"))
        if {"dast", "api", "container", "iac", "secrets"} & sel:
            engine, _ = admin_policy.engine_label(self._active_app)
            if {"dast", "api"} & sel and engine == "probely":
                out.append(("ok", "Web y API con Probely (asignado por Ciberseguridad)", None, None,
                            "Si Probely no está disponible se usa ZAP + Nuclei automáticamente."))
            cache_list = getattr(self, "_engine_cache", None)
            cache = {st.key: st for st in cache_list or []}
            need = {t for k in sel for t in tm.STAGE_TOOLS.get(k, ()) if not (engine == "probely" and k in ("dast", "api"))}
            need |= {d for t in list(need) for d in tm.NEEDS.get(t, ())}
            missing = [tm.LABELS[t] for t in sorted(need) if t in cache and not cache[t].installed]
            names = ", ".join(tm.LABELS[t] for t in sorted(need) if t != "jre")
            if need and cache_list is None:
                out.append(("info", "Verificando motores de escaneo…", None))
            elif missing:
                out.append(("info", "Se descargará al iniciar: " + ", ".join(missing), self._show_engines_popup,
                            "Preparar", "La primera vez se descargan (verificados con SHA-256) y tardan unos minutos. "
                            "Pulse «Preparar» para hacerlo ahora y que el escaneo empiece de inmediato."))
            elif need:
                out.append(("ok", f"Motores listos: {names}", None))
            if engine == "probely" and self._is_admin and self._probely_auth_status != "auth":
                out.append(("warn", "Clave de Probely sin validar", lambda: self._show_tab("admin")))
        snow = getattr(self, "_snow_state", "none")
        snow_help = ("Con sus credenciales, cada hallazgo alto o crítico crea o actualiza un ticket en ServiceNow. "
                     "Se guardan cifradas y solo funcionan con su cuenta de Windows.")
        level, text, action = {
            "ok": ("ok", "Tickets de ServiceNow automáticos", "Cambiar"),
            "checking": ("info", "Verificando la conexión con ServiceNow…", None),
            "invalid": ("warn", "ServiceNow rechazó sus credenciales — no se crearán tickets", "Corregir"),
            "unverified": ("warn", "No se pudo conectar con ServiceNow — los tickets pueden fallar", "Revisar"),
        }.get(snow, ("info", "Configure ServiceNow para crear tickets de hallazgos altos y críticos", "Configurar"))
        detail = getattr(self, "_snow_detail", "")
        out.append((level, text, self._show_servicenow_setup if action else None, action,
                    f"{detail}\n\n{snow_help}" if detail and snow in ("invalid", "unverified", "ok") else snow_help))
        app_ok = bool(self._active_app and self._active_app.get("name"))
        out.append(("ok" if app_ok else "info", f"Aplicación: {self._active_app['name']}" if app_ok else
                    "Sin aplicación — los resultados no se catalogan", lambda: self._show_tab("apps"), "Elegir",
                    "La aplicación agrupa los reportes, el historial y la tendencia. Sin ella, el reporte queda en "
                    "la carpeta «_unscoped»."))
        return out

    def _refresh_engine_cards(self):
        chips = getattr(self, "_engine_chips", {})
        engine, _ = admin_policy.engine_label(self._active_app)
        names = {"dast": "PROBELY" if engine == "probely" else "ZAP + NUCLEI",
                 "api": "PROBELY" if engine == "probely" else "ZAP + NUCLEI", "container": "TRIVY",
                 "iac": "CHECKOV + TRIVY"}
        for k, chip in chips.items():
            if chip.winfo_exists():
                chip.configure(text=names[k], fg=T["border2"] if engine == "probely" and k in ("dast", "api") else T["muted"])
        if hasattr(self, "_refresh_engine_badge_text"):
            self._refresh_engine_badge_text()

    def _render_readiness(self, items) -> None:
        box = getattr(self, "_ready_box", None)
        if box is None or not box.winfo_exists():
            return
        for w in box.winfo_children():
            w.destroy()
        p = T["panel_bg"]
        glyphs = {"ok": ("check", "ok"), "fail": ("close", "err"), "warn": ("warn", "warn"), "info": ("info", "muted")}
        for item in items:
            level, text, fix, action, help_ = (tuple(item) + (None, None))[:5]
            row = tk.Frame(box, bg=p)
            row.pack(fill="x", pady=px(4))
            g, role = glyphs[level]
            tk.Label(row, text=ico(g), font=icon_font(10), bg=p, fg=T[role], width=2).pack(side="left", anchor="n",
                                                                                         pady=(px(2), 0))
            lbl = tk.Label(row, text=text, font=(FUI, 10), bg=p, fg=T["muted"] if level in ("ok", "info") else T["text"],
                           anchor="w", justify="left", wraplength=px(200))
            lbl.pack(side="left", fill="x", expand=True)
            tip(lbl, help_)
            if fix and (level != "ok" or action == "Cambiar"):
                link = tk.Label(row, text=action or "Resolver", font=(FUI, 10, "bold"), bg=p, fg=T["border2"],
                                cursor="hand2")
                link.pack(side="right", anchor="n")
                link.bind("<Button-1>", lambda _e, f=fix: f())

    # ── Progreso ─────────────────────────────────────────────────────────────
    def _paint_card(self, key, pct, color=None):
        if fn := getattr(self, "_stage_bar_update", {}).get(key):
            fn(pct, color or (T["err"] if self._pipe_stage_states.get(key) == "failed" else progress_color()))

    def _pipeline_reset(self):
        self._pipe_stage_states, self._pipe_card_pcts = {}, {}
        self._pipe_progress_pct = 0.0
        self._static_route = (0, 1)
        for k in self.PROGRESS_TABS:
            self._set_ribbon_tab_progress(k, 0.0)
        for fn in self._stage_bar_update.values():
            fn(0.0, T["border"])
        for k in getattr(self, "_stage_status_lbl", {}):
            self._paint_stage_status(k, None)

    def _static_route_start(self, idx, total, keys):
        self._static_route = (idx, total)
        for k in keys:
            self._pipe_card_pcts[k] = 0.0
        self._recompute_progress()

    def _on_stage(self, key: str, state: str):
        self._pipe_stage_states[key] = state
        self._paint_stage_status(key, state)
        if state == "running":
            if key in ("sca", "code"):
                self._pulse(key)
        else:
            self._pipe_card_pcts[key] = 1.0 if state in ("done", "failed") else 0.0
            self._paint_card(key, self._pipe_card_pcts[key])
        self._recompute_progress()

    def _pulse(self, key):
        def tick():
            if self._pipe_stage_states.get(key) != "running":
                return
            self._pipe_card_pcts[key] = min(self._pipe_card_pcts.get(key, 0.0) + 0.015, 0.90)
            self._paint_card(key, self._pipe_card_pcts[key])
            self._recompute_progress()
            self.after(400, tick)
        self.after(400, tick)

    def _update_card_progress(self, key: str, done: int, total: int):
        if total > 0:
            self._pipe_card_pcts[key] = min(done / total, 0.99)
            self._paint_card(key, self._pipe_card_pcts[key])
            self._recompute_progress()

    def _update_play_ring(self, pct: float) -> None:
        self._play_ring_pct = max(0.0, min(1.0, pct))
        self._paint_cta()

    def _recompute_progress(self):
        sel = {k for k, v in self._scan_vars.items() if v.get()}
        active = [k for k in self._pipe_stage_states if k in sel]

        def lane(keys):
            ks = [k for k in active if k in keys]
            return sum(self._pipe_card_pcts.get(k, 0.0) for k in ks) / len(ks) if ks else 0.0

        general = lane(STAGES)
        self._pipe_progress_pct = general
        self._update_play_ring(general)
        idx, total = self._static_route
        st = lane(STATIC_STAGES)
        self._set_ribbon_tab_progress("scan", general)
        self._set_ribbon_tab_progress("static", (idx + st) / total if total > 1 else st)
        self._set_ribbon_tab_progress("dast", lane({"dast"}))
        self._set_ribbon_tab_progress("api", lane({"api"}))
        self._set_ribbon_tab_progress("container", lane({"container"}))
        self._set_ribbon_tab_progress("iac", lane({"iac"}))

    def _has_static_target(self) -> bool:
        return bool(self._static_paths) or bool(self._target_var.get().strip())

    def _snyk_auth_ok(self) -> bool:
        a = self._checks.get("auth")
        return bool(a and a.ok)

    def _refresh_scan_btn(self):
        items = self._readiness()
        self._play_ready = not any(it[0] == "fail" for it in items)
        busy = self._any_busy()
        self._render_readiness(items)
        self._refresh_summary()
        self._update_play_ring(self._play_ring_pct)
        auth_ok = self._snyk_auth_ok()
        for b in getattr(self, "_static_run_btns", []):
            if b.winfo_exists():
                self._set_icon_btn_enabled(b, self._has_static_target() and auth_ok and not busy)

    def _refresh_auth_banner(self, auth_ok: bool) -> None:
        b = getattr(self, "_auth_banner", None)
        if b is None or not b.winfo_exists():
            return
        if auth_ok:
            b.pack_forget()
        elif not b.winfo_ismapped():
            b.pack(fill="x", pady=(0, px(12)), before=self._cards_row)

    # ── Autenticación Snyk ───────────────────────────────────────────────────
    def _recheck(self):
        self._ui(self._apply_checks, {"auth": ss.check_auth()})

    def _apply_checks(self, results: dict):
        self._checks = results
        res = results.get("auth")
        ok = bool(res and res.ok)
        if ok and not any(k in (res.detail or "").lower() for k in ("sso", "oauth")):
            ok = False
            self._log_line("[auth] ⚠ Se detectó un token de API pero NO una sesión SSO/OAuth. Haga clic en «Snyk» "
                           "(arriba a la derecha) → Re-iniciar sesión y, en la ventana de Snyk, elija 'Iniciar sesión "
                           "con SSO'. Un token simple no basta para escanear en la organización.")
            self._checks = {"auth": ss.CheckResult("Snyk auth", False, "⚠ Token detectado — se requiere SSO", True)}
        self._set_key_status("auth" if ok else "unauth")
        self._refresh_auth_banner(ok)
        self._refresh_scan_btn()

    def _prompt_relogin(self):
        if self._relogin_prompted:
            return
        self._relogin_prompted = True
        self._set_status("Sesión de Snyk expirada — haga clic en «Snyk» → Re-iniciar sesión")
        self._log_line("[auth] ⚠ Snyk rechazó la credencial guardada (expirada o inválida). Haga clic en «Snyk» "
                       "(arriba a la derecha) → vuelva a iniciar sesión con el SSO de su organización y repita el escaneo.")
        self._set_key_status("unauth")

    def _clean_reinstall_snyk(self):
        if self._any_busy():
            return self._emit_log("[ocupado] se ignora la reinstalación limpia — otra operación en curso")
        self._show_confirm_popup(
            "¿Reinstalar Snyk desde cero?",
            "Esto desinstala la CLI de Snyk actual, borra su configuración local (incluida la sesión guardada) y "
            "descarga la versión más reciente. Tendrá que volver a iniciar sesión SSO antes de escanear.\n\nNo borra "
            "sus reportes ni las aplicaciones configuradas.",
            on_yes=lambda: self._run_async(self._do_clean_reinstall_snyk, "reinstalación limpia de Snyk"),
            yes_label="🧹  Reinstalar", no_label="Cancelar")

    def _do_clean_reinstall_snyk(self):
        ok = ss.reinstall_snyk_clean(self._emit_log)
        self._relogin_prompted = False
        self._ui(self._set_key_status, "unauth")
        self._emit_log("[snyk] reinstalación limpia completa — inicie sesión antes de escanear." if ok else
                       "[snyk] la reinstalación limpia no terminó bien — revise el registro anterior.")
        self._recheck()

    def _do_login(self):
        self._relogin_prompted = False
        if self._auth_proc and self._auth_proc.poll() is None:
            self._emit_log("[auth] cancelando el intento anterior e iniciando uno nuevo…")
            kill_process_tree(self._auth_proc)
            self._auth_proc = None
        self._ui(self._show_snyk_login_popup)

    def _show_snyk_login_popup(self):
        popup = self._popup("Iniciar sesión en Snyk (SSO)")
        raw_close = popup.close
        st = {"closed": False, "ready": False, "launched": False, "spin": None, "i": 0}

        def close(success=False):
            if st["closed"]:
                return
            st["closed"] = True
            self._login_popup_close = None
            raw_close()
            if not success:
                self._run_async(self._recheck, "verificación tras inicio de sesión")

        popup.close = close
        self._login_popup_close = lambda: close(True)
        popup._win.bind("<Escape>", lambda _e: close())
        self._popup_hdr(popup, "Iniciar sesión en Snyk", subtitle="Autenticación con el SSO de su organización",
                        icon_image=self._load_status_icon("snyk"))
        bg = T["bg"]
        body = tk.Frame(popup, bg=bg, padx=px(24), pady=px(4))
        body.pack(fill="both", expand=True)
        warn, _ = self._alert(body, "error", SNYK_SSO_TITLE, SNYK_SSO_WARNING)
        warn.pack(fill="x", pady=(0, px(12)))
        self._limit_wrap(warn, px(560))
        steps = (("Se abrirá su navegador en unos segundos.", None),
                 ("Haga clic en «Log in with SSO».", "NO use el formulario de correo y contraseña, ni Google, GitHub o "
                                                     "Microsoft."),
                 ("Ya dentro de la pantalla de SSO, escriba su correo corporativo o el dominio bancobase.com.",
                  "Lo enviará al inicio de sesión del banco; entre ahí con su usuario de red."),
                 ("Complete la autenticación y regrese aquí.", "Esta ventana se cierra sola al terminar."))
        for i, (title, note) in enumerate(steps, 1):
            row = tk.Frame(body, bg=bg)
            row.pack(fill="x", pady=px(6))
            d = px(26)
            c = tk.Canvas(row, width=d, height=d, bg=bg, highlightthickness=0, bd=0)
            c.create_oval(0, 0, d - 1, d - 1, fill=T["accent_soft"], outline="")
            c.create_text(d // 2, d // 2, text=str(i), font=(FUI, 10, "bold"), fill=T["text"])
            c.pack(side="left", anchor="n", padx=(0, px(12)))
            col = tk.Frame(row, bg=bg)
            col.pack(side="left", fill="x", expand=True)
            tk.Label(col, text=title, font=(FUI, 11, "bold" if i == 2 else "normal"), bg=bg, fg=T["text"],
                     anchor="w").pack(fill="x")
            if note:
                tk.Label(col, text=note, font=(FUI, 10), bg=bg, fg=T["muted"], anchor="w").pack(fill="x")

        def spin():
            if st["closed"] or st["launched"]:
                return
            st["i"] += 1
            status.config(text=f"{'◐◓◑◒'[st['i'] % 4]}  Preparando la sesión SSO, por favor espere…", fg=T["muted"])
            st["spin"] = popup._win.after(160, spin)

        def launch():
            st["launched"] = True
            status.config(text="Navegador abierto — esperando que complete el inicio de sesión…", fg=T["muted"])
            self._spawn_snyk_auth()

        def prepare():
            try:
                self._prepare_snyk_cli()
            finally:
                st["ready"] = True
                self._ui(lambda: not st["closed"] and not st["launched"] and launch())

        def reopen():
            if st["ready"]:
                launch()

        _, status = self._popup_foot(popup, ("Cerrar", close), ("🌐  Abrir navegador de nuevo", reopen),
                                     with_status=True)
        spin()
        threading.Thread(target=prepare, daemon=True).start()

    def _prepare_snyk_cli(self):
        try:
            ss.setup_proxy_tls_env(self._emit_log)
            if not which("snyk") or not ss.ensure_snyk_ready(self._emit_log):
                self._emit_log("[auth] la CLI de Snyk aún no se puede ejecutar y no se pudo reparar automáticamente. "
                               "Si su red usa un proxy con inspección TLS, configure NODE_EXTRA_CA_CERTS con el "
                               "certificado raíz (.pem) de su empresa e intente de nuevo.")
            else:
                ss.clear_snyk_credentials(self._emit_log)
                self._ui(self._set_status, "Abriendo navegador para Snyk SSO…")
        except Exception as e:
            self._emit_log(f"[auth] error al preparar la CLI: {e!r}")

    def _spawn_snyk_auth(self):
        try:
            if self._auth_proc is not None and self._auth_proc.poll() is None:
                kill_process_tree(self._auth_proc)
            self._auth_lines = queue.Queue()
            self._auth_proc = proc = ss.start_snyk_auth(self._emit_log)
            self._auth_deadline = time.time() + AUTH_POLL_TIMEOUT
        except Exception as e:
            return self._emit_log(f"[auth] no se pudo iniciar snyk auth: {e!r}")

        def reader():
            try:
                for line in iter(proc.stdout.readline, ""):
                    self._auth_lines.put(line)
            except Exception:
                pass
        threading.Thread(target=reader, daemon=True).start()

    def _begin_snyk_auth(self):
        self._relogin_prompted = False
        self._prepare_snyk_cli()
        self._spawn_snyk_auth()

    def _show_auth_status_popup(self):
        res = self._checks.get("auth")
        ok = bool(res and res.ok)
        if ok:
            icon, title, detail = "✓", "Autenticado", res.detail or "Sesión SSO activa."
        else:
            icon, title = "✕", "Sin autenticación"
            detail = (res.detail if res else None) or "No se detectó una sesión de Snyk."
        popup = self._popup("Autenticación Snyk")
        self._popup_hdr(popup, "Autenticación Snyk", subtitle="Estado de la sesión SSO",
                        icon_image=self._load_status_icon("snyk"))
        self._centered_msg(popup, icon, T["ok"] if ok else T["err"], title, detail, T["text"])
        note = tk.Frame(popup, bg=T["bg"], padx=px(24), pady=px(4))
        note.pack(fill="x")
        warn, _ = self._alert(note, "warn" if ok else "error", SNYK_SSO_TITLE, SNYK_SSO_WARNING + (
            "\n\nSi un escaneo dice que no tiene acceso a la organización, probablemente entró con su correo: pulse "
            "«Re-iniciar sesión» y use SSO." if ok else ""))
        warn.pack(fill="x", pady=(0, px(8)))
        self._limit_wrap(warn, px(560))

        def go(fn, label):
            popup.close()
            self._set_key_status("checking")
            self._run_async(fn, label)
        self._popup_foot(popup,
                         ("🧹  Reinstalar (limpio)", lambda: (popup.close(), self._clean_reinstall_snyk())),
                         ("🔄  Verificar", lambda: go(self._recheck, "verificación de entorno")),
                         ("🔁  Re-iniciar sesión" if ok else "🔑  Iniciar sesión SSO",
                          lambda: go(self._do_login, "snyk auth")),
                         ("Cerrar", popup.close),
                         primary=None if ok else "🔑  Iniciar sesión SSO")

    def _kick_auth_check(self):
        if self._auth_check_inflight:
            return
        self._auth_check_inflight = True

        def bg():
            try:
                res = ss.check_auth()
            except Exception:
                res = None
            self._ui(self._on_auth_check, res)
        threading.Thread(target=bg, daemon=True).start()

    def _on_auth_check(self, res):
        self._auth_check_inflight = False
        if res is None:
            self._set_key_status("unauth")
        else:
            if res.ok:
                self._log_line("[auth] autenticado.")
                if self._auth_proc is not None:
                    kill_process_tree(self._auth_proc)
                    self._auth_proc = None
                if callable(self._login_popup_close):
                    self._login_popup_close()
            self._apply_checks({"auth": res})
        self._set_idle_status()

    def _tick_auth_poll(self):
        proc = self._auth_proc
        while True:
            try:
                self._log_line(self._auth_lines.get_nowait().rstrip())
            except queue.Empty:
                break
        now = time.time()
        if now >= self._next_auth_check:
            self._next_auth_check = now + AUTH_POLL_INTERVAL
            self._kick_auth_check()
        if proc.poll() is not None:
            self._log_line(f"[auth] snyk auth terminó ({proc.returncode})")
            self._auth_proc = None
            self._run_async(self._recheck, "verificación post-auth")
        elif now > self._auth_deadline:
            self._log_line("[auth] tiempo de espera agotado — cancelando.")
            kill_process_tree(proc)
            self._auth_proc = None

    # ── Ejecución del pipeline ───────────────────────────────────────────────
    def _start_scan(self):
        sel = {k for k, v in self._scan_vars.items() if v.get()}
        if not (self._active_app and self._active_app.get("name")) and sel & set(STATIC_STAGES) and sel & {"dast", "api"} \
                and not self._has_static_target():
            dropped = [k for k in STATIC_STAGES if k in sel]
            for k in dropped:
                self._scan_vars[k].set(False)
            self._persist_scan_stages()
            self._refresh_scan_btn()
            names = ", ".join(STAGE_NAMES[k] for k in dropped)
            self._emit_log(f"[escaneo] {names} deseleccionado(s) — necesitan una aplicación cargada (ruta de objetivo) "
                           "y no hay ninguna activa. Se continúa solo con las etapas web/API seleccionadas.")
            self._show_info_popup("Etapas estáticas omitidas",
                f"{names} necesitan una aplicación cargada (ruta de objetivo) y no hay ninguna activa, así que se "
                "deseleccionaron.\n\nSe continúa solo con las etapas web/API seleccionadas, si cumplen sus propios "
                "requisitos.")
            return self._run_scan_pipeline()
        self._confirm_scan_without_app(self._run_scan_pipeline)

    def _run_scan_pipeline(self):
        self._run_async(self._do_scan, "escaneo completo de pipeline")

    def _request_cancel(self):
        if not self._any_busy():
            return self._emit_log("[escaneo] nada que cancelar.")
        self._show_confirm_popup("¿Detener escaneo?",
                                 "Hay un escaneo en ejecución. Detenerlo descartará los resultados que aún no se "
                                 "hayan guardado.",
                                 on_yes=self._do_cancel, yes_label="■  Detener escaneo", no_label="Continuar")

    def _do_cancel(self):
        if not self._any_busy():
            return
        if self._busy:
            self._cancel_evt.set()
        if self._static_busy:
            self._static_cancel_evt.set()
        self._emit_log("[escaneo] cancelación solicitada…")
        self._set_status("Cancelando…")
        audit(self._reports_var.get(), "scan_cancel_requested", actor=self._user, log=self._emit_log)

    def _web_runner(self, kind: str, cfg):
        """Elige el motor web/API: Probely solo si Ciberseguridad asignó la aplicación; si no, ZAP + Nuclei."""
        from oss_web_scanner import run_oss_api, run_oss_dast
        oss = run_oss_dast if kind == "dast" else run_oss_api
        engine, _ = admin_policy.engine_label(self._active_app)
        if engine != "probely":
            return oss

        def probely_then_fallback(c, out_dir, log, cancel=None, progress=None):
            from probely_engine import check_snyk_api_web, run_probely_api, run_probely_dast
            c.probely_token = admin_policy.probely_key()
            ok, msg = check_snyk_api_web(c, log)
            self._ui(self._set_probely_status, "auth" if ok else "unauth")
            if ok:
                log(f"[{kind}] motor asignado por Ciberseguridad: Probely ({msg})")
                res, path = (run_probely_dast if kind == "dast" else run_probely_api)(c, out_dir, log, cancel=cancel,
                                                                                        progress=progress)
                failed = any(str(f.get("title", "")).startswith("Falló el escaneo de Snyk API") for f in
                             res.get("findings") or [])
                if not failed:
                    return res, path
                msg = next((f.get("evidence", "") for f in res.get("findings") or []), "")[:200]
            if not admin_policy.probely_fallback():
                raise RuntimeError(f"Probely no está disponible y la política no permite usar otro motor: {msg}")
            log(f"[{kind}] Probely no disponible ({msg}) — se usa ZAP + Nuclei automáticamente.")
            return oss(c, out_dir, log, cancel=cancel, progress=progress)
        return probely_then_fallback

    def _scoped_report_paths(self, reports_root: Path):
        s = slug(self._active_app["name"]) if self._active_app and self._active_app.get("name") else ""
        root = reports_root / (s or "_unscoped")
        root.mkdir(parents=True, exist_ok=True)
        return (f"{self._user}+{s}" if s else self._user), root

    def _do_scan(self):
        sel = {k for k, v in self._scan_vars.items() if v.get()}
        if not sel:
            return self._emit_log("[escaneo] nada seleccionado")
        self._cancel_evt.clear()
        raw = self._target_var.get().strip()
        needs_folder = bool(set(STATIC_STAGES) & sel)
        if needs_folder and not raw and self._static_paths:
            raw = self._static_paths[0]
            self._ui(self._target_var.set, raw)
            self._emit_log(f"[escaneo] usando carpeta de la pestaña Estático: {raw}")
        if needs_folder and not raw:
            return self._emit_log("[escaneo] sin carpeta objetivo — seleccione una carpeta antes de escanear "
                                  "(SCA/SAST/Secretos la necesitan)")
        if not raw and "iac" in sel and self._iac_paths_effective():
            raw = self._iac_paths_effective()[0]
        target = Path(raw).resolve() if raw else Path(".").resolve()
        if {"sca", "code"} & sel and not target.is_dir():
            return self._emit_log(f"[escaneo] carpeta objetivo no encontrada: {target}")
        if needs_folder and target.is_dir() and not dir_has_files(target):
            return self._emit_log(f"[escaneo] ⚠ carpeta objetivo vacía (sin archivos): {target} — nada que escanear")
        self._ui(self._pipeline_reset)
        self._execute_scan(lane="pipeline", target=target, sel=sel, cancel=self._cancel_evt, batch=[target])

    def _execute_scan(self, *, lane: str, target: Path, sel: set, cancel: threading.Event,
                      batch: list, route: tuple = (0, 1)) -> dict:
        reports_root = Path(self._reports_var.get()).resolve()
        reports_root.mkdir(parents=True, exist_ok=True)
        app = self._active_app
        app_name = app.get("name", "") if app else ""
        label, app_root = self._scoped_report_paths(reports_root)
        mode = "+".join(sorted(sel))
        out_dir = app_root / f"report_{ts()}_{mode}"
        out_dir.mkdir(parents=True, exist_ok=True)
        tag = "estático" if lane == "static" else "escaneo"
        self._session_begin(lane, sel)
        audit(reports_root, "scan_start", actor=self._user, app=app_name, mode=mode, target=str(target),
              out_dir=str(out_dir), lane=lane, log=self._emit_log)
        self._emit_log(f"[{tag}] pipeline: {mode.upper()}")
        self._emit_log(f"[{tag}] salida → {out_dir}")
        try:
            snyk_ok = True
            if {"sca", "code"} & sel:
                try:
                    if not ss.ensure_snyk_ready(self._emit_log):
                        snyk_ok = False
                        self._emit_log(f"[{tag}] la CLI de Snyk no se puede ejecutar — se omiten SCA/SAST. "
                                       "Use «Snyk» → Reinstalar (limpio) para repararla.")
                except Exception as e:
                    self._emit_log(f"[{tag}] error al verificar Snyk: {e!r}")
            try:
                version = run([which("snyk") or "snyk", "--version"]).stdout.strip()
            except Exception:
                version = "?"
            results = dict.fromkeys(STAGES)
            failed: dict[str, str] = {}
            if lane == "static":
                self._ui(self._static_route_start, *route, [k for k in STATIC_STAGES if k in sel])
            for k in (STATIC_STAGES if lane == "static" else INFRA_STAGES if lane == "infra" else STAGES):
                self._ui(self._on_stage, k, "running" if k in sel and (snyk_ok or k not in ("sca", "code")) else "skipped")
            jobs = self._build_jobs(sel, snyk_ok, target, out_dir, results, cancel)
            self._run_jobs(jobs, failed, tag)
            self._diagnose_failures(failed)
            for k in ("dast", "api"):
                self._report_dynamic(k, results.get(k))
            ctx = self._finalize_report(target=target, sel=sel, mode=mode, version=version, results=results,
                                        failed=failed, reports_root=reports_root, out_dir=out_dir, label=label,
                                        batch=batch)
            report = ctx["_report_path"]
            audit(reports_root, "scan_end", actor=self._user, app=app_name, mode=mode, total=ctx["total"],
                  counts=ctx["counts"], gate=ctx["_gate"], report=str(report), lane=lane,
                  failed_stages=sorted(failed), incomplete=bool(failed), cancelled=cancel.is_set(), log=self._emit_log)
            self._ui(self._on_static_results, ctx)
            self._ui(self._on_report, report, route[1] == 1)
            tickets = ctx.get("servicenow_tickets") or []
            return {"path": str(target), "scanned": True, "report_path": str(report), "counts": dict(ctx["counts"]),
                    "total": ctx["total"], "ticket": tickets[0].get("number") if tickets else None}
        except Exception as e:
            self._emit_log(f"[{tag}] el escaneo falló: {e!r}")
            audit(reports_root, "scan_failed", actor=self._user, app=app_name, mode=mode, lane=lane, error=repr(e),
                  log=self._emit_log)
            self._ui(self._on_static_results, None)
            return {"path": str(target), "scanned": False, "reason": f"error: {e}"}
        finally:
            self._session_end(lane)

    def _build_jobs(self, sel, snyk_ok, target, out_dir, results, cancel):
        jobs = []
        prog = lambda key: (lambda n, t: self._ui(self._update_card_progress, key, n, t))
        if snyk_ok and "sca" in sel:
            jobs.append(("sca", lambda: results.__setitem__("sca", ss.run_snyk_test(target, out_dir, self._emit_log)[0])))
        if snyk_ok and "code" in sel:
            jobs.append(("code", lambda: results.__setitem__("code", ss.run_snyk_code(target, out_dir, self._emit_log)[0])))
        if "secrets" in sel:
            def secrets():
                self._emit_log("[secretos] ejecutando escaneo de secretos…")
                gs = ensure_git_secrets(self._emit_log)  # se descarga aquí si falta, igual que Trivy o Checkov
                r = scan_path(target, self._emit_log, cancel=cancel, git_secrets_status=gs, progress=prog("secrets"))
                write_secrets_report(r, out_dir / "secrets")
                self._emit_log(f"[secretos] {r['total']} hallazgo(s) en {r['scanned_files']} archivo(s)")
                results["secrets"] = r
            jobs.append(("secrets", secrets))
        if "container" in sel:
            ccfg = self._collect_container_cfg()
            jobs.append(("container", lambda: results.__setitem__("container", infra_scanner.run_container_scan(
                ccfg, out_dir, self._emit_log, cancel=cancel, progress=prog("container"))[0])))
        if "iac" in sel:
            icfg = self._collect_iac_cfg()
            if not icfg.iac_paths:
                self._emit_log("[iac] sin carpeta de IaC — se omite")
                self._ui(self._on_stage, "iac", "skipped")
            else:
                jobs.append(("iac", lambda: results.__setitem__("iac", infra_scanner.run_iac_scan(
                    icfg, out_dir, self._emit_log, cancel=cancel, progress=prog("iac"))[0])))
        for key, collect, missing in (("dast", self._collect_dast_cfg, lambda c: not c.url or c.url == "https://"),
                                      ("api", self._collect_api_cfg, lambda c: not c.spec_source and not c.base_url)):
            if key not in sel:
                continue
            cfg = collect()
            if missing(cfg):
                self._emit_log(f"[{key}] sin {'URL' if key == 'dast' else 'especificación ni URL base'} "
                               f"configurada — se omite {key.upper()}")
                self._ui(self._on_stage, key, "skipped")
                continue
            runner = self._web_runner(key, cfg)
            jobs.append((key, lambda k=key, r=runner, c=cfg: results.__setitem__(
                k, r(c, out_dir, self._emit_log, cancel=cancel, progress=prog(k))[0])))
        return jobs

    def _run_jobs(self, jobs, failed, tag):
        def run_one(job):
            key, fn = job
            try:
                fn()
                self._ui(self._on_stage, key, "done")
            except Exception as e:
                self._ui(self._on_stage, key, "failed")
                failed[key] = str(e)
                self._emit_log(f"[{tag}] {key} falló: {e!r}")
                if getattr(e, "is_auth", False) and key in ("sca", "code"):
                    self._ui(self._prompt_relogin)

        if len(jobs) > 1:
            self._emit_log(f"[{tag}] ejecutando {len(jobs)} etapas en paralelo")
            with ThreadPoolExecutor(max_workers=len(jobs)) as ex:
                list(ex.map(run_one, jobs))
        else:
            for j in jobs:
                run_one(j)
        if failed:
            self._emit_log(f"[{tag}] ⚠ {'/'.join(sorted(failed)).upper()} no se completó — el resultado es INCOMPLETO, "
                           "no lo interprete como un escaneo limpio.")

    def _diagnose_failures(self, failed: dict):
        def matching(text):
            return sorted(k for k, r in failed.items() if text in r.lower())

        if rej := matching("the request cannot be processed"):
            names = "/".join(rej).upper()
            if not getattr(self, "_snyk_auto_reinstall_done", False):
                self._snyk_auto_reinstall_done = True
                self._emit_log(f"[snyk] ⚠ Snyk rechazó la solicitud a nivel de servidor para {names} aunque la CLI local "
                               "corre sin problemas — normalmente el backend ya no acepta esta versión/instalación de "
                               "la CLI. Reinstalando automáticamente la versión más reciente (misma acción que "
                               "'Reinstalar (limpio)')…")
                try:
                    ss.reinstall_snyk_clean(self._emit_log)
                    self._emit_log("[snyk] reinstalación automática completa — inicie sesión de nuevo («Snyk», arriba "
                                   "a la derecha) antes de volver a escanear.")
                except Exception as e:
                    self._emit_log(f"[snyk] la reinstalación automática falló: {e!r}")
            else:
                self._emit_log(f"[snyk] ⚠ Snyk sigue rechazando la solicitud para {names} incluso tras la reinstalación "
                               "automática de esta sesión — puede requerir revisión manual (versión de CLI, "
                               "organización, proxy).")
        if mv := matching("cannot build maven dependency tree"):
            self._emit_log(f"[snyk] ℹ️ {'/'.join(mv).upper()}: Snyk no pudo construir el árbol de dependencias de Maven "
                           "— es un problema del proyecto/Maven, NO de Snyk ni de este programa (el mismo error ocurre "
                           "con 'snyk test' en terminal/IDE). Para diagnosticar, corra en esa carpeta: "
                           'mvn dependency:tree -DoutputType=dot --file="pom.xml" — si TAMBIÉN falla, el problema está '
                           "en Maven/el proyecto (mvn fuera del PATH, repositorio interno inalcanzable, plugin Maven "
                           "Dependency <2.2, versión de JDK, settings.xml); si funciona pero Snyk sigue fallando, es caso "
                           "para soporte de Snyk.")
        if org := matching("permissions to access the org"):
            m = re.search(r"[Oo]rg (\S+) was not found", " ".join(failed[k] for k in org))
            self._emit_log(f"[snyk] ℹ️ {'/'.join(org).upper()}: esta sesión de Snyk no tiene acceso a la organización "
                           f"{m.group(1) if m else ss.DEFAULT_SNYK_ORG}. Causa más común: se inició sesión con correo y "
                           "contraseña en vez de SSO — eso entra a una instancia PERSONAL de Snyk, no a la de la "
                           "empresa. SOLUCIÓN: clic en «Snyk» (arriba a la derecha) → 'Re-iniciar sesión' "
                           "→ en el navegador elija 'Login with SSO'. Si ya usó SSO y persiste, la cuenta puede no estar "
                           "agregada a esta organización (pertenecer al grupo de Snyk no basta) — pida a un admin de "
                           "Snyk que la agregue en Settings → Members, a nivel Organización.")

    def _report_dynamic(self, k: str, r):
        if not isinstance(r, dict):
            return
        if r.get("auth_error"):
            self._emit_log(f"[{k}] error de autenticación en Snyk API & Web — clave de Probely inválida o expirada "
                           "(Ciberseguridad debe revisarla en Administración).")
            self._ui(self._set_probely_status, "unauth")
        for name, e in (r.get("engines") or {}).items():
            if e.get("status") == "error":
                self._emit_log(f"[{k}] ⚠ {name.upper()} no se ejecutó: {e.get('detail', '')[:200]} — el resultado "
                               "de esta etapa es PARCIAL.")
        if r.get("scan_url"):
            self._emit_log(f"[{k}] ver el escaneo en Probely: {r['scan_url']}")
        if r.get("report_path"):
            self._emit_log(f"[{k}] reporte de cumplimiento: {r['report_path']}")
        for f in r.get("findings") or []:
            ev = (f.get("evidence") or "").lower()
            if ("not verified" in ev or "verification token" in ev) and self._is_admin:
                self._ui(self._show_probely_verify_popup, k, f.get("evidence") or "")
                break

    def _finalize_report(self, *, target, sel, mode, version, results, failed, reports_root, out_dir, label,
                         batch) -> dict:
        from report_engine import build_cumulative_context, export_csv, render_html, update_history_after_scan
        app = self._active_app
        app_name = app.get("name", "") if app else ""
        targets = {"dast": self._dast_url_var.get().strip(), "api": self._api_spec_var.get().strip(),
                   "container": ", ".join(s["value"] for s in self._container_sources_clean()),
                   "iac": ", ".join(self._iac_paths_effective())}
        state = self._scan_state
        for kind in STAGES:
            if results.get(kind) is not None:
                try:
                    state.save_kind(kind, results[kind], target=targets.get(kind) or str(target),
                                    snyk_version=version, mode=mode)
                    self._emit_log(f"[estado] resultado {kind} guardado en el histórico acumulado")
                except Exception as e:
                    self._emit_log(f"[estado] no se pudo guardar {kind}: {e!r}")
        ctx = build_cumulative_context(state, target_hint=target, snyk_version_hint=version, current_results=results)
        ctx.update(scan_mode=mode, failed_stages=sorted(failed), incomplete=bool(failed),
                   batch_targets=[str(Path(t).resolve()) for t in batch])
        ctx["servicenow_tickets"] = self._sync_tickets(sel, failed, results, target, version, reports_root, app_name)
        c = ctx["counts"]
        sec_ch = sum(1 for s in (ctx.get("secrets") or {}).get("findings", []) if s.get("severity") in ("critical", "high"))
        raw_gate = "FAIL" if (c.get("critical") or c.get("high") or sec_ch) else "PASS"
        gate = "INCOMPLETE" if failed else raw_gate
        self._emit_log(f"[gate] {gate}  (critical={c.get('critical', 0)} high={c.get('high', 0)} "
                       f"medium={c.get('medium', 0)} low={c.get('low', 0)} secrets_crit_high={sec_ch})"
                       + (f"  — {'/'.join(sorted(failed)).upper()} no se completó; vuelva a ejecutar antes de "
                          f"tomarlo como {raw_gate}" if failed else ""))
        base = report_basename(self._user, mode)
        report = render_html(ctx, out_dir, filename=f"{base}.html")
        self._emit_log(f"[reporte] HTML → {report}")
        for what, fn in (("CSV (ZIP)", lambda: export_csv(ctx, out_dir / f"{base}.csv", report_label=label)),
                         ("Secretos HTML", lambda: (out_dir / "secrets" / "secrets.html").exists() and shutil.copyfile(
                             out_dir / "secrets" / "secrets.html", out_dir / f"{base}_secrets.html")),
                         ("SARIF unificado", lambda: ss.export_sarif(out_dir, ctx)),
                         ("JSON unificado", lambda: ss.export_merged_json(out_dir, ctx))):
            try:
                if p := fn():
                    self._emit_log(f"[reporte] {what} → {p}")
            except Exception as e:
                self._emit_log(f"[reporte] {what} omitido: {e!r}")
        meta = {k: ctx.get(k, 0) for k in ("sca_total", "code_total", "dast_total", "api_total", "secrets_total",
                                           "container_total", "iac_total")}
        meta.update(generated_at=ctx["generated_at"], target=ctx["target"], mode=mode, counts=c, total=ctx["total"],
                    snyk_version=ctx.get("snyk_version", ""), failed_stages=sorted(failed), incomplete=bool(failed),
                    servicenow_tickets=ctx["servicenow_tickets"])
        write_json(out_dir / "meta.json", meta)
        try:
            rec = update_history_after_scan(reports_root, ctx, meta, actor=self._user, report_dir=out_dir)
            self._emit_log(f"[historial] registrado — remediadas {rec.get('remediated_count', 0)}, "
                           f"nuevas {rec.get('introduced_count', 0)} desde el último {mode.upper()}")
        except Exception as e:
            self._emit_log(f"[historial] no se pudo actualizar: {e!r}")
        if app and app.get("id"):
            try:
                self._inv_store.record_scan(app["id"], meta)
                if (fresh := self._inv_store.get_app(app["id"])) and self._active_app is app:
                    app.update(fresh)
                self._ui(self._refresh_inventory)
                self._ui(lambda: self._show_app_detail(self._selected_app()))
            except Exception as e:
                self._emit_log(f"[inventario] no se pudo actualizar: {e!r}")
        self._last_context = ctx
        self._last_static_report = Path(report)
        ctx["_report_path"], ctx["_gate"] = Path(report), gate
        return ctx

    def _sync_tickets(self, sel, failed, results, target, version, reports_root, app_name) -> list:
        try:
            from servicenow_tickets import public_view, summarize_dynamic, summarize_static, sync_ticket
        except ImportError as e:
            self._emit_log(f"[servicenow] no se pudo importar servicenow_tickets.py ({e!r}) — ese archivo (y "
                           "test_servicenow_ticket.py) deben estar en la MISMA carpeta que el escáner. Se omite la "
                           "sincronización.")
            return []
        snow = getattr(self, "_snow_state", "none")
        if snow in ("none", "invalid"):
            self._emit_log("[servicenow] " + ("sin credenciales configuradas" if snow == "none" else
                           "las credenciales guardadas fueron rechazadas") + " — se omite la creación de tickets "
                           "(configúrelo en Escanear → Preparación).")
            return []
        recs = []
        try:
            for kinds, label, ok_fn in ((set(STATIC_STAGES), "estática(s)", lambda: True),
                                        ({"dast", "api"}, "dast/api", lambda: bool(app_name))):
                chosen = kinds & sel
                if not chosen:
                    continue
                if chosen & set(failed):
                    self._emit_log(f"[servicenow] etapa(s) {label} incompleta(s) — se omite la sincronización del ticket")
                    continue
                if not any(results.get(k) is not None for k in kinds):
                    continue
                if not ok_fn():
                    self._emit_log("[servicenow] sin aplicación activa — se omite el ticket de DAST/API (se identifica "
                                   "por el nombre de la aplicación)")
                    continue
                if "sca" in kinds:
                    summary = summarize_static(results["sca"], results["code"], results["secrets"], target, version)
                    rec = sync_ticket(reports_root, kind="static", name=target.name, summary=summary,
                                      app_name=app_name, actor=self._user, log=self._emit_log)
                else:
                    summary = summarize_dynamic(results["dast"], results["api"], target, version)
                    rec = sync_ticket(reports_root, kind="dynamic", name=app_name, summary=summary,
                                      app_name=app_name, actor=self._user, log=self._emit_log)
                if rec:
                    recs.append(public_view(rec))
        except Exception as e:
            self._emit_log(f"[servicenow] no se pudo sincronizar el/los ticket(s): {e!r}")
        if not recs:
            self._ui(self._refresh_servicenow_state)  # p. ej. un 401: la «Preparación» deja de mostrar la palomita
        return recs

    def _on_report(self, path, primary: bool = True):
        self._last_report = Path(path)
        self._refresh_rep_tree()
        self._refresh_active_app_banner()
        self._refresh_summary()
        self._on_infra_results(self._last_context)
        self._refresh_engine_cache()
        if self._active_tab != "reports":
            self._set_reportes_notification(True)
        self._toast("Escaneo terminado — reporte generado", "ok")
        if self._auto_open and primary:
            open_path(self._last_report)
