"""Escaneo de contenedores (Trivy) e infraestructura como código (Checkov + Trivy config).

Contenedores — fuentes soportadas sin Docker Desktop:
  · «registry»: referencia de imagen (registro/repositorio:tag o @sha256). Trivy descarga las capas directo del
    registro (ECR, ACR, GCR/Artifact Registry, Harbor, Nexus, Artifactory, Docker Hub…). Si existe Docker/Podman en la
    máquina también se intenta el demonio local primero.
  · «archive»: archivo .tar generado con `docker save`, `podman save`, `skopeo copy … oci-archive:` o un layout OCI.
  · «sbom»: SBOM CycloneDX/SPDX (útil cuando la imagen se construye en el pipeline y solo se comparte el SBOM).
Las credenciales del registro se pasan solo en memoria (TRIVY_USERNAME/TRIVY_PASSWORD) y nunca se guardan; también se
respetan las que ya existan en ~/.docker/config.json.

IaC — Checkov (Terraform, Kubernetes, Helm, Kustomize, CloudFormation, ARM, Bicep, Dockerfile, Ansible…) y Trivy
config (aporta severidad oficial). Los hallazgos de ambos se fusionan por archivo + línea + CWE.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field

from ui_common import *
import findings as fz
import tool_manager as tm
from oss_web_scanner import _stream

IAC_EXT = {".tf": "Terraform", ".tfvars": "Terraform", ".bicep": "Bicep", ".hcl": "Terraform"}
_SKIP = {".git", "node_modules", ".terraform", "vendor", ".venv", "venv", "__pycache__", "dist", "build", "target",
         ".snyk-venv", "Reports"}
_MANIFESTS = {"package.json", "package-lock.json", "yarn.lock", "pnpm-lock.yaml", "requirements.txt", "pipfile",
              "pipfile.lock", "pyproject.toml", "poetry.lock", "pom.xml", "build.gradle", "build.gradle.kts", "go.mod",
              "gemfile.lock", "composer.json", "composer.lock", "cargo.lock", "packages.config", "nuget.config"}
_SOURCE_EXT = {".py", ".js", ".ts", ".tsx", ".jsx", ".java", ".cs", ".go", ".rb", ".php", ".kt", ".swift", ".scala",
               ".c", ".cpp", ".vb", ".apex", ".rs"}


@dataclass
class InfraConfig:
    sources: list = field(default_factory=list)          # [{"type": registry|archive|sbom, "value": str}]
    registry_user: str = ""
    registry_password: str = ""
    insecure_registry: bool = False
    iac_paths: list = field(default_factory=list)
    skip_checks: str = ""
    include_unfixed: bool = True


# ── Detección del proyecto (usada por el asistente y la pestaña IaC) ────────
def detect_project(root, max_files: int = 6000) -> dict:
    root = Path(root)
    out = {"manifests": [], "source": 0, "dockerfiles": [], "iac": {}, "k8s": 0, "compose": [], "secrets_hint": False}
    if not root.is_dir():
        return out
    n = 0
    for dirpath, dirnames, files in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in _SKIP and not d.startswith(".")]
        for name in files:
            n += 1
            if n > max_files:
                return out
            low, p = name.lower(), Path(dirpath) / name
            ext = p.suffix.lower()
            if low in _MANIFESTS or ext in (".csproj", ".sln"):
                out["manifests"].append(str(p.relative_to(root)))
            if ext in _SOURCE_EXT:
                out["source"] += 1
            if low == "dockerfile" or low.startswith("dockerfile.") or low.endswith(".dockerfile") or low == "containerfile":
                out["dockerfiles"].append(str(p.relative_to(root)))
                out["iac"]["Dockerfile"] = out["iac"].get("Dockerfile", 0) + 1
            if low in ("docker-compose.yml", "docker-compose.yaml", "compose.yaml", "compose.yml"):
                out["compose"].append(str(p.relative_to(root)))
            if ext in IAC_EXT:
                k = IAC_EXT[ext]
                out["iac"][k] = out["iac"].get(k, 0) + 1
            if low == "chart.yaml":
                out["iac"]["Helm"] = out["iac"].get("Helm", 0) + 1
            if low == "kustomization.yaml":
                out["iac"]["Kustomize"] = out["iac"].get("Kustomize", 0) + 1
            if ext in (".yaml", ".yml", ".json") and p.stat().st_size < 400_000:
                try:
                    head = p.read_text(encoding="utf-8", errors="ignore")[:3000]
                except Exception:
                    continue
                if re.search(r"(?m)^\s*apiVersion:\s*\S+", head) and re.search(r"(?m)^\s*kind:\s*\S+", head):
                    out["k8s"] += 1
                    out["iac"]["Kubernetes"] = out["iac"].get("Kubernetes", 0) + 1
                elif "AWSTemplateFormatVersion" in head or re.search(r'"Resources"\s*:\s*\{', head) and "AWS::" in head:
                    out["iac"]["CloudFormation"] = out["iac"].get("CloudFormation", 0) + 1
                elif "schema.management.azure.com" in head:
                    out["iac"]["ARM"] = out["iac"].get("ARM", 0) + 1
            if ext in (".env", ".pem", ".key", ".pfx"):
                out["secrets_hint"] = True
    return out


def recommended_stages(det: dict) -> set:
    rec = {"secrets"}
    if det.get("manifests"):
        rec.add("sca")
    if det.get("source"):
        rec.add("code")
    if det.get("iac"):
        rec.add("iac")
    return rec


# ── Trivy ────────────────────────────────────────────────────────────────────
def _trivy_cache() -> Path:
    p = TOOLS_DIR / "trivy-cache"
    p.mkdir(parents=True, exist_ok=True)
    return p


def _trivy_common() -> list:
    args = ["--cache-dir", str(_trivy_cache()), "--quiet", "--timeout", "30m"]
    try:
        import admin_policy
        t = admin_policy.load().get("trivy") or {}
        if t.get("db_repository"):
            args += ["--db-repository", t["db_repository"]]
        if t.get("java_db_repository"):
            args += ["--java-db-repository", t["java_db_repository"]]
        if t.get("checks_bundle_repository"):
            args += ["--checks-bundle-repository", t["checks_bundle_repository"]]
    except Exception:
        pass
    return args


def _trivy_db(exe: str, log, cancel) -> list:
    """Descarga/actualiza la base de vulnerabilidades como máximo cada 12 h; devuelve flags para el escaneo."""
    if time.time() - tm.stamp("trivy", "db_at") < 12 * 3600:
        return ["--skip-db-update", "--skip-java-db-update"]
    log("[trivy] actualizando base de datos de vulnerabilidades…")
    rc = _stream([exe, "image", "--download-db-only", *_trivy_common()], log=log, cancel=cancel, timeout_s=1200,
                 tag="trivy", on_line=lambda l: log(f"[trivy] {l[:200]}"))
    rc2 = _stream([exe, "image", "--download-java-db-only", *_trivy_common()], log=log, cancel=cancel, timeout_s=1200,
                  tag="trivy", on_line=lambda l: log(f"[trivy] {l[:200]}"))
    if rc == 0:
        tm.touch("trivy", "db_at")
        return ["--skip-db-update"] + (["--skip-java-db-update"] if rc2 == 0 else [])
    log("[trivy] no se pudo actualizar la base (¿ghcr.io/mirror.gcr.io bloqueado?). Ciberseguridad puede configurar un "
        "espejo en Administración → Trivy. Se intentará con la base en caché si existe.")
    return ["--skip-db-update", "--skip-java-db-update"] if any(_trivy_cache().rglob("trivy.db")) else []


def _image_src() -> str:
    srcs = [s for s, exe in (("docker", "docker"), ("podman", "podman")) if which(exe)]
    return ",".join(srcs + ["remote"])


def _parse_trivy(data: dict, *, label: str) -> tuple[list, list, list]:
    vulns, misconf, secrets = [], [], []
    for res in (data or {}).get("Results") or []:
        target = res.get("Target") or label
        for v in res.get("Vulnerabilities") or []:
            cvss = next((x.get("V3Score") for x in (v.get("CVSS") or {}).values() if isinstance(x, dict) and x.get("V3Score")),
                        "")
            f = {"severity": fz.sev(v.get("Severity")), "vuln_id": v.get("VulnerabilityID", ""),
                 "title": v.get("Title") or v.get("VulnerabilityID", ""), "package": v.get("PkgName", ""),
                 "installed": v.get("InstalledVersion", ""), "fixed": v.get("FixedVersion", ""),
                 "status": v.get("Status", ""), "target": f"{label} · {target}" if target != label else label,
                 "pkg_type": res.get("Type", ""), "cwe": ", ".join(fz.norm_cwes(v.get("CweIDs"))), "cvss": cvss,
                 "description": (v.get("Description") or "")[:1500], "url": v.get("PrimaryURL", ""),
                 "references": (v.get("References") or [])[:6], "detected_by": ["Trivy"]}
            f["remediation"] = f"Actualizar {f['package']} a {f['fixed']}" if f["fixed"] else "Sin versión corregida publicada"
            f["sources"] = [fz.source("Trivy", f)]
            vulns.append(f)
        for m in res.get("Misconfigurations") or []:
            if (m.get("Status") or "FAIL") != "FAIL":
                continue
            cm = m.get("CauseMetadata") or {}
            text = f"{m.get('Title', '')} {m.get('Description', '')}"
            cwe = fz.iac_cwe(text)
            f = {"severity": fz.sev(m.get("Severity")), "title": m.get("Title") or m.get("ID", ""),
                 "rule_id": m.get("AVDID") or m.get("ID", ""), "file": target, "line": cm.get("StartLine") or 0,
                 "end_line": cm.get("EndLine") or 0, "resource": cm.get("Resource", ""), "cwe": cwe,
                 "description": (m.get("Description") or m.get("Message") or "")[:1200],
                 "remediation": m.get("Resolution", ""), "references": (m.get("References") or [])[:5],
                 "framework": res.get("Type", ""), "url": m.get("PrimaryURL", ""), "detected_by": ["Trivy"]}
            f["sources"] = [fz.source("Trivy", f)]
            misconf.append(f)
        for s in res.get("Secrets") or []:
            secrets.append({"severity": fz.sev(s.get("Severity")), "title": s.get("Title") or s.get("RuleID", ""),
                            "file": target, "line": s.get("StartLine", 0), "match": (s.get("Match") or "")[:120],
                            "cwe": "CWE-798", "detected_by": ["Trivy"]})
    return vulns, misconf, secrets


def run_container_scan(cfg: InfraConfig, out_dir: Path, log, cancel=None, progress=None):
    cancel = cancel or threading.Event()
    out_dir = Path(out_dir)
    sources = [s for s in cfg.sources if (s.get("value") or "").strip()]
    summary = {"engine": "trivy", "images": [], "findings": [], "secrets": [], "misconfigurations": [],
               "cancelled": False, "targets": [s["value"] for s in sources]}
    if not sources:
        raise RuntimeError("No hay imágenes configuradas — agregue una referencia de registro, un .tar o un SBOM.")
    exe = tm.ensure("trivy", log)
    db_flags = _trivy_db(exe, log, cancel)
    env = dict(os.environ)
    if cfg.registry_user:
        env.update(TRIVY_USERNAME=cfg.registry_user, TRIVY_PASSWORD=cfg.registry_password)
    if cfg.insecure_registry:
        env["TRIVY_INSECURE"] = "true"
    total, ok = len(sources), 0
    for i, src in enumerate(sources):
        if cancel.is_set():
            summary["cancelled"] = True
            break
        kind, value = src.get("type", "registry"), src["value"].strip()
        dest = out_dir / f"trivy_image_{i + 1}.json"
        common = ["--format", "json", "--output", str(dest), *db_flags, *_trivy_common()]
        if kind == "sbom":
            cmd = [exe, "sbom", value, *common]
        elif kind == "archive":
            cmd = [exe, "image", "--input", value, "--scanners", "vuln,secret", *common]
        else:
            cmd = [exe, "image", value, "--image-src", _image_src(), "--scanners", "vuln,secret",
                   "--image-config-scanners", "misconfig,secret", *common]
        if not cfg.include_unfixed:
            cmd.append("--ignore-unfixed")
        log(f"[trivy] ({i + 1}/{total}) analizando {('SBOM ' if kind == 'sbom' else '')}{value}")
        rc = _stream(cmd, log=log, cancel=cancel, timeout_s=3600, env=env, tag="trivy",
                     on_line=lambda l: any(k in l.lower() for k in ("error", "fatal", "unauthorized", "denied"))
                     and log(f"[trivy] {l[:240]}"))
        progress and progress(i + 1, total)
        data = read_json(dest) if dest.exists() else None
        if rc != 0 or not data:
            hint = ""
            if kind == "registry":
                hint = (" Verifique la referencia, sus credenciales del registro (usuario/token) y que el registro sea "
                        "alcanzable desde su red. Alternativa sin red al registro: exporte la imagen con `docker save` "
                        "o pida el .tar/SBOM al pipeline.")
            log(f"[trivy] no se pudo analizar {value} (código {rc}).{hint}")
            summary["images"].append({"value": value, "type": kind, "status": "error"})
            continue
        ok += 1
        md = data.get("Metadata") or {}
        osi = md.get("OS") or {}
        label = data.get("ArtifactName") or value
        v, m, s = _parse_trivy(data, label=label)
        summary["findings"] += v
        summary["misconfigurations"] += m
        summary["secrets"] += s
        summary["images"].append({"value": value, "type": kind, "status": "ok", "artifact": label,
                                  "os": f"{osi.get('Family', '')} {osi.get('Name', '')}".strip(),
                                  "vulns": len(v), "eosl": bool(osi.get("EOSL"))})
        if osi.get("EOSL"):
            log(f"[trivy] ⚠ {label}: el sistema operativo base ({osi.get('Family')} {osi.get('Name')}) ya no recibe "
                "parches (fin de soporte). Cambie la imagen base.")
    if not ok and not summary["cancelled"]:
        raise RuntimeError("No se pudo analizar ninguna imagen — revise el registro de actividad.")
    summary["findings"] = fz.merge(summary["findings"], fz.vuln_key)
    for f in summary["misconfigurations"]:
        summary["findings"].append({**f, "package": f.get("resource") or "configuración de la imagen",
                                    "installed": "", "fixed": "", "vuln_id": f.get("rule_id", ""),
                                    "target": f.get("file", ""), "kind_detail": "config"})
    for s in summary["secrets"]:
        summary["findings"].append({**s, "package": "secreto en capa", "installed": "", "fixed": "",
                                    "vuln_id": s.get("title", ""), "target": s.get("file", ""), "kind_detail": "secret",
                                    "remediation": fz.REMEDIATION_BY_CWE["CWE-798"]})
    summary["findings"].sort(key=lambda f: SEV_ORDER.get(f["severity"], 9))
    log(f"[trivy] contenedores: {len(summary['findings'])} hallazgo(s) en {ok}/{total} imagen(es)")
    out = out_dir / "container.json"
    write_json(out, summary)
    return summary, out


# ── IaC ──────────────────────────────────────────────────────────────────────
def _utf8_env() -> dict:
    """Checkov abre los archivos con la codificación por defecto de Windows (cp1252) y falla con YAML/JSON en UTF-8
    que tienen acentos o emojis («'charmap' codec can't decode byte…»). El modo UTF-8 de Python lo corrige."""
    return dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8")


def _is_problem(line: str) -> bool:
    """Solo errores reales: ignora el resumen JSON de Checkov («"parsing_errors": 0»)."""
    s = line.strip()
    return not s.startswith('"') and bool(re.search(r"\b(error|traceback|exception)\b", s, re.I))


def _parse_checkov(path: Path, root: Path) -> list:
    data = read_json(path)
    docs = data if isinstance(data, list) else [data] if isinstance(data, dict) else []
    out = []
    for d in docs:
        for c in ((d or {}).get("results") or {}).get("failed_checks") or []:
            rng = c.get("file_line_range") or [0, 0]
            title = c.get("check_name") or c.get("check_id", "")
            cwe = fz.iac_cwe(f"{title} {c.get('check_id', '')}")
            s = c.get("severity")
            f = {"severity": fz.sev(s) if s else fz.iac_default_sev(cwe), "severity_estimated": not s,
                 "title": title, "rule_id": c.get("check_id", ""), "file": (c.get("repo_file_path") or c.get("file_path")
                                                                         or "").lstrip("/\\"),
                 "line": rng[0] if rng else 0, "end_line": rng[-1] if rng else 0, "resource": c.get("resource", ""),
                 "cwe": cwe, "framework": d.get("check_type", ""), "description": c.get("description") or "",
                 "remediation": fz.REMEDIATION_BY_CWE.get(cwe, ""), "references": [c["guideline"]] if c.get("guideline") else [],
                 "detected_by": ["Checkov"]}
            f["sources"] = [fz.source("Checkov", f)]
            out.append(f)
    return out


def _relpath(p: str, root: Path) -> str:
    try:
        pp = Path(p)
        return str(pp.relative_to(root)) if pp.is_absolute() else p
    except Exception:
        return p


def run_iac_scan(cfg: InfraConfig, out_dir: Path, log, cancel=None, progress=None):
    cancel = cancel or threading.Event()
    out_dir = Path(out_dir)
    paths = [Path(p) for p in cfg.iac_paths if str(p).strip() and Path(p).exists()]
    if not paths:
        raise RuntimeError("No hay carpetas de IaC configuradas (o no existen en disco).")
    summary = {"engine": "", "targets": [str(p) for p in paths], "findings": [], "frameworks": {}, "cancelled": False,
               "engines": {}}
    allf = []
    steps, step = len(paths) * 2, 0
    checkov_ok = trivy_ok = False
    for root in paths:
        if cancel.is_set():
            break
        det = detect_project(root if root.is_dir() else root.parent)
        for k, n in det["iac"].items():
            summary["frameworks"][k] = summary["frameworks"].get(k, 0) + n
        try:
            py = tm.ensure("checkov", log)
            dest = out_dir / f"checkov_{len(allf)}_{slug(root.name)}"
            dest.mkdir(parents=True, exist_ok=True)
            cmd = [py, "-m", "checkov.main", "-d" if root.is_dir() else "-f", str(root), "-o", "json",
                   "--output-file-path", str(dest), "--quiet", "--compact", "--soft-fail", "--skip-download"]
            if cfg.skip_checks.strip():
                cmd += ["--skip-check", ",".join(x.strip() for x in re.split(r"[,\s]+", cfg.skip_checks) if x.strip())]
            log(f"[checkov] analizando {root}")
            _stream(cmd, log=log, cancel=cancel, timeout_s=2400, tag="checkov", env=_utf8_env(),
                    on_line=lambda l: _is_problem(l) and log(f"[checkov] {l[:220]}"))
            res = next(iter(sorted(dest.glob("*.json"))), None)
            if res:
                found = _parse_checkov(res, root)
                for f in found:
                    f["file"] = _relpath(f["file"], root)
                    f["root"] = str(root)
                allf += found
                checkov_ok = True
                summary["engines"]["checkov"] = {"status": "ok"}
            else:
                summary["engines"]["checkov"] = {"status": "error", "detail": "sin archivo de resultados"}
        except Exception as e:
            log(f"[checkov] no disponible: {e}")
            summary["engines"]["checkov"] = {"status": "error", "detail": str(e)[:300]}
        step += 1
        progress and progress(step, steps)
        try:
            exe = tm.ensure("trivy", log)
            dest = out_dir / f"trivy_config_{slug(root.name)}.json"
            rc = _stream([exe, "config", str(root), "--format", "json", "--output", str(dest), *_trivy_common()],
                         log=log, cancel=cancel, timeout_s=1800, tag="trivy",
                         on_line=lambda l: "error" in l.lower() and log(f"[trivy] {l[:220]}"))
            data = read_json(dest) if dest.exists() else None
            if data:
                _, mis, _ = _parse_trivy(data, label=str(root))
                for f in mis:
                    f["file"] = _relpath(f["file"], root)
                    f["root"] = str(root)
                allf += mis
                trivy_ok = True
                summary["engines"]["trivy"] = {"status": "ok"}
            else:
                summary["engines"]["trivy"] = {"status": "error", "detail": f"código {rc}"}
        except Exception as e:
            log(f"[trivy] config no disponible: {e}")
            summary["engines"]["trivy"] = {"status": "error", "detail": str(e)[:300]}
        step += 1
        progress and progress(step, steps)
    if not (checkov_ok or trivy_ok) and not cancel.is_set():
        raise RuntimeError("Ningún motor de IaC pudo ejecutarse — revise el registro de actividad.")
    merged = fz.merge(allf, fz.iac_key)
    summary.update(findings=merged, cancelled=cancel.is_set(),
                   engine="+".join(k for k, ok in (("checkov", checkov_ok), ("trivy", trivy_ok)) if ok))
    log(f"[iac] {len(merged)} hallazgo(s) tras unificar ({len(allf) - len(merged)} duplicados entre Checkov y Trivy)")
    out = out_dir / "iac.json"
    write_json(out, summary)
    return summary, out
