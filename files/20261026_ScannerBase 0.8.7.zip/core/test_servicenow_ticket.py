#!/usr/bin/env python3

from __future__ import annotations

import argparse
import base64
import copy
import csv
import ctypes
import getpass
import hashlib
import hmac
import json
import os
import subprocess
import sys
import threading
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional

import requests


IS_WIN = os.name == "nt"
BASE_URL = os.environ.get("SNOW_BASE_URL", "https://bancobasedev.service-now.com")
SYS_ID = os.environ.get("SNOW_CATALOG_SYS_ID", "799044769396c750af38b6ea6aba1080")
ORDER_URL = f"{BASE_URL}/api/sn_sc/servicecatalog/items/{SYS_ID}/order_now"

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_FILE = os.environ.get("SNOW_TEST_LOG") or os.path.join(SCRIPT_DIR, "servicenow_test_log.csv")

APP_DATA_DIR = os.environ.get("SNOW_APP_DATA_DIR") or os.path.join(os.path.expanduser("~"), ".servicenow_ticket_tester")
try:
    os.makedirs(APP_DATA_DIR, exist_ok=True)
except OSError:
    pass

CANCEL_TABLE = os.environ.get("SNOW_CANCEL_TABLE", "sc_request")
CANCEL_STATE_FIELD = os.environ.get("SNOW_CANCEL_STATE_FIELD", "state")
CANCEL_STATE_VALUE = os.environ.get("SNOW_CANCEL_STATE", "Closed Cancelled")

RITM_TABLE = os.environ.get("SNOW_RITM_TABLE", "sc_req_item")
RESOLVE_STATE_FIELD = os.environ.get("SNOW_RESOLVE_STATE_FIELD", "state")
RESOLVE_STATE_VALUE = os.environ.get("SNOW_RESOLVE_STATE_VALUE", "Closed Complete")
COMMENT_FIELD = os.environ.get("SNOW_COMMENT_FIELD", "work_notes")

# Producción. La URL y el sys_id del catalog item se pueden cambiar desde el escáner (Escanear → Preparación →
# ServiceNow) o desde el Ticket Tester (pestaña Producción); se guardan en environment_prod.json y tienen prioridad.
PROD_BASE_URL = os.environ.get("SNOW_PROD_BASE_URL", "https://bancobase.service-now.com")
PROD_SYS_ID = os.environ.get("SNOW_PROD_CATALOG_SYS_ID", SYS_ID)
# Ambiente de ServiceNow donde el escáner levanta los tickets automáticos.
SCANNER_ENV = os.environ.get("SNOW_SCANNER_ENV", "prod")

CREDENTIALS_FILE = os.environ.get("SNOW_CREDENTIALS_FILE") or os.path.join(APP_DATA_DIR, "credentials.json")

DEFAULT_APP_NAME = os.environ.get("SNOW_APP_NAME", "Portal-Clientes")

# --- Multi-environment support (Development / QA / Producción) -----------------------------
#
# Everything above this block (BASE_URL, SYS_ID, CANCEL_*, CREDENTIALS_FILE) remains the single
# "default" environment used by the CLI when no --service/env flags are given, so existing CLI
# usage (env vars, `--remember`, etc.) is completely unaffected. The GUI drives three independent
# `Environment` instances instead of these module-level globals, each with its own connection
# settings and its own credentials file (Development deliberately reuses CREDENTIALS_FILE above so
# credentials already saved via the CLI or the pre-tabs GUI keep working without re-entry).


@dataclass
class Environment:
    key: str
    label: str
    base_url: str = ""
    sys_id: str = ""
    cancel_table: str = "sc_request"
    cancel_state_field: str = "state"
    cancel_state_value: str = "Closed Cancelled"
    credentials_file: str = ""
    is_production: bool = False


def _environment_config_file(env_key: str) -> str:
    return os.path.join(APP_DATA_DIR, f"environment_{env_key}.json")


def _default_environment(env_key: str) -> Environment:
    if env_key == "dev":
        return Environment(
            key="dev", label="Development",
            base_url=BASE_URL, sys_id=SYS_ID,
            cancel_table=CANCEL_TABLE, cancel_state_field=CANCEL_STATE_FIELD,
            cancel_state_value=CANCEL_STATE_VALUE,
            credentials_file=CREDENTIALS_FILE,
        )
    if env_key == "qa":
        return Environment(
            key="qa", label="QA",
            base_url="", sys_id="",
            credentials_file=os.path.join(APP_DATA_DIR, "credentials_qa.json"),
        )
    if env_key == "prod":
        return Environment(
            key="prod", label="Producción",
            base_url=PROD_BASE_URL, sys_id=PROD_SYS_ID,
            credentials_file=os.path.join(APP_DATA_DIR, "credentials_prod.json"),
            is_production=True,
        )
    raise ValueError(f"Ambiente desconocido: {env_key}")


ENVIRONMENT_KEYS = ("dev", "qa", "prod")


def load_environment(env_key: str) -> Environment:
    """Loads an Environment, seeded with defaults (real values for 'dev', the production instance for 'prod',
    blank for 'qa') and overlaid with whatever was saved
    to disk via save_environment() — e.g. after the user fills in the QA/Prod instance URL and
    catalog sys_id in the GUI once."""
    env = _default_environment(env_key)
    path = _environment_config_file(env_key)
    if os.path.isfile(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                saved = json.load(f)
            data = asdict(env)
            for k, v in saved.items():
                if k in data and v not in (None, ""):
                    data[k] = v
            env = Environment(**data)
        except (OSError, ValueError, TypeError):
            pass
    return env


def save_environment(env: Environment) -> None:
    path = _environment_config_file(env.key)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(asdict(env), f, indent=2, ensure_ascii=False)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
DEFAULT_DESCRIPTION = os.environ.get(
    "SNOW_DESCRIPCION",
    "Solicitud de escaneo de seguridad conforme al calendario de revisiones periódicas.",
)


BASE_FIELDS = {
    "id_del_solicitante": "slunam",
    "nombre_del_solicitante": "Sergio Luna Medel",
    "correo_del_solicitante": "slunam@bancobase.com",
    "objetivo_de_la_solicitud": "Obtener solicitudes de escaneo y limpieza de falsos positivos",
    "nombre_de_la_aplicaci_n": DEFAULT_APP_NAME,
    "ambiente": "Desarrollo",
    "modo_ejecucion": "Baseline",
    "clasificaci_n_de_la_aplicaci_n": "MDP",
    "prioridad_": "Media",
    "owner_de_la_aplicaci_n2": "URL de la API",
    "descripci_n_de_la_solicitud_justificaci_n": DEFAULT_DESCRIPTION,
    "cuentas_con_url": "URL de la API",
}


SERVICES = {
    "sast_sca": {
        "field": "sast_sca",
        "extra": {
            "organizaci_n_en_snyk": "TEST-ORG",
        },
    },
    "dast": {
        "field": "dast",
        "extra": {
            "organizaci_n_en_snyk": "TEST-ORG",
            "requiere_triage": "No",
            "url_objetivo": "https://test.bancobase.com",
            "urls_a_excluir": "[]",
            "usar_cuenta_de_servicio_del_equipo": "Si",
        },
    },
    "api": {
        "field": "api",
        "extra": {
            "organizaci_n_en_snyk": "TEST-ORG",
            "tecnologia_api": "REST",
            "usar_cuenta_de_servicio_del_equipo": "Si",
            "url_de_la_api": "https://test.bancobase.com/api",
        },
    },
    "secretos": {
        "field": "escaneo_de_secretos",
        "extra": {
            "repositorio_s": "[{\"name\": \"test-repo\"}]",
            "ruta_monorepo": "/",
            "usar_cuenta_de_servicio_del_equipo": "Si",
        },
    },
    "triage": {
        "field": "triage",
        "extra": {},
    },
    "servidor": {
        "field": "servidor_tenable",
        "extra": {
            "direcci_nes_ip_o_hostnames": "10.0.0.1;10.0.0.2",
        },
    },
}


def build_payload(selected_services: list[str], ambiente: Optional[str] = None,
                   app_name: Optional[str] = None, descripcion: Optional[str] = None,
                   solicitante_id: Optional[str] = None, solicitante_nombre: Optional[str] = None,
                   solicitante_correo: Optional[str] = None,
                   overrides: Optional[dict] = None) -> dict:
    if not selected_services:
        raise ValueError("Debes seleccionar al menos un servicio")
    unknown = [s for s in selected_services if s not in SERVICES]
    if unknown:
        raise ValueError(f"Servicio(s) desconocido(s): {', '.join(unknown)}")

    fields = copy.deepcopy(BASE_FIELDS)
    if app_name:
        fields["nombre_de_la_aplicaci_n"] = app_name
    if descripcion:
        fields["descripci_n_de_la_solicitud_justificaci_n"] = descripcion
    if ambiente:
        fields["ambiente"] = ambiente
    if solicitante_id:
        fields["id_del_solicitante"] = solicitante_id
    if solicitante_nombre:
        fields["nombre_del_solicitante"] = solicitante_nombre
    if solicitante_correo:
        fields["correo_del_solicitante"] = solicitante_correo

    for name, spec in SERVICES.items():
        fields[spec["field"]] = "true" if name in selected_services else "false"

    for name in selected_services:
        fields.update(SERVICES[name]["extra"])

    if overrides:
        fields.update(overrides)

    return {"sysparm_quantity": "1", "variables": fields}


CRYPTPROTECT_UI_FORBIDDEN = 0x1


class _DATA_BLOB(ctypes.Structure):
    _fields_ = [("cbData", ctypes.c_uint32), ("pbData", ctypes.POINTER(ctypes.c_char))]


def _dpapi(fn_name: str, data: bytes) -> Optional[bytes]:
    """Cifrado DPAPI de Windows: solo la misma cuenta de Windows en el mismo equipo puede descifrar."""
    if not IS_WIN:
        return None
    try:
        buf = ctypes.create_string_buffer(data, len(data))
        blob_in, blob_out = _DATA_BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char))), _DATA_BLOB()
        if not getattr(ctypes.windll.crypt32, fn_name)(ctypes.byref(blob_in), None, None, None, None,
                                                       CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(blob_out)):
            return None
        try:
            return ctypes.string_at(blob_out.pbData, blob_out.cbData)
        finally:
            ctypes.windll.kernel32.LocalFree(blob_out.pbData)
    except Exception:
        return None


def _encrypt_secret(plain: str) -> Optional[str]:
    enc = _dpapi("CryptProtectData", plain.encode("utf-8")) if plain else None
    return base64.b64encode(enc).decode("ascii") if enc is not None else None


def _decrypt_secret(blob_b64: str) -> str:
    try:
        dec = _dpapi("CryptUnprotectData", base64.b64decode(blob_b64)) if blob_b64 else None
        return dec.decode("utf-8") if dec is not None else ""
    except Exception:
        return ""


def load_saved_credentials(credentials_file: Optional[str] = None) -> dict:
    path = credentials_file or CREDENTIALS_FILE
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return {}
    if not isinstance(data, dict):
        return {}
    if data.get("encrypted"):
        return {"user": data.get("user", ""), "password": _decrypt_secret(data.get("password_enc", "")),
                "token": _decrypt_secret(data.get("token_enc", ""))}
    creds = {k: data.get(k, "") for k in ("user", "password", "token")}
    if IS_WIN and (creds["password"] or creds["token"]):  # archivo antiguo en texto plano → se re-guarda cifrado
        try:
            save_credentials(**creds, credentials_file=path)
        except Exception:
            pass
    return creds


def save_credentials(user: str = "", password: str = "", token: str = "",
                     credentials_file: Optional[str] = None) -> None:
    path = credentials_file or CREDENTIALS_FILE
    payload: dict = {"user": user or "", "encrypted": True}
    for key, val in (("password", password), ("token", token)):
        if val:
            enc = _encrypt_secret(val)
            if enc is not None:
                payload[f"{key}_enc"] = enc
            else:
                payload[key], payload["encrypted"] = val, False
    if not payload["encrypted"]:
        print(f"[servicenow] el cifrado no está disponible en esta plataforma — {path} se guardó en TEXTO PLANO.")
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def clear_saved_credentials(credentials_file: Optional[str] = None) -> None:
    try:
        os.remove(credentials_file or CREDENTIALS_FILE)
    except FileNotFoundError:
        pass


# ── Cuenta de integración de Producción ──────────────────────────────────────────────────────────────────
# Los tickets del escáner se levantan con la cuenta de integración y se asignan (requested_for + variables del
# solicitante) al usuario de Windows que escanea. La contraseña viaja CIFRADA en este archivo (no en texto plano):
# es ofuscación con llave embebida — evita que se lea a simple vista o por búsquedas de secretos, pero quien tenga el
# programa puede recuperarla. Dé a la cuenta solo los roles mínimos (catálogo + sc_req_item/sys_user de lectura).
# Para rotarla:  python test_servicenow_ticket.py --encode-secret  → pegue el resultado en _SVC_BLOB.
# También se puede sobrescribir con las variables de entorno SNOW_PROD_USER / SNOW_PROD_PASS.
SERVICE_ACCOUNT_USER = os.environ.get("SNOW_PROD_USER", "Integration_user")
_SVC_BLOB = "c59GAehxTSoHI0kfX58LmbLVyblo9EVaHtCQY5EBWkBLpSF21qL3MzyPClB7mVEKRWqDtvQgZ4T+3IMRGNMuxWVuPGC0"
_SVC_SALT = b"SecDevOps-BancoBase|servicenow-prod|v1"


def _svc_key() -> bytes:
    return hashlib.pbkdf2_hmac("sha256", _SVC_SALT, b"bbase-scanner-" + _SVC_SALT[::-1], 120_000)


def _keystream(key: bytes, nonce: bytes, n: int) -> bytes:
    out, i = b"", 0
    while len(out) < n:
        out += hashlib.sha256(key + nonce + i.to_bytes(4, "big")).digest()
        i += 1
    return out[:n]


def encode_service_secret(plain: str) -> str:
    key, nonce, data = _svc_key(), os.urandom(16), plain.encode("utf-8")
    ct = bytes(a ^ b for a, b in zip(data, _keystream(key, nonce, len(data))))
    tag = hmac.new(key, nonce + ct, hashlib.sha256).digest()[:16]
    return base64.b64encode(nonce + tag + ct).decode("ascii")


def decode_service_secret(blob: str) -> str:
    raw = base64.b64decode(blob)
    nonce, tag, ct = raw[:16], raw[16:32], raw[32:]
    key = _svc_key()
    if not hmac.compare_digest(tag, hmac.new(key, nonce + ct, hashlib.sha256).digest()[:16]):
        raise ValueError("secreto de la cuenta de integración alterado o inválido")
    return bytes(a ^ b for a, b in zip(ct, _keystream(key, nonce, len(ct)))).decode("utf-8")


_SVC_CACHE: dict = {}


def service_account_auth() -> Optional[tuple]:
    """(auth, headers) de la cuenta de integración de Producción, o None si no está disponible."""
    if "auth" not in _SVC_CACHE:
        try:
            pw = os.environ.get("SNOW_PROD_PASS") or decode_service_secret(_SVC_BLOB)
        except Exception:
            pw = ""
        _SVC_CACHE["auth"] = ((SERVICE_ACCOUNT_USER, pw), {}) if SERVICE_ACCOUNT_USER and pw else None
    return _SVC_CACHE["auth"]


def scanner_auth(env: "Environment") -> Optional[tuple]:
    """Producción → cuenta de integración. Otros ambientes → credenciales guardadas del usuario."""
    if env.is_production:
        return service_account_auth()
    return get_auth_silent(env.credentials_file)


# ── Identidad completa del usuario de Windows (whoami extendido) ────────────────────────────────────────
_ID_CACHE: dict = {}


def _user_name_ex(fmt: int) -> str:
    """GetUserNameExW: 2 = DOMINIO\\usuario, 3 = nombre para mostrar, 8 = UPN (correo corporativo)."""
    if not IS_WIN:
        return ""
    try:
        size = ctypes.c_ulong(0)
        ctypes.windll.secur32.GetUserNameExW(fmt, None, ctypes.byref(size))
        if not size.value:
            return ""
        buf = ctypes.create_unicode_buffer(size.value + 1)
        return buf.value.strip() if ctypes.windll.secur32.GetUserNameExW(fmt, buf, ctypes.byref(size)) else ""
    except Exception:
        return ""


def _whoami(*args) -> str:
    try:
        out = subprocess.run(["whoami", *args], capture_output=True, text=True, timeout=10,
                             **({"creationflags": subprocess.CREATE_NO_WINDOW} if IS_WIN else {}))
        return out.stdout.strip() if out.returncode == 0 else ""
    except Exception:
        return ""


def windows_identity() -> dict:
    """Quién escanea: login, DOMINIO\\usuario, nombre completo y correo (UPN), como «whoami /upn /fqdn»."""
    if not _ID_CACHE:
        login = os.environ.get("USERNAME") or getpass.getuser()
        sam = _user_name_ex(2) or _whoami() or login
        upn = _user_name_ex(8) or (_whoami("/upn") if IS_WIN else "")
        name = _user_name_ex(3)
        if not name and IS_WIN:
            fqdn = _whoami("/fqdn")  # CN=Nombre Apellido,OU=…,DC=…
            if fqdn.upper().startswith("CN="):
                name = fqdn[3:].split(",OU=")[0].split(",DC=")[0].replace("\\,", ",").strip()
        login = sam.split("\\")[-1] or login
        _ID_CACHE.update(login=login, account=sam, nombre=name or login,
                         correo=upn if "@" in upn else f"{login}@bancobase.com", upn=upn)
    return dict(_ID_CACHE)


def _resolve_auth(interactive: bool, credentials_file: Optional[str] = None):
    saved = load_saved_credentials(credentials_file)
    token = os.environ.get("SNOW_TOKEN") or saved.get("token")
    if token:
        return None, {"Authorization": f"Bearer {token}"}
    user = os.environ.get("SNOW_USER") or saved.get("user")
    password = os.environ.get("SNOW_PASS") or saved.get("password")
    if interactive:
        user = user or input("Usuario ServiceNow: ")
        password = password or getpass.getpass("Password ServiceNow: ")
    return ((user, password), {}) if user and password else None


def get_auth(credentials_file: Optional[str] = None):
    return _resolve_auth(True, credentials_file)


def get_auth_silent(credentials_file: Optional[str] = None) -> Optional[tuple]:
    """Credenciales guardadas sin preguntar nada (para el escáner). None si no hay."""
    return _resolve_auth(False, credentials_file)


def remember_auth(auth, extra_headers: dict, credentials_file: Optional[str] = None) -> None:
    hdr = extra_headers.get("Authorization", "")
    user, password = auth if auth else ("", "")
    save_credentials(user=user or "", password=password or "", token=hdr[7:] if hdr.startswith("Bearer ") else "",
                     credentials_file=credentials_file)


def _headers(extra_headers: dict, json_body: bool = True) -> dict:
    return {"Accept": "application/json", **({"Content-Type": "application/json"} if json_body else {}),
            **(extra_headers or {})}


def _get_rows(url: str, auth, extra_headers: dict, what: str, log, params: Optional[dict] = None) -> Optional[list]:
    try:
        resp = requests.get(url, auth=auth, headers=_headers(extra_headers, False), params=params, timeout=30)
    except requests.RequestException as exc:
        log(f"ERROR de red al {what}: {exc}")
        return None
    if resp.status_code != 200:
        log(f"No se pudo {what} ({resp.status_code}): {resp.text[:1000]}")
        return None
    try:
        return resp.json().get("result", [])
    except ValueError:
        log(f"Respuesta no es JSON válido al {what}.")
        return None


def _raw(field):
    return field.get("value", "") if isinstance(field, dict) else (field or "")


def update_record(table: str, sys_id: str, fields: dict, auth, extra_headers: dict, log=print, *,
                  base_url: Optional[str] = None) -> bool:
    if not sys_id:
        log("  update_record: sin sys_id, se omite")
        return False
    try:
        resp = requests.patch(f"{base_url or BASE_URL}/api/now/table/{table}/{sys_id}", auth=auth,
                              headers=_headers(extra_headers), json=fields, timeout=30)
    except requests.RequestException as exc:
        log(f"  update_record {table}/{sys_id}: ERROR de red: {exc}")
        return False
    if resp.status_code in (200, 201):
        return True
    log(f"  update_record {table}/{sys_id}: FALLÓ ({resp.status_code}): {resp.text[:300]}")
    return False


def find_ritm_for_request(request_sys_id: str, auth, extra_headers: dict, log=print, *,
                          base_url: Optional[str] = None) -> dict:
    if not request_sys_id:
        return {}
    rows = _get_rows(f"{base_url or BASE_URL}/api/now/table/sc_req_item", auth, extra_headers, "buscar el RITM",
                     lambda m: log(f"  {m}"), params={"sysparm_query": f"request={request_sys_id}",
                                                      "sysparm_fields": "sys_id,number,state",
                                                      "sysparm_display_value": "all", "sysparm_limit": 5})
    return {"ritm_sys_id": _raw(rows[0].get("sys_id")), "ritm_number": _raw(rows[0].get("number"))} if rows else {}


def ritm_url(ritm_sys_id: str, base_url: Optional[str] = None) -> str:
    return f"{base_url or BASE_URL}/nav_to.do?uri=sc_req_item.do?sys_id={ritm_sys_id}" if ritm_sys_id else ""


def send_request(scenario_name: str, payload: dict, auth, extra_headers: dict, dry_run: bool,
                  log=print, *, base_url: Optional[str] = None, sys_id: Optional[str] = None) -> dict:
    base_url = base_url or BASE_URL
    sys_id = sys_id or SYS_ID
    order_url = f"{base_url}/api/sn_sc/servicecatalog/items/{sys_id}/order_now"

    headers = {"Accept": "application/json", "Content-Type": "application/json"}
    headers.update(extra_headers)

    if dry_run:
        log(f"--- [DRY RUN] {scenario_name} ---")
        log(json.dumps(payload, indent=2, ensure_ascii=False))
        return {"scenario": scenario_name, "status": "dry-run", "sys_id": "", "request_number": "", "error": ""}

    try:
        resp = requests.post(order_url, auth=auth, headers=headers, json=payload, timeout=30)
    except requests.RequestException as exc:
        log(f"[{scenario_name}] ERROR de red: {exc}")
        return {"scenario": scenario_name, "status": "network_error", "sys_id": "", "request_number": "", "error": str(exc)}

    result_row = {"scenario": scenario_name, "status": resp.status_code, "sys_id": "", "request_number": "", "error": ""}

    if resp.status_code in (200, 201):
        try:
            body = resp.json()
            result = body.get("result", {})
            result_row["request_number"] = result.get("request_number", "")
            result_row["sys_id"] = result.get("sys_id", "") or result.get("request_id", "")
            log(f"[{scenario_name}] OK ({resp.status_code}) -> request_number: {result_row['request_number']}")
        except (ValueError, KeyError) as exc:
            result_row["error"] = f"Respuesta OK pero no se pudo parsear: {exc}"
            log(f"[{scenario_name}] OK ({resp.status_code}) pero respuesta inesperada:\n{resp.text[:500]}")
    else:
        result_row["error"] = resp.text[:1000]
        log(f"[{scenario_name}] FALLÓ ({resp.status_code}):\n{resp.text[:1000]}")
        if "mandatory" in resp.text.lower():
            log(f"[{scenario_name}] Diagnosticando variables obligatorias faltantes...")
            missing = diagnose_missing_variables(payload, auth, extra_headers, log=log,
                                                  base_url=base_url, sys_id=sys_id)
            if missing:
                result_row["error"] += f" | Variables obligatorias faltantes: {', '.join(missing)}"

    return result_row


def cancel_request(sys_id: str, auth, extra_headers: dict, log=print, *,
                    base_url: Optional[str] = None, cancel_table: Optional[str] = None,
                    cancel_state_field: Optional[str] = None,
                    cancel_state_value: Optional[str] = None) -> dict:
    if not sys_id:
        return {"cancelled": False, "cleanup_error": "sin sys_id (no se puede cancelar)"}

    base_url = base_url or BASE_URL
    cancel_table = cancel_table or CANCEL_TABLE
    cancel_state_field = cancel_state_field or CANCEL_STATE_FIELD
    cancel_state_value = cancel_state_value or CANCEL_STATE_VALUE

    url = f"{base_url}/api/now/table/{cancel_table}/{sys_id}"
    headers = {"Accept": "application/json", "Content-Type": "application/json"}
    headers.update(extra_headers)
    body = {
        cancel_state_field: cancel_state_value,
        "close_notes": "Cancelado automáticamente por test_servicenow_ticket.py (ticket de prueba)",
    }

    try:
        resp = requests.patch(url, auth=auth, headers=headers, json=body, timeout=30)
    except requests.RequestException as exc:
        log(f"  cleanup {sys_id}: ERROR de red: {exc}")
        return {"cancelled": False, "cleanup_error": str(exc)}

    if resp.status_code in (200, 201):
        log(f"  cleanup {sys_id}: cancelado OK")
        return {"cancelled": True, "cleanup_error": ""}

    log(f"  cleanup {sys_id}: FALLÓ ({resp.status_code}): {resp.text[:300]}")
    return {"cancelled": False, "cleanup_error": f"{resp.status_code}: {resp.text[:300]}"}


def get_audit_history(table: str, sys_id: str, auth, extra_headers: dict, log=print, *,
                       base_url: Optional[str] = None) -> list[dict]:
    base_url = base_url or BASE_URL
    url = (f"{base_url}/api/now/table/sys_audit"
           f"?sysparm_query=tablename={table}^documentkey={sys_id}^ORDERBYsys_created_on"
           f"&sysparm_fields=fieldname,oldvalue,newvalue,user,sys_created_on,reason"
           f"&sysparm_display_value=true"
           f"&sysparm_limit=200")
    headers = {"Accept": "application/json"}
    headers.update(extra_headers)

    try:
        resp = requests.get(url, auth=auth, headers=headers, timeout=30)
    except requests.RequestException as exc:
        log(f"ERROR de red al consultar auditoría: {exc}")
        return []

    if resp.status_code != 200:
        log(f"No se pudo consultar auditoría ({resp.status_code}): {resp.text[:1000]}")
        return []

    try:
        rows = resp.json().get("result", [])
    except ValueError:
        log("Respuesta no es JSON válido al consultar auditoría.")
        return []

    if not rows:
        log(f"(sin registros de auditoría para {table}/{sys_id} — revisa que el sys_id/tabla sean "
            f"correctos, o que tu usuario tenga permiso de lectura sobre sys_audit)")
        return rows

    log(f"--- Historial de cambios de {table}/{sys_id} (quién cambió qué, y cuándo) ---")
    for row in rows:
        who = row.get("user", "") or "(sistema/desconocido)"
        log(f"  {row.get('sys_created_on', '')}  [{who}]  {row.get('fieldname', '')}: "
            f"'{row.get('oldvalue', '')}' -> '{row.get('newvalue', '')}'"
            + (f"   motivo: {row.get('reason')}" if row.get("reason") else ""))
    log("  >>> Si el cambio de 'state' a Closed/Cancelled aparece con un usuario del sistema, "
        "una cuenta de servicio, o un Flow/Workflow (no tu usuario real y no justo después del "
        "mensaje 'Limpiando tickets de prueba...' en el log de este script), el cierre lo está "
        "haciendo ServiceNow del lado del servidor, no este script.")
    return rows


def list_variables(auth, extra_headers: dict, mandatory_only: bool = True, log=print, *,
                    base_url: Optional[str] = None, sys_id: Optional[str] = None) -> list[dict]:
    base_url = base_url or BASE_URL
    sys_id = sys_id or SYS_ID
    query = f"cat_item={sys_id}"
    if mandatory_only:
        query += "^mandatory=true"
    url = (f"{base_url}/api/now/table/item_option_new"
           f"?sysparm_query={query}^ORDERBYorder"
           f"&sysparm_fields=name,question_text,mandatory,active,order,type"
           f"&sysparm_display_value=true"
           f"&sysparm_limit=200")
    headers = {"Accept": "application/json"}
    headers.update(extra_headers)

    try:
        resp = requests.get(url, auth=auth, headers=headers, timeout=30)
    except requests.RequestException as exc:
        log(f"ERROR de red al listar variables: {exc}")
        return []

    if resp.status_code != 200:
        log(f"No se pudieron listar variables ({resp.status_code}): {resp.text[:1000]}")
        return []

    try:
        rows = resp.json().get("result", [])
    except ValueError:
        log("Respuesta no es JSON válido al listar variables.")
        return []

    if not rows:
        log("(sin resultados — revisa que SNOW_CATALOG_SYS_ID sea correcto, "
            "o que tu usuario tenga permiso de lectura sobre item_option_new)")
        return rows

    label = "obligatorias" if mandatory_only else "todas las"
    log(f"Variables {label} del catalog item ({len(rows)}):")
    for row in rows:
        flag = "OBLIGATORIA" if str(row.get("mandatory")).lower() == "true" else "opcional"
        active = "" if str(row.get("active", "true")).lower() == "true" else " [INACTIVA]"
        tipo = row.get("type", "")
        log(f"  [{flag}]{active} {row.get('name')}  (tipo: {tipo})  —  {row.get('question_text')}")
    return rows


def diagnose_missing_variables(payload: dict, auth, extra_headers: dict, log=print, *,
                                base_url: Optional[str] = None, sys_id: Optional[str] = None) -> list[str]:
    mandatory_vars = list_variables(auth, extra_headers, mandatory_only=True, log=lambda *_: None,
                                     base_url=base_url, sys_id=sys_id)
    sent_names = set(payload.get("variables", {}).keys())
    missing = [v.get("name") for v in mandatory_vars if v.get("name") not in sent_names]

    if missing:
        log("  >>> Variables obligatorias que FALTAN en el payload enviado:")
        for name in missing:
            v = next((v for v in mandatory_vars if v.get("name") == name), {})
            log(f"       - {name}  (tipo: {v.get('type', '')})  —  {v.get('question_text', '')}")
    elif mandatory_vars:
        reference_like = [v for v in mandatory_vars
                           if v.get("name") in sent_names
                           and any(kw in str(v.get("type", "")).lower() for kw in ("reference", "lookup", "list collector"))]
        if reference_like:
            log("  >>> Todas las variables obligatorias se enviaron, pero estas son de tipo "
                "referencia/lookup: si el valor no existe como registro real en tu instancia, "
                "ServiceNow lo trata como vacío y por eso sigue marcando 'mandatory':")
            for v in reference_like:
                name = v.get("name")
                log(f"       - {name} = '{payload['variables'].get(name)}'  (tipo: {v.get('type')})")
        else:
            log("  >>> Todas las variables marcadas 'obligatorias' sí se enviaron; el "
                "rechazo probablemente es por un VALOR inválido (ej. una opción de choice "
                "que no existe en tu instancia), no por un campo faltante.")
    else:
        log("  >>> No se pudo obtener la lista de variables obligatorias para comparar "
            "(revisa el mensaje anterior).")

    return missing


def get_variable_detail(auth, extra_headers: dict, name: str, log=print, *,
                         base_url: Optional[str] = None, sys_id: Optional[str] = None) -> dict:
    base_url = base_url or BASE_URL
    sys_id = sys_id or SYS_ID
    url = (f"{base_url}/api/now/table/item_option_new"
           f"?sysparm_query=cat_item={sys_id}^name={name}"
           f"&sysparm_fields=name,question_text,type,mandatory,active,order,help_text,default_value,tooltip"
           f"&sysparm_display_value=true"
           f"&sysparm_limit=5")
    headers = {"Accept": "application/json"}
    headers.update(extra_headers)

    try:
        resp = requests.get(url, auth=auth, headers=headers, timeout=30)
    except requests.RequestException as exc:
        log(f"ERROR de red al consultar '{name}': {exc}")
        return {}

    if resp.status_code != 200:
        log(f"No se pudo consultar '{name}' ({resp.status_code}): {resp.text[:1000]}")
        return {}

    try:
        rows = resp.json().get("result", [])
    except ValueError:
        log("Respuesta no es JSON válido.")
        return {}

    if not rows:
        log(f"(no se encontró la variable '{name}' en este catalog item)")
        return {}

    row = rows[0]
    log(f"--- Detalle de '{name}' ---")
    for key in ("name", "question_text", "type", "mandatory", "active", "order",
                "help_text", "tooltip", "default_value"):
        val = row.get(key, "")
        if val:
            log(f"  {key}: {val}")
    return row


def list_recent_tickets(auth, extra_headers: dict, limit: int = 25, log=print, *,
                         base_url: Optional[str] = None, sys_id: Optional[str] = None) -> list[dict]:
    base_url = base_url or BASE_URL
    sys_id = sys_id or SYS_ID
    url = (f"{base_url}/api/now/table/sc_req_item"
           f"?sysparm_query=cat_item={sys_id}^ORDERBYDESCsys_created_on"
           f"&sysparm_fields=sys_id,number,state,short_description,sys_created_on,request"
           f"&sysparm_display_value=all"
           f"&sysparm_limit={limit}")
    headers = {"Accept": "application/json"}
    headers.update(extra_headers)

    try:
        resp = requests.get(url, auth=auth, headers=headers, timeout=30)
    except requests.RequestException as exc:
        log(f"ERROR de red al listar tickets: {exc}")
        return []

    if resp.status_code != 200:
        log(f"No se pudieron listar tickets ({resp.status_code}): {resp.text[:1000]}")
        return []

    try:
        rows = resp.json().get("result", [])
    except ValueError:
        log("Respuesta no es JSON válido al listar tickets.")
        return []

    def _raw(field):
        return field.get("value", "") if isinstance(field, dict) else (field or "")

    def _readable(field):
        return field.get("display_value", "") if isinstance(field, dict) else (field or "")

    tickets = []
    for row in rows:
        tickets.append({
            "ritm_sys_id": _raw(row.get("sys_id")),
            "ritm_number": _raw(row.get("number")),
            "request_sys_id": _raw(row.get("request")),
            "state": _readable(row.get("state")),
            "short_description": _readable(row.get("short_description"))[:80],
            "created": _raw(row.get("sys_created_on")),
        })

    if not tickets:
        log("(sin tickets encontrados para este catalog item)")
    return tickets


def cleanup_results(results: list[dict], auth, extra_headers: dict, log=print, *,
                     base_url: Optional[str] = None, cancel_table: Optional[str] = None,
                     cancel_state_field: Optional[str] = None,
                     cancel_state_value: Optional[str] = None) -> None:
    for row in results:
        if row.get("status") in (200, 201) and row.get("sys_id"):
            cleanup = cancel_request(row["sys_id"], auth, extra_headers, log=log,
                                      base_url=base_url, cancel_table=cancel_table,
                                      cancel_state_field=cancel_state_field,
                                      cancel_state_value=cancel_state_value)
            row["cleanup_status"] = "cancelado" if cleanup["cancelled"] else "error"
            row["cleanup_error"] = cleanup["cleanup_error"]
        else:
            row["cleanup_status"] = "n/a"
            row["cleanup_error"] = ""


def log_results(rows: list[dict], log_file: str = LOG_FILE) -> None:
    file_exists = os.path.isfile(log_file)
    fieldnames = ["timestamp", "scenario", "status", "sys_id", "request_number",
                  "error", "cleanup_status", "cleanup_error"]
    with open(log_file, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        if not file_exists:
            writer.writeheader()
        for row in rows:
            row_out = {"timestamp": datetime.now().isoformat(timespec="seconds")}
            row_out.update({k: row.get(k, "") for k in fieldnames if k != "timestamp"})
            writer.writerow(row_out)
    print(f"\nResultados agregados a {log_file}")


# ══ Tickets automáticos del escáner (un ticket por aplicación) ═══════════════════════════════════════════
# Primer escaneo con críticas/altas → se crea el ticket a nombre del usuario de ServiceNow que escanea.
# Escaneos siguientes → se ACTUALIZA el mismo ticket (work notes) con métricas de remediación.
# Sin críticas ni altas en ningún servicio → el ticket se cierra solo.
# Si el ticket se cerró a mano en ServiceNow y vuelven a aparecer críticas/altas, se abre uno nuevo.

STORE_FILENAME = "servicenow_tickets.json"
_LOCK = threading.Lock()
_SEV = ("critical", "high", "medium", "low")
KIND_LABEL = {"sca": "Dependencias (SCA)", "code": "Código (SAST)", "secrets": "Secretos", "container": "Contenedores",
              "iac": "Infraestructura (IaC)", "dast": "Web (DAST)", "api": "API"}
# Servicio del catalog item que cubre cada etapa del escáner.
KIND_TO_SERVICE = {"sca": "sast_sca", "code": "sast_sca", "container": "sast_sca", "iac": "sast_sca",
                   "secrets": "secretos", "dast": "dast", "api": "api"}
# Entorno del perfil de la aplicación → opción «ambiente» del catalog item.
_AMBIENTE = (("desarrollo", "Desarrollo"), ("qa", "QA"), ("pruebas", "QA"), ("preproducci", "QA"), ("staging", "QA"))
_REQUESTER_CACHE: dict = {}


def scanner_environment() -> Environment:
    """Ambiente de ServiceNow donde el escáner levanta tickets (Producción por defecto)."""
    return load_environment(SCANNER_ENV if SCANNER_ENV in ENVIRONMENT_KEYS else "prod")


def ambiente_for(profile_env: str) -> str:
    low = (profile_env or "").lower()
    return next((v for k, v in _AMBIENTE if k in low), "Producción")


def _snow_now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _pl(n: int, one: str, many: str) -> str:
    return one if n == 1 else many


def _sum(services: dict) -> dict:
    return {s: sum(int((c or {}).get(s, 0) or 0) for c in (services or {}).values()) for s in _SEV}


def _ch(c: dict) -> int:
    return int((c or {}).get("critical", 0) or 0) + int((c or {}).get("high", 0) or 0)


def _hot(services: dict) -> bool:
    return any(_ch(c) for c in (services or {}).values())


def _fmt(c: dict) -> str:
    c = c or {}
    return f"C{c.get('critical', 0)} / A{c.get('high', 0)} / M{c.get('medium', 0)} / B{c.get('low', 0)}"


def _days(since: str) -> int:
    try:
        return max((datetime.now() - datetime.strptime(since[:19], "%Y-%m-%d %H:%M:%S")).days, 0)
    except Exception:
        return 0


def _service_lines(prev: dict, cur: dict) -> list[str]:
    out = []
    for k in KIND_LABEL:
        if k not in cur:
            continue
        c, p = cur[k], (prev or {}).get(k)
        line = f"  • {KIND_LABEL[k]}: {_fmt(c)}"
        if p is not None:
            d = _ch(p) - _ch(c)
            line += f"  ({'−' if d > 0 else '+'}{abs(d)} críticas/altas)" if d else "  (sin cambio en críticas/altas)"
        out.append(line + ("  ✓" if not _ch(c) else ""))
    return out


def _metrics(rec: dict, cur: dict) -> list[str]:
    opened, last = rec.get("opened_services") or {}, rec.get("last_services") or {}
    o, l, n = _ch(_sum(opened)), _ch(_sum(last)), _ch(_sum(cur))
    fixed_total = max(o - n, 0)
    pct = round(100 * fixed_total / o) if o else 100
    clean = sum(1 for c in cur.values() if not _ch(c))
    return [f"Métricas de remediación (críticas + altas):",
            f"  • Al abrir el ticket: {o}   ·   última actualización: {l}   ·   ahora: {n}",
            f"  • Remediadas desde la apertura: {fixed_total} ({pct}%)   ·   desde la última actualización: "
            f"{max(l - n, 0)}   ·   nuevas: {max(n - l, 0)}",
            f"  • Servicios sin críticas ni altas: {clean} de {len(cur)}",
            f"  • Días abierto: {_days(rec.get('created_at', ''))}   ·   escaneos desde la apertura: "
            f"{rec.get('scans_since_open', 0) + 1}"]


def _text_created(name: str, cur: dict, actor: str) -> str:
    t = _sum(cur)
    return "\n".join([f"Escaneo automático de seguridad de {name} detectó {t['critical']} "
                      f"{_pl(t['critical'], 'vulnerabilidad crítica', 'vulnerabilidades críticas')} y {t['high']} "
                      f"{_pl(t['high'], 'alta', 'altas')}. Se solicita revisión y remediación.",
                      f"Total: {_fmt(t)}. Escaneó: {actor or 'escáner SecDevOps'}.", "Detalle por servicio:",
                      *_service_lines({}, cur),
                      "Este ticket se actualizará en cada escaneo y se cerrará automáticamente cuando no queden "
                      "vulnerabilidades críticas ni altas."])


def _text_progress(rec: dict, cur: dict, scanned: list, actor: str) -> str:
    t = _sum(cur)
    return "\n".join([f"Re-escaneo de {rec['name']} ({', '.join(KIND_LABEL.get(k, k) for k in scanned) or '—'}) "
                      f"por {actor or 'escáner SecDevOps'}. Estado actual: {_fmt(t)}.",
                      *_metrics(rec, cur), "Detalle por servicio:", *_service_lines(rec.get("last_services"), cur),
                      f"Siguen pendientes {t['critical']} {_pl(t['critical'], 'crítica', 'críticas')} y {t['high']} "
                      f"{_pl(t['high'], 'alta', 'altas')}."])


def _text_closed(rec: dict, cur: dict, actor: str) -> str:
    t = _sum(cur)
    return "\n".join([f"Re-escaneo de {rec['name']} por {actor or 'escáner SecDevOps'} ya no reporta vulnerabilidades "
                      "críticas ni altas en ningún servicio. Se cierra el ticket automáticamente.",
                      *_metrics(rec, cur), "Detalle por servicio:", *_service_lines(rec.get("last_services"), cur),
                      f"Quedan {t['medium']} {_pl(t['medium'], 'media', 'medias')} y {t['low']} "
                      f"{_pl(t['low'], 'baja', 'bajas')} sin impacto en el gate."])


def _label(rec) -> str:
    return rec.get("ritm_number") or rec.get("request_number") or rec.get("sys_id", "")


def lookup_requester(auth, hdrs: dict, env: Environment, fallback_user: str = "", log=print) -> dict:
    """Solicitante = el usuario de Windows que escanea, buscado en sys_user por correo (UPN) o por usuario.
    Devuelve id, nombre, correo y sys_id (para «requested_for»)."""
    ident = windows_identity()
    login = ident.get("login") or fallback_user
    key = (env.base_url, login.lower())
    if key not in _REQUESTER_CACHE:
        q = "^NQ".join(x for x in (f"email={ident['correo']}^active=true" if ident.get("correo") else "",
                                    f"user_name={login}^active=true" if login else "") if x)
        rows = _get_rows(f"{env.base_url}/api/now/table/sys_user", auth, hdrs, "consultar el usuario solicitante",
                         lambda m: log(f"[servicenow] {m}"),
                         params={"sysparm_query": q, "sysparm_fields": "sys_id,user_name,name,email",
                                 "sysparm_limit": 1}) or [] if q else []
        row = rows[0] if rows else {}
        if not row:
            log(f"[servicenow] ⚠ no se encontró a {ident.get('correo') or login} en ServiceNow — el ticket queda con "
                "los datos de Windows, sin «requested_for»")
        _REQUESTER_CACHE[key] = {"id": _raw(row.get("user_name")) or login,
                                 "nombre": _raw(row.get("name")) or ident.get("nombre") or login,
                                 "correo": _raw(row.get("email")) or ident.get("correo", ""),
                                 "sys_id": _raw(row.get("sys_id"))}
    return _REQUESTER_CACHE[key]


def _ritm_active(rec: dict, auth, hdrs: dict, env: Environment, log) -> Optional[bool]:
    sid = rec.get("ritm_sys_id")
    if not sid:
        return None
    rows = _get_rows(f"{env.base_url}/api/now/table/{RITM_TABLE}", auth, hdrs, "consultar el estado del ticket",
                     lambda m: log(f"[servicenow] {m}"),
                     params={"sysparm_query": f"sys_id={sid}", "sysparm_fields": "active,number", "sysparm_limit": 1})
    if rows is None:
        return None
    return bool(rows) and str(_raw(rows[0].get("active"))).lower() == "true"


def find_open_app_ticket(app_name: str, auth, hdrs: dict, env: Environment, log=print) -> dict:
    """Busca en ServiceNow un RITM ACTIVO de este catalog item para la aplicación (por la variable
    «nombre_de_la_aplicaci_n»). Así no se duplica el ticket aunque lo haya creado otra persona u otro equipo."""
    q = (f"request_item.cat_item={env.sys_id}^request_item.active=true"
         f"^sc_item_option.item_option_new.name=nombre_de_la_aplicaci_n^sc_item_option.value={app_name}"
         "^ORDERBYDESCrequest_item.sys_created_on")
    rows = _get_rows(f"{env.base_url}/api/now/table/sc_item_option_mtom", auth, hdrs,
                     "buscar un ticket abierto de la aplicación", lambda m: log(f"[servicenow] {m}"),
                     params={"sysparm_query": q, "sysparm_limit": 1,
                             "sysparm_fields": "request_item.sys_id,request_item.number,request_item.request"})
    if not rows:
        return {}
    r = rows[0]
    return {"ritm_sys_id": _raw(r.get("request_item.sys_id")), "ritm_number": _raw(r.get("request_item.number")),
            "sys_id": _raw(r.get("request_item.request"))}


def _create(key, name, cur, ctx, env, auth, hdrs, log) -> dict:
    hot_kinds = [k for k, c in cur.items() if _ch(c)]
    services = sorted({KIND_TO_SERVICE[k] for k in hot_kinds if k in KIND_TO_SERVICE}) or ["sast_sca"]
    targets = ctx.get("targets") or {}
    ov = {}
    if "sast_sca" in services or "dast" in services or "api" in services:
        ov["organizaci_n_en_snyk"] = ctx.get("snyk_org") or "TEST-ORG"
    if "dast" in services and targets.get("dast"):
        ov["url_objetivo"] = targets["dast"]
    if "api" in services and targets.get("api"):
        ov["url_de_la_api"] = targets["api"]
    if "secretos" in services:
        ov.update(repositorio_s=json.dumps([{"name": targets.get("repo") or name}], ensure_ascii=False),
                  ruta_monorepo="/")
    req = lookup_requester(auth, hdrs, env, ctx.get("actor", ""), log)
    actor = req.get("nombre") or req.get("id") or ctx.get("actor", "")
    payload = build_payload(services, ambiente=ambiente_for(ctx.get("environment", "")), app_name=name,
                            descripcion=_text_created(name, cur, actor), solicitante_id=req.get("id"),
                            solicitante_nombre=req.get("nombre") or req.get("id"), solicitante_correo=req.get("correo"), overrides=ov)
    if req.get("sys_id"):
        payload["sysparm_requested_for"] = req["sys_id"]  # el ticket queda a nombre de quien escanea
    row = send_request(f"app:{name}", payload, auth, hdrs, dry_run=False, log=lambda m: log(f"[servicenow] {m}"),
                       base_url=env.base_url, sys_id=env.sys_id)
    ok, now = row.get("status") in (200, 201), _snow_now()
    rec = {"key": key, "env": env.key, "name": name, "app_name": name, "status": "open" if ok else "error",
           "sys_id": row.get("sys_id", ""), "request_number": row.get("request_number", ""), "ritm_sys_id": "",
           "ritm_number": "", "created_at": now, "updated_at": now, "requester": req.get("id", ""),
           "opened_services": cur, "last_services": cur, "opened_counts": _sum(cur), "last_counts": _sum(cur),
           "scans_since_open": 0,
           "history": [{"ts": now, "event": "created" if ok else "create_failed",
                        "note": payload["variables"].get("descripci_n_de_la_solicitud_justificaci_n", "") if ok
                        else row.get("error", "")}]}
    if ok and rec["sys_id"]:
        rec.update(find_ritm_for_request(rec["sys_id"], auth, hdrs, log=log, base_url=env.base_url))
    log(f"[servicenow] ticket creado en {env.label} para {name}: {_label(rec)} (solicitante: {req.get('id', '?')})"
        if ok else f"[servicenow] no se pudo crear el ticket para {name}: {row.get('error', '')[:200]}")
    return rec


def _touch(rec, cur, scanned, env, auth, hdrs, log, close: bool, actor: str) -> None:
    note = _text_closed(rec, cur, actor) if close else _text_progress(rec, cur, scanned, actor)
    table = RITM_TABLE if rec.get("ritm_sys_id") else CANCEL_TABLE
    fields = {COMMENT_FIELD: note}
    if close:
        fields.update({RESOLVE_STATE_FIELD: RESOLVE_STATE_VALUE, "close_notes": note})
    ok = update_record(table, rec.get("ritm_sys_id") or rec.get("sys_id"), fields, auth, hdrs,
                       log=lambda m: log(f"[servicenow] {m}"), base_url=env.base_url)
    now = _snow_now()
    if ok:
        rec.update(last_services=cur, last_counts=_sum(cur), updated_at=now,
                   scans_since_open=rec.get("scans_since_open", 0) + 1)
        if close:
            rec.update(status="closed", closed_at=now)
    event = ("closed" if close else "updated") + ("" if ok else "_failed")
    rec["history"] = (rec.get("history") or [])[-29:] + [{"ts": now, "event": event, "note": note}]
    log("[servicenow] " + (("ticket cerrado automáticamente" if ok else "no se pudo cerrar el ticket") if close else
                           ("ticket actualizado con métricas de remediación" if ok else
                            "no se pudo actualizar el ticket")) + f": {_label(rec)}")


def sync_app_ticket(reports_root, *, name: str, services: dict, scanned: list, environment: str = "",
                    targets: Optional[dict] = None, snyk_org: str = "", actor: str = "", allow_close: bool = True,
                    log=print) -> Optional[dict]:
    """Crea, actualiza o cierra el ticket de la aplicación.

    services: {etapa: {"critical", "high", "medium", "low"}} — estado vigente de cada servicio de la app (lo último
    escaneado de cada uno), no solo lo de este escaneo. scanned: etapas que corrieron en este escaneo."""
    name = (name or "").strip()
    if not name:
        log("[servicenow] sin nombre de aplicación — se omite el ticket")
        return None
    env = scanner_environment()
    if not (env.base_url and env.sys_id):
        log(f"[servicenow] falta la URL o el sys_id del catalog item de {env.label} — configúrelo en Escanear → "
            "Preparación → ServiceNow")
        return None
    cur = {k: {s: int((c or {}).get(s, 0) or 0) for s in _SEV} for k, c in (services or {}).items()}
    key = f"{env.key}:app:{name.lower()}"
    path = Path(reports_root) / STORE_FILENAME
    ctx = {"targets": targets or {}, "snyk_org": snyk_org, "environment": environment, "actor": actor}
    with _LOCK:
        try:
            store = json.loads(path.read_text(encoding="utf-8"))
            store.setdefault("tickets", {})
        except Exception:
            store = {"version": 2, "tickets": {}}
        rec = store["tickets"].get(key)
        hot = _hot(cur)
        auth_pair = scanner_auth(env)
        if auth_pair is None:
            if hot or (rec and rec.get("status") == "open"):
                log(f"[servicenow] sin credenciales para {env.label} — no se sincroniza el ticket "
                    "(Escanear → Preparación → ServiceNow)")
            return rec
        auth, hdrs = auth_pair
        who = lookup_requester(auth, hdrs, env, actor, log)
        who = who.get("nombre") or who.get("id") or actor
        try:
            if rec and rec.get("status") == "open" and _ritm_active(rec, auth, hdrs, env, log) is False:
                log(f"[servicenow] {_label(rec)} ya estaba cerrado en ServiceNow — se marca como cerrado")
                rec.update(status="closed", closed_at=_snow_now())
            if not (rec and rec.get("status") == "open"):
                found = find_open_app_ticket(name, auth, hdrs, env, log) if hot or rec is None else {}
                if found.get("ritm_sys_id"):
                    log(f"[servicenow] ya existe un ticket abierto para {name} ({found.get('ritm_number')}) — se "
                        "actualiza en lugar de crear otro")
                    rec = {"key": key, "env": env.key, "name": name, "app_name": name, "status": "open",
                           "request_number": "", **found, "created_at": _snow_now(), "updated_at": _snow_now(),
                           "opened_services": cur, "last_services": (rec or {}).get("last_services") or cur,
                           "opened_counts": _sum(cur), "last_counts": _sum(cur), "scans_since_open": 0,
                           "adopted": True, "history": []}
            if rec and rec.get("status") == "open":
                close = not hot and allow_close
                if not hot and not allow_close:
                    log("[servicenow] sin críticas/altas, pero alguna etapa no se completó — el ticket se actualiza "
                        "y se cerrará cuando el escaneo termine completo")
                _touch(rec, cur, scanned, env, auth, hdrs, log, close=close, actor=who)
            elif hot:
                if rec and rec.get("status") == "closed":
                    log(f"[servicenow] {name}: reaparecen críticas/altas tras cerrarse {_label(rec)} — se abre uno nuevo")
                rec = _create(key, name, cur, ctx, env, auth, hdrs, log)
        except Exception as e:
            log(f"[servicenow] error de sincronización, se continúa sin ticket: {e!r}")
        if rec is not None:
            store["tickets"][key] = rec
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(store, indent=2, ensure_ascii=False), encoding="utf-8")
        return rec


def public_view(rec: Optional[dict]) -> dict:
    if not rec:
        return {}
    env = load_environment(rec.get("env") or SCANNER_ENV)
    return {"kind": "app", "name": rec.get("name", ""), "status": rec.get("status", ""),
            "number": rec.get("ritm_number") or rec.get("request_number") or "",
            "link": ritm_url(rec["ritm_sys_id"], env.base_url) if rec.get("ritm_sys_id") else ""}


def main():
    parser = argparse.ArgumentParser(description="Prueba el template de ticket de ServiceNow.")
    parser.add_argument("--service", action="append", metavar="NAME", choices=list(SERVICES.keys()),
                         help="Servicio a incluir en el ticket (repetible: --service dast --service api). Si no se especifica, se incluyen todos en un solo ticket.")
    parser.add_argument("--ambiente", help="Sobrescribe el ambiente (ej. 'Producción' para probar la nota de validación).")
    parser.add_argument("--app-name", help=f"Nombre de la aplicación a usar en el ticket (default: '{DEFAULT_APP_NAME}').")
    parser.add_argument("--descripcion", help="Descripción/justificación de la solicitud (default: texto genérico de revisión periódica).")
    parser.add_argument("--solicitante-nombre", metavar="NOMBRE",
                         help="Nombre de la persona a cuyo nombre quedará el ticket (para probar con distintas personas).")
    parser.add_argument("--solicitante-correo", metavar="CORREO",
                         help="Correo de la persona a cuyo nombre quedará el ticket.")
    parser.add_argument("--solicitante-id", metavar="USUARIO",
                         help="ID/usuario ServiceNow de la persona a cuyo nombre quedará el ticket (opcional; por default se usa el mismo de siempre).")
    parser.add_argument("--var", action="append", metavar="NAME=VALUE",
                         help="Sobrescribe o agrega una variable del payload (repetible). Úsalo para dar valores REALES de organización/repositorio, ej: --var organizaci_n_en_snyk=MiOrgReal")
    parser.add_argument("--dry-run", action="store_true", help="Solo imprime el payload, no llama a la API.")
    parser.add_argument("--no-cleanup", action="store_true", help="No cancela los tickets de prueba al terminar.")
    parser.add_argument("--list", action="store_true", help="Lista las ramas disponibles y sale.")
    parser.add_argument("--inspect", action="store_true",
                         help="Consulta a ServiceNow cuáles variables son realmente obligatorias en el catalog item y sale (no crea tickets).")
    parser.add_argument("--inspect-all", action="store_true",
                         help="Como --inspect pero muestra todas las variables, no sólo las obligatorias.")
    parser.add_argument("--inspect-field", metavar="NAME",
                         help="Consulta el detalle completo (tipo, texto de ayuda, valor por defecto) de una variable específica y sale.")
    parser.add_argument("--list-tickets", nargs="?", const=25, type=int, metavar="N",
                         help="Lista los últimos N tickets (RITM) de este catalog item y sale (default 25).")
    parser.add_argument("--audit", metavar="SYS_ID",
                         help="Muestra el historial de cambios (sys_audit) de un registro por su sys_id, "
                              "para diagnosticar QUIÉN o QUÉ lo cerró/canceló (¿tu script, un usuario, o un Flow de ServiceNow?).")
    parser.add_argument("--audit-table", default="sc_req_item", metavar="TABLE",
                         help="Tabla del registro para --audit (default: sc_req_item, el RITM). "
                              "Usa 'sc_request' para auditar el REQ en vez del RITM.")
    parser.add_argument("--cancel", nargs="+", metavar="REQ_SYS_ID",
                         help="Cancela el/los REQ indicados por su sys_id (ver --list-tickets) y sale.")
    parser.add_argument("--remember", action="store_true",
                         help="Guarda las credenciales usadas en este comando (cifradas con DPAPI para esta cuenta de Windows).")
    parser.add_argument("--forget-credentials", action="store_true",
                         help="Borra las credenciales guardadas y sale.")
    parser.add_argument("--gui", action="store_true", help="Lanza la interfaz gráfica en vez del CLI.")
    parser.add_argument("--encode-secret", action="store_true",
                        help="Cifra una nueva contraseña de la cuenta de integración de Producción (para _SVC_BLOB) y sale.")
    parser.add_argument("--whoami", action="store_true", help="Muestra la identidad de Windows que se usará como solicitante.")
    args = parser.parse_args()

    if args.encode_secret:
        print(encode_service_secret(getpass.getpass("Contraseña de la cuenta de integración: ")))
        return
    if args.whoami:
        print(json.dumps(windows_identity(), indent=2, ensure_ascii=False))
        return

    if args.forget_credentials:
        clear_saved_credentials()
        print("Credenciales guardadas eliminadas.")
        return

    if args.gui:
        import gui_servicenow_tester
        gui_servicenow_tester.launch()
        return

    if args.list:
        print("Servicios disponibles:", ", ".join(SERVICES.keys()))
        return

    if args.inspect or args.inspect_all:
        auth, extra_headers = get_auth()
        if args.remember:
            remember_auth(auth, extra_headers)
        list_variables(auth, extra_headers, mandatory_only=not args.inspect_all)
        return

    if args.inspect_field:
        auth, extra_headers = get_auth()
        if args.remember:
            remember_auth(auth, extra_headers)
        get_variable_detail(auth, extra_headers, args.inspect_field)
        return

    if args.list_tickets is not None:
        auth, extra_headers = get_auth()
        if args.remember:
            remember_auth(auth, extra_headers)
        tickets = list_recent_tickets(auth, extra_headers, limit=args.list_tickets)
        for t in tickets:
            print(f"{t['ritm_number']:<14} {t['state']:<22} {t['created']:<20} "
                  f"{t['short_description']:<40} REQ sys_id: {t['request_sys_id']}")
        return

    if args.audit:
        auth, extra_headers = get_auth()
        if args.remember:
            remember_auth(auth, extra_headers)
        get_audit_history(args.audit_table, args.audit, auth, extra_headers)
        return

    if args.cancel:
        auth, extra_headers = get_auth()
        if args.remember:
            remember_auth(auth, extra_headers)
        for sys_id in args.cancel:
            cancel_request(sys_id, auth, extra_headers)
        return

    selected_services = args.service if args.service else list(SERVICES.keys())

    overrides = {}
    if args.var:
        for kv in args.var:
            if "=" not in kv:
                print(f"Ignorando --var mal formado (usa NAME=VALUE): {kv}")
                continue
            k, v = kv.split("=", 1)
            overrides[k] = v

    auth, extra_headers = (None, {}) if args.dry_run else get_auth()
    if args.remember and not args.dry_run:
        remember_auth(auth, extra_headers)

    label = "+".join(selected_services)
    payload = build_payload(selected_services, ambiente=args.ambiente, app_name=args.app_name,
                             descripcion=args.descripcion, solicitante_id=args.solicitante_id,
                             solicitante_nombre=args.solicitante_nombre,
                             solicitante_correo=args.solicitante_correo, overrides=overrides)
    results = [send_request(label, payload, auth, extra_headers, args.dry_run)]

    if args.dry_run:
        print("\n(dry-run: nada se envió ni se guardó en el log)")
        return

    print(f"[config] Limpieza automática (cancelar al terminar): "
          f"{'DESACTIVADA (--no-cleanup)' if args.no_cleanup else 'ACTIVADA'}")
    if not args.no_cleanup:
        print("\nLimpiando tickets de prueba...")
        cleanup_results(results, auth, extra_headers)
    else:
        for row in results:
            row["cleanup_status"] = "omitido"
            row["cleanup_error"] = ""

    log_results(results)


if __name__ == "__main__":
    sys.exit(main())
