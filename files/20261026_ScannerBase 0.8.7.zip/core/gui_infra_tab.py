"""Sección «Infraestructura»: páginas Contenedores e IaC."""
from __future__ import annotations

from ui_common import *
from infra_scanner import InfraConfig, detect_project

SOURCE_TYPES = {"registry": ("Registro", "cloud"), "archive": ("Archivo .tar / OCI", "package"),
                "sbom": ("SBOM", "document")}
FRAMEWORK_ORDER = ("Terraform", "Kubernetes", "Helm", "Kustomize", "Dockerfile", "CloudFormation", "ARM", "Bicep")


class _InfraTabMixin:
    def _init_infra_vars(self):
        saved = self._saved.get("infra") or {}
        self._container_sources = [s for s in saved.get("container_sources") or [] if isinstance(s, dict)]
        self._iac_paths = [p for p in saved.get("iac_paths") or [] if isinstance(p, str)]
        self._reg_user_var = tk.StringVar(value=saved.get("registry_user", ""))
        self._reg_pass_var = tk.StringVar()
        self._reg_insecure_var = tk.BooleanVar(value=bool(saved.get("insecure_registry", False)))
        self._unfixed_var = tk.BooleanVar(value=bool(saved.get("include_unfixed", True)))
        self._iac_skip_var = tk.StringVar(value=saved.get("skip_checks", ""))
        for v in (self._reg_user_var, self._reg_insecure_var, self._unfixed_var, self._iac_skip_var):
            v.trace_add("write", lambda *_: self.after_idle(self._persist_infra))

    def _dump_infra(self) -> dict:
        return {"container_sources": list(self._container_sources), "iac_paths": list(self._iac_paths),
                "registry_user": self._reg_user_var.get().strip(), "insecure_registry": bool(self._reg_insecure_var.get()),
                "include_unfixed": bool(self._unfixed_var.get()), "skip_checks": self._iac_skip_var.get().strip()}

    def _persist_infra(self):
        if self._active_app is not None:
            self._active_app["container_sources"] = list(self._container_sources)
            self._active_app["iac_paths"] = list(self._iac_paths)
            try:
                self._inv_store.save_app(self._active_app)
            except Exception as e:
                self._emit_log(f"[apps] no se pudo guardar la configuración de infraestructura: {e!r}")
        self._save_settings()
        self._refresh_scan_btn()

    def _container_sources_clean(self) -> list:
        return [s for s in getattr(self, "_container_sources", []) if (s.get("value") or "").strip()]

    def _iac_paths_effective(self) -> list:
        paths = [p for p in getattr(self, "_iac_paths", []) if p.strip()]
        if paths:
            return paths
        base = (self._target_var.get().strip() if hasattr(self, "_target_var") else "") or \
            (self._static_paths[0] if getattr(self, "_static_paths", None) else "")
        return [base] if base and Path(base).is_dir() else []

    def _collect_container_cfg(self) -> InfraConfig:
        return InfraConfig(sources=self._container_sources_clean(), registry_user=self._reg_user_var.get().strip(),
                           registry_password=self._reg_pass_var.get(), insecure_registry=bool(self._reg_insecure_var.get()),
                           include_unfixed=bool(self._unfixed_var.get()))

    def _collect_iac_cfg(self) -> InfraConfig:
        return InfraConfig(iac_paths=self._iac_paths_effective(), skip_checks=self._iac_skip_var.get())

    def _start_infra_scan(self, kind: str):
        if self._any_busy():
            return self._toast("Ya hay un escaneo en curso", "warn")
        if kind == "container" and not self._container_sources_clean():
            return self._show_warn_popup("Contenedores", "Agregue al menos una imagen (registro, archivo .tar o SBOM).")
        if kind == "iac" and not self._iac_paths_effective():
            return self._show_warn_popup("IaC", "Agregue la carpeta que contiene su infraestructura como código.")
        if not self._scan_vars[kind].get():
            self._scan_vars[kind].set(True)
            self._persist_scan_stages()
        target = Path(self._iac_paths_effective()[0]).resolve() if kind == "iac" else Path(".").resolve()

        def work():
            self._cancel_evt.clear()
            self._ui(self._pipeline_reset)
            self._execute_scan(lane="infra", target=target, sel={kind}, cancel=self._cancel_evt, batch=[target])
        self._confirm_scan_without_app(lambda: self._run_async(work, f"escaneo de {STAGE_LABELS[kind]}"))

    # ── Página «Contenedores» ───────────────────────────────────────────────
    def _build_tab_container(self, parent):
        pad = self._scrollable(parent)
        bar = tk.Frame(pad, bg=T["bg"])
        bar.pack(fill="x", pady=(0, CARD_GAP))
        PillButton(bar, "Escanear imágenes", lambda: self._start_infra_scan("container"), icon="play",
                   variant="primary").pack(side="left")
        tk.Frame(bar, bg=T["border"], width=1).pack(side="left", fill="y", padx=px(12), pady=px(4))
        self._btn(bar, "+ Imagen de registro", self._add_registry_image, tooltip=(
            "La imagen tal como la publica su pipeline, p. ej. registro.bancobase.com/equipo/servicio:1.4.2. "
            "Trivy la descarga directamente del registro; no necesita Docker en su PC.")).pack(side="left", padx=(0, px(6)))
        self._btn(bar, "+ Archivo .tar", self._add_image_archive, tooltip=(
            "Una imagen exportada con «docker save», «podman save» o «skopeo copy». Útil si el registro no es "
            "accesible desde su PC.")).pack(side="left", padx=(0, px(6)))
        self._btn(bar, "+ SBOM", self._add_sbom, tooltip=(
            "Lista de componentes (CycloneDX o SPDX) generada por su pipeline. Se revisan los componentes sin "
            "necesidad de la imagen.")).pack(side="left")
        cols = tk.Frame(pad, bg=T["bg"])
        cols.pack(fill="x")
        cols.columnconfigure(0, weight=3, uniform="ct")
        cols.columnconfigure(1, weight=2, uniform="ct")
        left, right = tk.Frame(cols, bg=T["bg"]), tk.Frame(cols, bg=T["bg"])
        left.grid(row=0, column=0, sticky="nsew", padx=(0, CARD_GAP // 2))
        right.grid(row=0, column=1, sticky="nsew", padx=(CARD_GAP // 2, 0))
        c = self._card(left, "Imágenes a analizar", collapsible=False)
        self._cont_list = tk.Frame(c, bg=T["panel_bg"])
        self._cont_list.pack(fill="x")
        self._render_container_sources()
        c = self._card(right, "Credenciales del registro (opcional)", collapsible=False)
        self._lbl(c, "Solo si sus imágenes están en un registro que pide usuario y contraseña (ECR, ACR, Harbor, "
                  "Artifactory…). Déjelo vacío para imágenes públicas o archivos .tar / SBOM.", size=10,
                  fg=T["muted"], anchor="w", justify="left", wraplength=px(380)).pack(fill="x", pady=(0, px(10)))
        for label, var, show, help_ in (
                ("Usuario", self._reg_user_var, "", "Use una cuenta de servicio de solo lectura. En AWS ECR el usuario "
                 "es «AWS»; en Azure ACR, el nombre del registro o el ID de una entidad de servicio."),
                ("Contraseña o token", self._reg_pass_var, "•", "Solo se guarda en memoria mientras el programa está "
                 "abierto. En ECR: salida de «aws ecr get-login-password» (dura 12 h).")):
            tip(self._lbl(c, label + "  ⓘ", size=10, bold=True, fg=T["muted"]), help_).pack(anchor="w")
            ttk.Entry(c, textvariable=var, show=show).pack(fill="x", pady=(px(3), px(10)))
        tip(ToggleSwitch(c, text="El registro usa un certificado interno", variable=self._reg_insecure_var),
            "Actívelo solo si la descarga falla por un error de certificado (registros con la CA interna del banco). "
            "Desactiva la verificación TLS únicamente para el registro.").pack(anchor="w")
        tip(ToggleSwitch(c, text="Incluir vulnerabilidades sin parche disponible", variable=self._unfixed_var),
            "Muestra también CVE para los que todavía no existe versión corregida. Desactívelo para ver solo lo que "
            "puede arreglar hoy actualizando un paquete o la imagen base.").pack(anchor="w", pady=(px(8), 0))
        res = self._card(pad, "Resultados", collapsible=False)
        self._cont_summary = tk.Label(res.right, text="", font=(FUI, 10, "bold"), bg=T["panel_bg"], fg=T["muted"])
        self._cont_summary.pack(side="right")
        box = tk.Frame(res, bg=T["panel_bg"])
        box.pack(fill="both", expand=True)
        self._cont_tree = make_tree(box, ("sev", "installed", "fixed", "id"), [
            ("Severidad", 100, "w", False), ("Instalada", 130, "w", False), ("Corregida en", 130, "w", False),
            ("CVE / regla", 170, "w", False)], 10, tree_col=("Imagen  /  Paquete", 320))
        for tag, role in (("crit", "err"), ("high", "warn"), ("med", "text"), ("low", "muted"), ("group", "text")):
            self._cont_tree.tag_configure(tag, foreground=T[role])
        self._cont_tree.tag_configure("group", font=(FUI, 10, "bold"))
        self._render_container_results()

    def _render_container_sources(self):
        box = getattr(self, "_cont_list", None)
        if box is None or not box.winfo_exists():
            return
        for w in box.winfo_children():
            w.destroy()
        p = T["panel_bg"]
        if not self._container_sources:
            for line in ("Agregue lo que tenga a mano:",
                         "·  Imagen de registro — p. ej. 123456789.dkr.ecr.us-east-1.amazonaws.com/pagos:1.4.2",
                         "·  Archivo .tar — generado con docker save / podman save / skopeo",
                         "·  SBOM — CycloneDX o SPDX exportado por su pipeline"):
                tk.Label(box, text=line, font=(FUI, 10), bg=p, fg=T["muted"], anchor="w").pack(fill="x")
            return
        for i, s in enumerate(self._container_sources):
            label, icon = SOURCE_TYPES.get(s.get("type"), SOURCE_TYPES["registry"])
            row = tk.Frame(box, bg=T["surface2"])
            row.pack(fill="x", pady=(0, px(4)))
            tk.Label(row, text=ico(icon), font=icon_font(12), bg=T["surface2"], fg=T["accent"]).pack(
                side="left", padx=(px(10), px(8)), pady=px(7))
            col = tk.Frame(row, bg=T["surface2"])
            col.pack(side="left", fill="x", expand=True)
            tk.Label(col, text=label.upper(), font=(FUI, 8, "bold"), bg=T["surface2"], fg=T["muted"], anchor="w").pack(
                fill="x")
            tk.Label(col, text=middle_ellipsis(s.get("value", ""), 90), font=(FMONO, 10), bg=T["surface2"],
                     fg=T["text"], anchor="w").pack(fill="x")
            PillButton(row, "", lambda i=i: self._remove_container_source(i), icon="delete", variant="danger_ghost",
                       size=10, tooltip="Quitar").pack(side="right", padx=px(6))

    def _remove_container_source(self, i):
        if 0 <= i < len(self._container_sources):
            del self._container_sources[i]
            self._render_container_sources()
            self._persist_infra()

    def _add_container_source(self, kind, value):
        value = (value or "").strip()
        if value and not any(s.get("value") == value for s in self._container_sources):
            self._container_sources.append({"type": kind, "value": value})
            self._render_container_sources()
            self._persist_infra()

    def _add_registry_image(self):
        popup = self._popup("Imagen de registro")
        self._popup_hdr(popup, "Agregar imagen de registro", subtitle="Referencia completa con tag o digest.")
        body = tk.Frame(popup, bg=T["bg"], padx=px(24), pady=px(4))
        body.pack(fill="both", expand=True)
        var = tk.StringVar()
        e = ttk.Entry(body, textvariable=var)
        e.pack(fill="x")
        e.focus_set()
        tk.Label(body, text="Ejemplos:\n  registro.bancobase.com/equipo/servicio:2.3.1\n"
                 "  123456789012.dkr.ecr.us-east-1.amazonaws.com/pagos@sha256:…\n  bancobase.azurecr.io/api-clientes:latest",
                 font=(FMONO, 9), bg=T["bg"], fg=T["muted"], justify="left", anchor="w").pack(fill="x", pady=(px(10), 0))

        def ok():
            ref = var.get().strip()
            if not re.match(r"^[\w.\-/:@]+$", ref) or ref.startswith(("http://", "https://")):
                return status.config(text="Formato inválido: use registro/repositorio:tag (sin http://).")
            self._add_container_source("registry", ref)
            popup.close()
        e.bind("<Return>", lambda _e: ok())
        _, status = self._popup_foot(popup, ("Cancelar", popup.close), ("Agregar", ok), with_status=True)

    def _add_image_archive(self):
        with dialog_guard(self):
            files = filedialog.askopenfilenames(title="Archivo de imagen (docker save / OCI)",
                                                filetypes=[("Imagen exportada", "*.tar *.tar.gz *.tgz"), ("Todos", "*.*")])
        for f in files or []:
            self._add_container_source("archive", f)

    def _add_sbom(self):
        with dialog_guard(self):
            files = filedialog.askopenfilenames(title="SBOM (CycloneDX / SPDX)",
                                                filetypes=[("SBOM", "*.json *.xml *.spdx *.cdx"), ("Todos", "*.*")])
        for f in files or []:
            self._add_container_source("sbom", f)

    def _render_container_results(self):
        tree = getattr(self, "_cont_tree", None)
        if tree is None or not tree.winfo_exists():
            return
        clear_tree(tree)
        data = (self._last_context or {}).get("container") or {}
        items = data.get("findings") or []
        groups: dict = {}
        for f in items:
            groups.setdefault(f.get("target") or "—", []).append(f)
        tag = {"critical": "crit", "high": "high", "medium": "med"}
        for name, fs in groups.items():
            worst = min((f["severity"] for f in fs), key=lambda s: SEV_ORDER.get(s, 9))
            pid = tree.insert("", "end", text=f"{middle_ellipsis(name, 60)}   ({len(fs)})", open=len(groups) == 1,
                              values=(SEV_ES.get(worst, worst), "", "", ""), tags=("group",))
            for f in fs:
                tree.insert(pid, "end", text="   " + (f.get("package") or f.get("title") or ""),
                            tags=(tag.get(f["severity"], "low"),),
                            values=(SEV_ES.get(f["severity"], f["severity"]), f.get("installed") or "—",
                                    f.get("fixed") or "—", f.get("vuln_id") or f.get("rule_id") or ""))
        imgs = data.get("images") or []
        if not items:
            tree.insert("", "end", text="  Sin resultados — ejecute un escaneo." if not imgs else
                        "  Sin vulnerabilidades en las imágenes analizadas ✓", tags=("low",))
        fixable = sum(1 for f in items if f.get("fixed"))
        self._cont_summary.config(text=f"{len(items)} hallazgo(s) · {fixable} con versión corregida" if items else "")

    # ── Página «IaC» ────────────────────────────────────────────────────────
    def _build_tab_iac(self, parent):
        pad = self._scrollable(parent)
        bar = tk.Frame(pad, bg=T["bg"])
        bar.pack(fill="x", pady=(0, CARD_GAP))
        PillButton(bar, "Escanear IaC", lambda: self._start_infra_scan("iac"), icon="play", variant="primary").pack(
            side="left")
        tk.Frame(bar, bg=T["border"], width=1).pack(side="left", fill="y", padx=px(12), pady=px(4))
        self._btn(bar, "+ Carpeta", self._add_iac_folder).pack(side="left", padx=(0, px(6)))
        self._btn(bar, "+ Archivo", self._add_iac_file).pack(side="left")
        c = self._card(pad, "Carpetas de infraestructura", collapsible=False)
        self._iac_list = tk.Frame(c, bg=T["panel_bg"])
        self._iac_list.pack(fill="x")
        self._iac_chips = tk.Frame(c, bg=T["panel_bg"])
        self._iac_chips.pack(fill="x", pady=(px(8), 0))
        self._render_iac_paths()
        c = self._card(pad, "Opciones", start_collapsed=True)
        tip(self._lbl(c, "Reglas a omitir (IDs de Checkov/Trivy separados por coma)  ⓘ", size=10, bold=True,
                      fg=T["muted"]), "Ejemplo: CKV_AWS_20, AVD-DS-0002. El ID aparece en la columna «Regla» de los "
                      "resultados. Se omite en todas las carpetas; para excepciones puntuales use anotaciones."
            ).pack(anchor="w")
        ttk.Entry(c, textvariable=self._iac_skip_var).pack(fill="x", pady=(px(3), px(4)))
        self._lbl(c, "Para aceptar un riesgo de forma puntual, prefiera una anotación en el código "
                  "(# checkov:skip=CKV_AWS_20: justificación).", size=9, fg=T["muted"], anchor="w", justify="left",
                  wraplength=px(700)).pack(fill="x")
        res = self._card(pad, "Resultados", collapsible=False)
        self._iac_summary = tk.Label(res.right, text="", font=(FUI, 10, "bold"), bg=T["panel_bg"], fg=T["muted"])
        self._iac_summary.pack(side="right")
        box = tk.Frame(res, bg=T["panel_bg"])
        box.pack(fill="both", expand=True)
        self._iac_tree = make_tree(box, ("sev", "line", "rule", "by"), [
            ("Severidad", 100, "w", False), ("Línea", 70, "center", False), ("Regla", 150, "w", False),
            ("Detectado por", 150, "w", False)], 10, tree_col=("Archivo  /  Hallazgo", 420))
        for tag, role in (("crit", "err"), ("high", "warn"), ("med", "text"), ("low", "muted"), ("group", "text")):
            self._iac_tree.tag_configure(tag, foreground=T[role])
        self._iac_tree.tag_configure("group", font=(FUI, 10, "bold"))
        self._render_iac_results()

    def _render_iac_paths(self):
        box = getattr(self, "_iac_list", None)
        if box is None or not box.winfo_exists():
            return
        for w in box.winfo_children():
            w.destroy()
        p = T["panel_bg"]
        eff = self._iac_paths_effective()
        if not self._iac_paths:
            msg = (f"Se usará la carpeta del repositorio: {middle_ellipsis(eff[0], 80)}" if eff else
                   "Agregue la carpeta con sus archivos Terraform, manifiestos de Kubernetes, charts de Helm, Dockerfile…")
            tk.Label(box, text=msg, font=(FUI, 10), bg=p, fg=T["muted"], anchor="w").pack(fill="x")
        for i, path in enumerate(self._iac_paths):
            row = tk.Frame(box, bg=T["surface2"])
            row.pack(fill="x", pady=(0, px(4)))
            tk.Label(row, text=ico("folder"), font=icon_font(11), bg=T["surface2"], fg=T["accent"]).pack(
                side="left", padx=(px(10), px(8)), pady=px(6))
            tk.Label(row, text=path, font=(FMONO, 10), bg=T["surface2"], fg=T["text"], anchor="w").pack(
                side="left", fill="x", expand=True)
            PillButton(row, "", lambda i=i: self._remove_iac_path(i), icon="delete", variant="danger_ghost", size=10,
                       tooltip="Quitar").pack(side="right", padx=px(6))
        self._render_iac_chips(eff)

    def _render_iac_chips(self, paths):
        box = getattr(self, "_iac_chips", None)
        if box is None or not box.winfo_exists():
            return
        for w in box.winfo_children():
            w.destroy()
        if not paths:
            return

        def work():
            fw: dict = {}
            for p in paths:
                det = detect_project(p if Path(p).is_dir() else Path(p).parent, max_files=4000)
                for k, n in det["iac"].items():
                    fw[k] = fw.get(k, 0) + n
            self._ui(paint, fw)

        def paint(fw):
            if not box.winfo_exists():
                return
            for w in box.winfo_children():
                w.destroy()
            tk.Label(box, text="Detectado:", font=(FUI, 9, "bold"), bg=T["panel_bg"], fg=T["muted"]).pack(side="left")
            if not fw:
                tk.Label(box, text="ningún archivo de IaC reconocido en la carpeta", font=(FUI, 9), bg=T["panel_bg"],
                         fg=T["warn"]).pack(side="left", padx=(px(6), 0))
            for k in sorted(fw, key=lambda x: FRAMEWORK_ORDER.index(x) if x in FRAMEWORK_ORDER else 99):
                pill_label(box, f"{k} · {fw[k]}", "text", "surface3", 9).pack(side="left", padx=(px(6), 0))
        threading.Thread(target=work, daemon=True).start()

    def _remove_iac_path(self, i):
        if 0 <= i < len(self._iac_paths):
            del self._iac_paths[i]
            self._render_iac_paths()
            self._persist_infra()

    def _add_iac_folder(self):
        with dialog_guard(self):
            d = filedialog.askdirectory(title="Carpeta de infraestructura como código",
                                        initialdir=self._target_var.get() or APP_DIR)
        if d and d not in self._iac_paths:
            self._iac_paths.append(d)
            self._render_iac_paths()
            self._persist_infra()

    def _add_iac_file(self):
        with dialog_guard(self):
            f = filedialog.askopenfilename(title="Archivo de IaC", filetypes=[
                ("IaC", "*.tf *.yaml *.yml *.json *.bicep Dockerfile*"), ("Todos", "*.*")])
        if f and f not in self._iac_paths:
            self._iac_paths.append(f)
            self._render_iac_paths()
            self._persist_infra()

    def _render_iac_results(self):
        tree = getattr(self, "_iac_tree", None)
        if tree is None or not tree.winfo_exists():
            return
        clear_tree(tree)
        data = (self._last_context or {}).get("iac") or {}
        items = data.get("findings") or []
        groups: dict = {}
        for f in items:
            groups.setdefault(f.get("file") or "—", []).append(f)
        tag = {"critical": "crit", "high": "high", "medium": "med"}
        for name in sorted(groups):
            fs = groups[name]
            worst = min((f["severity"] for f in fs), key=lambda s: SEV_ORDER.get(s, 9))
            pid = tree.insert("", "end", text=f"{name}   ({len(fs)})", values=(SEV_ES.get(worst, worst), "", "", ""),
                              tags=("group",), open=len(groups) <= 3)
            for f in fs:
                tree.insert(pid, "end", text="   " + (f.get("title") or ""), tags=(tag.get(f["severity"], "low"),),
                            values=(SEV_ES.get(f["severity"], f["severity"]) + (" *" if f.get("severity_estimated") else ""),
                                    f.get("line") or "—", f.get("rule_id") or "", ", ".join(f.get("detected_by") or [])))
        if not items:
            tree.insert("", "end", text="  Sin resultados — ejecute un escaneo." if not data.get("targets") else
                        "  Sin configuraciones inseguras ✓", tags=("low",))
        both = sum(1 for f in items if len(f.get("detected_by") or []) > 1)
        self._iac_summary.config(text=(f"{len(items)} hallazgo(s) · {both} confirmados por ambos motores · "
                                       "* severidad estimada") if items else "")

    def _on_infra_results(self, ctx):
        self._render_container_results()
        self._render_iac_results()
