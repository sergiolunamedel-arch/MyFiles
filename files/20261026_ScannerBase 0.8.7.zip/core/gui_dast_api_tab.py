"""Pantallas «Web (DAST)» y «API».

El desarrollador solo indica QUÉ escanear (URL o especificación), CÓMO entrar (autenticación) y CUÁNTO (perfil).
El motor lo decide la política: ZAP + Nuclei de código abierto por defecto, o Probely si Ciberseguridad asignó la
aplicación. Las opciones propias de Probely solo aparecen para administradores.
"""
from __future__ import annotations

import csv

from urllib.parse import urlparse

from ui_common import *
from gui_admin_tab import admin_policy
from probely_engine import REPORTS, fetch_scan_profiles
from web_common import (SCAN_PROFILES, ScanConfig, _LOGOUT_RE, _api_base_url, _api_load_spec, _api_operations,
                        _is_pass, _make_driver, _make_opener, analyze_login_macro, detect_browsers, norm_profile,
                        record_logout_work, record_macro_work)

DAST_FIELDS = [
    ("_dast_url_var", "url", "https://"), ("_dast_auth_var", "auth", "none"),
    ("_dast_profile_var", "profile", "normal"), ("_dast_relogin_var", "relogin", True),
    ("_dast_browser_var", "browser", "chrome"), ("_dast_selwait_var", "selwait", 15),
    ("_dast_minutes_var", "oss.minutes", 30), ("_dast_ajax_var", "oss.ajax", False),
    ("_dast_exclude_var", "oss.exclude", ""), ("_dast_rate_var", "oss.rate", 50),
    ("_dast_target_id_var", "probely.target_id", ""), ("_dast_reuse_url_var", "probely.reuse_url", True),
    ("_dast_maxwait_var", "probely.maxwait", 180), ("_dast_poll_var", "probely.poll", 15),
    ("_dast_require_verified_var", "probely.require_verified", False),
    ("_dast_reduced_scopes_var", "probely.reduced", ""), ("_dast_blacklist_var", "probely.blacklist", ""),
    ("_dast_ignore_blackout_var", "probely.ignore_blackout", False), ("_dast_report_var", "probely.report", "(ninguno)"),
    ("_dast_protect_session_var", "probely.protect", True), ("_dast_agent_warn_var", "probely.agent_warn", True),
    ("_dast_seq_path_var", "probely.seq_path", ""), ("_dast_form_login_var", "probely.form_login", "auto"),
    ("_dast_logout_cond_var", "probely.logout_cond", "any"),
    ("_dast_logout_url_det_var", "probely.logout_url_det", True),
    ("_dast_logout_code_det_var", "probely.logout_code_det", True),
    ("_dast_logout_selector_var", "probely.logout_selector", ""), ("_dast_logout_body_var", "probely.logout_body", ""),
    ("_dast_logout_header_var", "probely.logout_header", ""), ("_dast_2fa_var", "probely.twofa", False),
    ("_dast_otp_field_var", "probely.otp_field", ""), ("_dast_otp_submit_var", "probely.otp_submit", ""),
    ("_dast_otp_alg_var", "probely.otp_alg", "SHA1"), ("_dast_otp_digits_var", "probely.otp_digits", 6)]
API_FIELDS = [
    ("_api_spec_var", "spec", ""), ("_api_base_var", "base", ""), ("_api_auth_var", "auth", "none"),
    ("_api_profile_var", "profile", "normal"), ("_api_tls_var", "tls", True), ("_api_proxy_var", "proxy", ""),
    ("_api_minutes_var", "oss.minutes", 30), ("_api_rate_var", "oss.rate", 50),
    ("_api_target_id_var", "probely.target_id", ""), ("_api_reuse_url_var", "probely.reuse_url", True),
    ("_api_maxwait_var", "probely.maxwait", 180), ("_api_reduced_scopes_var", "probely.reduced", ""),
    ("_api_ignore_blackout_var", "probely.ignore_blackout", False), ("_api_report_var", "probely.report", "(ninguno)"),
    ("_api_protect_session_var", "probely.protect", True), ("_api_seq_path_var", "probely.seq_path", ""),
    ("_api_check_login_var", "probely.check_login", True),
    ("_api_require_verified_var", "probely.require_verified", False),
    ("_api_schema_type_var", "probely.schema_type", "(auto)"), ("_api_login_url_var", "probely.login_url", ""),
    ("_api_login_media_var", "probely.login_media", "application/json"),
    ("_api_login_token_field_var", "probely.login_token_field", ""),
    ("_api_login_token_param_var", "probely.login_token_param", "Authorization"),
    ("_api_login_token_prefix_var", "probely.login_token_prefix", ""),
    ("_api_login_place_var", "probely.login_place", "header")]
FIELD_SPECS = {"dast": DAST_FIELDS, "api": API_FIELDS}
DAST_CRED_KEYS = ["username", "password", "token", "cookie", "header_name", "header_value", "login_url", "login_data",
                  "selenium_login_url", "selenium_user_selector", "selenium_user_value", "selenium_pass_selector",
                  "selenium_pass_value", "selenium_submit_selector", "selenium_extra_steps", "selenium_macro",
                  "login_success_text", "logout_url_re", "selenium_logout_macro", "probely_form_login_check_pattern",
                  "probely_check_session_url", "probely_logout_markers"]
API_CRED_KEYS = ["username", "password", "token", "cookie", "header_name", "header_value"]
SECRET_KEYS = {"password", "token", "cookie", "header_value", "selenium_pass_value", "login_data"}
AUTH_TYPES = {"none": "Sin autenticación", "basic": "Usuario y contraseña (HTTP Basic)", "bearer": "Token Bearer",
              "cookie": "Cookie de sesión", "header": "Cabecera personalizada (API key)",
              "form": "Formulario de login simple", "selenium": "Login grabado en el navegador (recomendado para SSO/SPA)"}
AUTH_HELP = {
    "none": "El escáner solo verá las páginas públicas.",
    "basic": "Se envía «Authorization: Basic …» en cada petición.",
    "bearer": "Pegue un token vigente (p. ej. JWT de un usuario de pruebas). Caduca: renuévelo antes de escanear.",
    "cookie": "Copie la cabecera Cookie de una sesión iniciada (DevTools → Red). Caduca con la sesión.",
    "header": "Para APIs con llave: nombre de cabecera (p. ej. X-API-Key) y su valor.",
    "form": "Para formularios clásicos: URL del login y los campos campo=valor&campo2=valor.",
    "selenium": "Grabe una vez cómo inicia sesión; el escáner lo repite y usa esa sesión. Funciona con SSO, MFA "
                "por código y aplicaciones JavaScript.",
}
AUTH_FIELDS = {
    "none": [],
    "basic": [("username", "Usuario", False), ("password", "Contraseña", True)],
    "bearer": [("token", "Token Bearer", True)],
    "cookie": [("cookie", "Valor de la cabecera Cookie", False)],
    "header": [("header_name", "Nombre de cabecera", False), ("header_value", "Valor de cabecera", True)],
    "form": [("login_url", "URL de la página de login", False),
             ("login_data", "Campos del formulario (campo=valor&…)", True),
             ("probely_form_login_check_pattern", "Texto visible solo con sesión iniciada", False)],
    "selenium": [("selenium_login_url", "URL de la página de login", False),
                 ("selenium_user_value", "Usuario", False),
                 ("selenium_pass_value", "Contraseña (no se guarda en disco)", True)]}
SELENIUM_ADV_FIELDS = [("selenium_user_selector", "Selector CSS de usuario", False),
                       ("selenium_pass_selector", "Selector CSS de contraseña", False),
                       ("selenium_submit_selector", "Selector CSS de enviar", False),
                       ("selenium_extra_steps", "Pasos adicionales (JSON)", False)]
SESSION_FIELDS = [("login_success_text", "Texto visible SOLO con sesión iniciada", False),
                  ("logout_url_re", "URLs de logout a excluir (regex)", False)]
SESSION_FIELDS_ADMIN = [("probely_check_session_url", "URL de verificación de sesión (Probely)", False),
                        ("probely_logout_markers", "Marcadores de sesión cerrada (Probely)", False)]
CONDITION_KEYS = {"login": ["selenium_login_url", "selenium_user_selector", "selenium_user_value",
                            "selenium_pass_selector", "selenium_submit_selector", "selenium_extra_steps",
                            "selenium_macro", "login_success_text"],
                  "logout": ["logout_url_re", "login_success_text", "selenium_logout_macro"]}
_LEGACY = {"profile": {"(predeterminado)": "normal", "passive": "safe", "active": "full", "": "normal"},
           "auth": {"auto": "none"}}


def _opt(s) -> str:
    s = (s or "").strip()
    return "" if s in ("(predeterminado)", "(ninguno)", "(auto)") else s


def _var(default):
    return (tk.BooleanVar if isinstance(default, bool) else tk.IntVar if isinstance(default, int) else tk.StringVar)(
        value=default)


def _int(var, default):
    try:
        return int(var.get())
    except (tk.TclError, ValueError, TypeError):
        return default


PROFILE_TIPS = {
    "lightning": "≈ 5–10 min. Solo rastrea y revisa respuestas; no envía ataques. Bueno para probar que la "
                 "configuración y el login funcionan.",
    "safe": "≈ 15–40 min. Pruebas pasivas y no intrusivas. Se puede usar en ambientes compartidos sin riesgo de "
            "modificar datos.",
    "normal": "Hasta el límite de tiempo (30 min por defecto). Envía ataques reales (inyección SQL, XSS…): "
              "puede crear o modificar registros. Úselo en desarrollo o QA.",
    "full": "1–4 horas. Todo lo anterior más rastreo JavaScript y fuzzing extenso. Solo en ambientes de QA "
            "aislados.",
}

class _FieldsMixin:
    def _make_field_vars(self, kind: str, cred_keys: list):
        for attr, _, default in FIELD_SPECS[kind]:
            setattr(self, attr, _var(default))
        setattr(self, f"_{kind}_cred_vars", {k: tk.StringVar() for k in cred_keys})
        setattr(self, f"_{kind}_advanced_var", tk.BooleanVar(value=False))
        self._profile_values = getattr(self, "_profile_values", {})

    def _dump_fields(self, kind: str) -> dict:
        out: dict = {}
        for attr, path, default in FIELD_SPECS[kind]:
            node = out
            *parents, leaf = path.split(".")
            for p in parents:
                node = node.setdefault(p, {})
            try:
                node[leaf] = getattr(self, attr).get()
            except tk.TclError:
                node[leaf] = default
        out["creds"] = {k: v.get() for k, v in getattr(self, f"_{kind}_cred_vars").items() if k not in SECRET_KEYS}
        return out

    def _load_fields(self, kind: str, saved) -> None:
        if not isinstance(saved, dict):
            return
        for attr, path, default in FIELD_SPECS[kind]:
            node = saved
            for p in path.split("."):
                node = node.get(p) if isinstance(node, dict) else None
            if node is None or (node == "" and path in ("url", "auth", "browser", "spec")):
                continue
            node = _LEGACY.get(path, {}).get(node, node)
            if path == "profile":
                node = norm_profile(node)
            try:
                getattr(self, attr).set(type(default)(node))
            except (TypeError, ValueError, tk.TclError):
                pass
        creds = getattr(self, f"_{kind}_cred_vars")
        for k, v in (saved.get("creds") or {}).items():
            if k in creds and k not in SECRET_KEYS:
                creds[k].set(str(v))

    def _init_macro_flags(self):
        g = lambda k: self._dast_cred_vars[k].get().strip()
        self._macro_recorded = {"login": bool(g("selenium_macro") or g("selenium_login_url")),
                                "logout": bool(g("selenium_logout_macro") or g("logout_url_re"))}

    def _setup_field_persistence(self):
        pending = [None]

        def changed(*_):
            if pending[0]:
                self.after_cancel(pending[0])
            pending[0] = self.after(800, self._save_settings)
        for kind in ("dast", "api"):
            for attr, _, _ in FIELD_SPECS[kind]:
                getattr(self, attr).trace_add("write", changed)
            for k, v in getattr(self, f"_{kind}_cred_vars").items():
                if k not in SECRET_KEYS:
                    v.trace_add("write", changed)

    # ── Piezas de formulario ────────────────────────────────────────────────
    def _field(self, parent, label, var, *, show="", hint="", width=None, browse=None):
        """Campo con etiqueta ARRIBA (no se corta con DPI alto ni con textos largos)."""
        box = tk.Frame(parent, bg=T["panel_bg"])
        box.pack(fill="x", pady=(0, px(10)))
        tk.Label(box, text=label, font=(FUI, 10, "bold"), bg=T["panel_bg"], fg=T["muted"], anchor="w").pack(fill="x")
        row = tk.Frame(box, bg=T["panel_bg"])
        row.pack(fill="x", pady=(px(3), 0))
        e = ttk.Entry(row, textvariable=var, show=show, **({"width": width} if width else {}))
        e.pack(side="left", fill="x" if not width else None, expand=not width)
        if browse:
            PillButton(row, "Examinar…", browse, icon="folder", variant="secondary", size=10).pack(
                side="left", padx=(px(8), 0))
        if hint:
            autowrap(tk.Label(box, text=hint, font=(FUI, 9), bg=T["panel_bg"], fg=T["muted"], anchor="w",
                              justify="left"), 4, 200).pack(fill="x", pady=(px(2), 0))
        return e

    def _fields_grid(self, parent, fields, cred_vars, cols=2):
        grid = tk.Frame(parent, bg=T["panel_bg"])
        grid.pack(fill="x")
        for c in range(cols):
            grid.columnconfigure(c, weight=1, uniform="fg")
        for i, (key, label, secret) in enumerate(fields):
            cell = tk.Frame(grid, bg=T["panel_bg"])
            cell.grid(row=i // cols, column=i % cols, sticky="ew", padx=(0 if i % cols == 0 else px(12), 0))
            self._field(cell, label, cred_vars[key], show="•" if secret else "")
        return grid

    def _section_label(self, parent, text):
        return tk.Label(parent, text=text.upper(), font=(FUI, 9, "bold"), bg=T["panel_bg"], fg=T["muted"], anchor="w")

    def _grid_combo(self, parent, var, values, r, c, width=12, **kw):
        cb = ttk.Combobox(parent, textvariable=var, values=values, state="readonly", width=width)
        cb.grid(row=r, column=c, sticky="w", pady=1, **kw)
        return cb

    def _profile_picker(self, parent, var):
        """Selector segmentado de perfil con descripción — reemplaza el combo críptico (lightning/safe/…)."""
        wrap = tk.Frame(parent, bg=T["panel_bg"])
        wrap.pack(fill="x")
        seg = tk.Frame(wrap, bg=T["border_strong"])
        seg.pack(fill="x")
        cells = {}
        for i, (key, (label, _)) in enumerate(SCAN_PROFILES.items()):
            seg.columnconfigure(i, weight=1, uniform="seg")
            c = tk.Label(seg, text=label, font=(FUI, 10, "bold"), cursor="hand2", pady=px(7))
            c.grid(row=0, column=i, sticky="nsew", padx=(0 if not i else 1, 0), pady=1)
            c.bind("<Button-1>", lambda _e, k=key: var.set(k))
            tip(c, PROFILE_TIPS.get(key))
            cells[key] = c
        desc = autowrap(tk.Label(wrap, text="", font=(FUI, 10), bg=T["panel_bg"], fg=T["muted"], anchor="w",
                                 justify="left"), 4, 200)
        desc.pack(fill="x", pady=(px(6), 0))

        def paint(*_):
            if not wrap.winfo_exists():
                return
            cur = norm_profile(var.get())
            for k, c in cells.items():
                on = k == cur
                c.configure(bg=T["accent"] if on else T["panel_bg"], fg=T["button_fg"] if on else T["text"])
            desc.configure(text=SCAN_PROFILES[cur][1])
        tid = var.trace_add("write", paint)
        wrap.bind("<Destroy>", lambda e: e.widget is wrap and var.trace_remove("write", tid), add="+")
        paint()
        return wrap

    def _limits_spins(self, lim, minutes_var, rate_var):
        tip(self._spin(lim, "Duración máxima (min)", minutes_var, 5, 600, width=5),
            "El escaneo activo se detiene al llegar a este tiempo y reporta lo encontrado hasta ese momento.")
        tip(self._spin(lim, "   Peticiones/s", rate_var, 5, 500, width=5),
            "Límite de velocidad para no saturar el servidor. Bájelo si el ambiente es pequeño o compartido; "
            "súbalo para terminar antes en ambientes dedicados.")

    def _engine_banner(self, parent, kind):
        """Línea informativa «Motor: …» que se actualiza al cambiar de aplicación o de política."""
        row = tk.Frame(parent, bg=T["info_soft"])
        row.pack(fill="x", pady=(0, CARD_GAP))
        tk.Frame(row, bg=T["border2"], width=px(3)).pack(side="left", fill="y")
        inner = tk.Frame(row, bg=T["info_soft"], padx=px(14), pady=px(9))
        inner.pack(side="left", fill="x", expand=True)
        tk.Label(inner, text=ico("engine"), font=icon_font(11), bg=T["info_soft"], fg=T["border2"]).pack(side="left")
        lbl = tk.Label(inner, text="", font=(FUI, 10), bg=T["info_soft"], fg=T["text"], anchor="w", justify="left")
        lbl.pack(side="left", padx=(px(10), 0), fill="x", expand=True)
        PillButton(inner, "Motores", self._show_engines_popup, icon="engine", variant="ghost", size=9).pack(side="right")
        self._engine_banners = [b for b in getattr(self, "_engine_banners", []) if b.winfo_exists()] + [lbl]
        self._refresh_engine_badge_text()
        return row

    def _refresh_engine_badge_text(self):
        engine, label = admin_policy.engine_label(getattr(self, "_active_app", None))
        txt = (f"Motor: {label}. " + ("Ciberseguridad asignó Probely a esta aplicación; si no está disponible se usa "
                                       "ZAP + Nuclei automáticamente." if engine == "probely" else
                                       "Se descarga y verifica automáticamente la primera vez (sin Docker)."))
        for lbl in getattr(self, "_engine_banners", []):
            if lbl.winfo_exists():
                lbl.configure(text=txt)

    def _browse_into(self, var, title, filetypes):
        with dialog_guard(self):
            p = filedialog.askopenfilename(title=title, filetypes=filetypes)
        if p:
            var.set(p)
        return p

    # ── Administración de Probely (solo admins) ─────────────────────────────
    def _refresh_scan_profiles(self, which: str):
        token = admin_policy.probely_key()

        def work():
            profs = fetch_scan_profiles(token, which, self._emit_log)
            self._ui(self._on_scan_profiles, which, profs)
        self._run_async(work, "perfiles de escaneo", busy_attr="_tools_busy")

    def _on_scan_profiles(self, which, profs):
        if not profs:
            return self._log_line(f"[{which}] no se pudieron cargar perfiles de Probely")
        self._log_line(f"[{which}] perfiles de Probely disponibles: " + ", ".join(p[0] for p in profs))

    def _probely_admin_rows(self, c, kind):
        v = lambda n: getattr(self, f"_{kind}_{n}_var")
        grid = tk.Frame(c, bg=T["panel_bg"])
        grid.pack(fill="x")
        grid.columnconfigure(0, weight=1, uniform="pa")
        grid.columnconfigure(1, weight=1, uniform="pa")
        a, b = tk.Frame(grid, bg=T["panel_bg"]), tk.Frame(grid, bg=T["panel_bg"])
        a.grid(row=0, column=0, sticky="ew", padx=(0, px(12)))
        b.grid(row=0, column=1, sticky="ew")
        self._field(a, "Target existente (ID)", v("target_id"), hint="Vacío = se busca por URL o se crea.")
        self._field(b, "Alcance reducido (URLs, una por línea o coma)", v("reduced_scopes"))
        if kind == "dast":
            self._field(a, "Lista negra (globs de URL)", v("blacklist"))
        self._field(b, "Secuencia de login de Probely Recorder (.json)", v("seq_path"),
                    browse=lambda: self._browse_into(v("seq_path"), "Secuencia de login de Probely",
                                                     [("Secuencia Probely (JSON)", "*.json"), ("Todos", "*.*")]))
        opts = tk.Frame(c, bg=T["panel_bg"])
        opts.pack(fill="x", pady=(px(4), 0))
        self._spin(opts, "Espera máxima (min)", v("maxwait"), 5, 1440, width=6)
        if kind == "dast":
            self._spin(opts, "   Sondeo (s)", v("poll"), 5, 120, width=5)
        tk.Label(opts, text="   Reporte de cumplimiento", font=(FUI, 10), bg=T["panel_bg"], fg=T["text"]).pack(side="left")
        ttk.Combobox(opts, textvariable=v("report"), values=REPORTS, state="readonly", width=18).pack(
            side="left", padx=(px(6), 0))
        PillButton(opts, "Ver perfiles de Probely", lambda: self._refresh_scan_profiles("api" if kind == "api" else "web"),
                   icon="refresh", variant="ghost", size=10).pack(side="right")
        tg = tk.Frame(c, bg=T["panel_bg"])
        tg.pack(fill="x", pady=(px(8), 0))
        toggles = [("Reutilizar target por URL", v("reuse_url")), ("Ignorar blackout", v("ignore_blackout")),
                   ("Proteger sesión", v("protect_session")), ("Exigir dominio verificado", v("require_verified"))]
        if kind == "dast":
            toggles.append(("Avisar si el host no es público", v("agent_warn")))
        else:
            toggles.append(("Probar login del API antes de escanear", v("check_login")))
        for i, (text, var) in enumerate(toggles):
            ToggleSwitch(tg, text=text, variable=var).grid(row=i // 3, column=i % 3, sticky="w", padx=(0, px(16)),
                                                           pady=px(3))


class _ApiTabMixin(_FieldsMixin):
    def _init_api_vars(self):
        self._make_field_vars("api", API_CRED_KEYS)
        self._api_login_payload_var = tk.StringVar()

    def _build_tab_api(self, parent):
        pad = self._scrollable(parent)
        self._safety_banner(pad, "Use un entorno de pruebas: el escaneo envía peticiones reales (incluidas de escritura) "
                                 "a cada endpoint de la especificación.")
        cols = tk.Frame(pad, bg=T["bg"])
        cols.pack(fill="x")
        cols.columnconfigure(0, weight=3, uniform="api")
        cols.columnconfigure(1, weight=2, uniform="api")
        left, right = tk.Frame(cols, bg=T["bg"]), tk.Frame(cols, bg=T["bg"])
        left.grid(row=0, column=0, sticky="nsew", padx=(0, CARD_GAP // 2))
        right.grid(row=0, column=1, sticky="nsew", padx=(CARD_GAP // 2, 0))
        c = self._card(left, "Especificación del API", collapsible=False)
        self._field(c, "Archivo o URL (OpenAPI/Swagger, colección Postman o esquema GraphQL)", self._api_spec_var,
                    browse=self._api_import_popup)
        row = tk.Frame(c, bg=T["panel_bg"])
        row.pack(fill="x")
        row.columnconfigure(0, weight=3, uniform="sp")
        row.columnconfigure(1, weight=1, uniform="sp")
        a, b = tk.Frame(row, bg=T["panel_bg"]), tk.Frame(row, bg=T["panel_bg"])
        a.grid(row=0, column=0, sticky="ew", padx=(0, px(12)))
        b.grid(row=0, column=1, sticky="ew")
        self._field(a, "URL base del API (opcional)", self._api_base_var,
                    hint="Si la especificación ya trae «servers», puede dejarlo vacío.")
        tk.Label(b, text="Tipo", font=(FUI, 10, "bold"), bg=T["panel_bg"], fg=T["muted"], anchor="w").pack(fill="x")
        ttk.Combobox(b, textvariable=self._api_schema_type_var, values=["(auto)", "openapi", "postman", "graphql"],
                     state="readonly").pack(fill="x", pady=(px(3), 0))
        c = self._card(left, "Autenticación", collapsible=False)
        top = tk.Frame(c, bg=T["panel_bg"])
        top.pack(fill="x", pady=(0, px(8)))
        labels = {k: AUTH_TYPES[k] for k in ("none", "basic", "bearer", "cookie", "header")}
        self._api_auth_label = tk.StringVar(value=labels.get(self._api_auth_var.get(), labels["none"]))
        cb = ttk.Combobox(top, textvariable=self._api_auth_label, values=list(labels.values()), state="readonly")
        cb.pack(fill="x")
        cb.bind("<<ComboboxSelected>>", lambda _e: (self._api_auth_var.set(
            next(k for k, l in labels.items() if l == self._api_auth_label.get())), self._refresh_api_creds()))
        self._api_auth_help = autowrap(tk.Label(c, text="", font=(FUI, 9), bg=T["panel_bg"], fg=T["muted"], anchor="w",
                                                justify="left"), 4, 200)
        self._api_auth_help.pack(fill="x", pady=(0, px(8)))
        self._api_cred_frame = tk.Frame(c, bg=T["panel_bg"])
        self._api_cred_frame.pack(fill="x")
        c = self._card(right, "Perfil de escaneo", collapsible=False)
        self._profile_picker(c, self._api_profile_var)
        c = self._card(right, "Límites y red", start_collapsed=True)
        lim = tk.Frame(c, bg=T["panel_bg"])
        lim.pack(fill="x")
        self._limits_spins(lim, self._api_minutes_var, self._api_rate_var)
        ToggleSwitch(c, text="Verificar certificado TLS (vista previa)", variable=self._api_tls_var).pack(
            anchor="w", pady=(px(10), px(6)))
        self._field(c, "Proxy HTTP para la vista previa (opcional)", self._api_proxy_var)
        ep = self._card(pad, "Endpoints detectados", collapsible=False)
        btns = tk.Frame(ep.right, bg=T["panel_bg"])
        btns.pack(side="right")
        PillButton(btns, "Vista previa", self._api_preview_spec, icon="search", variant="secondary", size=10).pack(
            side="left")
        PillButton(btns, "Exportar…", self._api_export_popup, icon="save", variant="ghost", size=10).pack(
            side="left", padx=(px(6), 0))
        box = tk.Frame(ep, bg=T["panel_bg"])
        box.pack(fill="both", expand=True)
        self._ep_tree = make_tree(box, ("method", "url", "secured", "body"), [
            ("Método", 80, "w", False), ("URL del endpoint", 520), ("Requiere auth", 110, "center", False),
            ("Tipo de cuerpo", 160, "w", False)], 8)
        self._ep_count_lbl = self._lbl(ep, "Pulse «Vista previa» para ver qué endpoints se probarán.", size=10,
                                       fg=T["muted"])
        self._ep_count_lbl.pack(anchor="w", pady=(px(6), 0))
        if self._api_preview:
            self._render_api_preview(*self._api_preview)
        if self._is_admin:
            c = self._card(pad, "Probely · solo administración", start_collapsed=True)
            self._probely_admin_rows(c, "api")
            self._hdiv(c, pady=px(10))
            self._section_label(c, "Login por endpoint (obtención de token)").pack(anchor="w", pady=(0, px(6)))
            g = tk.Frame(c, bg=T["panel_bg"])
            g.pack(fill="x")
            g.columnconfigure(0, weight=1, uniform="lg")
            g.columnconfigure(1, weight=1, uniform="lg")
            a, b = tk.Frame(g, bg=T["panel_bg"]), tk.Frame(g, bg=T["panel_bg"])
            a.grid(row=0, column=0, sticky="ew", padx=(0, px(12)))
            b.grid(row=0, column=1, sticky="ew")
            self._field(a, "URL de login", self._api_login_url_var)
            self._field(a, "Payload de autenticación", self._api_login_payload_var)
            self._field(a, "Campo del token en la respuesta", self._api_login_token_field_var)
            self._field(b, "Cabecera/cookie del token", self._api_login_token_param_var)
            self._field(b, "Prefijo del token", self._api_login_token_prefix_var)
            pr = tk.Frame(b, bg=T["panel_bg"])
            pr.pack(fill="x")
            ttk.Combobox(pr, textvariable=self._api_login_media_var, values=["application/json",
                                                                             "application/x-www-form-urlencoded"],
                         state="readonly", width=30).pack(side="left")
            ttk.Combobox(pr, textvariable=self._api_login_place_var, values=["header", "cookie"], state="readonly",
                         width=8).pack(side="left", padx=(px(8), 0))
        self._refresh_api_creds()

    def _refresh_api_creds(self):
        f = self._api_cred_frame
        for w in f.winfo_children():
            w.destroy()
        kind = self._api_auth_var.get()
        self._api_auth_help.configure(text=AUTH_HELP.get(kind, ""))
        fields = [x for x in AUTH_FIELDS.get(kind, []) if x[0] in self._api_cred_vars]
        if fields:
            self._fields_grid(f, fields, self._api_cred_vars)

    # métodos reutilizados (importar/exportar/vista previa)
    def _api_import_popup(self):
        popup = self._popup("Importar especificación")
        self._popup_hdr(popup, "Importar especificación", icon="📥")
        body = tk.Frame(popup, bg=T["bg"])
        body.pack(fill="both", expand=True)
        tk.Label(body, text="Elija el formato a importar:", font=(FUI, 10), bg=T["bg"], fg=T["muted"]).pack(pady=(px(24), px(10)))
        row = tk.Frame(body, bg=T["bg"])
        row.pack(padx=px(24), pady=(0, px(16)))
        kinds = {"postman": ("Importar colección Postman", [("Colección Postman", "*.json")], "colección Postman"),
                 "openapi": ("Importar especificación OpenAPI / Swagger", [("OpenAPI/Swagger", "*.json *.yaml *.yml")],
                             "especificación OpenAPI/Swagger"),
                 "graphql": ("Importar esquema GraphQL (SDL o endpoint)", [("GraphQL", "*.graphql *.gql *.graphqls *.json")],
                             "esquema GraphQL")}

        def pick(kind):
            popup.close()
            if kind == "graphql":
                self._api_schema_type_var.set("graphql")
            title, ft, label = kinds[kind]
            if p := self._browse_into(self._api_spec_var, title, ft + [("Todos", "*.*")]):
                self._emit_log(f"[api] cargado {label}: {p}")
                self._api_preview_spec()
        for icon, label, desc, kind in (
                ("📦", "Colección Postman", "Importar una colección Postman v2.1 (.json)", "postman"),
                ("📄", "Swagger / OpenAPI", "Importar una especificación OpenAPI v2/v3 o Swagger\n(.json o .yaml)", "openapi"),
                ("◢", "GraphQL", "Esquema GraphQL (SDL .graphql) o introspección\nde un endpoint", "graphql")):
            self._choice_card(row, icon, label, desc, on_click=lambda k=kind: pick(k))
        self._popup_foot(popup, ("  Cancelar  ", popup.close))

    def _api_export_popup(self):
        t = self._ep_tree
        ops = [{c: t.set(i, c) for c in ("method", "url", "secured", "body")} for i in t.get_children()]
        if not ops:
            return self._show_warn_popup("Exportar endpoints", "Sin endpoints — ejecute Vista previa primero.")
        popup = self._popup("Exportar endpoints")
        self._popup_hdr(popup, "Exportar endpoints", icon="💾", subtitle=f"{len(ops)} endpoint(s)")
        body = tk.Frame(popup, bg=T["bg"])
        body.pack(fill="both", expand=True)
        tk.Label(body, text="Elija el formato de exportación:", font=(FUI, 10), bg=T["bg"], fg=T["muted"]).pack(pady=(px(24), px(10)))
        row = tk.Frame(body, bg=T["bg"])
        row.pack(padx=px(24), pady=(0, px(16)))
        fmt = tk.StringVar(value="CSV")
        cards = [self._choice_card(row, icon, name, desc, on_click=lambda n=name: fmt.set(n),
                                   selected=lambda n=name: fmt.get() == n)
                 for name, icon, desc in (("CSV", "📊", "Valores separados por comas\nExcel / Sheets"),
                                          ("JSON", "📋", "Arreglo JSON sin formato\nScripts / APIs"),
                                          ("YAML", "📄", "Formato YAML\nHerramientas OpenAPI"),
                                          ("Postman v2.1", "📦", "Colección Postman v2.1\nImportación directa en Postman"))]
        fmt.trace_add("write", lambda *_: [c.refresh() for c in cards])
        cards[0].refresh()
        self._popup_foot(popup, ("💾  Exportar  ", lambda: (popup.close(), self._api_export(ops, fmt.get()))),
                         ("  Cancelar  ", popup.close))

    def _api_export(self, ops, fmt):
        ext, name, ft = {"CSV": (".csv", "endpoints.csv", [("CSV", "*.csv")]),
                         "JSON": (".json", "endpoints.json", [("JSON", "*.json")]),
                         "YAML": (".yaml", "endpoints.yaml", [("YAML", "*.yaml *.yml")]),
                         "Postman v2.1": (".json", "endpoints_postman.json", [("JSON / Postman", "*.json")])}[fmt]
        with dialog_guard(self):
            path = filedialog.asksaveasfilename(title=f"Exportar endpoints como {fmt}", defaultextension=ext,
                                                initialfile=name, filetypes=ft + [("Todos", "*.*")])
        if not path:
            return
        if fmt == "CSV":
            with open(path, "w", newline="", encoding="utf-8") as f:
                w = csv.DictWriter(f, fieldnames=["method", "url", "secured", "body"])
                w.writeheader()
                w.writerows(ops)
        elif fmt == "JSON":
            write_json(path, ops)
        elif fmt == "YAML":
            Path(path).write_text("endpoints:\n" + "".join(
                f"  - method: {o['method']}\n    url: '{o['url']}'\n    secured: '{o['secured']}'\n    body: '{o['body']}'\n"
                for o in ops), encoding="utf-8")
        else:
            items = []
            for o in ops:
                proto, _, rest = o["url"].partition("://")
                items.append({"name": f"{o['method']} {o['url']}", "response": [], "request": {
                    "method": o["method"], "header": [],
                    "url": {"raw": o["url"], "protocol": proto if rest else "https",
                            "host": rest.split("/")[0].split(".") if rest else [],
                            "path": rest.split("/")[1:] if rest else []},
                    "description": f"Auth requerida: {o['secured']}  Tipo de cuerpo: {o['body']}"}})
            write_json(path, {"info": {"name": "Endpoints exportados", "schema":
                                       "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"},
                              "item": items})
        self._log_line(f"[api-export] {fmt} → {path}")
        self._show_info_popup("Exportación completada", f"Se guardaron {len(ops)} endpoint(s) en:\n{path}")

    def _api_preview_spec(self):
        src = self._api_spec_var.get().strip()
        if not src:
            return self._show_warn_popup("Vista previa", "Configure una especificación primero.")
        cfg = self._collect_api_cfg()

        def work():
            spec = _api_load_spec(*_make_opener(cfg), cfg, self._emit_log)
            if not isinstance(spec, dict):
                return self._emit_log("[api-preview] no se pudo cargar o interpretar la especificación.")
            fmt = ("Colección Postman" if "item" in spec and "paths" not in spec else
                   f"OpenAPI {spec['openapi']}" if str(spec.get("openapi", "")).startswith("3") else
                   f"Swagger {spec['swagger']}" if str(spec.get("swagger", "")).startswith("2") else "Formato desconocido")
            ops = _api_operations(spec, _api_base_url(spec, cfg, src) or "https://example.com")
            self._ui(self._render_api_preview, fmt, ops)
        self._run_async(work, "vista previa de especificación")

    def _render_api_preview(self, fmt, ops):
        self._api_preview = (fmt, ops)
        clear_tree(self._ep_tree)
        for op in ops:
            self._ep_tree.insert("", "end", values=(op["method"], op["url"], "✓" if op.get("secured") else "—",
                                                    op.get("ctype") or "—"), tags=(stripe(self._ep_tree),))
        self._ep_count_lbl.config(text=f"Formato: {fmt}  ·  {len(ops)} endpoint(s) detectados")
        self._log_line(f"[api-preview] {fmt} — {len(ops)} endpoints")

    def _collect_api_cfg(self) -> ScanConfig:
        v = {k: x.get() for k, x in self._api_cred_vars.items()}
        prof = norm_profile(self._api_profile_var.get())
        return ScanConfig(
            spec_source=self._api_spec_var.get().strip(), base_url=self._api_base_var.get().strip(),
            auth_type=self._api_auth_var.get(), profile=prof, verify_tls=self._api_tls_var.get(),
            proxy=self._api_proxy_var.get(), **v, scan_minutes=_int(self._api_minutes_var, 30),
            rate_limit=_int(self._api_rate_var, 50),
            probely_target_id=self._api_target_id_var.get().strip(),
            probely_reuse_by_url=self._api_reuse_url_var.get(), probely_scan_profile=prof,
            probely_max_wait_minutes=float(_int(self._api_maxwait_var, 180)),
            probely_reduced_scopes=self._api_reduced_scopes_var.get(),
            probely_ignore_blackout=self._api_ignore_blackout_var.get(),
            probely_compliance_report=_opt(self._api_report_var.get()),
            probely_protect_session=self._api_protect_session_var.get(),
            probely_login_sequence_path=self._api_seq_path_var.get().strip(),
            probely_check_login=self._api_check_login_var.get(),
            probely_require_verified=self._api_require_verified_var.get(),
            probely_api_schema_type=_opt(self._api_schema_type_var.get()),
            probely_api_login_url=self._api_login_url_var.get().strip(),
            probely_api_login_payload=self._api_login_payload_var.get(),
            probely_api_login_media_type=self._api_login_media_var.get() or "application/json",
            probely_api_login_token_field=self._api_login_token_field_var.get().strip(),
            probely_api_login_token_param=self._api_login_token_param_var.get().strip() or "Authorization",
            probely_api_login_token_prefix=self._api_login_token_prefix_var.get().strip(),
            probely_api_login_place=self._api_login_place_var.get() or "header")


class _DastTabMixin(_FieldsMixin):
    def _init_dast_vars(self):
        self._make_field_vars("dast", DAST_CRED_KEYS)
        self._dast_browser_label_var = tk.StringVar(value="Google Chrome")
        self._dast_otp_secret_var = tk.StringVar()
        self._browser_catalog = {}

    def _build_tab_dast(self, parent):
        pad = self._scrollable(parent)
        self._safety_banner(pad, "Escanee solo entornos de prueba o QA: el perfil Estándar y el Completo envían ataques "
                                 "reales que pueden crear o modificar datos.")
        cols = tk.Frame(pad, bg=T["bg"])
        cols.pack(fill="x")
        cols.columnconfigure(0, weight=3, uniform="dast")
        cols.columnconfigure(1, weight=2, uniform="dast")
        left, right = tk.Frame(cols, bg=T["bg"]), tk.Frame(cols, bg=T["bg"])
        left.grid(row=0, column=0, sticky="nsew", padx=(0, CARD_GAP // 2))
        right.grid(row=0, column=1, sticky="nsew", padx=(CARD_GAP // 2, 0))
        c = self._card(left, "Aplicación a escanear", collapsible=False)
        self._field(c, "URL de inicio", self._dast_url_var,
                    hint="Página desde donde el escáner empieza a rastrear, p. ej. https://qa.miapp.bancobase.com/")
        c = self._card(left, "Autenticación", collapsible=False)
        labels = AUTH_TYPES
        self._dast_auth_label = tk.StringVar(value=labels.get(self._dast_auth_var.get(), labels["none"]))
        cb = ttk.Combobox(c, textvariable=self._dast_auth_label, values=list(labels.values()), state="readonly")
        cb.pack(fill="x")
        cb.bind("<<ComboboxSelected>>", lambda _e: (self._dast_auth_var.set(
            next(k for k, l in labels.items() if l == self._dast_auth_label.get())), self._refresh_dast_creds()))
        self._dast_auth_help = autowrap(tk.Label(c, text="", font=(FUI, 9), bg=T["panel_bg"], fg=T["muted"],
                                                 anchor="w", justify="left"), 4, 200)
        self._dast_auth_help.pack(fill="x", pady=(px(6), px(10)))
        self._dast_cred_frame = tk.Frame(c, bg=T["panel_bg"])
        self._dast_cred_frame.pack(fill="x")
        self._dast_sel_wrap = tk.Frame(c, bg=T["panel_bg"])
        self._build_record_section(self._dast_sel_wrap)
        self._dast_session_wrap = tk.Frame(c, bg=T["panel_bg"])
        c = self._card(right, "Perfil de escaneo", collapsible=False)
        self._profile_picker(c, self._dast_profile_var)
        c = self._card(right, "Alcance y límites", start_collapsed=True)
        lim = tk.Frame(c, bg=T["panel_bg"])
        lim.pack(fill="x")
        self._limits_spins(lim, self._dast_minutes_var, self._dast_rate_var)
        tip(ToggleSwitch(c, text="Rastrear contenido JavaScript (SPA) — requiere Chrome", variable=self._dast_ajax_var),
            "Para sitios hechos con Angular, React o Vue, donde los enlaces se generan con JavaScript. Abre un Chrome "
            "oculto: encuentra más páginas pero tarda más.").pack(anchor="w", pady=(px(10), px(4)))
        tip(ToggleSwitch(c, text="Detectar cierre de sesión y volver a entrar", variable=self._dast_relogin_var),
            "Si durante el escaneo la aplicación lo saca de la sesión, el escáner vuelve a iniciar sesión con las "
            "credenciales o el login grabado para seguir probando las páginas privadas.").pack(
            anchor="w", pady=(0, px(10)))
        self._field(c, "No visitar (regex, uno por línea o coma)", self._dast_exclude_var,
                    hint="Las URLs de logout se excluyen automáticamente. Agregue aquí acciones peligrosas "
                         "(p. ej. .*/borrar.*, .*/pagos/confirmar.*).")
        self._dast_probely_card = self._build_dast_probely_card(pad) if self._is_admin else None
        self._refresh_dast_creds()

    def _build_record_section(self, parent):
        self._hdiv(parent, pady=(px(4), px(10)))
        self._section_label(parent, "Login grabado").pack(anchor="w")
        row = tk.Frame(parent, bg=T["panel_bg"])
        row.pack(fill="x", pady=(px(6), 0))
        self._macro_checks = {}
        for flag, label, icon in (("login", "Grabar login", "record"), ("logout", "Excluir logout", "close")):
            wrap = tk.Frame(row, bg=T["panel_bg"])
            wrap.pack(side="left", padx=(0, px(10)))
            b = PillButton(wrap, label, lambda f=flag: self._macro_popup(f), icon=icon,
                           variant="primary" if flag == "login" else "secondary", size=10, tooltip=(
                               "Abre un navegador: inicie sesión normalmente y el escáner repetirá esos pasos. "
                               "Úselo cuando el login tiene varios pasos, botones especiales o SSO." if flag == "login"
                               else "Haga clic en el botón de «Cerrar sesión» para que el escáner nunca lo presione "
                                    "y no pierda la sesión durante el escaneo."))
            b.pack(side="left")
            chk = tk.Label(wrap, font=(FUI, 10, "bold"), bg=T["panel_bg"], fg=T["ok"])
            chk.pack(side="left", padx=(px(6), 0))
            self._macro_checks[flag] = (b, chk)
        opts = tk.Frame(parent, bg=T["panel_bg"])
        opts.pack(fill="x", pady=(px(10), 0))
        tk.Label(opts, text="Navegador", font=(FUI, 10), bg=T["panel_bg"], fg=T["text"]).pack(side="left")
        cb = ttk.Combobox(opts, textvariable=self._dast_browser_label_var, values=self._refresh_browser_catalog(),
                          state="readonly", width=18)
        cb.pack(side="left", padx=(px(6), px(16)))
        cb.bind("<<ComboboxSelected>>", lambda _e: self._dast_browser_var.set(next(
            (k for k, i in self._browser_catalog.items() if i["name"] == self._dast_browser_label_var.get()), "chrome")))
        self._spin(opts, "Espera de login (s)", self._dast_selwait_var, 1, 180, width=5)
        adv = tk.Frame(parent, bg=T["panel_bg"])
        link = tk.Label(parent, text="▸ Selectores avanzados", font=(FUI, 9, "bold"), bg=T["panel_bg"],
                        fg=T["border2"], cursor="hand2", anchor="w")
        link.pack(fill="x", pady=(px(10), 0))
        st = {"open": False}

        def toggle(_e=None):
            st["open"] = not st["open"]
            link.configure(text=("▾" if st["open"] else "▸") + " Selectores avanzados")
            if st["open"]:
                adv.pack(fill="x", pady=(px(6), 0), after=link)
            else:
                adv.pack_forget()
        link.bind("<Button-1>", toggle)
        self._fields_grid(adv, SELENIUM_ADV_FIELDS, self._dast_cred_vars)
        self._refresh_macro_ui()

    def _refresh_dast_creds(self):
        f = self._dast_cred_frame
        for w in f.winfo_children():
            w.destroy()
        kind = self._dast_auth_var.get()
        self._dast_auth_help.configure(text=AUTH_HELP.get(kind, ""))
        fields = [x for x in AUTH_FIELDS.get(kind, []) if x[0] in self._dast_cred_vars]
        if fields:
            self._fields_grid(f, fields, self._dast_cred_vars)
        self._dast_sel_wrap.pack_forget()
        self._dast_session_wrap.pack_forget()
        for w in self._dast_session_wrap.winfo_children():
            w.destroy()
        if kind == "selenium":
            self._dast_sel_wrap.pack(fill="x")
        if kind != "none":
            self._dast_session_wrap.pack(fill="x")
            self._hdiv(self._dast_session_wrap, pady=(px(10), px(10)))
            self._section_label(self._dast_session_wrap, "Control de sesión").pack(anchor="w", pady=(0, px(6)))
            self._fields_grid(self._dast_session_wrap, SESSION_FIELDS + (SESSION_FIELDS_ADMIN if self._is_admin else []),
                              self._dast_cred_vars)

    def _build_dast_probely_card(self, pad):
        c = self._card(pad, "Probely · solo administración", start_collapsed=True)
        self._probely_admin_rows(c, "dast")
        self._hdiv(c, pady=px(10))
        self._section_label(c, "Login y detección de logout en Probely").pack(anchor="w", pady=(0, px(6)))
        ld = tk.Frame(c, bg=T["panel_bg"])
        ld.pack(fill="x")
        tk.Label(ld, text="Login de formulario", font=(FUI, 10), bg=T["panel_bg"], fg=T["text"]).pack(side="left")
        ttk.Combobox(ld, textvariable=self._dast_form_login_var, values=["auto", "on", "off"], state="readonly",
                     width=6).pack(side="left", padx=(px(6), px(16)))
        tk.Label(ld, text="Condición", font=(FUI, 10), bg=T["panel_bg"], fg=T["text"]).pack(side="left")
        ttk.Combobox(ld, textvariable=self._dast_logout_cond_var, values=["any", "all"], state="readonly",
                     width=5).pack(side="left", padx=(px(6), px(16)))
        ToggleSwitch(ld, text="Detector por URL", variable=self._dast_logout_url_det_var).pack(side="left",
                                                                                            padx=(0, px(12)))
        ToggleSwitch(ld, text="Detector 401/403", variable=self._dast_logout_code_det_var).pack(side="left")
        g = tk.Frame(c, bg=T["panel_bg"])
        g.pack(fill="x", pady=(px(10), 0))
        for i in range(3):
            g.columnconfigure(i, weight=1, uniform="pl")
        for i, (label, var) in enumerate((("Selector CSS visible sin sesión", self._dast_logout_selector_var),
                                          ("Marcadores en el cuerpo", self._dast_logout_body_var),
                                          ("Marcadores en cabecera (Nombre: valor)", self._dast_logout_header_var))):
            cell = tk.Frame(g, bg=T["panel_bg"])
            cell.grid(row=0, column=i, sticky="ew", padx=(0 if not i else px(12), 0))
            self._field(cell, label, var)
        self._hdiv(c, pady=px(6))
        ToggleSwitch(c, text="El objetivo requiere 2FA (TOTP)", variable=self._dast_2fa_var).pack(anchor="w",
                                                                                                   pady=(0, px(8)))
        g = tk.Frame(c, bg=T["panel_bg"])
        g.pack(fill="x")
        for i in range(3):
            g.columnconfigure(i, weight=1, uniform="tf")
        for i, (label, var, show) in enumerate((("Semilla / secreto TOTP", self._dast_otp_secret_var, "•"),
                                                ("Selector CSS del campo OTP", self._dast_otp_field_var, ""),
                                                ("Selector CSS de enviar", self._dast_otp_submit_var, ""))):
            cell = tk.Frame(g, bg=T["panel_bg"])
            cell.grid(row=0, column=i, sticky="ew", padx=(0 if not i else px(12), 0))
            self._field(cell, label, var, show=show)
        r = tk.Frame(c, bg=T["panel_bg"])
        r.pack(fill="x")
        tk.Label(r, text="Algoritmo", font=(FUI, 10), bg=T["panel_bg"], fg=T["text"]).pack(side="left")
        ttk.Combobox(r, textvariable=self._dast_otp_alg_var, values=["SHA1", "SHA256", "SHA512"], state="readonly",
                     width=8).pack(side="left", padx=(px(6), px(16)))
        self._spin(r, "Dígitos", self._dast_otp_digits_var, 4, 10, width=4)
        return c

    def _refresh_dast_cards(self):
        self._refresh_dast_creds()

    def _collect_dast_cfg(self) -> ScanConfig:
        g = {k: v.get() for k, v in self._dast_cred_vars.items()}
        key = self._dast_browser_var.get() or "chrome"
        prof = norm_profile(self._dast_profile_var.get())
        return ScanConfig(
            url=self._dast_url_var.get().strip(), auth_type=self._dast_auth_var.get(), profile=prof,
            **{k: v for k, v in g.items() if not k.startswith("probely_")},
            selenium_browser=key, selenium_binary=self._browser_catalog.get(key, {}).get("binary", ""),
            selenium_wait_seconds=_int(self._dast_selwait_var, 15),
            scan_minutes=_int(self._dast_minutes_var, 30), ajax_spider=bool(self._dast_ajax_var.get()),
            exclude_paths=self._dast_exclude_var.get(), rate_limit=_int(self._dast_rate_var, 50),
            probely_target_id=self._dast_target_id_var.get().strip(),
            probely_reuse_by_url=self._dast_reuse_url_var.get(), probely_scan_profile=prof,
            probely_max_wait_minutes=float(_int(self._dast_maxwait_var, 180)),
            probely_poll_interval=float(_int(self._dast_poll_var, 15)),
            probely_require_verified=self._dast_require_verified_var.get(),
            probely_reduced_scopes=self._dast_reduced_scopes_var.get(), probely_blacklist=self._dast_blacklist_var.get(),
            probely_ignore_blackout=self._dast_ignore_blackout_var.get(),
            probely_compliance_report=_opt(self._dast_report_var.get()),
            probely_protect_session=self._dast_protect_session_var.get(),
            probely_agent_warn=self._dast_agent_warn_var.get(),
            probely_login_sequence_path=self._dast_seq_path_var.get().strip(),
            probely_form_login=self._dast_form_login_var.get() or "auto",
            probely_logout_detection=self._dast_relogin_var.get(),
            probely_check_session_url=g["probely_check_session_url"].strip(),
            probely_logout_markers=g["probely_logout_markers"],
            probely_logout_condition=self._dast_logout_cond_var.get() or "any",
            probely_logout_url_detector=self._dast_logout_url_det_var.get(),
            probely_logout_code_detector=self._dast_logout_code_det_var.get(),
            probely_logout_selector=self._dast_logout_selector_var.get().strip(),
            probely_logout_body_markers=self._dast_logout_body_var.get(),
            probely_logout_header_markers=self._dast_logout_header_var.get(),
            probely_login_url=g["selenium_login_url"].strip() or g["login_url"].strip(),
            probely_form_login_check_pattern=g["probely_form_login_check_pattern"].strip(),
            probely_form_submit_selector=g["selenium_submit_selector"].strip(),
            probely_2fa_enabled=self._dast_2fa_var.get(), probely_otp_secret=self._dast_otp_secret_var.get().strip(),
            probely_otp_field=self._dast_otp_field_var.get().strip(),
            probely_otp_submit=self._dast_otp_submit_var.get().strip(),
            probely_otp_algorithm=self._dast_otp_alg_var.get() or "SHA1",
            probely_otp_digits=_int(self._dast_otp_digits_var, 6))

    # métodos reutilizados (grabación de login/logout, condiciones, navegador)
    def _refresh_macro_ui(self):
        for flag, (b, chk) in getattr(self, "_macro_checks", {}).items():
            if chk.winfo_exists():
                chk.config(text="  ✔" if self._macro_recorded[flag] else "")
        if lo := getattr(self, "_macro_checks", {}).get("logout"):
            lo[0].config(state="normal" if self._macro_recorded["login"] else "disabled")

    def _macro_popup(self, flag):
        login = flag == "login"
        title = "Macro de inicio de sesión" if login else "Exclusión / marcadores de logout"
        recorded = self._macro_recorded[flag]
        popup = self._popup(title)
        self._popup_hdr(popup, title, icon="⏺" if login else "🚪")
        body = tk.Frame(popup, bg=T["bg"])
        body.pack(fill="both", expand=True)
        stat = tk.Frame(body, bg=T["panel_bg"], padx=px(14), pady=px(10))
        stat.pack(fill="x", padx=px(24), pady=(px(20), 0))
        tk.Label(stat, text="✔  Grabado" if recorded else "⬜  Sin grabar", font=(FUI, 10, "bold"), bg=T["panel_bg"],
                 fg=T["ok"] if recorded else T["muted"]).pack(side="left")
        tk.Label(stat, font=(FUI, 10), bg=T["panel_bg"], fg=T["muted"], justify="left", wraplength=px(620), text=(
            "Grabe una macro nueva, o guarde/cargue una grabada previamente." if login else
            "Grabe la acción de logout para EXCLUIRLA del rastreo (el escáner no la visitará), o configure marcadores de "
            "'sesión cerrada' a mano.")).pack(side="left", padx=(px(12), 0))
        row = tk.Frame(body, bg=T["bg"])
        row.pack(padx=px(24), pady=px(14))
        cond = "condición de login" if login else "condición de logout"

        def run(fn):
            popup.close()
            fn()

        def record():
            popup.close()
            if (self._dast_record_macro if login else self._dast_record_logout)():
                self._macro_recorded[flag] = True
                self._refresh_macro_ui()

        def load():
            popup.close()
            self._dast_load_condition(flag)
            if self._dast_cred_vars["selenium_login_url" if login else "logout_url_re"].get().strip():
                self._macro_recorded[flag] = True
                self._refresh_macro_ui()

        def clear():
            keys = CONDITION_KEYS["login"] + ["selenium_pass_value"] + CONDITION_KEYS["logout"] if login \
                else CONDITION_KEYS["logout"]
            for k in keys:
                self._dast_cred_vars[k].set("")
            self._macro_recorded[flag] = False
            if login:
                self._macro_recorded["logout"] = False
            self._refresh_macro_ui()
            self._refresh_dast_creds()
            popup.close()
        for icon, label, tip, cmd, enabled in (
                ("⏺", "Grabar nueva", "Abre un navegador real y registra clics de inicio de sesión y campos de formulario."
                 if login else "Abre un navegador, reproduce su login y registra la URL de logout para excluirla.",
                 record, True),
                ("💾", "Guardar…", "Guarda los selectores de login grabados + campos de detección de sesión.\nLas "
                 "contraseñas nunca se escriben en disco." if login else
                 "Guarda el regex de URL de logout + marcadores de sesión cerrada.",
                 lambda: run(lambda: self._dast_save_condition(flag)), recorded),
                ("📂", "Cargar…", f"Carga un archivo de {cond} guardado anteriormente.", load, True),
                ("🗑", "Limpiar", f"Restablecer la {cond} y limpiar todos los selectores guardados.", clear, recorded)):
            self._choice_card(row, icon, label, tip, enabled=enabled, icon_size=17, desc_wrap=170, on_click=cmd)
        self._popup_foot(popup, ("  Cerrar  ", popup.close))

    def _dast_save_condition(self, flag):
        data = {k: self._dast_cred_vars[k].get() for k in CONDITION_KEYS[flag]}
        if data.get("selenium_macro"):
            try:
                steps = json.loads(data["selenium_macro"])
                for s in steps:
                    if isinstance(s, dict) and s.get("kind") == "field" and _is_pass(s):
                        s["value"] = ""
                data["selenium_macro"] = json.dumps(steps)
            except Exception:
                pass
        name = f"condición de {flag}"
        with dialog_guard(self):
            path = filedialog.asksaveasfilename(title=f"Guardar {name}", defaultextension=".json",
                                                initialfile=f"dast_{flag}_condition.json",
                                                filetypes=[(name.capitalize(), "*.json"), ("Todos", "*.*")])
        if path:
            write_json(path, data)
            self._emit_log(f"[dast] {name} guardada → {path}" + ("  (sin el valor de la contraseña)" if flag == "login" else ""))

    def _dast_load_condition(self, flag):
        name = f"condición de {flag}"
        with dialog_guard(self):
            path = filedialog.askopenfilename(title=f"Cargar {name}", filetypes=[(name.capitalize(), "*.json"),
                                                                                 ("Todos", "*.*")])
        if not path:
            return
        data = read_json(path)
        if not isinstance(data, dict):
            return self._show_error_popup(f"Cargar {name}", "No se pudo leer el archivo.")
        applied = [k for k in CONDITION_KEYS[flag] if k in data]
        for k in applied:
            self._dast_cred_vars[k].set(str(data[k]))
        self._refresh_dast_creds()
        self._emit_log(f"[dast] {name} cargada ← {path}  (campos: {', '.join(applied) or 'ninguno'})")

    def _record_in_browser(self, err_title, hud_title, work):
        url = self._dast_cred_vars["selenium_login_url"].get().strip() or self._dast_url_var.get().strip()
        if not url or url == "https://":
            self._show_error_popup(err_title, "Configure una URL objetivo o de login primero.")
            return None
        done, ready_evt, nav_done = threading.Event(), threading.Event(), threading.Event()
        result: dict = {"_nav_done": nav_done}
        st = {"msg": None, "cancel": False, "stop": False, "ready": False}
        cfg = self._collect_dast_cfg()

        def runner():
            try:
                drv = _make_driver(cfg, headless=False, log=self._emit_log)
                result["_driver"] = drv
                ready_evt.set()
                try:
                    work(drv, url, done, result, lambda m: st.__setitem__("msg", m))
                finally:
                    try:
                        drv.quit()
                    except Exception:
                        pass
            except Exception as e:
                result["error"] = repr(e)
                ready_evt.set()
            finally:
                nav_done.set()
                done.set()

        def watchdog():
            if not ready_evt.wait(30) or not nav_done.wait(60):
                return
            misses = 0
            while not done.is_set() and (drv := result.get("_driver")):
                ok = {"v": False}
                t = threading.Thread(target=lambda: ok.__setitem__("v", bool(drv.window_handles)), daemon=True)
                t.start()
                t.join(3.0)
                misses = 0 if ok["v"] else misses + 1
                if misses >= 2:
                    self._emit_log("[grabación] la ventana del navegador se cerró — se cancela la operación.")
                    st["cancel"] = True
                    done.set()
                    try:
                        drv.quit()
                    except Exception:
                        pass
                    return
                if done.wait(1.5):
                    return

        def hotkeys():
            try:
                from pynput import keyboard as kb
                pressed = set()

                def press(key):
                    pressed.add(key)
                    if pressed & {kb.Key.ctrl, kb.Key.ctrl_l, kb.Key.ctrl_r} and pressed & {kb.Key.shift, kb.Key.shift_l,
                                                                                         kb.Key.shift_r}:
                        st["stop"] = st["stop"] or key == kb.Key.f12
                        st["cancel"] = st["cancel"] or key == kb.Key.f11
                with kb.Listener(on_press=press, on_release=pressed.discard) as lst:
                    done.wait()
                    lst.stop()
            except Exception as ex:
                self._emit_log(f"[atajo] pynput no disponible ({ex!r}) — presione Ctrl+Shift+F12 con la ventana del "
                               "escáner enfocada")
        runner_t = threading.Thread(target=runner, daemon=True)
        runner_t.start()
        for fn in (watchdog, hotkeys):
            threading.Thread(target=fn, daemon=True).start()
        W, H, PAD = px(380), px(118), px(16)
        hud = tk.Toplevel(self)
        hud.overrideredirect(True)
        hud.attributes("-topmost", True)
        hud.attributes("-alpha", 0.90)
        corner = [0]

        def place():
            sw, sh = hud.winfo_screenwidth(), hud.winfo_screenheight()
            x, y = [(sw - W - PAD, PAD), (PAD, PAD), (PAD, sh - H - PAD), (sw - W - PAD, sh - H - PAD)][corner[0]]
            hud.geometry(f"{W}x{H}+{x}+{y}")

        def dodge(_e=None):
            corner[0] = (corner[0] + 1) % 4
            place()
        place()
        outer = tk.Frame(hud, bg=T["accent"], padx=1, pady=1)
        outer.pack(fill="both", expand=True)
        inner = tk.Frame(outer, bg=T["panel_bg"], padx=px(12), pady=px(10))
        inner.pack(fill="both", expand=True)
        tk.Label(inner, text=hud_title, font=(FUI_TITLE, 14, "bold"), bg=T["panel_bg"], fg=T["accent"]).pack(anchor="w")
        status = tk.StringVar(value="⏳  Abriendo navegador…")
        tk.Label(inner, textvariable=status, font=(FUI, 10), bg=T["panel_bg"], fg=T["muted"], wraplength=W - 24).pack(
            anchor="w", pady=1)
        keys = tk.Label(inner, text="Ctrl+Shift+F12  →  capturar     Ctrl+Shift+F11  →  cancelar", font=(FUI, 10),
                        bg=T["panel_bg"], fg=T["muted"])
        keys.pack(anchor="w")
        for w in (hud, outer, inner, keys):
            w.bind("<Enter>", dodge, "+")

        def on_key(e):
            if e.state & 0x4 and e.state & 0x1:
                st["stop"] = st["stop"] or e.keysym == "F12"
                st["cancel"] = st["cancel"] or e.keysym == "F11"
        bid = self.bind("<KeyPress>", on_key, "+")
        hud.bind("<KeyPress>", on_key, "+")

        def poll():
            if ready_evt.is_set() and not st["ready"]:
                st["ready"] = "error" not in result
                status.set("❌  El navegador falló" if not st["ready"] else "✅  Navegador abierto — interactúe libremente")
            if st["msg"] and st["msg"] != status.get():
                status.set(st["msg"])
            if st["cancel"] or (st["stop"] and st["ready"]):
                done.set()
            if done.is_set():
                self.unbind("<KeyPress>", bid)
                hud.destroy()
            else:
                hud.after(150, poll)
        hud.after(150, poll)
        self.wait_window(hud)
        runner_t.join(1.5 if st["cancel"] else 10)
        cancelled = st["cancel"] or result.get("_cancelled")
        if "error" in result:
            self._show_error_popup(err_title, f"Error del navegador:\n{result['error']}")
        if cancelled or "error" in result:
            return None
        result["_url"] = url
        return result

    def _dast_record_macro(self):
        result = self._record_in_browser("Grabar condición de login", "⏺ Condición de login",
                                         record_macro_work(self._collect_dast_cfg(), self._emit_log))
        if result is None:
            return False
        try:
            macro = [s for s in json.loads(result.get("macro") or "[]") if isinstance(s, dict)]
        except Exception:
            macro = []
        user_sel, user_val, pass_sel, pass_val, submit_sel = analyze_login_macro(macro)
        submit_extra = None
        if not submit_sel:
            sub = next((s for s in macro if s.get("kind") == "submit"), None)
            ent = next((s for s in macro if s.get("kind") == "enter"), None)
            if sub and sub.get("button"):
                submit_sel = sub["button"]
            elif (sub or ent or {}).get("form"):
                submit_extra = {"submit": (sub or ent)["form"]}
            elif ent:
                submit_extra = {"key": "Enter", "selector": ent.get("selector") or pass_sel}
        c = self._dast_cred_vars
        for k, v in (("selenium_user_selector", user_sel), ("selenium_user_value", user_val),
                     ("selenium_pass_selector", pass_sel), ("selenium_pass_value", pass_val)):
            if v:
                c[k].set(v)
        c["selenium_submit_selector"].set(submit_sel or "")
        if not c["selenium_login_url"].get():
            c["selenium_login_url"].set(result["_url"])
        is_logout = lambda s: s.get("kind") == "click" and _LOGOUT_RE.search(f"{s.get('selector', '')} {s.get('text', '')}")
        extras = [{"selector": s["selector"], "value": s["value"]} for s in macro if s.get("kind") == "field"
                  and s.get("selector") not in (None, user_sel, pass_sel) and s.get("role") != "password" and s.get("value")]
        extras += [{"click": s["selector"]} for s in macro if s.get("kind") == "click" and s.get("selector")
                   and s["selector"] != submit_sel and not is_logout(s)]
        if submit_extra:
            extras.append(submit_extra)
        c["selenium_extra_steps"].set(json.dumps(extras) if extras else "")
        literal = [s for s in macro if not is_logout(s)]
        c["selenium_macro"].set(json.dumps(literal) if literal else "")
        submit_desc = submit_sel or ("Enter / enviar formulario" if submit_extra else "(no detectado)")
        self._emit_log(f"[macro] {len(macro)} interacciones capturadas — usuario={user_sel!r} contraseña={pass_sel!r} "
                       f"enviar={submit_desc!r}")
        self._show_info_popup("Condición de login",
            f"Se capturaron {len(macro)} interacciones.\n\n"
            f"Selector de usuario:  {user_sel or '(no detectado)'}\n"
            f"Selector de contraseña: {pass_sel or '(no detectado)'}\n"
            f"Valor de contraseña:    {'✔ capturado (solo en esta sesión)' if pass_val else '(escríbalo en Valor de contraseña antes de grabar el logout)'}\n"
            f"Enviar:                 {submit_desc}\n\n"
            "Enviar es la acción que envía el formulario de login — un clic en botón, o un Enter / envío de formulario "
            "cuando no hay botón.\nLa contraseña se conserva solo en esta sesión y se borra al cerrar el programa; nunca "
            "se escribe en ningún archivo guardado.")
        self._refresh_dast_creds()
        return True

    def _dast_record_logout(self):
        cfg = self._collect_dast_cfg()
        if cfg.selenium_pass_selector and not cfg.selenium_pass_value:
            self._show_info_popup("Condición de logout — se requiere login manual",
                "Su login fue grabado, pero la contraseña no se guardó (las contraseñas nunca se escriben en disco).\n\n"
                "El navegador abrirá la página de login. Inicie sesión a mano, vaya a la página sin sesión y presione "
                "Ctrl+Shift+F12 para capturar.\n\nConsejo: escriba su contraseña en el campo «Valor de contraseña» de la "
                "sección de credenciales y el login se reproducirá solo la próxima vez.")
        result = self._record_in_browser("Grabar condición de logout", "⏺ Condición de logout",
                                         record_logout_work(cfg, self._emit_log))
        if result is None:
            return False
        final_url = result.get("final_url", "").strip()
        macro = list(result.get("logout_macro", []))
        last = result.get("last_logout_click", {})
        snap = result.get("snapshot", {})
        if last.get("selector") and last["selector"] not in [s.get("selector", "") for s in macro if s.get("kind") == "click"]:
            macro.append({"kind": "click", **last})
            self._emit_log("[logout-rec] se agregó el último clic a la macro")

        def path_of(u):
            p = urlparse(u if "://" in u else "https://x" + u).path.rstrip("/") or "/"
            return p if p != "/" else None
        hrefs = result.get("logout_href_candidates", [])
        paths = [p for p in map(path_of, hrefs) if p]
        best = next((p for p in paths if any(k in p.lower() for k in ("logout", "log-out", "signout", "sign-out", "cerrar", "salir"))), None) or (paths[0] if paths else None) \
            or (final_url and path_of(final_url)) or (last.get("href") and path_of(last["href"]))
        proposed = re.escape(best) + r"(\?|$)" if best else ""
        self._emit_log(f"[logout-rec] regex propuesto={proposed!r} desde ruta={best!r}")
        popup = self._popup("Condición de logout — revisar y confirmar")
        self._popup_hdr(popup, "Condición de logout", subtitle="revisar señales capturadas", icon="🔓")
        wrap = tk.Frame(popup, bg=T["bg"])
        wrap.pack(fill="both", expand=True)
        body = scroll_frame(wrap, pad=(px(24), px(8)))
        body.columnconfigure(1, weight=1)
        r = [0]

        def put(w, col=0, span=2, sticky="w", **kw):
            w.grid(row=r[0], column=col, columnspan=span, sticky=sticky, **kw)
            if col + span >= 2:
                r[0] += 1
            return w

        def note(text):
            put(self._lbl(body, text, size=10, fg=T["muted"], wraplength=px(560), anchor="w", justify="left", bg=T["bg"]))

        def sep():
            put(tk.Frame(body, bg=T["border"], height=1), sticky="ew", pady=px(8))

        def field(label, var):
            put(self._lbl(body, label, anchor="e", bg=T["bg"]), span=1, sticky="e", padx=(0, px(8)), pady=px(3))
            put(ttk.Entry(body, textvariable=var), col=1, span=1, sticky="ew", pady=1)
        put(self._lbl(body, "URL capturada", anchor="e", bg=T["bg"]), span=1, sticky="e", padx=(0, px(8)), pady=px(3))
        put(self._lbl(body, final_url or "(ninguna)", size=10, fg=T["text"], anchor="w", wraplength=px(540), bg=T["bg"]),
            col=1, span=1)
        re_var = tk.StringVar(value=proposed)
        field("Regex de URL de logout", re_var)
        note("Las URLs que coincidan con este regex se OMITEN para que el escáner nunca cierre su propia sesión.\n" + (
            "⚠  La URL capturada fue la raíz (/). Escriba la ruta a la que redirige la app tras el logout (p. ej. /login "
            "o /signin). Déjelo en blanco si la app se queda en / — use el texto de sesión activa de abajo." if not proposed
            else "El regex debe coincidir con una ruta específica (p. ej. /login o /logout). Evite patrones que "
                 "coincidan con / — son demasiado amplios."))
        sep()
        put(self._section_label(body, "DETECCIÓN DE SESIÓN"))
        note("Opcionalmente indique cómo se ve una página CON sesión para detectar la pérdida de sesión durante el "
             "escaneo y volver a autenticarse.")
        txt_var = tk.StringVar(value=self._dast_cred_vars["login_success_text"].get())
        field("Texto de sesión activa", txt_var)
        note("Texto visible SOLO con sesión iniciada (p. ej. 'Mi cuenta'). Probely lo usa como patrón de confirmación "
             "de login (form_login_check_pattern).")
        if macro:
            sep()
            put(self._section_label(body, "ACCIÓN DE LOGOUT GRABADA"))
            note(f"✓ {len(macro)} paso(s) grabados ({sum(s.get('kind') == 'click' for s in macro)} clic(s)). El último "
                 "clic se trata como la acción de logout.")
            for label, key in (("Texto del botón", "text"), ("Selector CSS", "selector"), ("Id del elemento", "el_id"),
                               ("data-action", "data_action")):
                if v := (last.get(key) or "").strip():
                    note(f"  · {label}: {v[:70]}")
            href = (last.get("href") or "").strip()
            note(f"  · Navega a: {href[:70]}" if href and href not in ("#", "javascript:void(0)", "javascript:;") else
                 "  · Sin URL de navegación (botón SPA) — la protección es por identidad del elemento, no por URL.")
        if snap.get("hints") or snap.get("title") or snap.get("has_password_field") or snap.get("has_login_form"):
            sep()
            note("Señales detectadas en la página sin sesión (referencia):")
            if snap.get("has_password_field"):
                note("  ✓ campo de contraseña presente (típico de una página de login)")
            if snap.get("has_login_form"):
                note("  ✓ formulario de login presente")
            hints = list(dict.fromkeys(re.sub(r"\s+", " ", str(h)).strip()[:80] for h in snap.get("hints", [])))
            for h in ([f"Título de la página: {snap['title']}"] if snap.get("title") else []) + [h for h in hints if h][:8]:
                note(f"  · {h}")
        elif not final_url:
            sep()
            note("⚠️  No se capturaron datos de la página. Asegúrese de presionar Ctrl+Shift+F12 *estando en la página sin "
                 "sesión* (el navegador debe seguir abierto). Puede escribir el regex de URL de logout arriba y Aplicar.")
        applied = [False]

        def apply():
            c = self._dast_cred_vars
            if v := re_var.get().strip():
                c["logout_url_re"].set(v)
            if v := txt_var.get().strip():
                c["login_success_text"].set(v)
            if macro:
                c["selenium_logout_macro"].set(json.dumps(macro))
                self._emit_log(f"[logout-rec] macro de logout guardada ({len(macro)} pasos)")
            else:
                self._emit_log("[logout-rec] ADVERTENCIA: 0 pasos de logout grabados — abra el menú de usuario y haga "
                               "clic en Cerrar sesión mientras graba")
            applied[0] = True
            self._emit_log(f"[logout-rec] aplicado — regex={re_var.get().strip()!r} texto={txt_var.get().strip()!r}")
            self._refresh_dast_creds()
            popup.close()
        self._popup_foot(popup, ("Aplicar", apply), ("Cancelar", popup.close))
        self.wait_window(popup._win)
        if not applied[0]:
            self._emit_log("[logout-rec] cancelado — no se aplicaron cambios")
        return applied[0]

    def _refresh_browser_catalog(self) -> list[str]:
        try:
            cat = detect_browsers()
        except Exception:
            cat = {}
        self._browser_catalog = cat or {"chrome": {"name": "Google Chrome", "binary": "", "engine": "chromium"}}
        if self._dast_browser_var.get() not in self._browser_catalog:
            self._dast_browser_var.set(next(iter(self._browser_catalog)))
        self._dast_browser_label_var.set(self._browser_catalog[self._dast_browser_var.get()]["name"])
        return [i["name"] for i in self._browser_catalog.values()]
