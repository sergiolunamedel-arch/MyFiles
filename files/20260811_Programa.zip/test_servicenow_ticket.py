#!/usr/bin/env python3
"""
test_servicenow_ticket.py

Prueba automatizada del catalog item "Ticket Seguridad Plataformas DEV" en
ServiceNow (bancobasedev.service-now.com). Envía peticiones POST de prueba a
la API de Service Catalog (order_now) cubriendo las ramas condicionales del
formulario según el diccionario de variables: SAST/SCA, DAST, API y Escaneo
de Secretos — y opcionalmente cancela los tickets de prueba al terminar.

Este archivo funciona como:
  1) módulo importable por gui_servicenow_tester.py (la interfaz gráfica)
  2) script de línea de comandos independiente

Requisitos: ver requirements.txt (pip install -r requirements.txt)

Configuración de credenciales (elige una):
    export SNOW_USER="tu_usuario"
    export SNOW_PASS="tu_password"
    # o, si usan OAuth:
    export SNOW_TOKEN="tu_bearer_token"

Si no defines las variables de entorno, el modo CLI te las pedirá por
consola (la contraseña no se muestra en pantalla).

Uso (CLI):
    python3 test_servicenow_ticket.py                    # corre las 4 ramas + limpieza automática
    python3 test_servicenow_ticket.py --scenario api      # corre solo una rama
    python3 test_servicenow_ticket.py --dry-run           # solo imprime el payload
    python3 test_servicenow_ticket.py --no-cleanup        # no cancela los tickets al terminar
    python3 test_servicenow_ticket.py --list               # lista las ramas disponibles
    python3 test_servicenow_ticket.py --ambiente Producción --scenario sast_sca

Para la interfaz gráfica:
    python3 gui_servicenow_tester.py
"""

from __future__ import annotations

import argparse
import copy
import csv
import getpass
import json
import os
import sys
from datetime import datetime
from typing import Optional

import requests

# ---------------------------------------------------------------------------
# Configuración base (ajustable por variables de entorno)
# ---------------------------------------------------------------------------

BASE_URL = os.environ.get("SNOW_BASE_URL", "https://bancobasedev.service-now.com")
SYS_ID = os.environ.get("SNOW_CATALOG_SYS_ID", "799044769396c750af38b6ea6aba1080")
ORDER_URL = f"{BASE_URL}/api/sn_sc/servicecatalog/items/{SYS_ID}/order_now"

# El log SIEMPRE se ancla a la carpeta donde vive este archivo, no a la
# carpeta "actual" del proceso (CWD). Un path relativo como
# "servicenow_test_log.csv" depende de cómo se haya lanzado el programa —
# doble clic, acceso directo, terminal en otra carpeta, etc. — y por eso
# terminaba apareciendo en un lugar distinto al esperado. Anclarlo a
# SCRIPT_DIR lo hace determinista sin importar cómo se ejecute la GUI.
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_FILE = os.environ.get("SNOW_TEST_LOG") or os.path.join(SCRIPT_DIR, "servicenow_test_log.csv")

# Tabla / campo / valor usados para cancelar un REQ ya creado (Table API).
# El valor exacto del estado "cancelado" depende de la configuración de cada
# instancia de ServiceNow (puede ser una etiqueta o un código numérico) —
# ajusta estas variables de entorno si tu instancia usa otro esquema.
CANCEL_TABLE = os.environ.get("SNOW_CANCEL_TABLE", "sc_request")
CANCEL_STATE_FIELD = os.environ.get("SNOW_CANCEL_STATE_FIELD", "state")
CANCEL_STATE_VALUE = os.environ.get("SNOW_CANCEL_STATE", "Closed Cancelled")

# Credenciales persistentes (opcional). Guardadas en texto plano junto al
# script, a petición explícita — sólo para uso en el ambiente DEV. Se
# restringe a permisos de solo lectura/escritura del dueño donde el sistema
# operativo lo permite; no la subas a un repositorio (agrégala a .gitignore).
CREDENTIALS_FILE = os.path.join(SCRIPT_DIR, ".snow_credentials.json")

# Nombre de la aplicación y descripción por defecto usados en el ticket.
# Configurables (env var, CLI, o campo en la GUI) para que el ticket luzca
# como una solicitud real y no delate que se generó con un script.
DEFAULT_APP_NAME = os.environ.get("SNOW_APP_NAME", "Portal-Clientes")
DEFAULT_DESCRIPTION = os.environ.get(
    "SNOW_DESCRIPCION",
    "Solicitud de escaneo de seguridad conforme al calendario de revisiones periódicas.",
)

# ---------------------------------------------------------------------------
# Campos comunes a todas las ramas (ver hoja "Variables" del diccionario)
# ---------------------------------------------------------------------------

BASE_FIELDS = {
    "id_del_solicitante": "ysantos",
    "nombre_del_solicitante": "Yessica de los Angeles Santos Sifuentes",
    "correo_del_solicitante": "ysantos@bancobase.com",
    "objetivo_de_la_solicitud": "Obtener solicitudes de escaneo y limpieza de falsos positivos",
    "nombre_de_la_aplicaci_n": DEFAULT_APP_NAME,
    "ambiente": "Desarrollo",
    "modo_ejecucion": "Baseline",
    "clasificaci_n_de_la_aplicaci_n": "MDP",
    "prioridad_": "Media",
    "owner_de_la_aplicaci_n2": "URL de la API",
    "descripci_n_de_la_solicitud_justificaci_n": DEFAULT_DESCRIPTION,
}

# ---------------------------------------------------------------------------
# Ramas condicionales según "tipo_de_escaneo"
# (nombres de variable EXACTOS tal como están en el diccionario / catalog item)
# ---------------------------------------------------------------------------

SCENARIOS = {
    "sast_sca": {
        "tipo_de_escaneo": "SAST/SCA",
        "organizaci_n_en_snyk": "TEST-ORG",
    },
    "dast": {
        "tipo_de_escaneo": "DAST",
        "organizaci_n_en_snyk2": "TEST-ORG",
        "requiere_triage": "No",
        "url_objetivo": "https://test.bancobase.com",
        "urls_a_excluir": "N/A",  # una cadena vacía puede fallar la validación de "obligatorio"
        "usar_cuenta_de_servicio_del_equipo": "Si",
        # Si usar_cuenta_de_servicio_del_equipo = "No", agregar:
        # "cual_cuenta_utilizar": "cuenta-ejemplo",
    },
    "api": {
        "tipo_de_escaneo": "API",
        "cuentas_con_url": "URL de la API",
        "Organizacion_3": "TEST-ORG",
        "tecnologia_api": "REST",
        "usar_cuenta_de_servicio_del_equipo": "Si",
        "url_de_la_api": "https://test.bancobase.com/api",
        # "archivo_definicion": "..."  # solo si cuentas_con_url = archivo de definición
    },
    "secretos": {
        "tipo_de_escaneo": "Escaneo de Secretos",
        "repositorio_s": "test-repo",
        "ruta_monorepo": "/",
        "usar_cuenta_de_servicio_del_equipo": "Si",
        # "cual_cuenta_utilizar": "cuenta-ejemplo",  # solo si es "No"
    },
}


def build_payload(scenario_name: str, ambiente: Optional[str] = None,
                   app_name: Optional[str] = None, descripcion: Optional[str] = None) -> dict:
    """Arma el payload combinando BASE_FIELDS + la rama seleccionada.

    app_name / descripcion permiten sobreescribir esos dos campos por
    petición (recomendado: usa un nombre de aplicación y una justificación
    reales de tu portafolio, no algo que suene a prueba automatizada).
    """
    if scenario_name not in SCENARIOS:
        raise ValueError(f"Escenario desconocido: {scenario_name}")

    fields = copy.deepcopy(BASE_FIELDS)
    if app_name:
        fields["nombre_de_la_aplicaci_n"] = app_name
    if descripcion:
        fields["descripci_n_de_la_solicitud_justificaci_n"] = descripcion
    if ambiente:
        fields["ambiente"] = ambiente
    fields.update(SCENARIOS[scenario_name])

    return {"sysparm_quantity": "1", "variables": fields}


def load_saved_credentials() -> dict:
    """Lee las credenciales guardadas localmente, si existen."""
    if not os.path.isfile(CREDENTIALS_FILE):
        return {}
    try:
        with open(CREDENTIALS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def save_credentials(user: str = "", password: str = "", token: str = "") -> None:
    """Guarda user/password/token en texto plano junto al script."""
    with open(CREDENTIALS_FILE, "w", encoding="utf-8") as f:
        json.dump({"user": user, "password": password, "token": token}, f)
    try:
        os.chmod(CREDENTIALS_FILE, 0o600)
    except OSError:
        pass


def clear_saved_credentials() -> None:
    try:
        os.remove(CREDENTIALS_FILE)
    except FileNotFoundError:
        pass


def get_auth():
    """(Solo CLI) Regresa (auth, headers). Prioridad: variables de entorno >
    credenciales guardadas > prompt interactivo."""
    token = os.environ.get("SNOW_TOKEN")
    if token:
        return None, {"Authorization": f"Bearer {token}"}

    saved = load_saved_credentials()
    if saved.get("token"):
        return None, {"Authorization": f"Bearer {saved['token']}"}

    user = os.environ.get("SNOW_USER") or saved.get("user") or input("Usuario ServiceNow: ")
    password = os.environ.get("SNOW_PASS") or saved.get("password") or getpass.getpass("Password ServiceNow: ")
    return (user, password), {}


def remember_auth(auth, extra_headers: dict) -> None:
    """Persiste las credenciales resueltas por get_auth()/la GUI."""
    auth_header = extra_headers.get("Authorization", "")
    token = auth_header[len("Bearer "):] if auth_header.startswith("Bearer ") else ""
    user, password = auth if auth else ("", "")
    save_credentials(user=user or "", password=password or "", token=token)


def send_request(scenario_name: str, payload: dict, auth, extra_headers: dict, dry_run: bool,
                  log=print) -> dict:
    """Envía el POST de order_now. `log` es la función usada para imprimir
    (se puede pasar un callback distinto de print, p.ej. desde la GUI)."""
    headers = {"Accept": "application/json", "Content-Type": "application/json"}
    headers.update(extra_headers)

    if dry_run:
        log(f"--- [DRY RUN] {scenario_name} ---")
        log(json.dumps(payload, indent=2, ensure_ascii=False))
        return {"scenario": scenario_name, "status": "dry-run", "sys_id": "", "request_number": "", "error": ""}

    try:
        resp = requests.post(ORDER_URL, auth=auth, headers=headers, json=payload, timeout=30)
    except requests.RequestException as exc:
        log(f"[{scenario_name}] ERROR de red: {exc}")
        return {"scenario": scenario_name, "status": "network_error", "sys_id": "", "request_number": "", "error": str(exc)}

    result_row = {"scenario": scenario_name, "status": resp.status_code, "sys_id": "", "request_number": "", "error": ""}

    if resp.status_code in (200, 201):
        try:
            body = resp.json()
            result = body.get("result", {})
            result_row["request_number"] = result.get("request_number", "")
            result_row["sys_id"] = result.get("sys_id", "") or result.get("request_id", "")
            log(f"[{scenario_name}] OK ({resp.status_code}) -> request_number: {result_row['request_number']}")
        except (ValueError, KeyError) as exc:
            result_row["error"] = f"Respuesta OK pero no se pudo parsear: {exc}"
            log(f"[{scenario_name}] OK ({resp.status_code}) pero respuesta inesperada:\n{resp.text[:500]}")
    else:
        result_row["error"] = resp.text[:1000]
        log(f"[{scenario_name}] FALLÓ ({resp.status_code}):\n{resp.text[:1000]}")
        if "mandatory" in resp.text.lower():
            log(f"[{scenario_name}] Diagnosticando variables obligatorias faltantes...")
            diagnose_missing_variables(payload, auth, extra_headers, log=log)

    return result_row


def cancel_request(sys_id: str, auth, extra_headers: dict, log=print) -> dict:
    """Cancela un REQ ya creado actualizando su estado vía Table API.

    NOTA: el valor exacto del estado "cancelado" (CANCEL_STATE_VALUE) depende
    de la configuración de tu instancia de ServiceNow. Algunas instancias
    también restringen la cancelación directa por Table API y requieren pasar
    por un Flow/Business Rule específico — si ves errores 403, confírmalo con
    el equipo de plataforma de ServiceNow.
    """
    if not sys_id:
        return {"cancelled": False, "cleanup_error": "sin sys_id (no se puede cancelar)"}

    url = f"{BASE_URL}/api/now/table/{CANCEL_TABLE}/{sys_id}"
    headers = {"Accept": "application/json", "Content-Type": "application/json"}
    headers.update(extra_headers)
    body = {
        CANCEL_STATE_FIELD: CANCEL_STATE_VALUE,
        "close_notes": "Cancelado automáticamente por test_servicenow_ticket.py (ticket de prueba)",
    }

    try:
        resp = requests.patch(url, auth=auth, headers=headers, json=body, timeout=30)
    except requests.RequestException as exc:
        log(f"  cleanup {sys_id}: ERROR de red: {exc}")
        return {"cancelled": False, "cleanup_error": str(exc)}

    if resp.status_code in (200, 201):
        log(f"  cleanup {sys_id}: cancelado OK")
        return {"cancelled": True, "cleanup_error": ""}

    log(f"  cleanup {sys_id}: FALLÓ ({resp.status_code}): {resp.text[:300]}")
    return {"cancelled": False, "cleanup_error": f"{resp.status_code}: {resp.text[:300]}"}


def list_variables(auth, extra_headers: dict, mandatory_only: bool = True, log=print) -> list[dict]:
    """Consulta la Table API para listar las variables REALMENTE configuradas
    en el catalog item (tabla item_option_new), con su flag `mandatory`.

    Esto es la forma confiable de diagnosticar "mandatory variables are
    required": ese error de order_now no dice cuál variable falta, y puede
    tratarse de una variable que la lógica de UI oculta en tu rama (ej. sólo
    aparece para otro tipo_de_escaneo) pero que el backend sigue exigiendo.
    """
    query = f"cat_item={SYS_ID}"
    if mandatory_only:
        query += "^mandatory=true"
    url = (f"{BASE_URL}/api/now/table/item_option_new"
           f"?sysparm_query={query}^ORDERBYorder"
           f"&sysparm_fields=name,question_text,mandatory,active,order,type"
           f"&sysparm_limit=200")
    headers = {"Accept": "application/json"}
    headers.update(extra_headers)

    try:
        resp = requests.get(url, auth=auth, headers=headers, timeout=30)
    except requests.RequestException as exc:
        log(f"ERROR de red al listar variables: {exc}")
        return []

    if resp.status_code != 200:
        log(f"No se pudieron listar variables ({resp.status_code}): {resp.text[:1000]}")
        return []

    try:
        rows = resp.json().get("result", [])
    except ValueError:
        log("Respuesta no es JSON válido al listar variables.")
        return []

    if not rows:
        log("(sin resultados — revisa que SNOW_CATALOG_SYS_ID sea correcto, "
            "o que tu usuario tenga permiso de lectura sobre item_option_new)")
        return rows

    label = "obligatorias" if mandatory_only else "todas las"
    log(f"Variables {label} del catalog item ({len(rows)}):")
    for row in rows:
        flag = "OBLIGATORIA" if str(row.get("mandatory")).lower() == "true" else "opcional"
        active = "" if str(row.get("active", "true")).lower() == "true" else " [INACTIVA]"
        log(f"  [{flag}]{active} {row.get('name')}  —  {row.get('question_text')}")
    return rows


def diagnose_missing_variables(payload: dict, auth, extra_headers: dict, log=print) -> None:
    """Se llama automáticamente cuando order_now responde 'mandatory
    variables are required'. Compara las variables realmente marcadas como
    obligatorias en el catalog item contra las que se enviaron, y reporta
    cuáles faltan — porque el error de order_now por sí solo no lo dice."""
    mandatory_vars = list_variables(auth, extra_headers, mandatory_only=True, log=lambda *_: None)
    sent_names = set(payload.get("variables", {}).keys())
    missing = [v for v in mandatory_vars if v.get("name") not in sent_names]

    if missing:
        log("  >>> Variables obligatorias que FALTAN en el payload enviado:")
        for v in missing:
            log(f"       - {v.get('name')}  ({v.get('question_text')})")
    elif mandatory_vars:
        log("  >>> Todas las variables marcadas 'obligatorias' sí se enviaron; el "
            "rechazo probablemente es por un VALOR inválido (ej. una opción de "
            "choice/reference que no existe en tu instancia), no por un campo faltante.")
    else:
        log("  >>> No se pudo obtener la lista de variables obligatorias para comparar "
            "(revisa el mensaje anterior).")


def list_recent_tickets(auth, extra_headers: dict, limit: int = 25, log=print) -> list[dict]:
    """Lista los RITM más recientes de ESTE catalog item (tabla sc_req_item,
    filtrada por cat_item), con el sys_id de su REQ padre — que es lo que
    cancel_request() necesita — y su estado legible.
    """
    url = (f"{BASE_URL}/api/now/table/sc_req_item"
           f"?sysparm_query=cat_item={SYS_ID}^ORDERBYDESCsys_created_on"
           f"&sysparm_fields=sys_id,number,state,short_description,sys_created_on,request"
           f"&sysparm_display_value=all"
           f"&sysparm_limit={limit}")
    headers = {"Accept": "application/json"}
    headers.update(extra_headers)

    try:
        resp = requests.get(url, auth=auth, headers=headers, timeout=30)
    except requests.RequestException as exc:
        log(f"ERROR de red al listar tickets: {exc}")
        return []

    if resp.status_code != 200:
        log(f"No se pudieron listar tickets ({resp.status_code}): {resp.text[:1000]}")
        return []

    try:
        rows = resp.json().get("result", [])
    except ValueError:
        log("Respuesta no es JSON válido al listar tickets.")
        return []

    def _raw(field):
        return field.get("value", "") if isinstance(field, dict) else (field or "")

    def _readable(field):
        return field.get("display_value", "") if isinstance(field, dict) else (field or "")

    tickets = []
    for row in rows:
        tickets.append({
            "ritm_sys_id": _raw(row.get("sys_id")),
            "ritm_number": _raw(row.get("number")),
            "request_sys_id": _raw(row.get("request")),
            "state": _readable(row.get("state")),
            "short_description": _readable(row.get("short_description"))[:80],
            "created": _raw(row.get("sys_created_on")),
        })

    if not tickets:
        log("(sin tickets encontrados para este catalog item)")
    return tickets


def cleanup_results(results: list[dict], auth, extra_headers: dict, log=print) -> None:
    """Cancela in-place cada resultado exitoso que tenga sys_id."""
    for row in results:
        if row.get("status") in (200, 201) and row.get("sys_id"):
            cleanup = cancel_request(row["sys_id"], auth, extra_headers, log=log)
            row["cleanup_status"] = "cancelado" if cleanup["cancelled"] else "error"
            row["cleanup_error"] = cleanup["cleanup_error"]
        else:
            row["cleanup_status"] = "n/a"
            row["cleanup_error"] = ""


def log_results(rows: list[dict], log_file: str = LOG_FILE) -> None:
    file_exists = os.path.isfile(log_file)
    fieldnames = ["timestamp", "scenario", "status", "sys_id", "request_number",
                  "error", "cleanup_status", "cleanup_error"]
    with open(log_file, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        if not file_exists:
            writer.writeheader()
        for row in rows:
            row_out = {"timestamp": datetime.now().isoformat(timespec="seconds")}
            row_out.update({k: row.get(k, "") for k in fieldnames if k != "timestamp"})
            writer.writerow(row_out)
    print(f"\nResultados agregados a {log_file}")


def main():
    parser = argparse.ArgumentParser(description="Prueba el template de ticket de ServiceNow.")
    parser.add_argument("--scenario", choices=list(SCENARIOS.keys()), help="Corre solo una rama.")
    parser.add_argument("--ambiente", help="Sobrescribe el ambiente (ej. 'Producción' para probar la nota de validación).")
    parser.add_argument("--app-name", help=f"Nombre de la aplicación a usar en el ticket (default: '{DEFAULT_APP_NAME}').")
    parser.add_argument("--descripcion", help="Descripción/justificación de la solicitud (default: texto genérico de revisión periódica).")
    parser.add_argument("--dry-run", action="store_true", help="Solo imprime el payload, no llama a la API.")
    parser.add_argument("--no-cleanup", action="store_true", help="No cancela los tickets de prueba al terminar.")
    parser.add_argument("--list", action="store_true", help="Lista las ramas disponibles y sale.")
    parser.add_argument("--inspect", action="store_true",
                         help="Consulta a ServiceNow cuáles variables son realmente obligatorias en el catalog item y sale (no crea tickets).")
    parser.add_argument("--inspect-all", action="store_true",
                         help="Como --inspect pero muestra todas las variables, no sólo las obligatorias.")
    parser.add_argument("--list-tickets", nargs="?", const=25, type=int, metavar="N",
                         help="Lista los últimos N tickets (RITM) de este catalog item y sale (default 25).")
    parser.add_argument("--cancel", nargs="+", metavar="REQ_SYS_ID",
                         help="Cancela el/los REQ indicados por su sys_id (ver --list-tickets) y sale.")
    parser.add_argument("--remember", action="store_true",
                         help="Guarda las credenciales usadas en este comando (texto plano, junto al script).")
    parser.add_argument("--forget-credentials", action="store_true",
                         help="Borra las credenciales guardadas y sale.")
    parser.add_argument("--gui", action="store_true", help="Lanza la interfaz gráfica en vez del CLI.")
    args = parser.parse_args()

    if args.forget_credentials:
        clear_saved_credentials()
        print("Credenciales guardadas eliminadas.")
        return

    if args.gui:
        import gui_servicenow_tester
        gui_servicenow_tester.launch()
        return

    if args.list:
        print("Ramas disponibles:", ", ".join(SCENARIOS.keys()))
        return

    if args.inspect or args.inspect_all:
        auth, extra_headers = get_auth()
        if args.remember:
            remember_auth(auth, extra_headers)
        list_variables(auth, extra_headers, mandatory_only=not args.inspect_all)
        return

    if args.list_tickets is not None:
        auth, extra_headers = get_auth()
        if args.remember:
            remember_auth(auth, extra_headers)
        tickets = list_recent_tickets(auth, extra_headers, limit=args.list_tickets)
        for t in tickets:
            print(f"{t['ritm_number']:<14} {t['state']:<22} {t['created']:<20} "
                  f"{t['short_description']:<40} REQ sys_id: {t['request_sys_id']}")
        return

    if args.cancel:
        auth, extra_headers = get_auth()
        if args.remember:
            remember_auth(auth, extra_headers)
        for sys_id in args.cancel:
            cancel_request(sys_id, auth, extra_headers)
        return

    scenarios_to_run = [args.scenario] if args.scenario else list(SCENARIOS.keys())

    auth, extra_headers = (None, {}) if args.dry_run else get_auth()
    if args.remember and not args.dry_run:
        remember_auth(auth, extra_headers)

    results = []
    for name in scenarios_to_run:
        payload = build_payload(name, ambiente=args.ambiente, app_name=args.app_name, descripcion=args.descripcion)
        results.append(send_request(name, payload, auth, extra_headers, args.dry_run))

    if args.dry_run:
        print("\n(dry-run: nada se envió ni se guardó en el log)")
        return

    if not args.no_cleanup:
        print("\nLimpiando tickets de prueba...")
        cleanup_results(results, auth, extra_headers)
    else:
        for row in results:
            row["cleanup_status"] = "omitido"
            row["cleanup_error"] = ""

    log_results(results)


if __name__ == "__main__":
    sys.exit(main())
