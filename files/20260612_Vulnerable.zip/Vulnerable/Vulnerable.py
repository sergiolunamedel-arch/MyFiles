from flask import Flask, request
import sqlite3
import os

app = Flask(__name__)

@app.route('/update')
def update_user():
    # Snyk detectará esto como SQL Injection porque 'id' viene de la URL
    user_id = request.args.get('id') 
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    query = f"SELECT * FROM users WHERE id = '{user_id}'"
    cursor.execute(query)
    
    # Snyk detectará esto como Path Traversal porque 'file' viene de la URL
    filename = request.args.get('file')
    with open(os.path.join("/tmp/", filename), 'r') as f:
        content = f.read()
        
    return content

# Snyk detectará esto como Hardcoded Secret
PASSWORD_DB = "admin_password_123"