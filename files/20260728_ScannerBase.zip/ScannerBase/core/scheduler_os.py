from __future__ import annotations
import getpass
import os
import plistlib
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional
import xml.etree.ElementTree as ET

IS_WIN   = os.name == "nt"
IS_MAC   = sys.platform == "darwin"
IS_LINUX = not IS_WIN and not IS_MAC

# Stable identity for everything this module creates. Do not change across
# versions without also migrating/removing the old identity, or repair
# logic will leave an orphaned entry behind under the old name.
TASK_ID        = "SecDevOpsBancoBase_ScanScheduler"
LAUNCHD_LABEL  = "com.bancobase.secdevops.scanscheduler"
CRON_BEGIN     = f"# >>> {TASK_ID} (auto-managed by SecDevOps Banco Base — no editar a mano) >>>"
CRON_END       = f"# <<< {TASK_ID} <<<"
RUNNER_FILE    = "scheduled_runner.py"
MANIFEST_NAME  = ".scheduler_manifest.json"
DEFAULT_INTERVAL_MIN = 5


def _log(cb: Optional[Callable[[str], None]], msg: str) -> None:
    if cb:
        try: cb(msg)
        except Exception: pass


@dataclass
class SchedulerStatus:
    backend: str                       # "schtasks" | "launchd" | "cron" | "unsupported"
    installed: bool = False            # an entry tagged TASK_ID exists
    healthy: bool = False              # installed AND command matches current path/interpreter
    permission_denied: bool = False    # last operation failed for permission/policy reasons
    detail: str = ""                   # human-readable Spanish message, safe to show in the UI
    command: list[str] = field(default_factory=list)  # expected [python_exe, runner_path, "--tick"]


def platform_label() -> str:
    if IS_WIN:  return "Programador de tareas de Windows"
    if IS_MAC:  return "launchd (macOS)"
    if IS_LINUX: return "cron (Linux)"
    return "no soportado en este sistema"


def runner_path(script_dir: Path) -> Path:
    return Path(script_dir) / RUNNER_FILE


def _win_pythonw(python_exe: str) -> str:
    """Prefer pythonw.exe (no console subsystem) over python.exe for the
    scheduled task. python.exe pops a visible cmd window on every single
    tick — even when scheduled_runner.py notices the GUI is already open
    and exits immediately — because Task Scheduler still has to launch a
    console-subsystem process to run it. pythonw.exe ships alongside
    python.exe in every standard CPython install and needs no elevation or
    stored credentials, unlike switching to "run whether user is logged on
    or not". Falls back to python_exe unchanged if pythonw.exe isn't found
    next to it (e.g. some unusual embedded/portable environments)."""
    candidate = Path(python_exe).with_name("pythonw.exe")
    return str(candidate) if candidate.exists() else python_exe


def build_command(script_dir: Path, python_exe: str) -> list[str]:
    if IS_WIN:
        python_exe = _win_pythonw(python_exe)
    return [str(python_exe), str(runner_path(script_dir)), "--tick"]


def _manifest_path(data_dir: Path) -> Path:
    return Path(data_dir) / MANIFEST_NAME


def _write_manifest(data_dir: Path, status: SchedulerStatus, interval_minutes: int) -> None:
    import json
    from datetime import datetime
    try:
        _manifest_path(data_dir).write_text(json.dumps({
            "task_id": TASK_ID, "backend": status.backend, "installed": status.installed,
            "healthy": status.healthy, "command": status.command,
            "interval_minutes": interval_minutes,
            "updated_at": datetime.now().isoformat(timespec="seconds"),
        }, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass  # bookkeeping only — never fatal


# ── Public API ──────────────────────────────────────────────────────────

def get_status(script_dir: Path, python_exe: str, data_dir: Path,
                interval_minutes: int = DEFAULT_INTERVAL_MIN) -> SchedulerStatus:
    """Read-only: what does the OS actually have registered for us right now?"""
    expected_cmd = build_command(script_dir, python_exe)
    if IS_WIN:
        return _win_status(expected_cmd, interval_minutes)
    if IS_MAC:
        return _mac_status(expected_cmd, interval_minutes)
    if IS_LINUX:
        return _linux_status(expected_cmd, interval_minutes)
    return SchedulerStatus(backend="unsupported", detail="Este sistema operativo no está soportado "
                            "para escaneos programados con la aplicación cerrada.")


def install_or_repair(script_dir: Path, python_exe: str, data_dir: Path,
                       interval_minutes: int = DEFAULT_INTERVAL_MIN,
                       log: Optional[Callable[[str], None]] = None) -> SchedulerStatus:
    """Idempotent: create the job if missing, silently repair it if the
    registered command drifted from the current folder/interpreter (e.g.
    the program's folder was moved), or leave it alone if already healthy.
    Safe — and intended — to call on every app launch."""
    status = get_status(script_dir, python_exe, data_dir, interval_minutes)
    if status.healthy:
        _log(log, f"[scheduler-os] {platform_label()}: tarea ya registrada y actualizada.")
        _write_manifest(data_dir, status, interval_minutes)
        return status

    _log(log, f"[scheduler-os] {platform_label()}: "
              f"{'reparando ruta de la tarea existente' if status.installed else 'registrando tarea nueva'}…")
    try:
        if IS_WIN:
            status = _win_install(script_dir, python_exe, interval_minutes)
        elif IS_MAC:
            status = _mac_install(script_dir, python_exe, data_dir, interval_minutes)
        elif IS_LINUX:
            status = _linux_install(script_dir, python_exe, data_dir, interval_minutes)
        else:
            status = SchedulerStatus(backend="unsupported", detail="Sistema operativo no soportado.")
    except Exception as e:
        status = SchedulerStatus(backend=platform_label(), permission_denied=True,
                                  detail=f"No se pudo registrar la tarea del sistema: {e!r}")

    _log(log, f"[scheduler-os] {status.detail}")
    _write_manifest(data_dir, status, interval_minutes)
    return status


def remove(data_dir: Path, log: Optional[Callable[[str], None]] = None) -> SchedulerStatus:
    """Uninstall our OS-level job, if present. Used when the user explicitly
    turns off "run when closed" from the Automatizar tab."""
    try:
        if IS_WIN:
            status = _win_remove()
        elif IS_MAC:
            status = _mac_remove()
        elif IS_LINUX:
            status = _linux_remove()
        else:
            status = SchedulerStatus(backend="unsupported")
    except Exception as e:
        status = SchedulerStatus(backend=platform_label(), permission_denied=True,
                                  detail=f"No se pudo quitar la tarea del sistema: {e!r}")
    _log(log, f"[scheduler-os] {status.detail}")
    try:
        _manifest_path(data_dir).unlink(missing_ok=True)
    except Exception:
        pass
    return status


def _classify_permission_error(text: str) -> bool:
    low = (text or "").lower()
    return any(m in low for m in (
        "access is denied", "acceso denegado", "denied", "denegado",
        "not allowed", "no está permitido", "no permitido", "permission",
        "operation not permitted", "requires elevation", "eleva",
    ))


# ── Windows (schtasks.exe) ────────────────────────────────────────────────
# No /RU or /RP → task is owned by the current user with no stored
# password (Task Scheduler's "Run only when user is logged on"), which
# never requires an elevated prompt to create.

def _win_status(expected_cmd: list[str], interval_minutes: int) -> SchedulerStatus:
    try:
        out = subprocess.run(["schtasks", "/Query", "/TN", TASK_ID, "/XML"],
                              capture_output=True, text=True, timeout=15,
                              encoding="utf-8", errors="replace")
    except Exception as e:
        return SchedulerStatus(backend="schtasks", command=expected_cmd,
                                detail=f"No se pudo consultar el Programador de tareas: {e!r}")
    if out.returncode != 0:
        # Not found is the common/expected "not installed yet" case.
        return SchedulerStatus(backend="schtasks", installed=False, command=expected_cmd,
                                detail="Sin tarea registrada en el Programador de tareas de Windows.")
    try:
        ns = {"t": "http://schemas.microsoft.com/windows/2004/02/mit/task"}
        root = ET.fromstring(out.stdout)
        cmd_el = root.find(".//t:Actions/t:Exec/t:Command", ns)
        args_el = root.find(".//t:Actions/t:Exec/t:Arguments", ns)
        cmd  = (cmd_el.text or "").strip('"') if cmd_el is not None else ""
        args = (args_el.text or "") if args_el is not None else ""
        matches = (cmd == expected_cmd[0] and expected_cmd[1] in args and "--tick" in args)
        return SchedulerStatus(backend="schtasks", installed=True, healthy=matches, command=expected_cmd,
                                detail=("Tarea registrada y apuntando a la ubicación actual del programa."
                                        if matches else
                                        "Tarea registrada pero apunta a una ubicación anterior — se reparará."))
    except Exception as e:
        return SchedulerStatus(backend="schtasks", installed=True, healthy=False, command=expected_cmd,
                                detail=f"Tarea registrada pero no se pudo verificar su ruta ({e!r}) — se reparará.")


def _win_install(script_dir: Path, python_exe: str, interval_minutes: int) -> SchedulerStatus:
    expected_cmd = build_command(script_dir, python_exe)
    tr = f'"{expected_cmd[0]}" "{expected_cmd[1]}" --tick'
    out = subprocess.run(
        ["schtasks", "/Create", "/TN", TASK_ID, "/TR", tr, "/SC", "MINUTE",
         "/MO", str(max(1, interval_minutes)), "/RL", "LIMITED", "/F"],
        capture_output=True, text=True, timeout=20, encoding="utf-8", errors="replace")
    if out.returncode == 0:
        return SchedulerStatus(backend="schtasks", installed=True, healthy=True, command=expected_cmd,
                                detail="Tarea registrada en el Programador de tareas de Windows "
                                       f"(cada {interval_minutes} min, solo con la sesión iniciada).")
    denied = _classify_permission_error(out.stderr or out.stdout)
    return SchedulerStatus(backend="schtasks", permission_denied=denied, command=expected_cmd,
                            detail=("Sin permisos para crear tareas en el Programador de tareas de Windows."
                                    if denied else
                                    f"No se pudo crear la tarea de Windows: {(out.stderr or out.stdout).strip()}"))


def _win_remove() -> SchedulerStatus:
    out = subprocess.run(["schtasks", "/Delete", "/TN", TASK_ID, "/F"],
                          capture_output=True, text=True, timeout=15,
                          encoding="utf-8", errors="replace")
    if out.returncode == 0 or "cannot find" in (out.stderr or "").lower() or "no se encuentra" in (out.stderr or "").lower():
        return SchedulerStatus(backend="schtasks", installed=False,
                                detail="Tarea de Windows eliminada (o ya no existía).")
    denied = _classify_permission_error(out.stderr or out.stdout)
    return SchedulerStatus(backend="schtasks", permission_denied=denied,
                            detail=f"No se pudo eliminar la tarea de Windows: {(out.stderr or out.stdout).strip()}")


# ── macOS (launchd user agent) ────────────────────────────────────────────
# Always ~/Library/LaunchAgents (user domain) — never /Library/LaunchDaemons
# (which needs root). Runs while the user is logged in, no sudo required.

def _mac_plist_path() -> Path:
    return Path.home() / "Library" / "LaunchAgents" / f"{LAUNCHD_LABEL}.plist"


def _mac_status(expected_cmd: list[str], interval_minutes: int) -> SchedulerStatus:
    p = _mac_plist_path()
    if not p.exists():
        return SchedulerStatus(backend="launchd", installed=False, command=expected_cmd,
                                detail="Sin LaunchAgent registrado en macOS.")
    try:
        data = plistlib.loads(p.read_bytes())
        args = data.get("ProgramArguments") or []
        matches = (len(args) >= 2 and args[0] == expected_cmd[0] and args[1] == expected_cmd[1]
                   and data.get("StartInterval") == max(60, interval_minutes * 60))
        return SchedulerStatus(backend="launchd", installed=True, healthy=matches, command=expected_cmd,
                                detail=("LaunchAgent registrado y apuntando a la ubicación actual del programa."
                                        if matches else
                                        "LaunchAgent registrado pero apunta a una ubicación anterior — se reparará."))
    except Exception as e:
        return SchedulerStatus(backend="launchd", installed=True, healthy=False, command=expected_cmd,
                                detail=f"LaunchAgent presente pero ilegible ({e!r}) — se reparará.")


def _mac_install(script_dir: Path, python_exe: str, data_dir: Path, interval_minutes: int) -> SchedulerStatus:
    expected_cmd = build_command(script_dir, python_exe)
    p = _mac_plist_path()
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        plist = {
            "Label": LAUNCHD_LABEL,
            "ProgramArguments": list(expected_cmd),
            "StartInterval": max(60, interval_minutes * 60),
            "RunAtLoad": False,
            "StandardOutPath": str(Path(data_dir) / "scheduler_launchd.log"),
            "StandardErrorPath": str(Path(data_dir) / "scheduler_launchd.log"),
        }
        p.write_bytes(plistlib.dumps(plist))
        # Reload: unload (ignore failure if not loaded yet) then load.
        subprocess.run(["launchctl", "unload", str(p)], capture_output=True, text=True, timeout=15)
        out = subprocess.run(["launchctl", "load", str(p)], capture_output=True, text=True, timeout=15)
        if out.returncode == 0:
            return SchedulerStatus(backend="launchd", installed=True, healthy=True, command=expected_cmd,
                                    detail="LaunchAgent registrado en macOS "
                                           f"(cada {interval_minutes} min, mientras la sesión esté iniciada).")
        denied = _classify_permission_error(out.stderr or out.stdout)
        return SchedulerStatus(backend="launchd", permission_denied=denied, command=expected_cmd,
                                detail=f"launchctl load falló: {(out.stderr or out.stdout).strip()}")
    except OSError as e:
        denied = _classify_permission_error(str(e))
        return SchedulerStatus(backend="launchd", permission_denied=True, command=expected_cmd,
                                detail=f"Sin permisos para escribir el LaunchAgent en ~/Library/LaunchAgents: {e!r}")


def _mac_remove() -> SchedulerStatus:
    p = _mac_plist_path()
    try:
        if p.exists():
            subprocess.run(["launchctl", "unload", str(p)], capture_output=True, text=True, timeout=15)
            p.unlink()
        return SchedulerStatus(backend="launchd", installed=False,
                                detail="LaunchAgent eliminado (o ya no existía).")
    except OSError as e:
        return SchedulerStatus(backend="launchd", permission_denied=True,
                                detail=f"No se pudo eliminar el LaunchAgent: {e!r}")


# ── Linux (user crontab) ──────────────────────────────────────────────────
# Always the invoking user's own crontab (`crontab -l` / `crontab -`) —
# never /etc/crontab or a system cron.d entry, so no root is ever needed.
# Our block is delimited by CRON_BEGIN/CRON_END markers so we only ever
# touch lines we ourselves wrote, regardless of whatever else is in the
# user's crontab.

def _cron_read() -> tuple[bool, str]:
    """Returns (ok, current_crontab_text). ok=False means we couldn't read
    it for a reason other than 'simply empty' (e.g. no crontab access)."""
    if shutil.which("crontab") is None:
        return False, ""
    out = subprocess.run(["crontab", "-l"], capture_output=True, text=True, timeout=15,
                          encoding="utf-8", errors="replace")
    if out.returncode == 0:
        return True, out.stdout
    err = (out.stderr or "").lower()
    if "no crontab" in err:  # normal "empty" case, not a permission problem
        return True, ""
    return False, out.stderr or ""


def _cron_extract_block(text: str) -> Optional[str]:
    m = re.search(re.escape(CRON_BEGIN) + r"(.*?)" + re.escape(CRON_END), text, re.S)
    return m.group(0) if m else None


def _cron_strip_block(text: str) -> str:
    return re.sub(re.escape(CRON_BEGIN) + r".*?" + re.escape(CRON_END) + r"\n?", "", text, flags=re.S)


def _linux_status(expected_cmd: list[str], interval_minutes: int) -> SchedulerStatus:
    if shutil.which("crontab") is None:
        return SchedulerStatus(backend="cron", command=expected_cmd,
                                detail="El comando 'crontab' no está disponible en este sistema.")
    ok, text = _cron_read()
    if not ok:
        return SchedulerStatus(backend="cron", permission_denied=True, command=expected_cmd,
                                detail=f"Sin acceso a crontab del usuario: {text.strip()}")
    block = _cron_extract_block(text)
    if not block:
        return SchedulerStatus(backend="cron", installed=False, command=expected_cmd,
                                detail="Sin entrada registrada en el crontab del usuario.")
    expected_line = _cron_line(expected_cmd, interval_minutes, log_path=None, match_only=True)
    matches = expected_line in block
    return SchedulerStatus(backend="cron", installed=True, healthy=matches, command=expected_cmd,
                            detail=("Entrada de crontab registrada y apuntando a la ubicación actual del programa."
                                    if matches else
                                    "Entrada de crontab registrada pero apunta a una ubicación anterior — se reparará."))


def _cron_line(expected_cmd: list[str], interval_minutes: int, log_path: Optional[Path],
                match_only: bool = False) -> str:
    py, runner = expected_cmd[0], expected_cmd[1]
    interval_minutes = max(1, min(59, interval_minutes))
    core = f'*/{interval_minutes} * * * * "{py}" "{runner}" --tick'
    if match_only:
        return core
    redirect = f' >> "{log_path}" 2>&1' if log_path else ""
    return core + redirect


def _linux_install(script_dir: Path, python_exe: str, data_dir: Path, interval_minutes: int) -> SchedulerStatus:
    expected_cmd = build_command(script_dir, python_exe)
    if shutil.which("crontab") is None:
        return SchedulerStatus(backend="cron", command=expected_cmd,
                                detail="El comando 'crontab' no está disponible en este sistema — "
                                       "instálalo o usa la aplicación siempre abierta para programar escaneos.")
    ok, text = _cron_read()
    if not ok:
        return SchedulerStatus(backend="cron", permission_denied=True, command=expected_cmd,
                                detail=f"Sin permiso para usar crontab en esta cuenta: {text.strip()}")
    log_path = Path(data_dir) / "scheduler_cron.log"
    new_line = _cron_line(expected_cmd, interval_minutes, log_path=log_path)
    new_block = f"{CRON_BEGIN}\n{new_line}\n{CRON_END}\n"
    body = _cron_strip_block(text).rstrip("\n")
    new_text = (body + "\n\n" + new_block) if body else new_block
    proc = subprocess.run(["crontab", "-"], input=new_text, capture_output=True, text=True,
                           timeout=15, encoding="utf-8", errors="replace")
    if proc.returncode == 0:
        return SchedulerStatus(backend="cron", installed=True, healthy=True, command=expected_cmd,
                                detail=f"Entrada registrada en el crontab del usuario (cada {interval_minutes} min).")
    denied = _classify_permission_error(proc.stderr or proc.stdout)
    return SchedulerStatus(backend="cron", permission_denied=denied, command=expected_cmd,
                            detail=f"No se pudo escribir el crontab: {(proc.stderr or proc.stdout).strip()}")


def _linux_remove() -> SchedulerStatus:
    if shutil.which("crontab") is None:
        return SchedulerStatus(backend="cron", installed=False, detail="Sin crontab que quitar (no instalado).")
    ok, text = _cron_read()
    if not ok:
        return SchedulerStatus(backend="cron", permission_denied=True,
                                detail=f"Sin permiso para modificar crontab: {text.strip()}")
    if not _cron_extract_block(text):
        return SchedulerStatus(backend="cron", installed=False, detail="No había entrada registrada.")
    new_text = _cron_strip_block(text)
    proc = subprocess.run(["crontab", "-"], input=new_text, capture_output=True, text=True,
                           timeout=15, encoding="utf-8", errors="replace")
    if proc.returncode == 0:
        return SchedulerStatus(backend="cron", installed=False, detail="Entrada de crontab eliminada.")
    denied = _classify_permission_error(proc.stderr or proc.stdout)
    return SchedulerStatus(backend="cron", permission_denied=denied,
                            detail=f"No se pudo quitar la entrada de crontab: {(proc.stderr or proc.stdout).strip()}")


# ── Linux display discovery (best-effort, used by scheduled_runner.py) ────
# cron does not inherit a logged-in desktop session's environment, so
# DISPLAY is normally unset even though a session may be active. This is a
# best-effort discovery only — never a hard requirement — the runner treats
# "no display found" as "skip this tick" rather than an error.

def discover_linux_display() -> Optional[str]:
    if os.environ.get("DISPLAY"):
        return os.environ["DISPLAY"]
    try:
        for sock in sorted(Path("/tmp/.X11-unix").glob("X*")):
            n = sock.name[1:]
            if n.isdigit():
                return f":{n}"
    except Exception:
        pass
    try:
        out = subprocess.run(["who"], capture_output=True, text=True, timeout=5)
        m = re.search(r"\(:(\d+)", out.stdout or "")
        if m:
            return f":{m.group(1)}"
    except Exception:
        pass
    return None


def try_start_xvfb(data_dir: Path, log: Optional[Callable[[str], None]] = None) -> Optional[subprocess.Popen]:
    """Best-effort virtual display for truly headless Linux boxes (no X
    session at all — e.g. a server). Returns the running Xvfb process (with
    DISPLAY already exported into os.environ) or None if Xvfb isn't
    available. Never attempts an elevated/sudo install."""
    xvfb = shutil.which("Xvfb")
    if not xvfb:
        _log(log, "[scheduler-os] Xvfb no está instalado — no se puede simular una pantalla en este servidor.")
        return None
    display = ":97"
    try:
        proc = subprocess.Popen([xvfb, display, "-screen", "0", "1024x768x16"],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as e:
        _log(log, f"[scheduler-os] No se pudo iniciar Xvfb: {e!r}")
        return None
    import time
    time.sleep(1.0)
    if proc.poll() is not None:
        _log(log, "[scheduler-os] Xvfb terminó inesperadamente al iniciar.")
        return None
    os.environ["DISPLAY"] = display
    _log(log, f"[scheduler-os] Xvfb iniciado en pantalla virtual {display}.")
    return proc
