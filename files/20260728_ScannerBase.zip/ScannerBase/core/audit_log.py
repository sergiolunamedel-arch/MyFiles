from __future__ import annotations

import json
import os
import threading
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Optional

_AUDIT_DIRNAME = ".audit"
_REVIEWED_FILENAME = "reviewed.json"
_lock = threading.Lock()

_MESES_ES = ["", "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
             "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]


def _audit_dir(reports_root) -> Path:
    d = Path(reports_root) / _AUDIT_DIRNAME
    d.mkdir(parents=True, exist_ok=True)
    return d


def audit_dir(reports_root) -> Path:
    """Public accessor for the folder where the monthly audit-YYYYMM.jsonl
    files (and the reviewed-mark store) live. Used by the console's
    'Abrir carpeta' action — kept separate from _audit_dir so callers
    outside this module don't reach into a "private" name."""
    return _audit_dir(reports_root)


def _audit_file(reports_root) -> Path:
    return _audit_dir(reports_root) / f"audit-{datetime.now():%Y%m}.jsonl"


def _audit_filename_for(yyyymm_or_filename: str) -> str:
    """Normalizes '202607', 'audit-202607', or 'audit-202607.jsonl' (already
    a filename, e.g. as returned by list_log_files) to the on-disk filename."""
    name = yyyymm_or_filename
    if not name.startswith("audit-"):
        name = f"audit-{name}"
    if not name.endswith(".jsonl"):
        name = f"{name}.jsonl"
    return name


def month_label(yyyymm: str) -> str:
    """'202607' -> 'Julio 2026'. Falls back to the raw string on bad input."""
    try:
        y, m = int(yyyymm[:4]), int(yyyymm[4:6])
        if 1 <= m <= 12:
            return f"{_MESES_ES[m]} {y}"
    except Exception:
        pass
    return yyyymm


def write_event(reports_root, event: str, *, actor: str = "", app: str = "",
                 log: Optional[Callable[[str], None]] = None, **fields: Any) -> None:
    record = {
        "ts": datetime.now().isoformat(timespec="seconds"),
        "event": event,
        "actor": actor or os.environ.get("USERNAME") or os.environ.get("USER") or "",
        "app": app,
        **fields,
    }
    try:
        line = json.dumps(record, default=str)
    except Exception as e:
        if log: log(f"[auditoría] no se pudo serializar el evento {event!r}: {e!r}")
        return
    try:
        with _lock:
            with open(_audit_file(reports_root), "a", encoding="utf-8") as f:
                f.write(line + "\n")
    except Exception as e:
        if log: log(f"[auditoría] no se pudo escribir el evento {event!r}: {e!r}")


# ---------------------------------------------------------------------------
# Listing / reading — powers the console's "Auditoría" view.
# ---------------------------------------------------------------------------

def list_log_files(reports_root) -> list[dict[str, Any]]:
    """One entry per monthly audit-YYYYMM.jsonl file, newest month first.

    Each entry: yyyymm, filename, path, size_bytes, event_count,
    first_ts, last_ts, reviewed (bool, from the persisted reviewed-mark
    store). Corrupt/unreadable files are still listed (with event_count 0)
    rather than raising, so one bad file doesn't hide the rest."""
    d = _audit_dir(reports_root)
    reviewed = _load_reviewed(reports_root)
    out: list[dict[str, Any]] = []
    for p in sorted(d.glob("audit-*.jsonl"), reverse=True):
        yyyymm = p.stem.split("-", 1)[-1]
        count = 0
        first_ts = last_ts = ""
        try:
            with open(p, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    count += 1
                    try:
                        ts = json.loads(line).get("ts", "")
                    except Exception:
                        continue
                    if ts:
                        if not first_ts:
                            first_ts = ts
                        last_ts = ts
        except Exception:
            pass
        try:
            size = p.stat().st_size
        except Exception:
            size = 0
        out.append({
            "yyyymm": yyyymm, "filename": p.name, "path": p,
            "size_bytes": size, "event_count": count,
            "first_ts": first_ts, "last_ts": last_ts,
            "reviewed": bool(reviewed.get(p.name, False)),
        })
    return out


def read_events(reports_root, yyyymm_or_filename: str) -> list[dict[str, Any]]:
    """Parsed events (as dicts) from one monthly file, oldest first.
    Malformed lines are skipped instead of raising. Returns [] if the
    file doesn't exist."""
    p = _audit_dir(reports_root) / _audit_filename_for(yyyymm_or_filename)
    events: list[dict[str, Any]] = []
    if not p.exists():
        return events
    try:
        with open(p, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    events.append(json.loads(line))
                except Exception:
                    continue
    except Exception:
        pass
    events.sort(key=lambda e: e.get("ts", ""))
    return events


# ---------------------------------------------------------------------------
# Deleting.
# ---------------------------------------------------------------------------

def delete_log_file(reports_root, yyyymm_or_filename: str) -> tuple[bool, str]:
    """Permanently deletes one monthly audit-YYYYMM.jsonl file and drops
    its reviewed-mark, if any. Returns (ok, error_message) instead of
    raising, so the caller can show one combined error for a batch."""
    filename = _audit_filename_for(yyyymm_or_filename)
    p = _audit_dir(reports_root) / filename
    try:
        with _lock:
            if p.exists():
                p.unlink()
            _set_reviewed_locked(reports_root, filename, None)
        return True, ""
    except Exception as e:
        return False, repr(e)


# ---------------------------------------------------------------------------
# "Reviewed" mark — persistent, independent of deletion. Stored as its own
# small JSON side-file (reviewed.json) inside the same .audit folder, keyed
# by filename, so it travels with the audit trail itself rather than living
# in the app's settings.json (which is keyed to a specific reports_root and
# unrelated to audit_log's own on-disk format).
# ---------------------------------------------------------------------------

def _reviewed_path(reports_root) -> Path:
    return _audit_dir(reports_root) / _REVIEWED_FILENAME


def _load_reviewed(reports_root) -> dict[str, bool]:
    p = _reviewed_path(reports_root)
    if not p.exists():
        return {}
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        return {str(k): bool(v) for k, v in data.items()} if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_reviewed(reports_root, data: dict[str, bool]) -> None:
    p = _reviewed_path(reports_root)
    try:
        p.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")
    except Exception:
        pass


def _set_reviewed_locked(reports_root, filename: str, value: Optional[bool]) -> None:
    """Caller must already hold _lock. value=None removes the entry
    entirely (used when the underlying log file is deleted, so a later
    file that happens to reuse the same name doesn't inherit a stale mark)."""
    data = _load_reviewed(reports_root)
    if value is None:
        data.pop(filename, None)
    else:
        data[filename] = bool(value)
    _save_reviewed(reports_root, data)


def is_reviewed(reports_root, yyyymm_or_filename: str) -> bool:
    filename = _audit_filename_for(yyyymm_or_filename)
    return bool(_load_reviewed(reports_root).get(filename, False))


def set_reviewed(reports_root, yyyymm_or_filename: str, reviewed: bool) -> None:
    filename = _audit_filename_for(yyyymm_or_filename)
    with _lock:
        _set_reviewed_locked(reports_root, filename, bool(reviewed))
