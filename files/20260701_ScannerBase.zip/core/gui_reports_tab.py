from __future__ import annotations



class _ReportsTabMixin:
    def _build_tab_reports(self, parent):
        self._section_header(parent, '📋  Reportes')
        pad = self._scrollable(parent)

        folder_card = self._card(pad, 'CARPETA DE REPORTES', pady=(0, 14))
        fr = tk.Frame(folder_card, bg=T["panel_bg"]); fr.pack(fill="x")
        self._reports_entry = ttk.Entry(fr, textvariable=self._reports_var)
        self._reports_entry.pack(side="left", fill="x", expand=True, padx=(0, 6))
        def _browse_rep():
            d = filedialog.askdirectory(title="Seleccionar carpeta de reportes",
                                        initialdir=self._reports_var.get() or str(SCRIPT_DIR))
            if d: self._reports_var.set(d); self._reports_root = Path(d)
        self._auto_open_var = tk.BooleanVar(value=self._auto_open)
        def _on_auto_open_change():
            self._auto_open = bool(self._auto_open_var.get()); self._save_settings()
        auto_row = tk.Frame(folder_card, bg=T["panel_bg"]); auto_row.pack(fill="x", pady=(8, 0))
        self._btn(auto_row, '📋 Visor de reportes', lambda: ReportsViewer(self, Path(self._reports_var.get()).resolve()),
                  kind="accent").pack(side="left")
        self._btn(auto_row, "🌐 Abrir HTML", self._open_selected_html_report, kind="accent").pack(side="left", padx=(8, 0))
        self._btn(auto_row, "🩹 Historial de remediación", self._open_remediation_history, kind="flat").pack(side="left", padx=(8, 0))
        self._btn(folder_card, "Explorar…", _browse_rep, kind="flat").pack(side="left", in_=fr)
        ttk.Checkbutton(auto_row, text='Abrir reporte automáticamente',
                        variable=self._auto_open_var, command=_on_auto_open_change).pack(side="left", padx=(14, 0))

        rec_card = self._card(pad, 'ESCANEOS RECIENTES', pady=(0, 0))
        rec_actions = tk.Frame(rec_card, bg=T["panel_bg"]); rec_actions.pack(side="bottom", fill="x", pady=(8, 0))
        self._btn(rec_actions, '🗑 Eliminar seleccionado', self._delete_rep_tree_sel, kind="flat").pack(side="left")
        self._btn(rec_actions, '📁 Abrir carpeta', self._open_rep_tree_sel_folder, kind="flat").pack(side="left", padx=(8, 0))
        self._btn(rec_actions, '📜 Abrir auditoría', self._open_audit_log_folder, kind="flat").pack(side="left", padx=(8, 0))
        search_row = tk.Frame(rec_card, bg=T["panel_bg"]); search_row.pack(fill="x", pady=(0, 8))
        tk.Label(search_row, text="🔎", font=(_FUI, 11), bg=T["panel_bg"], fg=T["muted"]).pack(side="left")
        self._rep_filter_var = tk.StringVar(value="")
        ttk.Entry(search_row, textvariable=self._rep_filter_var, width=36).pack(side="left", padx=(6, 0))
        tk.Label(search_row, text="filtrar por modo o destino", font=(_FUI, 9),
                 bg=T["panel_bg"], fg=T["muted"]).pack(side="left", padx=(8, 0))
        self._rep_filter_var.trace_add("write", lambda *_: self._refresh_rep_tree())
        tree_frame = tk.Frame(rec_card, bg=T["panel_bg"]); tree_frame.pack(fill="both", expand=True)
        cols = ("when","mode","total","crit","high","med","low","target")
        self._rep_tree = _make_tree(tree_frame, cols,
            [("Generado",150),("Modo",80),("Total",55),("Crít",45),("Alto",45),("Med",45),("Bajo",45),("Objetivo",300)], height=6)
        self._rep_tree.bind("<Double-1>", lambda _: self._open_rep_tree_sel())
        self._refresh_rep_tree()

    @staticmethod
    def _list_report_dirs(root: Path, limit: int = 0) -> list[Path]:
        if not root.exists(): return []
        try:
            items = sorted([p for p in root.iterdir() if p.is_dir() and p.name.startswith("report_")],
                           key=lambda p: p.stat().st_mtime, reverse=True)
            return items[:limit] if limit else items
        except OSError: return []

    def _refresh_recent(self):
        if not hasattr(self, "_recent_lb"): return
        self._recent_lb.delete(0, "end")
        root = Path(self._reports_var.get())
        items = self._list_report_dirs(root, limit=6); self._recent_paths = items
        if not items:
            self._recent_lb.insert("end", '(sin reportes — ejecute un escaneo)'); return
        for p in items: self._recent_lb.insert("end", p.name)

    def _refresh_rep_tree(self):
        if not hasattr(self, "_rep_tree"): return
        for iid in self._rep_tree.get_children(): self._rep_tree.delete(iid)
        root = Path(self._reports_var.get())
        active_app = getattr(self, "_active_app", None)
        if active_app and active_app.get("name"):
            _app_slug = _re.sub(r"[^A-Za-z0-9\-_]", "_", active_app["name"].strip())
            scoped_root = root / _app_slug
        else:
            scoped_root = root / "_unscoped"
        filt = getattr(self, "_rep_filter_var", None)
        filt_text = filt.get() if filt is not None else ""
        for d in self._list_report_dirs(scoped_root, limit=50):
            _fill_tree_row(self._rep_tree, d, filter_text=filt_text)

    def _open_audit_log_folder(self):
        import audit_log
        root = Path(self._reports_var.get()).resolve()
        d = audit_log._audit_dir(root)
        if not any(d.glob("audit-*.jsonl")):
            self._show_info_popup("Registro de auditoría",
                f"No hay entradas de auditoría aún para esta carpeta de reportes.\n\n{d}\n\n"
                "Las entradas se registran automáticamente cada vez que un escaneo "
                "inicia, finaliza, falla o se cancela.")
            return
        _open_path(d)

    def _open_rep_tree_sel(self):
        sel = self._rep_tree.selection()
        if not sel: return
        html = _find_report_html(Path(sel[0]))
        if html: _open_path(html)

    def _open_selected_html_report(self):
        sel = self._rep_tree.selection()
        if not sel:
            self._show_warn_popup("Abrir HTML",
                "Seleccione un reporte en la lista primero.")
            return
        d = Path(sel[0])
        html = _find_report_html(d)
        if html:
            _open_path(html)
        else:
            self._show_warn_popup("Abrir HTML", f"Sin archivo HTML en:\n{d}")

    def _open_rep_tree_sel_folder(self):
        _open_selected_report_folder(self, self._rep_tree)

    def _delete_rep_tree_sel(self):
        _delete_selected_report(self, self._rep_tree, self._refresh_rep_tree, self._refresh_recent)

    def _open_remediation_history(self):
        root = Path(self._reports_var.get()).resolve()
        try:
            hist = load_history(root)
            if not hist.get("scans") and not hist.get("actions"):
                self._show_info_popup("Historial de remediación",
                    "Sin historial aún. Ejecute un escaneo primero — cada escaneo se registra y "
                    "se compara con el anterior para rastrear remediaciones.")
                return
            out = render_remediation_history(root)
            self._log_line(f"[historial] {out}")
            _open_path(out)
        except Exception as e:
            self._show_error_popup("Historial de remediación", f"No se pudo generar:\n{e!r}")
