"""
uninstall_scanner_deps.py

Reversa lo que Snyk_Scanner_GUI.py / static_scanner.py instalan automaticamente,
para poder re-probar el instalador (BootSplash) desde cero.

Cubre, en este orden:
  1) Paquetes pip que instala _BOOT_DEPS (Jinja2, selenium, webdriver-manager,
     pynput, PyYAML, requests, MarkupSafe).
  2) El script git-secrets cacheado por ensure_git_secrets() (un solo archivo,
     sin impacto en el sistema -> seguro, va por defecto).
  3) El binario de Snyk CLI: tanto el que descarga _ensure_snyk_cli() en el
     archivo principal, como el que static_scanner.install_snyk() puede dejar
     via npm global / Homebrew / winget / binario standalone.
  4) (opt-in, --include-node) Node.js + npm, instalados por
     static_scanner.install_node() via winget / Homebrew / apt-get / dnf / yum
     / zypper / pacman. Esto es lo mas "pesado": usa el mismo gestor de
     paquetes del sistema, asi que si tenias Node de antes (por nvm, instalador
     oficial, otro proyecto, etc.) tambien se va. Por eso requiere su propia
     confirmacion ademas de la general.

Uso:
    python uninstall_scanner_deps.py                 # pip + git-secrets + snyk, pide confirmacion
    python uninstall_scanner_deps.py -y               # sin confirmacion
    python uninstall_scanner_deps.py --dry-run         # solo muestra los comandos
    python uninstall_scanner_deps.py --include-node    # ademas intenta desinstalar node/npm
    python uninstall_scanner_deps.py --skip-snyk       # no tocar snyk
    python uninstall_scanner_deps.py --skip-git-secrets
"""
from __future__ import annotations

import argparse
import importlib
import os
import platform
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

IS_WIN = os.name == "nt"
IS_MAC = sys.platform == "darwin"
IS_LINUX = not IS_WIN and not IS_MAC

# ── 1) Paquetes pip (igual a _BOOT_DEPS en Snyk_Scanner_GUI.py) ───────────────
BOOT_DEPS = [
    ("jinja2", "Jinja2"),
    ("selenium", "selenium"),
    ("webdriver_manager", "webdriver-manager"),
    ("pynput", "pynput"),
    ("yaml", "PyYAML"),
    ("requests", "requests"),
    ("markupsafe", "MarkupSafe"),  # dependencia transitiva que jinja2 fuerza a reinstalar
]


def is_pip_installed(import_name: str) -> bool:
    try:
        importlib.import_module(import_name)
        return True
    except Exception:
        return False


def run(cmd: list[str], dry_run: bool, check: bool = False) -> int:
    print(f"  $ {' '.join(cmd)}")
    if dry_run:
        return 0
    try:
        r = subprocess.run(cmd, check=check)
        return r.returncode
    except FileNotFoundError:
        print(f"    (no encontrado: {cmd[0]})")
        return 1
    except subprocess.CalledProcessError as e:
        return e.returncode


def uninstall_pip_deps(dry_run: bool) -> None:
    print("\n[1/4] Paquetes pip de _BOOT_DEPS")
    any_found = False
    for import_name, pip_name in BOOT_DEPS:
        if is_pip_installed(import_name):
            any_found = True
            run([sys.executable, "-m", "pip", "uninstall", "-y", pip_name], dry_run)
        else:
            print(f"  - {pip_name}: no instalado, se omite")
    if not any_found:
        print("  (nada que quitar)")


# ── 2) git-secrets cacheado ────────────────────────────────────────────────
def git_secrets_cache_path() -> Path:
    base = Path(os.environ.get("LOCALAPPDATA") or
                os.environ.get("XDG_CACHE_HOME") or
                (Path.home() / ".cache"))
    d = base / "vuln-scanner" / "git-secrets"
    return d / "git-secrets"


def uninstall_git_secrets(dry_run: bool) -> None:
    print("\n[2/4] Script git-secrets cacheado (ensure_git_secrets)")
    p = git_secrets_cache_path()
    if p.exists():
        print(f"  $ rm {p}")
        if not dry_run:
            try:
                p.unlink()
            except Exception as e:
                print(f"    error borrando: {e!r}")
    else:
        print(f"  - {p}: no existe, se omite")


# ── 3) Snyk CLI ────────────────────────────────────────────────────────────
def _which(cmd: str) -> str | None:
    return shutil.which(cmd)


def _brew() -> str | None:
    if p := shutil.which("brew"):
        return p
    for cand in ("/opt/homebrew/bin/brew", "/usr/local/bin/brew"):
        if Path(cand).exists():
            return cand
    return None


def snyk_main_cache_path() -> Path:
    """Ruta usada por _ensure_snyk_cli() en Snyk_Scanner_GUI.py."""
    if IS_WIN:
        return Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local")) / "snyk" / "snyk.exe"
    return Path.home() / ".local" / "bin" / "snyk"


def snyk_standalone_fallback_path() -> Path:
    """Ruta usada por _install_standalone_snyk() en static_scanner.py."""
    if IS_WIN:
        return Path(os.environ.get("LOCALAPPDATA", Path.home())) / "snyk" / "bin" / "snyk.exe"
    return Path.home() / ".local" / "bin" / "snyk"


def uninstall_snyk(dry_run: bool) -> None:
    print("\n[3/4] Snyk CLI")

    # a) binarios cacheados por la app (ambas rutas posibles)
    paths = {snyk_main_cache_path(), snyk_standalone_fallback_path()}
    for p in paths:
        if p.exists():
            print(f"  $ rm {p}")
            if not dry_run:
                try:
                    p.unlink()
                except Exception as e:
                    print(f"    error borrando: {e!r}")
        else:
            print(f"  - {p}: no existe, se omite")

    # b) si quedo instalado via npm global
    npm = "npm.cmd" if IS_WIN else "npm"
    if _which(npm):
        run([npm, "uninstall", "-g", "snyk"], dry_run)

    # c) si quedo instalado via Homebrew (mac)
    if IS_MAC and _brew():
        brew = _brew()
        run([brew, "uninstall", "snyk-cli"], dry_run)
        run([brew, "uninstall", "snyk"], dry_run)

    # d) si quedo instalado via winget (windows)
    if IS_WIN and _which("winget"):
        run(["winget", "uninstall", "--id", "Snyk.SnykCLI", "-e"], dry_run)


# ── 4) Node.js + npm (opt-in, mas invasivo) ───────────────────────────────
def _linux_pkg_mgr_remove() -> tuple[str, list[str]] | None:
    if shutil.which("apt-get"):
        return "apt-get", ["apt-get", "remove", "-y"]
    if shutil.which("dnf"):
        return "dnf", ["dnf", "remove", "-y"]
    if shutil.which("yum"):
        return "yum", ["yum", "remove", "-y"]
    if shutil.which("zypper"):
        return "zypper", ["zypper", "--non-interactive", "remove"]
    if shutil.which("pacman"):
        return "pacman", ["pacman", "-R", "--noconfirm"]
    return None


def _sudo_prefix() -> list[str]:
    if hasattr(os, "geteuid") and os.geteuid() == 0:
        return []
    if shutil.which("sudo"):
        return ["sudo"]
    return []


def uninstall_node(dry_run: bool, yes: bool) -> None:
    print("\n[4/4] Node.js + npm (instalados por static_scanner.install_node)")
    print("  AVISO: esto usa el gestor de paquetes del sistema (winget / brew /")
    print("  apt-get / dnf / yum / zypper / pacman) y borrara cualquier Node.js")
    print("  que este en el PATH ahora, sin importar como se instalo. Si tienes")
    print("  otro proyecto que depende de Node (via nvm, instalador oficial, etc.)")
    print("  tambien se vera afectado.")

    if not _which("node") and not _which("npm"):
        print("  - node/npm no estan en PATH, no hay nada que desinstalar.")
        return

    if not yes and not dry_run:
        resp = input("  ¿Confirmas que quieres desinstalar Node.js/npm del sistema? [s/N]: ").strip().lower()
        if resp not in ("s", "si", "y", "yes"):
            print("  Omitido por el usuario.")
            return

    if IS_WIN:
        if _which("winget"):
            run(["winget", "uninstall", "--id", "OpenJS.NodeJS.LTS", "-e"], dry_run)
        else:
            print("  - winget no disponible; desinstala Node manualmente desde "
                  "Configuracion > Apps, o el instalador original.")
        return

    if IS_MAC:
        brew = _brew()
        if brew:
            run([brew, "uninstall", "node"], dry_run)
        else:
            print("  - Homebrew no encontrado; si instalaste Node de otra forma, "
                  "desinstalalo manualmente.")
        return

    # Linux
    mgr = _linux_pkg_mgr_remove()
    if not mgr:
        print("  - no se encontro un gestor de paquetes soportado; "
              "desinstala nodejs/npm manualmente.")
        return
    name, remove_args = mgr
    sudo = _sudo_prefix()
    run(sudo + remove_args + ["nodejs", "npm"], dry_run)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("-y", "--yes", action="store_true", help="no pedir confirmacion general")
    parser.add_argument("--dry-run", action="store_true", help="mostrar comandos sin ejecutarlos")
    parser.add_argument("--include-node", action="store_true",
                         help="ademas intenta desinstalar Node.js/npm (mas invasivo, pide confirmacion propia)")
    parser.add_argument("--skip-snyk", action="store_true", help="no tocar Snyk CLI")
    parser.add_argument("--skip-git-secrets", action="store_true", help="no tocar el script git-secrets cacheado")
    args = parser.parse_args()

    print("Esto va a revertir lo que el instalador de Snyk_Scanner_GUI.py deja en el sistema.")
    if not args.yes and not args.dry_run:
        resp = input("¿Continuar con pip deps + git-secrets" +
                      ("" if args.skip_snyk else " + Snyk CLI") + "? [s/N]: ").strip().lower()
        if resp not in ("s", "si", "y", "yes"):
            print("Cancelado.")
            return

    uninstall_pip_deps(args.dry_run)

    if not args.skip_git_secrets:
        uninstall_git_secrets(args.dry_run)

    if not args.skip_snyk:
        uninstall_snyk(args.dry_run)

    if args.include_node:
        uninstall_node(args.dry_run, args.yes)
    else:
        print("\n[4/4] Node.js + npm: omitido (usa --include-node si tambien lo quieres probar)")

    print("\nListo. Corre Snyk_Scanner_GUI.py y observa el BootSplash reinstalando todo.")


if __name__ == "__main__":
    main()
