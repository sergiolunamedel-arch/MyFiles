from __future__ import annotations



class _StaticTabMixin:
    def _sev_brand_color(self, sev):
        sev = _sev_norm(sev)
        if sev in ("critical", "high"): return T["err"]     # brand red
        if sev == "medium":             return T["accent"]  # brand gold
        return T["muted"]                                   # low / info

    def _sev_leaf_tag(self, sev):
        sev = _sev_norm(sev)
        if sev in ("critical", "high"): return "crit"
        if sev == "medium":             return "med"
        return "muted"

    def _apply_group_tags(self, tree):
        tree.tag_configure("group", foreground=T["text"], font=(_FUI, 10, "bold"))
        tree.tag_configure("crit",  foreground=T["err"])
        tree.tag_configure("med",   foreground=T["text"])
        tree.tag_configure("muted", foreground=T["muted"])

    def _group_tree(self, parent, tree_col, cols, headings, height):
        """Árbol colapsable de 2 niveles (grupo → hallazgos) con estilo de marca."""
        outer = tk.Frame(parent, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["accent"])
        outer.pack(fill="both", expand=True)
        tk.Frame(outer, bg=T["accent"], height=2).pack(fill="x", side="top")
        tf = tk.Frame(outer, bg=T["panel_bg"]); tf.pack(fill="both", expand=True)
        tree = ttk.Treeview(tf, columns=cols, show="tree headings", height=height)
        tcol_txt, tcol_w = tree_col
        tree.heading("#0", text=tcol_txt, anchor="w"); tree.column("#0", width=tcol_w, stretch=True, anchor="w")
        for c, (txt, w, anchor, stretch) in zip(cols, headings):
            tree.heading(c, text=txt, anchor=anchor); tree.column(c, width=w, anchor=anchor, stretch=stretch)
        tree.pack(side="left", fill="both", expand=True)
        ttk.Scrollbar(tf, command=tree.yview, orient="vertical").pack(side="right", fill="y")
        self._apply_group_tags(tree)
        return tree

    def _tree_empty(self, tree, msg="Sin hallazgos — ejecute un escaneo."):
        for iid in tree.get_children(): tree.delete(iid)
        tree.insert("", "end", text="  " + msg, tags=("muted",))

    def _set_panel_summary(self, lbl, total, worst):
        if lbl is None: return
        if total == 0:
            lbl.config(text="sin hallazgos")
        else:
            lbl.config(text=f"{total} finding{'' if total == 1 else 's'}  ·  worst: {worst.upper()}")

    def _render_sca(self, projects):
        """SCA is about *which dependency to upgrade* — group by package, surface
        the fix version, collapse the individual CVEs underneath."""
        tree = self._static_sca_tree
        for iid in tree.get_children(): tree.delete(iid)
        groups: dict = {}
        for proj in projects or []:
            for i in proj.get("issues", []):
                groups.setdefault(i.get("package", "—"), []).append(i)
        total = 0; worst = "info"
        for pkg in sorted(groups):
            issues = groups[pkg]; total += len(issues)
            gw = "info"; fix = ""
            for i in issues:
                s = _sev_norm(i.get("severity"))
                if _SEV_RANK[s] > _SEV_RANK[gw]: gw = s
                if not fix and i.get("fixedIn") not in (None, "", "—"): fix = str(i.get("fixedIn"))
            if _SEV_RANK[gw] > _SEV_RANK[worst]: worst = gw
            p = tree.insert("", "end", text=f"{pkg}   ({len(issues)})",
                            values=(gw.upper(), ("→ " + fix) if fix else "—"), tags=("group",), open=False)
            for i in issues:
                s = _sev_norm(i.get("severity"))
                fx = i.get("fixedIn"); fx = ("→ " + str(fx)) if fx not in (None, "", "—") else "—"
                tree.insert(p, "end", text="   " + (i.get("title", "") or ""),
                            values=(s.upper(), fx), tags=(self._sev_leaf_tag(s),))
        if total == 0: self._tree_empty(tree)
        self._set_panel_summary(self._sca_summary, total, worst)

    def _render_sast(self, files):
        """SAST is about *where in the code* — group by file (data already is),
        collapse the per-line findings underneath."""
        tree = self._static_sast_tree
        for iid in tree.get_children(): tree.delete(iid)
        total = 0; worst = "info"
        for fobj in files or []:
            issues = fobj.get("issues", [])
            if not issues: continue
            total += len(issues); gw = "info"
            for i in issues:
                s = _sev_norm(i.get("severity"))
                if _SEV_RANK[s] > _SEV_RANK[gw]: gw = s
            if _SEV_RANK[gw] > _SEV_RANK[worst]: worst = gw
            p = tree.insert("", "end", text=f"{fobj.get('file', '—')}   ({len(issues)})",
                            values=(gw.upper(), ""), tags=("group",), open=False)
            for i in issues:
                s = _sev_norm(i.get("severity"))
                tree.insert(p, "end", text="   " + (i.get("title", "") or ""),
                            values=(s.upper(), str(i.get("line", "?"))), tags=(self._sev_leaf_tag(s),))
        if total == 0: self._tree_empty(tree)
        self._set_panel_summary(self._sast_summary, total, worst)

    def _secret_card(self, parent, sev, stype, file, line, redacted):
        card = tk.Frame(parent, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"])
        card.pack(fill="x", pady=(0, 6))
        tk.Frame(card, bg=T["accent"], width=4).pack(side="left", fill="y")
        body = tk.Frame(card, bg=T["panel_bg"], padx=12, pady=8); body.pack(side="left", fill="both", expand=True)
        top = tk.Frame(body, bg=T["panel_bg"]); top.pack(fill="x")
        tk.Label(top, text="🔑", font=(_FUI, 11), bg=T["panel_bg"], fg=T["accent"]).pack(side="left", padx=(0, 6))
        tk.Label(top, text=stype, font=(_FUI, 10, "bold"), bg=T["panel_bg"], fg=T["text"]).pack(side="left")
        tk.Label(top, text=_sev_norm(sev).upper(), font=(_FUI, 9, "bold"),
                 bg=T["panel_bg"], fg=self._sev_brand_color(sev)).pack(side="right")
        self._lbl(body, f"📄 {file}   :   {line}", size=9, fg=T["muted"], anchor="w").pack(fill="x", pady=(2, 0))
        if redacted:
            tk.Label(body, text=redacted, font=(_FMONO, 9), bg=T["surface2"], fg=T["text"],
                     anchor="w", padx=8, pady=3).pack(fill="x", pady=(4, 0))

    def _render_secrets(self, findings):
        box = self._secrets_box
        for w in box.winfo_children(): w.destroy()
        findings = findings or []; worst = "info"
        if not findings:
            self._lbl(box, "Sin secretos — ejecute un escaneo.", size=10, fg=T["muted"], anchor="w").pack(fill="x")
        else:
            for s in findings:
                sev = _sev_norm(s.get("severity"))
                if _SEV_RANK[sev] > _SEV_RANK[worst]: worst = sev
                self._secret_card(box, sev,
                                  s.get("secret_type", s.get("rule", "Secret")) or "Secret",
                                  s.get("file", "—"), s.get("line", "?"), s.get("match", ""))
        self._set_panel_summary(self._secrets_summary, len(findings), worst)

    def _build_tab_static(self, parent):
        self._section_header(parent, "🔍  Análisis estático  (SCA · SAST · Secretos)")
        pad = self._scrollable(parent)

        # ── Top row: target path(s) (left half) + run buttons (right half) ───────
        top_row = tk.Frame(pad, bg=T["bg"]); top_row.pack(fill="x", pady=(0, 8))

        fold = self._side_card(top_row, "OBJETIVO  ·  carpeta(s), archivo(s) o .csproj")
        # Multi-path listbox + scrollbar
        lb_frame = tk.Frame(fold, bg=T["panel_bg"]); lb_frame.pack(fill="x")
        self._static_paths_lb = tk.Listbox(lb_frame, height=4, font=(_FMONO, 9),
                                           bg=T["surface2"], fg=T["text"], selectmode="extended",
                                           highlightthickness=1, highlightbackground=T["border"],
                                           activestyle="none", selectbackground=T["accent"],
                                           selectforeground=T["button_fg"], relief="flat")
        _sb = ttk.Scrollbar(lb_frame, orient="vertical", command=self._static_paths_lb.yview)
        self._static_paths_lb.configure(yscrollcommand=_sb.set)
        self._static_paths_lb.pack(side="left", fill="both", expand=True)
        _sb.pack(side="right", fill="y")

        # Buttons row for path management
        path_btns = tk.Frame(fold, bg=T["panel_bg"]); path_btns.pack(fill="x", pady=(4, 0))

        def _add_folder():
            initial = self._target_var.get() or str(SCRIPT_DIR)
            d = filedialog.askdirectory(title="Agregar carpeta al escaneo", initialdir=initial)
            if d:
                existing = list(self._static_paths_lb.get(0, "end"))
                if d not in existing:
                    self._static_paths_lb.insert("end", d)
                self._target_var.set(d)  # keep _target_var pointing to last selected
                self._persist_static_paths()

        def _add_files():
            initial = self._target_var.get() or str(SCRIPT_DIR)
            files = filedialog.askopenfilenames(
                title="Agregar archivos o .csproj al escaneo",
                initialdir=initial,
                filetypes=[
                    ("Todos los compatibles", "*.csproj *.sln *.json *.py *.js *.ts *.cs *.java *.go *.rb *.php"),
                    ("Proyectos Visual Studio", "*.csproj *.sln"),
                    ("Manifiestos de dependencias", "*.json *.xml *.lock *.toml *.gradle"),
                    ("Código fuente", "*.py *.js *.ts *.cs *.java *.go *.rb *.php *.cpp *.c *.h"),
                    ("Todos los archivos", "*.*"),
                ])
            if files:
                existing = list(self._static_paths_lb.get(0, "end"))
                for f in files:
                    # If it's a .csproj, auto-add the containing folder too
                    p = Path(f)
                    if p.suffix.lower() == ".csproj":
                        folder = str(p.parent)
                        if folder not in existing:
                            self._static_paths_lb.insert("end", folder)
                            existing.append(folder)
                            self._log_line(f"[static] .csproj detected: using folder '{folder}'")
                    else:
                        if f not in existing:
                            self._static_paths_lb.insert("end", f)
                            existing.append(f)
                if files:
                    self._target_var.set(str(Path(files[-1]).parent))
                self._persist_static_paths()

        def _remove_selected():
            # Remove selected items in reverse order to keep indices valid
            sel = list(self._static_paths_lb.curselection())
            for idx in reversed(sel):
                self._static_paths_lb.delete(idx)
            # Update target_var to last remaining
            items = self._static_paths_lb.get(0, "end")
            if items: self._target_var.set(items[-1])
            self._persist_static_paths()

        def _open_add_popup():
            """Popup de agregar objetivos — dos paneles _side_card lado a lado.
            La cabecera y el pie son built manually (same pattern as ReportsViewer)
            to avoid _popup_hdr/_popup_foot calling _hdiv with T["border"], which
            in dark mode is "#ffffff12" — an alpha-channel hex that Tkinter
            rejects as a bg= value.  We strip alpha with _bdr before any Frame."""
            popup = self._create_popup("Agregar objetivos")

            # T["border_bg"] is the Tkinter-safe opaque border (added to both
            # palettes in Snyk_Scanner_GUI.py to fix the #ffffff12 alpha crash).
            _bdr = T["border_bg"]
            hb   = T["panel_bg"]

            # ── Header ────────────────────────────────────────────────────────────────────
            hdr = tk.Frame(popup, bg=hb, padx=30, pady=16); hdr.pack(fill="x")
            row = tk.Frame(hdr, bg=hb); row.pack(fill="x")
            tk.Label(row, text="📂  Agregar objetivos",
                     font=(_FUI, 15, "bold"), bg=hb, fg=T["accent"]).pack(side="left")
            tk.Label(row, text="Seleccione qué incluir en el análisis estático",
                     font=(_FUI, 11, "italic"), bg=hb, fg=T["muted"]).pack(side="left", padx=(12, 0))
            _cfn = getattr(popup, "close", None)
            if _cfn:
                xbtn = tk.Label(row, text="✕", font=(_FUI, 13, "bold"),
                                bg=hb, fg=T["muted"], cursor="hand2", padx=6)
                xbtn.pack(side="right")
                xbtn.bind("<Button-1>", lambda e: _cfn())
                xbtn.bind("<Enter>",    lambda e: xbtn.config(fg=T["err"]))
                xbtn.bind("<Leave>",    lambda e: xbtn.config(fg=T["muted"]))
            tk.Frame(popup, bg=_bdr, height=1).pack(fill="x")

            # ── Body ──────────────────────────────────────────────────────────────────────
            body = tk.Frame(popup, bg=T["bg"], padx=40, pady=30)
            body.pack(fill="both", expand=True)
            cards_row = tk.Frame(body, bg=T["bg"])
            cards_row.pack(fill="both", expand=True)

            # Left card: Add Folder
            fi = self._side_card(cards_row, "📂  AGREGAR CARPETA", padx=(0, 8))
            self._lbl(fi,
                      "Escanea todo el directorio de un proyecto.\n\n"
                      "Snyk analizará recursivamente todos los archivos de manifiesto compatibles "
                      "(package.json, pom.xml, requirements.txt, .csproj…) and "
                      "every source file it finds under the selected folder.",
                      size=10, fg=T["muted"], wraplength=520,
                      justify="left", anchor="nw").pack(fill="x", pady=(0, 16))
            tk.Frame(fi, bg=hb).pack(fill="both", expand=True)
            self._btn(fi, "📂  Explorar carpeta…",
                      lambda: [_add_folder(), popup.close()],
                      kind="accent").pack(fill="x")

            # Right card: Add File(s) / .csproj
            fi2 = self._side_card(cards_row, "📄  AGREGAR ARCHIVO(S) / .CSPROJ", padx=(8, 0))
            self._lbl(fi2,
                      "Escanea archivos específicos o un proyecto de Visual Studio.\n\n"
                      "Elija archivos fuente individuales, archivos de bloqueo o un .csproj / .sln. "
                      "Al seleccionar un .csproj, la carpeta contenedora se incluye automáticamente. "
                      "included so the full build graph is available to Snyk.",
                      size=10, fg=T["muted"], wraplength=520,
                      justify="left", anchor="nw").pack(fill="x", pady=(0, 16))
            tk.Frame(fi2, bg=hb).pack(fill="both", expand=True)
            self._btn(fi2, "📄  Explorar archivo(s)…",
                      lambda: [_add_files(), popup.close()],
                      kind="accent").pack(fill="x")

            # ── Footer ──────────────────────────────────────────────────────────────────
            tk.Frame(popup, bg=_bdr, height=1).pack(fill="x")
            foot = tk.Frame(popup, bg=hb, padx=40, pady=16); foot.pack(fill="x")
            self._btn(foot, "  Cerrar  ", popup.close, "accent").pack(side="right")

        # + opens the add-targets popup; - removes the currently selected entry.
        self._btn(path_btns, "+", _open_add_popup,    kind="outline").pack(side="left", padx=(0, 4))
        self._btn(path_btns, "−", _remove_selected, kind="outline").pack(side="left", padx=(0, 8))
        # Run Static sits immediately to the right.
        self._static_run_btns = []
        run_btn = self._btn(path_btns, "▶  Análisis estático",
                            lambda: self._start_static_scan({"sca", "code", "secrets"}), kind="accent")
        run_btn.pack(side="left")
        self._static_run_btns.append(run_btn)

        # Restore the path list saved on a previous run (clean close), falling
        # back to _target_var (e.g. set by an app profile) when nothing was saved.
        _saved_paths = getattr(self, "_saved_static_paths", None)
        if _saved_paths:
            for p in _saved_paths:
                self._static_paths_lb.insert("end", p)
        elif self._target_var.get():
            self._static_paths_lb.insert("end", self._target_var.get())

        # ── RESULTS — each analysis rendered in the form that suits its data ────
        results_row = tk.Frame(pad, bg=T["bg"]); results_row.pack(fill="x", pady=(0, 8))
        sca_half = tk.Frame(results_row, bg=T["bg"]); sca_half.pack(side="left", fill="both", expand=True, padx=(0, 6))
        sast_half = tk.Frame(results_row, bg=T["bg"]); sast_half.pack(side="left", fill="both", expand=True, padx=(6, 0))

        # SCA → grouped by package (the unit you actually upgrade), fix version surfaced.
        sca_inner, sca_right = self._panel(sca_half, "CÓDIGO ABIERTO (SCA)  ·  por paquete", pady=(0, 0))
        self._sca_summary = tk.Label(sca_right, text="sin hallazgos", font=(_FUI, 9, "bold"),
                                     bg=T["accent"], fg=T["button_fg"]); self._sca_summary.pack(side="right")
        self._static_sca_tree = self._group_tree(
            sca_inner, ("Paquete  /  Vulnerabilidad", 220), ("sev", "fix"),
            [("Severidad", 90, "w", False), ("Corrección disponible", 140, "w", False)], height=7)
        self._tree_empty(self._static_sca_tree)

        # SAST → grouped by file (where the weakness lives), line surfaced on each leaf.
        sast_inner, sast_right = self._panel(sast_half, "CÓDIGO ESTÁTICO (SAST)  ·  por archivo", pady=(0, 0))
        self._sast_summary = tk.Label(sast_right, text="sin hallazgos", font=(_FUI, 9, "bold"),
                                      bg=T["accent"], fg=T["button_fg"]); self._sast_summary.pack(side="right")
        self._static_sast_tree = self._group_tree(
            sast_inner, ("Archivo  /  Hallazgo", 220), ("sev", "line"),
            [("Severidad", 90, "w", False), ("Línea", 70, "center", False)], height=7)
        self._tree_empty(self._static_sast_tree)

        # Secrets → few + urgent: one alert card each, redacted value in monospace.
        sec_inner, sec_right = self._panel(pad, "SECRETOS  ·  credenciales expuestas", pady=(0, 0))
        self._secrets_summary = tk.Label(sec_right, text="sin hallazgos", font=(_FUI, 9, "bold"),
                                         bg=T["accent"], fg=T["button_fg"]); self._secrets_summary.pack(side="right")
        self._secrets_box = tk.Frame(sec_inner, bg=T["panel_bg"]); self._secrets_box.pack(fill="both", expand=True)
        self._lbl(self._secrets_box, "Sin secretos — ejecute un escaneo.", size=10, fg=T["muted"], anchor="w").pack(fill="x")

    def _start_static_scan(self, sel: set):
        if self._static_busy:
            self._log_line("[static] a scan is already running"); return

        # Reflect the static run in the pipeline cards: any of SCA / SAST /
        # Secrets that were de-selected get selected now, so the cards always
        # show what Run Static actually executes (and that becomes the new
        # remembered default).
        changed = False
        for k in ("sca", "code", "secrets"):
            if k in sel:
                var = self._scan_vars.get(k)
                if var is not None and not var.get():
                    var.set(1); changed = True
                apply_fn = getattr(self, "_stage_apply", {}).get(k)
                if apply_fn:
                    try: apply_fn(True)
                    except Exception: pass
        if changed:
            self._refresh_scan_btn(); self._persist_scan_stages()

        # Collect paths from the multi-path listbox
        raw_paths = list(getattr(self, "_static_paths_lb", None) and
                         self._static_paths_lb.get(0, "end") or [])
        # Filter out the placeholder text
        paths = [p for p in raw_paths if p.strip() and not p.strip().startswith("(empty")]
        if not paths:
            # Fallback to _target_var for backward compat (e.g. loaded from app profile)
            tv = self._target_var.get().strip()
            if tv: paths = [tv]
        if not paths:
            self._show_warn_popup("Análisis estático",
                "Sin carpetas ni archivos seleccionados.\n\n"
                "Use '📂 + Carpeta' o '📄 + Archivo(s) / .csproj' para agregar objetivos."); return

        # Validate paths
        valid_paths = []
        for p in paths:
            pp = Path(p).resolve()
            if pp.exists():
                valid_paths.append(pp)
            else:
                self._log_line(f"[static] ⚠ path not found, skipping: {p}")
        if not valid_paths:
            self._show_warn_popup("Análisis estático",
                "Ninguna de las rutas seleccionadas existe en disco.\n\n"
                "Verifique las rutas e intente de nuevo."); return

        # Scan EVERY valid path, not just the first. _static_scan iterates over
        # _static_targets; _target_var is kept only for display/back-compat.
        self._static_targets = valid_paths
        self._target_var.set(str(valid_paths[0]))

        # SCA/SAST need a logged-in Snyk session (the CLI itself is installed at boot).
        if {"sca", "code"} & sel:
            checks = self._checks or {}
            auth_ok = bool(checks.get("auth") and checks["auth"].ok)
            if not auth_ok:
                self._show_warn_popup("Análisis estático",
                    "SCA y SAST requieren una sesión SSO activa en Snyk.\n\n"
                    "Vaya a la pestaña ▶ Ejecutar escaneo → Prerrequisitos y haga clic en '🔑 Iniciar sesión SSO'.")
                return
        self._static_run_sel = sel
        for b in getattr(self, "_static_run_btns", []):
            b.config(state="disabled")
        if hasattr(self, "_static_count_lbl"):
            self._static_count_lbl.config(text="Escaneando… (" + " + ".join(sorted(sel)).upper() + ")")
        self._run_async(self._static_scan, label="static analysis",
                        busy_attr="_static_busy", done_kind="__static_done__")

    @staticmethod
    def _dir_has_files(p) -> bool:
        """True if the target contains at least one regular file (recursive),
        or is itself a file. Used to flag empty folders so SCA/Secrets don't
        report a misleading 'completed / 0 findings'. On any error we return
        True so we never block a real scan over a probe failure."""
        try:
            p = Path(p)
            if p.is_file():
                return True
            for child in p.rglob("*"):
                if child.is_file():
                    return True
        except Exception:
            return True
        return False

    def _static_scan(self):
        """Iterate EVERY queued target (multi-folder). Each folder gets its own
        report; empty/inexistent folders are flagged and skipped so they never
        produce a false 'completed'."""
        self._static_cancel_evt.clear()
        sel = getattr(self, "_static_run_sel", {"sca", "code", "secrets"})
        targets = getattr(self, "_static_targets", None)
        if not targets:
            tv = self._target_var.get().strip()
            targets = [tv] if tv else []
        targets = [Path(x).resolve() for x in targets]
        if not targets:
            self._emit_log("[static] sin objetivos — nada que escanear")
            self._event_queue.put(("static_results", None)); return

        scanned = 0
        for i, t in enumerate(targets, 1):
            if self._static_cancel_evt.is_set():
                self._emit_log("[static] cancelado — objetivos restantes omitidos")
                break
            if not t.exists():
                self._emit_log(f"[static] ⚠ ruta inexistente, se omite: {t}")
                continue
            if not self._dir_has_files(t):
                self._emit_log(f"[static] ⚠ objetivo vacío (sin archivos), se omite: {t}")
                continue
            self._emit_log(f"[static] === objetivo {i}/{len(targets)}: {t} ===")
            self._static_scan_one(t, sel)
            scanned += 1

        if scanned == 0:
            self._emit_log("[static] ningún objetivo escaneable "
                           "(todas las carpetas vacías o inexistentes)")
            self._event_queue.put(("static_results", None))

    def _static_scan_one(self, target, sel):
        """Run the selected folder-based analyses (SCA / SAST / Secrets) for a
        SINGLE target through the unified report pipeline. Each target produces
        its own report directory and report."""
        target = Path(target).resolve()
        reports_root = Path(self._reports_var.get()).resolve(); reports_root.mkdir(parents=True, exist_ok=True)
        active_app = getattr(self, "_active_app", None)
        _report_label, app_reports_root = self._scoped_report_paths(reports_root)
        mode = "+".join(sorted(sel))
        out_dir = app_reports_root / f"report_{_ts()}_{mode}"; out_dir.mkdir(parents=True, exist_ok=True)
        self._session_begin("static", set(sel))   # crash-recovery marker
        import audit_log
        audit_log.write_event(reports_root, "scan_start", actor=self._user,
                              app=(active_app.get("name") if active_app else ""),
                              mode=mode, target=str(target), out_dir=str(out_dir), lane="static",
                              log=self._emit_log)
        self._emit_log(f"[static] pipeline: {mode.upper()}")
        self._emit_log(f"[static] output → {out_dir}")
        _snyk_usable = True
        if {"sca", "code"} & sel:
            try:
                if not ensure_snyk_ready(self._emit_log):
                    _snyk_usable = False
                    self._emit_log("[static] Snyk CLI is not runnable — "
                                   "skipping SCA/SAST. Click Fix to repair it.")
            except Exception as e:
                self._emit_log(f"[static] snyk readiness check error: {e!r}")
        try: v = _run(["snyk", "--version"]).stdout.strip()
        except Exception: v = "?"

        results: dict[str, Any] = {"sca": None, "code": None, "dast": None, "api": None, "secrets": None}
        for k in ("sca", "code", "secrets"):
            running = k in sel and (_snyk_usable or k == "secrets")
            self._event_queue.put(("stage", (k, "running" if running else "skipped")))

        jobs: list[tuple[str, Callable[[], None]]] = []
        if "sca" in sel and _snyk_usable:
            jobs.append(("sca", lambda: results.__setitem__(
                "sca", run_snyk_test(target, out_dir, self._emit_log)[0])))
        if "code" in sel and _snyk_usable:
            jobs.append(("code", lambda: results.__setitem__(
                "code", run_snyk_code(target, out_dir, self._emit_log)[0])))
        if "secrets" in sel:
            def _run_secrets_stage():
                self._emit_log("[secrets] running secret scan…")
                result = scan_path(target, self._emit_log, cancel=self._static_cancel_evt,
                                   git_secrets_status=get_git_secrets_status())
                sec_dir = out_dir / "secrets"
                write_secrets_report(result, sec_dir)
                self._emit_log(f"[secrets] {result['total']} finding(s) across "
                               f"{result['scanned_files']} file(s)")
                results["secrets"] = result
            jobs.append(("secrets", _run_secrets_stage))

        def run_stage(item):
            key, fn = item
            try:
                fn(); self._event_queue.put(("stage", (key, "done")))
            except Exception as e:
                self._event_queue.put(("stage", (key, "failed")))
                self._emit_log(f"[static] {key} failed: {e!r}")
                if getattr(e, "is_auth", False):
                    self._event_queue.put(("auth_required", None))

        try:
            if len(jobs) > 1:
                self._emit_log(f"[static] running {len(jobs)} analyses concurrently")
                with ThreadPoolExecutor(max_workers=len(jobs)) as ex_:
                    list(ex_.map(run_stage, jobs))
            else:
                for j in jobs: run_stage(j)

            # Persist each completed kind so later cumulative reports stay complete.
            state = self._scan_state
            for kind in ("sca", "code", "secrets"):
                raw = results.get(kind)
                if raw is not None:
                    try:
                        state.save_kind(kind, raw, target=str(target), snyk_version=v, mode=mode)
                        self._emit_log(f"[state] {kind} result persisted")
                    except Exception as e:
                        self._emit_log(f"[state] could not save {kind}: {e!r}")

            ctx = build_cumulative_context(state, target_hint=target,
                                           snyk_version_hint=v, current_results=results)
            ctx["scan_mode"] = mode
            self._emit_log("[report] building cumulative report (all scan types merged)")
            _base = _report_basename(self._user, mode)
            report_html = render_html(ctx, out_dir, filename=f"{_base}.html")
            self._emit_log(f"[report] HTML → {report_html}")
            try:
                csv_path = export_csv(ctx, out_dir / f"{_base}.csv", report_label=_report_label)
                self._emit_log(f"[report] CSV bundle (ZIP): {csv_path}")
            except Exception as e:
                self._emit_log(f"[report] CSV export skipped: {e!r}")
            sec_html_src = out_dir / "secrets" / "secrets.html"
            if sec_html_src.exists():
                try:
                    sec_html_dst = out_dir / f"{_base}_secrets.html"
                    shutil.copyfile(sec_html_src, sec_html_dst)
                    self._emit_log(f"[report] Secrets HTML → {sec_html_dst}")
                except Exception as e:
                    self._emit_log(f"[report] secrets HTML copy skipped: {e!r}")
            try:
                sarif_path = export_sarif(out_dir)
                if sarif_path: self._emit_log(f"[report] SARIF: {sarif_path}")
            except Exception as e:
                self._emit_log(f"[report] SARIF export skipped: {e!r}")
            try:
                merged_path = export_merged_json(out_dir)
                if merged_path: self._emit_log(f"[report] merged JSON: {merged_path}")
            except Exception as e:
                self._emit_log(f"[report] merged JSON skipped: {e!r}")

            meta = {
                "generated_at": ctx["generated_at"], "target": ctx["target"], "mode": mode,
                "counts": ctx["counts"], "total": ctx["total"],
                "sca_total": ctx.get("sca_total", 0), "code_total": ctx.get("code_total", 0),
                "dast_total": ctx.get("dast_total", 0), "api_total": ctx.get("api_total", 0),
                "secrets_total": ctx.get("secrets_total", 0), "snyk_version": ctx.get("snyk_version", ""),
            }
            (out_dir / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
            try:
                rec = update_history_after_scan(reports_root, ctx, meta,
                                                actor=getattr(self, "_user", ""), report_dir=out_dir)
                self._emit_log(f"[history] recorded — remediated {rec.get('remediated_count', 0)}, "
                               f"new {rec.get('introduced_count', 0)}")
            except Exception as e:
                self._emit_log(f"[history] could not update: {e!r}")
            if active_app and active_app.get("id"):
                try:
                    self._inv_store.record_scan(active_app["id"], meta)
                    self._event_queue.put(("inv_refresh", active_app["id"]))
                except Exception as e:
                    self._emit_log(f"[inventory] could not update: {e!r}")

            self._last_context = ctx; self._last_report_dir = out_dir
            self._last_static_report = Path(report_html)
            audit_log.write_event(reports_root, "scan_end", actor=self._user,
                                  app=(active_app.get("name") if active_app else ""),
                                  mode=mode, total=ctx.get("total", 0), counts=ctx.get("counts", {}),
                                  report=str(report_html), lane="static",
                                  cancelled=self._static_cancel_evt.is_set(), log=self._emit_log)
            self._event_queue.put(("static_results", ctx))
            self._event_queue.put(("report", str(report_html)))
        except Exception as e:
            self._emit_log(f"[static] scan failed: {e!r}")
            audit_log.write_event(reports_root, "scan_failed", actor=self._user,
                                  app=(active_app.get("name") if active_app else ""),
                                  mode=mode, lane="static", error=repr(e), log=self._emit_log)
            self._event_queue.put(("static_results", None))
        finally:
            # Whether it finished or errored gracefully, the run is over — clear
            # the crash-recovery marker (it only survives a hard kill/close).
            self._session_end("static")
