"""probely_orchestrator.py — slot-pool orchestrator for Snyk API & Web (Probely).

Probely does NOT bill per user; it bills per *target* (and scan time). The top
plan caps the account at a fixed number of LIVE targets (5 by default). The
bottleneck is therefore "how many target slots are alive at once", not how many
scans you run. This module decides how to spend those slots so an on-demand scan
of a NEW url can run even when the pool is already full:

    pick a slot that
        (a) has NO active scan  (all of its scans are in a terminal state), and
        (b) was NOT created within the last `cooldown_minutes` (default 60),
    delete that target, and let the caller create the new one in its place.

Everything is done over the REST API via the existing ``_Probely`` client in
``snyk_dast_api`` — this module adds no new transport. It is intentionally
Tk-free so it can be unit-tested and reused head-less.

WHY A LOCAL LEDGER FOR "created_at"
-----------------------------------
Probely's target/site object exposes ``changed`` (last-modified, ISO-8601 UTC)
but no public ``created`` field, and ``changed`` is bumped by every PATCH — and
this app PATCHes a freshly-created target several times (login, blacklist,
logout detectors). So for targets THIS APP created, ``changed`` is useless as an
age signal. Since the app is the only thing creating targets in this workflow,
we keep an authoritative creation ledger on disk and consult it first. Order of
precedence for a target's age:

    1. local ledger ``created_at``         (authoritative for app-created targets)
    2. the API ``changed`` timestamp       (fine for foreign/pre-existing targets)
    3. ledger ``first_seen``               (recorded the first time we observe a
                                            target with neither of the above)

SCAN-STATE SEMANTICS (deliberately stricter than the engine's _TERMINAL)
------------------------------------------------------------------------
``snyk_dast_api._TERMINAL`` treats ``under_review`` as terminal because that's
the right place to *stop polling* a scan. For deciding whether a SLOT is free to
be recycled we must NOT delete a target that is paused or under review, so this
module uses its own state sets: a slot is free only when every one of its scans
is in ``TERMINAL_STATES`` (or it has no scans). Unknown states are treated as
busy (conservative — never delete on ambiguity).
"""

from __future__ import annotations

import json
import threading
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Optional

try:
    # Reuse the real client + error type. Import lazily-friendly names.
    from snyk_dast_api import _Probely, ProbelyError, _resolve_api_base  # type: ignore
except Exception:  # pragma: no cover - allows standalone import for tests
    _Probely = object       # type: ignore
    _resolve_api_base = None  # type: ignore

    class ProbelyError(Exception):  # type: ignore
        def __init__(self, message: str, *, status: int = 0, is_auth: bool = False):
            super().__init__(message)
            self.status = status
            self.is_auth = is_auth


# A slot is FREE only when every scan on it is in one of these states.
TERMINAL_STATES = {
    "completed", "completed_with_errors", "failed", "canceled", "cancelled",
}
# Anything here (or any unrecognised state) keeps the slot BUSY. Note that
# `paused` and `under_review` are intentionally busy here.
BUSY_STATES = {
    "queued", "started", "resuming", "pausing", "finishing_up", "under_review",
    "canceling", "cancelling", "paused", "over",
}

_DEFAULT_POOL_SIZE = 5
_DEFAULT_COOLDOWN_MIN = 60.0
_LEDGER_DIRNAME = ".orchestrator"
_LEDGER_FILENAME = "pool_ledger.json"

# One re-entrant lock per Probely account (keyed by API base URL), so the DAST
# and API pipeline stages — which run concurrently — can't both grab the last
# free slot. Guarded by a meta-lock during creation of the per-account lock.
_ACCOUNT_LOCKS: dict[str, threading.RLock] = {}
_ACCOUNT_LOCKS_META = threading.Lock()


def _account_lock(key: str) -> threading.RLock:
    with _ACCOUNT_LOCKS_META:
        lk = _ACCOUNT_LOCKS.get(key)
        if lk is None:
            lk = threading.RLock()
            _ACCOUNT_LOCKS[key] = lk
        return lk


def _now_utc() -> datetime:
    return datetime.now(timezone.utc)


def _parse_iso(value) -> Optional[datetime]:
    """Tolerant ISO-8601 parser (handles a trailing 'Z' and fractional seconds
    on Python versions where fromisoformat doesn't). Returns an aware UTC
    datetime, or None."""
    if not value or not isinstance(value, str):
        return None
    s = value.strip()
    if not s:
        return None
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(s)
    except ValueError:
        # Last resort: truncate over-long fractional seconds (….8208302 → ….820830)
        try:
            head, _, tail = s.partition(".")
            digits = ""
            rest = ""
            for ch in tail:
                if ch.isdigit() and len(digits) < 6:
                    digits += ch
                elif ch.isdigit():
                    continue
                else:
                    rest += ch
            dt = datetime.fromisoformat(f"{head}.{digits or '0'}{rest}")
        except Exception:
            return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def _target_changed(target: dict) -> Optional[datetime]:
    """Best-effort read of the API-provided last-change timestamp."""
    if not isinstance(target, dict):
        return None
    site = target.get("site") or {}
    for src in (target.get("changed"), site.get("changed"),
                target.get("last_scan", {}).get("started") if isinstance(target.get("last_scan"), dict) else None):
        dt = _parse_iso(src)
        if dt:
            return dt
    return None


def _target_url(target: dict) -> str:
    site = target.get("site") or {}
    return (site.get("url") or target.get("url") or "").rstrip("/")


def _target_type(target: dict) -> str:
    return (target.get("type") or "single") or "single"


class PoolLedger:
    """Tiny JSON ledger of {target_id: {created_at, source, url, type}}.

    Stored under ``<root>/.orchestrator/pool_ledger.json``. Thread-safe; tolerant
    of a missing/corrupt file (treated as empty)."""

    def __init__(self, root):
        self._dir = Path(root) / _LEDGER_DIRNAME
        self._path = self._dir / _LEDGER_FILENAME
        self._lock = threading.Lock()

    # — low level —
    def _read(self) -> dict:
        try:
            return json.loads(self._path.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def _write(self, data: dict) -> None:
        try:
            self._dir.mkdir(parents=True, exist_ok=True)
            self._path.write_text(json.dumps(data, indent=2, default=str),
                                  encoding="utf-8")
        except Exception:
            pass

    # — public —
    def get(self, target_id: str) -> Optional[dict]:
        with self._lock:
            return self._read().get(target_id)

    def record_created(self, target_id: str, *, url: str = "", ttype: str = "",
                       when: Optional[datetime] = None) -> None:
        when = when or _now_utc()
        with self._lock:
            data = self._read()
            data[target_id] = {"created_at": when.isoformat(), "source": "created",
                               "url": url, "type": ttype}
            self._write(data)

    def record_first_seen(self, target_id: str, *, url: str = "", ttype: str = "",
                          when: Optional[datetime] = None) -> datetime:
        when = when or _now_utc()
        with self._lock:
            data = self._read()
            existing = data.get(target_id)
            if existing and existing.get("created_at"):
                dt = _parse_iso(existing["created_at"])
                if dt:
                    return dt
            data[target_id] = {"created_at": when.isoformat(), "source": "first_seen",
                               "url": url, "type": ttype}
            self._write(data)
            return when

    def forget(self, target_id: str) -> None:
        with self._lock:
            data = self._read()
            if target_id in data:
                data.pop(target_id, None)
                self._write(data)

    def created_at(self, target_id: str) -> tuple[Optional[datetime], str]:
        rec = self.get(target_id)
        if rec and rec.get("created_at"):
            return _parse_iso(rec["created_at"]), (rec.get("source") or "ledger")
        return None, ""


@dataclass
class SlotInfo:
    target_id: str
    name: str
    url: str
    ttype: str
    scan_states: list[str] = field(default_factory=list)
    free: bool = False
    created_at: Optional[datetime] = None
    age_source: str = ""
    age_minutes: Optional[float] = None
    eligible: bool = False
    reason: str = ""

    @property
    def age_human(self) -> str:
        if self.age_minutes is None:
            return "?"
        m = self.age_minutes
        if m < 1:
            return "<1 min"
        if m < 90:
            return f"{int(round(m))} min"
        return f"{m / 60:.1f} h"

    @property
    def state_human(self) -> str:
        if not self.scan_states:
            return "sin escaneos"
        return ", ".join(self.scan_states[:4]) + (" …" if len(self.scan_states) > 4 else "")


class SlotUnavailable(ProbelyError):
    """Raised when the pool is full and no slot can be recycled right now."""


class Orchestrator:
    def __init__(self, client, ledger: PoolLedger, *,
                 pool_size: int = _DEFAULT_POOL_SIZE,
                 cooldown_minutes: float = _DEFAULT_COOLDOWN_MIN,
                 account_key: str = "",
                 log: Callable[[str], None] = lambda *_: None):
        self.client = client
        self.ledger = ledger
        self.pool_size = max(1, int(pool_size or _DEFAULT_POOL_SIZE))
        self.cooldown = max(0.0, float(cooldown_minutes if cooldown_minutes is not None
                                       else _DEFAULT_COOLDOWN_MIN))
        self._account_key = account_key or getattr(client, "_base", "probely")
        self.log = log

    # — concurrency —
    @contextmanager
    def account_lock(self):
        lk = _account_lock(self._account_key)
        lk.acquire()
        try:
            yield
        finally:
            lk.release()

    # — scan state —
    def scan_states(self, target_id: str) -> list[str]:
        try:
            scans = self.client.list_scans_for_target(target_id)
        except ProbelyError as e:
            self.log(f"[orchestrator] could not list scans for {target_id}: {e}")
            # Unknown → treat as busy (don't recycle on ambiguity).
            return ["unknown"]
        states = []
        for s in scans or []:
            st = (s.get("status") or s.get("state") or "").strip().lower()
            states.append(st or "unknown")
        return states

    @staticmethod
    def is_free(states: list[str]) -> bool:
        if not states:
            return True
        return all(st in TERMINAL_STATES for st in states)

    # — age —
    def created_at(self, target: dict) -> tuple[Optional[datetime], str]:
        tid = target.get("id") or ""
        dt, src = self.ledger.created_at(tid)
        if dt:
            return dt, src
        dt = _target_changed(target)
        if dt:
            return dt, "changed"
        # Nothing on file and nothing from the API → stamp first-seen so future
        # passes have a real age, and use that.
        seen = self.ledger.record_first_seen(
            tid, url=_target_url(target), ttype=_target_type(target))
        return seen, "first_seen"

    # — survey —
    def survey(self) -> list[SlotInfo]:
        targets = self.client.list_targets()
        now = _now_utc()
        out: list[SlotInfo] = []
        for t in targets or []:
            tid = t.get("id") or ""
            site = t.get("site") or {}
            states = self.scan_states(tid)
            free = self.is_free(states)
            created, src = self.created_at(t)
            age_min = ((now - created).total_seconds() / 60.0) if created else None
            if not free:
                eligible, reason = False, "escaneo activo"
            elif age_min is not None and age_min < self.cooldown:
                eligible, reason = False, f"enfriamiento ({self.cooldown - age_min:.0f} min restantes)"
            else:
                eligible, reason = True, "reciclable"
            out.append(SlotInfo(
                target_id=tid, name=(site.get("name") or t.get("name") or tid),
                url=_target_url(t), ttype=_target_type(t), scan_states=states,
                free=free, created_at=created, age_source=src, age_minutes=age_min,
                eligible=eligible, reason=reason))
        return out

    # — pick —
    def pick_recyclable(self, survey: list[SlotInfo], *,
                        exclude_url: str = "", protect_ids=()) -> Optional[SlotInfo]:
        prot = {i for i in (protect_ids or ()) if i}
        want = (exclude_url or "").rstrip("/")
        cands = [s for s in survey if s.eligible and s.target_id not in prot]
        # Prefer recycling a DIFFERENT url than the one we're about to create,
        # and among those the OLDEST (most stale) slot.
        preferred = [s for s in cands if s.url != want] or cands
        preferred.sort(key=lambda s: (s.age_minutes if s.age_minutes is not None else 1e9),
                       reverse=True)
        return preferred[0] if preferred else None

    # — free —
    def free_slot(self, slot: SlotInfo) -> None:
        self.log(f"[orchestrator] reciclando slot {slot.target_id} "
                 f"({slot.url or slot.name}; edad={slot.age_human}, fuente={slot.age_source}) "
                 f"→ DELETE")
        self.client.delete_target(slot.target_id)
        self.ledger.forget(slot.target_id)

    # — capacity (the main entry point used by _ensure_target) —
    def ensure_capacity(self, new_url: str, new_type: str,
                        protect_ids=()) -> Optional[SlotInfo]:
        """Make sure there's room for one more target. If the pool is below
        capacity, returns None (nothing to do). If it's full, recycles an
        eligible slot and returns the SlotInfo that was freed. Raises
        SlotUnavailable when the pool is full and nothing can be recycled.

        ``protect_ids`` are target ids that must NEVER be recycled (e.g. a target
        the user pinned via 'reuse by ID'). Freshly-created targets are already
        protected implicitly by the cooldown (their age is ~0)."""
        prot = {i for i in (protect_ids or ()) if i}
        survey = self.survey()
        if prot:
            for s in survey:
                if s.target_id in prot and s.eligible:
                    s.eligible = False
                    s.reason = "fijado (reuse por ID)"
        live = len(survey)
        self.log(f"[orchestrator] pool: {live}/{self.pool_size} targets vivos "
                 f"({sum(1 for s in survey if s.free)} libres, "
                 f"{sum(1 for s in survey if s.eligible)} reciclables).")
        if live < self.pool_size:
            return None
        slot = self.pick_recyclable(survey, exclude_url=new_url, protect_ids=prot)
        if slot is None:
            raise SlotUnavailable(self._no_slot_message(survey))
        self.free_slot(slot)
        return slot

    def _no_slot_message(self, survey: list[SlotInfo]) -> str:
        busy = [s for s in survey if not s.free]
        cooling = [s for s in survey if s.free and not s.eligible]
        lines = [f"Pool de Probely lleno ({len(survey)}/{self.pool_size}) y ningún "
                 "slot es reciclable ahora mismo:"]
        for s in survey:
            lines.append(f"  • {s.url or s.name}: {s.state_human}; "
                         f"edad={s.age_human}; {s.reason}")
        if cooling and not busy:
            soonest = min((self.cooldown - (s.age_minutes or 0)) for s in cooling)
            lines.append(f"El próximo slot se libera del enfriamiento en ~{soonest:.0f} min. "
                         "Baje el enfriamiento o espere, y reintente.")
        elif busy:
            lines.append("Hay escaneos activos. Espere a que terminen (o cancélelos) "
                         "y reintente.")
        return "\n".join(lines)

    # — register —
    def register_created(self, target: dict, *, url: str = "", ttype: str = "") -> None:
        tid = target.get("id") or ""
        if not tid:
            return
        self.ledger.record_created(
            tid, url=url or _target_url(target), ttype=ttype or _target_type(target))
        self.log(f"[orchestrator] target {tid} registrado en el ledger "
                 f"(created_at=ahora).")


def make_orchestrator(client, cfg, log: Callable[[str], None]) -> Optional[Orchestrator]:
    """Build an Orchestrator from a DastConfig/ApiConfig, or None if disabled.

    The ledger root comes from ``cfg.probely_ledger_path`` (the GUI passes the
    reports root); falls back to the current directory."""
    if not getattr(cfg, "probely_orchestrate", True):
        return None
    root = (getattr(cfg, "probely_ledger_path", "") or ".").strip() or "."
    ledger = PoolLedger(root)
    return Orchestrator(
        client, ledger,
        pool_size=int(getattr(cfg, "probely_pool_size", _DEFAULT_POOL_SIZE) or _DEFAULT_POOL_SIZE),
        cooldown_minutes=float(getattr(cfg, "probely_slot_cooldown_minutes", _DEFAULT_COOLDOWN_MIN)
                               or _DEFAULT_COOLDOWN_MIN),
        account_key=getattr(client, "_base", ""),
        log=log)
