from __future__ import annotations


class _DastTabMixin:
    _CRED_KEYS = [
        "username", "password", "token", "cookie", "header_name", "header_value",
        "login_url", "login_data", "selenium_login_url", "selenium_user_selector",
        "selenium_user_value", "selenium_pass_selector", "selenium_pass_value",
        "selenium_submit_selector", "selenium_extra_steps", "selenium_macro",
        "login_success_text", "logout_url_re",
        "selenium_logout_macro",
        "probely_form_login_check_pattern",
        "probely_check_session_url",
        "probely_logout_markers",
    ]
    _DAST_AUTH_FIELDS = {
        "none":     [],
        "basic":    [("username", "Usuario", False), ("password", "Contraseña", True)],
        "bearer":   [("token", "Token Bearer", True)],
        "cookie":   [("cookie", "Valor de cabecera Cookie", False)],
        "header":   [("header_name", "Nombre de cabecera", False), ("header_value", "Valor de cabecera", True)],
        "form":     [("login_url", "URL de la página de login", False),
                     ("login_data", "Campos del formulario (campo=valor&…)", False),
                     ("probely_form_login_check_pattern",
                      "Patrón de verificación de login (regex/texto)", False)],
        "selenium": [("selenium_login_url", "URL de página de login", False),
                     ("selenium_user_selector", "Selector CSS de usuario", False),
                     ("selenium_user_value", "Valor de usuario", False),
                     ("selenium_pass_selector", "Selector CSS de contraseña", False),
                     ("selenium_pass_value", "Valor de contraseña", True),
                     ("selenium_submit_selector", "Selector CSS de enviar", False),
                     ("selenium_extra_steps", "Pasos adicionales JSON", False)],
    }
    _SESSION_FIELDS = [
        ("login_success_text",        "Texto visible SOLO con sesión activa"),
        ("probely_check_session_url", "URL de verificación de sesión (opcional)"),
        ("probely_logout_markers",    "Marcadores de 'sesión cerrada' (uno por línea/coma)"),
        ("logout_url_re",             "Regex de URL de logout (excluir del rastreo)"),
    ]
    _LOGIN_CONDITION_KEYS = [
        "selenium_login_url", "selenium_user_selector", "selenium_user_value",
        "selenium_pass_selector", "selenium_submit_selector", "selenium_extra_steps",
        "selenium_macro", "login_success_text",
    ]
    _LOGOUT_CONDITION_KEYS = ["logout_url_re",
                              "login_success_text", "selenium_logout_macro"]
    _SECRET_KEYS = {"password", "token", "cookie", "header_value",
                    "selenium_pass_value", "login_data"}

    def _build_tab_dast(self, parent):
        self._section_header(parent, '🌐  Pruebas de seguridad dinámicas (DAST)')
        pad = self._scrollable(parent)
        self._safety_banner(pad,
            "Asegúrate de que la URL apunte a un entorno que NO sea de producción.")
        body = self._card(pad, 'OBJETIVO & PERFIL'); body.columnconfigure(1, weight=1)
        self._dast_objetivo_card = body
        def gl(text, r, c): return self._glabel(body, text, r, c)
        gl('URL del objetivo', 0, 0); self._gentry(body, self._dast_url_var, 0, 1, span=3)
        gl('Tipo de autenticación', 1, 0)
        ac = ttk.Combobox(body, textvariable=self._dast_auth_var,
                          values=["none","basic","bearer","cookie","header","form","selenium"],
                          state="readonly", width=12)
        ac.grid(row=1, column=1, sticky="w", pady=3)
        def _on_dast_auth_change(_evt=None): self._refresh_dast_creds(); self._refresh_dast_sel_card()
        ac.bind("<<ComboboxSelected>>", _on_dast_auth_change)
        gl('Perfil de escaneo', 2, 0)
        pc = ttk.Combobox(body, textvariable=self._dast_profile_var,
                          values=["(predeterminado)","lightning","safe","normal","full"],
                          state="readonly", width=14)
        pc.grid(row=2, column=1, sticky="w", pady=3, padx=(0, 4))
        self._dast_profile_cb = pc
        self._btn(body, "↻", lambda: self._refresh_scan_profiles("web"),
                  kind="flat").grid(row=2, column=2, sticky="w", pady=3)
        self._dast_cred_frame = tk.Frame(body, bg=T["panel_bg"])
        self._dast_cred_frame.grid(row=3, column=0, columnspan=4, sticky="ew", pady=(4, 0))
        self._dast_cred_frame.columnconfigure(1, weight=1)
        scope = tk.Frame(body, bg=T["panel_bg"]); scope.grid(row=4, column=0, columnspan=4, sticky="ew", pady=(8, 0))
        ttk.Checkbutton(scope, text="Detectar logout y re-loguear",
                        variable=self._dast_relogin_var).pack(side="left", padx=(0, 14))
        self._lbl(scope, "El alcance, el perfil y la sesión del escaneo en la nube se "
                  "configuran abajo en la tarjeta PROBELY (NUBE).", size=9, fg=T["muted"]
                  ).pack(side="left", padx=(4, 0))
        sel_card = self._card(pad, 'GRABAR LOGIN EN NAVEGADOR  →  SECUENCIA PROBELY  (auth = selenium)', pady=(0, 14)); sel_card.columnconfigure(1, weight=1)
        self._lbl(sel_card, 'Navegador', size=10, fg=T["muted"]).grid(row=1, column=0, sticky="e", padx=(0, 6))
        labels = self._refresh_browser_catalog()
        sel_browser_cb = ttk.Combobox(sel_card, textvariable=self._dast_browser_label_var,
                                      values=labels, state="readonly", width=18)
        sel_browser_cb.grid(row=1, column=1, sticky="w")
        def _on_browser_pick(_=None):
            key = self._browser_label_key.get(self._dast_browser_label_var.get())
            if key: self._dast_browser_var.set(key)
        sel_browser_cb.bind("<<ComboboxSelected>>", _on_browser_pick)
        sel_opts = tk.Frame(sel_card, bg=T["panel_bg"]); sel_opts.grid(row=2, column=0, columnspan=4, sticky="ew", pady=(4, 0))
        self._spin(sel_opts, 'Tiempo de espera de login (s)', self._dast_selwait_var, 1, 180, width=5, padx=(0, 16))
        macro_row = tk.Frame(sel_card, bg=T["panel_bg"]); macro_row.grid(row=3, column=0, columnspan=4, sticky="ew", pady=(8, 0))
        self._dast_macro_row = macro_row
        tk.Frame(macro_row, bg=T["border"], height=1).pack(fill="x", pady=(0, 8))
        self._lbl(macro_row, "MACROS", size=9, fg=T["muted"], bold=True).pack(anchor="w")
        macro_btns = tk.Frame(macro_row, bg=T["panel_bg"]); macro_btns.pack(fill="x", pady=(4, 0))
        self._macro_recorded = {"login": False, "logout": False}
        self._macro_check_vars = {"login": tk.StringVar(value=""), "logout": tk.StringVar(value="")}

        def _refresh_macro_ui():
            for flag, var in self._macro_check_vars.items():
                var.set("  ✔" if self._macro_recorded[flag] else "")
            lo_btn = getattr(self, "_macro_logout_btn", None)
            if lo_btn: lo_btn.config(state="normal" if self._macro_recorded["login"] else "disabled")

        def _macro_popup(flag, title, icon, desc, record_fn, save_fn, load_fn, rec_tip, save_tip, load_tip):
            popup = self._create_popup(title)
            self._popup_hdr(popup, title, icon=icon)
            body2 = tk.Frame(popup, bg=T["bg"]); body2.pack(fill="both", expand=True)
            tk.Frame(body2, bg=T["bg"]).pack(fill="both", expand=True)
            recorded_now = self._macro_recorded[flag]
            badge_var = tk.StringVar(value="✔  Recorded" if recorded_now else "⬜  Not recorded")
            badge_fg = T["ok"] if recorded_now else T["muted"]
            stat_frame = tk.Frame(body2, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"])
            stat_frame.pack(fill="x", padx=60)
            stat_inner = tk.Frame(stat_frame, bg=T["panel_bg"], padx=28, pady=14); stat_inner.pack(fill="x")
            badge_lbl = tk.Label(stat_inner, textvariable=badge_var, font=(_FUI, 16, "bold"), bg=T["panel_bg"], fg=badge_fg)
            badge_lbl.pack(side="left")
            tk.Label(stat_inner, text=desc, font=(_FUI, 11), bg=T["panel_bg"], fg=T["muted"],
                     justify="left", wraplength=900).pack(side="left", padx=(28, 0))
            card_row = tk.Frame(body2, bg=T["bg"]); card_row.pack(padx=60, pady=28)
            tk.Frame(body2, bg=T["bg"]).pack(fill="both", expand=True)

            def _do_record():
                popup.close(); ok = record_fn()
                if ok:
                    self._macro_recorded[flag] = True; _refresh_macro_ui()

            def _do_load():
                popup.close(); load_fn()
                check_key = "selenium_login_url" if flag == "login" else "logout_url_re"
                if self._dast_cred_vars.get(check_key, tk.StringVar()).get().strip():
                    self._macro_recorded[flag] = True; _refresh_macro_ui()

            def _do_clear():
                _CLEAR_KEYS = {
                    "login":  ["selenium_login_url","selenium_user_selector","selenium_user_value",
                               "selenium_pass_selector","selenium_pass_value","selenium_submit_selector",
                               "selenium_extra_steps","selenium_macro","login_success_text"],
                    "logout": ["logout_url_re","login_success_text"],
                }
                for k in _CLEAR_KEYS.get(flag, []):
                    if k in self._dast_cred_vars: self._dast_cred_vars[k].set("")
                self._macro_recorded[flag] = True
                self._macro_recorded[flag] = False
                if flag == "login":
                    for k in _CLEAR_KEYS["logout"]:
                        if k in self._dast_cred_vars: self._dast_cred_vars[k].set("")
                    self._macro_recorded["logout"] = False
                _refresh_macro_ui(); self._refresh_dast_creds()
                badge_var.set("⬜  Not recorded"); badge_lbl.config(fg=T["muted"]); popup.close()

            _actions = [
                ("⏺", "Grabar nueva", rec_tip, _do_record, True, "accent"),
                ("💾", "Guardar…", save_tip, lambda: (popup.close(), save_fn()), recorded_now, "outline"),
                ("📂", "Cargar…", load_tip, _do_load, True, "outline"),
                ("🗑", "Limpiar", f"Restablecer la condición {flag} y limpiar todos los selectores guardados.",
                 _do_clear, recorded_now, "flat"),
            ]
            for ico, lbl, tip, cmd, enabled, _kind in _actions:
                card = self._choice_card(card_row, ico, lbl, tip, enabled=enabled, icon_size=32,
                                         title_size=13, desc_size=9, desc_wrap=170, ipadx=18, ipady=12,
                                         padx=10, icon_pady=(16, 6), desc_pady=(4, 16))
                if enabled:
                    def _mk(c=cmd):
                        def _fn(e=None): c()
                        return _fn
                    fn = _mk(); card.bind("<Button-1>", fn)
                    for child in card.winfo_children(): child.bind("<Button-1>", fn)
                    card.bind("<Enter>", lambda e, c=card: c.configure(highlightbackground=T["accent"]))
                    card.bind("<Leave>", lambda e, c=card: c.configure(highlightbackground=T["border"]))
            self._popup_foot(popup, ("  Cerrar  ", popup.close, "flat"))

        login_wrap = tk.Frame(macro_btns, bg=T["panel_bg"]); login_wrap.pack(side="left", padx=(0, 4))
        login_args = ("login", "Macro de inicio de sesión", "⏺",
                      "Grabe una macro nueva, o guarde/cargue una grabada previamente.",
                      self._dast_record_macro, self._dast_save_login_condition, self._dast_load_login_condition,
                      "Abre un navegador real y registra clics de inicio de sesión y campos de formulario.",
                      "Guarda los selectores de login grabados + campos de detección de sesión.\nLas contraseñas nunca se escriben en disco.",
                      "Carga un archivo de condición de login guardado anteriormente.")
        login_btn = self._btn(login_wrap, "⏺  Grabar login → secuencia Probely", lambda a=login_args: _macro_popup(*a), kind="outline")
        login_btn.pack(side="left")
        tk.Label(login_wrap, textvariable=self._macro_check_vars["login"], font=(_FUI, 11, "bold"),
                 bg=T["panel_bg"], fg=T["ok"]).pack(side="left")
        logout_wrap = tk.Frame(macro_btns, bg=T["panel_bg"]); logout_wrap.pack(side="left", padx=(4, 0))
        logout_args = ("logout", "Exclusión / marcadores de logout", "🚪",
                       "Grabe la acción de logout para EXCLUIRLA del rastreo (Probely no la visitará), "
                       "o configure marcadores de 'sesión cerrada' a mano.",
                       self._dast_record_logout, self._dast_save_logout_condition, self._dast_load_logout_condition,
                       "Abre un navegador, reproduce su login y registra la URL de logout para excluirla.",
                       "Guarda el regex de URL de logout + marcadores de sesión cerrada.",
                       "Carga un archivo de condición de logout guardado.")
        logout_btn = self._btn(logout_wrap, "🚪  Exclusión de logout (opcional)", lambda a=logout_args: _macro_popup(*a), kind="outline")
        logout_btn.pack(side="left"); logout_btn.config(state="disabled")
        tk.Label(logout_wrap, textvariable=self._macro_check_vars["logout"], font=(_FUI, 11, "bold"),
                 bg=T["panel_bg"], fg=T["ok"]).pack(side="left")
        self._macro_logout_btn = logout_btn
        self._dast_sel_card = sel_card
        self._build_dast_probely_card(pad)
        self._build_dast_orchestrator_card(pad)
        self._build_dast_2fa_card(pad)
        self._refresh_dast_creds(); self._refresh_dast_sel_card()
        self._setup_dast_field_persistence()

    def _build_dast_probely_card(self, pad):
        """All Snyk API & Web (Probely) cloud-scan options that the engine honours
        but the legacy local-scanner UI never exposed."""
        REPORTS = ["(ninguno)", "owasp", "owasp_web_2021", "owasp_web_2025",
                   "pci", "pci4", "pci_v3_2_1", "pci_v4_0_1",
                   "iso27001", "hipaa", "executive_summary"]
        c = self._card(pad, 'PROBELY (NUBE) — ALCANCE, PERFIL Y SESIÓN', pady=(0, 14))
        c.columnconfigure(1, weight=1); c.columnconfigure(3, weight=1)
        # La clave de API de Probely se pega UNA sola vez con el icono 🌐 de la barra
        # superior (cuenta de servicio, compartida por DAST y API). No se repite aquí.
        # El endpoint del servicio (api.probely.com) ya no se expone: es fijo salvo
        # override avanzado, que se conserva en la config (_dast_apibase_var).
        self._lbl(c, "La clave de API de Probely se configura con el icono 🌐 de la barra superior.",
                  size=9, fg=T["muted"]).grid(row=0, column=0, columnspan=4, sticky="w", pady=(0, 6))
        def L(t, r, col=0): self._lbl(c, t, size=10, fg=T["muted"], anchor="e").grid(
            row=r, column=col, sticky="e", padx=(0, 6), pady=2)
        L('Reutilizar target por ID', 2)
        ttk.Entry(c, textvariable=self._dast_target_id_var).grid(row=2, column=1, sticky="ew", pady=2)
        rr = tk.Frame(c, bg=T["panel_bg"]); rr.grid(row=2, column=2, columnspan=2, sticky="w", pady=2)
        ttk.Checkbutton(rr, text="Reutilizar por URL", variable=self._dast_reuse_url_var).pack(side="left", padx=(8, 12))
        self._spin(rr, 'Espera máx. (min)', self._dast_maxwait_var, 5, 1440, width=6)
        self._spin(rr, 'Sondeo (s)', self._dast_poll_var, 5, 120, width=5, padx=(12, 0))
        L('Alcance reducido (URLs, una por línea/coma)', 3)
        ttk.Entry(c, textvariable=self._dast_reduced_scopes_var).grid(row=3, column=1, columnspan=3, sticky="ew", pady=2)
        L('Lista negra (globs de URL a excluir)', 4)
        ttk.Entry(c, textvariable=self._dast_blacklist_var).grid(row=4, column=1, columnspan=3, sticky="ew", pady=2)
        L('Secuencia de login (archivo del Probely Recorder)', 6)
        sf = tk.Frame(c, bg=T["panel_bg"]); sf.grid(row=6, column=1, columnspan=3, sticky="ew", pady=2)
        sf.columnconfigure(0, weight=1)
        ttk.Entry(sf, textvariable=self._dast_seq_path_var).grid(row=0, column=0, sticky="ew")
        self._btn(sf, 'Explorar…', self._dast_browse_sequence, kind="flat").grid(row=0, column=1, padx=(4, 0))
        tg = tk.Frame(c, bg=T["panel_bg"]); tg.grid(row=7, column=0, columnspan=4, sticky="ew", pady=(6, 0))
        ttk.Checkbutton(tg, text="Ignorar blackout", variable=self._dast_ignore_blackout_var).pack(side="left", padx=(0, 12))
        ttk.Checkbutton(tg, text="Proteger sesión (no fuzzear token)", variable=self._dast_protect_session_var).pack(side="left", padx=(0, 12))
        ttk.Checkbutton(tg, text="Avisar si el host no es público", variable=self._dast_agent_warn_var).pack(side="left", padx=(0, 12))
        ttk.Checkbutton(tg, text="Exigir dominio verificado", variable=self._dast_require_verified_var).pack(side="left", padx=(0, 12))
        tg2 = tk.Frame(c, bg=T["panel_bg"]); tg2.grid(row=8, column=0, columnspan=4, sticky="ew", pady=(2, 0))
        self._lbl(tg2, 'Reporte de cumplimiento', size=10, fg=T["muted"]).pack(side="left", padx=(0, 4))
        ttk.Combobox(tg2, textvariable=self._dast_report_var, values=REPORTS, state="readonly", width=18).pack(side="left", padx=(0, 16))
        self._lbl(tg2, 'Login de formulario', size=10, fg=T["muted"]).pack(side="left", padx=(0, 4))
        ttk.Combobox(tg2, textvariable=self._dast_form_login_var, values=["auto", "on", "off"], state="readonly", width=8).pack(side="left")
        sep = tk.Frame(c, bg=T["border"], height=1); sep.grid(row=9, column=0, columnspan=4, sticky="ew", pady=8)
        self._lbl(c, "DETECCIÓN DE LOGOUT (PROBELY)", size=9, fg=T["muted"], bold=True).grid(
            row=10, column=0, columnspan=4, sticky="w")
        ld = tk.Frame(c, bg=T["panel_bg"]); ld.grid(row=11, column=0, columnspan=4, sticky="ew", pady=(2, 0))
        self._lbl(ld, 'Condición', size=10, fg=T["muted"]).pack(side="left", padx=(0, 4))
        ttk.Combobox(ld, textvariable=self._dast_logout_cond_var, values=["any", "all"], state="readonly", width=6).pack(side="left", padx=(0, 12))
        ttk.Checkbutton(ld, text="Detector por URL de login", variable=self._dast_logout_url_det_var).pack(side="left", padx=(0, 12))
        ttk.Checkbutton(ld, text="Detector por código 401/403", variable=self._dast_logout_code_det_var).pack(side="left", padx=(0, 12))
        L('Selector CSS visible al estar deslogueado', 12)
        ttk.Entry(c, textvariable=self._dast_logout_selector_var).grid(row=12, column=1, columnspan=3, sticky="ew", pady=2)
        L('Marcadores en el cuerpo (body)', 13)
        ttk.Entry(c, textvariable=self._dast_logout_body_var).grid(row=13, column=1, columnspan=3, sticky="ew", pady=2)
        L('Marcadores en cabecera (Nombre: valor)', 14)
        ttk.Entry(c, textvariable=self._dast_logout_header_var).grid(row=14, column=1, columnspan=3, sticky="ew", pady=2)

    # ── Slot-pool orchestrator ────────────────────────────────────────────────
    _ORCH_TREE_COLS = ("target", "type", "url", "scans", "age", "elig")

    def _build_dast_orchestrator_card(self, pad):
        """Pool orchestration. The Probely licence caps the account at 5 LIVE
        targets (billed per target, not per user). Web and API targets share that
        single pool of 5. When a scan needs a NEW url and the pool is full, the app
        AUTOMATICALLY frees the OLDEST slot that has no active scan and was created
        more than <cooldown> minutes ago, then recreates it — all at scan time and
        only when full. This panel is read-only (status view); there is no manual
        'free' button on purpose, so a user can't drain the whole pool by hand."""
        c = self._card(pad, 'ORQUESTADOR DE SLOTS (POOL DE 5 TARGETS PROBELY)', pady=(0, 14))
        self._lbl(c, "La cuenta tiene 5 targets por licencia (Web y API comparten el mismo "
                  "pool). Al escanear una URL nueva con el pool lleno, se recicla automáticamente "
                  "el slot MÁS ANTIGUO sin escaneo activo y fuera del enfriamiento; si ninguno "
                  "califica, el escaneo se detiene con un aviso. El reciclado ocurre solo al "
                  "escanear: aquí únicamente puede consultar el estado.", size=9,
                  fg=T["muted"]).pack(anchor="w", pady=(0, 8))

        opts = tk.Frame(c, bg=T["panel_bg"]); opts.pack(fill="x", pady=(0, 8))
        ttk.Checkbutton(opts, text="Orquestar el pool automáticamente al escanear",
                        variable=self._dast_orch_var).pack(side="left", padx=(0, 14))
        self._spin(opts, 'Enfriamiento por slot (min)', self._dast_cooldown_var, 0, 1440, width=6)

        actions = tk.Frame(c, bg=T["panel_bg"]); actions.pack(fill="x", pady=(0, 6))
        self._btn(actions, '🔄  Actualizar estado del pool', self._refresh_pool_status,
                  kind="accent").pack(side="left")
        self._dast_orch_status_var = tk.StringVar(value="Pulse «Actualizar estado del pool».")
        tk.Label(c, textvariable=self._dast_orch_status_var, font=(_FUI, 9),
                 bg=T["panel_bg"], fg=T["muted"], anchor="w", justify="left",
                 wraplength=900).pack(fill="x", pady=(0, 6))

        tree_frame = tk.Frame(c, bg=T["panel_bg"]); tree_frame.pack(fill="both", expand=True)
        self._dast_orch_tree = _make_tree(
            tree_frame, self._ORCH_TREE_COLS,
            [("Target", 110), ("Tipo", 60), ("URL", 300), ("Escaneos", 200),
             ("Edad", 80), ("Reciclable", 150)], height=6)

    def _orch_build_client(self):
        """Return (client, orchestrator, cfg) for the current Probely settings, or
        (None, None, cfg) if no key is configured. Safe to call from a worker."""
        from snyk_dast_api import _Probely, _resolve_api_base
        from probely_orchestrator import Orchestrator, PoolLedger
        cfg = self._collect_dast_cfg()
        token = (getattr(cfg, "probely_token", "") or "").strip()
        if not token:
            return None, None, cfg
        client = _Probely(token, _resolve_api_base(cfg), self._emit_log,
                          getattr(cfg, "probely_auth_scheme", "JWT"))
        orch = Orchestrator(
            client, PoolLedger(getattr(cfg, "probely_ledger_path", ".") or "."),
            pool_size=int(getattr(cfg, "probely_pool_size", 5) or 5),
            cooldown_minutes=float(getattr(cfg, "probely_slot_cooldown_minutes", 60) or 60),
            log=self._emit_log)
        return client, orch, cfg

    # The pool is a SINGLE account-wide resource (5 targets, Web + API share it),
    # so refreshing from either tab queries it once and renders into BOTH the DAST
    # and API status cards. `which` only marks who triggered it (for logging/labels).
    def _orch_status_vars(self):
        return [v for v in (getattr(self, "_dast_orch_status_var", None),
                            getattr(self, "_api_orch_status_var", None)) if v is not None]

    def _orch_trees(self):
        return [t for t in (getattr(self, "_dast_orch_tree", None),
                            getattr(self, "_api_orch_tree", None)) if t is not None]

    def _set_orch_status(self, text: str):
        for v in self._orch_status_vars():
            try: v.set(text)
            except Exception: pass

    def _refresh_pool_status(self, which: str = "web"):
        if getattr(self, "_orch_busy", False):
            return
        client, orch, _ = self._orch_build_client()
        if orch is None:
            self._set_orch_status(
                "Sin clave de Probely — pulse 🌐 en la barra superior para pegarla.")
            self._show_warn_popup("Orquestador de slots",
                "No hay clave de API de Probely configurada. Péguela con el icono 🌐 "
                "de la barra superior y reintente.")
            return
        self._set_orch_status("Consultando el pool en Probely…")
        def _work():
            survey = orch.survey()
            pool = orch.pool_size
            self.after(0, lambda: self._render_pool(survey, pool))
        self._run_async(_work, label="estado del pool",
                        busy_attr="_orch_busy", done_kind="__orch_done__")

    def _render_pool(self, survey, pool_size):
        trees = self._orch_trees()
        if not trees:
            return
        for tree in trees:
            for iid in tree.get_children():
                tree.delete(iid)
            for s in survey:
                tree.insert("", "end", iid=s.target_id, values=(
                    s.target_id, ("API" if s.ttype == "api" else "Web"),
                    s.url or s.name, s.state_human, s.age_human,
                    ("✓ sí" if s.eligible else f"✗ {s.reason}")))
        live = len(survey)
        free = sum(1 for s in survey if s.free)
        elig = sum(1 for s in survey if s.eligible)
        web = sum(1 for s in survey if s.ttype != "api")
        api = sum(1 for s in survey if s.ttype == "api")
        self._set_orch_status(
            f"Pool: {live}/{pool_size} targets vivos ({web} Web · {api} API) · "
            f"{free} sin escaneo activo · {elig} reciclables ahora. "
            + ("Hay capacidad libre." if live < pool_size
               else ("Lleno, pero un slot puede reciclarse." if elig
                     else "Lleno y sin slots reciclables (escaneos activos o en enfriamiento).")))

    def _free_slot_now(self):
        # Removed by design: freeing is automatic at scan time (and only when the
        # pool is full), so the user can't drain the whole pool manually.
        raise AttributeError("manual slot freeing is disabled by design")

    def _build_dast_2fa_card(self, pad):
        """TOTP-based 2FA — only relevant on top of form/sequence login. Shown for
        auth_type form/selenium; otherwise collapsed."""
        outer = self._card(pad, '2FA / TOTP (encima del login)', pady=(0, 14))
        outer.columnconfigure(1, weight=1); outer.columnconfigure(3, weight=1)
        self._dast_2fa_card = outer
        ttk.Checkbutton(outer, text="El objetivo requiere 2FA (TOTP)",
                        variable=self._dast_2fa_var).grid(row=0, column=0, columnspan=4, sticky="w", pady=(0, 4))
        def L(t, r, col=0): self._lbl(outer, t, size=10, fg=T["muted"], anchor="e").grid(
            row=r, column=col, sticky="e", padx=(0, 6), pady=2)
        L('Seed / secreto', 1)
        ttk.Entry(outer, textvariable=self._dast_otp_secret_var, show="*").grid(row=1, column=1, columnspan=3, sticky="ew", pady=2)
        L('Selector CSS del campo OTP', 2)
        ttk.Entry(outer, textvariable=self._dast_otp_field_var).grid(row=2, column=1, sticky="ew", pady=2)
        L('Selector CSS de enviar', 2, 2)
        ttk.Entry(outer, textvariable=self._dast_otp_submit_var).grid(row=2, column=3, sticky="ew", pady=2)
        L('Algoritmo', 3)
        ttk.Combobox(outer, textvariable=self._dast_otp_alg_var, values=["SHA1", "SHA256", "SHA512"],
                     state="readonly", width=10).grid(row=3, column=1, sticky="w", pady=2)
        L('Dígitos', 3, 2)
        _dg = tk.Frame(outer, bg=T["panel_bg"]); _dg.grid(row=3, column=3, sticky="w", pady=2)
        self._spin(_dg, '', self._dast_otp_digits_var, 4, 10, width=4)

    def _dast_browse_sequence(self):
        p = filedialog.askopenfilename(title="Secuencia de login de Probely",
            filetypes=[("Secuencia Probely (JSON)", "*.json"), ("Todos", "*.*")])
        if p: self._dast_seq_path_var.set(p)

    def _refresh_scan_profiles(self, which: str):
        """Fetch the REAL scan profiles for this account from Probely and load
        them into the dropdown (DAST=web, API=api). Falls back silently to the
        static list on any error. Shared by the DAST and API tabs."""
        import types as _types
        if which == "api":
            apibase = self._api_apibase_var.get(); ttype = "api"
        else:
            apibase = self._dast_apibase_var.get(); ttype = "web"
        region = "us"
        cfg = _types.SimpleNamespace(
            probely_token=static_scanner.get_probely_key(),
            probely_auth_scheme=static_scanner.get_probely_auth_scheme(),
            probely_api_base=(apibase or "").strip(),
            probely_region=region)
        def _work():
            profs = fetch_scan_profiles(cfg, ttype, self._emit_log)
            self._event_queue.put(("scan_profiles", (which, profs)))
        self._run_async(_work, label="perfiles de escaneo")

    def _refresh_creds(self, frame, auth_var, cred_vars, *, session_fields=False):
        for w in frame.winfo_children(): w.destroy()
        frame.columnconfigure(1, weight=1)
        kind = auth_var.get()
        base = 0
        fields = [f for f in self._DAST_AUTH_FIELDS.get(kind, []) if f[0] in cred_vars]
        for i, (key, label, secret) in enumerate(fields):
            r = base + i
            self._lbl(frame, label, size=10, fg=T["muted"], anchor="e").grid(row=r, column=0, sticky="e", padx=(0, 6), pady=2)
            ttk.Entry(frame, textvariable=cred_vars[key], show="*" if secret else "").grid(row=r, column=1, sticky="ew", pady=2)
        if session_fields:
            r0 = base + len(fields)
            tk.Frame(frame, bg=T["border"], height=1).grid(row=r0, column=0, columnspan=2, sticky="ew", pady=6); r0 += 1
            self._lbl(frame, "DETECCIÓN DE LOGOUT (Probely)", size=9, fg=T["muted"], bold=True).grid(row=r0, column=0, columnspan=2, sticky="w"); r0 += 1
            for key, label in self._SESSION_FIELDS:
                self._lbl(frame, label, size=10, fg=T["muted"], anchor="e").grid(row=r0, column=0, sticky="e", padx=(0, 6), pady=2)
                ttk.Entry(frame, textvariable=cred_vars[key]).grid(row=r0, column=1, sticky="ew", pady=2); r0 += 1

    def _refresh_dast_creds(self):
        self._refresh_creds(self._dast_cred_frame, self._dast_auth_var, self._dast_cred_vars, session_fields=True)

    def _refresh_dast_sel_card(self):
        kind = self._dast_auth_var.get()
        show = kind == "selenium"
        outer = self._dast_sel_card.master
        if show:
            anchor = getattr(self, "_dast_objetivo_card", None)
            if anchor is not None:
                outer.pack(fill="x", pady=(0, 14), after=anchor.master)
            else:
                outer.pack(fill="x", pady=(0, 14))
        else:
            outer.pack_forget()
        mrow = getattr(self, "_dast_macro_row", None)
        if mrow is not None:
            if kind == "selenium": mrow.grid()
            else:                  mrow.grid_remove()
        card2fa = getattr(self, "_dast_2fa_card", None)
        if card2fa is not None:
            o2 = card2fa.master
            if kind in ("form", "selenium"): o2.pack(fill="x", pady=(0, 14))
            else:                            o2.pack_forget()

    def _collect_dast_cfg(self) -> DastConfig:
        v = self._dast_cred_vars; g = lambda k: v[k].get()
        browser_key = self._dast_browser_var.get() or "chrome"
        browser_bin = (self._browser_catalog.get(browser_key, {}) or {}).get("binary", "")
        def _opt(s):
            s = (s or "").strip()
            return "" if s in ("(predeterminado)", "(ninguno)", "") else s
        return DastConfig(
            url=self._dast_url_var.get().strip(), auth_type=self._dast_auth_var.get(),
            username=g("username"), password=g("password"), token=g("token"),
            cookie=g("cookie"), header_name=g("header_name"), header_value=g("header_value"),
            login_url=g("login_url"), login_data=g("login_data"), profile=self._dast_profile_var.get(),
            selenium_browser=browser_key,
            selenium_binary=browser_bin, selenium_headless=bool(self._dast_headless_var.get()),
            selenium_wait_seconds=int(self._dast_selwait_var.get() or 15),
            selenium_login_url=g("selenium_login_url"), selenium_user_selector=g("selenium_user_selector"),
            selenium_user_value=g("selenium_user_value"), selenium_pass_selector=g("selenium_pass_selector"),
            selenium_pass_value=g("selenium_pass_value"), selenium_submit_selector=g("selenium_submit_selector"),
            selenium_extra_steps=g("selenium_extra_steps"), selenium_macro=g("selenium_macro"),
            selenium_logout_macro=g("selenium_logout_macro"),
            login_success_text=g("login_success_text"), logout_url_re=g("logout_url_re"),
            auto_relogin=bool(self._dast_relogin_var.get()),
            probely_token=static_scanner.get_probely_key(),
            probely_auth_scheme=static_scanner.get_probely_auth_scheme(),
            probely_region="us",
            probely_api_base=(self._dast_apibase_var.get().strip() or "https://api.probely.com"),
            probely_target_id=self._dast_target_id_var.get().strip(),
            probely_reuse_by_url=bool(self._dast_reuse_url_var.get()),
            probely_scan_profile=_opt(self._dast_profile_var.get()),
            probely_max_wait_minutes=float(self._dast_maxwait_var.get() or 180),
            probely_poll_interval=float(self._dast_poll_var.get() or 15),
            probely_require_verified=bool(self._dast_require_verified_var.get()),
            probely_reduced_scopes=self._dast_reduced_scopes_var.get(),
            probely_extra_hosts="",
            probely_blacklist=self._dast_blacklist_var.get(),
            probely_ignore_blackout=bool(self._dast_ignore_blackout_var.get()),
            probely_compliance_report=_opt(self._dast_report_var.get()),
            probely_protect_session=bool(self._dast_protect_session_var.get()),
            probely_agent_warn=bool(self._dast_agent_warn_var.get()),
            probely_login_sequence_path=self._dast_seq_path_var.get().strip(),
            probely_form_login=(self._dast_form_login_var.get() or "auto"),
            probely_logout_detection=bool(self._dast_relogin_var.get()),
            probely_check_session_url=g("probely_check_session_url").strip(),
            probely_logout_markers=g("probely_logout_markers"),
            probely_logout_condition=(self._dast_logout_cond_var.get() or "any"),
            probely_logout_url_detector=bool(self._dast_logout_url_det_var.get()),
            probely_logout_code_detector=bool(self._dast_logout_code_det_var.get()),
            probely_logout_selector=self._dast_logout_selector_var.get().strip(),
            probely_logout_body_markers=self._dast_logout_body_var.get(),
            probely_logout_header_markers=self._dast_logout_header_var.get(),
            probely_login_url=g("selenium_login_url").strip() or g("login_url").strip(),
            probely_form_login_check_pattern=g("probely_form_login_check_pattern").strip(),
            probely_form_submit_selector=g("selenium_submit_selector").strip(),
            probely_2fa_enabled=bool(self._dast_2fa_var.get()),
            probely_otp_secret=self._dast_otp_secret_var.get().strip(),
            probely_otp_field=self._dast_otp_field_var.get().strip(),
            probely_otp_submit=self._dast_otp_submit_var.get().strip(),
            probely_otp_algorithm=(self._dast_otp_alg_var.get() or "SHA1"),
            probely_otp_digits=int(self._dast_otp_digits_var.get() or 6),
            probely_orchestrate=bool(self._dast_orch_var.get()),
            probely_pool_size=5,
            probely_slot_cooldown_minutes=float(self._dast_cooldown_var.get() or 60),
            probely_ledger_path=str(getattr(self, "_reports_root", ".")))

    def _setup_dast_field_persistence(self):
        delay = [None]
        def _on_change(*_):
            if delay[0] is not None:
                try: self.after_cancel(delay[0])
                except Exception: pass
            delay[0] = self.after(800, self._save_settings)
        for v in [self._dast_url_var, self._dast_auth_var, self._dast_profile_var,
                  self._dast_relogin_var, self._dast_browser_var,
                  self._dast_headless_var, self._dast_selwait_var,
                  self._dast_apibase_var, self._dast_target_id_var,
                  self._dast_reuse_url_var, self._dast_maxwait_var, self._dast_reduced_scopes_var,
                  self._dast_poll_var, self._dast_require_verified_var,
                  self._dast_blacklist_var, self._dast_ignore_blackout_var,
                  self._dast_report_var, self._dast_protect_session_var, self._dast_agent_warn_var,
                  self._dast_seq_path_var, self._dast_form_login_var, self._dast_logout_cond_var,
                  self._dast_logout_url_det_var, self._dast_logout_code_det_var,
                  self._dast_logout_selector_var, self._dast_logout_body_var, self._dast_logout_header_var,
                  self._dast_2fa_var, self._dast_otp_field_var, self._dast_otp_submit_var,
                  self._dast_otp_alg_var, self._dast_otp_digits_var,
                  self._dast_orch_var, self._dast_cooldown_var]:
            try: v.trace_add("write", _on_change)
            except Exception: pass
        for k, v in self._dast_cred_vars.items():
            if k not in self._SECRET_KEYS:
                try: v.trace_add("write", _on_change)
                except Exception: pass

    def _restore_dast_fields(self):
        saved = getattr(self, "_saved_dast_fields", None)
        if not isinstance(saved, dict): return
        try:
            if saved.get("url"):          self._dast_url_var.set(saved["url"])
            if saved.get("auth"):         self._dast_auth_var.set("none" if saved["auth"] == "auto" else saved["auth"])
            if saved.get("profile"):
                _p = saved["profile"]
                _p = {"passive": "(predeterminado)", "active": "full"}.get(_p, _p)
                self._dast_profile_var.set(_p)
            if "relogin"  in saved:       self._dast_relogin_var.set(bool(saved["relogin"]))
            if saved.get("browser"):      self._dast_browser_var.set(saved["browser"])
            if "headless" in saved:       self._dast_headless_var.set(bool(saved["headless"]))
            if "selwait"  in saved:       self._dast_selwait_var.set(int(saved["selwait"]))
            for k, val in (saved.get("creds") or {}).items():
                if k in self._dast_cred_vars and k not in self._SECRET_KEYS:
                    self._dast_cred_vars[k].set(str(val))
            pb = saved.get("probely") or {}
            if pb:
                _m = {
                    "apibase": self._dast_apibase_var,
                    "target_id": self._dast_target_id_var, "reduced": self._dast_reduced_scopes_var,
                    "blacklist": self._dast_blacklist_var,
                    "report": self._dast_report_var, "seq_path": self._dast_seq_path_var,
                    "form_login": self._dast_form_login_var, "logout_cond": self._dast_logout_cond_var,
                    "logout_selector": self._dast_logout_selector_var, "logout_body": self._dast_logout_body_var,
                    "logout_header": self._dast_logout_header_var, "otp_field": self._dast_otp_field_var,
                    "otp_submit": self._dast_otp_submit_var, "otp_alg": self._dast_otp_alg_var,
                }
                for k, var in _m.items():
                    if k in pb: var.set(str(pb[k]))
                if "reuse_url" in pb:       self._dast_reuse_url_var.set(bool(pb["reuse_url"]))
                if "maxwait" in pb:         self._dast_maxwait_var.set(int(pb["maxwait"]))
                if "ignore_blackout" in pb: self._dast_ignore_blackout_var.set(bool(pb["ignore_blackout"]))
                if "protect" in pb:        self._dast_protect_session_var.set(bool(pb["protect"]))
                if "agent_warn" in pb:     self._dast_agent_warn_var.set(bool(pb["agent_warn"]))
                if "logout_url_det" in pb: self._dast_logout_url_det_var.set(bool(pb["logout_url_det"]))
                if "logout_code_det" in pb: self._dast_logout_code_det_var.set(bool(pb["logout_code_det"]))
                if "twofa" in pb:          self._dast_2fa_var.set(bool(pb["twofa"]))
                if "otp_digits" in pb:     self._dast_otp_digits_var.set(int(pb["otp_digits"]))
                if "orchestrate" in pb:    self._dast_orch_var.set(bool(pb["orchestrate"]))
                if "cooldown" in pb:       self._dast_cooldown_var.set(int(pb["cooldown"]))
        except Exception:
            pass

    def _dast_save_condition(self, keys, name, initialfile, note=""):
        data = {k: self._dast_cred_vars[k].get() for k in keys if k in self._dast_cred_vars}
        if data.get("selenium_macro"):
            try:
                steps = json.loads(data["selenium_macro"])
                for s in steps:
                    if isinstance(s, dict) and s.get("kind") == "field" and (
                            s.get("role") == "password" or s.get("ftype") == "password"):
                        s["value"] = ""
                data["selenium_macro"] = json.dumps(steps)
            except Exception:
                pass
        path = filedialog.asksaveasfilename(title=f"Guardar {name}", defaultextension=".json",
            initialfile=initialfile, filetypes=[(name.capitalize(),"*.json"),("All","*.*")])
        if not path: return
        Path(path).write_text(json.dumps(data, indent=2), encoding="utf-8")
        self._emit_log(f"[dast] {name} saved → {path}{note}")

    def _dast_load_condition(self, keys, name):
        path = filedialog.askopenfilename(title=f"Cargar {name}", filetypes=[(name.capitalize(),"*.json"),("All","*.*")])
        if not path: return
        try:
            data = json.loads(Path(path).read_text(encoding="utf-8"))
        except Exception as e:
            self._show_error_popup(f"Cargar {name.title()}", f"No se pudo leer el archivo:\n{e}"); return
        applied = [k for k in keys if k in data and k in self._dast_cred_vars
                   and (self._dast_cred_vars[k].set(str(data[k])) or True)]
        self._refresh_dast_creds()
        self._emit_log(f"[dast] {name} loaded ← {path}  (fields: {', '.join(applied) or 'none'})")

    def _dast_save_login_condition(self):
        self._dast_save_condition(self._LOGIN_CONDITION_KEYS, "login condition",
                                  "dast_login_condition.json", "  (password value excluded)")

    def _dast_load_login_condition(self):
        self._dast_load_condition(self._LOGIN_CONDITION_KEYS, "login condition")

    def _dast_save_logout_condition(self):
        self._dast_save_condition(self._LOGOUT_CONDITION_KEYS, "logout condition", "dast_logout_condition.json")

    def _dast_load_logout_condition(self):
        self._dast_load_condition(self._LOGOUT_CONDITION_KEYS, "logout condition")

    def _record_in_browser(self, err_title, popup_title, instructions, work, *, w_pct=0.32, h_pct=0.30):
        url = (self._dast_cred_vars["selenium_login_url"].get().strip() or self._dast_url_var.get().strip())
        if not url or url == "https://":
            self._show_error_popup(err_title, "Configure una URL objetivo o de login primero."); return None
        done = threading.Event(); result: dict = {}
        cancelled = [False]
        status_box: dict = {"msg": None, "shown": None}
        def _emit_status(msg: str): status_box["msg"] = msg
        driver_ready = threading.Event()
        nav_done = threading.Event()
        result["_nav_done"] = nav_done

        def runner():
            try:
                drv = _make_driver(self._collect_dast_cfg(), headless=False, log=self._emit_log)
                result["_driver"] = drv; driver_ready.set()
                try:
                    work(drv, url, done, result, _emit_status)
                finally:
                    try: drv.quit()
                    except Exception: pass
            except Exception as e:
                result["error"] = repr(e); driver_ready.set()
            finally:
                nav_done.set()
                done.set()

        t = threading.Thread(target=runner, daemon=True); t.start()

        watchdog_stop = threading.Event()
        def _watchdog():
            misses = 0
            if not driver_ready.wait(timeout=30):
                return
            if not nav_done.wait(timeout=60):
                return
            if done.is_set() or watchdog_stop.is_set():
                return
            while not (done.is_set() or watchdog_stop.is_set()):
                drv = result.get("_driver")
                if drv is None:
                    return
                probe_done = threading.Event(); probe_ok = {"v": False}
                def _probe(drv=drv):
                    try:
                        _ = drv.window_handles
                        if _:
                            probe_ok["v"] = True
                    except Exception:
                        probe_ok["v"] = False
                    finally:
                        probe_done.set()
                threading.Thread(target=_probe, daemon=True).start()
                if not probe_done.wait(timeout=3.0) or not probe_ok["v"]:
                    misses += 1
                else:
                    misses = 0
                if misses >= 2:
                    self._emit_log("[record] browser window was closed — cancelling operation.")
                    cancelled[0] = True
                    done.set()
                    try: drv.quit()
                    except Exception: pass
                    return
                if done.wait(timeout=1.5):
                    return

        threading.Thread(target=_watchdog, daemon=True).start()
        HUD_W, HUD_H = 360, 105
        PADDING = 14
        CORNERS = ["ne", "nw", "sw", "se"]
        hud = tk.Toplevel(self)
        hud.overrideredirect(True); hud.attributes("-topmost", True)
        hud.attributes("-alpha", 0.90); hud.resizable(False, False)
        hud._corner_idx = [0]

        def _place_hud(corner: str):
            sw = hud.winfo_screenwidth(); sh = hud.winfo_screenheight()
            if corner == "ne":   x, y = sw - HUD_W - PADDING, PADDING
            elif corner == "nw": x, y = PADDING, PADDING
            elif corner == "sw": x, y = PADDING, sh - HUD_H - PADDING
            else:                x, y = sw - HUD_W - PADDING, sh - HUD_H - PADDING
            hud.geometry(f"{HUD_W}x{HUD_H}+{x}+{y}")

        def _dodge(event=None):
            idx = (hud._corner_idx[0] + 1) % len(CORNERS)
            hud._corner_idx[0] = idx; _place_hud(CORNERS[idx])

        _place_hud(CORNERS[0])
        outer = tk.Frame(hud, bg=T["accent"], padx=1, pady=1); outer.pack(fill="both", expand=True)
        inner = tk.Frame(outer, bg=T["panel_bg"], padx=10, pady=8); inner.pack(fill="both", expand=True)
        tk.Label(inner, text=popup_title, font=(_FUI, 10, "bold"), bg=T["panel_bg"], fg=T["accent"]).pack(anchor="w")
        status_var = tk.StringVar(value="⏳  Opening browser…")
        tk.Label(inner, textvariable=status_var, font=(_FUI, 9), bg=T["panel_bg"], fg=T["muted"],
                 wraplength=HUD_W - 24).pack(anchor="w", pady=(2, 4))
        hotkey_lbl = tk.Label(inner, text="Ctrl+Shift+F12  →  capturar     Ctrl+Shift+F11  →  cancelar",
                              font=(_FUI, 8), bg=T["panel_bg"], fg=T["muted"])
        hotkey_lbl.pack(anchor="w")
        for widget in (hud, outer, inner, hotkey_lbl): widget.bind("<Enter>", _dodge, "+")
        ready = [False]
        _hotkey_stop = threading.Event(); _hotkey_cancel = threading.Event()

        def _pynput_listener():
            try:
                from pynput import keyboard as _kb
                _pressed = set()
                def _on_press(key):
                    _pressed.add(key)
                    ctrl = any(k in _pressed for k in (_kb.Key.ctrl, _kb.Key.ctrl_l, _kb.Key.ctrl_r))
                    shift = any(k in _pressed for k in (_kb.Key.shift, _kb.Key.shift_l, _kb.Key.shift_r))
                    if ctrl and shift:
                        if key == _kb.Key.f12: _hotkey_stop.set()
                        elif key == _kb.Key.f11: _hotkey_cancel.set()
                def _on_release(key): _pressed.discard(key)
                with _kb.Listener(on_press=_on_press, on_release=_on_release) as lst:
                    while not done.is_set():
                        if done.wait(0.2): break
                    lst.stop()
            except Exception as ex:
                self._emit_log(f"[hotkey] pynput unavailable ({ex!r}) — "
                               "press Ctrl+Shift+F12 while the Scanner window is focused")

        threading.Thread(target=_pynput_listener, daemon=True).start()

        def _on_key_tk(event):
            ctrl = bool(event.state & 0x4); shift = bool(event.state & 0x1)
            if ctrl and shift and event.keysym == "F12": _hotkey_stop.set()
            elif ctrl and shift and event.keysym == "F11": _hotkey_cancel.set()

        _key_bind_id = self.bind("<KeyPress>", _on_key_tk, "+")
        hud.bind("<KeyPress>", _on_key_tk, "+")

        def _poll_hotkeys():
            if _hotkey_cancel.is_set():
                cancelled[0] = True; done.set(); return
            if _hotkey_stop.is_set() and ready[0]:
                done.set(); return
            hud.after(150, _poll_hotkeys)

        hud.after(150, _poll_hotkeys)

        def _poll_ready():
            if driver_ready.is_set():
                if "error" not in result:
                    if status_box.get("msg") is None:
                        status_var.set("✅  Browser open — interact freely")
                    ready[0] = True
                else:
                    status_var.set("❌  Browser failed")
                return
            hud.after(200, _poll_ready)

        hud.after(200, _poll_ready)

        def _poll_status():
            m = status_box.get("msg")
            if m is not None and m != status_box.get("shown"):
                status_var.set(m); status_box["shown"] = m
            if not (done.is_set() or cancelled[0]): hud.after(180, _poll_status)

        hud.after(180, _poll_status)

        def _poll_done():
            if done.is_set() or cancelled[0]:
                try: self.unbind("<KeyPress>", _key_bind_id)
                except Exception: pass
                try: hud.destroy()
                except Exception: pass
                return
            hud.after(300, _poll_done)

        hud.after(300, _poll_done)
        self.wait_window(hud)
        t.join(timeout=1.5 if (cancelled[0] or result.get("_cancelled")) else 10)
        if cancelled[0] or result.get("_cancelled") or "error" in result:
            if "error" in result:
                self._show_error_popup(err_title, f"Error del navegador:\n{result['error']}")
            return None
        result["_url"] = url
        return result

    def _dast_record_macro(self):
        work = record_macro_work(self._collect_dast_cfg(), emit_log=self._emit_log)
        result = self._record_in_browser("Grabar condición de login", "⏺ Condición de login",
                                         [], work, w_pct=0.32, h_pct=0.30)
        if result is None: return False
        url = result["_url"]
        try: macro = json.loads(result.get("macro") or "[]")
        except Exception: macro = []
        if not isinstance(macro, list): macro = []
        macro = [s for s in macro if isinstance(s, dict)]
        user_sel, user_val, pass_sel, pass_val, submit_sel = self._analyze_login_macro(macro)
        submit_extra = None
        if not submit_sel:
            sub = next((s for s in macro if s.get("kind") == "submit"), None)
            ent = next((s for s in macro if s.get("kind") == "enter"), None)
            if sub and sub.get("button"): submit_sel = sub["button"]
            elif sub and sub.get("form"): submit_extra = {"submit": sub["form"]}
            elif ent and ent.get("form"): submit_extra = {"submit": ent["form"]}
            elif ent: submit_extra = {"key": "Enter", "selector": ent.get("selector") or pass_sel}
        if user_sel: self._dast_cred_vars["selenium_user_selector"].set(user_sel)
        if user_val: self._dast_cred_vars["selenium_user_value"].set(user_val)
        if pass_sel: self._dast_cred_vars["selenium_pass_selector"].set(pass_sel)
        if pass_val: self._dast_cred_vars["selenium_pass_value"].set(pass_val)
        self._dast_cred_vars["selenium_submit_selector"].set(submit_sel or "")
        if not self._dast_cred_vars["selenium_login_url"].get():
            self._dast_cred_vars["selenium_login_url"].set(url)
        _LOGOUT_RE = _re.compile(
            r"(?i)(logout|log[\s_-]?out|sign[\s_-]?out|signoff|cerrar[\s_-]?sesi[oó]n|salir)")
        extras: list = []
        for s in macro:
            kind = s.get("kind"); sel = s.get("selector")
            if kind == "field" and sel and sel not in (user_sel, pass_sel) \
                    and s.get("role") != "password" and s.get("value"):
                extras.append({"selector": sel, "value": s["value"]})
            elif kind == "click" and sel and sel != submit_sel:
                blob = f"{sel} {s.get('text','')}"
                if _LOGOUT_RE.search(blob): continue
                extras.append({"click": sel})
        if submit_extra: extras.append(submit_extra)
        self._dast_cred_vars["selenium_extra_steps"].set(json.dumps(extras) if extras else "")
        literal: list = []
        for s in macro:
            if s.get("kind") == "click":
                blob = f"{s.get('selector','')} {s.get('text','')}"
                if _LOGOUT_RE.search(blob): continue
            literal.append(s)
        self._dast_cred_vars["selenium_macro"].set(json.dumps(literal) if literal else "")
        submit_desc = (submit_sel if submit_sel else "Enter / enviar formulario" if submit_extra else "(no detectado)")
        self._emit_log(f"[macro] captured {len(macro)} interactions — "
                       f"user={user_sel!r} pass={pass_sel!r} submit={submit_desc!r}")
        pass_note = ("✔ captured (runtime only)" if pass_val
                     else "(type it in Password value before recording Logout)")
        self._show_info_popup("Condición de login",
            f"Se capturaron {len(macro)} interacciones.\n\n"
            f"Selector de usuario:  {user_sel or '(no detectado)'}\n"
            f"Selector de contraseña: {pass_sel or '(no detectado)'}\n"
            f"Valor de contraseña:    {pass_note}\n"
            f"Enviar:                 {submit_desc}\n\n"
            "Enviar es la acción que envía el formulario de login — un clic en botón, "
            "or an Enter / form submit when there's no button.\n"
            "The password is held only in this session and is wiped when you "
            "close the program; it's never written to any saved file.")
        self._refresh_dast_creds()
        return True

    @staticmethod
    def _analyze_login_macro(macro: list) -> tuple:
        return analyze_login_macro(macro)

    def _dast_record_logout(self):
        cfg = self._collect_dast_cfg()
        pass_sel = cfg.selenium_pass_selector
        pass_val = cfg.selenium_pass_value
        password_missing = bool(pass_sel and not pass_val)
        if password_missing:
            self._show_info_popup("Condición de logout — se requiere login manual",
                "Su login fue grabado, pero la contraseña no se guardó "
                "(passwords are never written to disk).\n\n"
                "The browser will open at the login page. Log in by hand, go to "
                "the logged-OUT page, then press Ctrl+Shift+F12 to capture.\n\n"
                "Tip: type your password into the “Password value” field of the "
                "credentials section first and the login will replay itself "
                "automatically next time.")
        work = record_logout_work(cfg, emit_log=self._emit_log)
        result = self._record_in_browser("Record Logout Condition", "⏺ Logout Condition",
                                         [], work, w_pct=0.34, h_pct=0.32)
        if result is None: return False
        final_url = result.get("final_url","").strip()
        logout_macro = result.get("logout_macro", [])
        logout_hrefs = result.get("logout_href_candidates", [])
        last_click = result.get("last_logout_click", {})
        snapshot = result.get("snapshot", {})
        hints = snapshot.get("hints", [])
        page_title = snapshot.get("title","")
        if logout_macro and last_click and last_click.get("selector"):
            last_sel = last_click["selector"]
            macro_sels = [s.get("selector","") for s in logout_macro if s.get("kind") == "click"]
            if last_sel not in macro_sels:
                logout_macro = list(logout_macro) + [{
                    "kind": "click", "selector": last_click.get("selector", ""),
                    "fallback_selectors": last_click.get("fallback_selectors", []),
                    "href": last_click.get("href", ""), "text": last_click.get("text", ""),
                    "el_id": last_click.get("el_id", ""), "el_cls": last_click.get("el_cls", ""),
                    "data_action": last_click.get("data_action", ""),
                }]
                self._emit_log("[logout-rec] appended last click to macro (no kw match)")
        elif not logout_macro and last_click and last_click.get("selector"):
            logout_macro = [{
                "kind": "click", "selector": last_click.get("selector", ""),
                "fallback_selectors": last_click.get("fallback_selectors", []),
                "href": last_click.get("href", ""), "text": last_click.get("text", ""),
                "el_id": last_click.get("el_id", ""), "el_cls": last_click.get("el_cls", ""),
                "data_action": last_click.get("data_action", ""),
            }]
            self._emit_log("[logout-rec] built 1-step macro from last click (no macro recorded)")
        _LOGOUT_KW = ("logout","log-out","signout","sign-out","cerrar","salir")
        def _path_of(u):
            try:
                from urllib.parse import urlparse as _up2
                p = _up2(u if "://" in u else "https://x" + u).path.rstrip("/") or "/"
                return p if p != "/" else None
            except Exception:
                return None
        proposed_re = ""; best_path = None
        for h in logout_hrefs:
            p = _path_of(h)
            if p and any(k in p.lower() for k in _LOGOUT_KW): best_path = p; break
        if not best_path:
            for h in logout_hrefs:
                p = _path_of(h)
                if p: best_path = p; break
        if not best_path and final_url: best_path = _path_of(final_url)
        if not best_path and last_click.get("href"): best_path = _path_of(last_click["href"])
        if best_path: proposed_re = _re.escape(best_path) + r"(\?|$)"
        self._emit_log(f"[logout-rec] proposed_re={proposed_re!r} from path={best_path!r}")
        confirm = self._create_popup("Condición de logout — revisar y confirmar")
        self._popup_hdr(confirm, "Condición de logout", subtitle="revisar señales capturadas", icon="🔓")
        _cb: dict = {"apply": lambda: None}
        foot = tk.Frame(confirm, bg=T["panel_bg"], padx=28, pady=12); foot.pack(side="bottom", fill="x")
        self._btn(foot, "Aplicar", lambda: _cb["apply"](), "accent").pack(side="right", padx=(6, 0))
        self._btn(foot, "Cancelar", lambda: confirm.close(), "flat").pack(side="right", padx=(6, 0))
        tk.Frame(confirm, bg=T["border"], height=1).pack(side="bottom", fill="x")
        canvas = tk.Canvas(confirm, bg=T["bg"], highlightthickness=0, bd=0)
        vsb = ttk.Scrollbar(confirm, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y"); canvas.pack(side="left", fill="both", expand=True)
        cbody = tk.Frame(canvas, bg=T["bg"], padx=28, pady=14)
        cwin = canvas.create_window((0, 0), window=cbody, anchor="nw")
        def _sync_scroll(_e=None): canvas.configure(scrollregion=canvas.bbox("all"))
        def _sync_width(e): canvas.itemconfigure(cwin, width=e.width)
        cbody.bind("<Configure>", _sync_scroll); canvas.bind("<Configure>", _sync_width)
        def _wheel(e):
            try: canvas.yview_scroll(-1 * int(e.delta / 120), "units")
            except Exception: pass
        canvas.bind("<MouseWheel>", _wheel); cbody.bind("<MouseWheel>", _wheel)
        cbody.columnconfigure(1, weight=1)
        row_idx = [0]
        def _row(widget_or_text, *, col=0, span=1, sticky="w", advance=True, **gkw):
            w = widget_or_text
            if isinstance(w, str):
                w = self._lbl(cbody, w, size=9, fg=T["muted"], wraplength=430, anchor="w"); span = 2
            w.grid(row=row_idx[0], column=col, columnspan=span, sticky=sticky, **gkw)
            if advance: row_idx[0] += 1
            return w
        def _field(label, value_var):
            _row(self._lbl(cbody, label, size=10, fg=T["muted"], anchor="e"),
                 sticky="e", advance=False, padx=(0, 8), pady=3)
            e = ttk.Entry(cbody, textvariable=value_var); _row(e, col=1, sticky="ew", pady=3); return e
        _row(self._lbl(cbody, "URL capturada", size=10, fg=T["muted"], anchor="e"),
             sticky="e", advance=False, padx=(0, 8), pady=3)
        _row(self._lbl(cbody, final_url or "(none)", size=10, fg=T["text"], anchor="w", wraplength=420), col=1)
        re_var = tk.StringVar(value=proposed_re)
        _row(self._lbl(cbody, "Regex de URL de logout", size=10, fg=T["muted"], anchor="e"),
             sticky="e", advance=False, padx=(0, 8), pady=3)
        _re_entry = ttk.Entry(cbody, textvariable=re_var); _row(_re_entry, col=1, sticky="ew", pady=3)
        regex_hint = (
            "URLs matching this regex are SKIPPED so the scanner never logs itself out.\n"
            + ("⚠  Captured URL was root (/). Enter the path the app redirects to after "
               "logout (e.g. /login or /signin). Leave blank if the app stays at / — "
               "use Logged-in selector/text below for session detection instead."
               if not proposed_re else
               "Regex must match a specific path (e.g. /login or /logout). "
               "Avoid patterns that match / — they are too broad and will be rejected."))
        _row(regex_hint)
        _row(tk.Frame(cbody, bg=T["border"], height=1), span=2, sticky="ew", pady=10)
        _row(self._lbl(cbody, "DETECCIÓN DE SESIÓN", size=9, fg=T["muted"], bold=True, anchor="w"), span=2)
        _row("Optionally tell the scanner what a LOGGED-IN page looks like "
             "so it can detect session loss mid-scan and re-authenticate.")
        txt_var = tk.StringVar(value=self._dast_cred_vars["login_success_text"].get())
        _field("Texto de sesión activa", txt_var)
        _row("Text ONLY visible when logged in (e.g. 'My Account'). Used by Probely "
             "as the login-confirmation pattern (form_login_check_pattern).")
        if logout_macro:
            _row(tk.Frame(cbody, bg=T["border"], height=1), span=2, sticky="ew", pady=(10, 4))
            _row(self._lbl(cbody, "ACCIÓN DE LOGOUT GRABADA", size=9, fg=T["muted"], bold=True, anchor="w"), span=2)
            click_steps = [s for s in logout_macro if s.get("kind") == "click"]
            _row(f"✓ {len(logout_macro)} step(s) recorded "
                 f"({len(click_steps)} click(s)). The last click is treated as the logout action.")
            if last_click and last_click.get("selector"):
                lc_text = (last_click.get("text") or "").strip()
                lc_sel = (last_click.get("selector") or "").strip()
                lc_id = (last_click.get("el_id") or "").strip()
                lc_href = (last_click.get("href") or "").strip()
                lc_data = (last_click.get("data_action") or "").strip()
                if lc_text: _row(f"  · Button text: “{lc_text}”")
                if lc_sel: _row(f"  · CSS selector: {lc_sel[:70]}")
                if lc_id: _row(f"  · Element id: {lc_id}")
                if lc_data: _row(f"  · data-action: {lc_data}")
                if lc_href and lc_href not in ("#", "javascript:void(0)", "javascript:;"):
                    _row(f"  · Navigates to: {lc_href[:70]}")
                else:
                    _row("  · No navigation URL (SPA button) — protection is "
                         "by element identity, not URL.")
        if hints or page_title or snapshot.get("has_password_field") or snapshot.get("has_login_form"):
            _row(tk.Frame(cbody, bg=T["border"], height=1), span=2, sticky="ew", pady=(10, 4))
            _row("Signals detected on logout page (for reference):")
            strong = []
            if snapshot.get("has_password_field"): strong.append("password field present (typical of a login page)")
            if snapshot.get("has_login_form"): strong.append("login form present")
            for s in strong: _row(f"  ✓ {s}")
            clean_hints = []
            for h in hints:
                h = _re.sub(r"\s+", " ", str(h)).strip()[:80]
                if h and h not in clean_hints: clean_hints.append(h)
            for h in ([f"Page title: {page_title}"] if page_title else []) + clean_hints[:8]:
                _row(f"  · {h}")
        elif not final_url:
            _row(tk.Frame(cbody, bg=T["border"], height=1), span=2, sticky="ew", pady=(10, 4))
            _row("⚠️  No page data was captured. Make sure you pressed "
                 "Ctrl+Shift+F12 *while on the logged-out page* (the browser "
                 "must still be open). You can type the Logout URL regex above "
                 "by hand and Apply.")
        applied: list[bool] = [False]
        def _apply():
            re_val = re_var.get().strip(); txt_val = txt_var.get().strip()
            if re_val: self._dast_cred_vars["logout_url_re"].set(re_val)
            if txt_val: self._dast_cred_vars["login_success_text"].set(txt_val)
            if logout_macro:
                self._dast_cred_vars["selenium_logout_macro"].set(json.dumps(logout_macro))
                self._emit_log(f"[logout-rec] logout macro saved ({len(logout_macro)} steps)")
            else:
                self._emit_log("[logout-rec] WARNING: 0 logout steps recorded — "
                               "open user menu and click Log Out while recorder is running")
            applied[0] = True
            self._emit_log(f"[logout-rec] applied — regex={re_val!r} text={txt_val!r}")
            self._refresh_dast_creds(); confirm.close()
        _cb["apply"] = _apply
        def _bind_wheel_rec(w):
            try: w.bind("<MouseWheel>", _wheel)
            except Exception: pass
            for child in w.winfo_children(): _bind_wheel_rec(child)
        _bind_wheel_rec(cbody)
        self.wait_window(confirm._win)
        if not applied[0]:
            self._emit_log("[logout-rec] cancelled — no changes applied"); return False
        return True

    def _refresh_browser_catalog(self) -> list[str]:
        catalog = {}
        try:
            catalog = detect_browsers() or {}
        except Exception:
            try:
                from dast_api import detect_browsers as _db
                catalog = _db() or {}
            except Exception:
                catalog = {}
        if not catalog:
            catalog = {"chrome": {"name": "Google Chrome", "binary": "", "engine": "chromium"}}
        self._browser_catalog = catalog
        self._browser_label_key = {info["name"]: key for key, info in catalog.items()}
        labels = [info["name"] for info in catalog.values()]
        cur_key = self._dast_browser_var.get()
        if cur_key not in catalog:
            cur_key = next(iter(catalog)); self._dast_browser_var.set(cur_key)
        self._dast_browser_label_var.set(catalog[cur_key]["name"])
        return labels
