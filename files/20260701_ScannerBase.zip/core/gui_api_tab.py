from __future__ import annotations


class _ApiTabMixin:
    def _build_tab_api(self, parent):
        self._section_header(parent, '🔌  Seguridad de APIs')
        pad = self._scrollable(parent)
        self._safety_banner(pad,
            "Asegúrate de que la URL apunte a un entorno que NO sea de producción.")
        body = self._card(pad, 'ESPECIFICACIÓN Y OBJETIVO'); body.columnconfigure(1, weight=1); body.columnconfigure(3, weight=1)
        def gl(text, r, c): return self._glabel(body, text, r, c)
        gl('Especificación (URL o archivo)', 0, 0); self._gentry(body, self._api_spec_var, 0, 1, span=2)
        self._btn(body, 'Explorar…', self._browse_api_spec, kind="flat").grid(row=0, column=3, sticky="w", padx=(4, 0))
        gl('URL base del API objetivo (opcional)', 1, 0); self._gentry(body, self._api_base_var, 1, 1, span=3)
        gl('Tipo de autenticación', 2, 0)
        api_ac = ttk.Combobox(body, textvariable=self._api_auth_var,
                              values=["none","basic","bearer","cookie","header"],
                              state="readonly", width=10)
        api_ac.grid(row=2, column=1, sticky="w", pady=3)
        api_ac.bind("<<ComboboxSelected>>", lambda _: self._refresh_api_creds())
        gl('Perfil de escaneo', 3, 0)
        api_pc = ttk.Combobox(body, textvariable=self._api_profile_var,
                              values=["(predeterminado)","lightning","safe","normal","full"],
                              state="readonly", width=14)
        api_pc.grid(row=3, column=1, sticky="w", pady=3)
        self._api_profile_cb = api_pc
        self._btn(body, "↻", lambda: self._refresh_scan_profiles("api"),
                  kind="flat").grid(row=3, column=2, sticky="w", pady=3)
        gl('Tipo de esquema', 3, 2)
        ttk.Combobox(body, textvariable=self._api_schema_type_var,
                     values=["(auto)","openapi","postman","graphql"],
                     state="readonly", width=12).grid(row=3, column=3, sticky="w", pady=3)
        self._api_cred_frame = tk.Frame(body, bg=T["panel_bg"])
        self._api_cred_frame.grid(row=4, column=0, columnspan=4, sticky="ew", pady=(4, 0))
        self._api_cred_frame.columnconfigure(1, weight=1)
        scope = tk.Frame(body, bg=T["panel_bg"]); scope.grid(row=5, column=0, columnspan=4, sticky="ew", pady=(8, 0))
        ttk.Checkbutton(scope, text="Verificar TLS (solo vista previa local)", variable=self._api_tls_var).pack(side="left", padx=(0, 14))
        self._lbl(scope, 'Proxy HTTP (solo vista previa)', size=10, fg=T["muted"]).pack(side="left", padx=(0, 4))
        ttk.Entry(scope, textvariable=self._api_proxy_var, width=24).pack(side="left")
        self._lbl(scope, "El escaneo y su alcance se configuran en la tarjeta PROBELY (NUBE).",
                  size=9, fg=T["muted"]).pack(side="left", padx=(10, 0))
        conv_card = self._card(pad, 'CONVERSOR Y VISTA PREVIA DE ENDPOINTS', pady=(0, 14))
        btn_row_conv = tk.Frame(conv_card, bg=T["panel_bg"]); btn_row_conv.pack(fill="x", pady=(0, 6))
        self._btn(btn_row_conv, '🔍 Vista previa', self._api_preview_spec, kind="accent").pack(side="left")
        self._btn(btn_row_conv, '📥 Importar…', self._api_import_popup, kind="flat").pack(side="left", padx=(8, 0))
        self._btn(btn_row_conv, "💾 Exportar…", self._api_export_popup, kind="flat").pack(side="left", padx=(8, 0))
        tree_wrap = tk.Frame(conv_card, bg=T["panel_bg"]); tree_wrap.pack(fill="both", expand=True)
        self._ep_tree = _make_tree(tree_wrap, ("method","url","secured","body"),
                                   [("Método",70),("URL del endpoint",480),("Auth req.",70),("Tipo de cuerpo",120)], height=10)
        self._ep_count_lbl = self._lbl(conv_card, "", size=10, fg=T["muted"]); self._ep_count_lbl.pack(anchor="w", pady=(4, 0))
        self._build_api_probely_card(pad)
        self._build_api_orchestrator_card(pad)
        self._refresh_api_creds()
        self._setup_api_field_persistence()

    def _build_api_probely_card(self, pad):
        REPORTS = ["(ninguno)", "owasp", "owasp_web_2021", "owasp_web_2025",
                   "pci", "pci4", "pci_v3_2_1", "pci_v4_0_1",
                   "iso27001", "hipaa", "executive_summary"]
        c = self._card(pad, 'PROBELY (NUBE) — ALCANCE, PERFIL Y SESIÓN', pady=(0, 14))
        c.columnconfigure(1, weight=1); c.columnconfigure(3, weight=1)
        # La clave de API de Probely se pega UNA sola vez con el icono 🌐 de la barra
        # superior (cuenta de servicio, compartida por DAST y API). No se repite aquí.
        self._lbl(c, "La clave de API de Probely se configura con el icono 🌐 de la barra superior.",
                  size=9, fg=T["muted"]).grid(row=0, column=0, columnspan=4, sticky="w", pady=(0, 6))
        def L(t, r, col=0): self._lbl(c, t, size=10, fg=T["muted"], anchor="e").grid(
            row=r, column=col, sticky="e", padx=(0, 6), pady=2)
        L('Reutilizar target por ID', 1)
        ttk.Entry(c, textvariable=self._api_target_id_var).grid(row=1, column=1, sticky="ew", pady=2)
        rr = tk.Frame(c, bg=T["panel_bg"]); rr.grid(row=1, column=2, columnspan=2, sticky="w", pady=2)
        ttk.Checkbutton(rr, text="Reutilizar por URL", variable=self._api_reuse_url_var).pack(side="left", padx=(8, 12))
        self._spin(rr, 'Espera máx. (min)', self._api_maxwait_var, 5, 1440, width=6)
        L('Alcance reducido (URLs, una por línea/coma)', 2)
        ttk.Entry(c, textvariable=self._api_reduced_scopes_var).grid(row=2, column=1, columnspan=3, sticky="ew", pady=2)
        L('Secuencia de login (archivo del Probely Recorder)', 3)
        sf = tk.Frame(c, bg=T["panel_bg"]); sf.grid(row=3, column=1, columnspan=3, sticky="ew", pady=2)
        sf.columnconfigure(0, weight=1)
        ttk.Entry(sf, textvariable=self._api_seq_path_var).grid(row=0, column=0, sticky="ew")
        self._btn(sf, 'Explorar…', self._api_browse_sequence, kind="flat").grid(row=0, column=1, padx=(4, 0))
        tg = tk.Frame(c, bg=T["panel_bg"]); tg.grid(row=4, column=0, columnspan=4, sticky="ew", pady=(6, 0))
        ttk.Checkbutton(tg, text="Ignorar blackout", variable=self._api_ignore_blackout_var).pack(side="left", padx=(0, 12))
        ttk.Checkbutton(tg, text="Proteger sesión", variable=self._api_protect_session_var).pack(side="left", padx=(0, 12))
        ttk.Checkbutton(tg, text="Probar login API antes de escanear", variable=self._api_check_login_var).pack(side="left", padx=(0, 12))
        ttk.Checkbutton(tg, text="Exigir dominio verificado", variable=self._api_require_verified_var).pack(side="left", padx=(0, 12))
        tg2 = tk.Frame(c, bg=T["panel_bg"]); tg2.grid(row=5, column=0, columnspan=4, sticky="ew", pady=(2, 0))
        self._lbl(tg2, 'Reporte de cumplimiento', size=10, fg=T["muted"]).pack(side="left", padx=(0, 4))
        ttk.Combobox(tg2, textvariable=self._api_report_var, values=REPORTS, state="readonly", width=18).pack(side="left")
        sep = tk.Frame(c, bg=T["border"], height=1); sep.grid(row=6, column=0, columnspan=4, sticky="ew", pady=8)
        self._lbl(c, "LOGIN POR ENDPOINT (obtención de token) — opcional",
                  size=9, fg=T["muted"], bold=True).grid(row=7, column=0, columnspan=4, sticky="w")
        L('URL de login', 8)
        ttk.Entry(c, textvariable=self._api_login_url_var).grid(row=8, column=1, columnspan=3, sticky="ew", pady=2)
        L('Payload de autenticación', 9)
        ttk.Entry(c, textvariable=self._api_login_payload_var).grid(row=9, column=1, columnspan=3, sticky="ew", pady=2)
        L('Media type', 10)
        ttk.Combobox(c, textvariable=self._api_login_media_var,
                     values=["application/json", "application/x-www-form-urlencoded"],
                     state="readonly", width=30).grid(row=10, column=1, sticky="w", pady=2)
        L('Campo del token en la respuesta', 10, 2)
        ttk.Entry(c, textvariable=self._api_login_token_field_var).grid(row=10, column=3, sticky="ew", pady=2)
        L('Cabecera/cookie del token', 11)
        ttk.Entry(c, textvariable=self._api_login_token_param_var).grid(row=11, column=1, sticky="ew", pady=2)
        L('Prefijo del token', 11, 2)
        pf = tk.Frame(c, bg=T["panel_bg"]); pf.grid(row=11, column=3, sticky="ew", pady=2)
        ttk.Entry(pf, textvariable=self._api_login_token_prefix_var, width=10).pack(side="left")
        ttk.Combobox(pf, textvariable=self._api_login_place_var, values=["header", "cookie"],
                     state="readonly", width=8).pack(side="left", padx=(8, 0))

    def _build_api_orchestrator_card(self, pad):
        """Same account-wide pool as the DAST tab. An API scan registers an `api`
        target, which consumes one of the 5 shared slots — so scanning DAST + API
        of the same app frees/uses TWO slots (one Web, one API). This card mirrors
        the DAST orchestrator: the toggle and cooldown are the SAME shared setting,
        and refreshing here queries the one pool and updates both tabs' tables."""
        c = self._card(pad, 'ORQUESTADOR DE SLOTS (POOL DE 5 TARGETS PROBELY)', pady=(0, 14))
        self._lbl(c, "Un escaneo de API crea un target de tipo «API» que ocupa uno de los 5 "
                  "slots compartidos con DAST. Si escanea DAST y API a la vez, se usan/recargan "
                  "DOS slots (uno Web y uno API). El reciclado del slot más antiguo sin escaneo "
                  "activo y fuera del enfriamiento ocurre automáticamente al escanear; aquí solo "
                  "consulta el estado. Es el mismo pool y el mismo ajuste que en la pestaña DAST.",
                  size=9, fg=T["muted"]).pack(anchor="w", pady=(0, 8))

        opts = tk.Frame(c, bg=T["panel_bg"]); opts.pack(fill="x", pady=(0, 8))
        ttk.Checkbutton(opts, text="Orquestar el pool automáticamente al escanear",
                        variable=self._dast_orch_var).pack(side="left", padx=(0, 14))
        self._spin(opts, 'Enfriamiento por slot (min)', self._dast_cooldown_var, 0, 1440, width=6)

        actions = tk.Frame(c, bg=T["panel_bg"]); actions.pack(fill="x", pady=(0, 6))
        self._btn(actions, '🔄  Actualizar estado del pool',
                  lambda: self._refresh_pool_status("api"), kind="accent").pack(side="left")
        self._api_orch_status_var = tk.StringVar(value="Pulse «Actualizar estado del pool».")
        tk.Label(c, textvariable=self._api_orch_status_var, font=(_FUI, 9),
                 bg=T["panel_bg"], fg=T["muted"], anchor="w", justify="left",
                 wraplength=900).pack(fill="x", pady=(0, 6))

        tree_frame = tk.Frame(c, bg=T["panel_bg"]); tree_frame.pack(fill="both", expand=True)
        self._api_orch_tree = _make_tree(
            tree_frame, ("target", "type", "url", "scans", "age", "elig"),
            [("Target", 110), ("Tipo", 60), ("URL", 300), ("Escaneos", 200),
             ("Edad", 80), ("Reciclable", 150)], height=6)

    def _api_browse_sequence(self):
        p = filedialog.askopenfilename(title="Secuencia de login de Probely",
            filetypes=[("Secuencia Probely (JSON)", "*.json"), ("Todos", "*.*")])
        if p: self._api_seq_path_var.set(p)

    def _refresh_api_creds(self):
        self._refresh_creds(self._api_cred_frame, self._api_auth_var, self._api_cred_vars)

    def _browse_api_spec(self):
        p = filedialog.askopenfilename(title="Seleccionar especificación de API",
            filetypes=[("Archivos de especificación","*.json *.yaml *.yml"),("Todos","*.*")])
        if p: self._api_spec_var.set(p)

    def _api_load_spec_file(self, title: str, filetypes: list, log_label: str):
        p = filedialog.askopenfilename(title=title, filetypes=filetypes)
        if p:
            self._api_spec_var.set(p); self._emit_log(f"[api] cargado {log_label}: {p}"); self._api_preview_spec()

    def _api_import_postman(self):
        self._api_load_spec_file("Importar colección Postman",
            [("Colección Postman", "*.json"), ("Todos", "*.*")], "Colección Postman")

    def _api_import_openapi(self):
        self._api_load_spec_file("Importar especificación OpenAPI / Swagger",
            [("OpenAPI/Swagger", "*.json *.yaml *.yml"), ("Todos", "*.*")], "especificación OpenAPI/Swagger")

    def _api_import_graphql(self):
        self._api_schema_type_var.set("graphql")
        self._api_load_spec_file("Importar esquema GraphQL (SDL o endpoint)",
            [("GraphQL", "*.graphql *.gql *.graphqls *.json"), ("Todos", "*.*")], "esquema GraphQL")

    def _api_import_popup(self):
        popup = self._create_popup("Importar especificación")
        self._popup_hdr(popup, "Importar especificación", icon="📥")
        body = tk.Frame(popup, bg=T["bg"]); body.pack(fill="both", expand=True)
        tk.Frame(body, bg=T["bg"]).pack(fill="both", expand=True)
        tk.Label(body, text="Elija el formato a importar:", font=(_FUI, 13), bg=T["bg"], fg=T["muted"]).pack(pady=(0, 28))
        card_row = tk.Frame(body, bg=T["bg"]); card_row.pack(padx=80)
        tk.Frame(body, bg=T["bg"]).pack(fill="both", expand=True)
        def _pick(kind):
            popup.close()
            {"postman": self._api_import_postman,
             "graphql": self._api_import_graphql}.get(kind, self._api_import_openapi)()
        for icon_txt, label, desc, kind in [
            ("📦", "Colección Postman", "Importar una colección Postman v2.1 (.json)", "postman"),
            ("📄", "Swagger / OpenAPI", "Importar una especificación OpenAPI v2/v3 o Swagger\n(.json o .yaml)", "openapi"),
            ("◢", "GraphQL", "Esquema GraphQL (SDL .graphql) o introspección\nde un endpoint", "graphql"),
        ]:
            card = self._choice_card(card_row, icon_txt, label, desc, ipadx=28, ipady=22, padx=20, desc_pady=(6, 20))
            def _mk_click(k=kind):
                def _fn(e=None): _pick(k)
                return _fn
            click_fn = _mk_click(); card.bind("<Button-1>", click_fn)
            for child in card.winfo_children(): child.bind("<Button-1>", click_fn)
            card.bind("<Enter>", lambda e, c=card: c.configure(highlightbackground=T["accent"]))
            card.bind("<Leave>", lambda e, c=card: c.configure(highlightbackground=T["border"]))
        self._popup_foot(popup, ("  Cancelar  ", popup.close, "flat"))

    def _api_export_popup(self):
        rows = self._ep_tree.get_children()
        if not rows:
            self._show_warn_popup("Exportar endpoints", "Sin endpoints — ejecute Vista previa primero."); return
        ops = [{"method": self._ep_tree.set(iid, "method"), "url": self._ep_tree.set(iid, "url"),
                "secured": self._ep_tree.set(iid, "secured"), "body": self._ep_tree.set(iid, "body")} for iid in rows]
        popup = self._create_popup("Exportar endpoints")
        self._popup_hdr(popup, "Exportar endpoints", icon="💾", subtitle=f"{len(ops)} endpoint(s)")
        body = tk.Frame(popup, bg=T["bg"]); body.pack(fill="both", expand=True)
        tk.Frame(body, bg=T["bg"]).pack(fill="both", expand=True)
        tk.Label(body, text="Elija el formato de exportación:", font=(_FUI, 13), bg=T["bg"], fg=T["muted"]).pack(pady=(0, 20))
        card_row = tk.Frame(body, bg=T["bg"]); card_row.pack(padx=60)
        tk.Frame(body, bg=T["bg"]).pack(fill="both", expand=True)
        fmt_var = tk.StringVar(value="CSV"); _cards = {}
        _FORMAT_META = [
            ("CSV", "📊", "Valores separados por comas\nExcel / Sheets"),
            ("JSON", "📋", "Arreglo JSON sin formato\nScripts / APIs"),
            ("YAML", "📄", "Formato YAML\nHerramientas OpenAPI"),
            ("Postman v2.1", "📦", "Colección Postman v2.1\nImportación directa en Postman"),
        ]
        def _refresh_cards(*_):
            for f, c in _cards.items():
                c.configure(highlightbackground=T["accent"] if f == fmt_var.get() else T["border"])
        for fmt, icon_txt, desc in _FORMAT_META:
            card = self._choice_card(card_row, icon_txt, fmt, desc, title_size=13, ipadx=20, ipady=14, padx=12, desc_pady=(6, 18))
            _cards[fmt] = card
            def _mk_click(f=fmt):
                def _click(e=None): fmt_var.set(f)
                return _click
            click_fn = _mk_click(); card.bind("<Button-1>", click_fn)
            for child in card.winfo_children(): child.bind("<Button-1>", click_fn)
            def _enter(e, c=card, f=fmt):
                if f != fmt_var.get(): c.configure(highlightbackground=T["accent_hi"])
            card.bind("<Enter>", _enter)
            card.bind("<Leave>", lambda e: _refresh_cards())
        fmt_var.trace_add("write", _refresh_cards); _refresh_cards()
        def _do_export():
            fmt = fmt_var.get(); popup.close(); self._api_export_converted_with(ops, fmt)
        self._popup_foot(popup, ("  Cancelar  ", popup.close, "flat"), ("💾  Exportar  ", _do_export, "accent"))

    def _api_preview_spec(self):
        src = self._api_spec_var.get().strip()
        if not src:
            self._show_warn_popup("Vista previa", "Configure una especificación primero."); return
        def _load_and_render():
            cfg = self._collect_api_cfg()
            opener, _, hdrs = _make_opener(cfg)
            spec = _api_load_spec(opener, hdrs, cfg, self._emit_log)
            if not spec or not isinstance(spec, dict):
                self._event_queue.put(("log","[api-preview] no se pudo cargar o parsear la especificación.")); return
            if "item" in spec and "paths" not in spec: fmt = "Colección Postman"
            elif spec.get("openapi","").startswith("3"): fmt = f"OpenAPI {spec.get('openapi','3.x')}"
            elif spec.get("swagger","").startswith("2"): fmt = f"Swagger {spec.get('swagger','2.x')}"
            else: fmt = "Formato desconocido"
            base = _api_base_url(spec, cfg, src)
            ops = _api_operations(spec, base or "https://example.com", src)
            self._event_queue.put(("api_preview", (fmt, ops, len(ops))))
        self._run_async(_load_and_render, label="vista previa de especificación")

    def _api_export_converted_with(self, ops, fmt):
        if fmt == "CSV":
            path = filedialog.asksaveasfilename(title="Exportar endpoints como CSV", defaultextension=".csv",
                initialfile="endpoints.csv", filetypes=[("CSV","*.csv"),("Todos","*.*")])
            if not path: return
            import csv
            with open(path,"w",newline="",encoding="utf-8") as f:
                w = csv.DictWriter(f, fieldnames=["method","url","secured","body"]); w.writeheader(); w.writerows(ops)
        elif fmt == "JSON":
            path = filedialog.asksaveasfilename(title="Exportar endpoints como JSON", defaultextension=".json",
                initialfile="endpoints.json", filetypes=[("JSON","*.json"),("Todos","*.*")])
            if not path: return
            Path(path).write_text(json.dumps(ops, indent=2), encoding="utf-8")
        elif fmt == "YAML":
            path = filedialog.asksaveasfilename(title="Exportar endpoints como YAML", defaultextension=".yaml",
                initialfile="endpoints.yaml", filetypes=[("YAML","*.yaml *.yml"),("Todos","*.*")])
            if not path: return
            lines = ["endpoints:\n"]
            for op in ops:
                lines += [f"  - method: {op['method']}\n", f"    url: '{op['url']}'\n",
                          f"    secured: '{op['secured']}'\n", f"    body: '{op['body']}'\n"]
            Path(path).write_text("".join(lines), encoding="utf-8")
        elif fmt == "Postman v2.1":
            path = filedialog.asksaveasfilename(title="Exportar como Colección Postman v2.1", defaultextension=".json",
                initialfile="endpoints_postman.json", filetypes=[("JSON / Postman","*.json"),("Todos","*.*")])
            if not path: return
            items = []
            for op in ops:
                url_parts = op["url"].split("://",1); raw_url = op["url"]
                items.append({"name": f"{op['method']} {raw_url}",
                              "request": {"method": op["method"], "header": [],
                                          "url": {"raw": raw_url,
                                                  "protocol": url_parts[0] if len(url_parts)>1 else "https",
                                                  "host": (url_parts[1].split("/")[0].split(".") if len(url_parts)>1 else []),
                                                  "path": (url_parts[1].split("/")[1:] if len(url_parts)>1 else [])},
                                          "description": f"Auth requerida: {op['secured']}  Tipo de cuerpo: {op['body']}"},
                              "response": []})
            collection = {"info": {"name":"Endpoints exportados",
                                   "schema":"https://schema.getpostman.com/json/collection/v2.1.0/collection.json"},
                          "item": items}
            Path(path).write_text(json.dumps(collection, indent=2), encoding="utf-8")
        else:
            self._show_warn_popup("Exportar endpoints", f"Formato desconocido: {fmt}"); return
        self._log_line(f"[api-export] {fmt} → {path}")
        self._show_info_popup("Exportación completada", f"Se guardaron {len(ops)} endpoint(s) en:\n{path}")

    def _collect_api_cfg(self) -> ApiConfig:
        v = self._api_cred_vars
        def _opt(s):
            s = (s or "").strip()
            return "" if s in ("(predeterminado)", "(ninguno)", "") else s
        return ApiConfig(
            spec_source=self._api_spec_var.get().strip(), base_url=self._api_base_var.get().strip(),
            auth_type=self._api_auth_var.get(), username=v["username"].get(), password=v["password"].get(),
            token=v["token"].get(), cookie=v["cookie"].get(), header_name=v["header_name"].get(),
            header_value=v["header_value"].get(), profile=self._api_profile_var.get(),
            verify_tls=bool(self._api_tls_var.get()), proxy=self._api_proxy_var.get(),
            probely_token=static_scanner.get_probely_key(),
            probely_auth_scheme=static_scanner.get_probely_auth_scheme(),
            probely_region="us",
            probely_api_base=(self._api_apibase_var.get().strip() or "https://api.probely.com"),
            probely_target_id=self._api_target_id_var.get().strip(),
            probely_reuse_by_url=bool(self._api_reuse_url_var.get()),
            probely_scan_profile=_opt(self._api_profile_var.get()),
            probely_max_wait_minutes=float(self._api_maxwait_var.get() or 180),
            probely_reduced_scopes=self._api_reduced_scopes_var.get(),
            probely_ignore_blackout=bool(self._api_ignore_blackout_var.get()),
            probely_compliance_report=_opt(self._api_report_var.get()),
            probely_protect_session=bool(self._api_protect_session_var.get()),
            probely_login_sequence_path=self._api_seq_path_var.get().strip(),
            probely_check_login=bool(self._api_check_login_var.get()),
            probely_require_verified=bool(self._api_require_verified_var.get()),
            probely_api_schema_type=_opt(self._api_schema_type_var.get()),
            probely_api_login_url=self._api_login_url_var.get().strip(),
            probely_api_login_payload=self._api_login_payload_var.get(),
            probely_api_login_media_type=(self._api_login_media_var.get() or "application/json"),
            probely_api_login_token_field=self._api_login_token_field_var.get().strip(),
            probely_api_login_token_param=(self._api_login_token_param_var.get().strip() or "Authorization"),
            probely_api_login_token_prefix=self._api_login_token_prefix_var.get().strip(),
            probely_api_login_place=(self._api_login_place_var.get() or "header"),
            probely_orchestrate=bool(self._dast_orch_var.get()),
            probely_pool_size=5,
            probely_slot_cooldown_minutes=float(self._dast_cooldown_var.get() or 60),
            probely_ledger_path=str(getattr(self, "_reports_root", ".")))

    def _setup_api_field_persistence(self):
        delay = [None]
        def _on_change(*_):
            if delay[0] is not None:
                try: self.after_cancel(delay[0])
                except Exception: pass
            delay[0] = self.after(800, self._save_settings)
        for v in [self._api_spec_var, self._api_base_var, self._api_auth_var,
                  self._api_profile_var, self._api_tls_var, self._api_proxy_var,
                  self._api_region_var, self._api_apibase_var, self._api_target_id_var,
                  self._api_reuse_url_var, self._api_maxwait_var, self._api_reduced_scopes_var,
                  self._api_ignore_blackout_var, self._api_report_var, self._api_protect_session_var,
                  self._api_seq_path_var, self._api_check_login_var,
                  self._api_require_verified_var, self._api_schema_type_var,
                  self._api_login_url_var, self._api_login_payload_var, self._api_login_media_var,
                  self._api_login_token_field_var, self._api_login_token_param_var,
                  self._api_login_token_prefix_var, self._api_login_place_var]:
            try: v.trace_add("write", _on_change)
            except Exception: pass
        for k, v in self._api_cred_vars.items():
            if k not in self._SECRET_KEYS:
                try: v.trace_add("write", _on_change)
                except Exception: pass

    def _restore_api_fields(self):
        saved = getattr(self, "_saved_api_fields", None)
        if not isinstance(saved, dict): return
        try:
            if saved.get("spec"):         self._api_spec_var.set(saved["spec"])
            if "base"     in saved:       self._api_base_var.set(saved["base"])
            if saved.get("auth"):         self._api_auth_var.set(saved["auth"])
            if saved.get("profile"):
                _p = saved["profile"]
                _p = {"passive": "(predeterminado)", "active": "full"}.get(_p, _p)
                self._api_profile_var.set(_p)
            if "tls"      in saved:       self._api_tls_var.set(bool(saved["tls"]))
            if "proxy"    in saved:       self._api_proxy_var.set(saved["proxy"])
            for k, val in (saved.get("creds") or {}).items():
                if k in self._api_cred_vars and k not in self._SECRET_KEYS:
                    self._api_cred_vars[k].set(str(val))
            pb = saved.get("probely") or {}
            if pb:
                _m = {
                    "region": self._api_region_var, "apibase": self._api_apibase_var,
                    "target_id": self._api_target_id_var, "reduced": self._api_reduced_scopes_var,
                    "report": self._api_report_var, "seq_path": self._api_seq_path_var,
                }
                for k, var in _m.items():
                    if k in pb: var.set(str(pb[k]))
                if "reuse_url" in pb:       self._api_reuse_url_var.set(bool(pb["reuse_url"]))
                if "maxwait" in pb:         self._api_maxwait_var.set(int(pb["maxwait"]))
                if "ignore_blackout" in pb: self._api_ignore_blackout_var.set(bool(pb["ignore_blackout"]))
                if "protect" in pb:        self._api_protect_session_var.set(bool(pb["protect"]))
                if "check_login" in pb:    self._api_check_login_var.set(bool(pb["check_login"]))
        except Exception:
            pass
