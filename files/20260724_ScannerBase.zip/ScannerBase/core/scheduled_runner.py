from __future__ import annotations
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

SCRIPT_DIR = Path(__file__).resolve().parent
DATA_DIR   = SCRIPT_DIR / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)

IS_WIN   = os.name == "nt"
IS_MAC   = sys.platform == "darwin"
IS_LINUX = not IS_WIN and not IS_MAC

_LOG_PATH = DATA_DIR / "scheduled_runner.log"
_LOG_MAX_BYTES = 512_000
_GUI_PID_FILE = DATA_DIR / ".gui_running.pid"
_OWNER_FILE   = DATA_DIR / ".scan_engine_owner.pid"     # who's currently allowed to fire schedules
_RUNNER_LOCK  = DATA_DIR / ".scheduler_runner.lock"      # this script's own re-entrancy guard


def _log(msg: str) -> None:
    line = f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {msg}"
    print(line, flush=True)
    try:
        if _LOG_PATH.exists() and _LOG_PATH.stat().st_size > _LOG_MAX_BYTES:
            # Keep the tail rather than growing forever — this file is never
            # rotated by anything else since it only exists for this script.
            tail = _LOG_PATH.read_text(encoding="utf-8", errors="replace")[-_LOG_MAX_BYTES // 2:]
            _LOG_PATH.write_text(tail, encoding="utf-8")
        with open(_LOG_PATH, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


# ── PID liveness / lightweight cross-process locks ────────────────────────

def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    if IS_WIN:
        try:
            out = os.popen(f'tasklist /FI "PID eq {pid}" /NH').read()
            return str(pid) in out
        except Exception:
            return False
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True  # exists, just owned by someone else
    except Exception:
        return False


def _read_pid(path: Path) -> Optional[int]:
    try:
        return int(path.read_text(encoding="utf-8").strip())
    except Exception:
        return None


def _gui_is_running() -> bool:
    pid = _read_pid(_GUI_PID_FILE)
    return bool(pid and _pid_alive(pid))


def _owner_is_foreign_and_alive() -> bool:
    """True if some OTHER live process (normally the GUI) currently owns the
    schedule-firing role. The GUI claims this for its whole open session
    (see gui_schedule_tab.py); we only ever hold it transiently, tick by
    tick, and only when the GUI isn't running."""
    pid = _read_pid(_OWNER_FILE)
    return bool(pid and pid != os.getpid() and _pid_alive(pid))


def _claim_owner() -> bool:
    if _owner_is_foreign_and_alive():
        return False
    try:
        _OWNER_FILE.write_text(str(os.getpid()), encoding="utf-8")
        return True
    except Exception:
        return False


def _release_owner() -> None:
    try:
        if _read_pid(_OWNER_FILE) == os.getpid():
            _OWNER_FILE.unlink(missing_ok=True)
    except Exception:
        pass


def _acquire_runner_lock() -> bool:
    existing = _read_pid(_RUNNER_LOCK)
    if existing and _pid_alive(existing):
        return False  # a previous tick is still running (long scan) — skip this one
    try:
        _RUNNER_LOCK.write_text(str(os.getpid()), encoding="utf-8")
        return True
    except Exception:
        return False


def _release_runner_lock() -> None:
    try:
        if _read_pid(_RUNNER_LOCK) == os.getpid():
            _RUNNER_LOCK.unlink(missing_ok=True)
    except Exception:
        pass


# ── Phase 1 helpers ─────────────────────────────────────────────────────

def _resolve_reports_root() -> Path:
    """Mirrors ScannerApp._load_settings()'s reports_root resolution without
    needing the GUI/Tk — same settings file, same fallback."""
    default = SCRIPT_DIR / "Reports"
    settings_file = DATA_DIR / ".scanner_settings.json"
    if not settings_file.exists():
        return default
    try:
        data = json.loads(settings_file.read_text(encoding="utf-8"))
        candidate = data.get("reports_root")
        if candidate:
            p = Path(candidate)
            p.mkdir(parents=True, exist_ok=True)
            return p
    except Exception:
        pass
    return default


def _find_due_schedules(reports_root: Path):
    """Cheap, Tk-free check. Returns (store, due_list)."""
    sys.path.insert(0, str(SCRIPT_DIR))
    import gui_schedule_tab as sched_mod  # tkinter import only, no display needed
    store = sched_mod.ScheduleStore(reports_root)
    now = sched_mod._now()
    due = []
    for s in store.list_schedules():
        if not s.get("enabled"):
            continue
        nxt = s.get("next_run_at")
        try:
            is_due = bool(nxt) and __import__("datetime").datetime.fromisoformat(nxt) <= now
        except Exception:
            is_due = True
        if is_due:
            due.append(s)
    due.sort(key=lambda s: s.get("next_run_at") or "")
    return store, sched_mod, due


# ── Phase 2: real (hidden) app + actual _do_scan() ────────────────────────

def _ensure_linux_display() -> Optional[object]:
    """Returns an Xvfb Popen handle if we started one (caller must terminate
    it when done), or None if a real display was found / not needed."""
    if not IS_LINUX:
        return None
    if os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"):
        return None
    import scheduler_os
    found = scheduler_os.discover_linux_display()
    if found:
        os.environ["DISPLAY"] = found
        _log(f"[scheduler] usando sesión gráfica detectada en {found}")
        return None
    _log("[scheduler] sin sesión gráfica detectable — intentando Xvfb…")
    proc = scheduler_os.try_start_xvfb(DATA_DIR, log=_log)
    if not proc:
        _log("[scheduler] sin pantalla disponible (ni sesión activa ni Xvfb) — "
             "se omite este tick. Este horario se ejecutará normalmente la próxima "
             "vez que abras la aplicación.")
    return proc


def _fire_schedule(app, sched: dict) -> bool:
    app_rec = app._inv_store.get_app(sched.get("app_id", ""))
    if not app_rec:
        _log(f"[scheduler] la aplicación '{sched.get('app_name', '?')}' ya no existe en el "
             "inventario — se omite esta ejecución")
        return False
    app._active_app = app_rec
    app._target_var.set(app_rec.get("target_path", ""))
    app._dast_url_var.set(app_rec.get("dast_url", ""))
    app._api_spec_var.set(app_rec.get("api_spec", ""))
    for k, v in app._scan_vars.items():
        v.set(k in (sched.get("stages") or []))
    app._auto_open = False
    try:
        import audit_log
        audit_log.write_event(app._reports_root, "schedule_fire_headless", actor=app._user,
                               app=app_rec.get("name", ""), schedule_id=sched.get("id"),
                               stages=sched.get("stages"), log=_log)
    except Exception:
        pass
    _log(f"[scheduler] disparando escaneo programado (app cerrada) para '{app_rec.get('name')}' "
         f"({'+'.join(sched.get('stages') or [])})")
    try:
        app._do_scan()
        return True
    except Exception as e:
        _log(f"[scheduler] error inesperado durante el escaneo programado: {e!r}")
        return False


def _run_due(reports_root: Path, store, sched_mod, due: list) -> None:
    xvfb_proc = _ensure_linux_display()
    if IS_LINUX and not (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")):
        return  # already logged inside _ensure_linux_display

    try:
        sys.path.insert(0, str(SCRIPT_DIR))
        import INICIAR_SnykScannerGUI as app_main
    except Exception as e:
        _log(f"[scheduler] no se pudo importar la aplicación: {e!r}")
        if xvfb_proc: xvfb_proc.terminate()
        return

    try:
        err = None
        try:
            app_main._load_runtime(progress=None)
        except Exception as e:
            err = e
        if err is not None:
            _log(f"[scheduler] no se pudieron preparar las dependencias del motor: {err!r} — "
                 "se omite este tick.")
            return

        import tkinter as tk
        try:
            app = app_main.ScannerApp(boot_warnings=[], headless=True)
        except Exception as e:
            _log(f"[scheduler] no se pudo iniciar el motor de la aplicación en modo oculto: {e!r}")
            return

        try:
            for sched in due:
                if not _claim_owner():
                    _log("[scheduler] la aplicación se abrió durante este ciclo — se cede el "
                         "control al motor interno; se detienen los horarios restantes de este tick.")
                    break
                try:
                    ok = _fire_schedule(app, sched)
                    now = datetime.now()
                    sched["last_run_at"] = now.isoformat(timespec="seconds")
                    sched["last_run_status"] = "ok" if ok else "error"
                    sched["next_run_at"] = sched_mod._next_run_from(sched, now).isoformat(timespec="seconds")
                    store.save_schedule(sched)
                finally:
                    _release_owner()
        finally:
            try: app.destroy()
            except Exception: pass
    finally:
        if xvfb_proc:
            try: xvfb_proc.terminate()
            except Exception: pass


def main() -> int:
    if "--tick" not in sys.argv and "--force" not in sys.argv:
        print("Uso: scheduled_runner.py --tick   (invocado por el Programador de tareas / "
              "launchd / cron — no se ejecuta manualmente salvo pruebas con --force)")
        return 2

    if _gui_is_running():
        return 0  # the open GUI's own in-process engine owns scheduling right now

    if not _acquire_runner_lock():
        _log("[scheduler] un tick anterior sigue en ejecución (escaneo largo en curso) — se omite éste.")
        return 0

    try:
        reports_root = _resolve_reports_root()
        store, sched_mod, due = _find_due_schedules(reports_root)
        if not due:
            return 0
        _log(f"[scheduler] {len(due)} horario(s) vencido(s) — iniciando motor…")
        _run_due(reports_root, store, sched_mod, due)
        _log("[scheduler] tick finalizado.")
        return 0
    except Exception as e:
        _log(f"[scheduler] error no controlado en el tick: {e!r}")
        return 1
    finally:
        _release_runner_lock()


if __name__ == "__main__":
    sys.exit(main())
