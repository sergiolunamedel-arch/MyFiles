from __future__ import annotations

import json
import os
import threading
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Optional

_AUDIT_DIRNAME = ".audit"
_lock = threading.Lock()


def _audit_dir(reports_root) -> Path:
    d = Path(reports_root) / _AUDIT_DIRNAME
    d.mkdir(parents=True, exist_ok=True)
    return d


def _audit_file(reports_root) -> Path:
    return _audit_dir(reports_root) / f"audit-{datetime.now():%Y%m}.jsonl"


def write_event(reports_root, event: str, *, actor: str = "", app: str = "",
                 log: Optional[Callable[[str], None]] = None, **fields: Any) -> None:
    record = {
        "ts": datetime.now().isoformat(timespec="seconds"),
        "event": event,
        "actor": actor or os.environ.get("USERNAME") or os.environ.get("USER") or "",
        "app": app,
        **fields,
    }
    try:
        line = json.dumps(record, default=str)
    except Exception as e:
        if log: log(f"[auditoría] no se pudo serializar el evento {event!r}: {e!r}")
        return
    try:
        with _lock:
            with open(_audit_file(reports_root), "a", encoding="utf-8") as f:
                f.write(line + "\n")
    except Exception as e:
        if log: log(f"[auditoría] no se pudo escribir el evento {event!r}: {e!r}")
