from __future__ import annotations

"""gui_scans_tab.py — Escaneos guardados: modelo de datos, persistencia,
popup de edición, panel/lista de la pestaña "📦 Escaneos", y el mixin que
integra todo esto en CertDiscoveryApp — franja de mini-tabs en el ribbon,
carga/cambio/cierre de escaneo activo, y la consola por-escaneo.

Estructuralmente es el mismo patrón que gui_apps_tab.py del escáner Snyk
(AppInventoryStore / AppProfileEditor / AppInventoryTab / _AppsTabMixin),
adaptado a lo que un "escaneo" significa aquí: una configuración de
descubrimiento de certificados que el operador define y guarda (targets,
puertos, archivos, CT, etc. — los mismos campos de la pestaña "Descubrir"),
no una aplicación de negocio.

Este módulo es "wireado" por CertDiscoveryApp igual que gui_apps_tab.py lo es
por ScannerApp (ver _wire_mixin_globals en cert_discovery_gui.py): T, _FUI,
_FMONO, APP_BRAND_NAME, ToggleSwitch y el resto de la infraestructura de
chrome/popups compartida llegan como globals de módulo inyectados por el
host antes de que cualquier método de aquí corra — por eso se referencian
directamente sin import.
"""

import json
import re
import threading
from datetime import datetime, timedelta
from pathlib import Path
from tkinter import ttk, filedialog
from typing import Optional
import tkinter as tk

# ── Modelo de datos ────────────────────────────────────────────────────── #

_RISK_COLORS_LIGHT = {
    "Crítico": "#c8102e", "Alto": "#e26020", "Medio": "#d4a017",
    "Bajo": "#1a7a4a", "Ninguno": "#5a6475",
}
_RISK_COLORS_DARK = {
    "Crítico": "#f08090", "Alto": "#f4a460", "Medio": "#f0d060",
    "Bajo": "#5fe0a0", "Ninguno": "#8892a4",
}

_STARTTLS_VALUES = ["off", "auto", "smtp", "imap", "pop3", "ftp", "ldap", "postgres"]

_EMPTY_SCAN: dict = {
    # ── Identidad ─────────────────────────────────────────────────────── #
    "id":            "",
    "name":          "",
    "description":   "",
    "owner":         "",
    "created_at":    "",
    "updated_at":    "",
    # ── Red activa ────────────────────────────────────────────────────── #
    "targets":       "",
    "ports":         "443,8443",
    "starttls":      "off",
    "concurrency":   "200",
    "timeout":       "3.0",
    "exclude":       "",
    "check_trust":   False,
    "resolve_ptr":   False,
    "check_revocation": False,
    "prefilter":     True,
    "sni":           "",
    # ── Transparencia de certificados (CT) ───────────────────────────── #
    "ct_domain":     "",
    "ct_scan":       True,
    # ── Sistema de archivos / almacén de Windows ─────────────────────── #
    "files":         "",
    "winstore":      False,
    # ── Inventario vivo y programación ───────────────────────────────── #
    "live":          True,
    "baseline":      "",
    "schedule_minutes": "0",
    # ── Resultados acumulados (se actualizan tras cada corrida) ──────── #
    "last_scan":     None,          # ISO datetime string
    "last_status":   "",            # ok / error / cancelado
    "cert_total":    0,
    "findings_critical": 0,
    "findings_high":     0,
    "findings_medium":   0,
    "findings_low":      0,
    "findings_total":    0,
    "risk_tier":     "Ninguno",
    # ── Historial: [{"ts","total_certs","critical","high","medium","low","total"}] ─
    "scan_history":  [],
    # ── Notas ─────────────────────────────────────────────────────────── #
    "notes":         "",
}


def _slugify(name: str) -> str:
    s = name.strip().lower()
    s = re.sub(r"[^\w\s-]", "", s)
    s = re.sub(r"[\s_-]+", "_", s)
    return s[:48] or "scan"


def _risk_tier(critical: int, high: int, medium: int, low: int) -> str:
    if critical: return "Crítico"
    if high:     return "Alto"
    if medium:   return "Medio"
    if low:      return "Bajo"
    return "Ninguno"


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%dT%H:%M:%S")


# ── Persistencia ──────────────────────────────────────────────────────── #

class ScanConfigStore:
    """Almacén JSON, uno por escaneo guardado, con un índice de orden.
    Mismo patrón que AppInventoryStore del escáner Snyk."""

    def __init__(self, root_dir: Path):
        self._lock = threading.Lock()
        self.dir = Path(root_dir)
        self.dir.mkdir(parents=True, exist_ok=True)
        self._index_path = self.dir / "_index.json"

    def _read_index(self) -> list[str]:
        try:
            if self._index_path.exists():
                return json.loads(self._index_path.read_text("utf-8"))
        except Exception:
            pass
        ids = sorted(p.stem for p in self.dir.glob("*.json") if p.name != "_index.json")
        self._write_index(ids)
        return ids

    def _write_index(self, ids: list[str]) -> None:
        self._index_path.write_text(json.dumps(ids, indent=2), "utf-8")

    def _cfg_path(self, scan_id: str) -> Path:
        return self.dir / f"{scan_id}.json"

    def log_path(self, scan_id: str) -> Path:
        """Ruta del archivo de bitácora persistente de este escaneo — vive
        junto al .json, se abre en modo apéndice desde _ScansTabMixin y
        conserva el historial completo aunque se cierre la pestaña o se
        reinicie la app (ver _scan_log / _load_scan_log_tail)."""
        return self.dir / f"{scan_id}.log"

    def list_configs(self) -> list[dict]:
        with self._lock:
            ids = self._read_index()
            out = []
            for sid in ids:
                p = self._cfg_path(sid)
                if p.exists():
                    try: out.append(json.loads(p.read_text("utf-8")))
                    except Exception: pass
            return out

    def get_config(self, scan_id: str) -> Optional[dict]:
        with self._lock:
            p = self._cfg_path(scan_id)
            if p.exists():
                try: return json.loads(p.read_text("utf-8"))
                except Exception: pass
        return None

    def save_config(self, cfg: dict) -> None:
        with self._lock:
            if not cfg.get("id"):
                cfg["id"] = _slugify(cfg.get("name", "scan"))
            existing = self._read_index()
            if cfg["id"] not in existing:
                base = cfg["id"]; n = 1
                while (self.dir / f"{cfg['id']}.json").exists():
                    cfg["id"] = f"{base}_{n}"; n += 1
                existing.append(cfg["id"])
                self._write_index(existing)
            cfg["updated_at"] = _now()
            if not cfg.get("created_at"):
                cfg["created_at"] = cfg["updated_at"]
            self._cfg_path(cfg["id"]).write_text(
                json.dumps(cfg, indent=2, ensure_ascii=False), "utf-8")

    def delete_config(self, scan_id: str) -> None:
        with self._lock:
            ids = self._read_index()
            if scan_id in ids:
                ids.remove(scan_id); self._write_index(ids)
            p = self._cfg_path(scan_id)
            if p.exists(): p.unlink()

    def record_result(self, scan_id: str, *, total_certs: int, critical: int, high: int,
                       medium: int, low: int, status: str) -> None:
        cfg = self.get_config(scan_id)
        if cfg is None:
            return
        total = critical + high + medium + low
        cfg["last_scan"]         = _now()
        cfg["last_status"]       = status
        cfg["cert_total"]        = int(total_certs)
        cfg["findings_critical"] = int(critical)
        cfg["findings_high"]     = int(high)
        cfg["findings_medium"]   = int(medium)
        cfg["findings_low"]      = int(low)
        cfg["findings_total"]    = int(total)
        cfg["risk_tier"]         = _risk_tier(critical, high, medium, low)
        cfg.setdefault("scan_history", []).append({
            "ts": cfg["last_scan"], "total_certs": int(total_certs),
            "critical": int(critical), "high": int(high),
            "medium": int(medium), "low": int(low), "total": int(total),
        })
        cfg["scan_history"] = cfg["scan_history"][-50:]
        self.save_config(cfg)


# NOTE: T (paleta), _FUI/_FMONO (fuentes), APP_BRAND_NAME, ToggleSwitch, y las
# ayudas de chrome de popups (_apply_panel_chrome / _monitor_wh /
# _popup_follow_parent / _bind_popup_close / _popup_dialog_guard) llegan de
# cert_discovery_gui.py vía _wire_mixin_globals() — ver la nota del módulo.

# ── Popup: editor de escaneo guardado ───────────────────────────────────── #

class ScanConfigEditor(tk.Toplevel):
    """Modal para crear/editar una configuración de escaneo guardada.
    Deja el resultado en .result (None si se canceló)."""

    def __init__(self, master, store: ScanConfigStore, cfg: Optional[dict] = None):
        super().__init__(master)
        self._store = store
        self._cfg = dict(_EMPTY_SCAN)
        if cfg:
            self._cfg.update(cfg)
        self.result: Optional[dict] = None
        self.auto_load_var = tk.BooleanVar(value=True)

        self.transient(master)
        master.update_idletasks()
        mw, mh = _monitor_wh(master)
        w, h = int(mw * 0.78), int(mh * 0.82)
        px, py = master.winfo_rootx(), master.winfo_rooty()
        pw, ph = master.winfo_width(), master.winfo_height()
        self.geometry(f"{w}x{h}+{px + (pw - w)//2}+{py + (ph - h)//2}")
        self.overrideredirect(True)
        self.update_idletasks(); self.lift(); self.focus_force()
        try: self.grab_set()
        except tk.TclError: pass
        _bind_ids: dict = {}
        _close = _bind_popup_close(self, master, _bind_ids)
        _bind_ids.update(_popup_follow_parent(self, master))

        content = _apply_panel_chrome(self)
        content.close = _close

        title_text = "✏  Editar escaneo guardado" if cfg else "📦  Nuevo escaneo guardado"
        master._popup_hdr(content, title_text,
                          subtitle="El Nombre es obligatorio — el resto queda igual que la "
                                   "pestaña Descubrir.", on_close=_close)

        canvas = tk.Canvas(content, bg=T["bg"], highlightthickness=0, bd=0)
        vsb = ttk.Scrollbar(content, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        canvas.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        holder = tk.Frame(canvas, bg=T["bg"])
        win_id = canvas.create_window((0, 0), window=holder, anchor="nw")
        holder.bind("<Configure>", lambda _: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(win_id, width=e.width))
        def _wheel(e): canvas.yview_scroll(int(-e.delta / 120), "units")
        canvas.bind("<Enter>", lambda _: canvas.bind_all("<MouseWheel>", _wheel))
        canvas.bind("<Leave>", lambda _: canvas.unbind_all("<MouseWheel>"))
        pad = tk.Frame(holder, bg=T["bg"], padx=7, pady=4)
        pad.pack(fill="both", expand=True)

        self._vars: dict[str, tk.Variable] = {}

        def sv(key, default=""):
            v = tk.StringVar(value=self._cfg.get(key, default)); self._vars[key] = v; return v
        def bv(key, default=False):
            v = tk.BooleanVar(value=bool(self._cfg.get(key, default))); self._vars[key] = v; return v

        v_name    = sv("name")
        v_desc    = sv("description")
        v_owner   = sv("owner")
        v_targets = sv("targets")
        v_ports   = sv("ports", "443,8443")
        v_tls     = sv("starttls", "off")
        v_conc    = sv("concurrency", "200")
        v_timeout = sv("timeout", "3.0")
        v_exclude = sv("exclude")
        v_trust   = bv("check_trust")
        v_ptr     = bv("resolve_ptr")
        v_ocsp    = bv("check_revocation")
        v_prefilter = bv("prefilter", True)
        v_sni     = sv("sni")
        v_ct      = sv("ct_domain")
        v_ctscan  = bv("ct_scan", True)
        v_files   = sv("files")
        v_winstore = bv("winstore")
        v_live    = bv("live", True)
        v_baseline = sv("baseline")
        v_sched   = sv("schedule_minutes", "0")
        v_notes   = sv("notes")

        def section(title: str) -> tk.Frame:
            sh = tk.Frame(pad, bg=T["surface3"], padx=3, pady=1)
            sh.pack(fill="x", pady=(3, 2))
            master._lbl(sh, text=title, size=12, bold=True, bg=T["surface3"], fg=T["text"]).pack(side="left")
            shadow_wrap = master._shadow_wrap(pad)
            shadow_wrap.pack(fill="x", pady=(0, 1))
            inner = tk.Frame(shadow_wrap, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"])
            inner.pack(fill="both", expand=True, padx=(0, _CARD_SHADOW_OFFSET), pady=(0, _CARD_SHADOW_OFFSET))
            body_f = tk.Frame(inner, bg=T["panel_bg"], padx=4, pady=2)
            body_f.pack(fill="both", expand=True)
            return body_f

        def row(parent, label: str, widget_factory, tip: str = "") -> tk.Widget:
            r = tk.Frame(parent, bg=T["panel_bg"]); r.pack(fill="x", pady=1)
            master._lbl(r, text=label, size=10, bg=T["panel_bg"], fg=T["muted"],
                       anchor="w", width=20).pack(side="left")
            w = widget_factory(r)
            w.pack(side="left", fill="x", expand=True)
            if tip:
                master._lbl(parent, text=tip, size=10, bg=T["panel_bg"], fg=T["muted"],
                           anchor="w").pack(fill="x", padx=(122, 0))
            return w

        def entry(parent, var, **kw) -> ttk.Entry:
            return ttk.Entry(parent, textvariable=var, **kw)

        def combo(parent, var, values) -> ttk.Combobox:
            return ttk.Combobox(parent, textvariable=var, values=values, state="readonly", width=14)

        def toggle_row(parent, label, var):
            r = tk.Frame(parent, bg=T["panel_bg"]); r.pack(fill="x", pady=1)
            ToggleSwitch(r, text=label, variable=var).pack(side="left")

        def browse_row(parent, label, var, *, folder=True):
            r = tk.Frame(parent, bg=T["panel_bg"]); r.pack(fill="x", pady=1)
            master._lbl(r, text=label, size=10, bg=T["panel_bg"], fg=T["muted"],
                       anchor="w", width=20).pack(side="left")
            e = ttk.Entry(r, textvariable=var); e.pack(side="left", fill="x", expand=True)
            def pick():
                with _popup_dialog_guard(self):
                    p = (filedialog.askdirectory(parent=self) if folder
                         else filedialog.askopenfilename(parent=self,
                              filetypes=[("JSON", "*.json"), ("Todo", "*.*")]))
                if p: var.set(p)
            master._icon_square_btn(r, "…", pick).pack(side="left", padx=(2, 0))

        # ── Identidad ──────────────────────────────────────────────────── #
        s0 = section("🏷  IDENTIDAD")
        row(s0, "Nombre",       lambda p: entry(p, v_name))
        row(s0, "Descripción",  lambda p: entry(p, v_desc))
        row(s0, "Responsable",  lambda p: entry(p, v_owner))

        # ── Red activa ─────────────────────────────────────────────────── #
        s1 = section("🌐  RED ACTIVA · handshake TLS / STARTTLS")
        row(s1, "Objetivos", lambda p: entry(p, v_targets),
            "CIDR · rango (10.0.0.1-50) · IP · host, coma-separado")
        row(s1, "Puertos",   lambda p: entry(p, v_ports), "443,8443,25,587,143,…")
        row(s1, "STARTTLS",  lambda p: combo(p, v_tls, _STARTTLS_VALUES))
        cr = tk.Frame(s1, bg=T["panel_bg"]); cr.pack(fill="x", pady=1)
        master._lbl(cr, text="Concurrencia", size=10, bg=T["panel_bg"], fg=T["muted"],
                   anchor="w", width=20).pack(side="left")
        ttk.Entry(cr, textvariable=v_conc, width=8).pack(side="left")
        master._lbl(cr, text="  Timeout (s)", size=10, bg=T["panel_bg"], fg=T["muted"]).pack(side="left", padx=(8, 2))
        ttk.Entry(cr, textvariable=v_timeout, width=6).pack(side="left")
        row(s1, "Excluir", lambda p: entry(p, v_exclude), "IP / CIDR / host / puerto a omitir")
        toggle_row(s1, "Validar cadena de confianza (2º handshake)", v_trust)
        toggle_row(s1, "Resolver PTR inverso", v_ptr)
        toggle_row(s1, "Comprobar revocación (OCSP)", v_ocsp)
        toggle_row(s1, "Pre-filtrar puertos abiertos antes del handshake", v_prefilter)
        row(s1, "SNI (vhosts)", lambda p: entry(p, v_sni), "hostnames extra a probar por IP")

        # ── CT / archivos / Windows ────────────────────────────────────── #
        s2 = section("🔎  TRANSPARENCIA DE CERTIFICADOS · crt.sh")
        row(s2, "Dominio CT", lambda p: entry(p, v_ct), "ej. bancobase.com")
        toggle_row(s2, "Resolver y escanear activamente los hosts hallados", v_ctscan)

        s3 = section("🗂  ARCHIVOS Y ALMACÉN DE WINDOWS")
        browse_row(s3, "Directorio", v_files, folder=True)
        toggle_row(s3, "Leer almacén de certificados de Windows (MY · CA · ROOT)", v_winstore)

        # ── Inventario vivo / programación ─────────────────────────────── #
        s4 = section("🕒  INVENTARIO VIVO Y PROGRAMACIÓN")
        toggle_row(s4, "Usar inventario vivo (baseline automático + guardar)", v_live)
        browse_row(s4, "Baseline manual", v_baseline, folder=False)
        sr = tk.Frame(s4, bg=T["panel_bg"]); sr.pack(fill="x", pady=1)
        master._lbl(sr, text="Repetir cada", size=10, bg=T["panel_bg"], fg=T["muted"],
                   anchor="w", width=20).pack(side="left")
        ttk.Entry(sr, textvariable=v_sched, width=6).pack(side="left")
        master._lbl(sr, text=" minutos (0 = una sola vez)", size=10, bg=T["panel_bg"],
                   fg=T["muted"]).pack(side="left", padx=(4, 0))

        s5 = section("📝  NOTAS")
        notes_txt = tk.Text(s5, height=3, font=(_FUI, 10), bg=T["surface2"], fg=T["text"],
                            insertbackground=T["text"], relief="flat", wrap="word")
        notes_txt.pack(fill="x", pady=1)
        if v_notes.get(): notes_txt.insert("1.0", v_notes.get())

        def _save():
            name = v_name.get().strip()
            if not name:
                try: self._status_lbl.config(text="⚠  El Nombre es obligatorio.")
                except Exception: pass
                return
            a = dict(self._cfg)
            a["name"]        = name
            a["description"] = v_desc.get().strip()
            a["owner"]       = v_owner.get().strip()
            a["targets"]     = v_targets.get().strip()
            a["ports"]       = v_ports.get().strip()
            a["starttls"]    = v_tls.get()
            a["concurrency"] = v_conc.get().strip()
            a["timeout"]     = v_timeout.get().strip()
            a["exclude"]     = v_exclude.get().strip()
            a["check_trust"] = bool(v_trust.get())
            a["resolve_ptr"] = bool(v_ptr.get())
            a["check_revocation"] = bool(v_ocsp.get())
            a["prefilter"]   = bool(v_prefilter.get())
            a["sni"]         = v_sni.get().strip()
            a["ct_domain"]   = v_ct.get().strip()
            a["ct_scan"]     = bool(v_ctscan.get())
            a["files"]       = v_files.get().strip()
            a["winstore"]    = bool(v_winstore.get())
            a["live"]        = bool(v_live.get())
            a["baseline"]    = v_baseline.get().strip()
            a["schedule_minutes"] = v_sched.get().strip()
            a["notes"]       = notes_txt.get("1.0", "end").strip()
            if not a.get("id"):
                a["id"] = _slugify(name)
            self._store.save_config(a)
            self.result = a
            _close()

        footer_bar, self._status_lbl = master._popup_foot(
            content, ("  Cancelar  ", _close, "flat"), ("💾  Guardar escaneo", _save, "accent"),
            with_status=True)
        _toggle_row = tk.Frame(footer_bar, bg=T["panel_bg"])
        _toggle_row.pack(fill="x", pady=(2, 0), before=self._status_lbl)
        ToggleSwitch(_toggle_row, text="Cargar escaneo", variable=self.auto_load_var).pack(side="right")

        try: self.grab_set()
        except tk.TclError: pass
        self.focus_force()


# ── Pestaña "📦 Escaneos" (lista + detalle) ─────────────────────────────── #

class ScanConfigDashboard:
    def __init__(self, parent: tk.Frame, master: tk.Tk, store: ScanConfigStore, on_load=None):
        self._parent = parent
        self._master = master
        self._store = store
        self._on_load = on_load
        self._current: Optional[dict] = None
        self._build()

    def _build(self):
        hdr = tk.Frame(self._parent, bg=T["panel_bg"], padx=4, pady=2,
                       highlightthickness=1, highlightbackground=T["border"])
        self._title_hdr_frame = hdr
        self._title_lbl = self._master._lbl(hdr, text="", size=12, bold=True,
                                            bg=T["panel_bg"], fg=T["text"])
        self._title_lbl.pack(side="left")

        toolbar = tk.Frame(self._parent, bg=T["bg"], padx=4, pady=2)
        toolbar.pack(fill="x")
        self._title_hdr_anchor = toolbar
        self._update_title_label(self._current)

        def _vsep():
            tk.Frame(toolbar, bg=T["border"], width=1).pack(side="left", fill="y", padx=2, pady=1)

        self._build_dashboard(toolbar)
        _vsep()

        self._load_btn = self._master._btn(toolbar, "📂  Cargar", self._load_selected, kind="accent")
        self._load_btn.pack(side="left", padx=(0, 2))
        for txt, cmd in [("+ Nuevo", self._new_cfg), ("✏  Editar", self._edit_cfg),
                         ("🗑  Eliminar", self._delete_cfg)]:
            self._master._btn(toolbar, txt, cmd, kind="accent").pack(side="left", padx=(0, 2))

        search_frame = tk.Frame(toolbar, bg=T["bg"]); search_frame.pack(side="left", fill="x", expand=True)
        self._master._lbl(search_frame, text="🔎", size=10, bg=T["bg"], fg=T["muted"]).pack(side="left")
        PLACEHOLDER = "filtrar por nombre, objetivos o nivel de riesgo"
        self._search_var = tk.StringVar(value=PLACEHOLDER)
        self._search_placeholder = True
        se = ttk.Entry(search_frame, textvariable=self._search_var, foreground=T["muted"])
        se.pack(side="left", padx=(2, 0), fill="x", expand=True)
        def _clear(_e=None):
            if self._search_placeholder:
                self._search_placeholder = False; self._search_var.set(""); se.configure(foreground=T["text"])
        def _restore(_e=None):
            if not self._search_var.get():
                self._search_placeholder = True; self._search_var.set(PLACEHOLDER); se.configure(foreground=T["muted"])
        se.bind("<FocusIn>", _clear); se.bind("<FocusOut>", _restore)
        self._search_var.trace_add("write", lambda *_: self.refresh())

        split = tk.Frame(self._parent, bg=T["bg"]); split.pack(fill="both", expand=True, padx=4, pady=(0, 3))

        left_shadow = self._master._shadow_wrap(split); left_shadow.pack(side="left", fill="both", expand=True)
        left = tk.Frame(left_shadow, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"])
        left.pack(fill="both", expand=True, padx=(0, _CARD_SHADOW_OFFSET), pady=(0, _CARD_SHADOW_OFFSET))
        tree_hdr = tk.Frame(left, bg=T["surface3"], padx=3, pady=1); tree_hdr.pack(fill="x")
        self._master._lbl(tree_hdr, text="ESCANEOS GUARDADOS", size=10, bold=True,
                          bg=T["surface3"], fg=T["text"]).pack(side="left")

        cols = ("name", "targets", "certs", "findings", "risk", "last")
        self._tree = ttk.Treeview(left, columns=cols, show="headings", height=20)
        heads = [("name", "Nombre", 190), ("targets", "Objetivos", 220), ("certs", "Certs", 60),
                 ("findings", "C / A / M / B", 110), ("risk", "Riesgo", 90), ("last", "Último escaneo", 130)]
        for c, txt, w in heads:
            self._tree.heading(c, text=txt, command=lambda col=c: self._sort_by(col))
            self._tree.column(c, width=w, anchor="w")
        vsb = ttk.Scrollbar(left, orient="vertical", command=self._tree.yview)
        self._tree.configure(yscrollcommand=vsb.set)
        self._tree.pack(side="left", fill="both", expand=True); vsb.pack(side="right", fill="y")
        self._tree.bind("<<TreeviewSelect>>", self._on_select)
        self._tree.bind("<Double-1>", lambda _: self._edit_cfg())

        right_shadow = self._master._shadow_wrap(split); right_shadow.pack(side="right", fill="y", padx=(2, 0))
        right = tk.Frame(right_shadow, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"])
        right.pack(fill="both", expand=True, padx=(0, _CARD_SHADOW_OFFSET), pady=(0, _CARD_SHADOW_OFFSET))
        right.configure(width=300); right.pack_propagate(False)
        detail_hdr = tk.Frame(right, bg=T["surface3"], padx=3, pady=1); detail_hdr.pack(fill="x")
        self._master._lbl(detail_hdr, text="DETALLE", size=10, bold=True,
                          bg=T["surface3"], fg=T["text"]).pack(side="left")
        self._detail_canvas = tk.Canvas(right, bg=T["panel_bg"], highlightthickness=0, bd=0)
        dvsb = ttk.Scrollbar(right, orient="vertical", command=self._detail_canvas.yview)
        self._detail_canvas.configure(yscrollcommand=dvsb.set)
        self._detail_canvas.pack(side="left", fill="both", expand=True); dvsb.pack(side="right", fill="y")
        self._detail_frame = tk.Frame(self._detail_canvas, bg=T["panel_bg"])
        self._detail_win = self._detail_canvas.create_window((0, 0), window=self._detail_frame, anchor="nw")
        self._detail_frame.bind("<Configure>",
            lambda _: self._detail_canvas.configure(scrollregion=self._detail_canvas.bbox("all")))
        self._detail_canvas.bind("<Configure>",
            lambda e: self._detail_canvas.itemconfigure(self._detail_win, width=e.width))

        self._show_detail(None)
        self.refresh()

    def _build_dashboard(self, parent):
        self._dash_tiles: dict[str, dict] = {}
        specs = [
            ("scans",    "Escaneos guardados", T["text"]),
            ("critical", "🔴 Crítico", _RISK_COLORS_LIGHT["Crítico"]),
            ("high",     "🟠 Alto", _RISK_COLORS_LIGHT["Alto"]),
            ("medium",   "🟡 Medio", _RISK_COLORS_LIGHT["Medio"]),
            ("low",      "🟢 Bajo", _RISK_COLORS_LIGHT["Bajo"]),
            ("stale",    "⏰ Sin correr 30d+", T["muted"]),
        ]
        for key, label, colour in specs:
            tile = tk.Frame(parent, bg=T["panel_bg"], highlightthickness=1,
                            highlightbackground=T["border"], padx=2, pady=1)
            tile.pack(side="left", fill="y", padx=(0, 2))
            tk.Frame(tile, bg=colour, height=2).pack(fill="x", pady=(0, 1))
            row = tk.Frame(tile, bg=T["panel_bg"]); row.pack(anchor="w")
            val = self._master._lbl(row, text="—", size=10, bold=True, bg=T["panel_bg"], fg=colour)
            val.pack(side="left")
            self._master._lbl(row, text=label, size=10, bg=T["panel_bg"], fg=T["muted"]).pack(side="left", padx=(1, 0))
            self._dash_tiles[key] = {"value": val}

    def _refresh_dashboard(self):
        if not hasattr(self, "_dash_tiles"): return
        cfgs = self._store.list_configs()
        agg = {"scans": len(cfgs), "critical": 0, "high": 0, "medium": 0, "low": 0, "stale": 0}
        cutoff = datetime.now() - timedelta(days=30)
        for c in cfgs:
            agg["critical"] += int(c.get("findings_critical", 0) or 0)
            agg["high"]     += int(c.get("findings_high", 0) or 0)
            agg["medium"]   += int(c.get("findings_medium", 0) or 0)
            agg["low"]      += int(c.get("findings_low", 0) or 0)
            last = c.get("last_scan"); is_stale = True
            if last:
                try: is_stale = datetime.fromisoformat(str(last)[:19]) < cutoff
                except Exception: is_stale = False
            if is_stale: agg["stale"] += 1
        for key, tile in self._dash_tiles.items():
            tile["value"].config(text=str(agg.get(key, 0)))

    def refresh(self):
        self._refresh_dashboard()
        dark = getattr(self._master, "_dark", False)
        colors = _RISK_COLORS_DARK if dark else _RISK_COLORS_LIGHT
        for tier, colour in colors.items():
            self._tree.tag_configure(tier.lower(), foreground=colour,
                                     font=(_FUI, 10, "bold") if tier in ("Crítico", "Alto") else (_FUI, 10))
        for iid in self._tree.get_children(): self._tree.delete(iid)
        cfgs = self._store.list_configs()
        needle = "" if self._search_placeholder else (self._search_var.get() or "").strip().lower()
        if needle:
            cfgs = [c for c in cfgs if needle in " ".join(
                str(c.get(k, "")) for k in ("name", "targets", "risk_tier")).lower()]
        for c in cfgs:
            findings = f"{c.get('findings_critical',0)} / {c.get('findings_high',0)} / " \
                       f"{c.get('findings_medium',0)} / {c.get('findings_low',0)}"
            last = c.get("last_scan") or "—"
            tier = c.get("risk_tier", "Ninguno")
            self._tree.insert("", "end", iid=c["id"], values=(
                c.get("name", ""), c.get("targets", "") or c.get("files", "") or "—",
                c.get("cert_total", 0), findings, tier, last[:16] if last != "—" else "—",
            ), tags=(tier.lower(),))
        if self._current:
            cid = self._current.get("id", "")
            if self._tree.exists(cid):
                self._tree.selection_set(cid); self._tree.see(cid)

    def _sort_by(self, col: str):
        items = [(self._tree.set(iid, col), iid) for iid in self._tree.get_children()]
        rev = getattr(self, f"_sort_rev_{col}", False)
        items.sort(reverse=rev, key=lambda x: x[0].lower() if x[0] else "")
        for idx, (_, iid) in enumerate(items): self._tree.move(iid, "", idx)
        setattr(self, f"_sort_rev_{col}", not rev)

    def _show_detail(self, cfg: Optional[dict]):
        self._detail_canvas.configure(bg=T["panel_bg"]); self._detail_frame.configure(bg=T["panel_bg"])
        for w in self._detail_frame.winfo_children(): w.destroy()
        if cfg is None:
            self._master._lbl(self._detail_frame, text="Selecciona un escaneo\nde la lista.",
                             size=10, bg=T["panel_bg"], fg=T["muted"], justify="center").pack(expand=True, pady=10)
            return
        pad = tk.Frame(self._detail_frame, bg=T["panel_bg"], padx=4, pady=3); pad.pack(fill="both", expand=True)

        def kv(label, value, bold=False, color=None):
            r = tk.Frame(pad, bg=T["panel_bg"]); r.pack(fill="x", pady=1)
            self._master._lbl(r, text=label, size=10, bold=True, bg=T["panel_bg"], fg=T["muted"],
                             anchor="w", width=16).pack(side="left")
            self._master._lbl(r, text=str(value) if value not in (None, "") else "—", size=10, bold=bold,
                             bg=T["panel_bg"], fg=color or T["text"], anchor="w",
                             wraplength=190, justify="left").pack(side="left")

        tier = cfg.get("risk_tier", "Ninguno")
        tc = (_RISK_COLORS_DARK if getattr(self._master, "_dark", False) else _RISK_COLORS_LIGHT).get(tier, T["muted"])
        kv("Nombre", cfg.get("name", ""), bold=True)
        kv("Nivel de riesgo", tier, bold=True, color=tc)
        kv("Objetivos", cfg.get("targets", "") or "—")
        kv("Puertos", cfg.get("ports", ""))
        kv("Archivos", cfg.get("files", "") or "—")
        kv("Dominio CT", cfg.get("ct_domain", "") or "—")

        tk.Frame(pad, bg=T["border"], height=1).pack(fill="x", pady=2)
        c = cfg.get("findings_critical", 0); h = cfg.get("findings_high", 0)
        m = cfg.get("findings_medium", 0); lo = cfg.get("findings_low", 0)
        badge_row = tk.Frame(pad, bg=T["panel_bg"]); badge_row.pack(fill="x")
        for count, label, bg_hex in [(c, "Crítico", "#7a0c1c"), (h, "Alto", "#8b3a0a"),
                                     (m, "Medio", "#7a5e00"), (lo, "Bajo", "#0c4a2b")]:
            badge = tk.Frame(badge_row, bg=bg_hex, padx=2, pady=1); badge.pack(side="left", padx=(0, 1))
            self._master._lbl(badge, text=str(count), size=10, bold=True, bg=bg_hex, fg="#ffffff").pack()
            self._master._lbl(badge, text=label, size=10, bg=bg_hex, fg="#cccccc").pack()
        kv("Certificados", cfg.get("cert_total", 0))
        kv("Último escaneo", (cfg.get("last_scan") or "—")[:16])
        kv("Estado", cfg.get("last_status", "—") or "—")

        tk.Frame(pad, bg=T["border"], height=1).pack(fill="x", pady=2)
        kv("Responsable", cfg.get("owner", ""))
        kv("Programación", f"cada {cfg.get('schedule_minutes','0')} min"
           if str(cfg.get("schedule_minutes", "0")) not in ("0", "") else "una sola vez")

        notes = cfg.get("notes", "")
        if notes:
            tk.Frame(pad, bg=T["border"], height=1).pack(fill="x", pady=2)
            self._master._lbl(pad, text="NOTAS", size=10, bold=True, bg=T["panel_bg"],
                             fg=T["muted"], anchor="w").pack(fill="x")
            self._master._lbl(pad, text=notes, size=10, bg=T["panel_bg"], fg=T["text"],
                             anchor="w", wraplength=240, justify="left").pack(fill="x")

        history = cfg.get("scan_history", [])
        if len(history) >= 2:
            self._draw_trend(pad, history)

    def _draw_trend(self, parent, history: list):
        tk.Frame(parent, bg=T["border"], height=1).pack(fill="x", pady=2)
        self._master._lbl(parent, text="TENDENCIA DE HALLAZGOS (últimos escaneos)", size=10, bold=True,
                          bg=T["panel_bg"], fg=T["muted"], anchor="w").pack(fill="x")
        W, H = 260, 90
        cv = tk.Canvas(parent, width=W, height=H, bg=T["surface2"], bd=0, highlightthickness=0)
        cv.pack(pady=(1, 0))
        entries = history[-10:]
        n = len(entries)
        max_v = max((e.get("total", 0) or 0) for e in entries) or 1
        xs = [int(12 + (i / max(n - 1, 1)) * (W - 24)) for i in range(n)]
        def y_for(v): return int(H - 8 - (v / max_v) * (H - 20))
        for pct in (0.25, 0.5, 0.75, 1.0):
            yy = y_for(int(max_v * pct))
            cv.create_line(4, yy, W - 4, yy, fill=T["border"], dash=(2, 4))
        for key, colour in [("critical", "#c8102e"), ("high", "#e26020"), ("medium", "#d4a017"),
                            ("total", T["muted"])]:
            pts = []
            for i, e in enumerate(entries): pts += [xs[i], y_for(e.get(key, e.get("total", 0) or 0))]
            if len(pts) >= 4: cv.create_line(pts, fill=colour, width=2, smooth=True)
        if entries:
            last = entries[-1]
            for key, colour in [("critical", "#c8102e"), ("high", "#e26020"), ("medium", "#d4a017")]:
                v = last.get(key, 0) or 0
                if v:
                    yy = y_for(v)
                    cv.create_oval(xs[-1] - 4, yy - 4, xs[-1] + 4, yy + 4, fill=colour, outline="")
            cv.create_text(xs[0], H - 2, text=entries[0].get("ts", "")[:10], font=(_FUI, 10),
                           fill=T["muted"], anchor="s")
            cv.create_text(xs[-1], H - 2, text=entries[-1].get("ts", "")[:10], font=(_FUI, 10),
                           fill=T["muted"], anchor="s")

    def _on_select(self, _evt=None):
        sel = self._tree.selection()
        self._show_detail(self._store.get_config(sel[0]) if sel else None)

    def _selected(self) -> Optional[dict]:
        sel = self._tree.selection()
        return self._store.get_config(sel[0]) if sel else None

    def _new_cfg(self):
        ed = ScanConfigEditor(self._master, self._store)
        self._master.wait_window(ed)
        if ed.result:
            self.refresh(); self._tree.selection_set(ed.result["id"]); self._show_detail(ed.result)
            if ed.auto_load_var.get():
                self._current = ed.result; self._update_title_label(ed.result)
                if self._on_load: self._on_load(ed.result)

    def _edit_cfg(self):
        cfg = self._selected()
        if not cfg: return
        ed = ScanConfigEditor(self._master, self._store, cfg)
        self._master.wait_window(ed)
        if ed.result:
            self.refresh(); self._show_detail(ed.result)
            if ed.auto_load_var.get():
                self._current = ed.result; self._update_title_label(ed.result)
                if self._on_load: self._on_load(ed.result)

    def _delete_cfg(self):
        cfg = self._selected()
        if not cfg: return
        def _do():
            self._store.delete_config(cfg["id"])
            if self._current and self._current.get("id") == cfg["id"]:
                self._current = None; self._update_title_label(None)
            self.refresh(); self._show_detail(None)
        self._master._show_confirm_popup(
            "Eliminar escaneo guardado", f"¿Eliminar '{cfg['name']}'?\nEsta acción no se puede deshacer.",
            on_yes=_do, yes_label="  🗑  Eliminar  ", no_label="  Cancelar  ")

    def _load_selected(self):
        cfg = self._selected()
        if not cfg: return
        self._current = cfg; self._update_title_label(cfg)
        if self._on_load: self._on_load(cfg)

    def _update_title_label(self, cfg: Optional[dict]) -> None:
        lbl = getattr(self, "_title_lbl", None); hdr = getattr(self, "_title_hdr_frame", None)
        if lbl is None or hdr is None: return
        if cfg:
            lbl.config(text=f"📦  {cfg['name']}", fg=T["text"])
            anchor = getattr(self, "_title_hdr_anchor", None)
            hdr.pack(fill="x", before=anchor) if anchor is not None else hdr.pack(fill="x")
        else:
            lbl.config(text="", fg=T["text"]); hdr.pack_forget()

    def apply_theme(self) -> None:
        sel = self._tree.selection()
        selected_id = sel[0] if sel else None
        active = self._current
        for child in list(self._parent.winfo_children()):
            try: child.destroy()
            except Exception: pass
        self._build()
        if selected_id and self._tree.exists(selected_id):
            self._tree.selection_set(selected_id); self._tree.see(selected_id)
            self._show_detail(self._store.get_config(selected_id))
        if active:
            self._current = active; self._update_title_label(active)


# ── Integración en CertDiscoveryApp ─────────────────────────────────────── #

_MAX_SCAN_LOG_LINES_MEM = 4000   # tope en memoria por escaneo — el .log en
                                  # disco (ScanConfigStore.log_path) nunca se
                                  # trunca, esto solo limita lo que se
                                  # mantiene vivo en el Text widget/RAM.
_TAIL_LINES_FROM_DISK = 2000     # al reabrir una pestaña, cuántas líneas del
                                  # final del .log se recargan a memoria.


class _ScansTabMixin:
    def _build_tab_scans(self, parent):
        self._scan_dashboard = ScanConfigDashboard(
            parent=parent, master=self, store=self._scan_store, on_load=self._load_scan_profile)

    # ---------------------------------------------------------- carga/cambio
    def _load_scan_profile(self, cfg: dict, *, silent: bool = False) -> None:
        self._active_scan = cfg
        self.v_targets.set(cfg.get("targets", ""))
        self.v_ports.set(cfg.get("ports", "443,8443"))
        self.v_starttls.set(cfg.get("starttls", "off"))
        self.v_conc.set(str(cfg.get("concurrency", "200")))
        self.v_timeout.set(str(cfg.get("timeout", "3.0")))
        self.v_exclude.set(cfg.get("exclude", ""))
        self.v_checktrust.set(bool(cfg.get("check_trust", False)))
        self.v_ptr.set(bool(cfg.get("resolve_ptr", False)))
        self.v_ocsp.set(bool(cfg.get("check_revocation", False)))
        self.v_prefilter.set(bool(cfg.get("prefilter", True)))
        self.v_sni.set(cfg.get("sni", ""))
        self.v_ct.set(cfg.get("ct_domain", ""))
        self.v_ctscan.set(bool(cfg.get("ct_scan", True)))
        self.v_files.set(cfg.get("files", ""))
        self.v_winstore.set(bool(cfg.get("winstore", False)))
        self.v_live.set(bool(cfg.get("live", True)))
        self.v_baseline.set(cfg.get("baseline", ""))
        self.v_schedule.set(str(cfg.get("schedule_minutes", "0")))

        scan_id = cfg.get("id")
        if scan_id:
            open_ids = list(getattr(self, "_open_scan_tabs", []) or [])
            if scan_id not in open_ids: open_ids.append(scan_id)
            self._open_scan_tabs = open_ids
        self._swap_console_buffer(scan_id)
        self._rebuild_scan_tabs()
        self._update_window_title()
        self._last_scan_id = scan_id
        self._save_gui_state()
        dash = getattr(self, "_scan_dashboard", None)
        if dash is not None:
            try: dash.refresh()
            except Exception: pass
        if silent:
            return
        self._show_tab("discover")
        self._logln(f"Escaneo guardado cargado: {cfg['name']}")

    def _switch_scan_tab(self, scan_id: str) -> None:
        current = getattr(self, "_active_scan", None)
        if current and current.get("id") == scan_id:
            return
        if self._busy:
            self._show_warn_popup("Cambiar de escaneo",
                "No se puede cambiar de escaneo mientras hay uno en curso.\n\n"
                "Espere a que termine o deténgalo antes de cambiar de pestaña.")
            return
        cfg = self._scan_store.get_config(scan_id)
        if not cfg:
            self._open_scan_tabs = [s for s in getattr(self, "_open_scan_tabs", []) if s != scan_id]
            self._rebuild_scan_tabs()
            return
        self._load_scan_profile(cfg, silent=True)

    def _close_scan_tab(self, scan_id: str) -> None:
        if self._busy:
            self._show_warn_popup("Cerrar pestaña", "No se puede cerrar una pestaña de escaneo mientras hay uno en curso.")
            return
        self._open_scan_tabs = [s for s in getattr(self, "_open_scan_tabs", []) if s != scan_id]
        active = getattr(self, "_active_scan", None)
        self._scan_log_buffers.pop(scan_id, None)   # libera RAM — el .log en disco queda intacto
        if active and active.get("id") == scan_id:
            fallback = None
            if self._open_scan_tabs:
                fallback = self._scan_store.get_config(self._open_scan_tabs[-1])
            if fallback:
                self._load_scan_profile(fallback, silent=True); return
            self._active_scan = None
            self._last_scan_id = None
            self._swap_console_buffer(None)
            self._update_window_title()
        self._save_gui_state()
        self._rebuild_scan_tabs()

    def _update_window_title(self) -> None:
        cfg = getattr(self, "_active_scan", None)
        base = f"Descubrimiento de certificados — {self._profile['dc_name']}" if self._profile \
               else "Descubrimiento de certificados"
        self.title(f"{base}  ·  {cfg['name']}" if cfg else base)

    def _counts_for(self, cfg: dict) -> tuple[int, int, int, int]:
        return (cfg.get("findings_critical", 0), cfg.get("findings_high", 0),
                cfg.get("findings_medium", 0), cfg.get("findings_low", 0))

    def _rebuild_scan_tabs(self) -> None:
        """(Re)construye la franja de mini-tabs del ribbon a partir de
        _open_scan_tabs — mismo patrón visual que _rebuild_app_tabs del
        escáner Snyk (ver gui_apps_tab.py): solo la pestaña ACTIVA muestra
        su % en vivo y sus conteos; el resto solo el nombre."""
        container = getattr(self, "_scan_tabs_container", None)
        if container is None: return
        for w in container.winfo_children(): w.destroy()
        self._scan_tab_widgets = {}
        self._scan_tab_pct_widgets = {}

        open_ids = list(getattr(self, "_open_scan_tabs", []) or [])
        active = getattr(self, "_active_scan", None)
        active_id = active.get("id") if active else None

        if not open_ids:
            chip = tk.Frame(container, bg=T["bg"], highlightthickness=1,
                            highlightbackground=T["border"], cursor="hand2")
            chip.pack(side="left")
            lbl = self._lbl(chip, text="Sin escaneo — clic para elegir", size=10, bold=True,
                           bg=T["bg"], fg=T["muted"], cursor="hand2")
            lbl.pack(side="left", padx=2, pady=2)
            for w in (chip, lbl): w.bind("<Button-1>", lambda e: self._show_tab("scans"))
            return

        for scan_id in open_ids:
            cfg = self._scan_store.get_config(scan_id)
            if not cfg:
                self._open_scan_tabs = [s for s in self._open_scan_tabs if s != scan_id]
                continue
            is_active = (scan_id == active_id)
            border = T["accent"] if is_active else T["border"]
            tab = tk.Frame(container, bg=T["bg"], highlightthickness=1, highlightbackground=border, cursor="hand2")
            tab.pack(side="left", padx=(0, 1))
            clickable = [tab]
            if is_active:
                pct_lbl = self._lbl(tab, text="", size=10, bold=True, bg=T["bg"], fg=T["accent"], cursor="hand2")
                pct_lbl.pack(side="left", padx=(2, 0), pady=2)
                clickable.append(pct_lbl)
                self._scan_tab_pct_widgets[scan_id] = pct_lbl
            name_lbl = self._lbl(tab, text=cfg.get("name", "?"), size=10, bold=True, bg=T["bg"],
                                 fg=T["accent"] if is_active else T["muted"], cursor="hand2")
            name_lbl.pack(side="left", padx=(2, 1), pady=2)
            clickable.append(name_lbl)
            if is_active:
                crit, high, med, low = self._counts_for(cfg)
                counts_lbl = self._lbl(tab, text=f"  C:{crit}  A:{high}  M:{med}  B:{low}", size=10,
                                       bg=T["bg"], fg=T["muted"] if (crit == 0 and high == 0) else T["accent"],
                                       cursor="hand2")
                counts_lbl.pack(side="left", padx=(0, 1), pady=2)
                clickable.append(counts_lbl)
            close_lbl = self._lbl(tab, text="✕", size=10, bg=T["bg"], fg=T["muted"], cursor="hand2")
            close_lbl.pack(side="left", padx=(1, 2), pady=2)
            close_lbl.bind("<Button-1>", lambda e, sid=scan_id: self._close_scan_tab(sid))
            for w in clickable:
                w.bind("<Button-1>", lambda e, sid=scan_id: self._switch_scan_tab(sid))
            self._scan_tab_widgets[scan_id] = tab

        self._update_scan_tab_progress(0.0)

    def _update_scan_tab_progress(self, pct: float) -> None:
        widgets = getattr(self, "_scan_tab_pct_widgets", None)
        if not widgets: return
        active = getattr(self, "_active_scan", None)
        active_id = active.get("id") if active else None
        busy = bool(getattr(self, "_busy", False))
        for scan_id, lbl in widgets.items():
            try:
                if busy and scan_id == active_id:
                    lbl.configure(text=f"{int(round(max(0.0, min(1.0, pct)) * 100))}%")
                    lbl.pack_configure(padx=(2, 0))
                else:
                    lbl.configure(text=""); lbl.pack_configure(padx=(0, 0))
            except Exception:
                pass

    def _auto_load_last_scan(self) -> None:
        """Restaura las pestañas de escaneo abiertas en la sesión anterior."""
        restored = []
        for scan_id in getattr(self, "_saved_open_scan_ids", None) or []:
            if self._scan_store.get_config(scan_id): restored.append(scan_id)
        self._open_scan_tabs = restored
        scan_id = getattr(self, "_last_scan_id", None)
        if not scan_id:
            self._rebuild_scan_tabs(); return
        cfg = self._scan_store.get_config(scan_id)
        if cfg:
            self._load_scan_profile(cfg, silent=True)
        else:
            self._rebuild_scan_tabs()

    # -------------------------------------------------- consola por-escaneo
    def _swap_console_buffer(self, scan_id: Optional[str]) -> None:
        """Vacía el widget de consola visible y lo repuebla con el búfer del
        escaneo que se acaba de activar (None = actividad general/perfil de
        DC, fuera de cualquier escaneo guardado). Si el búfer no está en
        memoria todavía (p.ej. se acaba de reabrir la pestaña), se recarga
        la cola del .log en disco (ver ScanConfigStore.log_path)."""
        buf = self._scan_log_buffers.get(scan_id)
        if buf is None:
            buf = self._load_scan_log_tail(scan_id)
            self._scan_log_buffers[scan_id] = buf
        self._active_console_key = scan_id
        self._log.configure(state="normal")
        self._log.delete("1.0", "end")
        for text, tag in buf:
            self._log.insert("end", text + "\n", (tag,) if tag else ())
        self._log.see("end")
        self._log.configure(state="disabled")

    def _load_scan_log_tail(self, scan_id: Optional[str]) -> list:
        if scan_id is None:
            return []
        try:
            p = self._scan_store.log_path(scan_id)
            if not p.exists(): return []
            lines = p.read_text("utf-8", errors="replace").splitlines()[-_TAIL_LINES_FROM_DISK:]
            return [(ln, self._classify_log_line(ln)) for ln in lines]
        except Exception:
            return []

    def _classify_log_line(self, s: str) -> str:
        low = s.lower()
        if "error" in low or "✕" in s or "falló" in low:
            return "error"
        if "⚠" in s or "cancelado" in low or "aviso" in low:
            return "warn"
        if "✓" in s or "completado" in low or "listo" in low or "actualizado" in low:
            return "ok"
        if "escane" in low or "descubr" in low:
            return "scan"
        return ""

    def _scan_log(self, text: str) -> None:
        """Punto único de escritura de la consola — reemplaza el _logln
        plano anterior. Escribe en el búfer del escaneo ACTIVO en este
        momento (None = bitácora general), lo persiste en disco si hay un
        escaneo guardado activo, y solo repinta el Text widget si ese
        búfer es el que está visible ahora mismo."""
        ts_line = f"[{datetime.now():%H:%M:%S}] {text}"
        tag = self._classify_log_line(ts_line)
        active = getattr(self, "_active_scan", None)
        key = active.get("id") if active else None
        buf = self._scan_log_buffers.setdefault(key, [])
        buf.append((ts_line, tag))
        if len(buf) > _MAX_SCAN_LOG_LINES_MEM:
            del buf[: len(buf) - _MAX_SCAN_LOG_LINES_MEM]
        if key is not None:
            try:
                with open(self._scan_store.log_path(key), "a", encoding="utf-8") as fh:
                    fh.write(ts_line + "\n")
            except Exception:
                pass
        if getattr(self, "_active_console_key", None) == key:
            self._log.configure(state="normal")
            self._log.insert("end", ts_line + "\n", (tag,) if tag else ())
            self._log.see("end")
            self._log.configure(state="disabled")

    def _record_scan_result(self) -> None:
        """Llamado al terminar una corrida (_pump, rama 'done') — si hay un
        escaneo guardado activo, actualiza sus conteos/tendencia."""
        active = getattr(self, "_active_scan", None)
        if not active:
            return
        flagged = [f for f in self._inv.values() if f.flags]
        from collections import Counter
        c = Counter(cd.SEVERITY.get(fl, "low") for f in flagged for fl in f.flags)
        try:
            self._scan_store.record_result(
                active["id"], total_certs=len(self._inv),
                critical=c.get("critical", 0), high=c.get("high", 0),
                medium=c.get("medium", 0), low=c.get("low", 0), status="ok")
            refreshed = self._scan_store.get_config(active["id"])
            if refreshed:
                self._active_scan = refreshed
        except Exception as e:
            self._scan_log(f"No se pudo actualizar el historial del escaneo guardado: {e!r}")
        self._rebuild_scan_tabs()
        dash = getattr(self, "_scan_dashboard", None)
        if dash is not None:
            try: dash.refresh()
            except Exception: pass
