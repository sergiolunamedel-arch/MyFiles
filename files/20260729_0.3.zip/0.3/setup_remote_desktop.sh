#!/usr/bin/env bash
# setup_remote_desktop.sh — deja este servidor Linux con escritorio remoto
# (XFCE + XRDP) para poder abrir la GUI de descubrimiento de certificados
# desde "Conexión a Escritorio remoto" (mstsc.exe) — la que YA trae Windows,
# sin instalar nada adicional del lado de Windows.
#
# Corre UNA SOLA VEZ por servidor, como root/sudo, ANTES de install_dc.sh.
#
# Uso:
#   sudo ./setup_remote_desktop.sh              # crea el usuario 'certdisco' para RDP
#   sudo ./setup_remote_desktop.sh miusuario     # usa/reconfigura un usuario existente
set -euo pipefail

RDP_USER="${1:-certdisco}"
RDP_PORT=3389

if [[ $EUID -ne 0 ]]; then
  echo "Este script necesita privilegios de root. Corre: sudo $0 ${1:-}" >&2
  exit 1
fi

echo "== 1/6 · Instalando escritorio XFCE + XRDP =="
if command -v apt-get >/dev/null 2>&1; then
  apt-get update -qq
  DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
    xfce4 xfce4-session xorgxrdp xrdp dbus-x11
elif command -v dnf >/dev/null 2>&1; then
  dnf install -y epel-release || true
  dnf groupinstall -y "Xfce" || dnf install -y xfce4-session
  dnf install -y xrdp
elif command -v yum >/dev/null 2>&1; then
  yum install -y epel-release || true
  yum groupinstall -y "Xfce" || yum install -y xfce4-session
  yum install -y xrdp
elif command -v zypper >/dev/null 2>&1; then
  zypper --non-interactive install -t pattern xfce || true
  zypper --non-interactive install xfce4-session xrdp
else
  echo "ERROR: no reconozco el gestor de paquetes de este sistema." >&2
  echo "Instala XFCE + xrdp manualmente y vuelve a correr install_dc.sh." >&2
  exit 1
fi

echo "== 2/6 · Configurando XRDP para abrir sesión XFCE =="
cat > /etc/xrdp/startwm.sh << 'EOF'
#!/bin/sh
if [ -r /etc/profile ]; then . /etc/profile; fi
if [ -r ~/.profile ]; then . ~/.profile; fi
exec startxfce4
EOF
chmod +x /etc/xrdp/startwm.sh

echo "== 3/6 · Preparando el usuario para iniciar sesión ($RDP_USER) =="
if ! id "$RDP_USER" >/dev/null 2>&1; then
  useradd -m -s /bin/bash "$RDP_USER"
  echo "  Usuario '$RDP_USER' creado. Define su contraseña ahora (la va a pedir):"
  passwd "$RDP_USER"
else
  echo "  El usuario '$RDP_USER' ya existe."
  pw_status=$(passwd -S "$RDP_USER" 2>/dev/null | awk '{print $2}')
  if [[ "$pw_status" != "P" ]]; then
    echo "  No tiene contraseña utilizable por RDP (p.ej. solo entra por llave SSH). Defínela:"
    passwd "$RDP_USER"
  fi
fi

echo "== 4/6 · Habilitando el servicio xrdp (sobrevive reinicios) =="
systemctl enable --now xrdp

echo "== 5/6 · Abriendo el puerto $RDP_PORT en el firewall local, si hay uno activo =="
if command -v ufw >/dev/null 2>&1 && ufw status | grep -q "Status: active"; then
  ufw allow "$RDP_PORT"/tcp
elif command -v firewall-cmd >/dev/null 2>&1 && systemctl is-active --quiet firewalld; then
  firewall-cmd --permanent --add-port="$RDP_PORT"/tcp
  firewall-cmd --reload
else
  echo "  No detecté ufw/firewalld activo en este servidor — nada que abrir aquí localmente."
fi

echo "== 6/6 · Listo =="
IP=$(hostname -I 2>/dev/null | awk '{print $1}')
cat << EOF

Escritorio remoto configurado en este servidor.

  Desde Windows, SIN instalar nada adicional:
    1) Abre "Conexión a Escritorio remoto" (mstsc.exe)
    2) Equipo: ${IP:-<IP de este servidor>}:$RDP_PORT
    3) Usuario: $RDP_USER   (la contraseña que acabas de definir)

IMPORTANTE — esta es una excepción de red NUEVA y DISTINTA a la del escaneo:
  El puerto $RDP_PORT/tcp necesita quedar abierto de ENTRADA en este
  servidor, desde la red donde están las laptops/PCs de tu equipo — en el
  firewall perimetral y en Darktrace. Es tráfico RDP entrante hacia el
  servidor, aparte de la excepción de SALIDA que ya pidieron para que este
  mismo servidor escanee su Datacenter.

Siguiente paso: entra por RDP con '$RDP_USER' y corre ./install_dc.sh desde
ahí (también puedes correr install_dc.sh por SSH normal si prefieres, no
necesita sesión gráfica — solo la GUI en sí la necesita).
EOF
