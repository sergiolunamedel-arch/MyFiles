# Despliegue por Datacenter — 3 instancias independientes

Cada servidor corre su propia instancia, ya configurada de fábrica con los
rangos de red de SU datacenter. Son **3 instancias separadas** (una por DC),
cada una con su propio inventario local — unificarlas en un solo dashboard
queda para después.

Hay dos scripts porque son dos responsabilidades distintas:

| Script | Qué hace | Cuándo | Necesita sudo |
|---|---|---|---|
| `setup_remote_desktop.sh` | Deja el servidor con escritorio remoto (XFCE + xrdp) | Una vez por servidor, primero | Sí |
| `install_dc.sh` | Instala la app de descubrimiento en sí | Una vez por servidor, después | Solo si falta Tkinter |

## 0. Escritorio remoto (una sola vez por servidor)

Si el servidor todavía no tiene forma de mostrarte una ventana gráfica:

```bash
sudo ./setup_remote_desktop.sh
```

Esto instala XFCE (un escritorio ligero) + xrdp, y te deja usar
**"Conexión a Escritorio remoto" (mstsc.exe), la que ya trae Windows** —
sin instalar ningún cliente VNC aparte. El script te pide fijar una
contraseña para el usuario de conexión (por defecto `certdisco`; puedes
pasarle otro usuario ya existente: `sudo ./setup_remote_desktop.sh miusuario`).

⚠️ **Esta es una excepción de red NUEVA, distinta a la del escaneo**: el
puerto 3389/TCP necesita quedar abierto de ENTRADA en cada servidor, desde
la red de tu equipo, tanto en el firewall perimetral como en Darktrace. Es
tráfico RDP entrante hacia el servidor — trámite aparte de la excepción de
SALIDA que ya gestionaron para que el servidor escanee su Datacenter.

Si el servidor **ya tiene** escritorio remoto funcionando (VNC, xrdp, lo
que sea), sáltate este paso y ve directo al 1.

## 1. Instalar la app (una sola vez por servidor)

```bash
# Copia esta carpeta completa al servidor (scp, rsync, git, lo que usen)
chmod +x install_dc.sh
./install_dc.sh
#   Si este DC tiene certificados en keystores Java (.jks):
#   ./install_dc.sh --with-jks
```

Esto se puede correr por SSH normal (no necesita sesión gráfica) — solo la
GUI que instala sí la necesita para mostrarse.

## 2. Configurar el perfil de este Datacenter

```bash
cp profiles/dc1_profile.example.json dc_profile.json    # en el servidor de DC1
# cp profiles/dc2_profile.example.json dc_profile.json  # en el servidor de DC2
# cp profiles/dc3_profile.example.json dc_profile.json  # en el servidor de DC3

nano dc_profile.json   # como mínimo, cambia "targets" por los rangos reales
```

## 3. Conectarte y arrancar

Desde Windows: `mstsc.exe` → IP del servidor:3389 → usuario que definiste en
el paso 0. Ya adentro:

```bash
./run.sh
```

(o doble clic en el ícono "Descubrimiento de Certificados" del escritorio,
que también deja creado `install_dc.sh`).

## 4. Qué vas a ver al abrir la app

- El título y un rótulo rojo arriba muestran de qué DC es esta instancia —
  para no confundirte si tienes las 3 abiertas por RDP a la vez.
- El botón grande dice **"Escanear DC1 completo"** (o DC2/DC3) y ya trae
  precargados los rangos, puertos y demás del perfil. Solo hay que darle
  clic.
- Si editas `dc_profile.json` mientras la app está abierta, **"🔄 Perfil"**
  (arriba a la derecha) recarga los campos sin reiniciar.

## 5. Descubrimiento continuo (opcional, estilo job recurrente de Venafi)

En `dc_profile.json`:

- `"schedule_minutes"`: cada cuántos minutos se repite el escaneo solo
  (1440 = una vez al día, valor de fábrica).
- `"autostart"`: si lo pones en `true`, el escaneo arranca solo al abrir la
  app. Actívalo solo **después** de correr el perfil manualmente una vez y
  confirmar que los rangos están bien.

## 6. Inventario

Cada servidor guarda su propio histórico en `~/.bbcerts/inventory.json` de
ESE servidor — hoy son 3 inventarios independientes, uno por DC. Unificarlos
queda pendiente para cuando decidan abordar esa fase.

## 7. Validar el perfil sin abrir la GUI (opcional)

```bash
source venv/bin/activate
python3 cert_discovery.py --profile
```

## Resumen de las dos excepciones de red que necesitan gestionarse

1. **Salida**, desde cada servidor de DC hacia todo su Datacenter, en los
   puertos configurados en `dc_profile.json` — para poder escanear.
2. **Entrada**, hacia cada servidor de DC en el puerto 3389/TCP, desde la
   red de tu equipo — para poder conectarte por Escritorio Remoto.
