#!/usr/bin/env python3
"""
cert_discovery_gui.py — Consola de descubrimiento de certificados.

GUI con el mismo lenguaje visual que el escáner SecDevOps · Banco Base
(paleta naranja/rojo, tarjetas con franja de acento, píldoras de severidad,
modo claro/oscuro). Maneja el motor interno `cert_discovery.py`, pensado
para reemplazar el descubrimiento de Venafi.

Es autónomo (se ejecuta solo) y, a la vez, está estructurado como un panel
que puede injertarse en el escáner principal a través del hook `_inv_tab`:
la clase InventoryTab expone .apply_theme() y .refresh().

    python cert_discovery_gui.py
"""
from __future__ import annotations

import os
import re as _re
import sys
import csv as _csv
import json
import queue
import asyncio
import threading
from contextlib import contextmanager
from pathlib import Path
from datetime import datetime
from typing import Optional, Any

import tkinter as tk
from tkinter import ttk, filedialog, messagebox

import cert_discovery as cd
import gui_scans_tab

IS_WIN = os.name == "nt"
IS_MAC = sys.platform == "darwin"
IS_LINUX = not IS_WIN and not IS_MAC

if IS_MAC:     _FUI, _FMONO = "SF Pro Text", "Menlo"
elif IS_LINUX: _FUI, _FMONO = "DejaVu Sans", "DejaVu Sans Mono"
else:          _FUI, _FMONO = "Segoe UI", "Cascadia Mono"

APP_BRAND_NAME = "SecDevOps · Banco Base"

# --------------------------------------------------------------------------- #
#  Paleta (idéntica al escáner principal)
# --------------------------------------------------------------------------- #
# NOTA sobre por qué estos valores no son "redondos": _recolour() (más abajo)
# identifica el ROL semántico de un widget adivinándolo por su color hex
# actual (búsqueda inversa valor->rol), para poder repintarlo al cambiar de
# tema sin reconstruir toda la ventana. Eso solo funciona si, DENTRO de cada
# paleta, cada rol tiene un valor único — si dos roles comparten el mismo hex
# (p.ej. panel_bg y button_fg valían ambos "#ffffff" en LIGHT), la búsqueda
# inversa no puede distinguirlos y uno de los dos se repinta con el color del
# OTRO rol al cambiar de tema (el bug real: la mayoría de los fondos de panel
# se volvían negro sólido en vez de gris oscuro, porque "panel_bg" perdía la
# ambigüedad contra "button_fg"). Los valores de abajo están ajustados en 1
# unidad de hex (imperceptible al ojo) donde hacía falta para que cada rol
# sea único dentro de su propia paleta — LIGHT y DARK se verifican por
# separado, cada una debe ser internamente única.
_CARD_SHADOW_OFFSET = 2
_PALETTE_LIGHT = {
    "bg":        "#ffffff", "panel_bg":  "#fefefe", "surface2":  "#fdfdfd",
    "accent":    "#f5a800", "accent_hi": "#c48700", "button_fg": "#ffffff",
    "accent2":   "#c8102e", "accent2_hi":"#a00d24",
    "text":      "#0d1b2a", "muted":     "#5a6475", "border":    "#dde2ec",
    "border_bg": "#dde2ec",
    "border2":   "#1a3a5c",
    "shadow":    "#4a4a4a",
    "ok":        "#1a7a4a", "err":       "#c8102e", "card_hover":"#eef1f7",
    "surface3":  "#fcfcfc",
    "pill_run_bg":"#002060","pill_run_fg":"#c0ccee",
    "pill_ok_bg": "#0c4a2b","pill_ok_fg": "#a7f0c8",
    "pill_bad_bg":"#7a0c1c","pill_bad_fg":"#fdb8c0",
    "pill_idle_bg":"#dde2ec","pill_idle_fg":"#5a6475",
    "pill_crit_bg":"#fcebeb","pill_crit_fg":"#791f1f",
    "pill_high_bg":"#faeeda","pill_high_fg":"#633806",
    "pill_med_bg":"#f1efe8","pill_med_fg":"#444441",
    "pill_low_bg":"#f1efe8","pill_low_fg":"#888780",
}
_PALETTE_DARK = {
    # panel_bg/surface2/surface3 corridos a casi-negro puro (1-2 LSB fuera de
    # negro puro) — fondos de contenido 100% negro/blanco en todo el app,
    # igual que el escáner Snyk tras su pasada de normalización; solo
    # border/border_bg/shadow/border2 conservan su tinte real, por ser líneas
    # estructurales y no rellenos.
    "bg":        "#000000", "panel_bg":  "#010101", "surface2":  "#020202",
    "accent":    "#f5a800", "accent_hi": "#c48700", "button_fg": "#000000",
    "accent2":   "#c8102e", "accent2_hi":"#a00d24",
    "text":      "#f0f1f3", "muted":     "#6b7280", "border":    "#252830",
    "border_bg": "#252830",
    "border2":   "#3d6899",
    "shadow":    "#c9c9c9",
    "ok":        "#22c55e", "err":       "#ef4444", "card_hover":"#1e2127",
    "surface3":  "#030303",
    "pill_run_bg":"#0a1840","pill_run_fg":"#7a9cee",
    "pill_ok_bg": "#0a2818","pill_ok_fg": "#4ade80",
    "pill_bad_bg":"#3b0f0f","pill_bad_fg":"#fca5a5",
    "pill_idle_bg":"#252830","pill_idle_fg":"#6b7280",
    "pill_crit_bg":"#3b0f0f","pill_crit_fg":"#fca5a5",
    "pill_high_bg":"#3b2508","pill_high_fg":"#fdba74",
    "pill_med_bg": "#1e2127","pill_med_fg": "#9ca3af",
    "pill_low_bg": "#1e2127","pill_low_fg": "#6b7280",
}
T = dict(_PALETTE_LIGHT)
T["highlight"] = T["accent"]; T["highlight_text"] = T["button_fg"]
T["tree_bg"] = T["panel_bg"]; T["button_hover"] = T["accent_hi"]


def _apply_palette(dark: bool) -> None:
    T.update(_PALETTE_DARK if dark else _PALETTE_LIGHT)
    T["highlight"] = T["accent"]; T["highlight_text"] = T["button_fg"]
    T["tree_bg"] = T["panel_bg"]; T["button_hover"] = T["accent_hi"]


def _sev_pill(sev: str) -> tuple[str, str]:
    return {
        "critical": (T["pill_crit_bg"], T["pill_crit_fg"]),
        "high":     (T["pill_high_bg"], T["pill_high_fg"]),
        "medium":   (T["pill_med_bg"],  T["pill_med_fg"]),
        "low":      (T["pill_low_bg"],  T["pill_low_fg"]),
        "info":     (T["pill_low_bg"],  T["pill_low_fg"]),
        "ok":       (T["pill_ok_bg"],   T["pill_ok_fg"]),
    }.get(sev, (T["pill_low_bg"], T["pill_low_fg"]))


_SEV_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}


# --------------------------------------------------------------------------- #
#  ToggleSwitch — reemplazo app-wide de Checkbutton, mismo widget que el
#  escáner Snyk (drop-in: parent, text=, variable=, command=).
# --------------------------------------------------------------------------- #
class ToggleSwitch(tk.Frame):
    _W, _H = 28, 15

    def __init__(self, parent, text: str = "", variable: Optional[tk.BooleanVar] = None,
                 command=None, bg: Optional[str] = None, fg: Optional[str] = None,
                 font=None, state: str = "normal", anchor: str = "w", **_ignored):
        self._bg = bg
        if self._bg is None:
            try: self._bg = parent.cget("bg")
            except Exception: self._bg = T["panel_bg"]
        super().__init__(parent, bg=self._bg)
        self.variable = variable if variable is not None else tk.BooleanVar(value=False)
        self._command = command
        self._disabled = (state == "disabled")
        self._canvas = tk.Canvas(self, width=self._W, height=self._H, highlightthickness=0,
                                 bd=0, bg=self._bg, cursor="arrow" if self._disabled else "hand2")
        self._canvas.pack(side="left")
        self._label = None
        if text:
            self._label = tk.Label(self, text=text, font=font or (_FUI, 10),
                                   bg=self._bg, fg=fg or T["text"], anchor=anchor)
            self._label.pack(side="left", padx=(2, 0))
            self._label.bind("<Button-1>", self._on_click)
        self._canvas.bind("<Button-1>", self._on_click)
        self.variable.trace_add("write", lambda *_a: self._redraw())
        self._redraw()

    def _on_click(self, _evt=None):
        if self._disabled: return
        self.variable.set(not bool(self.variable.get()))
        if self._command:
            try: self._command()
            except Exception: pass

    def _redraw(self):
        c = self._canvas
        try: c.delete("all")
        except Exception: return
        on = bool(self.variable.get())
        W, H = self._W, self._H
        r = H // 2
        if self._disabled:
            track, knob, outline = T["surface2"], T["muted"], T["border"]
        elif on:
            track, knob, outline = T["accent"], T["button_fg"], T["accent"]
        elif T["bg"] == "#ffffff":
            track, knob, outline = "#000000", "#ffffff", "#000000"
        else:
            track, knob, outline = "#ffffff", "#000000", "#ffffff"
        c.create_oval(0, 0, H, H, fill=track, outline=outline, width=1)
        c.create_oval(W - H, 0, W, H, fill=track, outline=outline, width=1)
        c.create_rectangle(r, 0, W - r, H, fill=track, outline=track)
        kr = r - 3
        kx = (W - r) if on else r
        c.create_oval(kx - kr, r - kr, kx + kr, r + kr, fill=knob, outline=knob)

    def refresh_theme(self):
        try: self._bg = self.master.cget("bg")
        except Exception: pass
        try:
            self.configure(bg=self._bg); self._canvas.configure(bg=self._bg)
            if self._label is not None: self._label.configure(bg=self._bg)
        except Exception: pass
        self._redraw()

    def set_enabled(self, enabled: bool) -> None:
        self._disabled = not enabled
        try: self._canvas.configure(cursor="arrow" if self._disabled else "hand2")
        except Exception: pass
        self._redraw()


# --------------------------------------------------------------------------- #
#  Chrome de popups sin bordes (overrideredirect + doble contorno + sombra) —
#  mismo patrón que el escáner Snyk, para que el editor de escaneos guardados
#  y los diálogos de info/aviso/confirmación se vean idénticos.
# --------------------------------------------------------------------------- #
def _monitor_rect(widget) -> tuple:
    if IS_WIN:
        try:
            import ctypes, struct
            hwnd = int(widget.wm_frame(), 16)
            hmon = ctypes.windll.user32.MonitorFromWindow(hwnd, 2)
            mi = (ctypes.c_uint32 * 10)()
            mi[0] = ctypes.sizeof(mi)
            ctypes.windll.user32.GetMonitorInfoW(hmon, mi)
            l, t, r, b = struct.unpack_from("<iiii", bytes(mi), 4)
            return l, t, r - l, b - t
        except Exception:
            pass
    return 0, 0, widget.winfo_screenwidth(), widget.winfo_screenheight()


def _monitor_wh(widget) -> tuple:
    _l, _t, w, h = _monitor_rect(widget)
    return w, h


def _center_over(master, win, w_pct: float, h_pct: float) -> None:
    master.update_idletasks()
    mw, mh = _monitor_wh(master)
    w, h = int(mw * w_pct), int(mh * h_pct)
    px, py = master.winfo_rootx(), master.winfo_rooty()
    pw, ph = master.winfo_width(), master.winfo_height()
    x = px + (pw - w) // 2; y = py + (ph - h) // 2
    win.geometry(f"{w}x{h}+{x}+{y}")


def _bind_popup_close(win, master, bind_ids: dict):
    def _close():
        try: win.grab_release()
        except Exception: pass
        for evt, bid in bind_ids.items():
            try: master.unbind(evt, bid)
            except Exception: pass
        win.destroy()
        try: master.focus_force()
        except Exception: pass
    win.bind("<Escape>", lambda e: _close())
    return _close


def _popup_follow_parent(win, parent) -> dict:
    if IS_WIN:
        try:
            import ctypes
            win.update_idletasks()
            child_hwnd = int(win.wm_frame(), 16)
            parent_hwnd = int(parent.wm_frame(), 16)
            ctypes.windll.user32.SetWindowLongPtrW(child_hwnd, -8, parent_hwnd)
        except Exception:
            pass

    def _on_focus(e):
        if win.winfo_exists():
            try:
                if not win.winfo_ismapped(): win.deiconify()
                win.lift()
            except Exception: pass

    def _on_focus_out(e):
        if win.winfo_exists():
            def _check():
                if win.winfo_exists():
                    if getattr(win, "_dialog_guard_active", False):
                        return
                    try:
                        if parent.focus_get() is None:
                            win.withdraw()
                    except Exception: pass
            parent.after(100, _check)

    def _on_unmap(e):
        if e.widget is parent and win.winfo_exists():
            try: win.withdraw()
            except Exception: pass

    def _on_map(e):
        if e.widget is parent and win.winfo_exists():
            try: win.deiconify(); win.lift()
            except Exception: pass

    return {"<FocusIn>":  parent.bind("<FocusIn>",  _on_focus,     "+"),
            "<FocusOut>": parent.bind("<FocusOut>",  _on_focus_out, "+"),
            "<Unmap>":    parent.bind("<Unmap>",     _on_unmap,     "+"),
            "<Map>":      parent.bind("<Map>",        _on_map,       "+")}


@contextmanager
def _popup_dialog_guard(win):
    """Suspende el auto-withdraw de _popup_follow_parent mientras un diálogo
    nativo (filedialog.askdirectory/etc.) está abierto encima del popup."""
    win._dialog_guard_active = True
    try:
        yield
    finally:
        win._dialog_guard_active = False
        try:
            if win.winfo_exists():
                win.deiconify(); win.lift(); win.focus_force()
        except Exception:
            pass


def _apply_panel_chrome(win, geo_string: Optional[str] = None) -> tk.Frame:
    """Doble contorno + sombra para un panel sin bordes nativos; devuelve el
    Frame de contenido donde el caller empaca sus propios widgets."""
    _SD = 10
    win.update_idletasks()
    geo = geo_string or win.geometry()
    m = _re.match(r"(\d+)x(\d+)\+(-?\d+)\+(-?\d+)", geo)
    if not m:
        win.configure(bg=T["border2"])
        b = tk.Frame(win, bg=T["border2"], padx=1, pady=1); b.pack(fill="both", expand=True)
        c = tk.Frame(b, bg=T["bg"]); c.pack(fill="both", expand=True)
        return c
    gw, gh, gx, gy = int(m.group(1)), int(m.group(2)), int(m.group(3)), int(m.group(4))
    try:
        root = win.nametowidget(".")
    except Exception:
        root = win.winfo_toplevel().master or win
    shad = tk.Toplevel(root)
    shad.overrideredirect(True)
    shad.configure(bg=T["shadow"])
    shad.geometry(f"{gw}x{gh}+{gx + _SD}+{gy + _SD}")
    shad.lower(win)
    win._shadow_win = shad
    try: shad.attributes("-alpha", 0.35)
    except tk.TclError: pass
    win.bind("<Destroy>", lambda e: (shad.destroy() if shad.winfo_exists() else None), add="+")

    def _sync_shadow(e=None):
        if not win.winfo_exists() or not shad.winfo_exists(): return
        try:
            x = win.winfo_rootx() + _SD; y = win.winfo_rooty() + _SD
            w = win.winfo_width(); h = win.winfo_height()
            shad.geometry(f"{w}x{h}+{x}+{y}")
        except Exception:
            pass
    win.bind("<Configure>", _sync_shadow, add="+")

    def _on_map(e):
        if e.widget is win and shad.winfo_exists():
            try: shad.deiconify(); _sync_shadow(); shad.lower(win)
            except Exception: pass
    def _on_unmap(e):
        if e.widget is win and shad.winfo_exists():
            try: shad.withdraw()
            except Exception: pass
    win.bind("<Map>", _on_map, add="+")
    win.bind("<Unmap>", _on_unmap, add="+")

    border2 = tk.Frame(win, bg=T["border2"]); border2.place(x=0, y=0, relwidth=1.0, relheight=1.0)
    border = tk.Frame(border2, bg=T["border"])
    border.place(x=1, y=1, relwidth=1.0, relheight=1.0, width=-2, height=-2)
    content = tk.Frame(border, bg=T["bg"])
    content.place(x=1, y=1, relwidth=1.0, relheight=1.0, width=-2, height=-2)
    return content


# --------------------------------------------------------------------------- #
#  Mixins "wireados" — mismo patrón que _wire_mixin_globals() del escáner
#  Snyk: gui_scans_tab.py recibe T/_FUI/_FMONO/APP_BRAND_NAME/ToggleSwitch y
#  el resto de estos globals inyectados, en vez de importarlos (evita ciclos).
# --------------------------------------------------------------------------- #
_MIXIN_MODULES = (gui_scans_tab,)


def _wire_mixin_globals() -> None:
    shared = globals()
    for mod in _MIXIN_MODULES:
        for k, v in shared.items():
            if not k.startswith("__"):
                mod.__dict__[k] = v


_wire_mixin_globals()


# --------------------------------------------------------------------------- #
#  App
# --------------------------------------------------------------------------- #
class CertDiscoveryApp(gui_scans_tab._ScansTabMixin, tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Descubrimiento de certificados — SecDevOps · Banco Base")
        self.geometry("1180x780")
        self.minsize(980, 640)

        self._dark = False
        _apply_palette(self._dark)
        self.configure(bg=T["bg"])

        # Exactamente dos tamaños de fuente en toda la app — igual que el
        # escáner Snyk: "title" (encabezados/tabs) y "body" (todo lo demás).
        self.fonts = {
            "h1": (_FUI, 12, "bold"), "h2": (_FUI, 10, "bold"),
            "title": (_FUI, 12, "bold"), "tab": (_FUI, 12, "bold"),
            "body": (_FUI, 10), "bold": (_FUI, 10, "bold"),
            "small": (_FUI, 10), "mono": (_FMONO, 10),
        }

        self._inv: dict[str, cd.CertFinding] = {}
        self._delta: Optional[dict] = None
        self._busy = False
        self._q: queue.Queue = queue.Queue()
        self._active_tab = "discover"

        # ── Escaneos guardados ("apps" del escáner Snyk, adaptado) ────────
        self._scan_store = gui_scans_tab.ScanConfigStore(
            Path(cd.inventory_dir()) / "scan_profiles")
        self._active_scan: Optional[dict] = None
        self._open_scan_tabs: list[str] = []
        self._scan_log_buffers: dict = {None: []}   # scan_id|None -> [(texto, tag)]
        self._active_console_key = None
        self._unread_log = 0
        self._load_gui_state()

        # Perfil de Datacenter de esta instancia (si existe dc_profile.json).
        # Una instancia = un DC: el perfil ya trae targets/puertos/horario
        # precargados, para que el operador solo abra la app y dé ▶.
        # Independiente del sistema de escaneos guardados de arriba (ver
        # notas de diseño) — sigue funcionando exactamente igual que antes.
        self._profile: Optional[dict] = cd.load_dc_profile()

        self._build_vars()
        self._apply_profile_to_vars()
        if self._profile:
            self.title(f"Descubrimiento de certificados — {self._profile['dc_name']}")
        self._setup_ttk_styles()
        self._build_ribbon()
        self._build_body()
        self._build_status_bar()
        self._show_tab("discover")
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.after(80, self._pump)
        # Inventario vivo: cargar el histórico al arrancar (estilo Venafi siempre-vigente)
        self.after(120, self._load_living_inventory)
        # Restaurar las pestañas de escaneo guardado abiertas la última vez
        self.after(140, self._auto_load_last_scan)
        if self._profile and self._profile.get("autostart"):
            self.after(800, self._start)   # arranca solo, sin que nadie toque nada

    # ------------------------------------------------------- estado de sesión
    def _gui_state_path(self) -> str:
        return os.path.join(cd.inventory_dir(), "gui_state.json")

    def _load_gui_state(self) -> None:
        try:
            with open(self._gui_state_path(), encoding="utf-8") as fh:
                data = json.load(fh)
            self._last_scan_id = data.get("last_scan_id")
            self._saved_open_scan_ids = data.get("open_scan_tabs") or []
        except Exception:
            self._last_scan_id = None
            self._saved_open_scan_ids = []

    def _save_gui_state(self) -> None:
        try:
            data = {"last_scan_id": getattr(self, "_last_scan_id", None),
                   "open_scan_tabs": list(getattr(self, "_open_scan_tabs", []) or [])}
            with open(self._gui_state_path(), "w", encoding="utf-8") as fh:
                json.dump(data, fh)
        except Exception:
            pass

    def _on_close(self) -> None:
        self._save_gui_state()
        self.destroy()


    def _load_living_inventory(self):
        try:
            live = cd.load_inventory()
        except Exception:
            live = {}
        if live:
            self._inv = live
            self._refresh_inventory(); self._refresh_findings()
            self._status.config(
                text=f"Inventario vivo cargado · {len(live)} cert(s) "
                     f"({cd.default_inventory_path()})")

    def _reload_profile(self):
        if self._busy:
            messagebox.showinfo("Perfil", "Espera a que termine el escaneo en curso.")
            return
        self._profile = cd.load_dc_profile()
        if not self._profile:
            messagebox.showwarning("Perfil", "No se encontró dc_profile.json.")
            return
        self._apply_profile_to_vars()
        self.title(f"Descubrimiento de certificados — {self._profile['dc_name']}")
        self._big_run.config(text=f"▶  Escanear {self._profile['dc_name']} completo")
        self._logln(f"Perfil recargado: {self._profile['dc_name']} "
                    f"({self._profile['_path']})")

    # ---------------------------------------------------------------- vars
    def _build_vars(self):
        self.v_targets   = tk.StringVar(value="127.0.0.1")
        self.v_ports     = tk.StringVar(value="443,8443")
        self.v_starttls  = tk.StringVar(value="off")
        self.v_conc      = tk.StringVar(value="200")
        self.v_timeout   = tk.StringVar(value="3.0")
        self.v_exclude   = tk.StringVar(value="")
        self.v_checktrust= tk.BooleanVar(value=False)
        self.v_ptr       = tk.BooleanVar(value=False)
        self.v_ct        = tk.StringVar(value="")
        self.v_ctscan    = tk.BooleanVar(value=True)
        self.v_files     = tk.StringVar(value="")
        self.v_baseline  = tk.StringVar(value="")
        self.v_filter    = tk.StringVar(value="")
        self.v_only_flag = tk.BooleanVar(value=False)
        # --- nuevas capacidades ---
        self.v_winstore  = tk.BooleanVar(value=False)   # almacén de Windows
        self.v_ocsp      = tk.BooleanVar(value=False)   # revocación OCSP
        self.v_sni       = tk.StringVar(value="")       # vhosts SNI extra
        self.v_live      = tk.BooleanVar(value=True)    # inventario vivo (baseline+save)
        self.v_prefilter = tk.BooleanVar(value=True)    # pre-filtro TCP antes del handshake TLS
        self.v_schedule  = tk.StringVar(value="0")      # repetir cada N min (0=off)
        self._sched_job  = None                         # id del after() programado

    def _apply_profile_to_vars(self):
        """Precarga los campos con el perfil de Datacenter de esta instancia.
        El operador puede seguir editando todo a mano; esto solo evita que
        tenga que escribir los rangos de red cada vez que abre la app."""
        p = self._profile
        if not p:
            return
        self.v_targets.set(p["targets"])
        self.v_ports.set(str(p["ports"]))
        self.v_starttls.set(p["starttls"])
        self.v_conc.set(str(p["concurrency"]))
        self.v_timeout.set(str(p["timeout"]))
        self.v_exclude.set(p["exclude"])
        self.v_checktrust.set(bool(p["check_trust"]))
        self.v_ptr.set(bool(p["resolve_ptr"]))
        self.v_ocsp.set(bool(p["check_revocation"]))
        self.v_sni.set(p["sni"])
        self.v_files.set(p["files"])
        self.v_schedule.set(str(p["schedule_minutes"]))
        self.v_prefilter.set(bool(p.get("prefilter", True)))

    # ------------------------------------------------------------ ttk styles
    def _setup_ttk_styles(self):
        st = ttk.Style(self)
        try: st.theme_use("clam")
        except tk.TclError: pass
        st.configure("Treeview", background=T["panel_bg"], fieldbackground=T["panel_bg"],
                     foreground=T["text"], rowheight=26, borderwidth=0,
                     font=(_FUI, 10))
        st.map("Treeview", background=[("selected", T["accent"])],
               foreground=[("selected", T["button_fg"])])
        st.configure("Treeview.Heading", background=T["surface2"], foreground=T["muted"],
                     font=(_FUI, 10, "bold"), relief="flat", borderwidth=0)
        st.map("Treeview.Heading", background=[("active", T["surface3"])])
        st.configure("Cert.Horizontal.TProgressbar", troughcolor=T["surface2"],
                     background=T["accent"], bordercolor=T["border"],
                     lightcolor=T["accent"], darkcolor=T["accent"])
        st.configure("TCombobox", fieldbackground=T["panel_bg"], background=T["surface2"],
                     foreground=T["text"], arrowcolor=T["muted"])
        st.configure("Vertical.TScrollbar", background=T["surface2"],
                     troughcolor=T["bg"], arrowcolor=T["muted"], borderwidth=0)
        self._ttk = st

    # --------------------------------------------------------------- ribbon
    def _build_ribbon(self):
        self._ribbon = tk.Frame(self, bg=T["bg"]); self._ribbon.pack(side="top", fill="x")
        top_row = tk.Frame(self._ribbon, bg=T["bg"]); top_row.pack(fill="x", side="top")
        tk.Frame(self._ribbon, bg=T["border"], height=2).pack(fill="x", side="top", before=top_row)

        brand = tk.Frame(top_row, bg=T["bg"]); brand.pack(side="left", padx=(3, 0), pady=1)
        tk.Label(brand, text="⬡", font=(_FUI, 12, "bold"), bg=T["bg"], fg=T["accent"]).pack(side="left")
        tk.Label(brand, text="  Descubrimiento", font=(_FUI, 10, "bold"), bg=T["bg"], fg=T["accent"]).pack(side="left")
        tk.Label(brand, text=" de certificados", font=(_FUI, 10), bg=T["bg"], fg=T["accent"]).pack(side="left")
        tk.Frame(top_row, bg=T["border"], width=1).pack(side="left", fill="y", padx=(6, 0), pady=2)

        # Badge del Datacenter: cuál instancia es esta, a simple vista (evita
        # confundir DC1/DC2/DC3 cuando se entra por VNC a varios servidores).
        if self._profile:
            dcbox = tk.Frame(top_row, bg=T["accent2"], padx=8, pady=3)
            dcbox.pack(side="left", padx=(6, 0), pady=2)
            tk.Label(dcbox, text=f"📍 {self._profile['dc_name']}", font=(_FUI, 10, "bold"),
                     bg=T["accent2"], fg="#ffffff").pack()

        # Franja de mini-tabs de escaneos guardados abiertos — mismo patrón
        # que el escáner Snyk (_rebuild_app_tabs, ver gui_scans_tab.py).
        self._scan_tabs_container = tk.Frame(top_row, bg=T["bg"])
        self._scan_tabs_container.pack(side="left", padx=6, pady=2)
        self._rebuild_scan_tabs()

        right = tk.Frame(top_row, bg=T["bg"]); right.pack(side="right", padx=2, pady=1)

        self._run_btn = self._icon_square_btn(right, "▶", self._start)
        self._run_btn.pack(side="left", padx=(0, 2))
        self._stop_btn = self._icon_square_btn(right, "■", self._cancel, color=T["muted"])
        self._stop_btn.config(state="disabled")
        self._stop_btn.pack(side="left", padx=(0, 4))

        if self._profile:
            self._btn(right, "🔄 Perfil", self._reload_profile, kind="flat").pack(side="left", padx=(0, 2))

        tk.Frame(self._ribbon, bg=T["border"], height=1).pack(fill="x")
        tabrow = tk.Frame(self._ribbon, bg=T["bg"]); tabrow.pack(fill="x", side="top")
        self._tabs: dict[str, tk.Button] = {}
        for key, label in (("discover", "🔎  Descubrir"),
                           ("inventory", "📋  Inventario"),
                           ("findings", "⚠  Hallazgos"),
                           ("scans", "📦  Escaneos")):
            b = tk.Button(tabrow, text=label, command=lambda k=key: self._show_tab(k),
                          bg=T["bg"], fg=T["muted"], font=(_FUI, 12, "bold"),
                          relief="flat", bd=0, padx=14, pady=8, cursor="hand2",
                          activebackground=T["bg"], activeforeground=T["accent"])
            b.pack(side="left"); self._tabs[key] = b
        tk.Frame(self._ribbon, bg=T["border"], height=2).pack(fill="x", side="bottom")

    def _show_tab(self, key: str):
        self._active_tab = key
        for k, b in self._tabs.items():
            b.config(bg=T["bg"], fg=T["accent"] if k == key else T["muted"],
                     activebackground=T["bg"], activeforeground=T["accent"])
        for k, f in self._frames.items():
            if k == key: f.tkraise()

    # ----------------------------------------------------------------- body
    def _build_body(self):
        body = tk.Frame(self, bg=T["bg"]); body.pack(side="top", fill="both", expand=True)
        self._console_frame = tk.Frame(body, bg=T["panel_bg"], highlightthickness=1,
                                       highlightbackground=T["border"], height=240)
        self._console_frame.pack_propagate(False)
        self._build_console(self._console_frame)
        self._console_visible = False
        stack = tk.Frame(body, bg=T["bg"]); stack.pack(side="top", fill="both", expand=True)
        self._frames: dict[str, tk.Frame] = {}
        for key, builder in (("discover", self._build_discover),
                             ("inventory", self._build_inventory),
                             ("findings", self._build_findings),
                             ("scans", self._build_tab_scans)):
            f = tk.Frame(stack, bg=T["bg"]); f.place(x=0, y=0, relwidth=1, relheight=1)
            builder(f); self._frames[key] = f

    # --------------------------------------------------------- shared chrome
    def _scrollable(self, parent):
        cv = tk.Canvas(parent, bg=T["bg"], highlightthickness=0, bd=0)
        vsb = ttk.Scrollbar(parent, orient="vertical", command=cv.yview)
        cv.configure(yscrollcommand=vsb.set)
        cv.pack(side="left", fill="both", expand=True); vsb.pack(side="right", fill="y")
        holder = tk.Frame(cv, bg=T["bg"]); win = cv.create_window((0, 0), window=holder, anchor="nw")
        holder.bind("<Configure>", lambda _: cv.configure(scrollregion=cv.bbox("all")))
        cv.bind("<Configure>", lambda e: cv.itemconfigure(win, width=e.width))
        def wheel(e): cv.yview_scroll(int(-e.delta / 120), "units")
        cv.bind("<Enter>", lambda _: cv.bind_all("<MouseWheel>", wheel))
        cv.bind("<Leave>", lambda _: cv.unbind_all("<MouseWheel>"))
        inner = tk.Frame(holder, bg=T["bg"], padx=18, pady=12); inner.pack(fill="both", expand=True)
        return inner

    def _lbl(self, parent, text="", size=10, bold=False, bg=None, fg=None, **kw) -> tk.Label:
        return tk.Label(parent, text=text, font=(_FUI, size, "bold" if bold else "normal"),
                        bg=bg or T["panel_bg"], fg=fg or T["text"], **kw)

    def _btn(self, parent, text, cmd, kind="accent", **kw) -> tk.Button:
        """Fábrica central de botones rectangulares — ~45px de alto, relleno
        naranja/texto blanco habilitado, gris uniforme deshabilitado, sin
        excepciones. `kind` se conserva solo por compatibilidad de firma."""
        _ENABLED_FG = "#ffffff"
        cfg = dict(bg=T["accent"], fg=_ENABLED_FG, activebackground=T["accent_hi"],
                   activeforeground=_ENABLED_FG, disabledforeground=T["muted"],
                   font=(_FUI, 10), padx=14, pady=12, cursor="hand2", bd=0, relief="flat")
        cfg.update(kw)
        container = tk.Frame(parent, bg=T["accent"])
        inner_btn = tk.Button(container, text=text, command=cmd, **cfg)
        inner_btn.pack(fill="both", expand=True)
        _real_configure = tk.Button.configure
        def _auto_state_configure(*a, **kwa):
            if a and isinstance(a[0], dict):
                kwa = {**a[0], **kwa}; a = ()
            if "state" in kwa:
                if kwa["state"] == "disabled":
                    _real_configure(inner_btn, bg=T["surface2"], activebackground=T["surface2"], fg=T["muted"])
                    try: container.configure(bg=T["surface2"])
                    except Exception: pass
                elif kwa["state"] == "normal":
                    _real_configure(inner_btn, bg=T["accent"], activebackground=T["accent_hi"], fg=_ENABLED_FG)
                    try: container.configure(bg=T["accent"])
                    except Exception: pass
            return _real_configure(inner_btn, *a, **kwa)
        inner_btn.configure = _auto_state_configure
        inner_btn.config = _auto_state_configure
        if cfg.get("state") == "disabled":
            _auto_state_configure(state="disabled")
        inner_btn.pack = lambda *a, **kwa: container.pack(*a, **kwa)
        inner_btn.grid = lambda *a, **kwa: container.grid(*a, **kwa)
        inner_btn.container = container
        return inner_btn

    def _icon_square_btn(self, parent, text: str, cmd, *, color: Optional[str] = None) -> tk.Button:
        """Botón cuadrado de ícono, siempre 45x45 — marco de 1px con el color
        de borde (naranja por defecto), botón plano adentro. Expone `.wrap`
        para que el caller pueda cambiar el color del marco (p.ej. ▶/■)."""
        color = color or T["accent"]
        wrap = tk.Frame(parent, bg=color, width=45, height=45)
        wrap.pack_propagate(False); wrap.grid_propagate(False)
        btn = tk.Button(wrap, text=text, font=(_FUI, 10, "bold"), command=cmd,
                        bg=T["panel_bg"], fg=color, activebackground=T["surface2"],
                        activeforeground=color, relief="flat", bd=0, cursor="hand2",
                        disabledforeground=T["muted"])
        btn.place(x=1, y=1, relwidth=1.0, relheight=1.0, width=-2, height=-2)
        btn.wrap = wrap
        btn.pack = lambda *a, **kwa: wrap.pack(*a, **kwa)
        btn.grid = lambda *a, **kwa: wrap.grid(*a, **kwa)
        return btn

    def _hdiv(self, parent, **pk) -> tk.Frame:
        f = tk.Frame(parent, bg=T["border_bg"], height=1); f.pack(fill="x", **pk)
        return f

    def _shadow_wrap(self, parent) -> tk.Frame:
        return tk.Frame(parent, bg=T["shadow"])

    def _card_header(self, outer, title: str, *, pad: int = 14, collapsible: bool = True) -> tk.Frame:
        wrap = tk.Frame(outer, bg=T["panel_bg"]); wrap.pack(fill="x", side="top")
        tk.Frame(wrap, bg=T["border"], width=3).pack(side="left", fill="y")
        hdr = tk.Frame(wrap, bg=T["panel_bg"], padx=max(pad - 3, 6), pady=2)
        hdr.pack(side="left", fill="x", expand=True)
        chev = None
        if collapsible:
            chev = tk.Label(hdr, text="▾", font=(_FUI, 10), bg=T["panel_bg"], fg=T["muted"], cursor="hand2")
            chev.pack(side="left", padx=(0, 2))
        title_lbl = tk.Label(hdr, text=title, font=(_FUI, 12, "bold"), bg=T["panel_bg"], fg=T["text"],
                             anchor="w", cursor="hand2" if collapsible else "")
        title_lbl.pack(side="left")
        tk.Frame(outer, bg=T["border_bg"], height=1).pack(fill="x", side="top")
        hdr._chevron, hdr._title_lbl = chev, title_lbl
        return hdr

    def _wire_collapsible(self, hdr, body, *, start_collapsed: bool = False) -> None:
        chev = getattr(hdr, "_chevron", None)
        if chev is None: return
        state = {"collapsed": False}
        def _toggle(_evt=None):
            if state["collapsed"]:
                body.pack(fill="both", expand=True); chev.configure(text="▾"); state["collapsed"] = False
            else:
                body.pack_forget(); chev.configure(text="▸"); state["collapsed"] = True
        for w in (hdr, chev, getattr(hdr, "_title_lbl", None)):
            if w is not None: w.bind("<Button-1>", _toggle)
        if start_collapsed: _toggle()

    def _card(self, parent, title="", *, pady=(0, 10), collapsible: bool = True,
             start_collapsed: bool = False) -> tk.Frame:
        shadow_wrap = tk.Frame(parent, bg=T["shadow"]); shadow_wrap.pack(fill="x", pady=pady)
        outer = tk.Frame(shadow_wrap, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"])
        outer.pack(fill="both", expand=True, padx=(0, _CARD_SHADOW_OFFSET), pady=(0, _CARD_SHADOW_OFFSET))
        hdr = None
        if title:
            hdr = self._card_header(outer, title, collapsible=collapsible)
        inner = tk.Frame(outer, bg=T["panel_bg"], padx=14, pady=10); inner.pack(fill="both", expand=True)
        if title and collapsible and hdr is not None:
            self._wire_collapsible(hdr, inner, start_collapsed=start_collapsed)
        return inner

    # ------------------------------------------------------------- popups
    def _create_popup(self, title: str = "Window", w_pct: float = 0.75, h_pct: float = 0.75) -> tk.Frame:
        win = tk.Toplevel(self)
        win.title(title); win.configure(bg=T["bg"]); win.transient(self)
        _center_over(self, win, w_pct, h_pct)
        win.overrideredirect(True)
        win.update_idletasks(); win.lift(); win.focus_force()
        try: win.grab_set()
        except tk.TclError: pass
        _bind_ids: dict = {}
        _close = _bind_popup_close(win, self, _bind_ids)
        _bind_ids.update(_popup_follow_parent(win, self))
        content = _apply_panel_chrome(win)
        content.close = _close
        content._win = win
        return content

    def _popup_hdr(self, popup, title: str, subtitle: str = "", icon: str = "", on_close=None) -> tk.Frame:
        bg = T["panel_bg"]
        hdr = tk.Frame(popup, bg=bg, padx=8, pady=4); hdr.pack(fill="x")
        row = tk.Frame(hdr, bg=bg); row.pack(fill="x")
        tk.Label(row, text=f"{icon}  {title}" if icon else title, font=(_FUI, 12, "bold"),
                bg=bg, fg=T["text"]).pack(side="left")
        if subtitle:
            tk.Label(row, text=subtitle, font=(_FUI, 10, "italic"), bg=bg, fg=T["muted"]).pack(side="left", padx=(3, 0))
        _close_fn = on_close or getattr(popup, "close", None)
        if _close_fn:
            xbtn = tk.Label(row, text="✕", font=(_FUI, 10, "bold"), bg=bg, fg=T["muted"], cursor="hand2", padx=2)
            xbtn.pack(side="right")
            xbtn.bind("<Button-1>", lambda e: _close_fn())
            xbtn.bind("<Enter>", lambda e: xbtn.config(fg=T["err"]))
            xbtn.bind("<Leave>", lambda e: xbtn.config(fg=T["muted"]))
        hdr._row = row
        self._hdiv(popup)
        return hdr

    def _popup_foot(self, popup, *items, padx: int = 40, pady: int = 16, with_status: bool = False):
        bg = T["panel_bg"]
        self._hdiv(popup)
        bar = tk.Frame(popup, bg=bg, padx=padx, pady=pady); bar.pack(fill="x")
        status_lbl = None
        btn_row = tk.Frame(bar, bg=bg); btn_row.pack(fill="x")
        for text, cmd, kind in items:
            self._btn(btn_row, text, cmd, kind).pack(side="right", padx=(2, 0))
        if with_status:
            status_lbl = tk.Label(bar, text="", font=(_FUI, 10), bg=bg, fg=T["muted"], anchor="w", justify="left")
            status_lbl.pack(fill="x", pady=(2, 0))
            status_lbl.bind("<Configure>", lambda e: status_lbl.config(wraplength=max(e.width - 4, 10)))
        return (bar, status_lbl) if with_status else bar

    def _centered_msg(self, popup, icon, icon_color, title, message, msg_fg):
        bg = T["bg"]
        body = tk.Frame(popup, bg=bg); body.pack(fill="both", expand=True)
        tk.Frame(body, bg=bg).pack(fill="both", expand=True)
        row = tk.Frame(body, bg=bg); row.pack(padx=15)
        tk.Frame(body, bg=bg).pack(fill="both", expand=True)
        tk.Label(row, text=icon, font=(_FUI, 30), bg=bg, fg=icon_color).pack(side="left", padx=(0, 11))
        tk.Frame(row, bg=T["border_bg"], width=1).pack(side="left", fill="y", padx=(0, 10))
        txt = tk.Frame(row, bg=bg); txt.pack(side="left", fill="x", expand=True)
        tk.Label(txt, text=title, font=(_FUI, 12, "bold"), bg=bg, fg=T["text"], anchor="w").pack(anchor="w")
        tk.Frame(txt, bg=T["border_bg"], height=1).pack(fill="x", pady=(2, 3))
        tk.Label(txt, text=message, font=(_FUI, 10), bg=bg, fg=msg_fg, justify="left",
                wraplength=520, anchor="w").pack(anchor="w")

    def _show_popup(self, title: str, message: str, kind: str = "info"):
        icon = {"info": "ℹ", "warn": "⚠", "error": "✕"}.get(kind, "ℹ")
        icon_color = {"info": T["accent"], "warn": T["accent"], "error": T["err"]}.get(kind, T["accent"])
        popup = self._create_popup(title)
        self._popup_hdr(popup, title, icon=icon)
        self._centered_msg(popup, icon, icon_color, title, message, T["err"] if kind == "error" else T["text"])
        self._popup_foot(popup, ("  Aceptar  ", popup.close, "accent"))

    def _show_info_popup(self, title, message):  self._show_popup(title, message, "info")
    def _show_warn_popup(self, title, message):  self._show_popup(title, message, "warn")
    def _show_error_popup(self, title, message): self._show_popup(title, message, "error")

    def _show_confirm_popup(self, title, message, *, on_yes, yes_label="  Sí  ", no_label="  No  "):
        popup = self._create_popup(title)
        self._popup_hdr(popup, title, icon="⚠")
        self._centered_msg(popup, "⚠", T["accent"], title, message, T["text"])
        def _yes():
            popup.close()
            try: on_yes()
            except Exception as e: self._logln(f"[popup] acción falló: {e!r}")
        self._popup_foot(popup, (no_label, popup.close, "flat"), (yes_label, _yes, "accent"))

    def _field(self, parent, label, var, hint=""):
        row = tk.Frame(parent, bg=T["panel_bg"]); row.pack(fill="x", pady=4)
        tk.Label(row, text=label, font=(_FUI, 10, "bold"), bg=T["panel_bg"], fg=T["text"],
                 width=16, anchor="w").pack(side="left")
        e = tk.Entry(row, textvariable=var, font=(_FUI, 10), bg=T["surface2"], fg=T["text"],
                     insertbackground=T["text"], relief="flat",
                     highlightthickness=1, highlightbackground=T["border"],
                     highlightcolor=T["accent"])
        e.pack(side="left", fill="x", expand=True, ipady=4, ipadx=6)
        if hint:
            tk.Label(parent, text=hint, font=(_FUI, 10), bg=T["panel_bg"], fg=T["muted"],
                     anchor="w").pack(fill="x", padx=(120, 0))
        return e

    def _browse(self, parent, label, var, folder=True):
        row = tk.Frame(parent, bg=T["panel_bg"]); row.pack(fill="x", pady=4)
        tk.Label(row, text=label, font=(_FUI, 10, "bold"), bg=T["panel_bg"], fg=T["text"],
                 width=16, anchor="w").pack(side="left")
        e = tk.Entry(row, textvariable=var, font=(_FUI, 10), bg=T["surface2"], fg=T["text"],
                     insertbackground=T["text"], relief="flat",
                     highlightthickness=1, highlightbackground=T["border"])
        e.pack(side="left", fill="x", expand=True, ipady=4, ipadx=6)
        def pick():
            p = (filedialog.askdirectory() if folder
                 else filedialog.askopenfilename(filetypes=[("JSON", "*.json"), ("Todo", "*.*")]))
            if p: var.set(p)
        tk.Button(row, text="…", command=pick, font=(_FUI, 10, "bold"), bg=T["surface2"],
                  fg=T["muted"], relief="flat", bd=0, padx=10, cursor="hand2",
                  activebackground=T["surface3"]).pack(side="left", padx=(6, 0))

    def _pill(self, parent, text, sev):
        bg, fg = _sev_pill(sev)
        lbl = tk.Label(parent, text=f" {text} ", font=(_FUI, 10, "bold"), bg=bg, fg=fg, padx=6, pady=2)
        return lbl

    def _make_tree(self, parent, cols, headings, height=14):
        outer = tk.Frame(parent, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"])
        outer.pack(fill="both", expand=True)
        tk.Frame(outer, bg=T["accent"], height=2).pack(fill="x", side="top")
        tf = tk.Frame(outer, bg=T["panel_bg"]); tf.pack(fill="both", expand=True)
        tree = ttk.Treeview(tf, columns=cols, show="headings", height=height)
        for c, (txt, w) in zip(cols, headings):
            tree.heading(c, text=txt, command=lambda col=c: self._sort_tree(tree, col, False))
            tree.column(c, width=w, anchor="w")
        tree.tag_configure("even", background=T["panel_bg"])
        tree.tag_configure("odd", background=T["surface2"])
        tree.pack(side="left", fill="both", expand=True)
        ttk.Scrollbar(tf, command=tree.yview, orient="vertical").pack(side="right", fill="y")
        return tree

    def _sort_tree(self, tree, col, rev):
        data = [(tree.set(i, col), i) for i in tree.get_children()]
        def key(x):
            try: return (0, float(x[0]))
            except (ValueError, TypeError): return (1, str(x[0]).lower())
        data.sort(key=key, reverse=rev)
        for idx, (_, i) in enumerate(data): tree.move(i, "", idx)
        tree.heading(col, command=lambda: self._sort_tree(tree, col, not rev))

    # ----------------------------------------------------------- DISCOVER tab
    def _build_discover(self, parent):
        inner = self._scrollable(parent)

        if self._profile:
            p = self._profile
            n_targets = cd.count_targets(p["targets"]) if p["targets"] else 0
            n_ports = len([x for x in str(p["ports"]).split(",") if x.strip()])
            pb = tk.Frame(inner, bg=T["accent2"], padx=14, pady=10); pb.pack(fill="x", pady=(0, 10))
            tk.Label(pb, text=f"📍 Perfil precargado: {p['dc_name']}", font=(_FUI, 10, "bold"),
                     bg=T["accent2"], fg="#ffffff", anchor="w").pack(fill="x")
            sched = (f"cada {p['schedule_minutes']} min" if int(p["schedule_minutes"]) > 0
                     else "una sola vez")
            tk.Label(pb, text=f"{n_targets} host(s) · {n_ports} puerto(s) · repetición: {sched}"
                              f"{'  ·  arranque automático' if p.get('autostart') else ''}"
                              f"  ·  {p['_path']}",
                     font=(_FUI, 10), bg=T["accent2"], fg="#ffffff", anchor="w").pack(fill="x", pady=(2, 0))
            tk.Label(pb, text="Puedes editar los campos de abajo para este escaneo; "
                              "'🔄 Perfil' arriba los regresa a lo que dice el archivo.",
                     font=(_FUI, 10), bg=T["accent2"], fg="#ffffff", anchor="w").pack(fill="x", pady=(2, 0))

        tk.Label(inner, text="Fuentes de descubrimiento", font=(_FUI, 12, "bold"),
                 bg=T["bg"], fg=T["accent"], anchor="w").pack(fill="x", pady=(0, 8))

        c1 = self._card(inner, "Red activa  ·  handshake TLS / STARTTLS")
        self._field(c1, "Objetivos", self.v_targets, "CIDR · rango (10.0.0.1-50) · IP · host, coma-separado")
        self._field(c1, "Puertos", self.v_ports, "443,8443,25,587,143,…")
        row = tk.Frame(c1, bg=T["panel_bg"]); row.pack(fill="x", pady=4)
        tk.Label(row, text="STARTTLS", font=(_FUI, 10, "bold"), bg=T["panel_bg"], fg=T["text"],
                 width=16, anchor="w").pack(side="left")
        ttk.Combobox(row, textvariable=self.v_starttls, state="readonly", width=12,
                     values=["off", "auto", "smtp", "imap", "pop3", "ftp", "ldap", "postgres"]).pack(side="left")
        tk.Label(row, text="  'auto' = detecta por puerto (25/587→smtp, 143→imap, 5432→postgres…)",
                 font=(_FUI, 10), bg=T["panel_bg"], fg=T["muted"]).pack(side="left")
        r2 = tk.Frame(c1, bg=T["panel_bg"]); r2.pack(fill="x", pady=4)
        tk.Label(r2, text="Concurrencia", font=(_FUI, 10, "bold"), bg=T["panel_bg"], fg=T["text"],
                 width=16, anchor="w").pack(side="left")
        tk.Entry(r2, textvariable=self.v_conc, width=8, font=(_FUI, 10), bg=T["surface2"],
                 fg=T["text"], relief="flat", highlightthickness=1,
                 highlightbackground=T["border"]).pack(side="left", ipady=3, ipadx=4)
        tk.Label(r2, text="   Timeout (s)", font=(_FUI, 10, "bold"), bg=T["panel_bg"],
                 fg=T["text"]).pack(side="left", padx=(10, 4))
        tk.Entry(r2, textvariable=self.v_timeout, width=6, font=(_FUI, 10), bg=T["surface2"],
                 fg=T["text"], relief="flat", highlightthickness=1,
                 highlightbackground=T["border"]).pack(side="left", ipady=3, ipadx=4)
        self._field(c1, "Excluir", self.v_exclude, "IP / CIDR / host / puerto a omitir, coma-separado")
        chk = tk.Frame(c1, bg=T["panel_bg"]); chk.pack(fill="x", pady=(6, 0))
        self._check(chk, "Validar cadena de confianza (2º handshake)", self.v_checktrust).pack(side="left")
        self._check(chk, "Resolver PTR inverso", self.v_ptr).pack(side="left", padx=(16, 0))
        chk2 = tk.Frame(c1, bg=T["panel_bg"]); chk2.pack(fill="x", pady=(2, 0))
        self._check(chk2, "Comprobar revocación (OCSP) — marca REVOKED", self.v_ocsp).pack(side="left")
        chk3 = tk.Frame(c1, bg=T["panel_bg"]); chk3.pack(fill="x", pady=(2, 0))
        self._check(chk3, "Pre-filtrar puertos abiertos antes del handshake TLS "
                          "(recomendado en rangos grandes)", self.v_prefilter).pack(side="left")
        self._field(c1, "SNI (vhosts)", self.v_sni,
                    "hostnames extra a probar por IP — descubre varios certs tras una misma IP")

        c2 = self._card(inner, "Transparencia de certificados  ·  crt.sh  (activos externos / shadow-IT)")
        self._field(c2, "Dominio CT", self.v_ct, "ej. bancobase.com — descubre subdominios con cert emitido")
        self._check(c2, "Resolver y escanear activamente los hosts hallados", self.v_ctscan).pack(anchor="w", pady=(4, 0))

        c3 = self._card(inner, "Sistema de archivos  ·  certificados en reposo  (estilo agente)")
        self._browse(c3, "Directorio", self.v_files, folder=True)
        tk.Label(c3, text="Extrae .pem .crt .cer .der .p12 .pfx y keystores Java .jks/.keystore "
                          "— certs en disco que un scan de red no ve",
                 font=(_FUI, 10), bg=T["panel_bg"], fg=T["muted"], anchor="w").pack(fill="x", padx=(120, 0))

        c3b = self._card(inner, "Almacén de Windows  ·  LocalMachine  (estilo CAPI)")
        self._check(c3b, "Leer el almacén de certificados de Windows (MY · CA · ROOT)",
                    self.v_winstore).pack(anchor="w")
        tk.Label(c3b, text="Encuentra los certs que usan IIS y servicios desde el store, no desde disco. "
                          "Solo aplica al ejecutar en Windows.",
                 font=(_FUI, 10), bg=T["panel_bg"], fg=T["muted"], anchor="w").pack(fill="x", pady=(2, 0))

        c4 = self._card(inner, "Inventario vivo y cambios  ·  delta vs histórico")
        self._check(c4, "Usar inventario vivo: baseline automático + guardar tras cada scan",
                    self.v_live).pack(anchor="w")
        tk.Label(c4, text=f"Histórico persistente en {cd.default_inventory_path()} — "
                          f"como el inventario siempre-vigente de Venafi.",
                 font=(_FUI, 10), bg=T["panel_bg"], fg=T["muted"], anchor="w").pack(fill="x", pady=(2, 6))
        self._browse(c4, "Baseline manual", self.v_baseline, folder=False)
        sr = tk.Frame(c4, bg=T["panel_bg"]); sr.pack(fill="x", pady=(6, 0))
        tk.Label(sr, text="Repetir cada", font=(_FUI, 10, "bold"), bg=T["panel_bg"],
                 fg=T["text"], width=16, anchor="w").pack(side="left")
        tk.Entry(sr, textvariable=self.v_schedule, width=6, font=(_FUI, 10), bg=T["surface2"],
                 fg=T["text"], relief="flat", highlightthickness=1,
                 highlightbackground=T["border"]).pack(side="left", ipady=3, ipadx=4)
        tk.Label(sr, text="minutos  (0 = una sola vez — descubrimiento continuo estilo job de Venafi)",
                 font=(_FUI, 10), bg=T["panel_bg"], fg=T["muted"]).pack(side="left", padx=(6, 0))

        runrow = tk.Frame(inner, bg=T["bg"]); runrow.pack(fill="x", pady=(6, 4))
        run_label = (f"▶  Escanear {self._profile['dc_name']} completo"
                     if self._profile else "▶  Iniciar descubrimiento")
        self._big_run = tk.Button(runrow, text=run_label, command=self._start,
                                  font=(_FUI, 10, "bold"), bg=T["accent"], fg=T["button_fg"],
                                  activebackground=T["accent_hi"], activeforeground=T["button_fg"],
                                  relief="flat", bd=0, padx=18, pady=10, cursor="hand2")
        self._big_run.pack(side="left")
        tk.Button(runrow, text="▥  Registro", command=self._toggle_console, font=(_FUI, 10, "bold"),
                  bg=T["panel_bg"], fg=T["muted"], relief="flat", bd=0, padx=12, pady=10,
                  cursor="hand2", activebackground=T["card_hover"],
                  highlightthickness=1, highlightbackground=T["border"]).pack(side="left", padx=(8, 0))

    def _check(self, parent, text, var):
        return tk.Checkbutton(parent, text=text, variable=var, font=(_FUI, 10),
                              bg=T["panel_bg"], fg=T["text"], activebackground=T["panel_bg"],
                              activeforeground=T["text"], selectcolor=T["surface2"],
                              highlightthickness=0, anchor="w")

    # ---------------------------------------------------------- INVENTORY tab
    def _build_inventory(self, parent):
        wrap = tk.Frame(parent, bg=T["bg"], padx=18, pady=12); wrap.pack(fill="both", expand=True)

        bar = tk.Frame(wrap, bg=T["bg"]); bar.pack(fill="x", pady=(0, 8))
        tk.Label(bar, text="Inventario", font=(_FUI, 12, "bold"), bg=T["bg"], fg=T["accent"]).pack(side="left")
        self._inv_count = tk.Label(bar, text="", font=(_FUI, 10), bg=T["bg"], fg=T["muted"])
        self._inv_count.pack(side="left", padx=(10, 0))
        tk.Button(bar, text="⬇ HTML", command=lambda: self._export("html"), font=(_FUI, 10, "bold"),
                  bg=T["accent"], fg=T["button_fg"], relief="flat", bd=0, padx=10, pady=5,
                  cursor="hand2", activebackground=T["accent_hi"]).pack(side="right", padx=(0, 6))
        tk.Button(bar, text="⬇ JSON", command=lambda: self._export("json"), font=(_FUI, 10, "bold"),
                  bg=T["surface2"], fg=T["text"], relief="flat", bd=0, padx=10, pady=5,
                  cursor="hand2", activebackground=T["surface3"]).pack(side="right")
        tk.Button(bar, text="⬇ CSV", command=lambda: self._export("csv"), font=(_FUI, 10, "bold"),
                  bg=T["surface2"], fg=T["text"], relief="flat", bd=0, padx=10, pady=5,
                  cursor="hand2", activebackground=T["surface3"]).pack(side="right", padx=(0, 6))
        fe = tk.Entry(bar, textvariable=self.v_filter, font=(_FUI, 10), bg=T["surface2"], fg=T["text"],
                      insertbackground=T["text"], relief="flat", width=24,
                      highlightthickness=1, highlightbackground=T["border"], highlightcolor=T["accent"])
        fe.pack(side="right", padx=(0, 8), ipady=3, ipadx=4)
        fe.bind("<KeyRelease>", lambda e: self._refresh_inventory())
        tk.Label(bar, text="Filtrar:", font=(_FUI, 10), bg=T["bg"], fg=T["muted"]).pack(side="right", padx=(0, 4))

        split = tk.Frame(wrap, bg=T["bg"]); split.pack(fill="both", expand=True)
        left = tk.Frame(split, bg=T["bg"]); left.pack(side="left", fill="both", expand=True)
        cols = ("cn", "exp", "key", "src", "tls", "rev", "delta", "sev", "seen")
        heads = (("Nombre (CN/SAN)", 220), ("Vence (d)", 68), ("Llave", 76), ("Fuente", 66),
                 ("TLS", 64), ("Revoc.", 64), ("Δ", 70), ("Severidad", 78), ("Visto en", 190))
        self._inv_tree = self._make_tree(left, cols, heads, height=18)
        self._inv_tree.bind("<<TreeviewSelect>>", self._on_inv_select)

        self._detail = tk.Frame(split, bg=T["panel_bg"], width=320,
                                highlightthickness=1, highlightbackground=T["border"])
        self._detail.pack(side="right", fill="y", padx=(10, 0)); self._detail.pack_propagate(False)
        tk.Frame(self._detail, bg=T["accent"], height=2).pack(fill="x", side="top")
        self._detail_body = tk.Frame(self._detail, bg=T["panel_bg"], padx=12, pady=10)
        self._detail_body.pack(fill="both", expand=True)
        tk.Label(self._detail_body, text="Seleccione un certificado", font=(_FUI, 10),
                 bg=T["panel_bg"], fg=T["muted"]).pack(anchor="w")

    # ----------------------------------------------------------- FINDINGS tab
    def _build_findings(self, parent):
        wrap = tk.Frame(parent, bg=T["bg"], padx=18, pady=12); wrap.pack(fill="both", expand=True)
        tk.Label(wrap, text="Hallazgos de higiene", font=(_FUI, 12, "bold"),
                 bg=T["bg"], fg=T["accent"], anchor="w").pack(fill="x", pady=(0, 8))
        self._sev_bar = tk.Frame(wrap, bg=T["bg"]); self._sev_bar.pack(fill="x", pady=(0, 10))
        cols = ("sev", "cn", "exp", "flags", "seen")
        heads = (("Severidad", 90), ("Nombre", 230), ("Vence (d)", 80),
                 ("Hallazgos", 340), ("Visto en", 200))
        self._find_tree = self._make_tree(wrap, cols, heads, height=18)
        self._find_tree.tag_configure("critical", foreground=_sev_pill("critical")[1])
        self._find_tree.tag_configure("high", foreground=_sev_pill("high")[1])

    # ---------------------------------------------------------- status bar
    def _build_status_bar(self):
        bar = tk.Frame(self, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"])
        bar.pack(side="bottom", fill="x")
        self._help_btn = self._icon_square_btn(bar, "?", self._toggle_help_overlay)
        self._help_btn.pack(side="left", padx=(2, 0))
        self._theme_btn = self._icon_square_btn(bar, "🌙" if self._dark else "☀", self._toggle_theme)
        self._theme_btn.pack(side="left", padx=(2, 0))
        self._console_btn = self._btn(bar, "▥  Consola", self._toggle_console, kind="accent")
        self._console_btn.pack(side="left", padx=2)
        os_tag = "macOS" if IS_MAC else ("Windows" if IS_WIN else "Linux")
        tk.Label(bar, text=f"  ·  {os_tag}", font=(_FUI, 10), bg=T["panel_bg"], fg=T["muted"]).pack(side="right", padx=(0, 6))
        self._status = tk.Label(bar, text="Listo.", font=(_FUI, 10), bg=T["panel_bg"],
                                fg=T["muted"], anchor="center")
        self._status.pack(expand=True)
        self._pb = ttk.Progressbar(bar, style="Cert.Horizontal.TProgressbar",
                                   mode="determinate", maximum=100, length=220)
        self._pb.pack(side="right", padx=12, pady=4)

    def _toggle_help_overlay(self):
        self._show_info_popup("Descubrimiento de certificados",
            "Reemplazo interno de Venafi: descubre certificados por red activa "
            "(TLS/STARTTLS), Transparencia de Certificados (crt.sh), sistema de "
            "archivos y el almacén de Windows.\n\n"
            "Los escaneos guardados (📦 Escaneos) te dejan definir varias "
            "configuraciones y cambiar entre ellas — cada una con su propia "
            "consola de actividad detallada.")

    def _build_console(self, parent):
        hdr = tk.Frame(parent, bg=T["accent"], padx=10, pady=6); hdr.pack(fill="x")
        tk.Label(hdr, text="REGISTRO DE ACTIVIDAD", font=(_FUI, 12, "bold"),
                 bg=T["accent"], fg=T["button_fg"]).pack(side="left")
        tk.Button(hdr, text="✕ Cerrar", command=self._toggle_console, font=(_FUI, 10, "bold"),
                  bg=T["accent"], fg=T["button_fg"], relief="flat", bd=0, cursor="hand2",
                  activebackground=T["accent_hi"]).pack(side="right")
        inner = tk.Frame(parent, bg=T["surface2"]); inner.pack(fill="both", expand=True)
        self._log = tk.Text(inner, wrap="word", font=(_FMONO, 10), bg=T["surface2"], fg=T["text"],
                            insertbackground=T["text"], relief="flat", padx=12, pady=8,
                            height=9, state="disabled")
        self._log.pack(side="left", fill="both", expand=True)
        sb = ttk.Scrollbar(inner, command=self._log.yview); sb.pack(side="right", fill="y")
        self._log.configure(yscrollcommand=sb.set)
        # Consola con código de colores — igual que el escáner Snyk: rojo =
        # error, ámbar = aviso, verde = éxito, azul = actividad de escaneo.
        self._log.tag_configure("error", foreground=T["err"])
        self._log.tag_configure("warn",  foreground=T["accent"])
        self._log.tag_configure("ok",    foreground=T["ok"])
        self._log.tag_configure("scan",  foreground=T["border2"])

    def _toggle_console(self):
        if self._console_visible:
            self._console_frame.pack_forget(); self._console_visible = False
        else:
            self._console_frame.pack(side="bottom", fill="x"); self._console_visible = True
            self._unread_log = 0
        self._console_btn.configure(text="▥  Consola")

    def _logln(self, text):
        """Punto único de escritura de la consola — delega en el búfer del
        escaneo guardado activo (o el general si no hay ninguno cargado);
        ver _scan_log en gui_scans_tab.py / _ScansTabMixin."""
        self._scan_log(text)
        if not self._console_visible:
            self._unread_log += 1
            self._console_btn.configure(text=f"▥  Consola ({self._unread_log})")

    # ----------------------------------------------------------------- run
    def _start(self):
        if self._busy:
            return
        self._busy = True
        self._cancel_flag = threading.Event()
        self._run_btn.config(state="disabled"); self._big_run.config(state="disabled", text="Escaneando…")
        self._stop_btn.config(state="normal"); self._stop_btn.wrap.config(bg=T["accent2"])
        self._status.config(text="Descubriendo…"); self._pb["value"] = 0
        self._update_scan_tab_progress(0.0)
        if not self._console_visible:
            self._toggle_console()
        cfg = self._collect_cfg()
        threading.Thread(target=self._worker, args=(cfg,), daemon=True).start()

    def _cancel(self):
        if self._busy and getattr(self, "_cancel_flag", None):
            self._cancel_flag.set()
            self._status.config(text="Cancelando…")

    def _collect_cfg(self) -> dict:
        def _int(s, d):
            try: return int(s)
            except ValueError: return d
        def _flt(s, d):
            try: return float(s)
            except ValueError: return d
        return dict(
            targets=self.v_targets.get().strip(),
            ports=[int(p) for p in self.v_ports.get().split(",") if p.strip().isdigit()] or [443],
            starttls=self.v_starttls.get(),
            conc=_int(self.v_conc.get(), 200), timeout=_flt(self.v_timeout.get(), 3.0),
            exclude=self.v_exclude.get().strip(),
            checktrust=self.v_checktrust.get(), ptr=self.v_ptr.get(),
            ct=self.v_ct.get().strip(), ctscan=self.v_ctscan.get(),
            files=self.v_files.get().strip(), baseline=self.v_baseline.get().strip(),
            winstore=self.v_winstore.get(), ocsp=self.v_ocsp.get(),
            sni=[s.strip() for s in self.v_sni.get().split(",") if s.strip()],
            live=self.v_live.get(), prefilter=self.v_prefilter.get(),
        )

    def _worker(self, cfg: dict):
        loop = asyncio.new_event_loop(); asyncio.set_event_loop(loop)
        inv: dict[str, cd.CertFinding] = {}
        try:
            def prog(done, total, host, port):
                if self._cancel_flag.is_set():
                    raise asyncio.CancelledError()
                self._q.put(("progress", (done, total, f"{host}:{port}")))

            if cfg["ct"]:
                self._q.put(("log", f"Consultando crt.sh para {cfg['ct']}…"))
                names = cd.ct_discover(cfg["ct"])
                self._q.put(("log", f"crt.sh devolvió {len(names)} nombre(s)."))
                if cfg["ctscan"] and names:
                    inv = loop.run_until_complete(cd.scan(
                        names, cfg["ports"], cfg["conc"], cfg["timeout"], cfg["starttls"],
                        cfg["checktrust"], cfg["ptr"], cfg["exclude"], progress=prog,
                        check_revocation=cfg["ocsp"], sni_names=cfg["sni"],
                        prefilter=cfg["prefilter"]))
                else:
                    for n in names:
                        self._q.put(("log", f"  {n}"))
            elif cfg["targets"]:
                tgts = cd.expand_targets(cfg["targets"])
                self._q.put(("log", f"Red activa: {len(tgts)} host(s) × {len(cfg['ports'])} puerto(s)"
                                    f"{' · pre-filtro TCP activo' if cfg['prefilter'] else ''}"))
                inv = loop.run_until_complete(cd.scan(
                    tgts, cfg["ports"], cfg["conc"], cfg["timeout"], cfg["starttls"],
                    cfg["checktrust"], cfg["ptr"], cfg["exclude"], progress=prog,
                    check_revocation=cfg["ocsp"], sni_names=cfg["sni"],
                    prefilter=cfg["prefilter"]))

            # Archivos en reposo y almacén de Windows: fuentes ADITIVAS — se
            # fusionan con lo anterior en vez de reemplazarlo. Antes "archivos"
            # vivía en el mismo if/elif que red/CT, así que un perfil de DC con
            # AMBOS campos llenos (targets + files) se quedaba SOLO con el
            # escaneo de archivos y omitía la red por completo, en silencio.
            if cfg["files"]:
                self._q.put(("log", f"Sistema de archivos: {cfg['files']}"))
                files_inv = cd.scan_files(cfg["files"])
                self._q.put(("log", f"Sistema de archivos: {len(files_inv)} cert(s)."))
                inv = cd.merge_inventories(inv, files_inv) if inv else files_inv

            if cfg["winstore"]:
                self._q.put(("log", "Leyendo almacén de certificados de Windows…"))
                win = cd.scan_windows_store()
                self._q.put(("log", f"Almacén de Windows: {len(win)} cert(s)."))
                inv = cd.merge_inventories(inv, win) if inv else win

            if not (cfg["files"] or cfg["ct"] or cfg["targets"] or cfg["winstore"]):
                self._q.put(("error", "No hay ninguna fuente seleccionada."))
                return

            # Baseline: manual tiene prioridad; si no, el inventario vivo
            baseline = None
            if cfg["baseline"]:
                baseline = cfg["baseline"]
            elif cfg["live"]:
                baseline = cd.load_inventory()
                if baseline:
                    self._q.put(("log", f"Baseline = inventario vivo ({len(baseline)} cert)."))
            delta = None
            if baseline is not None and inv:
                try:
                    delta = cd.apply_delta(inv, baseline)
                    self._q.put(("log", f"Delta: {len(delta['new'])} nuevo(s), "
                                        f"{len(delta['renewed'])} renovado(s), "
                                        f"{len(delta['removed'])} eliminado(s)."))
                except Exception as e:
                    self._q.put(("log", f"Baseline no aplicable: {e!r}"))

            # Guardar/fusionar en el inventario vivo
            if cfg["live"] and inv:
                try:
                    p = cd.save_inventory(inv, merge=True)
                    merged = cd.load_inventory(p)
                    self._q.put(("log", f"Inventario vivo actualizado: {len(merged)} cert(s)."))
                    inv = merged   # mostramos el inventario acumulado, no solo lo de este scan
                except Exception as e:
                    self._q.put(("log", f"No se pudo guardar inventario vivo: {e!r}"))

            self._q.put(("done", (inv, delta)))
        except asyncio.CancelledError:
            self._q.put(("log", "Cancelado por el usuario."))
            self._q.put(("done", (inv, None)))
        except Exception as e:
            self._q.put(("error", repr(e)))
        finally:
            loop.close()

    def _pump(self):
        try:
            while True:
                kind, payload = self._q.get_nowait()
                if kind == "progress":
                    done, total, where = payload
                    pct = done / max(total, 1)
                    self._pb["value"] = int(100 * pct)
                    self._status.config(text=f"Escaneando {done}/{total} · {where}")
                    self._update_scan_tab_progress(pct)
                elif kind == "log":
                    self._logln(str(payload))
                elif kind == "error":
                    self._logln(f"ERROR: {payload}")
                    self._finish_run()
                    messagebox.showerror("Descubrimiento", f"Falló:\n{payload}")
                elif kind == "done":
                    inv, delta = payload
                    self._inv = inv; self._delta = delta
                    self._finish_run()
                    self._refresh_inventory(); self._refresh_findings()
                    n = len(inv); flagged = sum(1 for f in inv.values() if f.flags)
                    self._status.config(text=f"Listo · {n} cert(s) únicos · {flagged} con hallazgos")
                    self._logln(f"Completado: {n} certificado(s), {flagged} con hallazgos.")
                    self._record_scan_result()
                    if n:
                        self._show_tab("inventory")
                    self._maybe_schedule_next()
        except queue.Empty:
            pass
        self.after(80, self._pump)

    def _maybe_schedule_next(self):
        """Descubrimiento continuo: si 'Repetir cada N min' > 0, reprograma el scan."""
        try:
            mins = int(self.v_schedule.get())
        except ValueError:
            mins = 0
        if self._sched_job is not None:
            try: self.after_cancel(self._sched_job)
            except Exception: pass
            self._sched_job = None
        if mins > 0:
            self._logln(f"Próximo descubrimiento en {mins} min (continuo).")
            self._status.config(text=f"Programado · próximo scan en {mins} min")
            self._sched_job = self.after(mins * 60 * 1000,
                                         lambda: self._start() if not self._busy else None)

    def _finish_run(self):
        self._busy = False
        run_label = (f"▶  Escanear {self._profile['dc_name']} completo"
                     if self._profile else "▶  Iniciar descubrimiento")
        self._run_btn.config(state="normal"); self._big_run.config(state="normal", text=run_label)
        self._stop_btn.config(state="disabled"); self._stop_btn.wrap.config(bg=T["muted"])
        self._pb["value"] = 0
        self._update_scan_tab_progress(0.0)

    # --------------------------------------------------------- refresh views
    def _refresh_inventory(self):
        tree = self._inv_tree
        tree.delete(*tree.get_children())
        flt = self.v_filter.get().lower().strip()
        items = sorted(self._inv.values(), key=lambda f: f.days_to_expiry)
        shown = 0
        for f in items:
            cn = f.subject_cn or (f.sans[0] if f.sans else "(sin CN)")
            sev = f.max_severity()
            row = (cn, f.days_to_expiry, f"{f.key_type}{f.key_size}", f.source,
                   f.tls_version, f.revocation or "—", f.delta or "—",
                   sev if f.flags else "ok",
                   ", ".join(f.seen_at[:2]))
            if flt and flt not in " ".join(str(v) for v in row).lower() \
                    and flt not in " ".join(f.flags).lower():
                continue
            tag = "odd" if shown % 2 else "even"
            tree.insert("", "end", iid=f.fingerprint_sha256, values=row, tags=(tag,))
            shown += 1
        self._inv_count.config(text=f"{shown} de {len(self._inv)} certificado(s)")

    def _on_inv_select(self, _evt):
        sel = self._inv_tree.selection()
        for w in self._detail_body.winfo_children(): w.destroy()
        if not sel:
            return
        f = self._inv.get(sel[0])
        if not f:
            return
        def line(k, v, accent=False):
            r = tk.Frame(self._detail_body, bg=T["panel_bg"]); r.pack(fill="x", pady=1)
            tk.Label(r, text=k, font=(_FUI, 10, "bold"), bg=T["panel_bg"], fg=T["muted"],
                     width=12, anchor="w").pack(side="left")
            tk.Label(r, text=str(v), font=(_FMONO, 10), bg=T["panel_bg"],
                     fg=T["accent"] if accent else T["text"], anchor="w",
                     wraplength=200, justify="left").pack(side="left", fill="x", expand=True)
        cn = f.subject_cn or (f.sans[0] if f.sans else "(sin CN)")
        tk.Label(self._detail_body, text=cn, font=(_FUI, 10, "bold"), bg=T["panel_bg"],
                 fg=T["text"], anchor="w", wraplength=290, justify="left").pack(fill="x", pady=(0, 6))
        if f.flags:
            pr = tk.Frame(self._detail_body, bg=T["panel_bg"]); pr.pack(fill="x", pady=(0, 6))
            for fl in f.flags:
                self._pill(pr, fl, cd.SEVERITY.get(fl, "low")).pack(side="left", padx=(0, 4), pady=2)
        line("Emisor", f.issuer_cn or "—")
        line("Vence en", f"{f.days_to_expiry} días", accent=(f.days_to_expiry < 30))
        line("Validez", f"{f.validity_days} días")
        line("Llave", f"{f.key_type} {f.key_size}")
        line("Firma", f.sig_algorithm)
        if f.tls_version: line("TLS", f"{f.tls_version} · {f.cipher}")
        if f.revocation: line("Revocación", f.revocation,
                              accent=(f.revocation == "revoked"))
        line("Fuente", f.source)
        if f.delta: line("Cambio", f.delta, accent=(f.delta in ("NEW", "RENEWED")))
        if f.sans: line("SAN", ", ".join(f.sans[:6]))
        if f.hostnames: line("PTR", ", ".join(f.hostnames[:4]))
        line("Visto en", "\n".join(f.seen_at[:6]))
        line("SHA-256", f.fingerprint_sha256[:32] + "…")

        # --- Responsable / nota (editable, persiste al inventario vivo) ---
        tk.Frame(self._detail_body, bg=T["border_bg"], height=1).pack(fill="x", pady=(8, 6))
        tk.Label(self._detail_body, text="RESPONSABLE / NOTA", font=(_FUI, 10, "bold"),
                 bg=T["panel_bg"], fg=T["muted"], anchor="w").pack(fill="x")
        v_owner = tk.StringVar(value=f.owner)
        v_note = tk.StringVar(value=f.note)
        e1 = tk.Entry(self._detail_body, textvariable=v_owner, font=(_FUI, 10),
                      bg=T["surface2"], fg=T["text"], insertbackground=T["text"],
                      relief="flat", highlightthickness=1, highlightbackground=T["border"])
        e1.pack(fill="x", pady=(3, 3), ipady=3, ipadx=4)
        e2 = tk.Entry(self._detail_body, textvariable=v_note, font=(_FUI, 10),
                      bg=T["surface2"], fg=T["text"], insertbackground=T["text"],
                      relief="flat", highlightthickness=1, highlightbackground=T["border"])
        e2.pack(fill="x", pady=(0, 4), ipady=3, ipadx=4)

        def save_owner():
            f.owner = v_owner.get().strip()
            f.note = v_note.get().strip()
            try:
                cd.save_inventory(self._inv, merge=True)
                self._logln(f"Responsable guardado para {cn}: {f.owner or '—'}")
                self._refresh_inventory()
            except Exception as ex:
                self._logln(f"No se pudo guardar responsable: {ex!r}")
        tk.Button(self._detail_body, text="Guardar responsable", command=save_owner,
                  font=(_FUI, 10, "bold"), bg=T["accent"], fg=T["button_fg"], relief="flat",
                  bd=0, padx=10, pady=5, cursor="hand2",
                  activebackground=T["accent_hi"]).pack(anchor="w", pady=(2, 0))

    def _refresh_findings(self):
        for w in self._sev_bar.winfo_children(): w.destroy()
        tree = self._find_tree
        tree.delete(*tree.get_children())
        flagged = [f for f in self._inv.values() if f.flags]
        from collections import Counter
        c = Counter(cd.SEVERITY.get(fl, "low") for f in flagged for fl in f.flags)
        for sev in ("critical", "high", "medium", "low"):
            p = self._pill(self._sev_bar, f"{sev.upper()}  {c.get(sev, 0)}", sev)
            p.pack(side="left", padx=(0, 6))
        flagged.sort(key=lambda f: (_SEV_ORDER.get(f.max_severity(), 9), f.days_to_expiry))
        for i, f in enumerate(flagged):
            cn = f.subject_cn or (f.sans[0] if f.sans else "(sin CN)")
            sev = f.max_severity()
            tag = sev if sev in ("critical", "high") else ("odd" if i % 2 else "even")
            tree.insert("", "end", values=(sev.upper(), cn, f.days_to_expiry,
                        ", ".join(f.flags), ", ".join(f.seen_at[:2])), tags=(tag,))

    # --------------------------------------------------------------- export
    def _export(self, kind: str):
        if not self._inv:
            messagebox.showinfo("Exportar", "No hay inventario que exportar todavía."); return
        if kind == "json":
            p = filedialog.asksaveasfilename(defaultextension=".json",
                                             filetypes=[("JSON", "*.json")])
            if p: cd.dump(self._inv, p); self._logln(f"Exportado JSON → {p}")
        elif kind == "html":
            p = filedialog.asksaveasfilename(defaultextension=".html",
                                             filetypes=[("HTML", "*.html")])
            if p:
                cd.dump_html(self._inv, p, self._delta)
                self._logln(f"Reporte HTML → {p}")
        else:
            p = filedialog.asksaveasfilename(defaultextension=".csv",
                                             filetypes=[("CSV", "*.csv")])
            if p: cd.dump_csv(self._inv, p); self._logln(f"Exportado CSV → {p}")

    # ---------------------------------------------------------------- theme
    def _toggle_theme(self):
        self._dark = not self._dark
        _apply_palette(self._dark)
        self._theme_btn.config(text="🌙" if self._dark else "☀")
        self._setup_ttk_styles()
        self._recolour(self)
        self._retag_trees()
        self._rebuild_scan_tabs()
        dash = getattr(self, "_scan_dashboard", None)
        if dash is not None:
            try: dash.apply_theme()
            except Exception: pass
        self._show_tab(self._active_tab)
        if self._inv:
            self._refresh_inventory(); self._refresh_findings()

    def _retag_trees(self):
        """Las etiquetas odd/even/critical/high se fijan al crear el árbol con
        la paleta de ese momento; al cambiar de tema hay que repintarlas."""
        for tree in (getattr(self, "_inv_tree", None), getattr(self, "_find_tree", None)):
            if tree is None:
                continue
            tree.tag_configure("even", background=T["panel_bg"])
            tree.tag_configure("odd", background=T["surface2"])
        if getattr(self, "_find_tree", None) is not None:
            self._find_tree.tag_configure("critical", foreground=_sev_pill("critical")[1])
            self._find_tree.tag_configure("high", foreground=_sev_pill("high")[1])

    def _recolour(self, w):
        """Repinta recursivamente según el rol de color actual de cada widget."""
        old_light = _PALETTE_LIGHT; old_dark = _PALETTE_DARK
        inv_bg = {v: k for k, v in (old_dark if not self._dark else old_light).items()}
        try:
            for opt in ("bg", "background"):
                try: cur = w.cget(opt)
                except tk.TclError: continue
                role = inv_bg.get(str(cur))
                if role and role in T:
                    w.configure(**{opt: T[role]})
                break
            for opt in ("fg", "foreground"):
                try: cur = w.cget(opt)
                except tk.TclError: continue
                role = inv_bg.get(str(cur))
                if role and role in T:
                    w.configure(**{opt: T[role]})
                break
        except tk.TclError:
            pass
        for c in w.winfo_children():
            self._recolour(c)


# --------------------------------------------------------------------------- #
#  Injerto opcional en el escáner principal (hook self._inv_tab)
# --------------------------------------------------------------------------- #
class InventoryTab(tk.Frame):
    """Envoltura para montar el panel dentro del escáner SecDevOps existente.
    Expone apply_theme() y refresh() como espera el hook _inv_tab del host."""
    def __init__(self, master, **kw):
        super().__init__(master, **kw)
        # En un injerto real se compartiría el AppInventoryStore del host;
        # aquí dejamos el panel autónomo como referencia visual/funcional.
        tk.Label(self, text="Monte CertDiscoveryApp o reutilice sus _build_* aquí.",
                 font=(_FUI, 10)).pack(padx=20, pady=20)

    def apply_theme(self):  # llamado por el host al cambiar de tema
        pass

    def refresh(self):      # llamado por el host tras un escaneo
        pass


def main():
    app = CertDiscoveryApp()
    app.mainloop()


if __name__ == "__main__":
    main()
