#!/usr/bin/env python3
"""
cert_discovery.py — Motor interno de descubrimiento de certificados (reemplazo de Venafi).

Arquitectura híbrida multi-fuente (igual que los líderes del mercado:
Venafi/CyberArk, Keyfactor, AppViewX, DigiCert):

  FUENTE 1 · Red activa   -> handshake TLS directo + STARTTLS (este módulo)
  FUENTE 2 · Reachability -> masscan/zmap (externo)   ... adaptador from_masscan()
  FUENTE 3 · Escala TLS   -> zgrab2 (externo)         ... adaptador via_zgrab2()
  FUENTE 4 · Sistema de archivos -> .pem/.der/.crt/.p12/.pfx  (estilo agente Venafi)
  FUENTE 5 · Transparencia (CT)  -> crt.sh  (descubre shadow-IT / activos olvidados)
  CEREBRO  · parseo x509, dedup por fingerprint, validación de cadena,
             reglas de higiene, detección de cambios (delta), inventario

Mejoras frente al PoC original (lo que hacen los mejores descubridores):
  • STARTTLS (SMTP/IMAP/POP3/FTP/LDAP/PostgreSQL), no solo TLS implícito
  • IPv6 + resolución de hostnames (getaddrinfo) y PTR inverso
  • Captura de la CADENA completa, no solo el leaf, con validación de confianza
  • Versión TLS y cifrado negociados (para flag de protocolos obsoletos)
  • Descubrimiento por Certificate Transparency (crt.sh) -> activos externos/olvidados
  • Descubrimiento en sistema de archivos (certs "en reposo")
  • Detección de cambios contra un inventario previo (NUEVO/RENOVADO/ELIMINADO)
  • Exclusiones (IP/CIDR/host/puerto)
  • Reglas de higiene ampliadas (ver SEVERITY más abajo)
  • Salida JSON + CSV

Uso rápido:
    python cert_discovery.py 10.0.0.0/24 --ports 443,8443 --out inv.json
    python cert_discovery.py mail.banco.local --ports 25,587,143 --starttls auto
    python cert_discovery.py --ct bancobase.com --resolve-scan --out inv.json
    python cert_discovery.py --scan-files /etc/ssl --out reposo.json
    python cert_discovery.py 10.0.0.0/24 --baseline inv_ayer.json --csv inv.csv
    python cert_discovery.py --demo
"""

import argparse
import asyncio
import csv as _csv
import ipaddress
import json
import os
import socket
import ssl
import struct
import subprocess
import sys
import threading
import warnings

# Bajamos deliberadamente el piso de protocolo a TLS 1.0 para CAPTURAR (y luego
# marcar) servidores obsoletos; silenciamos el aviso de deprecación que esto causa.
warnings.filterwarnings("ignore", message=".*TLSv1.*", category=DeprecationWarning)
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from hashlib import sha256, sha1

try:
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.serialization import pkcs12
    from cryptography.x509.oid import NameOID, ExtensionOID
except ImportError:
    sys.exit("Falta 'cryptography'. Instala con: pip install cryptography")


# --------------------------------------------------------------------------- #
#  Catálogo de hallazgos de higiene -> severidad
#  (Centralizado para que CLI, CSV y GUI hablen el mismo idioma)
# --------------------------------------------------------------------------- #
SEVERITY = {
    # crítico — outage inminente o riesgo directo
    "EXPIRED":            "critical",
    "REVOKED":            "critical",
    "WEAK_SIGNATURE":     "critical",   # sha1 / md5
    "CA_AS_LEAF":         "critical",   # cert de CA sirviendo tráfico
    "NAME_MISMATCH":      "critical",   # el cert no cubre el host servido
    # alto
    "EXPIRING_SOON":      "high",       # <= 30 días
    "WEAK_KEY":           "high",       # RSA < 2048 / curva débil
    "NOT_YET_VALID":      "high",       # notBefore en el futuro
    "KEY_REUSE":          "high",       # misma llave pública en >1 cert
    "DEPRECATED_TLS":     "high",       # negoció < TLS 1.2
    "NO_SAN":             "high",       # sin SubjectAltName (rechazado por navegadores)
    "SELF_SIGNED":        "high",
    # medio
    "WILDCARD":           "medium",
    "OVERLONG_VALIDITY":  "medium",     # > 398 días (CA/B Forum)
    "INTERNAL_CA":        "medium",     # emitido por CA no pública
    "INCOMPLETE_CHAIN":   "medium",     # el servidor no envió intermedios
    "UNTRUSTED_CHAIN":    "medium",     # no valida contra el almacén de confianza
    # bajo / informativo
    "NO_REVOCATION_INFO": "low",        # sin OCSP ni CRL en el cert
    "EXPIRING_WINDOW":    "low",        # <= 90 días (aviso temprano)
}

# Tope de validez máxima del CA/B Forum (Ballot SC-081v3) — es POR FASES y
# aplica según la fecha de EMISIÓN (notBefore) del certificado, no la fecha de hoy.
#   <  2026-03-15 : 398 días
#   >= 2026-03-15 : 200 días   (ya vigente)
#   >= 2027-03-15 : 100 días
#   >= 2029-03-15 :  47 días
# Para certs internos (CA propia) el tope sigue siendo informativo, pero marcarlo
# alinea al banco con la práctica pública y prepara la migración a 47 días.
_VALIDITY_PHASES = (
    (datetime(2029, 3, 15, tzinfo=timezone.utc),  47),
    (datetime(2027, 3, 15, tzinfo=timezone.utc), 100),
    (datetime(2026, 3, 15, tzinfo=timezone.utc), 200),
)
MAX_VALIDITY_DAYS = 398   # piso histórico (compat. hacia atrás)


def max_validity_for(not_before: datetime) -> int:
    """Devuelve el tope de validez (en días) aplicable a un cert emitido en
    `not_before`, según el calendario por fases del CA/B Forum."""
    for cutoff, cap in _VALIDITY_PHASES:
        if not_before >= cutoff:
            return cap
    return MAX_VALIDITY_DAYS

# CAs públicas conocidas (heurística para distinguir CA interna vs pública).
# No pretende ser exhaustiva; sirve para marcar INTERNAL_CA con sensatez.
_PUBLIC_CA_HINTS = (
    "digicert", "sectigo", "let's encrypt", "lets encrypt", "isrg", "globalsign",
    "godaddy", "entrust", "amazon", "google trust", "microsoft", "comodo",
    "geotrust", "thawte", "rapidssl", "ssl.com", "buypass", "certum",
    "actalis", "quovadis", "identrust", "trustwave", "zerossl",
)


# --------------------------------------------------------------------------- #
#  Modelo de datos
# --------------------------------------------------------------------------- #
@dataclass
class CertFinding:
    fingerprint_sha256: str
    fingerprint_sha1: str
    spki_sha256: str               # hash de la llave pública (clave para KEY_REUSE)
    subject_cn: str
    sans: list
    issuer_cn: str
    not_before: str
    not_after: str
    days_to_expiry: int
    validity_days: int
    key_type: str
    key_size: int
    sig_algorithm: str
    serial: str
    is_ca: bool = False
    ocsp_urls: list = field(default_factory=list)
    crl_urls: list = field(default_factory=list)
    chain_len: int = 0             # nº de certs que envió el servidor (0 = desconocido)
    tls_version: str = ""          # versión TLS negociada (solo fuente de red)
    cipher: str = ""
    source: str = "network"        # network | starttls | file | ct | zgrab2
    # Dónde se ha visto este cert (clave para dedup global)
    seen_at: list = field(default_factory=list)   # ["10.0.0.5:443", "file:///etc/...", ...]
    hostnames: list = field(default_factory=list) # PTR / nombres asociados
    # Flags de higiene (el valor real de un inventario)
    flags: list = field(default_factory=list)
    # Detección de cambios contra baseline
    delta: str = ""                # "" | NEW | RENEWED | UNCHANGED
    # Estado de revocación (OCSP). "" = no comprobado.
    revocation: str = ""           # "" | good | revoked | unknown
    # Metadatos de gestión (estilo Venafi: ¿de quién es este cert?)
    owner: str = ""                # equipo/persona responsable
    note: str = ""                 # nota libre
    first_seen: str = ""           # ISO; cuándo lo vimos por primera vez
    last_seen: str = ""            # ISO; última vez que lo vimos en un scan

    def max_severity(self) -> str:
        ranks = {"critical": 4, "high": 3, "medium": 2, "low": 1}
        best = 0
        for fl in self.flags:
            best = max(best, ranks.get(SEVERITY.get(fl, "low"), 1))
        return {4: "critical", 3: "high", 2: "medium", 1: "low", 0: "info"}[best]

    @classmethod
    def from_dict(cls, d: dict) -> "CertFinding":
        """Reconstruye un finding desde un dict (al cargar inventario JSON previo).
        Ignora claves desconocidas para tolerar inventarios de versiones futuras."""
        known = {f.name for f in cls.__dataclass_fields__.values()}
        return cls(**{k: v for k, v in d.items() if k in known})


# --------------------------------------------------------------------------- #
#  Capa 3: parseo x509 + reglas de higiene
# --------------------------------------------------------------------------- #
def _name_cn(name) -> str:
    try:
        attrs = name.get_attributes_for_oid(NameOID.COMMON_NAME)
        return attrs[0].value if attrs else ""
    except Exception:
        return ""


def _host_matches(host: str, names: list) -> bool:
    """¿`host` (CN/SAN) cubre el nombre servido? Soporta comodín de 1 nivel."""
    host = (host or "").lower().rstrip(".")
    if not host:
        return True   # conectamos por IP: no podemos juzgar -> no marcar mismatch
    for n in names:
        n = (n or "").lower().rstrip(".")
        if not n:
            continue
        if n == host:
            return True
        if n.startswith("*."):
            base = n[2:]
            # comodín cubre exactamente un nivel a la izquierda
            if "." in host and host.split(".", 1)[1] == base:
                return True
    return False


def parse_certificate(der: bytes, location: str, *, source: str = "network",
                      served_name: str | None = None, tls_version: str = "",
                      cipher: str = "", chain_len: int = 0,
                      chain_trusted: bool | None = None) -> CertFinding:
    """Convierte el DER crudo en un hallazgo enriquecido + flags de higiene."""
    cert = x509.load_der_x509_certificate(der)
    fp = sha256(der).hexdigest()
    fp1 = sha1(der).hexdigest()

    # SANs
    sans = []
    try:
        ext = cert.extensions.get_extension_for_oid(ExtensionOID.SUBJECT_ALTERNATIVE_NAME)
        sans = ext.value.get_values_for_type(x509.DNSName)
    except x509.ExtensionNotFound:
        pass

    # Llave pública + hash SPKI (para KEY_REUSE)
    pub = cert.public_key()
    key_type = type(pub).__name__.replace("_", "").replace("PublicKey", "")
    key_size = getattr(pub, "key_size", 0)
    try:
        spki = pub.public_bytes(serialization.Encoding.DER,
                                serialization.PublicFormat.SubjectPublicKeyInfo)
        spki_hash = sha256(spki).hexdigest()
    except Exception:
        spki_hash = ""

    # basicConstraints CA?
    is_ca = False
    try:
        bc = cert.extensions.get_extension_for_oid(ExtensionOID.BASIC_CONSTRAINTS)
        is_ca = bool(bc.value.ca)
    except x509.ExtensionNotFound:
        pass

    # OCSP / CRL (AIA + CRLDistributionPoints)
    ocsp_urls, crl_urls = [], []
    try:
        aia = cert.extensions.get_extension_for_oid(ExtensionOID.AUTHORITY_INFORMATION_ACCESS)
        for desc in aia.value:
            if desc.access_method == x509.oid.AuthorityInformationAccessOID.OCSP:
                ocsp_urls.append(desc.access_location.value)
    except Exception:
        pass
    try:
        crl = cert.extensions.get_extension_for_oid(ExtensionOID.CRL_DISTRIBUTION_POINTS)
        for dp in crl.value:
            if dp.full_name:
                for n in dp.full_name:
                    crl_urls.append(getattr(n, "value", str(n)))
    except Exception:
        pass

    not_after = cert.not_valid_after_utc
    not_before = cert.not_valid_before_utc
    now = datetime.now(timezone.utc)
    days = (not_after - now).days
    validity_days = (not_after - not_before).days

    finding = CertFinding(
        fingerprint_sha256=fp,
        fingerprint_sha1=fp1,
        spki_sha256=spki_hash,
        subject_cn=_name_cn(cert.subject),
        sans=sans,
        issuer_cn=_name_cn(cert.issuer),
        not_before=not_before.isoformat(),
        not_after=not_after.isoformat(),
        days_to_expiry=days,
        validity_days=validity_days,
        key_type=key_type,
        key_size=key_size,
        sig_algorithm=cert.signature_hash_algorithm.name if cert.signature_hash_algorithm else "unknown",
        serial=format(cert.serial_number, "x"),
        is_ca=is_ca,
        ocsp_urls=ocsp_urls,
        crl_urls=crl_urls,
        chain_len=chain_len,
        tls_version=tls_version,
        cipher=cipher,
        source=source,
        seen_at=[location],
    )
    _now_iso = now.isoformat()
    finding.first_seen = _now_iso
    finding.last_seen = _now_iso

    # --- Reglas de higiene (esto es lo que da ROI en un banco) ---
    f = finding.flags
    covered = sans + ([finding.subject_cn] if finding.subject_cn else [])

    if days < 0:
        f.append("EXPIRED")
    elif days <= 30:
        f.append("EXPIRING_SOON")
    elif days <= 90:
        f.append("EXPIRING_WINDOW")
    if not_before > now:
        f.append("NOT_YET_VALID")
    if finding.subject_cn == finding.issuer_cn and finding.subject_cn:
        f.append("SELF_SIGNED")
    if finding.sig_algorithm in ("sha1", "md5"):
        f.append("WEAK_SIGNATURE")
    if key_type == "RSA" and key_size and key_size < 2048:
        f.append("WEAK_KEY")
    if key_type in ("EllipticCurve", "EC") and key_size and key_size < 256:
        f.append("WEAK_KEY")
    if not sans:
        f.append("NO_SAN")
    if any(s.startswith("*.") for s in covered):
        f.append("WILDCARD")
    if validity_days > max_validity_for(not_before):
        f.append("OVERLONG_VALIDITY")
    if is_ca and source in ("network", "starttls"):
        f.append("CA_AS_LEAF")
    if served_name and not _host_matches(served_name, covered):
        f.append("NAME_MISMATCH")
    if tls_version in ("TLSv1", "TLSv1.1", "SSLv3", "SSLv2", "TLSv1.0"):
        f.append("DEPRECATED_TLS")
    if not ocsp_urls and not crl_urls and "SELF_SIGNED" not in f:
        f.append("NO_REVOCATION_INFO")
    # CA interna: emitido por algo que no parece CA pública y no es autofirmado
    iss = (finding.issuer_cn or "").lower()
    if iss and "SELF_SIGNED" not in f and not any(h in iss for h in _PUBLIC_CA_HINTS):
        f.append("INTERNAL_CA")
    # Cadena
    if chain_len == 1 and "SELF_SIGNED" not in f:
        f.append("INCOMPLETE_CHAIN")
    if chain_trusted is False:
        f.append("UNTRUSTED_CHAIN")
    return finding


def flag_key_reuse(inventory: dict[str, CertFinding]) -> None:
    """Marca KEY_REUSE en todo cert cuya llave pública (SPKI) aparece en >1 cert.
    Reutilizar la misma llave entre certificados es un anti-patrón de higiene."""
    from collections import defaultdict
    by_spki: dict[str, list[str]] = defaultdict(list)
    for fp, fnd in inventory.items():
        if fnd.spki_sha256:
            by_spki[fnd.spki_sha256].append(fp)
    for spki, fps in by_spki.items():
        if len(fps) > 1:
            for fp in fps:
                if "KEY_REUSE" not in inventory[fp].flags:
                    inventory[fp].flags.append("KEY_REUSE")


# --------------------------------------------------------------------------- #
#  Capa 2 (nativa): captura TLS en Python  (+ STARTTLS, IPv6, cadena)
# --------------------------------------------------------------------------- #
def _abortive_close(sock: socket.socket):
    """SO_LINGER con timeout 0 -> cierre con RST en vez de FIN.
    Igual que Venafi: evita agotar puertos efímeros en scans grandes."""
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER,
                        struct.pack("ii", 1, 0))
    except OSError:
        pass


# Puerto -> protocolo STARTTLS por defecto. 'auto' usa este mapa.
STARTTLS_PORTS = {
    25: "smtp", 587: "smtp", 465: "tls",      # 465 = SMTPS implícito
    110: "pop3", 143: "imap", 21: "ftp",
    389: "ldap", 5432: "postgres", 3306: "mysql",
}


def _read_line(sock: socket.socket) -> bytes:
    buf = b""
    while not buf.endswith(b"\n") and len(buf) < 4096:
        chunk = sock.recv(1)
        if not chunk:
            break
        buf += chunk
    return buf


def _starttls(sock: socket.socket, proto: str) -> bool:
    """Lleva un socket en claro hasta el punto de upgrade TLS según el protocolo.
    Devuelve True si el servidor aceptó el comando STARTTLS."""
    try:
        if proto == "smtp":
            _read_line(sock)                       # 220 greeting
            sock.sendall(b"EHLO certdiscovery\r\n")
            # drenar respuesta EHLO (multilínea 250-)
            for _ in range(20):
                line = _read_line(sock)
                if not line or (line[3:4] == b" "):
                    break
            sock.sendall(b"STARTTLS\r\n")
            return _read_line(sock).startswith(b"220")
        if proto == "imap":
            _read_line(sock)                       # * OK greeting
            sock.sendall(b"a1 STARTTLS\r\n")
            return b"OK" in _read_line(sock)
        if proto == "pop3":
            _read_line(sock)                       # +OK greeting
            sock.sendall(b"STLS\r\n")
            return _read_line(sock).startswith(b"+OK")
        if proto == "ftp":
            _read_line(sock)                       # 220 greeting
            sock.sendall(b"AUTH TLS\r\n")
            return _read_line(sock).startswith(b"234")
        if proto == "ldap":
            # LDAP StartTLS extended request (OID 1.3.6.1.4.1.1466.20037), msgID 1
            req = bytes.fromhex("30 1d 02 01 01 77 18 80 16"
                                "312e332e362e312e342e312e313436362e3230303337".replace(" ", ""))
            sock.sendall(req)
            resp = sock.recv(64)
            return b"\x0a\x01\x00" in resp          # resultCode success(0)
        if proto == "postgres":
            # SSLRequest: length=8, code=80877103
            sock.sendall(struct.pack("!ii", 8, 80877103))
            return sock.recv(1) == b"S"
        if proto == "mysql":
            return _mysql_ssl_request(sock)
    except OSError:
        return False
    return False


def _mysql_ssl_request(sock: socket.socket) -> bool:
    """Protocolo real de MySQL/MariaDB para iniciar TLS (no es STARTTLS clásico
    en texto, pero cumple el mismo papel): el servidor manda primero un paquete
    de saludo (Handshake V10) anunciando sus capacidades; si trae el flag
    CLIENT_SSL, el cliente responde con un paquete "SSLRequest" (una versión
    truncada del handshake response, solo con las capability flags + charset)
    y, sin esperar respuesta, el servidor empieza a hablar TLS de inmediato.

    Antes este branch regresaba False siempre ('no soportado'), así que el
    puerto 3306 —incluido por defecto en el perfil de Datacenter— nunca
    capturaba nada aunque el servidor sí ofreciera TLS."""
    CLIENT_SSL = 0x00000800
    CLIENT_PROTOCOL_41 = 0x00000200
    CLIENT_LONG_PASSWORD = 0x00000001
    try:
        hdr = _recv_exact(sock, 4)
        if hdr is None:
            return False
        length = hdr[0] | (hdr[1] << 8) | (hdr[2] << 16)
        seq = hdr[3]
        payload = _recv_exact(sock, length)
        if payload is None or len(payload) < 1:
            return False

        idx = 1                                    # protocol_version
        nul = payload.index(b"\x00", idx)           # server_version (NUL-terminado)
        idx = nul + 1
        idx += 4                                    # thread_id (4 bytes)
        idx += 8                                     # auth_plugin_data_part_1 (8 bytes)
        idx += 1                                     # filler (0x00)
        if idx + 2 > len(payload):
            return False
        cap_lower = payload[idx] | (payload[idx + 1] << 8)
        if not (cap_lower & CLIENT_SSL):
            return False                             # el servidor no ofrece TLS en este puerto

        cap = CLIENT_SSL | CLIENT_PROTOCOL_41 | CLIENT_LONG_PASSWORD
        body = struct.pack("<IIB23x", cap, 16 * 1024 * 1024, 33)  # charset 33 = utf8_general_ci
        pkt_len = struct.pack("<I", len(body))[:3]
        sock.sendall(pkt_len + bytes([(seq + 1) & 0xFF]) + body)
        return True                                  # a partir de aquí el server ya habla TLS
    except (OSError, ValueError, IndexError):
        return False


def _recv_exact(sock: socket.socket, n: int) -> bytes | None:
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            return None
        buf += chunk
    return buf


def _capture_sync(host: str, port: int, sni: str | None, timeout: float,
                  starttls: str = "off", check_trust: bool = False) -> dict | None:
    """Un handshake TLS (directo o vía STARTTLS). Devuelve dict con DER del leaf,
    longitud de cadena, versión y cifrado. NO valida la cadena por defecto:
    queremos el cert aunque sea autofirmado / expirado / con CN incorrecto."""
    proto = starttls
    if starttls == "auto":
        proto = STARTTLS_PORTS.get(port, "off")
        if proto == "tls":
            proto = "off"

    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    try:
        ctx.minimum_version = ssl.TLSVersion.TLSv1
    except ValueError:
        pass

    # getaddrinfo -> soporta IPv4, IPv6 y hostnames
    try:
        infos = socket.getaddrinfo(host, port, proto=socket.IPPROTO_TCP)
    except OSError:
        return None
    if not infos:
        return None
    family, socktype, sproto, _, sockaddr = infos[0]

    raw = socket.socket(family, socktype, sproto)
    raw.settimeout(timeout)
    try:
        raw.connect(sockaddr)
    except OSError:
        raw.close()
        return None

    try:
        if proto not in ("off", "", "tls", None):
            if not _starttls(raw, proto):
                return None
        with ctx.wrap_socket(raw, server_hostname=sni or None) as ss:
            der = ss.getpeercert(binary_form=True)
            version = ss.version() or ""
            cipher = (ss.cipher() or ("",))[0]
            chain_ders = _chain_ders(ss)
        if not der:
            return None
        result = {"der": der, "version": version, "cipher": cipher,
                  "chain_len": len(chain_ders) if chain_ders else 0,
                  "chain_ders": chain_ders, "trusted": None}
        if check_trust:
            result["trusted"] = _trust_probe(host, port, sni, timeout, proto)
        return result
    except (ssl.SSLError, OSError):
        return None
    finally:
        _abortive_close(raw)
        try:
            raw.close()
        except OSError:
            pass


def _chain_ders(ss: ssl.SSLSocket) -> list[bytes]:
    """Best-effort: lista de DERs de la cadena que envió el servidor (leaf primero).
    Usa la API privada get_unverified_chain(); en CPython 3.10–3.12 devuelve
    objetos cuyo .public_bytes() es PEM, así que lo reconvertimos a DER.
    Lista vacía = no se pudo determinar (no implica cadena incompleta)."""
    out: list[bytes] = []
    try:
        chain = ss._sslobj.get_unverified_chain() or []
    except Exception:
        return out
    for c in chain:
        try:
            pem = c.public_bytes()           # str PEM en 3.10–3.12
            if isinstance(pem, str):
                cert = x509.load_pem_x509_certificate(pem.encode())
            else:
                cert = x509.load_der_x509_certificate(pem)
            out.append(cert.public_bytes(serialization.Encoding.DER))
        except Exception:
            continue
    return out


def _trust_probe(host: str, port: int, sni: str | None, timeout: float, proto: str) -> bool | None:
    """Segundo handshake, esta vez validando contra el almacén de confianza del SO.
    True/False = confía/no confía; None = no se pudo determinar."""
    try:
        vctx = ssl.create_default_context()
        infos = socket.getaddrinfo(host, port, proto=socket.IPPROTO_TCP)
        family, socktype, sproto, _, sockaddr = infos[0]
        raw = socket.socket(family, socktype, sproto)
        raw.settimeout(timeout)
        raw.connect(sockaddr)
        try:
            if proto not in ("off", "", "tls", None):
                _starttls(raw, proto)
            with vctx.wrap_socket(raw, server_hostname=(sni or host)):
                return True
        except ssl.SSLCertVerificationError:
            return False
        except (ssl.SSLError, OSError):
            return None
        finally:
            _abortive_close(raw)
            raw.close()
    except OSError:
        return None


async def capture(host: str, port: int, sni: str | None, timeout: float,
                  starttls: str = "off", check_trust: bool = False) -> dict | None:
    return await asyncio.to_thread(_capture_sync, host, port, sni, timeout,
                                   starttls, check_trust)


# --------------------------------------------------------------------------- #
#  Revocación OCSP  (lo que activa el flag REVOKED, antes nunca poblado)
# --------------------------------------------------------------------------- #
def revocation_status(leaf_der: bytes, issuer_der: bytes | None,
                      timeout: float = 5.0) -> str:
    """Comprueba el estado de revocación de un cert vía OCSP (AIA del propio cert).
    Necesita el cert emisor (issuer) para construir la petición — de ahí que
    capturemos la cadena completa. Devuelve: good | revoked | unknown.

    'unknown' es deliberadamente conservador: sin issuer, sin URL OCSP, o ante
    cualquier fallo de red/respuesta, NO afirmamos nada (no marcamos REVOKED)."""
    if not issuer_der:
        return "unknown"
    try:
        from cryptography.x509 import ocsp
        from cryptography.hazmat.primitives import hashes as _h
        import urllib.request

        leaf = x509.load_der_x509_certificate(leaf_der)
        issuer = x509.load_der_x509_certificate(issuer_der)

        # URL OCSP desde la AIA del leaf
        ocsp_url = None
        try:
            aia = leaf.extensions.get_extension_for_oid(
                ExtensionOID.AUTHORITY_INFORMATION_ACCESS)
            for d in aia.value:
                if d.access_method == x509.oid.AuthorityInformationAccessOID.OCSP:
                    ocsp_url = d.access_location.value
                    break
        except Exception:
            return "unknown"
        if not ocsp_url:
            return "unknown"

        # SHA1 es lo que esperan casi todos los responders OCSP públicos
        req = (ocsp.OCSPRequestBuilder()
               .add_certificate(leaf, issuer, _h.SHA1())
               .build())
        body = req.public_bytes(serialization.Encoding.DER)
        http = urllib.request.Request(
            ocsp_url, data=body,
            headers={"Content-Type": "application/ocsp-request",
                     "Accept": "application/ocsp-response"})
        with urllib.request.urlopen(http, timeout=timeout) as r:
            resp = ocsp.load_der_ocsp_response(r.read())
        if resp.response_status != ocsp.OCSPResponseStatus.SUCCESSFUL:
            return "unknown"
        st = resp.certificate_status
        if st == ocsp.OCSPCertStatus.REVOKED:
            return "revoked"
        if st == ocsp.OCSPCertStatus.GOOD:
            return "good"
        return "unknown"
    except Exception:
        return "unknown"


async def _ptr(ip: str) -> list[str]:
    """PTR inverso best-effort (para nombrar activos en el inventario)."""
    def _lookup():
        try:
            name, aliases, _ = socket.gethostbyaddr(ip)
            return [name] + list(aliases)
        except OSError:
            return []
    return await asyncio.to_thread(_lookup)


# --------------------------------------------------------------------------- #
#  Expansión de objetivos + exclusiones
# --------------------------------------------------------------------------- #
def expand_targets(spec: str) -> list[str]:
    """CIDR (v4/v6), rango con guion, IP suelta o hostname -> lista de hosts."""
    out = []
    for token in spec.split(","):
        token = token.strip()
        if not token:
            continue
        try:
            if "/" in token:
                out += [str(h) for h in ipaddress.ip_network(token, strict=False).hosts()]
            elif "-" in token and _looks_like_ip_range(token):
                a, b = [t.strip() for t in token.split("-", 1)]
                start = int(ipaddress.ip_address(a))
                end = int(ipaddress.ip_address(b))
                if end < start:
                    start, end = end, start
                out += [str(ipaddress.ip_address(i)) for i in range(start, end + 1)]
            else:
                out.append(token)  # IP suelta o hostname
        except ValueError:
            out.append(token)
    return out


def count_targets(spec: str) -> int:
    """Cuenta cuántos hosts produciría expand_targets(spec) SIN materializar
    la lista completa. Para CIDR/rangos grandes (un /16 de Datacenter son
    65 534 hosts) expand_targets() de verdad genera cada string — bien para
    escanear, un desperdicio si solo quieres mostrar un número en la GUI."""
    total = 0
    for token in spec.split(","):
        token = token.strip()
        if not token:
            continue
        try:
            if "/" in token:
                net = ipaddress.ip_network(token, strict=False)
                total += max(net.num_addresses - 2, 1) if net.num_addresses > 2 else net.num_addresses
            elif "-" in token and _looks_like_ip_range(token):
                a, b = [t.strip() for t in token.split("-", 1)]
                start, end = int(ipaddress.ip_address(a)), int(ipaddress.ip_address(b))
                total += abs(end - start) + 1
            else:
                total += 1
        except ValueError:
            total += 1
    return total


def _looks_like_ip_range(token: str) -> bool:
    """True solo si `a-b` tiene AMBOS extremos parseables como IP. Evita tratar
    hostnames con guion (web-01.banco.local) como rangos de IP por accidente."""
    if token.count("-") != 1:
        return False
    a, _, b = token.partition("-")
    try:
        ipaddress.ip_address(a.strip())
        ipaddress.ip_address(b.strip())
        return True
    except ValueError:
        return False


def _build_excluder(exclude_spec: str):
    """Devuelve una función exclude(host, port) -> bool a partir de una
    especificación coma-separada de IP/CIDR/host[:puerto].

    Un token SIN puerto (IP, CIDR o host) excluye ese destino en TODOS los
    puertos. Un token CON puerto (host:puerto / CIDR:puerto) excluye
    ÚNICAMENTE ese puerto en ESE destino — no afecta a otros hosts.
    Un token que es solo un número (p.ej. "587") excluye ese puerto en
    TODOS los destinos; es la única forma de excluir un puerto global."""
    nets, hosts, ports = [], set(), set()          # exclusiones sin puerto (o puerto global)
    scoped_nets, scoped_hosts = [], set()           # exclusiones host:puerto (ámbito acotado)
    for tok in (exclude_spec or "").split(","):
        tok = tok.strip()
        if not tok:
            continue
        if tok.isdigit():
            ports.add(int(tok)); continue
        h, sep, p = tok.partition(":")
        if sep and p.isdigit():
            port = int(p)
            try:
                scoped_nets.append((ipaddress.ip_network(h, strict=False), port))
            except ValueError:
                scoped_hosts.add((h.lower(), port))
            continue
        try:
            nets.append(ipaddress.ip_network(tok, strict=False))
        except ValueError:
            hosts.add(tok.lower())

    def excluded(host: str, port: int) -> bool:
        if port in ports:
            return True
        hl = host.lower()
        if hl in hosts:
            return True
        try:
            ipo = ipaddress.ip_address(host)
        except ValueError:
            ipo = None
        if ipo is not None and any(ipo in n for n in nets):
            return True
        if (hl, port) in scoped_hosts:
            return True
        if ipo is not None and any(port == p and ipo in n for n, p in scoped_nets):
            return True
        return False
    return excluded


# --------------------------------------------------------------------------- #
#  Pre-filtro de puertos abiertos  (equivalente ligero a masscan/zmap)
#  Un handshake TLS completo cuesta un timeout entero por IP muerta. En un
#  rango grande (p.ej. un /16 de Datacenter, ~65 mil hosts) la inmensa
#  mayoría de las direcciones no tienen nada escuchando, así que barrer con
#  el motor TLS directo puede tardar horas. Este pre-filtro usa conexiones
#  TCP simples con asyncio nativo (sin hilos, sin TLS) -> aguanta mucha más
#  concurrencia real que el handshake completo, y solo pasa al motor TLS los
#  pares host:puerto donde de verdad hay algo escuchando.
# --------------------------------------------------------------------------- #
async def _tcp_probe(host: str, port: int, timeout: float) -> bool:
    try:
        _, writer = await asyncio.wait_for(
            asyncio.open_connection(host=host, port=port), timeout=timeout)
    except (OSError, asyncio.TimeoutError):
        return False
    writer.close()
    try:
        await writer.wait_closed()
    except Exception:
        pass
    return True


async def prefilter_open_ports(targets: list[str], ports: list[int], *,
                                concurrency: int = 4000, timeout: float = 1.5,
                                exclude: str = "", progress=None) -> list[tuple[str, int]]:
    """Barrido rápido host:puerto -> lista de los que respondieron abiertos.
    concurrency puede ser mucho más alta que la del motor TLS (no hay hilos
    de por medio ni handshake criptográfico, solo un connect())."""
    sem = asyncio.Semaphore(concurrency)
    excluded = _build_excluder(exclude)
    open_targets: list[tuple[str, int]] = []
    total = len(targets) * len(ports)
    done = 0
    lock = threading.Lock()

    async def probe(host: str, port: int):
        nonlocal done
        if excluded(host, port):
            with lock:
                done += 1
            return
        async with sem:
            ok = await _tcp_probe(host, port, timeout)
        with lock:
            if ok:
                open_targets.append((host, port))
            done += 1
            d = done
        if progress:
            progress(d, total, host, port)

    await asyncio.gather(*[probe(h, p) for h in targets for p in ports])
    return open_targets


# --------------------------------------------------------------------------- #
#  Motor de scan nativo
# --------------------------------------------------------------------------- #
async def scan(targets: list[str], ports: list[int], concurrency: int = 200,
               timeout: float = 3.0, starttls: str = "off",
               check_trust: bool = False, resolve_ptr: bool = False,
               exclude: str = "", progress=None, *,
               check_revocation: bool = False,
               sni_names: list[str] | None = None,
               prefilter: bool = False,
               prefilter_concurrency: int = 4000,
               prefilter_timeout: float = 1.5) -> dict[str, CertFinding]:
    """Motor de scan nativo. Devuelve inventario dedup por fingerprint.

    check_revocation: tras capturar, consulta OCSP y marca REVOKED si aplica.
    sni_names: lista de hostnames a probar como SNI sobre cada IP, para descubrir
               vhosts (varios certs tras una misma IP) que un scan plano omitiría.
    prefilter: antes del handshake TLS, hace un barrido TCP rápido y solo
               intenta el handshake completo en los pares host:puerto que
               respondieron. Recomendado para rangos grandes (/16 o más).
    """
    pairs = [(h, p) for h in targets for p in ports]
    if prefilter and pairs:
        pairs = await prefilter_open_ports(
            targets, ports, concurrency=prefilter_concurrency,
            timeout=prefilter_timeout, exclude=exclude, progress=progress)

    sem = asyncio.Semaphore(concurrency)
    inventory: dict[str, CertFinding] = {}
    excluded = _build_excluder(exclude)
    sni_names = sni_names or []
    total = len(pairs)
    done = 0
    # Cuando check_revocation=True, _ingest se despacha a un hilo real del
    # pool (ver worker() más abajo) para no bloquear el event loop con la
    # consulta OCSP. Eso significa que, a diferencia del caso sin OCSP (donde
    # todo corre cooperativamente en un solo hilo), aquí SÍ puede haber
    # varios hilos mutando `inventory` al mismo tiempo — típicamente cuando
    # el mismo certificado (mismo fingerprint) aparece en muchos hosts a la
    # vez, p.ej. un wildcard repartido en una granja de servidores. Sin este
    # candado, dos hilos pueden "empatar" en el check `fp in inventory` y uno
    # pisar el resultado del otro, perdiendo silenciosamente ubicaciones
    # (seen_at) del inventario.
    inv_lock = threading.Lock()

    def _ingest(res: dict, host: str, port: int, sni: str | None, names: list[str]):
        loc = f"{host}:{port}"
        if sni and sni != host:
            loc = f"{host}:{port}#{sni}"   # distinguir vhost en seen_at
        src = "starttls" if starttls not in ("off", "", None) else "network"
        # Solo juzgamos NAME_MISMATCH cuando el SNI es un hostname real
        # (conectar por IP no permite juzgar el nombre servido).
        served = sni if (sni and not _is_ip(sni)) else None
        finding = parse_certificate(
            res["der"], loc, source=src, served_name=served,
            tls_version=res["version"], cipher=res["cipher"],
            chain_len=res["chain_len"], chain_trusted=res["trusted"])
        finding.hostnames = [n for n in names if n]
        if check_revocation:
            chain = res.get("chain_ders") or []
            issuer_der = chain[1] if len(chain) > 1 else None
            finding.revocation = revocation_status(res["der"], issuer_der, timeout=5.0)
            if finding.revocation == "revoked" and "REVOKED" not in finding.flags:
                finding.flags.append("REVOKED")
        fp = finding.fingerprint_sha256
        with inv_lock:
            if fp in inventory:                # dedup global por fingerprint
                if loc not in inventory[fp].seen_at:
                    inventory[fp].seen_at.append(loc)
                for n in finding.hostnames:
                    if n not in inventory[fp].hostnames:
                        inventory[fp].hostnames.append(n)
            else:
                inventory[fp] = finding

    async def worker(host: str, port: int):
        nonlocal done
        if excluded(host, port):
            done += 1
            return
        # SNIs a probar: el propio host + extras (solo tiene sentido por IP/vhost)
        snis: list[str | None] = [host]
        if sni_names:
            snis += [s for s in sni_names if s and s != host]
        async with sem:
            for sni in snis:
                res = await capture(host, port, sni=sni, timeout=timeout,
                                    starttls=starttls, check_trust=check_trust)
                if res:
                    names = (await _ptr(host) if (resolve_ptr and _is_ip(host))
                             else ([host] if not _is_ip(host) else []))
                    await asyncio.to_thread(_ingest, res, host, port, sni, names) \
                        if check_revocation else _ingest(res, host, port, sni, names)
        done += 1
        if progress:
            progress(done, total, host, port)   # puede lanzar CancelledError

    await asyncio.gather(*[worker(h, p) for h, p in pairs])
    flag_key_reuse(inventory)
    return inventory


def _is_ip(host: str) -> bool:
    try:
        ipaddress.ip_address(host)
        return True
    except ValueError:
        return False


# --------------------------------------------------------------------------- #
#  FUENTE 4: descubrimiento en sistema de archivos (certs en reposo)
# --------------------------------------------------------------------------- #
_CERT_EXTS = (".pem", ".crt", ".cer", ".der", ".cert", ".p12", ".pfx", ".p7b",
              ".jks", ".keystore", ".ts", ".truststore")


def _try_import_jks():
    try:
        import jks  # pyjks
        return jks
    except ImportError:
        return None


def scan_files(root: str, passwords: list[bytes] | None = None) -> dict[str, CertFinding]:
    """Recorre `root` y extrae certificados de archivos PEM/DER/PKCS12/JKS.
    Equivalente ligero al agente de Venafi: encuentra certs 'en reposo'
    (en disco) que un scan de red nunca vería. JKS/keystores Java requieren
    'pip install pyjks' (opcional); si falta, esos archivos se omiten con aviso."""
    passwords = passwords or [None, b"", b"changeit", b"password"]
    str_pwds = [p.decode() if isinstance(p, bytes) else (p or "")
                for p in passwords] + ["changeit", ""]
    inventory: dict[str, CertFinding] = {}
    _jks = None
    _jks_checked = False

    def _add(der: bytes, loc: str):
        try:
            finding = parse_certificate(der, loc, source="file")
        except Exception:
            return
        fp = finding.fingerprint_sha256
        if fp in inventory:
            if loc not in inventory[fp].seen_at:
                inventory[fp].seen_at.append(loc)
        else:
            inventory[fp] = finding

    for dirpath, _, files in os.walk(root):
        for fn in files:
            if not fn.lower().endswith(_CERT_EXTS):
                continue
            path = os.path.join(dirpath, fn)
            loc = f"file://{path}"
            try:
                raw = open(path, "rb").read()
            except OSError:
                continue
            ext = os.path.splitext(fn)[1].lower()
            if ext in (".p12", ".pfx"):
                for pw in passwords:
                    try:
                        _, c, extra = pkcs12.load_key_and_certificates(raw, pw)
                        if c:
                            _add(c.public_bytes(serialization.Encoding.DER), loc)
                        for ec in (extra or []):
                            _add(ec.public_bytes(serialization.Encoding.DER), loc)
                        break
                    except Exception:
                        continue
            elif ext in (".jks", ".keystore", ".ts", ".truststore"):
                if not _jks_checked:
                    _jks = _try_import_jks(); _jks_checked = True
                    if _jks is None:
                        print("[scan_files] JKS detectado pero falta 'pyjks' "
                              "(pip install pyjks); se omiten los keystores Java.")
                if _jks is None:
                    continue
                ok = False
                for pw in str_pwds:
                    try:
                        ks = _jks.KeyStore.loads(raw, pw)
                        ok = True
                        # NOTA: en pyjks, hasattr() sobre las entradas puede lanzar
                        # KeyError (bug interno), así que discriminamos por isinstance.
                        for alias, e in ks.entries.items():
                            if isinstance(e, _jks.PrivateKeyEntry):
                                for _ctype, cder in e.cert_chain:
                                    _add(cder, f"{loc}#{alias}")
                            elif isinstance(e, _jks.TrustedCertEntry):
                                _add(e.cert, f"{loc}#{alias}")
                        break
                    except Exception:
                        continue
                if not ok:
                    print(f"[scan_files] No se pudo abrir keystore (clave?): {path}")
            elif b"-----BEGIN CERTIFICATE-----" in raw:
                # PEM: puede contener varios certs concatenados
                for block in raw.split(b"-----BEGIN CERTIFICATE-----")[1:]:
                    pem = b"-----BEGIN CERTIFICATE-----" + block.split(b"-----END CERTIFICATE-----")[0] + b"-----END CERTIFICATE-----"
                    try:
                        c = x509.load_pem_x509_certificate(pem)
                        _add(c.public_bytes(serialization.Encoding.DER), loc)
                    except Exception:
                        continue
            else:
                # DER binario
                try:
                    c = x509.load_der_x509_certificate(raw)
                    _add(c.public_bytes(serialization.Encoding.DER), loc)
                except Exception:
                    continue
    flag_key_reuse(inventory)
    return inventory


# --------------------------------------------------------------------------- #
#  FUENTE 6: almacén de certificados de Windows (estilo CAPI de Venafi)
# --------------------------------------------------------------------------- #
def scan_windows_store(stores: tuple[str, ...] = ("MY", "CA", "ROOT")) -> dict[str, CertFinding]:
    """Lee el almacén de certificados de Windows (LocalMachine) vía la API nativa
    `ssl.enum_certificates`. Es el equivalente ligero a la discovery CAPI de
    Venafi: encuentra certs que IIS/servicios usan desde el store, no desde disco.
    No-op (inventario vacío) fuera de Windows."""
    inventory: dict[str, CertFinding] = {}
    if not hasattr(ssl, "enum_certificates"):
        print("[windows-store] Solo disponible en Windows; omitido.")
        return inventory
    for store in stores:
        try:
            for der, enc, trust in ssl.enum_certificates(store):  # type: ignore[attr-defined]
                if enc != "x509_asn":
                    continue
                loc = f"winstore://LocalMachine/{store}"
                try:
                    finding = parse_certificate(der, loc, source="winstore")
                except Exception:
                    continue
                fp = finding.fingerprint_sha256
                if fp in inventory:
                    if loc not in inventory[fp].seen_at:
                        inventory[fp].seen_at.append(loc)
                else:
                    inventory[fp] = finding
        except Exception as e:
            print(f"[windows-store] No se pudo leer el store {store!r}: {e!r}")
    flag_key_reuse(inventory)
    return inventory




# --------------------------------------------------------------------------- #
#  FUENTE 5: Certificate Transparency (crt.sh)  -> shadow-IT / activos olvidados
# --------------------------------------------------------------------------- #
def ct_discover(domain: str, timeout: float = 30.0, retries: int = 3) -> list[str]:
    """Consulta crt.sh por todos los nombres con cert emitido para *domain*
    y sus subdominios. Devuelve hostnames únicos (sin comodín).
    Esto descubre activos públicos/olvidados que NUNCA aparecerían en un
    scan de red interno: justo el punto ciego más caro de un inventario.

    crt.sh es notoriamente inestable (502 / HTML / timeouts); reintentamos con
    backoff y toleramos respuestas no-JSON sin reventar el scan completo."""
    import urllib.request, urllib.parse, time
    q = urllib.parse.quote(f"%.{domain}")
    url = f"https://crt.sh/?q={q}&output=json"
    names: set[str] = set()
    last_err = None
    for attempt in range(retries):
        try:
            req = urllib.request.Request(
                url, headers={"User-Agent": "cert-discovery/2.0",
                              "Accept": "application/json"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                body = r.read().decode("utf-8", "replace").strip()
            if not body or body[:1] not in "[{":
                raise ValueError("crt.sh devolvió contenido no-JSON (¿rate-limit/502?)")
            data = json.loads(body)
            for row in data:
                val = (row.get("name_value") or "") + "\n" + (row.get("common_name") or "")
                for n in val.split("\n"):
                    n = n.strip().lower().lstrip("*.")
                    if n and "@" not in n and " " not in n:
                        names.add(n)
            return sorted(names)
        except Exception as e:
            last_err = e
            if attempt < retries - 1:
                time.sleep(2 * (attempt + 1))   # backoff: 2s, 4s
    raise RuntimeError(f"crt.sh falló tras {retries} intento(s): {last_err!r}")


# --------------------------------------------------------------------------- #
#  Capa 1 -> 2: adaptadores para las herramientas de escala
# --------------------------------------------------------------------------- #
def from_masscan(path: str) -> list[tuple[str, int]]:
    """Ingiere salida JSON de masscan (-oJ) -> [(ip, port), ...]."""
    targets = []
    with open(path) as fh:
        data = json.load(fh)
    for entry in data:
        ip = entry.get("ip")
        for p in entry.get("ports", []):
            if p.get("status") == "open":
                targets.append((ip, p.get("port")))
    return targets


def via_zgrab2(targets: list[tuple[str, int]], port: int = 443) -> dict[str, CertFinding]:
    """Delega la captura TLS a zgrab2 (Go) para escala real."""
    stdin = "\n".join(ip for ip, _ in targets) + "\n"
    proc = subprocess.run(
        ["zgrab2", "tls", "--port", str(port)],
        input=stdin, capture_output=True, text=True, check=True,
    )
    inventory: dict[str, CertFinding] = {}
    for line in proc.stdout.splitlines():
        if not line.strip():
            continue
        rec = json.loads(line)
        ip = rec.get("ip", "")
        try:
            chain = rec["data"]["tls"]["result"]["handshake_log"]["server_certificates"]
            import base64
            der = base64.b64decode(chain["certificate"]["raw"])
        except (KeyError, TypeError):
            continue
        loc = f"{ip}:{port}"
        finding = parse_certificate(der, loc, source="zgrab2")
        fp = finding.fingerprint_sha256
        if fp in inventory:
            inventory[fp].seen_at.append(loc)
        else:
            inventory[fp] = finding
    flag_key_reuse(inventory)
    return inventory


# --------------------------------------------------------------------------- #
#  FUENTE 7 (extensión): cloud key stores y onboarding de dispositivos
#  Stubs documentados. Necesitan SDK/credenciales del entorno y NO se incluyen
#  activos porque no pueden probarse sin esas credenciales. Son los ganchos que
#  cierran la última brecha frente a la "Onboard Discovery" de Venafi.
# --------------------------------------------------------------------------- #
def from_cloud(provider: str, **creds) -> dict[str, CertFinding]:
    """Descubre certs gestionados en almacenes cloud. Punto de extensión.

    Implementación sugerida por proveedor (todas devuelven DER -> parse_certificate
    con source='cloud:<provider>'):
      • aws    : boto3 acm.list_certificates() + get_certificate() (la cadena PEM)
      • azure  : azure-keyvault-certificates CertificateClient.list_properties_of_certificates()
      • gcp    : google-cloud-certificate-manager list_certificates()
    """
    raise NotImplementedError(
        f"from_cloud('{provider}') es un gancho: instala el SDK del proveedor y "
        f"mapea cada cert a parse_certificate(der, loc, source='cloud:{provider}').")


def from_device(kind: str, host: str, **creds) -> dict[str, CertFinding]:
    """Onboarding agentless de certs en la config de un dispositivo (no solo lo que
    sirve en el puerto). Equivale a la Onboard Discovery de Venafi.

    Sugerencias por dispositivo:
      • f5        : iControl REST  GET /mgmt/tm/sys/file/ssl-cert
      • netscaler : Nitro API     GET /nitro/v1/config/sslcertkey
      • iis/capi  : PowerShell remoto -> Get-ChildItem Cert:\\LocalMachine\\My
    """
    raise NotImplementedError(
        f"from_device('{kind}', '{host}') es un gancho: usa la API del dispositivo "
        f"(iControl/Nitro/PowerShell) y mapea a parse_certificate(..., source='device:{kind}').")


# --------------------------------------------------------------------------- #
#  Inventario vivo persistente  (estilo "inventario siempre vigente" de Venafi)
#  Auto-guarda el inventario fusionado y lo reutiliza como baseline implícito,
#  para que la detección de cambios "simplemente funcione" sin elegir archivos.
# --------------------------------------------------------------------------- #
def inventory_dir() -> str:
    d = os.path.join(os.path.expanduser("~"), ".bbcerts")
    os.makedirs(d, exist_ok=True)
    return d


def default_inventory_path() -> str:
    return os.path.join(inventory_dir(), "inventory.json")


def load_inventory(path: str | None = None) -> dict[str, CertFinding]:
    """Carga un inventario JSON previo como dict[fingerprint] -> CertFinding."""
    path = path or default_inventory_path()
    out: dict[str, CertFinding] = {}
    try:
        records = json.load(open(path, encoding="utf-8"))
    except Exception:
        return out
    for r in records:
        try:
            f = CertFinding.from_dict(r)
            out[f.fingerprint_sha256] = f
        except Exception:
            continue
    return out


def merge_inventories(base: dict[str, CertFinding],
                      fresh: dict[str, CertFinding]) -> dict[str, CertFinding]:
    """Fusiona `fresh` sobre `base`: une seen_at/hostnames, conserva owner/note y
    first_seen del histórico, y refresca higiene/expiración con lo recién visto."""
    merged: dict[str, CertFinding] = {fp: f for fp, f in base.items()}
    for fp, nf in fresh.items():
        if fp in merged:
            old = merged[fp]
            for loc in nf.seen_at:
                if loc not in old.seen_at:
                    old.seen_at.append(loc)
            for n in nf.hostnames:
                if n not in old.hostnames:
                    old.hostnames.append(n)
            # refrescar datos volátiles desde la captura nueva
            old.flags = nf.flags or old.flags
            old.days_to_expiry = nf.days_to_expiry
            old.tls_version = nf.tls_version or old.tls_version
            old.cipher = nf.cipher or old.cipher
            old.chain_len = nf.chain_len or old.chain_len
            old.revocation = nf.revocation or old.revocation
            old.delta = nf.delta or old.delta
            old.last_seen = nf.last_seen or old.last_seen
            if not old.first_seen:
                old.first_seen = nf.first_seen
            # owner/note SIEMPRE ganan del histórico (los puso una persona)
        else:
            merged[fp] = nf
    return merged


def save_inventory(inventory: dict[str, CertFinding], path: str | None = None,
                   merge: bool = True) -> str:
    """Guarda el inventario (fusionado con el histórico si merge=True). Devuelve
    la ruta. Esto convierte cada scan en una actualización del inventario vivo."""
    path = path or default_inventory_path()
    final = merge_inventories(load_inventory(path), inventory) if merge else inventory
    records = [asdict(f) for f in final.values()]
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(records, fh, indent=2, ensure_ascii=False)
    return path


# --------------------------------------------------------------------------- #
#  Perfil de Datacenter  (una instancia por DC — estilo "job preconfigurado"
#  de un vSatellite: alguien ya definió QUÉ escanear, el operador solo da ▶)
# --------------------------------------------------------------------------- #
def default_profile_path() -> str:
    """Ruta del perfil de esta instancia: primero junto al script (para que
    vaya empacado con el despliegue), si no ~/.bbcerts/dc_profile.json."""
    here = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dc_profile.json")
    if os.path.exists(here):
        return here
    return os.path.join(inventory_dir(), "dc_profile.json")


def load_dc_profile(path: str | None = None) -> dict | None:
    """Carga el perfil de Datacenter de esta instancia (targets/puertos/horario).
    Orden de búsqueda si `path` es None: $BBCERTS_DC_PROFILE -> dc_profile.json
    junto al script -> ~/.bbcerts/dc_profile.json. Devuelve None si no hay perfil
    (la app sigue funcionando en modo manual, como antes)."""
    path = path or os.environ.get("BBCERTS_DC_PROFILE") or default_profile_path()
    if not path or not os.path.exists(path):
        return None
    try:
        with open(path, encoding="utf-8") as fh:
            prof = json.load(fh)
    except Exception as e:
        print(f"[profile] No se pudo leer {path}: {e!r}")
        return None
    # Defaults sensatos para cualquier clave que falte en el JSON del operador.
    prof.setdefault("dc_name", "Datacenter")
    prof.setdefault("targets", "")
    prof.setdefault("ports", "443")
    prof.setdefault("starttls", "auto")
    prof.setdefault("exclude", "")
    prof.setdefault("concurrency", 300)
    prof.setdefault("timeout", 3.0)
    prof.setdefault("check_trust", False)
    prof.setdefault("resolve_ptr", True)
    prof.setdefault("check_revocation", False)
    prof.setdefault("sni", "")
    prof.setdefault("files", "")
    prof.setdefault("schedule_minutes", 1440)   # 1440 = re-escanear cada 24h, como un vSatellite
    prof.setdefault("autostart", False)         # true = arranca el scan solo al abrir la app
    # Pre-filtro TCP antes del handshake TLS: recomendado por defecto porque
    # los perfiles de DC suelen cubrir rangos /16+ donde la mayoría de las
    # IPs no tienen nada escuchando (ver prefilter_open_ports()).
    prof.setdefault("prefilter", True)
    prof.setdefault("prefilter_concurrency", 4000)
    prof.setdefault("prefilter_timeout", 1.5)
    prof["_path"] = path
    return prof


# --------------------------------------------------------------------------- #
#  Detección de cambios (delta) contra un inventario previo
# --------------------------------------------------------------------------- #
def apply_delta(current: dict[str, CertFinding], baseline) -> dict:
    """Compara el inventario actual contra un baseline previo.
    `baseline` puede ser una ruta a JSON, o un dict[fingerprint]->CertFinding
    (p.ej. el inventario vivo en memoria).
    Anota .delta en cada finding y devuelve un resumen NUEVO/RENOVADO/ELIMINADO.
    Equivale al 'only changed data' de Venafi: el inventario siempre vigente."""
    if isinstance(baseline, dict):
        prev = [asdict(f) if isinstance(f, CertFinding) else f
                for f in baseline.values()]
    else:
        try:
            prev = json.load(open(baseline))
        except Exception:
            prev = []
    prev_fp = {r["fingerprint_sha256"]: r for r in prev}
    # índice por identidad lógica (CN+issuer) para detectar renovaciones
    prev_ident: dict[tuple, str] = {}
    for r in prev:
        prev_ident[(r.get("subject_cn"), r.get("issuer_cn"))] = r["fingerprint_sha256"]

    new, renewed = [], []
    for fp, fnd in current.items():
        if fp in prev_fp:
            fnd.delta = "UNCHANGED"
        else:
            ident = (fnd.subject_cn, fnd.issuer_cn)
            if ident in prev_ident and prev_ident[ident] not in current:
                fnd.delta = "RENEWED"; renewed.append(fp)
            else:
                fnd.delta = "NEW"; new.append(fp)
    removed = [fp for fp in prev_fp if fp not in current]
    return {
        "new": new, "renewed": renewed, "removed": removed,
        "removed_records": [prev_fp[fp] for fp in removed],
        "total_current": len(current), "total_baseline": len(prev),
    }


# --------------------------------------------------------------------------- #
#  Salida
# --------------------------------------------------------------------------- #
def dump(inventory: dict[str, CertFinding], path: str | None):
    records = [asdict(f) for f in inventory.values()]
    text = json.dumps(records, indent=2, ensure_ascii=False)
    if path:
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(text)
    return records


def dump_csv(inventory: dict[str, CertFinding], path: str):
    cols = ["subject_cn", "issuer_cn", "days_to_expiry", "validity_days",
            "key_type", "key_size", "sig_algorithm", "tls_version", "source",
            "revocation", "owner", "delta", "severity", "flags", "seen_at",
            "hostnames", "fingerprint_sha256"]
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = _csv.writer(fh)
        w.writerow(cols)
        for f in inventory.values():
            w.writerow([
                f.subject_cn, f.issuer_cn, f.days_to_expiry, f.validity_days,
                f.key_type, f.key_size, f.sig_algorithm, f.tls_version, f.source,
                f.revocation, f.owner, f.delta, f.max_severity(), "|".join(f.flags),
                "; ".join(f.seen_at[:8]), "; ".join(f.hostnames[:8]),
                f.fingerprint_sha256,
            ])


def dump_html(inventory: dict[str, CertFinding], path: str,
              delta_summary: dict | None = None):
    """Reporte ejecutivo HTML autocontenido (un archivo, sin dependencias) para
    entregar a dirección/auditoría. Es el equivalente al dashboard de Venafi en
    forma de informe portátil."""
    import html as _html
    from collections import Counter
    records = list(inventory.values())
    flagged = [r for r in records if r.flags]
    c = Counter(SEVERITY.get(fl, "low") for r in flagged for fl in r.flags)
    expiring = sum(1 for r in records if 0 <= r.days_to_expiry <= 30)
    expired = sum(1 for r in records if r.days_to_expiry < 0)

    def esc(x): return _html.escape(str(x))
    sev_color = {"critical": "#c8102e", "high": "#c48700", "medium": "#888",
                 "low": "#5a6475", "info": "#5a6475"}
    rows = []
    for r in sorted(records, key=lambda x: (_sev_rank(x.max_severity()), x.days_to_expiry)):
        cn = r.subject_cn or (r.sans[0] if r.sans else "(sin CN)")
        sev = r.max_severity()
        col = sev_color.get(sev, "#5a6475")
        pills = "".join(
            f'<span style="background:#f1efe8;border-radius:8px;padding:1px 6px;'
            f'margin:1px;font-size:11px;color:{sev_color.get(SEVERITY.get(fl,"low"),"#555")}">'
            f'{esc(fl)}</span> ' for fl in r.flags)
        rows.append(
            f"<tr><td style='color:{col};font-weight:600'>{esc(sev.upper())}</td>"
            f"<td>{esc(cn)}</td><td style='text-align:right'>{r.days_to_expiry}</td>"
            f"<td>{esc(r.key_type)}{esc(r.key_size)}</td>"
            f"<td>{esc(r.revocation or '—')}</td>"
            f"<td>{esc(r.owner or '—')}</td>"
            f"<td>{pills or '—'}</td>"
            f"<td style='font-size:11px;color:#666'>{esc('; '.join(r.seen_at[:3]))}</td></tr>")

    delta_html = ""
    if delta_summary:
        delta_html = (f"<p><b>Cambios vs baseline:</b> "
                      f"{len(delta_summary['new'])} nuevo(s) · "
                      f"{len(delta_summary['renewed'])} renovado(s) · "
                      f"{len(delta_summary['removed'])} eliminado(s)</p>")

    def kpi(label, val, color="#0d1b2a"):
        return (f"<div style='flex:1;background:#fff;border:1px solid #dde2ec;"
                f"border-radius:10px;padding:14px 16px'>"
                f"<div style='font-size:28px;font-weight:700;color:{color}'>{val}</div>"
                f"<div style='font-size:12px;color:#5a6475'>{label}</div></div>")

    doc = f"""<!doctype html><html lang="es"><head><meta charset="utf-8">
<title>Inventario de certificados — SecDevOps · Banco Base</title></head>
<body style="font-family:Segoe UI,system-ui,sans-serif;background:#f5f6f8;margin:0;padding:24px;color:#0d1b2a">
<div style="max-width:1100px;margin:0 auto">
<div style="border-top:4px solid #F5A800;background:#fff;border:1px solid #dde2ec;border-radius:10px;padding:18px 20px;margin-bottom:16px">
<h1 style="margin:0;font-size:18px">Inventario de certificados</h1>
<div style="color:#5a6475;font-size:13px">SecDevOps · Banco Base — generado {esc(datetime.now().strftime('%Y-%m-%d %H:%M'))}</div>
</div>
<div style="display:flex;gap:12px;margin-bottom:16px;flex-wrap:wrap">
{kpi("Certificados únicos", len(records))}
{kpi("Con hallazgos", len(flagged), "#c48700")}
{kpi("Críticos", c.get('critical',0), "#c8102e")}
{kpi("Expiran ≤30d", expiring, "#c48700")}
{kpi("Expirados", expired, "#c8102e")}
</div>
{delta_html}
<table style="width:100%;border-collapse:collapse;background:#fff;border:1px solid #dde2ec;border-radius:10px;overflow:hidden;font-size:13px">
<thead><tr style="background:#eef1f7;text-align:left">
<th style="padding:8px">Severidad</th><th style="padding:8px">Nombre (CN/SAN)</th>
<th style="padding:8px">Vence (d)</th><th style="padding:8px">Llave</th>
<th style="padding:8px">Revocación</th><th style="padding:8px">Responsable</th>
<th style="padding:8px">Hallazgos</th><th style="padding:8px">Visto en</th></tr></thead>
<tbody>{''.join(rows)}</tbody>
</table>
<p style="color:#9aa3b2;font-size:11px;margin-top:14px">
Generado por el motor interno de descubrimiento de certificados. Reemplazo del
descubrimiento de Venafi · {esc(len(records))} activos.</p>
</div></body></html>"""
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(doc)
    return path


def _sev_rank(sev: str) -> int:
    return {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}.get(sev, 9)


def summarize(inventory: dict[str, CertFinding], delta_summary: dict | None = None):
    records = list(inventory.values())
    print(f"\n=== Inventario: {len(records)} certificados únicos ===")
    flagged = [r for r in records if r.flags]
    for r in sorted(records, key=lambda x: x.days_to_expiry):
        cn = r.subject_cn or (r.sans[0] if r.sans else "(sin CN)")
        locs = ", ".join(r.seen_at[:2])
        sev = r.max_severity()
        d = f" {r.delta}" if r.delta and r.delta != "UNCHANGED" else ""
        flags = f"  [{sev.upper()}] {', '.join(r.flags)}" if r.flags else ""
        print(f"  {cn:34.34}  exp {r.days_to_expiry:>5}d  "
              f"{r.key_type}{r.key_size}  @ {locs}{d}{flags}")
    if flagged:
        from collections import Counter
        c = Counter(SEVERITY.get(fl, "low") for r in flagged for fl in r.flags)
        print(f"\n  {len(flagged)} cert(s) con hallazgos: "
              f"{c.get('critical',0)} crít · {c.get('high',0)} alto · "
              f"{c.get('medium',0)} medio · {c.get('low',0)} bajo")
    if delta_summary:
        print(f"\n  Cambios vs baseline: "
              f"{len(delta_summary['new'])} nuevo(s) · "
              f"{len(delta_summary['renewed'])} renovado(s) · "
              f"{len(delta_summary['removed'])} eliminado(s)")


# --------------------------------------------------------------------------- #
#  Demo autocontenida (prueba real sin salida de red)
# --------------------------------------------------------------------------- #
def _demo():
    """Levanta un TLS server local con cert autofirmado y se escanea a sí mismo."""
    import threading
    from cryptography.hazmat.primitives.asymmetric import rsa
    from datetime import timedelta
    import tempfile

    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    subject = issuer = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "demo.bancobase.local")])
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject).issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(datetime.now(timezone.utc) - timedelta(days=1))
        .not_valid_after(datetime.now(timezone.utc) + timedelta(days=20))   # -> EXPIRING_SOON
        .add_extension(x509.SubjectAlternativeName([x509.DNSName("*.bancobase.local")]), False)  # -> WILDCARD
        .sign(key, hashes.SHA256())
    )
    tmp = tempfile.mkdtemp()
    cpath, kpath = os.path.join(tmp, "c.pem"), os.path.join(tmp, "k.pem")
    open(cpath, "wb").write(cert.public_bytes(serialization.Encoding.PEM))
    open(kpath, "wb").write(key.private_bytes(serialization.Encoding.PEM,
                            serialization.PrivateFormat.TraditionalOpenSSL,
                            serialization.NoEncryption()))

    srv_ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    srv_ctx.load_cert_chain(cpath, kpath)
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("127.0.0.1", 0))
    port = srv.getsockname()[1]
    srv.listen(5)

    def serve():
        while True:
            try:
                c, _ = srv.accept()
                try: srv_ctx.wrap_socket(c, server_side=True).close()
                except (ssl.SSLError, OSError): c.close()
            except OSError:
                break

    threading.Thread(target=serve, daemon=True).start()
    print(f"[demo] TLS server en 127.0.0.1:{port}  (autofirmado + wildcard + exp 20d)")
    inv = asyncio.run(scan(["127.0.0.1"], [port], concurrency=10))
    srv.close()
    summarize(inv)
    return inv


# --------------------------------------------------------------------------- #
def main():
    ap = argparse.ArgumentParser(description="Descubrimiento interno de certificados (reemplazo Venafi)")
    ap.add_argument("targets", nargs="?", help="CIDR / rango / IP / hostname (coma-separado)")
    ap.add_argument("--ports", default="443", help="Puertos coma-separados (def 443)")
    ap.add_argument("--concurrency", type=int, default=200)
    ap.add_argument("--timeout", type=float, default=3.0)
    ap.add_argument("--starttls", default="off",
                    help="off | auto | smtp | imap | pop3 | ftp | ldap | postgres")
    ap.add_argument("--check-trust", action="store_true",
                    help="Validar cadena contra el almacén de confianza (2º handshake)")
    ap.add_argument("--resolve-ptr", action="store_true", help="Resolver PTR inverso de cada IP")
    ap.add_argument("--exclude", default="", help="IP/CIDR/host/puerto a excluir (coma-sep)")
    ap.add_argument("--ct", help="Descubrir vía Certificate Transparency (crt.sh) para este dominio")
    ap.add_argument("--resolve-scan", action="store_true",
                    help="Tras --ct, resolver y escanear activamente los hosts hallados")
    ap.add_argument("--scan-files", help="Descubrir certs en un directorio (en reposo)")
    ap.add_argument("--scan-windows", action="store_true",
                    help="Leer el almacén de certificados de Windows (LocalMachine)")
    ap.add_argument("--check-revocation", action="store_true",
                    help="Comprobar revocación vía OCSP (marca REVOKED)")
    ap.add_argument("--sni", default="",
                    help="Hostnames extra a probar como SNI por IP (vhosts), coma-sep")
    ap.add_argument("--prefilter", action="store_true",
                    help="Barrido TCP rápido antes del handshake TLS; recomendado "
                         "en rangos grandes (/16 o más) para no gastar el timeout "
                         "completo en cada IP muerta")
    ap.add_argument("--prefilter-concurrency", type=int, default=4000)
    ap.add_argument("--prefilter-timeout", type=float, default=1.5)
    ap.add_argument("--baseline", help="Inventario JSON previo para detección de cambios. "
                    "Usa 'live' para el inventario vivo (~/.bbcerts/inventory.json)")
    ap.add_argument("--save", action="store_true",
                    help="Fusionar y guardar en el inventario vivo (~/.bbcerts/inventory.json)")
    ap.add_argument("--out", help="Ruta de salida JSON")
    ap.add_argument("--csv", help="Ruta de salida CSV")
    ap.add_argument("--html", help="Ruta de salida de reporte HTML ejecutivo")
    ap.add_argument("--from-masscan", help="Ingerir reachability desde JSON de masscan")
    ap.add_argument("--via-zgrab2", action="store_true", help="Capturar con zgrab2 (escala)")
    ap.add_argument("--demo", action="store_true", help="Prueba autocontenida local")
    ap.add_argument("--profile", nargs="?", const="__default__", default=None,
                    help="Escanea usando el perfil de Datacenter de esta instancia "
                         "(dc_profile.json junto al script, o la ruta que indiques). "
                         "Ignora targets/ports manuales. Útil para probar el perfil "
                         "desde terminal antes de abrir la GUI.")
    args = ap.parse_args()

    if args.demo:
        _demo(); return

    if args.profile:
        prof_path = None if args.profile == "__default__" else args.profile
        prof = load_dc_profile(prof_path)
        if not prof:
            ap.error(f"No se encontró perfil de Datacenter en "
                     f"{prof_path or default_profile_path()}")
        print(f"[profile] {prof['dc_name']}  ·  perfil: {prof['_path']}")
        p_ports = [int(p) for p in str(prof["ports"]).split(",") if str(p).strip().isdigit()] or [443]
        p_sni = [s.strip() for s in str(prof.get("sni", "")).split(",") if s.strip()]
        inv = asyncio.run(scan(
            expand_targets(prof["targets"]), p_ports,
            concurrency=int(prof["concurrency"]), timeout=float(prof["timeout"]),
            starttls=prof["starttls"], check_trust=bool(prof["check_trust"]),
            resolve_ptr=bool(prof["resolve_ptr"]), exclude=prof.get("exclude", ""),
            check_revocation=bool(prof["check_revocation"]), sni_names=p_sni,
            prefilter=bool(prof.get("prefilter", True)),
            prefilter_concurrency=int(prof.get("prefilter_concurrency", 4000)),
            prefilter_timeout=float(prof.get("prefilter_timeout", 1.5))))
        if prof.get("files"):
            inv = merge_inventories(inv, scan_files(prof["files"]))
        baseline = load_inventory()
        delta = apply_delta(inv, baseline) if baseline else None
        summarize(inv, delta)
        save_inventory(inv, merge=True)
        return

    ports = [int(p) for p in args.ports.split(",")]
    sni_names = [s.strip() for s in args.sni.split(",") if s.strip()]

    if args.scan_files:
        inv = scan_files(args.scan_files)
    elif args.scan_windows:
        inv = scan_windows_store()
    elif args.ct:
        names = ct_discover(args.ct)
        print(f"[ct] crt.sh devolvió {len(names)} nombre(s) para {args.ct}")
        if args.resolve_scan:
            inv = asyncio.run(scan(names, ports, args.concurrency, args.timeout,
                                   args.starttls, args.check_trust, args.resolve_ptr,
                                   args.exclude, check_revocation=args.check_revocation,
                                   sni_names=sni_names, prefilter=args.prefilter,
                                   prefilter_concurrency=args.prefilter_concurrency,
                                   prefilter_timeout=args.prefilter_timeout))
        else:
            for n in names:
                print(f"  {n}")
            return
    elif args.from_masscan:
        tgts = from_masscan(args.from_masscan)
        inv = via_zgrab2(tgts) if args.via_zgrab2 else asyncio.run(
            scan([ip for ip, _ in tgts], sorted({p for _, p in tgts}),
                 args.concurrency, args.timeout, args.starttls,
                 args.check_trust, args.resolve_ptr, args.exclude,
                 check_revocation=args.check_revocation, sni_names=sni_names))
    elif args.targets:
        inv = asyncio.run(scan(expand_targets(args.targets), ports,
                               args.concurrency, args.timeout, args.starttls,
                               args.check_trust, args.resolve_ptr, args.exclude,
                               check_revocation=args.check_revocation,
                               sni_names=sni_names, prefilter=args.prefilter,
                               prefilter_concurrency=args.prefilter_concurrency,
                               prefilter_timeout=args.prefilter_timeout))
    else:
        ap.error("Da un target, --ct, --scan-files, --scan-windows, --from-masscan o --demo")

    baseline = None
    if args.baseline == "live":
        baseline = load_inventory()
    elif args.baseline:
        baseline = args.baseline
    delta = apply_delta(inv, baseline) if baseline is not None else None
    summarize(inv, delta)
    if args.save:
        p = save_inventory(inv);  print(f"\nInventario vivo actualizado: {p}")
    if args.out:
        dump(inv, args.out);  print(f"Guardado JSON en {args.out}")
    if args.csv:
        dump_csv(inv, args.csv);  print(f"Guardado CSV  en {args.csv}")
    if args.html:
        dump_html(inv, args.html, delta);  print(f"Guardado HTML en {args.html}")


if __name__ == "__main__":
    main()
