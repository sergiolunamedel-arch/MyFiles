"""
db.py - Capa de persistencia en SQLite para tenable_sc_scanner.

Guarda:
  - Configuración de Security Center y de los 3 Nessus Manager (URLs y API
    keys). ADVERTENCIA: las llaves se guardan en TEXTO PLANO en el archivo
    .db local (decisión aceptada explícitamente para agilizar pruebas). El
    archivo vive junto a los scripts; protégelo con permisos de archivo
    (chmod 600 en Linux/Mac) y NUNCA lo subas a un repositorio.
  - Caché local de "qué host apareció en qué scan, en cuál Nessus Manager",
    para que la búsqueda sea instantánea en vez de tener que golpear las 3
    APIs cada vez. Se refresca manualmente (botón "Sincronizar" en la GUI,
    o el comando 'sincronizar' del CLI).
  - Historial de scans lanzados desde esta herramienta (referencia local,
    no reemplaza el historial real que vive en Security Center).
"""

import sqlite3
from pathlib import Path
from datetime import datetime, timezone

DB_PATH = Path(__file__).parent / "tenable_sc_scanner.db"

DEFAULT_NESSUS_MANAGERS = [
    ("Queretaro", "https://10.48.36.37:8834"),
    ("Monterrey", "https://10.48.4.37:8834"),
    ("Torre Base", "https://10.48.196.37:8834"),
]
DEFAULT_SC_URL = "https://qro-ale-ptsc001"


def _conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def _asegurar_columnas(conn, tabla, columnas_def):
    """Agrega columnas faltantes a una tabla ya existente (ALTER TABLE ...
    ADD COLUMN), sin tocar las que ya están. Necesario porque
    'CREATE TABLE IF NOT EXISTS' no modifica una tabla que un usuario ya
    tenía creada con un esquema viejo."""
    existentes = {row[1] for row in conn.execute(f"PRAGMA table_info({tabla})")}
    for columna_def in columnas_def:
        nombre_columna = columna_def.split()[0]
        if nombre_columna not in existentes:
            conn.execute(f"ALTER TABLE {tabla} ADD COLUMN {columna_def}")


def init_db():
    conn = _conn()
    try:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS security_center (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                url TEXT NOT NULL,
                access_key TEXT NOT NULL DEFAULT '',
                secret_key TEXT NOT NULL DEFAULT '',
                verify_ssl INTEGER NOT NULL DEFAULT 0
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS nessus_managers (
                name TEXT PRIMARY KEY,
                url TEXT NOT NULL,
                access_key TEXT NOT NULL DEFAULT '',
                secret_key TEXT NOT NULL DEFAULT '',
                verify_ssl INTEGER NOT NULL DEFAULT 0
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS scan_cache (
                nessus_manager TEXT NOT NULL,
                scan_id INTEGER NOT NULL,
                scan_name TEXT,
                host TEXT NOT NULL,
                last_modification TEXT,
                synced_at TEXT NOT NULL,
                PRIMARY KEY (nessus_manager, scan_id, host)
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS cache_sync_log (
                nessus_manager TEXT PRIMARY KEY,
                synced_at TEXT NOT NULL,
                scans_revisados INTEGER,
                hosts_indexados INTEGER,
                error TEXT
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS scan_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT,
                ips TEXT,
                policy_id TEXT,
                repository_id TEXT,
                zone_id TEXT,
                sc_scan_id TEXT,
                sc_scan_result_id TEXT,
                estado TEXT,
                lanzado_at TEXT,
                tipo TEXT NOT NULL DEFAULT 'ip',
                scanner_id TEXT,
                agent_group_id TEXT,
                agent_group_name TEXT
            )
            """
        )
        # Migración para bases .db ya existentes creadas antes de que
        # scan_log tuviera estas columnas -- sin esto, "re-escanear" no
        # tendría dónde guardar lo que necesita para relanzar un scan de
        # Agent (scanner_id / agent_group_id / agent_group_name), y las
        # instalaciones viejas romperían en el primer INSERT.
        _asegurar_columnas(
            conn,
            "scan_log",
            [
                "tipo TEXT NOT NULL DEFAULT 'ip'",
                "scanner_id TEXT",
                "agent_group_id TEXT",
                "agent_group_name TEXT",
            ],
        )

        # Seed inicial de SC y de los 3 Nessus Manager (solo URLs; llaves vacías).
        if conn.execute("SELECT COUNT(*) FROM security_center").fetchone()[0] == 0:
            conn.execute(
                "INSERT INTO security_center (id, url, access_key, secret_key, verify_ssl) VALUES (1, ?, '', '', 0)",
                (DEFAULT_SC_URL,),
            )
        for name, url in DEFAULT_NESSUS_MANAGERS:
            conn.execute(
                "INSERT OR IGNORE INTO nessus_managers (name, url, access_key, secret_key, verify_ssl) "
                "VALUES (?, ?, '', '', 0)",
                (name, url),
            )
        conn.commit()
    finally:
        conn.close()


# --- Configuración --------------------------------------------------------
def get_sc_config():
    conn = _conn()
    try:
        row = conn.execute("SELECT * FROM security_center WHERE id = 1").fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def save_sc_config(url, access_key, secret_key, verify_ssl):
    conn = _conn()
    try:
        conn.execute(
            """
            INSERT INTO security_center (id, url, access_key, secret_key, verify_ssl)
            VALUES (1, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                url=excluded.url, access_key=excluded.access_key,
                secret_key=excluded.secret_key, verify_ssl=excluded.verify_ssl
            """,
            (url, access_key, secret_key, int(bool(verify_ssl))),
        )
        conn.commit()
    finally:
        conn.close()


def list_nessus_managers():
    conn = _conn()
    try:
        rows = conn.execute("SELECT * FROM nessus_managers ORDER BY name").fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def save_nessus_manager(name, url, access_key, secret_key, verify_ssl):
    conn = _conn()
    try:
        conn.execute(
            """
            INSERT INTO nessus_managers (name, url, access_key, secret_key, verify_ssl)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(name) DO UPDATE SET
                url=excluded.url, access_key=excluded.access_key,
                secret_key=excluded.secret_key, verify_ssl=excluded.verify_ssl
            """,
            (name, url, access_key, secret_key, int(bool(verify_ssl))),
        )
        conn.commit()
    finally:
        conn.close()


# --- Caché de búsqueda -----------------------------------------------------
def reemplazar_cache_manager(nessus_manager, filas, scans_revisados, error=None):
    """
    filas: lista de dicts {scan_id, scan_name, host, last_modification}.
    Reemplaza atómicamente todo lo que había cacheado para ese Nessus Manager.
    """
    conn = _conn()
    ahora = datetime.now(timezone.utc).isoformat()
    try:
        conn.execute("DELETE FROM scan_cache WHERE nessus_manager = ?", (nessus_manager,))
        conn.executemany(
            """
            INSERT OR REPLACE INTO scan_cache
                (nessus_manager, scan_id, scan_name, host, last_modification, synced_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            [
                (nessus_manager, f["scan_id"], f["scan_name"], f["host"], f["last_modification"], ahora)
                for f in filas
            ],
        )
        conn.execute(
            """
            INSERT INTO cache_sync_log (nessus_manager, synced_at, scans_revisados, hosts_indexados, error)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(nessus_manager) DO UPDATE SET
                synced_at=excluded.synced_at, scans_revisados=excluded.scans_revisados,
                hosts_indexados=excluded.hosts_indexados, error=excluded.error
            """,
            (nessus_manager, ahora, scans_revisados, len(filas), error),
        )
        conn.commit()
    finally:
        conn.close()


def estado_cache():
    conn = _conn()
    try:
        rows = conn.execute("SELECT * FROM cache_sync_log ORDER BY nessus_manager").fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def buscar_en_cache(objetivo):
    conn = _conn()
    try:
        rows = conn.execute(
            """
            SELECT nessus_manager, scan_id, scan_name, host, last_modification
            FROM scan_cache
            WHERE host LIKE ?
            ORDER BY nessus_manager, scan_name
            """,
            (f"%{objetivo}%",),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# --- Historial de scans lanzados -------------------------------------------
def registrar_scan_lanzado(
    nombre,
    ips,
    policy_id,
    repository_id,
    zone_id,
    sc_scan_id,
    sc_scan_result_id,
    estado="Lanzado",
    tipo="ip",
    scanner_id=None,
    agent_group_id=None,
    agent_group_name=None,
):
    """
    Guarda un scan lanzado en el historial local. A partir de 'tipo',
    'scanner_id', 'agent_group_id' y 'agent_group_name' (todos opcionales,
    con default para no romper llamadas viejas) queda guardada la
    configuración completa necesaria para volver a lanzar este mismo scan
    después ("re-escanear" desde Historial), tanto para scans por IP como
    para scans de Agent.
    """
    conn = _conn()
    try:
        conn.execute(
            """
            INSERT INTO scan_log
                (nombre, ips, policy_id, repository_id, zone_id, sc_scan_id, sc_scan_result_id, estado,
                 lanzado_at, tipo, scanner_id, agent_group_id, agent_group_name)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                nombre,
                ",".join(ips) if isinstance(ips, list) else ips,
                str(policy_id) if policy_id else None,
                str(repository_id),
                str(zone_id) if zone_id else None,
                str(sc_scan_id),
                str(sc_scan_result_id) if sc_scan_result_id else None,
                estado,
                datetime.now(timezone.utc).isoformat(),
                tipo,
                str(scanner_id) if scanner_id else None,
                str(agent_group_id) if agent_group_id else None,
                agent_group_name,
            ),
        )
        conn.commit()
    finally:
        conn.close()


def actualizar_estado_scan(sc_scan_result_id, estado):
    conn = _conn()
    try:
        conn.execute(
            "UPDATE scan_log SET estado = ? WHERE sc_scan_result_id = ?",
            (estado, str(sc_scan_result_id)),
        )
        conn.commit()
    finally:
        conn.close()


def listar_historial(limit=200):
    conn = _conn()
    try:
        rows = conn.execute("SELECT * FROM scan_log ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def obtener_scan_log(scan_log_id):
    """Devuelve una fila del historial (con toda la config guardada del
    scan) para poder re-lanzarla, o None si no existe."""
    conn = _conn()
    try:
        row = conn.execute("SELECT * FROM scan_log WHERE id = ?", (scan_log_id,)).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def eliminar_scan_log(scan_log_id):
    """Quita una entrada del historial local (no afecta el scan real en
    Security Center, solo esta referencia local)."""
    conn = _conn()
    try:
        conn.execute("DELETE FROM scan_log WHERE id = ?", (scan_log_id,))
        conn.commit()
    finally:
        conn.close()
