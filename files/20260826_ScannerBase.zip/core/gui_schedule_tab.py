from __future__ import annotations
import json
import os
import queue
import sys
import threading
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import tkinter as tk
from tkinter import ttk

import scheduler_os

_STAGE_KEYS   = ("sca", "code", "secrets", "dast", "api")
_STAGE_LABELS = {"sca": "SCA", "code": "SAST", "secrets": "Secretos", "dast": "DAST", "api": "API"}
_WEEKDAYS     = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]

_SCHEDULE_POLL_MS = 30_000

_OS_SCHED_INTERVAL_MIN = 5

def _owner_file() -> Path:
    return Path(DATA_DIR) / ".scan_engine_owner.pid"

def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    if IS_WIN:
        try:
            out = os.popen(f'tasklist /FI "PID eq {pid}" /NH').read()
            return str(pid) in out
        except Exception:
            return False
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except Exception:
        return False

def _claim_owner() -> bool:
    p = _owner_file()
    try:
        existing = int(p.read_text(encoding="utf-8").strip())
    except Exception:
        existing = None
    if existing and existing != os.getpid() and _pid_alive(existing):
        return False
    try:
        p.write_text(str(os.getpid()), encoding="utf-8")
        return True
    except Exception:
        return False

def _release_owner() -> None:
    p = _owner_file()
    try:
        if int(p.read_text(encoding="utf-8").strip()) == os.getpid():
            p.unlink(missing_ok=True)
    except Exception:
        pass

def _now() -> datetime:
    return datetime.now()

def _parse_hhmm(s: str) -> tuple[int, int]:
    try:
        hh, mm = (s or "00:00").split(":")
        return max(0, min(23, int(hh))), max(0, min(59, int(mm)))
    except Exception:
        return 0, 0

def _fmt_dt(iso: Optional[str]) -> str:
    if not iso:
        return "—"
    try:
        return datetime.fromisoformat(iso).strftime("%Y-%m-%d %H:%M")
    except Exception:
        return iso

def _new_schedule_id() -> str:
    return f"sched_{uuid.uuid4().hex[:10]}"

def _next_run_from(sched: dict, base: datetime) -> datetime:
    """Compute the next fire time strictly after `base`."""
    rec = sched.get("recurrence", "daily")
    if rec == "interval":
        minutes = max(5, int(sched.get("interval_minutes") or 60))
        return base + timedelta(minutes=minutes)
    hh, mm = _parse_hhmm(sched.get("time_of_day") or "00:00")
    if rec == "weekly":
        target_wd = int(sched.get("weekday", 0)) % 7
        candidate = base.replace(hour=hh, minute=mm, second=0, microsecond=0)
        days_ahead = (target_wd - candidate.weekday()) % 7
        candidate += timedelta(days=days_ahead)
        if candidate <= base:
            candidate += timedelta(days=7)
        return candidate

    candidate = base.replace(hour=hh, minute=mm, second=0, microsecond=0)
    if candidate <= base:
        candidate += timedelta(days=1)
    return candidate

def _describe_recurrence(sched: dict) -> str:
    rec = sched.get("recurrence", "daily")
    if rec == "interval":
        mins = int(sched.get("interval_minutes") or 60)
        if mins % 1440 == 0:
            return f"cada {mins // 1440} día(s)"
        if mins % 60 == 0:
            return f"cada {mins // 60} hora(s)"
        return f"cada {mins} min"
    hh, mm = _parse_hhmm(sched.get("time_of_day") or "00:00")
    t = f"{hh:02d}:{mm:02d}"
    if rec == "weekly":
        wd = int(sched.get("weekday", 0)) % 7
        return f"{_WEEKDAYS[wd]} {t}"
    return f"diario {t}"

class ScheduleStore:
    """Thread-safe JSON store for scan schedules — one file per schedule plus an _index.json, mirroring AppInventoryS…"""

    def __init__(self, reports_root: Path):
        self._lock = threading.Lock()
        self.sched_dir = Path(reports_root) / "schedules"
        self.sched_dir.mkdir(parents=True, exist_ok=True)
        self._index_path = self.sched_dir / "_index.json"

    def _read_index(self) -> list[str]:
        try:
            if self._index_path.exists():
                return json.loads(self._index_path.read_text("utf-8"))
        except Exception:
            pass
        ids = sorted(p.stem for p in self.sched_dir.glob("*.json") if p.name != "_index.json")
        self._write_index(ids)
        return ids

    def _write_index(self, ids: list[str]) -> None:
        self._index_path.write_text(json.dumps(ids, indent=2), "utf-8")

    def _sched_path(self, sid: str) -> Path:
        return self.sched_dir / f"{sid}.json"

    def list_schedules(self) -> list[dict]:
        with self._lock:
            out = []
            for sid in self._read_index():
                p = self._sched_path(sid)
                if p.exists():
                    try:
                        out.append(json.loads(p.read_text("utf-8")))
                    except Exception:
                        pass
            return out

    def get_schedule(self, sid: str) -> Optional[dict]:
        with self._lock:
            p = self._sched_path(sid)
            if p.exists():
                try:
                    return json.loads(p.read_text("utf-8"))
                except Exception:
                    pass
        return None

    def save_schedule(self, sched: dict) -> None:
        with self._lock:
            if not sched.get("id"):
                sched["id"] = _new_schedule_id()
            ids = self._read_index()
            if sched["id"] not in ids:
                ids.append(sched["id"])
                self._write_index(ids)
            sched["updated_at"] = _now().isoformat(timespec="seconds")
            if not sched.get("created_at"):
                sched["created_at"] = sched["updated_at"]
            self._sched_path(sched["id"]).write_text(
                json.dumps(sched, indent=2, ensure_ascii=False), "utf-8")

    def delete_schedule(self, sid: str) -> None:
        with self._lock:
            ids = self._read_index()
            if sid in ids:
                ids.remove(sid)
                self._write_index(ids)
            p = self._sched_path(sid)
            if p.exists():
                p.unlink()

    def _stage_prefs_path(self) -> Path:
        return self.sched_dir / "_stage_prefs.json"

    def _read_stage_prefs(self) -> dict:
        p = self._stage_prefs_path()
        if p.exists():
            try:
                return json.loads(p.read_text("utf-8"))
            except Exception:
                pass
        return {}

    def get_stage_prefs(self, app_id: str) -> Optional[list[str]]:
        """None means 'no memory for this app yet' (first-run default applies); an empty list is a valid remembered choic…"""
        if not app_id:
            return None
        with self._lock:
            return self._read_stage_prefs().get(app_id)

    def save_stage_prefs(self, app_id: str, stages: list[str]) -> None:
        if not app_id:
            return
        with self._lock:
            prefs = self._read_stage_prefs()
            prefs[app_id] = list(stages)
            self._stage_prefs_path().write_text(
                json.dumps(prefs, indent=2, ensure_ascii=False), "utf-8")

class _ScheduleEditor(tk.Toplevel):
    """Create/edit a single schedule."""

    def __init__(self, master, store: ScheduleStore, apps: list[dict],
                 sched: Optional[dict] = None):
        super().__init__(master)
        self._store = store
        self.result: Optional[dict] = None
        self._is_new = sched is None
        self._sched = dict(sched) if sched else {
            "id": "", "app_id": "", "app_name": "",
            "stages": [], "recurrence": "daily",
            "time_of_day": "02:00", "weekday": 0, "interval_minutes": 360,
            "enabled": True, "last_run_at": None, "last_run_status": None,
            "auto_open_on_finish": False,
        }

        self.transient(master)
        master.update_idletasks()
        mw, mh = _monitor_wh(master)
        w, h = int(mw * 0.75), int(mh * 0.75)
        px, py = master.winfo_rootx(), master.winfo_rooty()
        pw, ph = master.winfo_width(), master.winfo_height()
        self.geometry(f"{w}x{h}+{px + (pw - w) // 2}+{py + (ph - h) // 2}")
        self.overrideredirect(True)
        self.update_idletasks(); self.lift(); self.focus_force()
        try: self.grab_set()
        except tk.TclError: pass
        _bind_ids: dict = {}
        _close = _bind_popup_close(self, master, _bind_ids)
        _bind_ids.update(_popup_follow_parent(self, master))

        content = _apply_panel_chrome(self)
        content.close = _close
        title = "✏  Editar Horario" if sched else "🕒  Nuevo Horario de Escaneo"
        master._popup_hdr(content, title,
                          subtitle="Elige la aplicación, los stages a correr y cuándo debe dispararse.",
                          on_close=_close)

        pad = tk.Frame(content, bg=T["bg"], padx=6, pady=4)
        pad.pack(fill="both", expand=True)

        row1 = tk.Frame(pad, bg=T["bg"]); row1.pack(fill="x", pady=(0, 2))
        tk.Label(row1, text="Aplicación", font=(_FUI, 12), bg=T["bg"], fg=T["card_fg"],
                 width=16, anchor="w").pack(side="left")
        app_names = [a["name"] for a in apps]
        app_by_name = {a["name"]: a for a in apps}
        cur_app = next((a for a in apps if a.get("id") == self._sched.get("app_id")), None)
        self._app_var = tk.StringVar(value=cur_app["name"] if cur_app else (app_names[0] if app_names else ""))
        ttk.Combobox(row1, textvariable=self._app_var, values=app_names,
                    state="readonly", width=34).pack(side="left", fill="x", expand=True)
        if not app_names:
            tk.Label(pad, text="⚠  No hay aplicaciones registradas — cree una en 📦 Aplicaciones primero.",
                     font=(_FUI, 10), bg=T["bg"], fg=T["err"]).pack(anchor="w", pady=(0, 2))

        stg_hdr = tk.Frame(pad, bg=T["surface3"], padx=3, pady=1); stg_hdr.pack(fill="x", pady=(1, 2))
        tk.Label(stg_hdr, text="Stages", font=(_FUI, 14, "bold"),
                 bg=T["surface3"], fg=T["card_fg"]).pack(side="left")
        stg_shadow = master._shadow_wrap(pad, visible=False)
        stg_shadow.pack(fill="x", pady=(0, 1))
        stg_body = tk.Frame(stg_shadow, bg=T["panel_bg"], highlightthickness=0,
                            highlightbackground=T["border"], padx=4, pady=2)
        stg_body.pack(fill="both", expand=True, padx=(0, 0), pady=(0, 0))

        def _resolve_default_stages(app_id: str) -> set[str]:
            if not self._is_new:
                return set(self._sched.get("stages") or [])
            remembered = self._store.get_stage_prefs(app_id) if app_id else None
            if remembered is not None:
                return set(remembered)
            return set(_NO_APP_DEFAULT_STAGES)

        self._stage_vars: dict[str, tk.BooleanVar] = {}
        _initial_app = app_by_name.get(self._app_var.get())
        sel_stages = _resolve_default_stages(_initial_app.get("id") if _initial_app else "")
        for k in _STAGE_KEYS:
            v = tk.BooleanVar(value=(k in sel_stages))
            self._stage_vars[k] = v
            ToggleSwitch(stg_body, text=_STAGE_LABELS[k], variable=v).pack(side="left", padx=(0, 4))
        tk.Label(pad, text="Puede diferir de los stages configurados en el perfil de la aplicación.",
                 font=(_FUI, 10), bg=T["bg"], fg=T["muted"]).pack(anchor="w", pady=(0, 2))

        if self._is_new:

            def _on_app_change(*_a):
                app = app_by_name.get(self._app_var.get())
                new_sel = _resolve_default_stages(app.get("id") if app else "")
                for k, v in self._stage_vars.items():
                    v.set(k in new_sel)
            self._app_var.trace_add("write", _on_app_change)

        rec_hdr = tk.Frame(pad, bg=T["surface3"], padx=3, pady=1); rec_hdr.pack(fill="x", pady=(1, 2))
        tk.Label(rec_hdr, text="Recurrencia", font=(_FUI, 14, "bold"),
                 bg=T["surface3"], fg=T["card_fg"]).pack(side="left")
        rec_shadow = master._shadow_wrap(pad, visible=False)
        rec_shadow.pack(fill="x", pady=(0, 2))
        rec_body = tk.Frame(rec_shadow, bg=T["panel_bg"], highlightthickness=0,
                            highlightbackground=T["border"], padx=4, pady=2)
        rec_body.pack(fill="both", expand=True, padx=(0, 0), pady=(0, 0))

        self._rec_var = tk.StringVar(value=self._sched.get("recurrence", "daily"))
        rec_row = tk.Frame(rec_body, bg=T["panel_bg"]); rec_row.pack(fill="x", pady=(0, 2))
        for val, lbl in (("daily", "Diario"), ("weekly", "Semanal"), ("interval", "Cada intervalo")):
            ttk.Radiobutton(rec_row, text=lbl, value=val, variable=self._rec_var,
                           command=lambda: _sync_rec_visibility()).pack(side="left", padx=(0, 4))

        hh, mm = _parse_hhmm(self._sched.get("time_of_day") or "02:00")
        self._hh_var = tk.StringVar(value=f"{hh:02d}")
        self._mm_var = tk.StringVar(value=f"{mm:02d}")
        self._wd_var = tk.StringVar(value=_WEEKDAYS[int(self._sched.get("weekday", 0)) % 7])
        self._interval_var = tk.StringVar(value=str(self._sched.get("interval_minutes") or 360))

        time_row = tk.Frame(rec_body, bg=T["panel_bg"])
        tk.Label(time_row, text="Hora", font=(_FUI, 12), bg=T["panel_bg"], fg=T["card_fg"]).pack(side="left")
        ttk.Spinbox(time_row, textvariable=self._hh_var, from_=0, to=23, width=3).pack(side="left", padx=(2, 1))
        tk.Label(time_row, text=":", bg=T["panel_bg"], fg=T["card_fg"]).pack(side="left")
        ttk.Spinbox(time_row, textvariable=self._mm_var, from_=0, to=59, width=3).pack(side="left", padx=(1, 1))
        tk.Label(time_row, text="(24h)", font=(_FUI, 12), bg=T["panel_bg"], fg=T["card_fg"]).pack(side="left")

        wd_row = tk.Frame(rec_body, bg=T["panel_bg"])
        tk.Label(wd_row, text="Día de la semana", font=(_FUI, 12), bg=T["panel_bg"], fg=T["card_fg"]).pack(side="left")
        ttk.Combobox(wd_row, textvariable=self._wd_var, values=_WEEKDAYS,
                    state="readonly", width=12).pack(side="left", padx=(2, 0))

        int_row = tk.Frame(rec_body, bg=T["panel_bg"])
        tk.Label(int_row, text="Intervalo (minutos)", font=(_FUI, 12), bg=T["panel_bg"], fg=T["card_fg"]).pack(side="left")
        ttk.Spinbox(int_row, textvariable=self._interval_var, from_=5, to=10080, width=6).pack(side="left", padx=(2, 2))
        tk.Label(int_row, text="mín. 5 — p.ej. 360 = cada 6h, 1440 = cada 24h",
                 font=(_FUI, 12), bg=T["panel_bg"], fg=T["card_fg"]).pack(side="left")

        def _sync_rec_visibility(*_a):
            rec = self._rec_var.get()
            for w_ in (time_row, wd_row, int_row):
                w_.pack_forget()
            if rec == "interval":
                int_row.pack(fill="x", pady=(0, 1))
            else:
                time_row.pack(fill="x", pady=(0, 2))
                if rec == "weekly":
                    wd_row.pack(fill="x", pady=(0, 1))
        _sync_rec_visibility()

        self._enabled_var = tk.BooleanVar(value=self._sched.get("enabled", True))
        ToggleSwitch(pad, text="Horario activo", variable=self._enabled_var).pack(anchor="w", pady=(2, 0))

        self._auto_open_var = tk.BooleanVar(value=self._sched.get("auto_open_on_finish", False))
        ToggleSwitch(
            pad, text="Abrir el reporte al terminar",
            variable=self._auto_open_var,
        ).pack(anchor="w", pady=(1, 0))

        def _time_conflict(new_s: dict) -> Optional[str]:
            """True (returns the clashing app name) if another ENABLED daily/weekly schedule fires at the exact same time_of_…"""
            rec = new_s.get("recurrence")
            if rec not in ("daily", "weekly"):
                return None
            for other in self._store.list_schedules():
                if other.get("id") == new_s.get("id"):
                    continue
                if not other.get("enabled", True):
                    continue
                o_rec = other.get("recurrence")
                if o_rec not in ("daily", "weekly"):
                    continue
                if other.get("time_of_day") != new_s.get("time_of_day"):
                    continue
                if rec == "weekly" and o_rec == "weekly" and\
                        int(other.get("weekday", 0)) != int(new_s.get("weekday", 0)):
                    continue
                return other.get("app_name", "?")
            return None

        def _save():
            app = app_by_name.get(self._app_var.get())
            if not app:
                self._status_lbl.config(text="⚠  Seleccione una aplicación.")
                return
            stages = [k for k in _STAGE_KEYS if self._stage_vars[k].get()]
            if not stages:
                self._status_lbl.config(text="⚠  Seleccione al menos un stage.")
                return
            try:
                hh_v, mm_v = int(self._hh_var.get()), int(self._mm_var.get())
            except Exception:
                hh_v, mm_v = 2, 0
            try:
                interval_v = max(5, int(self._interval_var.get()))
            except Exception:
                interval_v = 360
            s = dict(self._sched)
            s["app_id"]           = app["id"]
            s["app_name"]         = app["name"]
            s["stages"]           = stages
            s["recurrence"]       = self._rec_var.get()
            s["time_of_day"]      = f"{max(0, min(23, hh_v)):02d}:{max(0, min(59, mm_v)):02d}"
            s["weekday"]          = _WEEKDAYS.index(self._wd_var.get())
            s["interval_minutes"] = interval_v
            s["enabled"]          = bool(self._enabled_var.get())
            s["auto_open_on_finish"] = bool(self._auto_open_var.get())
            if s["enabled"]:
                clash = _time_conflict(s)
                if clash:
                    self._status_lbl.config(
                        text=f"⚠  Ya hay un horario de '{clash}' a las {s['time_of_day']} — "
                             "elija otra hora o desactive uno de los dos.")
                    return
            s["next_run_at"]      = _next_run_from(s, _now()).isoformat(timespec="seconds")
            self._store.save_schedule(s)
            try:
                self._store.save_stage_prefs(app["id"], stages)
            except Exception:
                pass
            self.result = s
            _close()

        _, self._status_lbl = master._popup_foot(
            content,
            ("  Cancelar  ", _close, "flat"),
            ("💾  Guardar Horario", _save, "accent"),
            with_status=True,
        )
        try: self.grab_set()
        except tk.TclError: pass
        self.focus_force()

class _ScheduleTabMixin:

    def _sched_banner(self, parent, text: str) -> tk.Frame:
        """Same visual language as ScannerApp._safety_banner, but the shared helper hardcodes wraplength=760 — on a wide/…"""
        f = tk.Frame(parent, bg=T["panel_bg"], highlightthickness=1,
                     highlightbackground=T["accent"], padx=3, pady=2)
        f.pack(fill="x", pady=(0, 2))
        tk.Label(f, text="⚠", font=(_FUI, 11, "bold"), bg=T["panel_bg"], fg=T["accent"]).pack(side="left")
        lbl = tk.Label(f, text=text, font=(_FUI, 10, "bold"), bg=T["panel_bg"], fg=T["text"],
                       anchor="w", justify="left")
        lbl.pack(side="left", padx=(2, 0), fill="x", expand=True)
        lbl.bind("<Configure>", lambda e: lbl.config(wraplength=max(e.width - 4, 100)))
        return f

    def _build_tab_schedule(self, parent):
        self._sched_store = ScheduleStore(Path(self._reports_var.get()).resolve())
        self._sched_pending_ids: set[str] = set()
        self._sched_event_queue: "queue.Queue" = queue.Queue()
        self._sched_engine_started = False

        pad = self._scrollable(parent)

        toolbar = tk.Frame(pad, bg=T["bg"]); toolbar.pack(fill="x", pady=(0, _CARD_GAP))
        self._btn(toolbar, "+ Nuevo horario",       self._sched_new,             "accent" ).pack(side="left", padx=(0, 2))
        self._btn(toolbar, "✏  Editar",              self._sched_edit,            "flat"   ).pack(side="left", padx=(0, 2))
        self._btn(toolbar, "🗑  Eliminar",            self._sched_delete,          "flat"   ).pack(side="left", padx=(0, 2))
        self._btn(toolbar, "⏻  Activar / Pausar",    self._sched_toggle_enabled,  "flat"   ).pack(side="left", padx=(0, 2))
        self._btn(toolbar, "▶  Ejecutar ahora",      self._sched_run_now,         "outline").pack(side="left", padx=(0, 2))
        self._sched_engine_lbl = self._lbl(toolbar, "", size=10, fg=T["muted"])
        self._sched_engine_lbl.pack(side="right")

        os_card = self._card(pad, 'Scheduler')
        os_row = tk.Frame(os_card, bg=T["panel_bg"]); os_row.pack(fill="x")
        os_btn_col = tk.Frame(os_row, bg=T["panel_bg"]); os_btn_col.pack(side="left", padx=(0, 4))
        self._icon_square_btn(os_btn_col, "🗑", self._ossched_remove_completely, danger=True).pack(side="left", padx=(0, 2))
        self._icon_square_btn(os_btn_col, "🔄", self._ossched_reinstall).pack(side="left")
        os_right_col = tk.Frame(os_row, bg=T["panel_bg"]); os_right_col.pack(side="left", fill="both", expand=True)
        self._os_sched_enabled_var = tk.BooleanVar(value=getattr(self, "_saved_os_sched_enabled", False))
        ToggleSwitch(
            os_right_col,
            text="Usar Windows Task Scheduler para programar scans si esta aplicación está cerrada.",

            variable=self._os_sched_enabled_var, command=self._ossched_on_toggle,
        ).pack(anchor="w", pady=(1, 2))
        self._ossched_status_lbl = tk.Label(os_right_col, text="Verificando…", font=(_FUI, 12),
                                            bg=T["panel_bg"], fg=T["card_fg"], anchor="w",
                                            justify="left", wraplength=680)
        self._ossched_status_lbl.pack(anchor="w", fill="x", pady=(0, 1))

        body = self._card(pad, 'Horarios')
        cols = ("app", "stages", "recur", "next", "last", "status", "enabled")
        headings = [("Aplicación", 190), ("Stages", 150), ("Recurrencia", 130),
                    ("Próxima ejecución", 150), ("Última ejecución", 150),
                    ("Resultado", 90), ("Activo", 60)]
        self._sched_tree = _make_tree(body, cols, headings, height=14)
        self._sched_tree.bind("<Double-1>", lambda _e: self._sched_edit())

        self._sched_refresh()
        self._schedule_engine_start()
        self._sched_drain()

        self.after(1500, self._ossched_kickoff_selfheal)

    def _sched_refresh(self) -> None:
        tree = self._sched_tree
        for iid in tree.get_children():
            tree.delete(iid)
        scheds = sorted(self._sched_store.list_schedules(), key=lambda s: s.get("next_run_at") or "")
        for s in scheds:
            stages_txt = "+".join(_STAGE_LABELS.get(k, k) for k in s.get("stages", []))
            status = {"ok": "✓ OK", "error": "✕ Error"}.get(s.get("last_run_status"), "—")
            tree.insert("", "end", iid=s["id"], values=(
                s.get("app_name", "?"), stages_txt, _describe_recurrence(s),
                _fmt_dt(s.get("next_run_at")) if s.get("enabled") else "(pausado)",
                _fmt_dt(s.get("last_run_at")), status,
                "✓" if s.get("enabled") else "—",
            ))
        enabled = [s for s in scheds if s.get("enabled")]
        if enabled:
            nxt = min(s.get("next_run_at") or "" for s in enabled)
            self._sched_engine_lbl.config(text=f"Motor activo · {len(enabled)} horario(s) · próxima: {_fmt_dt(nxt)}")
        else:
            self._sched_engine_lbl.config(text="Motor activo · sin horarios habilitados")

    def _sched_selected(self) -> Optional[dict]:
        sel = self._sched_tree.selection()
        if not sel:
            return None
        return self._sched_store.get_schedule(sel[0])

    def _sched_new(self) -> None:
        apps = self._inv_store.list_apps()
        if not apps:
            self._show_warn_popup("Sin aplicaciones",
                "Cree al menos una aplicación en 📦 Aplicaciones antes de programar un escaneo.")
            return
        ed = _ScheduleEditor(self, self._sched_store, apps)
        self.wait_window(ed)
        if ed.result:
            self._sched_refresh()
            self._ossched_kickoff_selfheal()

    def _sched_edit(self) -> None:
        s = self._sched_selected()
        if not s:
            return
        ed = _ScheduleEditor(self, self._sched_store, self._inv_store.list_apps(), s)
        self.wait_window(ed)
        if ed.result:
            self._sched_refresh()
            self._ossched_kickoff_selfheal()

    def _sched_delete(self) -> None:
        s = self._sched_selected()
        if not s:
            return
        def _do_delete():
            self._sched_store.delete_schedule(s["id"])
            self._sched_pending_ids.discard(s["id"])
            self._sched_refresh()
            if not self._sched_store.list_schedules():
                self._ossched_cleanup_if_unused()
        self._show_confirm_popup(
            "Eliminar horario",
            f"¿Eliminar el horario de '{s.get('app_name', '?')}'?\nEsta acción no se puede deshacer.",
            on_yes=_do_delete, yes_label="  🗑  Eliminar  ", no_label="  Cancelar  ")

    def _sched_toggle_enabled(self) -> None:
        s = self._sched_selected()
        if not s:
            return
        s["enabled"] = not s.get("enabled", True)
        if s["enabled"]:
            s["next_run_at"] = _next_run_from(s, _now()).isoformat(timespec="seconds")
        else:
            self._sched_pending_ids.discard(s["id"])
        self._sched_store.save_schedule(s)
        self._sched_refresh()

    def _sched_run_now(self) -> None:
        s = self._sched_selected()
        if not s:
            return
        if s["id"] in self._sched_pending_ids:
            self._emit_log(f"[schedule] '{s.get('app_name')}' ya está en cola.")
            return
        self._sched_pending_ids.add(s["id"])
        self._emit_log(f"[schedule] '{s.get('app_name')}' — ejecución manual solicitada, en cola.")
        self._sched_refresh()
        self._schedule_process_pending()

    def _ossched_kickoff_selfheal(self) -> None:
        """Safe to call repeatedly (every launch, every manual click)."""
        if getattr(self, "_headless", False):
            return
        if not self._sched_store.list_schedules():

            self._ossched_cleanup_if_unused()
            return
        if not self._os_sched_enabled_var.get():
            self._ossched_apply_status(scheduler_os.SchedulerStatus(
                backend=scheduler_os.platform_label(), installed=False,
                detail="Desactivado — los horarios solo corren con la aplicación abierta."))
            return
        try:
            self._ossched_status_lbl.config(text=f"Verificando {scheduler_os.platform_label()}…")
        except Exception:
            pass

        def _work():
            status = scheduler_os.install_or_repair(
                SCRIPT_DIR, sys.executable, DATA_DIR,
                interval_minutes=_OS_SCHED_INTERVAL_MIN, log=self._emit_log)
            self.after(0, lambda: self._ossched_apply_status(status))
        threading.Thread(target=_work, daemon=True).start()

    def _ossched_cleanup_if_unused(self) -> None:
        """No hay horarios → no debe haber tarea del SO."""
        def _work():
            status = scheduler_os.get_status(SCRIPT_DIR, sys.executable, DATA_DIR,
                                              interval_minutes=_OS_SCHED_INTERVAL_MIN)
            if status.installed:
                status = scheduler_os.remove(DATA_DIR, log=self._emit_log)
            else:
                status = scheduler_os.SchedulerStatus(
                    backend=scheduler_os.platform_label(), installed=False,
                    detail="Sin horarios configurados — no hay tarea registrada.")
            self.after(0, lambda: self._ossched_apply_status(status))
        threading.Thread(target=_work, daemon=True).start()

    def _ossched_remove_completely(self) -> None:
        """Botón explícito: apaga la casilla, la guarda, y borra la tarea del SO ya mismo — sin esperar al próximo lanzam…"""
        def _do_remove():
            self._os_sched_enabled_var.set(False)
            self._saved_os_sched_enabled = False
            try: self._save_settings()
            except Exception: pass
            try:
                self._ossched_status_lbl.config(text="Quitando tarea del sistema…")
            except Exception:
                pass
            def _work():
                status = scheduler_os.remove(DATA_DIR, log=self._emit_log)
                self.after(0, lambda: self._ossched_apply_status(status))
            threading.Thread(target=_work, daemon=True).start()
        self._show_confirm_popup(
            "Quitar tarea del sistema",
            f"Se eliminará por completo la tarea de {scheduler_os.platform_label()} que permite "
            "correr horarios con la aplicación cerrada.\n\nLos horarios que tengas configurados "
            "dentro de la app no se borran, pero dejarán de dispararse mientras la aplicación "
            "esté cerrada, hasta que vuelvas a activar la casilla de arriba.",
            on_yes=_do_remove, yes_label="  🗑  Quitar  ", no_label="  Cancelar  ")

    def _ossched_apply_status(self, status) -> None:
        self._os_sched_status = status
        if not self._os_sched_enabled_var.get():
            text, fg = status.detail, T["muted"]
        elif status.permission_denied:
            text, fg = "⚠  " + status.detail, T["accent"]
        elif status.healthy:
            text, fg = f"✓  {status.detail}", T["muted"]
        else:
            text, fg = "⚠  " + (status.detail or "No se pudo verificar el estado."), T["accent"]
        try:
            self._ossched_status_lbl.config(text=text, fg=fg)
        except Exception:
            pass

    def _ossched_reinstall(self) -> None:
        if not self._os_sched_enabled_var.get():

            def _work():
                status = scheduler_os.get_status(SCRIPT_DIR, sys.executable, DATA_DIR,
                                                  interval_minutes=_OS_SCHED_INTERVAL_MIN)
                self.after(0, lambda: self._ossched_apply_status(status))
            threading.Thread(target=_work, daemon=True).start()
            return
        self._ossched_kickoff_selfheal()

    def _ossched_on_toggle(self) -> None:
        self._saved_os_sched_enabled = bool(self._os_sched_enabled_var.get())
        try: self._save_settings()
        except Exception: pass
        if self._os_sched_enabled_var.get():
            self._ossched_kickoff_selfheal()
            return
        try:
            self._ossched_status_lbl.config(text="Quitando tarea del sistema…")
        except Exception:
            pass

        def _work():
            status = scheduler_os.remove(DATA_DIR, log=self._emit_log)
            self.after(0, lambda: self._ossched_apply_status(status))
        threading.Thread(target=_work, daemon=True).start()

    def _schedule_engine_start(self) -> None:
        if getattr(self, "_sched_engine_started", False):
            return
        self._sched_engine_started = True
        self._schedule_tick()

    def _schedule_tick(self) -> None:
        try:
            self._schedule_check_due()
            self._schedule_process_pending()
        except Exception as e:
            self._emit_log(f"[schedule] tick error: {e!r}")
        finally:
            self.after(_SCHEDULE_POLL_MS, self._schedule_tick)

    def _schedule_check_due(self) -> None:
        now = _now()
        due_any = False
        for s in self._sched_store.list_schedules():
            if not s.get("enabled"):
                continue
            nxt = s.get("next_run_at")
            try:
                is_due = bool(nxt) and datetime.fromisoformat(nxt) <= now
            except Exception:
                is_due = True
            if is_due and s["id"] not in self._sched_pending_ids:
                self._sched_pending_ids.add(s["id"])
                self._emit_log(f"[schedule] '{s.get('app_name', '?')}' vencido — en cola")
                due_any = True
        if due_any:
            self._sched_refresh()

    def _schedule_process_pending(self) -> None:
        if not self._sched_pending_ids or self._any_busy():
            return
        candidates = []
        for sid in self._sched_pending_ids:
            s = self._sched_store.get_schedule(sid)
            candidates.append((s.get("next_run_at") or "" if s else "", sid, s))
        candidates.sort(key=lambda t: t[0])
        _, sid, s = candidates[0]
        if not _claim_owner():

            return
        self._sched_pending_ids.discard(sid)
        if not s:
            _release_owner()
            return
        self._launch_scheduled_scan(s)

    def _launch_scheduled_scan(self, sched: dict) -> None:
        app = self._inv_store.get_app(sched.get("app_id", ""))
        if not app:
            self._emit_log(f"[schedule] aplicación '{sched.get('app_name', '?')}' ya no existe "
                           "en el inventario — se omite esta ejecución")
            now = _now()
            sched["last_run_at"] = now.isoformat(timespec="seconds")
            sched["last_run_status"] = "error"
            sched["next_run_at"] = _next_run_from(sched, now).isoformat(timespec="seconds")
            self._sched_store.save_schedule(sched)
            self._sched_refresh()
            return

        prev_snapshot = {
            "active_app": getattr(self, "_active_app", None),
            "target":     self._target_var.get(),
            "dast_url":   self._dast_url_var.get(),
            "api_spec":   self._api_spec_var.get(),
            "stages":     {k: v.get() for k, v in self._scan_vars.items()},
            "auto_open":  self._auto_open,
        }

        self._active_app = app
        self._target_var.set(app.get("target_path", ""))
        self._dast_url_var.set(app.get("dast_url", ""))
        self._api_spec_var.set(app.get("api_spec", ""))
        for k, v in self._scan_vars.items():
            v.set(k in sched.get("stages", []))

        self._auto_open = bool(sched.get("auto_open_on_finish", False))
        try:
            self._refresh_stage_cards(); self._refresh_scan_btn()
            self._refresh_active_app_banner(); self._update_window_title()
        except Exception:
            pass

        self._emit_log(f"[schedule] disparando escaneo programado para '{app.get('name')}' "
                       f"({'+'.join(sched.get('stages', []))})")
        try:
            import audit_log
            audit_log.write_event(Path(self._reports_var.get()), "schedule_fire",
                                  actor=self._user, app=app.get("name", ""),
                                  schedule_id=sched.get("id"), stages=sched.get("stages"),
                                  log=self._emit_log)
        except Exception:
            pass

        sched_id = sched.get("id")

        def _run_wrapped():
            ok = True
            try:
                self._do_scan()
            except Exception as e:
                ok = False
                self._emit_log(f"[schedule] error inesperado durante el escaneo programado: {e!r}")
            self._sched_event_queue.put(("finish", (sched_id, prev_snapshot, ok)))

        self._run_async(_run_wrapped, label=f"escaneo programado: {app.get('name')}")

    def _sched_drain(self) -> None:
        try:
            while True:
                kind, payload = self._sched_event_queue.get_nowait()
                if kind == "finish":
                    self._finish_scheduled_run(*payload)
        except queue.Empty:
            pass
        self.after(200, self._sched_drain)

    def _finish_scheduled_run(self, sched_id: str, prev_snapshot: dict, ok: bool) -> None:

        self._active_app = prev_snapshot["active_app"]
        self._target_var.set(prev_snapshot["target"])
        self._dast_url_var.set(prev_snapshot["dast_url"])
        self._api_spec_var.set(prev_snapshot["api_spec"])
        for k, v in self._scan_vars.items():
            v.set(prev_snapshot["stages"].get(k, False))
        self._auto_open = prev_snapshot["auto_open"]
        try:
            self._refresh_stage_cards(); self._refresh_scan_btn()
            self._refresh_active_app_banner(); self._update_window_title()
        except Exception:
            pass

        sched = self._sched_store.get_schedule(sched_id)
        if sched:
            now = _now()
            sched["last_run_at"] = now.isoformat(timespec="seconds")
            sched["last_run_status"] = "ok" if ok else "error"
            sched["next_run_at"] = _next_run_from(sched, now).isoformat(timespec="seconds")
            self._sched_store.save_schedule(sched)
        self._emit_log(f"[schedule] ejecución programada finalizada ({'ok' if ok else 'error'})")
        self._sched_refresh()
        _release_owner()
