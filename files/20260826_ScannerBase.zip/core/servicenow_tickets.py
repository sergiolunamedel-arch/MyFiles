"""servicenow_tickets.py — automatic ServiceNow ticket sync for scan findings.

Called by static_scanner.py (per scanned folder) and gui_dast_api_tab.py (per app)
right after a scan finishes. Given the severity counts *of that one scan*, it:

  - creates a ticket (in DEV — ambiente="Desarrollo") the first time a repo/app shows
    critical/high findings,
  - adds a progress comment on every re-scan while critical/high findings remain,
  - closes the ticket automatically once a re-scan of the same repo/app comes back
    clean.

"Same repo/app" is a plain string key: the scanned folder's basename for static
(SCA/SAST/Secrets) findings, the application name (from the Aplicaciones tab) for
DAST/API findings — per the product decision that folders identify a static target
but only the app profile identifies a dynamic one. State lives in a small JSON file
next to the other per-reports-root state (servicenow_tickets.json), independent of
ScanStateStore (which is a *global* last-known-value cache across every target and is
not safe to use for a per-repo/app decision — see build_cumulative_context).

Everything here is best-effort: a ServiceNow error never raises out to the caller, it's
logged and the scan/report continues — matching the explicit "si hay errores al crear
el ticket no lo pongas pero si que continue el proceso" requirement.

Known assumptions worth confirming against the real DEV instance (see the constants in
test_servicenow_ticket.py):
  - RESOLVE_STATE_VALUE ("Closed Complete") is a guess at the choice-list value that
    means "resolved", distinct from CANCEL_STATE_VALUE ("Closed Cancelled") already
    used by the tester for throwaway test tickets. If your instance uses a different
    label (or a numeric state), set SNOW_RESOLVE_STATE_VALUE.
  - Progress comments are written to work_notes (internal), not comments (visible to
    the requester). Set SNOW_COMMENT_FIELD=comments to flip that.
  - DAST and API share ONE ticket per application (both flagged on the same request)
    rather than one ticket each — see summarize_dynamic().
  - Requester identity on created tickets reuses the same placeholder identity
    (id_del_solicitante/nombre_del_solicitante/correo_del_solicitante) as
    test_servicenow_ticket.py's BASE_FIELDS. Override via the `overrides` argument to
    core.build_payload if these need to be a real automation account.
"""

from __future__ import annotations

import json
import threading
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

import test_servicenow_ticket as core
from report_engine import build_context

STORE_FILENAME = "servicenow_tickets.json"
_LOCK = threading.Lock()

_SEVERITIES = ("critical", "high", "medium", "low")


# --------------------------------------------------------------------------- store ---

def _store_path(reports_root) -> Path:
    return Path(reports_root) / STORE_FILENAME


def _load_store(reports_root) -> dict:
    p = _store_path(reports_root)
    if p.exists():
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            data.setdefault("tickets", {})
            return data
        except Exception:
            pass
    return {"version": 1, "tickets": {}}


def _save_store(reports_root, data: dict) -> None:
    p = _store_path(reports_root)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def _ticket_key(kind: str, name: str) -> str:
    return f"{kind}:{name.strip().lower()}"


def _now_iso() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# ---------------------------------------------------------------- severity summaries --

def _sum_counts(*count_dicts: dict) -> dict:
    total = {k: 0 for k in _SEVERITIES}
    for c in count_dicts:
        for k in _SEVERITIES:
            total[k] += int((c or {}).get(k, 0) or 0)
    return total


def _has_high_or_crit(counts: dict) -> bool:
    return bool((counts or {}).get("critical") or (counts or {}).get("high"))


def summarize_static(sca_raw, code_raw, secrets_raw, target, snyk_version) -> dict:
    """Severity summary for the folder-based (SCA/SAST/Secrets) side of one scan run.
    Only looks at the raw results handed in -- NOT the cumulative cross-target state --
    so it reflects exactly what this run actually checked."""
    sca_ctx = build_context(sca_raw, None, target, snyk_version)
    code_ctx = build_context(None, code_raw, target, snyk_version)
    sec_ctx = build_context(None, None, target, snyk_version, secrets_data=secrets_raw)
    counts = _sum_counts(sca_ctx["counts"], code_ctx["counts"], sec_ctx["counts"])
    return {
        "counts": counts,
        "total": sca_ctx["total"] + code_ctx["total"] + sec_ctx["total"],
        "services": {
            "sast_sca": _has_high_or_crit(sca_ctx["counts"]) or _has_high_or_crit(code_ctx["counts"]),
            "secretos": _has_high_or_crit(sec_ctx["counts"]),
        },
    }


def summarize_dynamic(dast_raw, api_raw, target, snyk_version) -> dict:
    """Severity summary for the DAST/API side of one scan run (same caveat as above)."""
    dast_ctx = build_context(None, None, target, snyk_version, dast_data=dast_raw)
    api_ctx = build_context(None, None, target, snyk_version, api_data=api_raw)
    counts = _sum_counts(dast_ctx["counts"], api_ctx["counts"])
    return {
        "counts": counts,
        "total": dast_ctx["total"] + api_ctx["total"],
        "services": {
            "dast": _has_high_or_crit(dast_ctx["counts"]),
            "api": _has_high_or_crit(api_ctx["counts"]),
        },
    }


# --------------------------------------------------------------------- comment text --
# Plain, terse, numbers-first -- matches this app's own log/audit-line register rather
# than a chatty tone.

def _fmt_counts(c: dict) -> str:
    return (f"C{c.get('critical', 0)}/A{c.get('high', 0)}/"
            f"M{c.get('medium', 0)}/B{c.get('low', 0)}")


def _pl(n: int, singular: str, plural: str) -> str:
    return singular if n == 1 else plural


def _delta(prev: dict, cur: dict) -> tuple[int, int]:
    remediated = sum(max((prev or {}).get(s, 0) - (cur or {}).get(s, 0), 0) for s in _SEVERITIES)
    introduced = sum(max((cur or {}).get(s, 0) - (prev or {}).get(s, 0), 0) for s in _SEVERITIES)
    return remediated, introduced


def _text_created(name: str, summary: dict) -> str:
    c = summary["counts"]
    crit, high, total = c.get("critical", 0), c.get("high", 0), summary.get("total", 0)
    return (f"Escaneo automático detectó {crit} {_pl(crit, 'vulnerabilidad crítica', 'vulnerabilidades críticas')} "
            f"y {high} {_pl(high, 'alta', 'altas')} en {name}. Se solicita revisión y remediación. "
            f"Detalle: {_fmt_counts(c)} sobre {total} {_pl(total, 'hallazgo', 'hallazgos')} "
            f"{_pl(total, 'total', 'totales')}.")


def _text_progress(name: str, prev: dict, cur: dict) -> str:
    remediated, introduced = _delta(prev, cur)
    parts = [f"Re-escaneo de {name}: estado actual {_fmt_counts(cur)}."]
    if remediated:
        parts.append(f"Se {_pl(remediated, 'remedió', 'remediaron')} {remediated} "
                     f"{_pl(remediated, 'hallazgo', 'hallazgos')} desde la última actualización.")
    if introduced:
        parts.append(f"Se {_pl(introduced, 'detectó', 'detectaron')} {introduced} "
                     f"{_pl(introduced, 'hallazgo nuevo', 'hallazgos nuevos')}.")
    crit, high = cur.get('critical', 0), cur.get('high', 0)
    parts.append(f"Siguen pendientes {crit} {_pl(crit, 'crítica', 'críticas')} "
                f"y {high} {_pl(high, 'alta', 'altas')}.")
    return " ".join(parts)


def _text_closed(name: str, opened: dict, cur: dict) -> str:
    remediated, _ = _delta(opened, cur)
    med, low = cur.get('medium', 0), cur.get('low', 0)
    return (f"Re-escaneo de {name} ya no reporta vulnerabilidades críticas ni altas "
            f"({remediated} {_pl(remediated, 'remediada', 'remediadas')} desde la apertura del ticket). "
            f"Se cierra el seguimiento automáticamente. Quedan {med} "
            f"{_pl(med, 'media', 'medias')} y {low} {_pl(low, 'baja', 'bajas')} sin impacto en el gate.")


# ------------------------------------------------------------------------- creation --

def _create_ticket(key: str, kind: str, name: str, summary: dict, app_name: str,
                    environment: str, auth, extra_headers: dict, log) -> dict:
    services = [s for s, on in summary.get("services", {}).items() if on]
    if not services:
        services = ["sast_sca"] if kind == "static" else ["dast"]

    overrides: dict = {}
    if kind == "static" and "secretos" in services:
        overrides["repositorio_s"] = json.dumps([{"name": name}], ensure_ascii=False)
        overrides["ruta_monorepo"] = "/"

    payload = core.build_payload(
        services, ambiente=environment, app_name=(app_name or name),
        descripcion=_text_created(name, summary), overrides=overrides)
    row = core.send_request(f"{kind}:{name}", payload, auth, extra_headers,
                            dry_run=False, log=log)

    now = _now_iso()
    ok = row.get("status") in (200, 201)
    rec = {
        "key": key, "kind": kind, "name": name, "app_name": app_name,
        "status": "open" if ok else "error",
        "sys_id": row.get("sys_id", ""), "request_number": row.get("request_number", ""),
        "ritm_sys_id": "", "ritm_number": "",
        "created_at": now, "updated_at": now,
        "opened_counts": dict(summary["counts"]), "last_counts": dict(summary["counts"]),
        "scans_since_open": 1,
        "history": [{"ts": now, "event": "created" if ok else "create_failed",
                     "note": row.get("error", "") if not ok else _text_created(name, summary)}],
    }

    if ok and rec["sys_id"]:
        ritm = core.find_ritm_for_request(rec["sys_id"], auth, extra_headers, log=log)
        if ritm.get("ritm_sys_id"):
            rec["ritm_sys_id"] = ritm["ritm_sys_id"]
            rec["ritm_number"] = ritm["ritm_number"]

    if ok:
        log(f"[servicenow] ticket creado para {name}: "
            f"{rec['ritm_number'] or rec['request_number'] or rec['sys_id']}")
    else:
        log(f"[servicenow] no se pudo crear el ticket para {name}: {row.get('error', '')[:200]}")
    return rec


def _update_open_ticket(rec: dict, summary: dict, auth, extra_headers: dict, log) -> None:
    cur = summary["counts"]
    note = _text_progress(rec["name"], rec.get("last_counts", {}), cur)
    sys_id = rec.get("ritm_sys_id") or rec.get("sys_id")
    table = core.RITM_TABLE if rec.get("ritm_sys_id") else core.CANCEL_TABLE
    ok = core.update_record(table, sys_id, {core.COMMENT_FIELD: note}, auth, extra_headers, log=log)

    rec["last_counts"] = dict(cur)
    rec["scans_since_open"] = rec.get("scans_since_open", 0) + 1
    rec["updated_at"] = _now_iso()
    rec.setdefault("history", []).append(
        {"ts": rec["updated_at"], "event": "comment" if ok else "comment_failed", "note": note})
    rec["history"] = rec["history"][-20:]
    label = rec.get("ritm_number") or rec.get("request_number")
    log(f"[servicenow] {'comentario agregado en' if ok else 'no se pudo comentar'} {label}")


def _close_ticket(rec: dict, summary: dict, auth, extra_headers: dict, log) -> None:
    cur = summary["counts"]
    note = _text_closed(rec["name"], rec.get("opened_counts", {}), cur)
    sys_id = rec.get("ritm_sys_id") or rec.get("sys_id")
    table = core.RITM_TABLE if rec.get("ritm_sys_id") else core.CANCEL_TABLE
    fields = {core.RESOLVE_STATE_FIELD: core.RESOLVE_STATE_VALUE, "close_notes": note}
    ok = core.update_record(table, sys_id, fields, auth, extra_headers, log=log)

    if ok:
        rec["status"] = "closed"
        rec["closed_at"] = _now_iso()
    rec["last_counts"] = dict(cur)
    rec["updated_at"] = _now_iso()
    rec.setdefault("history", []).append(
        {"ts": rec["updated_at"], "event": "closed" if ok else "close_failed", "note": note})
    rec["history"] = rec["history"][-20:]
    label = rec.get("ritm_number") or rec.get("request_number")
    log(f"[servicenow] {'ticket cerrado' if ok else 'no se pudo cerrar el ticket'}: {label}")


# --------------------------------------------------------------------------- public --

def sync_ticket(reports_root, *, kind: str, name: str, summary: dict,
                 app_name: str = "", environment: str = "Desarrollo",
                 actor: str = "", log=print) -> Optional[dict]:
    """Create/update/close the ticket for this repo (kind="static") or app
    (kind="dynamic") based on `summary` (see summarize_static/summarize_dynamic).
    Returns the stored ticket record, or None if there's nothing to track (no name, or
    no ticket ever existed and nothing to open). Never raises."""
    name = (name or "").strip()
    if not name:
        log(f"[servicenow] sin nombre de {'repositorio' if kind == 'static' else 'aplicación'} — se omite ticket")
        return None

    auth_pair = core.get_auth_silent()
    key = _ticket_key(kind, name)

    with _LOCK:
        store = _load_store(reports_root)
        rec = store["tickets"].get(key)
        has_issue = _has_high_or_crit(summary["counts"])

        if auth_pair is None:
            if has_issue or (rec and rec.get("status") == "open"):
                log("[servicenow] sin credenciales guardadas — no se sincroniza el ticket "
                    "(abra el ServiceNow Ticket Tester, inicie sesión y marque "
                    "'Recordar en este equipo' para activar esta función)")
            return rec

        auth, extra_headers = auth_pair
        try:
            if rec and rec.get("status") == "open":
                if has_issue:
                    _update_open_ticket(rec, summary, auth, extra_headers, log)
                else:
                    _close_ticket(rec, summary, auth, extra_headers, log)
            elif has_issue:
                if rec and rec.get("status") == "closed":
                    log(f"[servicenow] {name}: vuelven a aparecer vulnerabilidades altas/críticas "
                        f"tras haberse cerrado el ticket anterior "
                        f"({rec.get('ritm_number') or rec.get('request_number')}) — se abre uno nuevo")
                rec = _create_ticket(key, kind, name, summary, app_name, environment,
                                     auth, extra_headers, log)
            # else: nothing open, nothing to report -> no-op
        except Exception as e:
            log(f"[servicenow] error de sincronización, se continúa sin ticket: {e!r}")

        if rec is not None:
            store["tickets"][key] = rec
        _save_store(reports_root, store)
        return rec


def public_view(rec: Optional[dict]) -> dict:
    """Small dict safe to embed in ctx (report template) / meta.json — no history, no
    internal sys_ids beyond what's needed to build a link."""
    if not rec:
        return {}
    return {
        "kind": rec.get("kind", ""),
        "name": rec.get("name", ""),
        "status": rec.get("status", ""),
        "number": rec.get("ritm_number") or rec.get("request_number") or "",
        "link": core.ritm_url(rec["ritm_sys_id"]) if rec.get("ritm_sys_id") else "",
    }


def display_string(tickets: list) -> str:
    """One-line summary for tree rows, e.g. 'RITM0012345' or 'RITM0012345, RITM0012346'."""
    labels = [t.get("number") for t in (tickets or []) if t and t.get("number")]
    return ", ".join(labels) if labels else "—"
