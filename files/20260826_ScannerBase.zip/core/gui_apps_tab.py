from __future__ import annotations

"""gui_apps_tab.py — Application Inventory: data model, persistence, editor
popup, dashboard/tree UI, and the ScannerApp tab integration.

Fusion of the former ``app_inventory.py`` (AppInventoryStore persistence,
AppProfileEditor popup, AppInventoryTab dashboard/tree UI) and
``gui_apps_tab.py`` (the thin ``_AppsTabMixin`` that wires the inventory tab
into ScannerApp — active-app loading, window title, header banner/chip).

This module is one of ScannerApp's wired mixin modules (see
``_MIXIN_MODULES`` / ``_wire_mixin_globals()`` in INICIAR_SnykScannerGUI.py),
so palette/font/chrome globals — ``T``, ``_FUI``, ``_FMONO``,
``APP_BRAND_NAME``, ``_apply_panel_chrome``, ``_monitor_wh``,
``_popup_follow_parent``, ``_bind_popup_close`` — are injected as module
globals by the main app before any of the UI code below ever runs, so it is
referenced directly rather than looked up per-call.
"""

import json
import re
import threading
from datetime import datetime, timedelta
from pathlib import Path
from tkinter import ttk
from typing import Optional
import tkinter as tk

_RISK_COLORS_LIGHT = {
    "Crítico": "#c8102e",
    "Alto":     "#e26020",
    "Medio":   "#d4a017",
    "Bajo":      "#1a7a4a",
    "Ninguno":     "#5a6475",
}
_RISK_COLORS_DARK = {
    "Crítico": "#f08090",
    "Alto":     "#f4a460",
    "Medio":   "#f0d060",
    "Bajo":      "#5fe0a0",
    "Ninguno":     "#8892a4",
}

_TECH_STACKS = [
    "Python", "Node.js / JavaScript", "Java / Spring", "C# / .NET",
    "Go", "Ruby on Rails", "PHP", "Rust", "C / C++", "Kotlin / Android",
    "Swift / iOS", "React / Vue / Angular (SPA)", "Mobile (React Native)",
    "Microservicios", "Serverless / Lambda", "Otro",
]

_ENVIRONMENTS = [
    "Producción", "Preproducción / Staging", "QA / Pruebas",
    "Desarrollo", "Interno / Intranet", "Nube (AWS)", "Nube (Azure)",
    "Nube (GCP)", "En sitio (On-Premise)", "Híbrido",
]

_APP_TYPES = [
    "Aplicación Web", "API REST", "API GraphQL", "App Móvil (iOS)",
    "App Móvil (Android)", "Aplicación de Escritorio", "Herramienta CLI / Script",
    "Microservicio", "Pipeline de Datos", "Proceso por Lotes / Trabajo en Segundo Plano",
    "IoT / Embebido", "Librería / SDK", "Otro",
]

_CRITICALITY_LEVELS = [
    "Crítico para la Misión",
    "Crítico para el Negocio",
    "Importante",
    "Estándar",
    "Bajo",
]

_COMPLIANCE_TAGS = [
    "PCI-DSS", "PCI-DSS v4", "ISO 27001", "ISO 27001:2022",
    "SOC 2 Type II", "NIST CSF", "NIST SP 800-53",
    "OWASP Top-10", "OWASP ASVS", "CIS Benchmarks",
    "GDPR", "LFPDPPP (Mexico)", "CNBV Circular", "DORA (EU)",
    "HIPAA", "FedRAMP", "NOM-151", "Ninguno",
]

_DATA_CLASSIFICATION = [
    "Confidencial — Financiero",
    "Confidencial — Personal",
    "Restringido",
    "Interno",
    "Público",
]

_EMPTY_APP: dict = {

    "id":            "",
    "name":          "",
    "description":   "",
    "owner":         "",
    "owner_email":   "",
    "created_at":    "",
    "updated_at":    "",

    "app_type":      _APP_TYPES[0],
    "tech_stack":    _TECH_STACKS[0],
    "environment":   _ENVIRONMENTS[0],
    "criticality":   _CRITICALITY_LEVELS[1],
    "data_class":    _DATA_CLASSIFICATION[0],
    "compliance":    [],
    "repo_url":      "",
    "ci_pipeline":   "",

    "target_path":   "",
    "dast_url":      "",
    "api_spec":      "",
    "scan_stages":   ["sca", "code", "secrets"],

    "last_scan":     None,
    "last_mode":     "",
    "vuln_critical": 0,
    "vuln_high":     0,
    "vuln_medium":   0,
    "vuln_low":      0,
    "vuln_total":    0,
    "secrets_total": 0,
    "risk_tier":     "Ninguno",

    "scan_history":  [],

    "notes":         "",
}

def _slugify(name: str) -> str:
    """Convert a human name to a safe filename slug."""
    s = name.strip().lower()
    s = re.sub(r"[^\w\s-]", "", s)
    s = re.sub(r"[\s_-]+", "_", s)
    return s[:48] or "app"

def _risk_tier(critical: int, high: int, medium: int, low: int) -> str:
    if critical:  return "Crítico"
    if high:      return "Alto"
    if medium:    return "Medio"
    if low:       return "Bajo"
    return "Ninguno"

def _now() -> str:
    return datetime.now().strftime("%Y-%m-%dT%H:%M:%S")

class AppInventoryStore:
    """Thread-safe JSON store for application profiles."""

    def __init__(self, reports_root: Path):
        self._lock   = threading.Lock()
        self.inv_dir = reports_root / "inventory"
        self.inv_dir.mkdir(parents=True, exist_ok=True)
        self._index_path = self.inv_dir / "_index.json"

    def _read_index(self) -> list[str]:
        """Return ordered list of app IDs."""
        try:
            if self._index_path.exists():
                return json.loads(self._index_path.read_text("utf-8"))
        except Exception:
            pass

        ids = sorted(
            p.stem for p in self.inv_dir.glob("*.json")
            if p.name != "_index.json"
        )
        self._write_index(ids)
        return ids

    def _write_index(self, ids: list[str]) -> None:
        self._index_path.write_text(json.dumps(ids, indent=2), "utf-8")

    def _app_path(self, app_id: str) -> Path:
        return self.inv_dir / f"{app_id}.json"

    def list_apps(self) -> list[dict]:
        """Return all app dicts in index order."""
        with self._lock:
            ids = self._read_index()
            apps = []
            for aid in ids:
                p = self._app_path(aid)
                if p.exists():
                    try:
                        apps.append(json.loads(p.read_text("utf-8")))
                    except Exception:
                        pass
            return apps

    def get_app(self, app_id: str) -> Optional[dict]:
        with self._lock:
            p = self._app_path(app_id)
            if p.exists():
                try:
                    return json.loads(p.read_text("utf-8"))
                except Exception:
                    pass
        return None

    def save_app(self, app: dict) -> None:
        """Create or update an app profile. Generates id if missing."""
        with self._lock:
            if not app.get("id"):
                app["id"] = _slugify(app.get("name", "app"))

            existing = self._read_index()
            if app["id"] not in existing:

                base = app["id"]; n = 1
                while (self.inv_dir / f"{app['id']}.json").exists():
                    app["id"] = f"{base}_{n}"; n += 1
                existing.append(app["id"])
                self._write_index(existing)
            app["updated_at"] = _now()
            if not app.get("created_at"):
                app["created_at"] = app["updated_at"]
            self._app_path(app["id"]).write_text(
                json.dumps(app, indent=2, ensure_ascii=False), "utf-8")

    def delete_app(self, app_id: str) -> None:
        with self._lock:
            ids = self._read_index()
            if app_id in ids:
                ids.remove(app_id)
                self._write_index(ids)
            p = self._app_path(app_id)
            if p.exists():
                p.unlink()

    def record_scan(self, app_id: str, meta: dict) -> None:
        """Update vuln counts from a completed scan meta dict."""
        app = self.get_app(app_id)
        if app is None:
            return
        counts = meta.get("counts", {})
        c = int(counts.get("critical", 0) or 0)
        h = int(counts.get("high", 0) or 0)
        m = int(counts.get("medium", 0) or 0)
        lo = int(counts.get("low", 0) or 0)
        tot = int(meta.get("total", 0) or 0)
        sec = int(meta.get("secrets_total", 0) or 0)
        app["last_scan"]     = _now()
        app["last_mode"]     = meta.get("mode", "")
        app["vuln_critical"] = c
        app["vuln_high"]     = h
        app["vuln_medium"]   = m
        app["vuln_low"]      = lo
        app["vuln_total"]    = tot
        app["secrets_total"] = sec
        app["risk_tier"]     = _risk_tier(c, h, m, lo)
        app.setdefault("scan_history", []).append({
            "ts":       app["last_scan"],
            "mode":     app["last_mode"],
            "critical": c, "high": h,
            "medium":   m, "low":  lo,
            "total":    tot,
        })

        app["scan_history"] = app["scan_history"][-50:]
        self.save_app(app)

class AppProfileEditor(tk.Toplevel):
    """Modal dialog to create or edit an application profile."""
    def __init__(self, master, store: AppInventoryStore,
                 app: Optional[dict] = None):
        super().__init__(master)
        self._store  = store
        self._app    = dict(_EMPTY_APP)
        if app:
            self._app.update(app)
        self.result: Optional[dict] = None

        self.auto_load_var = tk.BooleanVar(value=True)
        FUI = _FUI

        self.transient(master)

        master.update_idletasks()
        mw, mh = _monitor_wh(master)
        w, h = int(mw * 0.75), int(mh * 0.75)
        px, py = master.winfo_rootx(), master.winfo_rooty()
        pw, ph = master.winfo_width(), master.winfo_height()
        self.geometry(f"{w}x{h}+{px + (pw - w)//2}+{py + (ph - h)//2}")
        self.overrideredirect(True)
        self.update_idletasks(); self.lift(); self.focus_force()
        try: self.grab_set()
        except tk.TclError: pass
        _bind_ids: dict = {}
        _close = _bind_popup_close(self, master, _bind_ids)
        _bind_ids.update(_popup_follow_parent(self, master))

        content = _apply_panel_chrome(self)
        content.close = _close

        title_text = ("✏  Editar Perfil de Aplicación" if app else "📋  Perfil de Aplicación")
        master._popup_hdr(
            content, title_text,
            subtitle="Complete los campos — solo el Nombre es obligatorio.",
            on_close=_close,
        )

        canvas = tk.Canvas(content, bg=T["bg"], highlightthickness=0, bd=0)
        vsb    = ttk.Scrollbar(content, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        canvas.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        holder = tk.Frame(canvas, bg=T["bg"])
        win_id = canvas.create_window((0, 0), window=holder, anchor="nw")
        holder.bind("<Configure>",
                    lambda _: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>",
                    lambda e: canvas.itemconfigure(win_id, width=e.width))
        def _wheel(e): canvas.yview_scroll(int(-e.delta / 120), "units")
        canvas.bind("<Enter>", lambda _: canvas.bind_all("<MouseWheel>", _wheel))
        canvas.bind("<Leave>", lambda _: canvas.unbind_all("<MouseWheel>"))
        pad = tk.Frame(holder, bg=T["bg"], padx=7, pady=4)
        pad.pack(fill="both", expand=True)

        self._vars: dict[str, tk.Variable] = {}

        def sv(key, default=""): v=tk.StringVar(value=self._app.get(key,default)); self._vars[key]=v; return v

        v_name       = sv("name")
        v_desc       = sv("description")
        v_owner      = sv("owner")
        v_email      = sv("owner_email")
        v_repo       = sv("repo_url")
        v_type       = sv("app_type",       _APP_TYPES[0])
        v_stack      = sv("tech_stack",     _TECH_STACKS[0])
        v_env        = sv("environment",    _ENVIRONMENTS[0])
        v_crit       = sv("criticality",    _CRITICALITY_LEVELS[1])
        v_data       = sv("data_class",     _DATA_CLASSIFICATION[0])

        def section(title: str) -> tk.Frame:
            sh = tk.Frame(pad, bg=T["surface3"], padx=3, pady=1)
            sh.pack(fill="x", pady=(3, 2))
            master._lbl(sh, text=title, size=14, bold=True,
                        bg=T["surface3"], fg=T["card_fg"]).pack(side="left")
            shadow_wrap = master._shadow_wrap(pad, visible=False)
            shadow_wrap.pack(fill="x", pady=(0, 1))
            inner = tk.Frame(shadow_wrap, bg=T["panel_bg"],
                             highlightthickness=0,
                             highlightbackground=T["border"])
            inner.pack(fill="both", expand=True, padx=(0, 0), pady=(0, 0))
            body_f = tk.Frame(inner, bg=T["panel_bg"], padx=4, pady=2)
            body_f.pack(fill="both", expand=True)
            return body_f

        def row(parent, label: str, widget_factory, tip: str = "") -> tk.Widget:
            r = tk.Frame(parent, bg=T["panel_bg"])
            r.pack(fill="x", pady=1)
            lbl = master._lbl(r, text=label, size=12, bg=T["panel_bg"],
                              fg=T["card_fg"], anchor="w", width=22)
            lbl.pack(side="left")
            w = widget_factory(r)
            w.pack(side="left", fill="x", expand=True)
            return w

        def entry(parent, var) -> ttk.Entry:
            return ttk.Entry(parent, textvariable=var)

        def combo(parent, var, values) -> ttk.Combobox:
            return ttk.Combobox(parent, textvariable=var,
                                values=values, state="readonly", width=36)

        s1 = section("Identidad")

        _BANK_APPS = [
            "ACL Analytics", "Activación", "AllianceWarehouse", "ALPINEDEVSECOPSNODE2",
            "API Manager", "auth-service", "Avaya Acra Report", "axiscom",
            "B2B_Loans", "B3", "Backoffice - AML", "BackOffice - Captacion",
            "Backoffice - Catalogs", "Backoffice - Client as a Service",
            "Backoffice - Digital Business", "Backoffice - Framework",
            "Backoffice - Middle Office", "Backoffice - Operations",
            "Backoffice - Security", "BackOffice - Solutions", "Bajaware",
            "Base Fix API", "Baseinet", "Baseinet - Automation", "BaseLake",
            "BaseMX", "Bastian", "BaseWEB - Refresh", "Bayu", "BI",
            "Binnacle App", "Biometrics", "Blacklist Api", "bloom", "BPM",
            "Calculator", "ChannelPayments", "CI/CD", "CIS BenchMark", "Citrix",
            "Clients API", "Cloud", "Cognos", "Collectpayments",
            "CommonLibraries-dso", "commons-dev", "Communicator", "ConnectDirect",
            "Constancias - Retenciones", "Contabilidad", "ContPaq",
            "ContratoDigitalExp", "Core Batch", "Core FX", "Core Withholding",
            "coreaxis", "Corems", "Credit Bureau", "Crypto API", "Customers",
            "Darwin", "DataHub", "Datascience", "DealTracker", "DevelopTools",
            "devsecops-alpine-python-1", "devsecops-ex-py-1",
            "devsecops-workshop-sample-1", "DEVSECOPSALPINEJAVA1",
            "Digital infrastructure", "Digital Transformation", "DirectDebit",
            "Easycredit", "ESB", "ESBs", "Fiel Services", "FinantialOCI",
            "FixReader", "FoundDispersion", "generic",
            "gfb-devsecops-infra-onprem-cloud", "gfb-externalpayments", "GWDB",
            "H2H", "Historical Databases", "Hopex", "Image check", "Imperva",
            "indeval", "Infrastructure Requests POC", "Infrastrucutre Requests",
            "Instrumental", "Intelexion", "Interfaz BBASE Creditos",
            "Interfaz Reuters", "InvoiceAssignment", "ISILoans", "IT Architecture",
            "ITAL", "Kondor - Derivatives", "Legal", "Lexis Nexis - AML",
            "maincatalogs", "MessageHub", "ModeloRiesgo", "MoneyMarketBk",
            "MoneyMarketCB", "Nautilus", "Notificator API", "Nuba2.0", "OnBase",
            "Onboarding", "Onboarding-Gen", "Onboarding-PF", "Onboarding-PM",
            "Pagare", "Panjiva", "PIPELINE-BPM", "PLD", "PLD - Fraudes",
            "Power BI", "Price Vector", "PrivateCloud", "PROKEY1", "Proleasenet",
            "Quadient", "RecipientAccounts", "Release Management", "Rentabilidad",
            "RiskAnalysis", "RPA", "Sailpoint", "Salesforce", "SatEnrichment",
            "security", "Service Now", "Sibase", "Siglo", "Siscore", "SonarQube",
            "specoff", "SPEI", "SPID", "SWA", "SWIFT", "Tableau", "Taller Git",
            "Teller", "Transactional-linking", "Validanet", "Veritran VTET",
            "Volpay", "WebLandings", "WinService Alerts", "wiretransfer",
            "workflowcontroller", "Workspaces", "Wrapper", "Wso2_internal",
        ]

        name_outer = tk.Frame(s1, bg=T["panel_bg"]); name_outer.pack(fill="x", pady=1)
        master._lbl(name_outer, text="Nombre de la Aplicación *", size=12,
                    bg=T["panel_bg"], fg=T["card_fg"], anchor="w", width=22).pack(side="left")
        name_right = tk.Frame(name_outer, bg=T["panel_bg"]); name_right.pack(side="left", fill="x", expand=True)

        search_var = tk.StringVar()
        search_entry = ttk.Entry(name_right, textvariable=search_var)
        search_entry.pack(fill="x")

        lb_wrap = tk.Frame(name_right, bg=T["panel_bg"],
                           highlightthickness=1, highlightbackground=T["border"])
        lb_wrap.pack(fill="x", pady=(1, 0))
        app_lb = tk.Listbox(lb_wrap, height=5, font=(FUI, 11),
                            bg=T["surface2"], fg=T["card_fg"],
                            selectbackground=T["accent"], selectforeground=T["button_fg"],
                            activestyle="none", relief="flat",
                            highlightthickness=0, exportselection=False)
        lb_sb = ttk.Scrollbar(lb_wrap, orient="vertical", command=app_lb.yview)
        app_lb.configure(yscrollcommand=lb_sb.set)
        app_lb.pack(side="left", fill="x", expand=True)
        lb_sb.pack(side="right", fill="y")

        hint_lbl = master._lbl(name_right,
                               text="Escribe para filtrar · selecciona para usar · o escribe un nombre nuevo",
                               size=12, bg=T["panel_bg"], fg=T["card_fg"])
        hint_lbl.pack(anchor="w", pady=(1, 0))

        _APP_NAME_PLACEHOLDER = "Teclea el nombre de tu Aplicacion aqui\u2026"
        _placeholder_active = [False]

        def _show_placeholder():
            _placeholder_active[0] = True
            search_entry.configure(foreground=T["muted"])
            search_var.set(_APP_NAME_PLACEHOLDER)

        def _hide_placeholder():
            if _placeholder_active[0]:
                _placeholder_active[0] = False
                search_entry.configure(foreground=T["text"])
                search_var.set("")

        search_entry.bind("<FocusIn>", lambda _e: _hide_placeholder())
        search_entry.bind("<FocusOut>",
            lambda _e: (None if search_var.get().strip() else _show_placeholder()))

        _stored_names = [a["name"] for a in self._store.list_apps() if a.get("name")]
        _all_names = sorted(
            set(_BANK_APPS) | set(_stored_names),
            key=lambda s: s.lower(),
        )

        def _populate_lb(filter_text=""):
            app_lb.delete(0, "end")
            ft = filter_text.strip().lower()
            for name in _all_names:
                if ft in name.lower():
                    app_lb.insert("end", name)

            cur = v_name.get().strip()
            for i in range(app_lb.size()):
                if app_lb.get(i) == cur:
                    app_lb.selection_set(i); app_lb.see(i); break

        _populate_lb()

        def _sync_name_from_entry(*_):
            """Called on every keystroke: filter the list AND keep v_name in sync."""
            if _placeholder_active[0]:
                return
            txt = search_var.get()
            v_name.set(txt.strip())
            _populate_lb(txt)

            for i in range(app_lb.size()):
                if app_lb.get(i).lower() == txt.strip().lower():
                    app_lb.selection_clear(0, "end")
                    app_lb.selection_set(i)
                    app_lb.see(i)
                    break
            else:

                app_lb.selection_clear(0, "end")

        def _on_lb_select(evt=None):
            sel = app_lb.curselection()
            if sel:
                chosen = app_lb.get(sel[0])

                _placeholder_active[0] = False
                search_entry.configure(foreground=T["text"])
                v_name.set(chosen)

                search_var.trace_remove("write", _search_trace_id[0])
                search_var.set(chosen)
                _search_trace_id[0] = search_var.trace_add("write", _sync_name_from_entry)

        _search_trace_id = [search_var.trace_add("write", _sync_name_from_entry)]
        app_lb.bind("<<ListboxSelect>>", _on_lb_select)
        app_lb.bind("<Double-1>", _on_lb_select)

        search_entry.bind("<Return>", lambda _: self.focus_set())

        if self._app.get("name"):
            search_var.set(self._app["name"])
            _populate_lb(self._app["name"])
        else:
            _show_placeholder()

        row(s1, "Descripción",          lambda p: entry(p, v_desc))
        row(s1, "Responsable / Equipo", lambda p: entry(p, v_owner))
        row(s1, "Correo del responsable", lambda p: entry(p, v_email))
        row(s1, "URL del repositorio",   lambda p: entry(p, v_repo))

        s2 = section("Clasificación")
        row(s2, "Tipo de Aplicación",   lambda p: combo(p, v_type,  _APP_TYPES))
        row(s2, "Stack Tecnológico",    lambda p: combo(p, v_stack, _TECH_STACKS))
        row(s2, "Entorno",              lambda p: combo(p, v_env,   _ENVIRONMENTS))
        row(s2, "Criticidad de Negocio", lambda p: combo(p, v_crit, _CRITICALITY_LEVELS))
        row(s2, "Clasificación de Datos", lambda p: combo(p, v_data, _DATA_CLASSIFICATION))

        def _save():

            name = "" if _placeholder_active[0] else (v_name.get().strip() or search_var.get().strip())
            if not name:
                try:
                    self._status_lbl.config(text="⚠  El Nombre de la Aplicación es obligatorio.")
                except Exception:
                    pass
                return
            a = dict(self._app)
            a["name"]         = name
            a["description"]  = v_desc.get().strip()
            a["owner"]        = v_owner.get().strip()
            a["owner_email"]  = v_email.get().strip()
            a["repo_url"]     = v_repo.get().strip()
            a["app_type"]     = v_type.get()
            a["tech_stack"]   = v_stack.get()
            a["environment"]  = v_env.get()
            a["criticality"]  = v_crit.get()
            a["data_class"]   = v_data.get()
            if not a.get("id"):
                a["id"] = _slugify(name)
            self._store.save_app(a)
            self.result = a
            _close()

        footer_bar, self._status_lbl = master._popup_foot(
            content,
            ("  Cancelar  ",      _close, "flat"),
            ("💾  Guardar Perfil", _save,  "accent"),
            with_status=True,
        )

        _toggle_row = tk.Frame(footer_bar, bg=T["panel_bg"])
        _toggle_row.pack(fill="x", pady=(2, 0), before=self._status_lbl)
        ToggleSwitch(_toggle_row, text="Cargar Aplicación",
                     variable=self.auto_load_var).pack(side="right")

        try: self.grab_set()
        except tk.TclError: pass
        self.focus_force()

class AppInventoryTab:

    def __init__(self, parent: tk.Frame, master: tk.Tk,
                 store: AppInventoryStore,
                 on_load_app=None):
        self._parent       = parent
        self._master       = master
        self._store        = store
        self._on_load_app  = on_load_app
        self._current_app: Optional[dict] = None
        self._build()

    def _build(self):
        FUI = _FUI

        toolbar = tk.Frame(self._parent, bg=T["bg"], padx=4, pady=2)
        toolbar.pack(fill="x")

        def _vsep():
            tk.Frame(toolbar, bg=T["border"], width=1).pack(
                side="left", fill="y", padx=2, pady=1)

        self._load_btn = self._master._icon_square_btn(toolbar, "📂", self._load_into_scanner)
        self._load_btn.pack(side="left", padx=(0, 2))

        self._new_btn = self._master._btn(toolbar, "+ Nueva", self._new_app, kind="accent")
        self._new_btn.pack(side="left", padx=(0, 2))
        self._edit_btn = self._master._btn(toolbar, "✏  Editar", self._edit_app, kind="accent")
        self._edit_btn.pack(side="left", padx=(0, 2))
        self._delete_btn = self._master._icon_square_btn(toolbar, "🗑", self._delete_app, danger=True)
        self._delete_btn.pack(side="left", padx=(0, 2))

        _vsep()
        self._build_dashboard(toolbar)
        _vsep()

        search_frame = tk.Frame(toolbar, bg=T["bg"])
        search_frame.pack(side="left", fill="x", expand=True)
        self._master._lbl(search_frame, text="🔎", size=10, bg=T["bg"], fg=T["muted"]).pack(side="left")

        SEARCH_PLACEHOLDER = "filtrar por nombre, tipo, entorno o nivel de riesgo"
        self._search_var = tk.StringVar(value=SEARCH_PLACEHOLDER)
        self._search_showing_placeholder = True
        search_entry = ttk.Entry(search_frame, textvariable=self._search_var,
                                  foreground=T["muted"])
        search_entry.pack(side="left", padx=(2, 0), fill="x", expand=True)

        def _clear_placeholder(_e=None):
            if self._search_showing_placeholder:
                self._search_showing_placeholder = False
                self._search_var.set("")
                search_entry.configure(foreground=T["text"])

        def _restore_placeholder(_e=None):
            if not self._search_var.get():
                self._search_showing_placeholder = True
                self._search_var.set(SEARCH_PLACEHOLDER)
                search_entry.configure(foreground=T["muted"])

        search_entry.bind("<FocusIn>", _clear_placeholder)
        search_entry.bind("<FocusOut>", _restore_placeholder)
        self._search_var.trace_add("write", lambda *_: self.refresh())

        split = tk.Frame(self._parent, bg=T["bg"])
        split.pack(fill="both", expand=True, padx=4, pady=(0, 3))

        # The fixed-width Detalles panel is packed FIRST so it always reserves its own
        # slice of the split — packing it after the expanding Treeview meant that on a
        # narrow/small-monitor window the Treeview's fill+expand could claim the whole
        # cavity and leave nothing for this panel to render into.
        right_shadow = self._master._shadow_wrap(split, visible=False)
        right_shadow.pack(side="right", fill="y", padx=(_CARD_GAP // 2, 0))
        right = tk.Frame(right_shadow, bg=T["panel_bg"],
                         highlightthickness=0, highlightbackground=T["border"])
        right.pack(fill="both", expand=True, padx=(0, 0), pady=(0, 0))
        right.configure(width=300)
        right.pack_propagate(False)

        left_shadow = self._master._shadow_wrap(split, visible=False)
        left_shadow.pack(side="left", fill="both", expand=True)
        left = tk.Frame(left_shadow, bg=T["panel_bg"],
                        highlightthickness=0, highlightbackground=T["border"])
        left.pack(fill="both", expand=True, padx=(0, _CARD_SHADOW_OFFSET), pady=(0, _CARD_SHADOW_OFFSET))

        tree_hdr = tk.Frame(left, bg=T["surface3"], padx=3, pady=1)
        tree_hdr.pack(fill="x")
        tk.Label(tree_hdr, text="Aplicaciones", font=(_FUI_TITLE, 14, "bold"),
                 bg=T["surface3"], fg=T["card_fg"]).pack(side="left")

        cols = ("name","type","env","crit","vulns","risk","last_scan")
        tree_outer = tk.Frame(left, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["accent"])
        tree_outer.pack(fill="both", expand=True)
        self._tree = ttk.Treeview(tree_outer, columns=cols,
                                  show="headings", height=22)
        headings = [
            ("name",      "Aplicación",        200),
            ("type",      "Tipo",              120),
            ("env",       "Entorno",            90),
            ("crit",      "Criticidad",        110),
            ("vulns",     "🐛 C / A / M / B",  140),
            ("risk",      "Nivel de Riesgo",    90),
            ("last_scan", "Último Escaneo",    130),
        ]
        for col, txt, width in headings:
            self._tree.heading(col, text=txt,
                               command=lambda c=col: self._sort_by(c))
            self._tree.column(col, width=width, anchor="w")

        vsb = ttk.Scrollbar(tree_outer, orient="vertical", command=self._tree.yview)
        self._tree.configure(yscrollcommand=vsb.set)
        self._tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        self._tree.bind("<<TreeviewSelect>>", self._on_select)
        self._tree.bind("<Double-1>", lambda _: self._edit_app())

        detail_hdr = tk.Frame(right, bg=T["surface3"], padx=3, pady=1)
        detail_hdr.pack(fill="x")
        tk.Label(detail_hdr, text="Detalles", font=(_FUI_TITLE, 14, "bold"),
                 bg=T["surface3"], fg=T["card_fg"]).pack(side="left")

        self._detail_canvas = tk.Canvas(right, bg=T["panel_bg"],
                                        highlightthickness=0, bd=0)
        detail_vsb = ttk.Scrollbar(right, orient="vertical",
                                   command=self._detail_canvas.yview)
        self._detail_canvas.configure(yscrollcommand=detail_vsb.set)
        self._detail_canvas.pack(side="left", fill="both", expand=True)
        detail_vsb.pack(side="right", fill="y")
        self._detail_frame = tk.Frame(self._detail_canvas, bg=T["panel_bg"])
        self._detail_win   = self._detail_canvas.create_window(
            (0, 0), window=self._detail_frame, anchor="nw")
        self._detail_frame.bind(
            "<Configure>",
            lambda _: self._detail_canvas.configure(
                scrollregion=self._detail_canvas.bbox("all")))
        self._detail_canvas.bind(
            "<Configure>",
            lambda e: self._detail_canvas.itemconfigure(
                self._detail_win, width=e.width))

        self._show_detail(None)
        self.refresh()

    def _build_dashboard(self, parent):
        """One-row strip of portfolio-wide tiles: total apps, aggregate findings by severity across every app's last scan…"""
        FUI = _FUI
        self._dash_tiles: dict[str, dict] = {}
        specs = [
            ("apps",     "Apps registradas",  T["text"]),
            ("critical", "🔴 Crítico",         _RISK_COLORS_LIGHT["Crítico"]),
            ("high",     "🟠 Alto",            _RISK_COLORS_LIGHT["Alto"]),
            ("medium",   "🟡 Medio",           _RISK_COLORS_LIGHT["Medio"]),
            ("low",      "🟢 Bajo",            _RISK_COLORS_LIGHT["Bajo"]),
            ("stale",    "⏰ Sin escaneo 30d+", T["muted"]),
        ]

        for key, label, colour in specs:
            tile = tk.Frame(parent, bg=T["panel_bg"], highlightthickness=1,
                            highlightbackground=T["border"], padx=2, pady=1)
            tile.pack(side="left", fill="y", padx=(0, 2))
            content = tk.Frame(tile, bg=T["panel_bg"])
            content.pack(expand=True, fill="x")
            top = tk.Frame(content, bg=colour, height=2); top.pack(fill="x", pady=(0, 1))
            row = tk.Frame(content, bg=T["panel_bg"]); row.pack(anchor="w")
            val_lbl = self._master._lbl(row, text="—", size=10, bold=True, bg=T["panel_bg"], fg=colour)
            val_lbl.pack(side="left")
            self._master._lbl(row, text=label, size=10, bg=T["panel_bg"], fg=T["muted"]).pack(side="left", padx=(1, 0))
            self._dash_tiles[key] = {"value": val_lbl, "frame": tile, "colour": colour}

    def _refresh_dashboard(self):
        if not hasattr(self, "_dash_tiles"):
            return
        apps = self._store.list_apps()
        agg = {"apps": len(apps), "critical": 0, "high": 0, "medium": 0, "low": 0, "stale": 0}
        cutoff = datetime.now() - timedelta(days=30)
        for app in apps:
            agg["critical"] += int(app.get("vuln_critical", 0) or 0)
            agg["high"]     += int(app.get("vuln_high", 0) or 0)
            agg["medium"]   += int(app.get("vuln_medium", 0) or 0)
            agg["low"]      += int(app.get("vuln_low", 0) or 0)
            last = app.get("last_scan")
            is_stale = True
            if last:
                try:
                    ts = datetime.fromisoformat(str(last)[:19])
                    is_stale = ts < cutoff
                except Exception:
                    is_stale = False
            if is_stale:
                agg["stale"] += 1
        for key, tile in self._dash_tiles.items():
            tile["value"].config(text=str(agg.get(key, 0)))

    def refresh(self):
        self._refresh_dashboard()
        dark = getattr(self._master, "_dark_mode", False)
        risk_colors = _RISK_COLORS_DARK if dark else _RISK_COLORS_LIGHT
        FUI = _FUI
        for tier, colour in risk_colors.items():
            self._tree.tag_configure(
                tier.lower(), foreground=colour,
                font=(FUI, 9, "bold") if tier in ("Crítico", "Alto") else (FUI, 9))
        for iid in self._tree.get_children():
            self._tree.delete(iid)
        apps = self._store.list_apps()
        if getattr(self, "_search_showing_placeholder", False):
            needle = ""
        else:
            needle = (getattr(self, "_search_var", None) and self._search_var.get() or "").strip().lower()
        if needle:
            apps = [a for a in apps if needle in " ".join(str(a.get(k, "")) for k in
                    ("name", "app_type", "environment", "risk_tier", "criticality")).lower()]
        for app in apps:
            vulns = (f"{app.get('vuln_critical',0)} / "
                     f"{app.get('vuln_high',0)} / "
                     f"{app.get('vuln_medium',0)} / "
                     f"{app.get('vuln_low',0)}")
            last  = app.get("last_scan") or "—"
            tier  = app.get("risk_tier", "Ninguno")
            self._tree.insert(
                "", "end", iid=app["id"],
                values=(
                    app.get("name",""),
                    app.get("app_type",""),
                    app.get("environment",""),
                    app.get("criticality",""),
                    vulns,
                    tier,
                    last[:16] if last != "—" else "—",
                ),
                tags=(tier.lower(),),
            )

        if self._current_app:
            aid = self._current_app.get("id","")
            if self._tree.exists(aid):
                self._tree.selection_set(aid)
                self._tree.see(aid)

    def _sort_by(self, col: str):
        """Toggle-sort treeview by column."""
        items = [(self._tree.set(iid, col), iid)
                 for iid in self._tree.get_children()]
        rev = getattr(self, f"_sort_rev_{col}", False)
        items.sort(reverse=rev,
                   key=lambda x: x[0].lower() if x[0] else "")
        for idx, (_, iid) in enumerate(items):
            self._tree.move(iid, "", idx)
        setattr(self, f"_sort_rev_{col}", not rev)

    def _show_detail(self, app: Optional[dict]):
        FUI = _FUI
        self._detail_canvas.configure(bg=T["panel_bg"])
        self._detail_frame.configure(bg=T["panel_bg"])
        for w in self._detail_frame.winfo_children():
            w.destroy()

        if app is None:
            self._master._lbl(self._detail_frame,
                     text="Selecciona una app\nde la lista.",
                     size=12, bg=T["panel_bg"],
                     fg=T["card_fg"], justify="center").pack(
                expand=True, pady=10)
            return

        pad = tk.Frame(self._detail_frame, bg=T["panel_bg"], padx=4, pady=3)
        pad.pack(fill="both", expand=True)
        pad.columnconfigure(1, weight=1)

        _row = [0]
        _value_lbls: list = []
        _full_lbls: list = []

        def kv(label: str, value: str, bold: bool = False, color=None):
            r = _row[0]; _row[0] += 1
            self._master._lbl(pad, text=label, size=12, bold=True,
                     bg=T["panel_bg"], fg=T["card_fg"],
                     anchor="nw", justify="left").grid(
                row=r, column=0, sticky="nw", padx=(0, 6), pady=1)
            vlbl = self._master._lbl(pad, text=value or "—",
                     size=12, bold=bold,
                     bg=T["panel_bg"],
                     fg=color or T["card_fg"],
                     anchor="w", justify="left")
            vlbl.grid(row=r, column=1, sticky="ew", pady=1)
            _value_lbls.append(vlbl)

        def sep():
            r = _row[0]; _row[0] += 1
            tk.Frame(pad, bg=T["border"], height=1).grid(
                row=r, column=0, columnspan=2, sticky="ew", pady=2)

        def full_row(sticky="ew"):
            """A sub-frame spanning both grid columns — for widgets (badges, headers, trend
            chart) that don't fit the label/value column pair but still need to sit inside
            pad's single grid geometry manager."""
            r = _row[0]; _row[0] += 1
            w = tk.Frame(pad, bg=T["panel_bg"])
            w.grid(row=r, column=0, columnspan=2, sticky=sticky, pady=1)
            return w

        tier  = app.get("risk_tier", "Ninguno")
        tc    = (_RISK_COLORS_DARK if getattr(self._master, "_dark_mode", False) else _RISK_COLORS_LIGHT).get(tier, T["muted"])
        kv("Nombre",       app.get("name",""),       bold=True)
        kv("Nivel de Riesgo", tier,                  bold=True, color=tc)
        kv("Tipo",         app.get("app_type",""))
        kv("Stack",        app.get("tech_stack",""))
        kv("Entorno",      app.get("environment",""))
        kv("Criticidad",   app.get("criticality",""))
        kv("Clasif. Datos", app.get("data_class",""))

        sep()

        c = app.get("vuln_critical",0)
        h = app.get("vuln_high",0)
        m = app.get("vuln_medium",0)
        lo = app.get("vuln_low",0)
        tot = app.get("vuln_total", c+h+m+lo)

        badge_row = full_row()
        for count, label, bg_hex in [
            (c,  "Crítico", "#7a0c1c"),
            (h,  "Alto",     "#8b3a0a"),
            (m,  "Medio",   "#7a5e00"),
            (lo, "Bajo",      "#0c4a2b"),
        ]:
            badge = tk.Frame(badge_row, bg=bg_hex,
                             padx=2, pady=1)
            badge.pack(side="left", padx=(0, 1))
            self._master._lbl(badge, text=str(count), size=12, bold=True,
                     bg=bg_hex, fg="#ffffff").pack()
            self._master._lbl(badge, text=label, size=12,
                     bg=bg_hex, fg="#cccccc").pack()

        kv("Total Vulns",   str(tot))
        kv("Secretos",      str(app.get("secrets_total",0)))
        kv("Último Escaneo", (app.get("last_scan") or "—")[:16])
        kv("Modo",          app.get("last_mode","—"))

        sep()

        kv("Responsable",      app.get("owner",""))
        kv("Email",      app.get("owner_email",""))
        kv("Objetivo",     app.get("target_path","")[-40:] if app.get("target_path") else "—")
        kv("URL para DAST",   app.get("dast_url",""))

        comp = app.get("compliance",[])
        if comp:
            sep()
            comp_wrap = full_row()
            self._master._lbl(comp_wrap, text="COMPLIANCE",
                     size=12, bold=True, bg=T["panel_bg"],
                     fg=T["card_fg"], anchor="w").pack(fill="x")
            comp_lbl = self._master._lbl(comp_wrap, text=", ".join(comp),
                     size=12, bg=T["panel_bg"],
                     fg=T["card_fg"], anchor="w",
                     justify="left")
            comp_lbl.pack(fill="x")
            _full_lbls.append(comp_lbl)

        notes = app.get("notes","")
        if notes:
            sep()
            notes_wrap = full_row()
            self._master._lbl(notes_wrap, text="NOTAS",
                     size=12, bold=True, bg=T["panel_bg"],
                     fg=T["card_fg"], anchor="w").pack(fill="x")
            notes_lbl = self._master._lbl(notes_wrap, text=notes,
                     size=12, bg=T["panel_bg"],
                     fg=T["card_fg"], anchor="w",
                     justify="left")
            notes_lbl.pack(fill="x")
            _full_lbls.append(notes_lbl)

        def _rewrap(_evt=None):
            pad.update_idletasks()
            bbox0 = pad.grid_bbox(column=0)
            label_w = bbox0[2] if bbox0 else 0
            avail = max(pad.winfo_width() - label_w - 14, 60)
            full_avail = max(pad.winfo_width() - 8, 60)
            for vlbl in _value_lbls:
                try: vlbl.configure(wraplength=avail)
                except Exception: pass
            for flbl in _full_lbls:
                try: flbl.configure(wraplength=full_avail)
                except Exception: pass

        pad.bind("<Configure>", _rewrap)
        pad.after(0, _rewrap)

        history = app.get("scan_history", [])
        if len(history) >= 2:
            trend_wrap = full_row()
            self._draw_trend(trend_wrap, history, T, FUI)

    def _draw_trend(self, parent, history: list, T: dict, FUI: str):
        """Draw a tiny SVG-style canvas trend chart of the last N scans."""
        tk.Frame(parent, bg=T["border"], height=1).pack(fill="x", pady=2)
        self._master._lbl(parent, text="TENDENCIA DE VULNERABILIDADES (últimos escaneos)",
                 size=12, bold=True, bg=T["panel_bg"],
                 fg=T["card_fg"], anchor="w").pack(fill="x")

        W, H = 260, 90
        cv = tk.Canvas(parent, width=W, height=H,
                       bg=T["surface2"], bd=0, highlightthickness=0)
        cv.pack(pady=(1, 0))

        entries = history[-10:]
        n = len(entries)
        max_v  = max((e.get("total", 0) or 0) for e in entries) or 1
        xs = [int(12 + (i / max(n-1, 1)) * (W - 24)) for i in range(n)]

        def y_for(v): return int(H - 8 - (v / max_v) * (H - 20))

        for pct in (0.25, 0.5, 0.75, 1.0):
            yy = y_for(int(max_v * pct))
            cv.create_line(4, yy, W-4, yy, fill=T["border"], dash=(2, 4))

        for key, colour in [
            ("critical", "#c8102e"), ("high", "#e26020"),
            ("medium",   "#d4a017"), ("total",  T["muted"]),
        ]:
            pts = []
            for i, e in enumerate(entries):
                pts += [xs[i], y_for(e.get(key, e.get("total", 0) or 0))]
            if len(pts) >= 4:
                cv.create_line(pts, fill=colour, width=2, smooth=True)

        if entries:
            last = entries[-1]
            for key, colour in [
                ("critical","#c8102e"), ("high","#e26020"),
                ("medium","#d4a017"),
            ]:
                v = last.get(key, 0) or 0
                if v:
                    yy = y_for(v)
                    cv.create_oval(xs[-1]-4, yy-4, xs[-1]+4, yy+4,
                                   fill=colour, outline="")

        if entries:
            cv.create_text(xs[0], H-2, text=entries[0].get("ts","")[:10],
                           font=(FUI, 9), fill=T["muted"], anchor="s")
            cv.create_text(xs[-1], H-2, text=entries[-1].get("ts","")[:10],
                           font=(FUI, 9), fill=T["muted"], anchor="s")

    def _on_select(self, _event=None):
        sel = self._tree.selection()
        if sel:
            app = self._store.get_app(sel[0])
            self._show_detail(app)
        else:
            self._show_detail(None)

    def _selected_app(self) -> Optional[dict]:
        sel = self._tree.selection()
        return self._store.get_app(sel[0]) if sel else None

    def _new_app(self):
        ed = AppProfileEditor(self._master, self._store)
        self._master.wait_window(ed)
        if ed.result:
            self.refresh()
            self._tree.selection_set(ed.result["id"])
            self._show_detail(ed.result)
            if ed.auto_load_var.get():
                self._current_app = ed.result
                self._update_title_label(ed.result)
                if self._on_load_app:
                    self._on_load_app(ed.result)

    def _edit_app(self):
        app = self._selected_app()
        if not app:
            return
        ed = AppProfileEditor(self._master, self._store, app)
        self._master.wait_window(ed)
        if ed.result:
            self.refresh()
            self._show_detail(ed.result)
            if ed.auto_load_var.get():
                self._current_app = ed.result
                self._update_title_label(ed.result)
                if self._on_load_app:
                    self._on_load_app(ed.result)

    def _delete_app(self):
        app = self._selected_app()
        if not app:
            return
        def _do_delete():
            self._store.delete_app(app["id"])
            if self._current_app and self._current_app.get("id") == app["id"]:
                self._current_app = None
                self._update_title_label(None)
            self.refresh()
            self._show_detail(None)
        self._master._show_confirm_popup(
            "Eliminar aplicación",
            f"¿Eliminar '{app['name']}'?\nEsta acción no se puede deshacer.",
            on_yes=_do_delete,
            yes_label="  🗑  Eliminar  ",
            no_label="  Cancelar  ",
        )

    def _load_into_scanner(self):
        app = self._selected_app()
        if not app:
            return
        self._current_app = app
        self._update_title_label(app)
        if self._on_load_app:
            self._on_load_app(app)

    def _update_title_label(self, app: "Optional[dict]") -> None:
        """No-op: the redundant active-app banner was removed — the loaded app already shows at all times in the top-of-…"""
        return

    def apply_theme(self) -> None:
        """Rebuild the tab UI in-place with the current palette."""

        sel = self._tree.selection()
        selected_id  = sel[0] if sel else None
        active_app   = self._current_app

        for child in list(self._parent.winfo_children()):
            try:
                child.destroy()
            except Exception:
                pass

        self._build()

        if selected_id and self._tree.exists(selected_id):
            self._tree.selection_set(selected_id)
            self._tree.see(selected_id)
            app = self._store.get_app(selected_id)
            self._show_detail(app)

        if active_app:
            self._current_app = active_app
            self._update_title_label(active_app)

class _AppsTabMixin:
    def _build_tab_apps(self, parent):
        self._inv_tab = AppInventoryTab(parent=parent, master=self, store=self._inv_store,
                                        on_load_app=self._load_app_profile)

    def _load_app_profile(self, app: dict, *, silent: bool = False) -> None:
        self._active_app = app
        if app.get("target_path"): self._target_var.set(app["target_path"])
        if app.get("dast_url"): self._dast_url_var.set(app["dast_url"])
        if app.get("api_spec"): self._api_spec_var.set(app["api_spec"])
        for k, var in self._scan_vars.items():
            var.set(k in app.get("scan_stages", _NO_APP_DEFAULT_STAGES))
        if hasattr(self, "_static_paths_lb"):
            self._static_paths_lb.delete(0, "end")
            for p in app.get("static_paths") or ([app["target_path"]] if app.get("target_path") else []):
                self._static_paths_lb.insert("end", p)
        self._refresh_stage_cards()
        self._refresh_scan_btn()
        app_id = app.get("id")
        if app_id:

            open_ids = list(getattr(self, "_open_app_tabs", []) or [])
            if app_id not in open_ids:
                open_ids.append(app_id)
            self._open_app_tabs = open_ids
        self._refresh_active_app_banner()
        self._update_window_title()
        self._last_app_id = app_id
        self._save_settings()

        inv_tab = getattr(self, "_inv_tab", None)
        if inv_tab is not None:
            try: inv_tab.refresh()
            except Exception: pass
        if silent:
            return
        self._show_tab("scan")
        self._show_info_popup("Perfil de aplicación cargado",
            f"Nombre: {app['name']}\n"
            f"Descripción: {app.get('description') or '(no configurado)'}\n"
            f"Tipo: {app.get('app_type') or '(no configurado)'}\n"
            f"Criticidad de negocio: {app.get('criticality') or '(no configurado)'}\n"
            f"URL: {app.get('dast_url') or '(no configurado)'}")

    def _switch_app_tab(self, app_id: str) -> None:
        """Called by clicking a header app tab."""
        current = getattr(self, "_active_app", None)
        if current and current.get("id") == app_id:
            return
        if self._any_busy():
            self._show_warn_popup("Cambiar de aplicación",
                "No se puede cambiar de aplicación mientras hay un escaneo en curso.\n\n"
                "Espere a que termine o deténgalo antes de cambiar de pestaña.")
            return
        try:
            app = self._inv_store.get_app(app_id)
        except Exception:
            app = None
        if not app:

            self._open_app_tabs = [a for a in getattr(self, "_open_app_tabs", []) if a != app_id]
            self._rebuild_app_tabs()
            return
        self._load_app_profile(app, silent=True)

    def _close_app_tab(self, app_id: str) -> None:
        """Removes an app from the header tab strip WITHOUT touching the underlying profile (that's what deleting it in 📦…"""
        if self._any_busy():
            self._show_warn_popup("Cerrar pestaña",
                "No se puede cerrar una pestaña de aplicación mientras hay un escaneo en curso.")
            return
        self._open_app_tabs = [a for a in getattr(self, "_open_app_tabs", []) if a != app_id]
        active = getattr(self, "_active_app", None)
        if active and active.get("id") == app_id:
            fallback = None
            if self._open_app_tabs:
                try: fallback = self._inv_store.get_app(self._open_app_tabs[-1])
                except Exception: fallback = None
            if fallback:
                self._load_app_profile(fallback, silent=True)
                return
            self._active_app = None
            self._last_app_id = None
            self._update_window_title()

            self._apply_no_app_default_stages()
            self._refresh_stage_cards()
            self._refresh_scan_btn()
        self._save_settings()
        self._rebuild_app_tabs()

    def _update_window_title(self) -> None:
        app = getattr(self, "_active_app", None)
        name = app.get("name") if app else None
        self.title(f"{APP_BRAND_NAME} - ({name})" if name else APP_BRAND_NAME)

    def _auto_load_last_app(self) -> None:

        restored = []
        for app_id in getattr(self, "_saved_open_app_ids", None) or []:
            try:
                if self._inv_store.get_app(app_id):
                    restored.append(app_id)
            except Exception:
                pass
        self._open_app_tabs = restored

        app_id = getattr(self, "_last_app_id", None)
        if not app_id:
            self._update_window_title(); self._rebuild_app_tabs(); return
        try:
            app = self._inv_store.get_app(app_id)
        except Exception:
            app = None
        if app:
            self._load_app_profile(app, silent=True)
            self._log_line(f"[apps] perfil recargado automáticamente: {app.get('name')}")
        else:
            self._update_window_title()

            self._apply_no_app_default_stages()
            self._refresh_stage_cards()
            self._refresh_scan_btn()
            self._rebuild_app_tabs()

    def _counts_for(self, app: dict) -> tuple[int, int, int, int]:
        """crit/high/med/low for `app`, preferring the live scan context (self._last_context) over the stale counts store…"""
        ctx = getattr(self, "_last_context", None)
        c = ctx.get("counts", {}) if ctx else {}
        return (c.get("critical", app.get("vuln_critical", 0)),
                c.get("high", app.get("vuln_high", 0)),
                c.get("medium", app.get("vuln_medium", 0)),
                c.get("low", app.get("vuln_low", 0)))

    def _refresh_active_app_banner(self) -> None:
        """Kept under its original name since callers elsewhere just want 'make the header reflect the current active/ope…"""
        self._rebuild_app_tabs()

    def _rebuild_app_tabs(self) -> None:
        """(Re)builds the header's app-tab strip from _open_app_tabs."""
        container = getattr(self, "_app_tabs_container", None)
        if container is None:
            return
        for w in container.winfo_children():
            w.destroy()
        self._app_tab_widgets = {}
        self._app_tab_pct_widgets = {}

        open_ids = list(getattr(self, "_open_app_tabs", []) or [])
        active = getattr(self, "_active_app", None)
        active_id = active.get("id") if active else None

        if not open_ids:
            chip = tk.Frame(container, bg=T["bg"],
                            highlightthickness=1, highlightbackground=T["border"],
                            cursor="hand2")
            chip.pack(side="left")
            lbl = self._lbl(chip, text="Sin aplicación — haga clic para seleccionar",
                          size=10, bold=True, bg=T["bg"], fg=T["muted"],
                          cursor="hand2")
            lbl.pack(side="left", padx=2, pady=2)
            for w in (chip, lbl):
                w.bind("<Button-1>", lambda e: self._show_tab("apps"))
            return

        for app_id in open_ids:
            try:
                app = self._inv_store.get_app(app_id)
            except Exception:
                app = None
            if not app:

                self._open_app_tabs = [a for a in self._open_app_tabs if a != app_id]
                continue
            is_active = (app_id == active_id)
            bg = T["bg"] if is_active else T["bg"]
            border = T["accent"] if is_active else T["border"]
            tab = tk.Frame(container, bg=bg, highlightthickness=1,
                           highlightbackground=border, cursor="hand2")
            tab.pack(side="left", padx=(0, 1))
            clickable = [tab]
            if is_active:

                pct_lbl = self._lbl(tab, text="", size=10, bold=True,
                                    bg=bg, fg=T["accent"], cursor="hand2")
                pct_lbl.pack(side="left", padx=(2, 0), pady=2)
                clickable.append(pct_lbl)
                self._app_tab_pct_widgets[app_id] = pct_lbl
            name_lbl = tk.Label(tab, text=app.get("name", "?"), font=(_FUI_TITLE, 10, "bold"),
                                bg=bg, fg=T["accent"] if is_active else T["muted"],
                                cursor="hand2")
            name_lbl.pack(side="left", padx=(2, 1), pady=2)
            clickable.append(name_lbl)
            if is_active:

                crit, high, med, low = self._counts_for(app)
                counts_lbl = self._lbl(tab, text=f"  C:{crit}  A:{high}  M:{med}  B:{low}",
                                      size=10, bg=bg,
                                      fg=T["muted"] if (crit == 0 and high == 0) else T["accent"],
                                      cursor="hand2")
                counts_lbl.pack(side="left", padx=(0, 1), pady=2)
                clickable.append(counts_lbl)
            close_lbl = self._lbl(tab, text="✕", size=10, bg=bg, fg=T["muted"], cursor="hand2")
            close_lbl.pack(side="left", padx=(1, 2), pady=2)
            close_lbl.bind("<Button-1>", lambda e, aid=app_id: self._close_app_tab(aid))
            for w in clickable:
                w.bind("<Button-1>", lambda e, aid=app_id: self._switch_app_tab(aid))
            self._app_tab_widgets[app_id] = tab

        self._update_app_tab_progress(getattr(self, "_pipe_progress_pct", 0.0))

    def _update_app_tab_progress(self, pct: float) -> None:
        """Keeps the open-app tab strip's percent indicator (left of the active app's name) in sync with the current scan…"""
        widgets = getattr(self, "_app_tab_pct_widgets", None)
        if not widgets:
            return
        active = getattr(self, "_active_app", None)
        active_id = active.get("id") if active else None
        busy = bool(getattr(self, "_busy", False) or getattr(self, "_static_busy", False))
        for app_id, lbl in widgets.items():
            try:
                if busy and app_id == active_id:
                    lbl.configure(text=f"{int(round(max(0.0, min(1.0, pct)) * 100))}%")
                    lbl.pack_configure(padx=(2, 0))
                else:
                    lbl.configure(text="")
                    lbl.pack_configure(padx=(0, 0))
            except Exception:
                pass
