"""secrets_scanner.py — standalone hard-coded-secrets detection engine."""

from __future__ import annotations

import hashlib, json, math, os, re, shutil, subprocess, sys, tempfile, time
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Optional

IS_WIN   = os.name == "nt"
IS_MAC   = sys.platform == "darwin"
IS_LINUX = not IS_WIN and not IS_MAC

_NOWIN = {"creationflags": subprocess.CREATE_NO_WINDOW} if IS_WIN else {}

SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}

def _log(cb: Optional[Callable[[str], None]], msg: str) -> None:
    if cb:
        try: cb(msg)
        except Exception: pass

def _download_file(url: str, dest: Path, log: Callable[[str], None],
                   timeout: int = 120) -> bool:
    import ssl, urllib.error, urllib.request
    req = urllib.request.Request(url, headers={"User-Agent": "vuln-scanner/1.0"})
    try:
        log(f"[download] {url}")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = resp.read()
        except urllib.error.URLError as e:
            if isinstance(e.reason, ssl.SSLCertVerificationError):
                log(f"[download] TLS verify failed ({e.reason}); "
                    f"retrying without cert verification (fixed host only)…")
                ctx = ssl._create_unverified_context()
                with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
                    data = resp.read()
            else:
                raise
        if not data:
            log("[download] empty response"); return False
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        log(f"[download] saved {len(data)//1024} KB → {dest}")
        return True
    except Exception as e:
        log(f"[download] failed: {e!r}")
        return False

GIT_SECRETS_RAW_URL = (
    "https://raw.githubusercontent.com/awslabs/git-secrets/master/git-secrets"
)

_GIT_SECRETS_STATUS: dict = {}

def get_git_secrets_status() -> dict:
    """Return the cached git-secrets bootstrap status (set by ensure_git_secrets)."""
    return _GIT_SECRETS_STATUS

def get_engine_label(status: "Optional[dict]" = None) -> "tuple[str, str]":
    """Return (label_text, color_key) for the current engine status."""
    st = status if status is not None else _GIT_SECRETS_STATUS
    n_builtin = len(_PROVIDERS)
    if st.get("method") == "git-secrets" and st.get("available"):
        return (f"git-secrets ready ({st.get('note', '')}) + {n_builtin} built-in "
                f"patterns + entropy fallback", "ok")
    return (f"Built-in engine: {n_builtin} patterns + entropy fallback "
            f"(git-secrets download unavailable)", "muted")

def _cache_dir() -> Path:
    base = Path(os.environ.get("LOCALAPPDATA") or
                os.environ.get("XDG_CACHE_HOME") or
                (Path.home() / ".cache"))
    d = base / "vuln-scanner" / "git-secrets"
    try:
        d.mkdir(parents=True, exist_ok=True)
    except Exception:
        d = Path(tempfile.gettempdir()) / "vuln-scanner-git-secrets"
        d.mkdir(parents=True, exist_ok=True)
    return d

def ensure_git_secrets(log: Optional[Callable[[str], None]] = None) -> dict:
    """Best-effort download of the real git-secrets script into the cache."""
    global _GIT_SECRETS_STATUS
    status: dict[str, Any] = {
        "available": False, "method": "builtin", "path": None,
        "has_git": bool(shutil.which("git")),
        "has_bash": bool(shutil.which("bash")) or IS_MAC or IS_LINUX,
        "note": "",
    }
    target = _cache_dir() / "git-secrets"

    if target.exists() and target.stat().st_size > 1000:

        if not IS_WIN:
            try: os.chmod(target, 0o755)
            except Exception: pass
        status.update(available=True, method="git-secrets", path=str(target),
                      note="cached")
        _log(log, f"[secrets] git-secrets ready (cached): {target}")
        _GIT_SECRETS_STATUS = status
        return status

    _log(log, "[secrets] downloading git-secrets from GitHub…")
    if _download_file(GIT_SECRETS_RAW_URL, target, log, timeout=25) and target.stat().st_size > 1000:
        if not IS_WIN:
            try: os.chmod(target, 0o755)
            except Exception: pass
        status.update(available=True, method="git-secrets", path=str(target), note="downloaded")
        _log(log, f"[secrets] git-secrets downloaded → {target} "
                  f"({target.stat().st_size // 1024} KB)")
    else:
        if target.exists():
            try: target.unlink()
            except Exception: pass
        status["note"] = "download failed — using built-in engine"
        _log(log, "[secrets] git-secrets download failed; built-in engine will be used.")
    _GIT_SECRETS_STATUS = status
    return status

_GIT_SECRETS_CUSTOM_PATTERNS = [
    r"-----BEGIN (RSA |EC |DSA |OPENSSH |PGP |ENCRYPTED )?PRIVATE KEY-----",
    r"AIza[0-9A-Za-z_-]{35}",
    r"gh[pousr]_[0-9A-Za-z]{36,255}",
    r"github_pat_[0-9A-Za-z_]{22,255}",
    r"glpat-[0-9A-Za-z_-]{20}",
    r"xox[baoprs]-[0-9A-Za-z-]{10,48}",
    r"(sk|rk)_(live|prod)_[0-9a-zA-Z]{20,}",
    r"AKIA[0-9A-Z]{16}",

    r"sk-ant-(api03|admin01)-[A-Za-z0-9_-]{93}AA",
    r"sk-[A-Za-z0-9_-]{20,74}T3BlbkFJ[A-Za-z0-9_-]{20,74}",
    r"hf_[A-Za-z]{34}",
    r"AGE-SECRET-KEY-1[0-9A-Za-z]{58}",
]

def _run_git_secrets(script: Path, target: Path,
                     log: Optional[Callable[[str], None]] = None) -> list[dict]:
    """Run the downloaded git-secrets against a git repo — both the current working tree AND, when possible, the full…"""
    if not (target / ".git").exists():
        return []
    git = shutil.which("git")
    if not git:
        return []
    bash = shutil.which("bash")
    if IS_WIN and not bash:

        _log(log, "[secrets] git-secrets needs Git Bash on Windows — "
                  "none found; skipping the git-secrets bonus layer.")
        return []
    findings: list[dict] = []
    try:
        env = os.environ.copy()
        tmp_cfg = _cache_dir() / "gs_global.gitconfig"
        env["GIT_CONFIG_GLOBAL"] = str(tmp_cfg)
        env["GIT_CONFIG_NOSYSTEM"] = "1"
        runner = [bash, str(script)] if bash else [str(script)]

        subprocess.run(runner + ["--register-aws", "--global"],
                       cwd=str(target), env=env, timeout=60,
                       capture_output=True, text=True, **_NOWIN)

        for pat in _GIT_SECRETS_CUSTOM_PATTERNS:
            try:
                subprocess.run(runner + ["--add", pat],
                               cwd=str(target), env=env, timeout=30,
                               capture_output=True, text=True, **_NOWIN)
            except Exception:
                pass

        def _parse_hits(out: str, *, history: bool) -> None:
            for line in out.splitlines():
                m = re.match(r"^(.*?):(\d+):(.*)$", line) if not history else\
                    re.match(r"^([0-9a-fA-F]{7,40}):(.*?):(\d+):(.*)$", line)
                if not m:
                    continue
                if history:
                    commit, fp, ln, txt = m.group(1), m.group(2), int(m.group(3)), m.group(4)
                else:
                    fp, ln, txt = m.group(1), int(m.group(2)), m.group(3)
                    commit = None

                fp = fp[2:] if fp.startswith("./") else fp
                fp = fp.replace("\\", "/")
                if "Possible mistakes" in txt or not txt.strip():
                    continue
                sev = "low" if _looks_like_example(txt) else "critical"
                entry = {
                    "file": fp, "line": ln, "severity": sev,
                    "rule": "git-secrets/history" if history else "git-secrets/registered",
                    "title": "Secret in commit history (git-secrets)" if history
                             else "Credential matched by git-secrets",
                    "secret_type": "Historical credential" if history else "git-secrets match",
                    "match": redact(txt.strip()),
                    "engine": "git-secrets/history" if history else "git-secrets",
                }
                if commit:
                    entry["commit"] = commit
                findings.append(entry)

        proc = subprocess.run(runner + ["--scan", "-r", "."],
                              cwd=str(target), env=env, timeout=300,
                              capture_output=True, text=True, **_NOWIN)
        _parse_hits((proc.stderr or "") + "\n" + (proc.stdout or ""), history=False)

        try:
            hproc = subprocess.run(runner + ["--scan-history"],
                                   cwd=str(target), env=env, timeout=240,
                                   capture_output=True, text=True, **_NOWIN)
            _parse_hits((hproc.stderr or "") + "\n" + (hproc.stdout or ""), history=True)
        except subprocess.TimeoutExpired:
            _log(log, "[secrets] git-secrets --scan-history timed out on a large "
                      "repo — working-tree results are still complete.")
        except Exception as e:
            _log(log, f"[secrets] git-secrets --scan-history skipped: {e!r}")

    except Exception as e:
        _log(log, f"[secrets] git-secrets run skipped: {e!r}")
        return []
    if findings:
        n_hist = sum(1 for f in findings if f.get("engine") == "git-secrets/history")
        n_tree = len(findings) - n_hist
        _log(log, f"[secrets] git-secrets reported {n_tree} hit(s) in the working tree"
                  + (f" and {n_hist} in commit history" if n_hist else "") + ".")
    return findings

def _p(pattern: str, flags: int = 0) -> "re.Pattern[str]":
    return re.compile(pattern, flags)

_PROVIDERS_CLOUD: list[tuple[str, str, str, "re.Pattern[str]"]] = [
    ("aws-access-key-id", "AWS Access Key ID", "critical",
     _p(r"(?<![A-Z0-9])(?:AKIA|ASIA|AGPA|AIDA|AROA|AIPA|ANPA|ANVA|ABIA|ACCA)[A-Z0-9]{16}(?![A-Z0-9])")),
    ("aws-secret-access-key", "AWS Secret Access Key", "critical",
     _p(r"(?i)aws.{0,24}?(?:secret|private).{0,24}?['\"`]([0-9a-zA-Z/+]{40})['\"`]")),
    ("aws-session-token", "AWS Session Token", "high",
     _p(r"(?i)aws.{0,24}?session.{0,24}?token.{0,4}?['\"`]([0-9a-zA-Z/+=]{100,})['\"`]")),
    ("aws-mws-key", "Amazon MWS Auth Token", "high",
     _p(r"amzn\.mws\.[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}")),
    ("gcp-api-key", "Google API key", "high",
     _p(r"\bAIza[0-9A-Za-z\-_]{35}\b")),
    ("gcp-oauth", "Google OAuth client id", "medium",
     _p(r"\b[0-9]+-[0-9A-Za-z_]{32}\.apps\.googleusercontent\.com\b")),
    ("gcp-service-account", "GCP service-account private key (JSON)", "critical",
     _p(r'"private_key"\s*:\s*"-----BEGIN PRIVATE KEY')),
    ("firebase-server-key", "Firebase Cloud Messaging server key", "high",
     _p(r"\bAAAA[A-Za-z0-9_-]{7}:[A-Za-z0-9_-]{140}\b")),
    ("azure-storage-key", "Azure Storage account key", "critical",
     _p(r"(?i)AccountKey=[A-Za-z0-9+/]{86}==")),
    ("azure-sas-token", "Azure SAS token", "high",
     _p(r"(?i)[?&]sig=[A-Za-z0-9%]{20,}.{0,40}se=\d")),
    ("azure-devops-pat", "Azure DevOps personal access token", "high",
     _p(r"(?i)azure.{0,20}(?:devops|pat).{0,20}['\"`]([a-z0-9]{52})['\"`]")),
    ("azure-client-secret", "Azure AD app client secret", "high",
     _p(r"(?i)(?:azure|aad|client).{0,15}secret.{0,4}['\"`]([a-zA-Z0-9_~.\-]{34,40})['\"`]")),
    ("digitalocean-pat", "DigitalOcean personal access token", "high",
     _p(r"\bdop_v1_[a-f0-9]{64}\b")),
    ("digitalocean-oauth", "DigitalOcean OAuth token", "high",
     _p(r"\bdoo_v1_[a-f0-9]{64}\b")),
    ("alibaba-access-key", "Alibaba Cloud AccessKey ID", "high",
     _p(r"\bLTAI[0-9A-Za-z]{12,20}\b")),
    ("oracle-ocid", "Oracle Cloud OCID (resource identifier)", "low",
     _p(r"\bocid1\.[a-z0-9]+\.oc[0-9]\.[a-z0-9-]*\.[a-z0-9]{20,}\b")),
    ("cloudflare-api-key", "Cloudflare Global API key", "high",
     _p(r"(?i)cloudflare.{0,20}api.{0,10}key.{0,4}['\"`]([a-f0-9]{37})['\"`]")),
    ("cloudflare-api-token", "Cloudflare API token", "high",
     _p(r"(?i)cloudflare.{0,20}token.{0,4}['\"`]([A-Za-z0-9_-]{40})['\"`]")),
    ("heroku-api-key", "Heroku API key", "medium",
     _p(r"(?i)heroku.{0,20}['\"`]([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})['\"`]")),
    ("linode-pat", "Linode personal access token", "high",
     _p(r"(?i)linode.{0,20}token.{0,4}['\"`]([a-f0-9]{64})['\"`]")),
    ("ibm-cloud-api-key", "IBM Cloud API key", "high",
     _p(r"(?i)ibm.{0,10}cloud.{0,10}api.{0,10}key.{0,4}['\"`]([A-Za-z0-9_-]{44})['\"`]")),
]

_PROVIDERS_KEYS: list[tuple[str, str, str, "re.Pattern[str]"]] = [
    ("private-key", "Private key block", "critical",
     _p(r"-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP |ENCRYPTED )?PRIVATE KEY-----")),
    ("putty-private-key", "PuTTY private key (.ppk)", "critical",
     _p(r"PuTTY-User-Key-File-\d")),
    ("ansible-vault", "Ansible Vault-encrypted content", "medium",
     _p(r"\$ANSIBLE_VAULT;\d\.\d;AES256")),
    ("age-secret-key", "age encryption secret key", "critical",
     _p(r"\bAGE-SECRET-KEY-1[QPZRY9X8GF2TVDW0S3JN54KHCE6MUA7L]{58}\b")),
]

_PROVIDERS_AI: list[tuple[str, str, str, "re.Pattern[str]"]] = [
    ("anthropic-api-key", "Anthropic API key", "critical",
     _p(r"\bsk-ant-api03-[A-Za-z0-9_-]{93}AA\b")),
    ("anthropic-admin-key", "Anthropic Admin API key", "critical",
     _p(r"\bsk-ant-admin01-[A-Za-z0-9_-]{93}AA\b")),
    ("openai-api-key", "OpenAI API key", "critical",
     _p(r"\bsk-(?:proj-|svcacct-|admin-)?[A-Za-z0-9_-]{20,74}T3BlbkFJ[A-Za-z0-9_-]{20,74}\b")),
    ("azure-openai-key", "Azure OpenAI resource key", "critical",
     _p(r"(?i)azure.{0,15}openai.{0,20}key.{0,4}['\"`]([a-f0-9]{32})['\"`]")),
    ("google-ai-gemini-key", "Google AI (Gemini/PaLM) API key", "high",
     _p(r"(?i)(?:gemini|google.?ai|palm).{0,20}key.{0,4}['\"`](AIza[0-9A-Za-z\-_]{35})['\"`]")),
    ("cohere-api-key", "Cohere API key", "high",
     _p(r"(?i)(?:cohere|CO_API_KEY).{0,20}[\s'\"`]{0,3}[:=][\x60'\"\s=]{0,5}([A-Za-z0-9]{40})(?:[\x60'\"\s;]|$)")),
    ("huggingface-token", "Hugging Face access token", "high",
     _p(r"\bhf_[A-Za-z]{34}\b")),
    ("huggingface-org-token", "Hugging Face organization API token", "high",
     _p(r"\bapi_org_[A-Za-z]{34}\b")),
    ("perplexity-api-key", "Perplexity API key", "high",
     _p(r"\bpplx-[a-zA-Z0-9]{48}\b")),
    ("replicate-api-token", "Replicate API token", "high",
     _p(r"\br8_[A-Za-z0-9]{37}\b")),
    ("groq-api-key", "Groq API key", "high",
     _p(r"\bgsk_[A-Za-z0-9]{52}\b")),
    ("mistral-api-key", "Mistral AI API key", "high",
     _p(r"(?i)mistral.{0,20}key.{0,4}['\"`]([A-Za-z0-9]{32})['\"`]")),
    ("elevenlabs-api-key", "ElevenLabs API key", "medium",
     _p(r"(?i)elevenlabs.{0,20}key.{0,4}['\"`]([a-f0-9]{32})['\"`]")),
    ("pinecone-api-key", "Pinecone vector-DB API key", "high",
     _p(r"(?i)pinecone.{0,20}key.{0,4}['\"`]([a-f0-9-]{36})['\"`]")),
    ("langsmith-api-key", "LangSmith/LangChain API key", "medium",
     _p(r"\bls(?:v2|__)[A-Za-z0-9_-]{20,64}\b")),
]

_PROVIDERS_VCS_CI: list[tuple[str, str, str, "re.Pattern[str]"]] = [
    ("github-token", "GitHub token", "high",
     _p(r"\bgh[pousr]_[0-9A-Za-z]{36,255}\b")),
    ("github-fine-pat", "GitHub fine-grained personal access token", "high",
     _p(r"\bgithub_pat_[0-9A-Za-z_]{22,255}\b")),
    ("gitlab-pat", "GitLab personal access token", "high",
     _p(r"\bglpat-[0-9A-Za-z_-]{20}\b")),
    ("bitbucket-app-password", "Bitbucket app password", "high",
     _p(r"(?i)bitbucket.{0,20}(?:app.?password|token).{0,4}['\"`]([A-Za-z0-9]{20,32})['\"`]")),
    ("circleci-token", "CircleCI personal API token", "high",
     _p(r"(?i)circleci.{0,20}token.{0,4}['\"`]([a-f0-9]{40})['\"`]")),
    ("travis-token", "Travis CI token", "medium",
     _p(r"(?i)travis.{0,20}token.{0,4}['\"`]([A-Za-z0-9]{22})['\"`]")),
    ("npm-token", "npm access token", "high",
     _p(r"\bnpm_[A-Za-z0-9]{36}\b")),
    ("npmrc-legacy-token", ".npmrc legacy auth token", "high",
     _p(r"//registry\.npmjs\.org/:_authToken=([A-Za-z0-9_-]{20,})")),
    ("pypi-token", "PyPI upload token", "high",
     _p(r"\bpypi-AgEIcHlwaS5vcmc[A-Za-z0-9_-]{40,}\b")),
    ("nuget-api-key", "NuGet API key", "medium",
     _p(r"(?i)nuget.{0,20}api.?key.{0,4}['\"`]([a-z0-9]{46})['\"`]")),
    ("docker-hub-pat", "Docker Hub personal access token", "high",
     _p(r"\bdckr_pat_[A-Za-z0-9_-]{27}\b")),
    ("docker-config-auth", "Docker config.json base64 auth", "medium",
     _p(r'"auth"\s*:\s*"[A-Za-z0-9+/]{20,}={0,2}"')),
    ("terraform-cloud-token", "Terraform Cloud API token", "high",
     _p(r"\b[A-Za-z0-9]{14}\.atlasv1\.[A-Za-z0-9_-]{60,}\b")),
    ("jfrog-artifactory-token", "JFrog/Artifactory API key or token", "high",
     _p(r"(?i)artifactory.{0,20}(?:api.?key|token).{0,4}['\"`]([A-Za-z0-9]{20,})['\"`]")),
    ("jfrog-artifactory-akcp", "JFrog/Artifactory reference token (AKCp)", "high",
     _p(r"\bAKCp[A-Za-z0-9]{69}\b")),
    ("sonar-token", "SonarQube/SonarCloud token", "medium",
     _p(r"\b(?:squ?_|sqp_|sqa_)[a-z0-9]{40}\b")),
    ("snyk-api-token", "Snyk API/OAuth token", "high",
     _p(r"(?i)snyk[_.-]?(?:api|oauth)?[_.-]?(?:key|token).{0,20}['\"`]([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})['\"`]")),
    ("gitlab-deploy-token", "GitLab deploy token", "high",
     _p(r"\bgldt-[0-9a-zA-Z_-]{20}\b")),
    ("gitlab-runner-token", "GitLab Runner authentication token", "high",
     _p(r"\bglrt-[0-9a-zA-Z_-]{20}\b")),
    ("gitlab-cicd-job-token", "GitLab CI/CD job token", "medium",
     _p(r"\bglcbt-[0-9a-zA-Z]{1,5}_[0-9a-zA-Z_-]{20}\b")),
    ("gitlab-pat-routable", "GitLab personal access token (routable format)", "high",
     _p(r"\bglpat-[0-9a-zA-Z_-]{27,300}\.[0-9a-z]{9}\b")),
    ("bitbucket-client-secret", "Bitbucket OAuth client secret", "high",
     _p(r"(?i)bitbucket.{0,20}client.?secret.{0,4}['\"`]([A-Za-z0-9]{32,64})['\"`]")),
    ("codecov-token", "Codecov upload token", "medium",
     _p(r"(?i)codecov.{0,20}token.{0,4}['\"`]([a-z0-9-]{32,36})['\"`]")),
    ("clojars-token", "Clojars deploy token", "medium",
     _p(r"(?i)CLOJARS_[a-z0-9]{60}")),
    ("droneci-token", "Drone CI access token", "medium",
     _p(r"(?i)drone.{0,15}token.{0,4}['\"`]([a-z0-9]{32})['\"`]")),
    ("doppler-token", "Doppler secrets-manager service token", "critical",
     _p(r"\bdp\.pt\.[a-zA-Z0-9]{43}\b")),
    ("hashicorp-vault-token", "HashiCorp Vault service/batch token", "critical",
     _p(r"\bhv[bs]\.[A-Za-z0-9_-]{90,300}\b")),
    ("pulumi-token", "Pulumi access token", "high",
     _p(r"\bpul-[a-f0-9]{40}\b")),
    ("prefect-token", "Prefect API token", "high",
     _p(r"\bpnu_[a-zA-Z0-9]{36}\b")),
    ("octopus-deploy-key", "Octopus Deploy API key", "high",
     _p(r"\bAPI-[A-Z0-9]{26}\b")),
    ("harness-api-key", "Harness API key", "high",
     _p(r"\b(?:pat|sat)\.[a-zA-Z0-9_-]{22}\.[a-zA-Z0-9]{24}\.[a-zA-Z0-9]{20}\b")),
    ("infracost-token", "Infracost API token", "low",
     _p(r"\bico-[a-zA-Z0-9]{32}\b")),
    ("sourcegraph-token", "Sourcegraph access token", "medium",
     _p(r"\bsgp_(?:[a-fA-F0-9]{16}|local)_[a-fA-F0-9]{40}\b")),
    ("rubygems-token", "RubyGems API token", "high",
     _p(r"\brubygems_[a-f0-9]{48}\b")),
    ("postman-token", "Postman API token", "medium",
     _p(r"\bPMAK-[a-f0-9]{24}-[a-f0-9]{34}\b")),
    ("readme-token", "ReadMe.io API token", "low",
     _p(r"\brdme_[a-z0-9]{70}\b")),
    ("databricks-token", "Databricks personal access token", "high",
     _p(r"\bdapi[a-f0-9]{32}(?:-\d)?\b")),
    ("planetscale-token", "PlanetScale database token", "critical",
     _p(r"\bpscale_tkn_[\w=.-]{32,64}\b")),
    ("planetscale-oauth", "PlanetScale OAuth token", "critical",
     _p(r"\bpscale_oauth_[\w=.-]{32,64}\b")),
    ("notion-token", "Notion integration token", "medium",
     _p(r"\bntn_[0-9]{11}[A-Za-z0-9]{30,40}\b")),
    ("linear-api-key", "Linear API key", "medium",
     _p(r"\blin_api_[a-zA-Z0-9]{40}\b")),
    ("asana-secret", "Asana client secret", "high",
     _p(r"(?i)asana.{0,20}(?:client.?)?secret.{0,4}['\"`]([a-z0-9]{32})['\"`]")),
    ("atlassian-api-token", "Atlassian (Jira/Confluence) API token", "high",
     _p(r"\bATATT3[A-Za-z0-9_-]{100,200}\b")),
    ("airtable-token", "Airtable API key / PAT", "high",
     _p(r"\bpat[A-Za-z0-9]{14}\.[a-f0-9]{64}\b")),
    ("launchdarkly-token", "LaunchDarkly access token", "high",
     _p(r"(?i)launchdarkly.{0,20}token.{0,4}['\"`]([a-z0-9=_-]{40})['\"`]")),
]

_PROVIDERS_PAYMENTS: list[tuple[str, str, str, "re.Pattern[str]"]] = [
    ("stripe-secret-live", "Stripe live secret/restricted key", "critical",
     _p(r"\b(?:sk|rk)_live_[0-9a-zA-Z]{20,}\b")),
    ("stripe-secret-test", "Stripe test secret key", "low",
     _p(r"\b(?:sk|rk)_test_[0-9a-zA-Z]{20,}\b")),
    ("stripe-webhook-secret", "Stripe webhook signing secret", "high",
     _p(r"\bwhsec_[A-Za-z0-9]{32,}\b")),
    ("paypal-braintree-token", "PayPal/Braintree access token", "high",
     _p(r"\baccess_token\$production\$[a-z0-9]{16}\$[a-f0-9]{32}\b")),
    ("square-token", "Square access token", "high",
     _p(r"\bsq0(?:atp|csp)-[0-9A-Za-z_-]{22,43}\b")),
    ("razorpay-key", "Razorpay live key", "high",
     _p(r"\brzp_live_[A-Za-z0-9]{14,}\b")),
    ("plaid-secret", "Plaid secret", "high",
     _p(r"(?i)plaid.{0,20}secret.{0,4}['\"`]([a-f0-9]{30})['\"`]")),
    ("stripe-secret-prod", "Stripe production secret/restricted key", "critical",
     _p(r"\b(?:sk|rk)_prod_[0-9a-zA-Z]{10,99}\b")),
    ("square-access-token-v2", "Square access token (current format)", "high",
     _p(r"\b(?:EAAA[\w-]{22,60}|sq0atp-[\w-]{22,43})\b")),
    ("flutterwave-key", "Flutterwave public/secret key", "critical",
     _p(r"\bFLW(?:PUBK|SECK)(?:_TEST)?-[A-Za-z0-9]{32}-?X?\b")),
    ("gocardless-token", "GoCardless live API token", "critical",
     _p(r"(?i)gocardless.{0,20}token.{0,4}['\"`](live_[A-Za-z0-9_-]{40})['\"`]")),
    ("kraken-api-key", "Kraken exchange API key", "critical",
     _p(r"(?i)kraken.{0,20}(?:key|secret).{0,4}['\"`]([A-Za-z0-9/=+_-]{80,90})['\"`]")),
    ("kucoin-key", "KuCoin exchange API key/secret", "critical",
     _p(r"(?i)kucoin.{0,20}(?:key|secret).{0,4}['\"`]([a-f0-9]{24}|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})['\"`]")),
    ("bittrex-key", "Bittrex exchange access/secret key", "critical",
     _p(r"(?i)bittrex.{0,20}(?:key|secret).{0,4}['\"`]([a-z0-9]{32})['\"`]")),
    ("coinbase-token", "Coinbase access token", "critical",
     _p(r"(?i)coinbase.{0,20}token.{0,4}['\"`]([a-z0-9_-]{64})['\"`]")),
    ("lob-api-key", "Lob API key", "medium",
     _p(r"(?i)lob.{0,15}key.{0,4}['\"`]((?:live|test)_[a-f0-9]{35})['\"`]")),
    ("shippo-token", "Shippo API token", "medium",
     _p(r"\bshippo_(?:live|test)_[a-fA-F0-9]{40}\b")),
]

_PROVIDERS_MESSAGING: list[tuple[str, str, str, "re.Pattern[str]"]] = [

    ("slack-token", "Slack token", "high",
     _p(r"\bxox[baoprs]-[0-9A-Za-z-]{10,48}\b")),
    ("slack-webhook", "Slack webhook URL", "medium",
     _p(r"https://hooks\.slack\.com/(?:services|workflows|triggers)/[A-Za-z0-9/_-]{30,}")),
    ("discord-bot-token", "Discord bot token", "high",
     _p(r"\b[MN][A-Za-z\d]{23}\.[\w-]{6}\.[\w-]{27}\b")),
    ("discord-webhook", "Discord webhook URL", "medium",
     _p(r"https://discord(?:app)?\.com/api/webhooks/\d{17,20}/[A-Za-z0-9_-]{60,}")),
    ("telegram-bot-token", "Telegram bot token", "high",
     _p(r"\b\d{8,10}:[A-Za-z0-9_-]{35}\b")),
    ("twilio-sid", "Twilio account/API SID", "high",
     _p(r"\b(?:AC|SK)[0-9a-fA-F]{32}\b")),
    ("twilio-auth-token", "Twilio Auth Token", "high",
     _p(r"(?i)twilio.{0,20}(?:auth.?token).{0,4}['\"`]([0-9a-f]{32})['\"`]")),
    ("sendgrid-key", "SendGrid API key", "high",
     _p(r"\bSG\.[0-9A-Za-z\-_]{22}\.[0-9A-Za-z\-_]{43}\b")),
    ("mailgun-key", "Mailgun API key", "high",
     _p(r"\bkey-[0-9a-f]{32}\b")),
    ("mailchimp-key", "Mailchimp API key", "high",
     _p(r"\b[0-9a-f]{32}-us\d{1,2}\b")),
    ("twitter-bearer", "Twitter/X bearer token", "high",
     _p(r"\bAAAAAAAAAAAAAAAAAAAAA[A-Za-z0-9%]{35,}\b")),
    ("twitter-secret", "Twitter/X API secret", "medium",
     _p(r"(?i)twitter.{0,20}secret.{0,4}['\"`]([A-Za-z0-9]{45})['\"`]")),
    ("facebook-access-token", "Facebook/Meta access token", "high",
     _p(r"\bEAA[A-Za-z0-9]{60,}\b")),
    ("discord-client-secret", "Discord OAuth client secret", "high",
     _p(r"(?i)discord.{0,20}(?:client.?)?secret.{0,4}['\"`]([a-zA-Z0-9_-]{32})['\"`]")),
    ("shopify-token", "Shopify access/private-app/custom-app token", "critical",
     _p(r"\bsh(?:pat|pca|ppa)_[a-fA-F0-9]{32}\b")),
    ("zendesk-token", "Zendesk API secret key", "high",
     _p(r"(?i)zendesk.{0,20}(?:key|token).{0,4}['\"`]([a-z0-9]{40})['\"`]")),
    ("linkedin-client-secret", "LinkedIn OAuth client secret", "high",
     _p(r"(?i)linked[_-]?in.{0,20}secret.{0,4}['\"`]([a-zA-Z0-9]{16})['\"`]")),
    ("twitch-token", "Twitch API token", "medium",
     _p(r"(?i)twitch.{0,20}token.{0,4}['\"`]([a-z0-9]{30})['\"`]")),
    ("sendinblue-brevo-key", "Sendinblue/Brevo API key", "high",
     _p(r"\bxkeysib-[a-f0-9]{64}-[a-zA-Z0-9]{16}\b")),
    ("squarespace-token", "Squarespace access token", "high",
     _p(r"(?i)squarespace.{0,20}token.{0,4}['\"`]([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})['\"`]")),
    ("etsy-token", "Etsy access token", "medium",
     _p(r"(?i)etsy.{0,20}token.{0,4}['\"`]([a-z0-9]{24})['\"`]")),
    ("messagebird-token", "MessageBird API token", "medium",
     _p(r"(?i)message[_-]?bird.{0,20}['\"`]([a-z0-9]{25})['\"`]")),
    ("intercom-token", "Intercom API key", "high",
     _p(r"(?i)intercom.{0,20}key.{0,4}['\"`]([a-z0-9=_-]{60})['\"`]")),
    ("typeform-token", "Typeform personal access token", "medium",
     _p(r"\btfp_[a-zA-Z0-9_.=-]{40,59}\b")),
    ("microsoft-teams-webhook", "Microsoft Teams incoming webhook URL", "medium",
     _p(r"https://[a-z0-9.-]+\.webhook\.office\.com/webhookb2/[A-Za-z0-9@/-]{20,}")),
]

_PROVIDERS_AUTH: list[tuple[str, str, str, "re.Pattern[str]"]] = [
    ("jwt", "JSON Web Token", "medium",
     _p(r"\beyJ[A-Za-z0-9_-]{8,}\.eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b")),
    ("auth0-client-secret", "Auth0 client secret", "high",
     _p(r"(?i)auth0.{0,20}(?:client.?)?secret.{0,4}['\"`]([A-Za-z0-9_-]{48,64})['\"`]")),
    ("okta-api-token", "Okta API token", "high",
     _p(r"(?i)okta.{0,20}token.{0,4}['\"`]([A-Za-z0-9_-]{40})['\"`]")),
    ("basic-auth-url", "Credentials embedded in URL", "high",
     _p(r"\b[a-zA-Z][a-zA-Z0-9+.\-]*://[^/\s:@]{1,64}:([^/\s:@]{3,64})@")),
    ("bearer-header", "Hard-coded Bearer/Authorization header", "medium",
     _p(r"(?i)authorization['\"`]?\s*[:=]\s*['\"`]?bearer\s+([A-Za-z0-9._-]{20,})")),
    ("1password-service-token", "1Password service account token (secrets manager)", "critical",
     _p(r"\bops_eyJ[A-Za-z0-9+/]{100,}={0,3}\b")),
    ("openshift-user-token", "OpenShift/Kubernetes bearer user token", "high",
     _p(r"\bsha256~[\w-]{43}\b")),
    ("adobe-client-secret", "Adobe client secret", "high",
     _p(r"\bp8e-[a-zA-Z0-9]{32}\b")),
]

_PROVIDERS_OBSERVABILITY: list[tuple[str, str, str, "re.Pattern[str]"]] = [
    ("datadog-api-key", "Datadog API key", "medium",
     _p(r"(?i)datadog.{0,20}api.?key.{0,4}['\"`]([a-f0-9]{32})['\"`]")),
    ("datadog-app-key", "Datadog application key", "medium",
     _p(r"(?i)datadog.{0,20}app.?key.{0,4}['\"`]([a-f0-9]{40})['\"`]")),
    ("newrelic-license-key", "New Relic license key", "medium",
     _p(r"\b[A-Za-z0-9]{40}NRAL\b")),
    ("newrelic-insert-key", "New Relic insert key (write telemetry)", "medium",
     _p(r"\bNRII-[a-z0-9-]{32}\b")),
    ("newrelic-user-api-key", "New Relic user API key (full account access)", "high",
     _p(r"\bNRAK-[A-Z0-9]{27}\b")),
    ("newrelic-browser-token", "New Relic browser API token", "low",
     _p(r"\bNRJS-[a-f0-9]{19}\b")),
    ("pagerduty-api-key", "PagerDuty API key", "medium",
     _p(r"(?i)pagerduty.{0,20}(?:api.?key|token).{0,4}['\"`]([A-Za-z0-9+_-]{20})['\"`]")),
    ("sentry-auth-token", "Sentry auth token", "medium",
     _p(r"\bsntrys_[A-Za-z0-9_]{40,}\b")),
    ("sentry-user-token", "Sentry user auth token", "high",
     _p(r"\bsntryu_[a-f0-9]{64}\b")),
    ("algolia-admin-key", "Algolia Admin API key", "high",
     _p(r"(?i)algolia.{0,20}admin.{0,10}key.{0,4}['\"`]([a-f0-9]{32})['\"`]")),
    ("segment-write-key", "Segment write key", "medium",
     _p(r"(?i)segment.{0,20}write.?key.{0,4}['\"`]([A-Za-z0-9]{32})['\"`]")),
    ("grafana-api-key", "Grafana API key", "high",
     _p(r"(?i)\beyJrIjoi[A-Za-z0-9]{70,400}={0,3}\b")),
    ("grafana-cloud-token", "Grafana Cloud API token", "high",
     _p(r"\bglc_[A-Za-z0-9+/]{32,400}={0,3}\b")),
    ("grafana-service-account", "Grafana service-account token", "high",
     _p(r"\bglsa_[A-Za-z0-9]{32}_[A-Fa-f0-9]{8}\b")),
    ("dynatrace-token", "Dynatrace API token", "high",
     _p(r"\bdt0c01\.[a-zA-Z0-9]{24}\.[a-zA-Z0-9]{64}\b")),
    ("sumologic-token", "Sumo Logic access token", "medium",
     _p(r"(?i)sumo(?:logic)?.{0,20}token.{0,4}['\"`]([a-z0-9]{64})['\"`]")),
    ("confluent-key", "Confluent (Kafka) API key/secret", "high",
     _p(r"(?i)confluent.{0,20}(?:key|secret).{0,4}['\"`]([a-z0-9]{16}|[a-z0-9]{64})['\"`]")),
    ("clickhouse-cloud-key", "ClickHouse Cloud API secret key", "critical",
     _p(r"\b4b1d[A-Za-z0-9]{38}\b")),
    ("honeycomb-api-key", "Honeycomb API key", "medium",
     _p(r"(?i)honeycomb.{0,20}key.{0,4}['\"`]([a-zA-Z0-9]{22,32})['\"`]")),
    ("rollbar-token", "Rollbar access token", "medium",
     _p(r"(?i)rollbar.{0,20}(?:token|key).{0,4}['\"`]([a-f0-9]{32})['\"`]")),
    ("bugsnag-key", "Bugsnag API/project key", "medium",
     _p(r"(?i)bugsnag.{0,20}key.{0,4}['\"`]([a-f0-9]{32})['\"`]")),
]

_PROVIDERS_DEVTOOLS: list[tuple[str, str, str, "re.Pattern[str]"]] = [
    ("maxmind-license-key", "MaxMind GeoIP license key", "low",
     _p(r"\b[A-Za-z0-9]{6}_[A-Za-z0-9]{29}_mmk\b")),
    ("rapidapi-token", "RapidAPI access token", "medium",
     _p(r"(?i)rapidapi.{0,20}['\"`]([a-z0-9_-]{50})['\"`]")),
    ("mapbox-secret-token", "Mapbox secret token (sk.)", "high",
     _p(r"\bsk\.eyJ[A-Za-z0-9_-]{40,}\.[A-Za-z0-9_-]{20,}\b")),
    ("contentful-token", "Contentful delivery/management API token", "medium",
     _p(r"(?i)contentful.{0,20}['\"`]([a-z0-9=_-]{43})['\"`]")),
    ("cisco-meraki-key", "Cisco Meraki dashboard API key", "high",
     _p(r"(?i)meraki.{0,20}['\"`]([0-9a-f]{40})['\"`]")),
    ("looker-client-secret", "Looker client secret", "high",
     _p(r"(?i)looker.{0,20}secret.{0,4}['\"`]([a-z0-9]{24})['\"`]")),
    ("mattermost-token", "Mattermost access token", "medium",
     _p(r"(?i)mattermost.{0,20}token.{0,4}['\"`]([a-z0-9]{26})['\"`]")),
    ("gitter-token", "Gitter access token", "low",
     _p(r"(?i)gitter.{0,20}token.{0,4}['\"`]([a-z0-9_-]{40})['\"`]")),
    ("frameio-token", "Frame.io API token", "medium",
     _p(r"\bfio-u-[a-zA-Z0-9_=-]{64}\b")),
    ("freshbooks-token", "FreshBooks access token", "medium",
     _p(r"(?i)freshbooks.{0,20}token.{0,4}['\"`]([a-z0-9]{64})['\"`]")),
    ("finicity-token", "Finicity (financial data) API token/secret", "high",
     _p(r"(?i)finicity.{0,20}(?:token|secret).{0,4}['\"`]([a-f0-9]{32})['\"`]")),
    ("finnhub-token", "Finnhub market-data API token", "low",
     _p(r"(?i)finnhub.{0,20}['\"`]([a-z0-9]{20})['\"`]")),
    ("flickr-token", "Flickr access token", "low",
     _p(r"(?i)flickr.{0,20}['\"`]([a-z0-9]{32})['\"`]")),
    ("nytimes-token", "New York Times API key", "low",
     _p(r"(?i)nytimes.{0,20}['\"`]([a-z0-9=_-]{32})['\"`]")),
    ("beamer-token", "Beamer API token", "low",
     _p(r"\bb_[a-zA-Z0-9=_-]{44}\b")),
]

_PROVIDERS_SHELL: list[tuple[str, str, str, "re.Pattern[str]"]] = [
    ("curl-auth-header", "Credential in curl -H/--header Authorization/API-Key", "high",
     _p(r"(?i)curl\b.*(?:-H|--header)\s+['\"](?:Authorization:\s*(?:Bearer|Token)\s+([A-Za-z0-9._~+/=-]{8,})|(?:[A-Za-z-]*Api-?Key):\s*([A-Za-z0-9._~+/=-]{8,}))")),
    ("curl-auth-user", "Credential in curl -u/--user", "high",
     _p(r"(?i)curl\b.*(?:-u|--user)\s+['\"]?([^:'\"\s]{2,}:[^'\"\s]{3,})")),
    ("wget-auth", "Credential in wget --http-password/--ftp-password", "high",
     _p(r"(?i)wget\b.*--(?:http|ftp)-password[= ]([^\s'\"]{3,})")),
]

_CRED_KEYWORD = (r"(?:api[_-]?key|apikey|access[_-]?key|private[_-]?key|"
                 r"client[_-]?secret|auth[_-]?token|secret(?:[_-]?key)?|"
                 r"token|passwd|password|pwd|credential)")
_CRED_IDENTIFIER = rf"[A-Za-z0-9_]{{0,40}}{_CRED_KEYWORD}[A-Za-z0-9_]{{0,40}}"

_PROVIDERS_GENERIC: list[tuple[str, str, str, "re.Pattern[str]"]] = [
    ("generic-secret", "Generic hard-coded secret", "medium",
     _p(rf"(?i){_CRED_IDENTIFIER}\s*[:=]\s*['\"`]([^'\"`\s]{{12,128}})['\"`]")),

    ("connstring-password", "Connection-string password", "high",
     _p(r"(?i)\b(?:password|pwd)\s*=\s*([^;'\"\s][^;'\"<]{2,128})(?:;|['\"]|\s*/?>)")),
    ("connstring-user", "Connection-string user id", "low",
     _p(r"(?i)\b(?:user\s*id|uid)\s*=\s*([^;'\"\s][^;'\"<]{1,64})(?:;|['\"]|\s*/?>)")),

    ("config-password", "Config password value", "high",
     _p(r"(?i)(?:password|passwd|pwd)\s*[:=]\s*[\"']([^\"'<>\s]{4,128})[\"']")),

    ("db-url-credential", "Database URL with embedded credentials", "high",
     _p(r"(?i)\b(?:jdbc:)?(?:postgres(?:ql)?|mysql|mongodb(?:\+srv)?|redis|mssql|oracle):(?://)?[^/\s:@]{0,64}:([^/\s:@]{3,64})@")),

    ("dotenv-unquoted-secret", "Unquoted secret in .env/.properties/.yml", "medium",
     _p(r"(?im)^\s*(?:export\s+)?[A-Za-z_][A-Za-z0-9_]*(?:API[_-]?KEY|SECRET|TOKEN|PASSWORD|PASSWD|PWD|PRIVATE[_-]?KEY|ACCESS[_-]?KEY)\w*\s*[:=]\s*(?!['\"]?\$\{)([^\s'\"][^\s#]{7,127})\s*$")),
    ("django-secret-key", "Django SECRET_KEY", "critical",
     _p(r"SECRET_KEY\s*=\s*['\"]([^'\"]{20,})['\"]")),
    ("flask-secret-key", "Flask SECRET_KEY", "high",
     _p(r"(?i)app\.config\[['\"]SECRET_KEY['\"]\]\s*=\s*['\"]([^'\"]{8,})['\"]")),
    ("rails-secret-key-base", "Rails secret_key_base", "critical",
     _p(r"secret_key_base\s*:\s*([0-9a-f]{64,})")),
    ("laravel-app-key", "Laravel APP_KEY", "critical",
     _p(r"APP_KEY\s*=\s*base64:([A-Za-z0-9+/=]{32,})")),
    ("spring-datasource-password", "Spring Boot datasource password", "high",
     _p(r"spring\.datasource\.password\s*=\s*(\S+)")),
    ("wordpress-auth-key", "WordPress AUTH_KEY/salts", "medium",
     _p(r"define\(\s*['\"](?:AUTH|SECURE_AUTH|LOGGED_IN|NONCE)_KEY['\"]\s*,\s*['\"]([^'\"]{16,})['\"]")),
    ("maven-server-password", "Maven settings.xml server password", "high",
     _p(r"<password>([^<>\s]{4,128})</password>")),
    ("generic-high-entropy-hex", "Long hex string assigned to a credential-like name", "medium",
     _p(rf"(?i){_CRED_IDENTIFIER}\s*[:=]\s*['\"`]?([0-9a-f]{{32,64}})['\"`]?\b")),
]

_PROVIDERS: list[tuple[str, str, str, "re.Pattern[str]"]] = (
    _PROVIDERS_CLOUD + _PROVIDERS_KEYS + _PROVIDERS_AI + _PROVIDERS_VCS_CI
    + _PROVIDERS_PAYMENTS + _PROVIDERS_MESSAGING + _PROVIDERS_AUTH
    + _PROVIDERS_OBSERVABILITY + _PROVIDERS_DEVTOOLS + _PROVIDERS_SHELL
    + _PROVIDERS_GENERIC
)

_GENERIC_CATCHALL_RULES = {
    "generic-secret", "generic-high-entropy-hex", "bearer-header",
    "basic-auth-url", "config-password",
}

_SENSITIVE_FILENAME_PATTERNS: list[tuple[str, str, str, "re.Pattern[str]"]] = [
    ("private-key-file", "Archivo de llave privada / certificado con clave", "high",
     _p(r"\.(pem|key|ppk|pfx|p12|jks|keystore|asc|gpg)$", re.I)),
    ("ssh-keypair-file", "Llave SSH privada sin cifrar (por nombre de archivo)", "high",
     _p(r"(?:^|[\\/])id_(rsa|dsa|ecdsa|ed25519)$", re.I)),
    ("env-file-committed", "Archivo .env versionado en el repositorio", "medium",
     _p(r"(?:^|[\\/])\.env(?:\.[a-zA-Z0-9_-]+)?$", re.I)),
    ("aws-credentials-file", "Archivo de credenciales de AWS CLI", "high",
     _p(r"(?:^|[\\/])\.aws[\\/]credentials$", re.I)),
    ("kube-config-file", "kubeconfig — puede traer tokens/certs embebidos", "medium",
     _p(r"(?:^|[\\/])(?:\.kube[\\/]config|kubeconfig(?:\.ya?ml)?)$", re.I)),
    ("netrc-file", "Archivo .netrc con credenciales de texto plano", "medium",
     _p(r"(?:^|[\\/])\.netrc$", re.I)),
    ("npmrc-file", "Archivo .npmrc — revisar _authToken", "low",
     _p(r"(?:^|[\\/])\.npmrc$", re.I)),
    ("pypirc-file", "Archivo .pypirc con credenciales de PyPI", "medium",
     _p(r"(?:^|[\\/])\.pypirc$", re.I)),
    ("terraform-state", "Terraform state — puede contener secretos en claro", "medium",
     _p(r"\.tfstate(?:\.backup)?$", re.I)),
    ("docker-config-file", "Docker config.json con auth embebido", "medium",
     _p(r"(?:^|[\\/])\.docker[\\/]config\.json$", re.I)),
    ("git-credentials-file", "Archivo .git-credentials con credenciales en texto plano", "high",
     _p(r"(?:^|[\\/])\.git-credentials$", re.I)),
    ("rails-master-key", "Rails master.key — descifra credentials.yml.enc", "critical",
     _p(r"(?:^|[\\/])config[\\/]master\.key$", re.I)),
    ("rails-encrypted-credentials", "Rails credentials.yml.enc versionado", "medium",
     _p(r"credentials\.yml\.enc$", re.I)),
    ("pgpass-file", "Archivo .pgpass con credenciales de PostgreSQL", "high",
     _p(r"(?:^|[\\/])\.pgpass$", re.I)),
    ("mysql-cnf-file", "Archivo .my.cnf — puede traer password= en claro", "medium",
     _p(r"(?:^|[\\/])\.my\.cnf$", re.I)),
    ("htpasswd-file", "Archivo .htpasswd con hashes de contraseñas", "medium",
     _p(r"(?:^|[\\/])\.htpasswd$", re.I)),
    ("unix-shadow-file", "Archivo shadow de contraseñas de sistema", "critical",
     _p(r"(?:^|[\\/])shadow$", re.I)),
    ("gcp-service-account-json", "Posible JSON de service account de GCP (por nombre)", "high",
     _p(r"(?:service[_-]?account|application[_-]?default[_-]?credentials).*\.json$", re.I)),
]

_EXAMPLE_MARKERS = (
    "EXAMPLE", "your-api-key", "your_api_key", "changeme", "change-me",
    "placeholder", "dummy", "redacted", "xxxxxxxx", "test-key", "testkey",
    "notreal", "fakekey", "sample", "0000000000", "1111111111",
)

_SKIP_DIRS = {
    ".git", ".hg", ".svn", "node_modules", "bower_components", "vendor",
    "venv", ".venv", "env", ".env.d", "__pycache__", ".mypy_cache",
    ".pytest_cache", "dist", "build", ".idea", ".vscode", ".gradle",
    "site-packages", "target", ".next", ".nuxt", "coverage", ".tox",
    "Reports", "reports", "_secrets_out", ".snyk-venv", ".snyk-wheels",
    ".cache", ".terraform", ".serverless", ".parcel-cache", ".turbo",
}
_SKIP_EXT = {
    ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico", ".webp", ".svg",
    ".pdf", ".zip", ".gz", ".tar", ".tgz", ".bz2", ".7z", ".rar",
    ".mp3", ".mp4", ".avi", ".mov", ".mkv", ".wav", ".ogg", ".flac",
    ".woff", ".woff2", ".ttf", ".otf", ".eot",
    ".class", ".jar", ".war", ".so", ".dll", ".dylib", ".exe", ".bin",
    ".pyc", ".pyo", ".o", ".a", ".lib", ".obj", ".wasm",
    ".lock",
}
_MAX_BYTES = 1_500_000
_BINARY_SNIFF = 4096

def redact(secret: str, keep_head: int = 4, keep_tail: int = 2) -> str:
    s = secret.strip()
    if len(s) <= keep_head + keep_tail:
        return "•" * len(s)
    return f"{s[:keep_head]}{'•' * max(4, len(s) - keep_head - keep_tail)}{s[-keep_tail:]}"

def _looks_like_example(text: str) -> bool:
    up = text.upper()
    return any(m.upper() in up for m in _EXAMPLE_MARKERS)

_SUPPRESS_MARKERS_RE = _p(
    r"(?:nosecret|secrets?[:=]\s*ignore|pragma:\s*allowlist\s*secret|gitleaks:allow)",
    re.I)

def _is_suppressed(line: str) -> bool:
    return bool(_SUPPRESS_MARKERS_RE.search(line))

def redact_line(line: str, secret: str) -> str:
    snippet = line.strip()
    if len(snippet) > 160:
        idx = snippet.find(secret.strip())
        if idx >= 0:
            start = max(0, idx - 40)
            snippet = ("…" if start else "") + snippet[start:idx + len(secret) + 40] + "…"
        else:
            snippet = snippet[:160] + "…"
    try:
        snippet = snippet.replace(secret.strip(), redact(secret))
    except Exception:
        pass
    return snippet

_ENTROPY_ASSIGN_RE = _p(
    rf"""(?i){_CRED_IDENTIFIER}\s*[:=]\s*['"`]?([A-Za-z0-9+/_.=-]{{20,120}})['"`]?"""
)

_LOW_VALUE_TOKEN = _p(r"^(.)\1{6,}$|^(?:0123456789|abcdefgh|password|changeme)$", re.I)

def _shannon_entropy(s: str) -> float:
    if not s:
        return 0.0
    counts = Counter(s)
    n = len(s)
    return -sum((c / n) * math.log2(c / n) for c in counts.values())

def _looks_high_entropy(token: str) -> bool:
    if len(token) < 20 or len(token) > 120:
        return False
    if _LOW_VALUE_TOKEN.match(token):
        return False

    if re.search(r"[\s]{1,}", token) or token.count("/") > 3 or token.count(".") > 4:
        return False
    ent = _shannon_entropy(token)

    return ent >= 3.4

_BOMS = (
    (b"\xef\xbb\xbf",     "utf-8-sig"),
    (b"\xff\xfe\x00\x00", "utf-32-le"),
    (b"\x00\x00\xfe\xff", "utf-32-be"),
    (b"\xff\xfe",         "utf-16-le"),
    (b"\xfe\xff",         "utf-16-be"),
)

def _read_text_smart(path: Path) -> Optional[str]:
    """Read a file as text, honouring BOMs and UTF-16 (no BOM)."""
    try:
        with open(path, "rb") as fh:
            head = fh.read(_BINARY_SNIFF)
    except Exception:
        return None

    for bom, enc in _BOMS:
        if head.startswith(bom):
            try:
                return path.read_text(encoding=enc, errors="ignore")
            except Exception:
                return None

    if b"\x00" not in head:
        try:
            return path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            return None

    even_nul = head[0::2].count(0)
    odd_nul = head[1::2].count(0)
    half = max(1, len(head) // 2)
    if odd_nul > half * 0.30 and odd_nul >= even_nul:
        enc = "utf-16-le"
    elif even_nul > half * 0.30 and even_nul > odd_nul:
        enc = "utf-16-be"
    else:
        return None
    try:
        return path.read_text(encoding=enc, errors="ignore")
    except Exception:
        return None

def _iter_files(root: Path, stats: Optional[dict] = None):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in _SKIP_DIRS]
        for name in filenames:
            if stats is not None:
                stats["seen"] = stats.get("seen", 0) + 1
            yield Path(dirpath) / name

def _is_relative(p: Path, root: Path) -> bool:
    try:
        p.relative_to(root); return True
    except Exception:
        return False

_K8S_KIND_SECRET_RE = _p(r"(?im)^\s*kind:\s*[\"']?Secret[\"']?\s*$")
_K8S_DATA_BLOCK_RE = _p(r"(?im)^\s*(?:data|stringData)\s*:\s*$")
_K8S_DATA_KEY_RE = _p(r"(?im)^\s{2,}([\w.-]+):\s*(\S.*)$")

def _scan_k8s_secret_manifest(rel: str, text: str) -> list[dict]:
    """Whole-file (not per-line) heuristic: a Kubernetes ``kind: Secret`` manifest's `data:`/`stringData:` keys can s…"""
    if not _K8S_KIND_SECRET_RE.search(text) or not _K8S_DATA_BLOCK_RE.search(text):
        return []
    m = _K8S_DATA_BLOCK_RE.search(text)
    tail = text[m.end():]

    end_m = re.search(r"(?m)^\S", tail)
    if end_m:
        tail = tail[:end_m.start()]
    keys = [km.group(1) for km in _K8S_DATA_KEY_RE.finditer(tail)][:8]
    if not keys:
        return []
    line_no = text[:m.start()].count("\n") + 1
    return [{
        "file": rel, "line": line_no, "severity": "medium",
        "rule": "kubernetes-secret-manifest",
        "title": "Manifiesto de Kubernetes tipo Secret con datos embebidos",
        "secret_type": f"Secret manifest — claves: {', '.join(keys)}",
        "match": "(valores en base64 bajo data:/stringData:)",
        "context": f"kind: Secret · data keys: {', '.join(keys)}",
        "engine": "builtin/k8s-manifest",
    }]

def _scan_filename(rel: str) -> list[dict]:
    """Filename-only heuristics — run on EVERY file, including ones the content-scanner below will skip as binary/ove…"""
    hits = []
    for rule, stype, sev, rx in _SENSITIVE_FILENAME_PATTERNS:
        if rx.search(rel):
            hits.append({
                "file": rel, "line": "—", "severity": sev,
                "rule": rule, "title": stype, "secret_type": stype,
                "match": "(por nombre de archivo)",
                "context": rel,
                "engine": "builtin/filename",
            })
    return hits

def _scan_builtin(target: Path, log: Optional[Callable[[str], None]] = None,
                  cancel=None,
                  progress: Optional[Callable[[int, int], None]] = None,
                  total_files: int = 0) -> tuple[list[dict], int]:
    findings: list[dict] = []
    scanned = 0
    seen: set[tuple] = set()
    stats = {"seen": 0, "skip_ext": 0, "skip_size": 0, "skip_binary": 0,
             "skip_error": 0, "scanned": 0, "entropy_hits": 0, "filename_hits": 0,
             "suppressed_inline": 0}
    for fp in _iter_files(target, stats):
        if cancel is not None and getattr(cancel, "is_set", lambda: False)():
            _log(log, "[secrets] scan cancelled.")
            break

        rel = str(fp.relative_to(target)) if _is_relative(fp, target) else str(fp)

        fn_hits = _scan_filename(rel)
        if fn_hits:
            stats["filename_hits"] += len(fn_hits)
            findings.extend(fn_hits)

        ext = fp.suffix.lower()
        if ext in _SKIP_EXT:
            stats["skip_ext"] += 1
            continue
        try:
            if fp.stat().st_size > _MAX_BYTES:
                stats["skip_size"] += 1
                continue
            text = _read_text_smart(fp)
            if text is None:
                stats["skip_binary"] += 1
                continue
        except Exception:
            stats["skip_error"] += 1
            continue

        if ext in (".yaml", ".yml"):
            k8s_hits = _scan_k8s_secret_manifest(rel, text)
            if k8s_hits:
                stats["filename_hits"] += len(k8s_hits)
                findings.extend(k8s_hits)

        scanned += 1
        stats["scanned"] = scanned
        if progress is not None and total_files > 0:
            try:
                progress(scanned, total_files)
            except Exception:
                pass
        for lineno, line in enumerate(text.splitlines(), start=1):
            if len(line) > 4000:
                continue
            suppressed_line = _is_suppressed(line)

            candidates: dict[str, dict] = {}
            for rule, stype, sev, rx in _PROVIDERS:
                m = rx.search(line)
                if not m:
                    continue
                raw = m.group(m.lastindex) if m.lastindex else m.group(0)
                eff_sev = "low" if _looks_like_example(raw) else sev

                pkey = hashlib.sha1(raw.encode("utf-8", "ignore")).hexdigest()[:20]
                rank = (0 if rule in _GENERIC_CATCHALL_RULES else 1,
                        -SEVERITY_ORDER.get(eff_sev, 99))
                prev = candidates.get(pkey)
                if prev is not None and prev["_rank"] >= rank:
                    continue
                candidates[pkey] = {
                    "file": rel, "line": lineno, "severity": eff_sev,
                    "rule": rule, "title": stype, "secret_type": stype,
                    "match": redact(raw),
                    "context": redact_line(line, raw),
                    "engine": "builtin",
                    "_rank": rank,

                    "_raw_hash": hashlib.sha256(raw.encode("utf-8", "ignore")).hexdigest(),
                }
            matched_span: Optional[bool] = None
            for pkey, finding in candidates.items():
                key = (rel, lineno, pkey)
                if key in seen:
                    continue
                seen.add(key)
                finding.pop("_rank", None)
                matched_span = True
                if suppressed_line:
                    stats["suppressed_inline"] += 1
                    continue
                findings.append(finding)

            if matched_span is None:
                em = _ENTROPY_ASSIGN_RE.search(line)
                if em:
                    raw = em.group(1)
                    if _looks_high_entropy(raw) and not _looks_like_example(raw):
                        key = (rel, lineno, "entropy:" + raw[:24])
                        if key not in seen:
                            seen.add(key)
                            if suppressed_line:
                                stats["suppressed_inline"] += 1
                            else:
                                stats["entropy_hits"] += 1
                                findings.append({
                                    "file": rel, "line": lineno, "severity": "low",
                                    "rule": "high-entropy-secret",
                                    "title": "Posible secreto de alta entropía",
                                    "secret_type": "Cadena de alta entropía (heurística)",
                                    "match": redact(raw),
                                    "context": redact_line(line, raw),
                                    "engine": "builtin/entropy",
                                    "_raw_hash": hashlib.sha256(raw.encode("utf-8", "ignore")).hexdigest(),
                                })
    _log(log, "[secrets] built-in engine: "
              f"{stats['seen']} file(s) seen · {scanned} scanned · "
              f"skipped {stats['skip_ext']} by type, {stats['skip_size']} too-large, "
              f"{stats['skip_binary']} binary, {stats['skip_error']} unreadable · "
              f"{stats['filename_hits']} filename-based hit(s) · "
              f"{stats['entropy_hits']} entropy-fallback hit(s)"
              + (f" · {stats['suppressed_inline']} suppressed by inline marker"
                 if stats['suppressed_inline'] else ""))
    return findings, scanned

def _dedupe_findings(findings: list[dict]) -> list[dict]:
    """BUGFIX: the git-secrets bonus layer and the built-in engine used to both report the SAME AWS key on the SAME l…"""
    by_loc: dict[tuple[str, Any], list[dict]] = {}
    order: list[tuple[str, Any]] = []
    for f in findings:
        key = (f["file"], f["line"])
        if key not in by_loc:
            order.append(key)
            by_loc[key] = []
        by_loc[key].append(f)

    out: list[dict] = []
    for key in order:
        group = by_loc[key]
        if len(group) == 1:
            out.append(group[0])
            continue

        history = [f for f in group if f.get("engine") == "git-secrets/history"]
        current = [f for f in group if f.get("engine") != "git-secrets/history"]
        out.extend(history)
        if not current:
            continue

        exact: dict[tuple[str, str], list[dict]] = {}
        exact_order: list[tuple[str, str]] = []
        for f in current:
            ekey = (f.get("rule", ""), f.get("match", ""))
            if ekey not in exact:
                exact_order.append(ekey)
                exact[ekey] = []
            exact[ekey].append(f)

        def _merge(dupes: list[dict]) -> dict:
            dupes = sorted(dupes, key=lambda f: (SEVERITY_ORDER.get(f["severity"], 99),
                                                 0 if f.get("engine") == "builtin" else 1))
            merged = dict(dupes[0])
            engines = sorted({f.get("engine", "") for f in dupes})
            if len(engines) > 1:
                merged["engine"] = " + ".join(engines)
                merged["cross_validated"] = True
            return merged

        collapsed = [_merge(exact[ek]) if len(exact[ek]) > 1 else exact[ek][0]
                     for ek in exact_order]

        gs = [f for f in collapsed if f.get("engine") == "git-secrets"]
        others = [f for f in collapsed if f.get("engine") != "git-secrets"]
        if len(gs) == 1 and len(others) == 1:
            out.append(_merge([gs[0], others[0]]))
        else:
            out.extend(collapsed)
    return out

_BASELINE_FILENAME = ".secrets-baseline.json"

def _finding_fingerprint(f: dict) -> str:
    raw = f"{f.get('file', '')}|{f.get('rule', '')}|{f.get('match', '')}"
    return hashlib.sha256(raw.encode("utf-8", "ignore")).hexdigest()[:24]

def load_baseline(target) -> dict:
    """Return {fingerprint: {file, rule, note, added_at}} for a target's accepted-risk entries."""
    p = Path(target) / _BASELINE_FILENAME
    if not p.exists():
        return {}
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        accepted = data.get("accepted", {}) if isinstance(data, dict) else {}
        return accepted if isinstance(accepted, dict) else {}
    except Exception:
        return {}

def save_baseline_entry(target, finding: dict, note: str = "") -> str:
    """Mark one finding as reviewed/accepted for this target so future scans stop reporting it."""
    p = Path(target) / _BASELINE_FILENAME
    try:
        data = json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
    except Exception:
        data = {}
    if not isinstance(data, dict):
        data = {}
    accepted = data.setdefault("accepted", {})
    fp = _finding_fingerprint(finding)
    accepted[fp] = {
        "file": finding.get("file", ""), "rule": finding.get("rule", ""),
        "secret_type": finding.get("secret_type", finding.get("title", "")),
        "note": note,
        "added_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    p.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    return fp

def remove_baseline_entry(target, fingerprint: str) -> bool:
    """Undo a previous save_baseline_entry() — the finding will be reported again on the next scan."""
    p = Path(target) / _BASELINE_FILENAME
    if not p.exists():
        return False
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return False
    accepted = data.get("accepted", {}) if isinstance(data, dict) else {}
    if fingerprint not in accepted:
        return False
    del accepted[fingerprint]
    p.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    return True

def scan_path(target, log: Optional[Callable[[str], None]] = None, *,
              cancel=None, git_secrets_status: Optional[dict] = None,
              progress: Optional[Callable[[int, int], None]] = None) -> dict:
    target = Path(target).resolve()
    _log(log, f"[secrets] scanning {target}")
    t0 = time.time()
    findings: list[dict] = []

    gss = git_secrets_status or {}
    script = gss.get("path")
    git_secrets_active = bool(script and Path(script).exists())
    if git_secrets_active:
        _log(log, f"[secrets] git-secrets layer active ({script})")
        try:
            findings.extend(_run_git_secrets(Path(script), target, log))
        except Exception as e:
            _log(log, f"[secrets] git-secrets layer error: {e!r}")
    else:
        _log(log, "[secrets] git-secrets NOT available on this machine — "
                  "running the built-in pattern engine only. "
                  "(If the corporate proxy blocks the git-secrets download, "
                  "findings depend entirely on the built-in rules.)")

    total_files = 0
    if progress is not None:
        try:
            for _ in _iter_files(target):
                total_files += 1
        except Exception:
            total_files = 0

    builtin, scanned = _scan_builtin(target, log, cancel=cancel,
                                     progress=progress, total_files=total_files)
    findings.extend(builtin)
    findings = _dedupe_findings(findings)

    _hash_counts: dict[str, int] = {}
    for f in findings:
        h = f.get("_raw_hash")
        if h:
            _hash_counts[h] = _hash_counts.get(h, 0) + 1
    for f in findings:
        h = f.pop("_raw_hash", None)
        if h and _hash_counts.get(h, 0) > 1:
            f["reused_elsewhere"] = _hash_counts[h] - 1

    baseline = load_baseline(target)
    baseline_suppressed: list[dict] = []
    if baseline:
        kept = []
        for f in findings:
            fp = _finding_fingerprint(f)
            entry = baseline.get(fp)
            if entry:
                f = dict(f)
                f["baseline_note"] = entry.get("note", "")
                baseline_suppressed.append(f)
            else:
                kept.append(f)
        findings = kept

    findings.sort(key=lambda x: (SEVERITY_ORDER.get(x["severity"], 99),
                                 str(x["file"]), x["line"] if isinstance(x["line"], int) else -1))
    counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}
    for f in findings:
        counts[f["severity"]] = counts.get(f["severity"], 0) + 1

    dt = time.time() - t0
    engine = "git-secrets + built-in" if git_secrets_active else "built-in"
    if not findings and scanned > 0 and not baseline_suppressed:
        _log(log, "[secrets] 0 findings across a non-empty tree. If you expected "
                  "hits, confirm the target is the source root (not bin/obj), and "
                  "note that the built-in engine flags credentials in config/"
                  "connection strings, keys and tokens — not every password-shaped string.")
    _log(log, f"[secrets] done — {len(findings)} finding(s) across "
              f"{scanned} file(s) in {dt:.1f}s"
              + (f" ({len(baseline_suppressed)} baseline-accepted hidden)"
                 if baseline_suppressed else ""))
    return {
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "target": str(target), "engine": engine,
        "scanned_files": scanned, "elapsed": round(dt, 2),
        "counts": counts, "total": len(findings), "findings": findings,
        "baseline_suppressed": baseline_suppressed,
        "baseline_suppressed_count": len(baseline_suppressed),
    }

_SECRETS_HTML = r"""<!doctype html><html lang="en"><head><meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Secrets Report — {generated_at}</title><style>
:root{{--bg:#0d1b2a;--panel:#13243a;--bd:#21364f;--tx:#e8eef7;--mu:#90a4bd;
--ac:#F5A800;--crit:#ff5d6c;--high:#ff944d;--med:#ffd23f;--low:#5fe0a0}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--tx);
font:14px/1.55 -apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif}}
.shell{{max-width:1280px;margin:0 auto;padding:30px clamp(16px,4vw,48px) 80px}}
.top{{display:flex;align-items:center;gap:14px;margin-bottom:22px;flex-wrap:wrap}}
.logo{{width:42px;height:42px;border-radius:11px;background:var(--ac);color:#111;
display:grid;place-items:center;font-weight:800;font-size:20px}}
h1{{margin:0;font-size:22px}}.sub{{color:var(--mu);font-size:12px}}
.pill{{margin-left:auto;display:flex;gap:8px;flex-wrap:wrap}}
.tag{{background:var(--panel);border:1px solid var(--bd);border-radius:999px;
padding:6px 12px;font-size:12px;color:var(--mu)}}.tag b{{color:var(--tx)}}
.kpis{{display:grid;grid-template-columns:repeat(6,1fr);gap:12px;margin:8px 0 26px}}
@media(max-width:760px){{.kpis{{grid-template-columns:repeat(3,1fr)}}}}
.kpi{{background:var(--panel);border:1px solid var(--bd);border-left:4px solid var(--ac);
border-radius:12px;padding:16px}}.kpi .l{{color:var(--mu);font-size:11px;
text-transform:uppercase;letter-spacing:.1em}}.kpi .v{{font-size:30px;font-weight:800;margin-top:6px}}
.kpi.critical{{border-left-color:var(--crit)}}.kpi.high{{border-left-color:var(--high)}}
.kpi.medium{{border-left-color:var(--med)}}.kpi.low{{border-left-color:var(--low)}}
.kpi.accepted{{border-left-color:var(--mu)}}
.badge-reuse{{display:inline-block;margin-left:6px;padding:1px 7px;border-radius:999px;
font-size:10px;font-weight:700;background:#F5A80022;color:var(--ac)}}
table{{width:100%;border-collapse:collapse;background:var(--panel);
border:1px solid var(--bd);border-radius:12px;overflow:hidden;font-size:13px}}
th{{text-align:left;color:var(--mu);font-size:11px;text-transform:uppercase;
letter-spacing:.07em;padding:12px 14px;border-bottom:1px solid var(--bd)}}
td{{padding:11px 14px;border-bottom:1px solid var(--bd);vertical-align:top}}
tr:last-child td{{border-bottom:0}}tr:hover td{{background:#16294250}}
code{{font-family:ui-monospace,Menlo,Consolas,monospace;background:#0b1626;
border:1px solid var(--bd);border-radius:6px;padding:1px 6px;font-size:12px}}
.sev{{display:inline-block;padding:3px 10px;border-radius:999px;font-size:11px;
font-weight:800;text-transform:uppercase}}
.sev.critical{{background:#ff5d6c22;color:var(--crit)}}.sev.high{{background:#ff944d22;color:var(--high)}}
.sev.medium{{background:#ffd23f22;color:var(--med)}}.sev.low{{background:#5fe0a022;color:var(--low)}}
.empty{{text-align:center;padding:48px;color:var(--mu);background:var(--panel);
border:1px dashed var(--bd);border-radius:12px}}
.note{{margin:18px 0;color:var(--mu);font-size:12px}}
footer{{text-align:center;color:var(--mu);font-size:12px;padding:34px 0 0}}
</style></head><body><div class="shell">
<div class="top"><div class="logo">🔑</div>
<div><h1>Secrets Report</h1><div class="sub">git-secrets · hard-coded credential scan</div></div>
<div class="pill"><span class="tag">Engine <b>{engine}</b></span>
<span class="tag">Target <b>{target}</b></span>
<span class="tag">Files <b>{scanned_files}</b></span>
<span class="tag">Generated <b>{generated_at}</b></span></div></div>
<div class="kpis">
<div class="kpi"><div class="l">Total</div><div class="v">{total}</div></div>
<div class="kpi critical"><div class="l">Critical</div><div class="v">{c_critical}</div></div>
<div class="kpi high"><div class="l">High</div><div class="v">{c_high}</div></div>
<div class="kpi medium"><div class="l">Medium</div><div class="v">{c_medium}</div></div>
<div class="kpi low"><div class="l">Low</div><div class="v">{c_low}</div></div>
<div class="kpi accepted"><div class="l">Aceptados</div><div class="v">{c_accepted}</div></div>
</div>
{body}
<p class="note">Matched secrets are redacted. Treat any flagged credential as
compromised: rotate it and purge it from version-control history.</p>
<footer>Vulnerability Scanner · Secrets module · {generated_at}</footer>
</div></body></html>"""

def _safe(s: str) -> str:
    import html as _html
    return _html.escape(str(s))

def render_secrets_html(result: dict) -> str:
    import html as _html
    findings = result.get("findings", [])
    if findings:
        rows = []
        for f in findings:
            engine_txt = str(f.get("engine", ""))
            if f.get("cross_validated"):
                engine_txt += " ✓"
            reuse = f.get("reused_elsewhere")
            reuse_badge = (f"<span class='badge-reuse'>🔁 en {reuse} lugar(es) más</span>"
                           if reuse else "")
            rows.append(
                "<tr>"
                f"<td><span class='sev {f['severity']}'>{f['severity']}</span></td>"
                f"<td>{_html.escape(f.get('secret_type', f.get('rule','')))}{reuse_badge}</td>"
                f"<td><code>{_html.escape(str(f['file']))}</code></td>"
                f"<td>{f.get('line','?')}</td>"
                f"<td><code>{_html.escape(str(f.get('match','')))}</code></td>"
                f"<td><code>{_html.escape(engine_txt)}</code></td>"
                "</tr>")
        body = ("<table><thead><tr><th>Severity</th><th>Type</th><th>File</th>"
                "<th>Line</th><th>Secret (redacted)</th><th>Engine</th></tr></thead>"
                "<tbody>" + "".join(rows) + "</tbody></table>")
    else:
        body = ("<div class='empty'>No hard-coded secrets detected. "
                "Nothing to rotate — nice.</div>")
    counts = result.get("counts", {})
    return _SECRETS_HTML.format(
        generated_at=result.get("generated_at", ""),
        engine=result.get("engine", ""),
        target=_safe(result.get("target", "")),
        scanned_files=result.get("scanned_files", 0),
        total=result.get("total", 0),
        c_critical=counts.get("critical", 0), c_high=counts.get("high", 0),
        c_medium=counts.get("medium", 0), c_low=counts.get("low", 0),
        c_accepted=result.get("baseline_suppressed_count", 0),
        body=body)

def write_secrets_report(result: dict, out_dir) -> Path:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "secrets.json").write_text(
        json.dumps(result, indent=2), encoding="utf-8")
    html_path = out_dir / "secrets.html"
    html_path.write_text(render_secrets_html(result), encoding="utf-8")
    return html_path

class _SecretsPanelMixin:
    def _secret_card(self, parent, finding: dict, accepted: bool = False):
        sev = finding.get("severity", "low")
        stype = finding.get("secret_type", finding.get("rule", "Secret")) or "Secret"
        if finding.get("reused_elsewhere"):
            stype += f"  🔁 en {finding['reused_elsewhere']} lugar(es) más"
        file, line = finding.get("file", "—"), finding.get("line", "?")
        redacted = finding.get("match", "")

        card = tk.Frame(parent, bg=T["panel_bg"], highlightthickness=0, highlightbackground=T["border"])
        card.pack(fill="x", pady=(0, 2))
        tk.Frame(card, bg=(T["muted"] if accepted else T["border"]), width=4).pack(side="left", fill="y")
        body = tk.Frame(card, bg=T["panel_bg"], padx=3, pady=2); body.pack(side="left", fill="both", expand=True)
        top = tk.Frame(body, bg=T["panel_bg"]); top.pack(fill="x")
        tk.Label(top, text="🔑", font=(_FUI, 10), bg=T["panel_bg"], fg=T["muted"]).pack(side="left", padx=(0, 2))
        tk.Label(top, text=stype, font=(_FUI_TITLE, 13, "bold"), bg=T["panel_bg"], fg=T["card_fg"]).pack(side="left")
        tk.Label(top, text=_sev_norm(sev).upper(), font=(_FUI, 12, "bold"),
                 bg=T["panel_bg"], fg=self._sev_brand_color(sev)).pack(side="right")

        action = tk.Label(top, text=("↩ Deshacer" if accepted else "✓ Aceptar"),
                          font=(_FUI, 10, "bold"), bg=T["panel_bg"], fg=T["accent"], cursor="hand2")
        action.pack(side="right", padx=(0, 2))
        action.bind("<Button-1>", lambda _e, f=finding, acc=accepted:
                    self._on_secret_accept_toggle(f, acc))
        self._lbl(body, f"📄 {file}   :   {line}", size=12, fg=T["card_fg"], anchor="w").pack(fill="x", pady=(1, 0))
        if accepted and finding.get("baseline_note"):
            self._lbl(body, f"📝 {finding['baseline_note']}", size=12, fg=T["card_fg"],
                      anchor="w").pack(fill="x", pady=(1, 0))
        if redacted:
            tk.Label(body, text=redacted, font=(_FMONO, 12), bg=T["surface2"], fg=T["card_fg"],
                     anchor="w", padx=2, pady=1).pack(fill="x", pady=(1, 0))

    def _on_secret_accept_toggle(self, finding: dict, currently_accepted: bool):
        """Click handler behind each card's Aceptar/Deshacer label."""
        target = getattr(self, "_secrets_target", None)
        if not target:
            messagebox.showinfo("Aceptar hallazgo",
                                "Ejecute un escaneo de Secretos primero — no hay una carpeta "
                                "objetivo activa a la cual asociar esta decisión.")
            return
        active = list(getattr(self, "_secrets_active", []))
        baseline = list(getattr(self, "_secrets_baseline", []))
        try:
            if currently_accepted:
                fp = _finding_fingerprint(finding)
                remove_baseline_entry(target, fp)
                baseline = [f for f in baseline if f is not finding]
                restored = {k: v for k, v in finding.items() if k != "baseline_note"}
                active.append(restored)
            else:
                from tkinter import simpledialog
                note = simpledialog.askstring(
                    "Aceptar hallazgo",
                    "Nota opcional (por qué se acepta este hallazgo):",
                    parent=self) or ""
                save_baseline_entry(target, finding, note)
                active = [f for f in active if f is not finding]
                accepted_copy = dict(finding); accepted_copy["baseline_note"] = note
                baseline.append(accepted_copy)
        except Exception as e:
            messagebox.showerror("Aceptar hallazgo", f"No se pudo guardar la decisión: {e!r}")
            return
        self._render_secrets(active, target=target, baseline_suppressed=baseline)

    def _render_secrets(self, findings, target=None, baseline_suppressed=None):
        box = self._secrets_box
        for w in box.winfo_children(): w.destroy()
        findings = list(findings or [])
        baseline_suppressed = list(baseline_suppressed or [])
        self._secrets_target = target
        self._secrets_active = findings
        self._secrets_baseline = baseline_suppressed
        worst = "info"
        if not findings and not baseline_suppressed:
            self._lbl(box, "Sin secretos — ejecute un escaneo.", size=12, fg=T["card_fg"], anchor="w").pack(fill="x")
        else:
            if not findings:
                self._lbl(box, "Sin hallazgos activos — todo lo detectado fue aceptado.",
                          size=12, fg=T["card_fg"], anchor="w").pack(fill="x", pady=(0, 2))
            for f in findings:
                sev = _sev_norm(f.get("severity"))
                if _SEV_RANK[sev] > _SEV_RANK[worst]: worst = sev
                self._secret_card(box, f, accepted=False)
            if baseline_suppressed:
                self._build_baseline_toggle(box, baseline_suppressed)
        self._set_panel_summary(self._secrets_summary, len(findings), worst)

    def _build_baseline_toggle(self, box, baseline_suppressed):
        """Collapsible 'N aceptado(s) — ver/deshacer' link under the active findings, so accepted-risk items stay reachab…"""
        state = {"open": False}
        link_row = tk.Frame(box, bg=T["panel_bg"]); link_row.pack(fill="x", pady=(2, 0))
        body = tk.Frame(box, bg=T["panel_bg"])

        def _label_text():
            arrow = "▾" if state["open"] else "▸"
            return f"{arrow} {len(self._secrets_baseline)} aceptado(s) — ver / deshacer"

        link = tk.Label(link_row, text=_label_text(), font=(_FUI, 12, "bold"),
                        bg=T["panel_bg"], fg=T["card_fg"], cursor="hand2")
        link.pack(side="left")

        def _redraw_body():
            for w in body.winfo_children(): w.destroy()
            if state["open"]:
                for f in self._secrets_baseline:
                    self._secret_card(body, f, accepted=True)
                body.pack(fill="x", pady=(1, 0))
            else:
                body.pack_forget()

        def _toggle(_e=None):
            state["open"] = not state["open"]
            link.config(text=_label_text())
            _redraw_body()

        link.bind("<Button-1>", _toggle)

    def _build_secrets_panel(self, parent) -> "tk.Frame":
        """Builds the standalone SECRETOS results panel (summary pill + alert-card box) and returns its outer wrap frame."""
        secrets_wrap = tk.Frame(parent, bg=T["bg"])
        sec_inner, sec_right = self._panel(secrets_wrap, "Secretos", pady=(0, 0))
        self._secrets_summary = tk.Label(sec_right, text="sin hallazgos", font=(_FUI, 12, "bold"),
                                         bg=T["pill_idle_bg"], fg=T["pill_idle_fg"]); self._secrets_summary.pack(side="right")
        self._secrets_box = tk.Frame(sec_inner, bg=T["panel_bg"]); self._secrets_box.pack(fill="both", expand=True)
        self._lbl(self._secrets_box, "Sin secretos — ejecute un escaneo.", size=12, fg=T["card_fg"], anchor="w").pack(fill="x")
        return secrets_wrap

if __name__ == "__main__":
    tgt = sys.argv[1] if len(sys.argv) > 1 else "."
    st = ensure_git_secrets(print)
    res = scan_path(tgt, print, git_secrets_status=st)
    out = write_secrets_report(res, Path(tgt) / "_secrets_out")
    print("secrets report:", out)
    print(f"providers loaded: {len(_PROVIDERS)} + entropy fallback + "
          f"{len(_SENSITIVE_FILENAME_PATTERNS)} filename heuristics")
    if res.get("baseline_suppressed_count"):
        print(f"baseline-accepted (hidden): {res['baseline_suppressed_count']} "
              f"— see {Path(tgt) / _BASELINE_FILENAME}")
    reused = sum(1 for f in res.get("findings", []) if f.get("reused_elsewhere"))
    if reused:
        print(f"findings reused elsewhere: {reused} (same value seen in >1 spot)")
