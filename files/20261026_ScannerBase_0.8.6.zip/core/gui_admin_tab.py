"""Sección «Administración» (solo administradores), diálogo «Motores» (todos los usuarios) y la política de
administración (antes admin_policy.py).

Política — archivo admin_policy.json junto al programa. Lo edita un administrador desde «Administración» (visible solo
para los usuarios de Windows listados en «admins») y se distribuye con el programa. Controla:
  · Qué aplicaciones usan Probely (5 licencias) y la clave de API. El usuario final nunca ve ni captura la clave:
    las demás aplicaciones escanean con ZAP + Nuclei automáticamente.
  · Versiones fijadas de los motores y un espejo interno de descargas (para redes que bloquean GitHub).
  · Espejos de las bases de datos de Trivy.

Nota de seguridad: es un control de gobierno de la interfaz, no un control de acceso fuerte — la clave de Probely viaja
en el archivo para que las aplicaciones asignadas puedan escanear desde la máquina del desarrollador. Use una clave de
Probely con el rol mínimo necesario.
"""
from __future__ import annotations

from ui_common import *
import tool_manager as tm


class admin_policy:
    """Espacio de nombres de la política. Uso: ``from gui_admin_tab import admin_policy`` → admin_policy.load()."""
    POLICY_FILE = APP_DIR / "admin_policy.json"
    DEFAULT_ADMINS = [SUPPORT_EMAIL.split("@")[0]]
    _DEFAULT = {"version": 1, "admins": DEFAULT_ADMINS,
                "probely": {"api_key": "", "apps": [], "fallback_open_source": True, "max_apps": 5},
                "tools": {"versions": {}, "mirror_base": ""},
                "trivy": {"db_repository": "", "java_db_repository": "", "checks_bundle_repository": ""},
                "updated_by": "", "updated_at": ""}
    _cache: dict = {"mtime": None, "data": None}
    _lock = threading.Lock()

    @staticmethod
    def _merge(base: dict, over: dict) -> dict:
        out = dict(base)
        for k, v in (over or {}).items():
            out[k] = admin_policy._merge(base[k], v) if isinstance(v, dict) and isinstance(base.get(k), dict) else v
        return out

    @staticmethod
    def load() -> dict:
        P = admin_policy
        with P._lock:
            try:
                mt = P.POLICY_FILE.stat().st_mtime
            except OSError:
                mt = None
            if P._cache["data"] is not None and P._cache["mtime"] == mt:
                return P._cache["data"]
            data = P._merge(P._DEFAULT, read_json(P.POLICY_FILE, {}) or {}) if mt else P._merge(P._DEFAULT, {})
            P._cache.update(mtime=mt, data=data)
            return data

    @staticmethod
    def save(data: dict, actor: str = "") -> None:
        P = admin_policy
        data = P._merge(P._DEFAULT, data)
        data.update(updated_by=actor or detect_user(), updated_at=now_human())
        write_json(P.POLICY_FILE, data)
        with P._lock:
            P._cache.update(mtime=None, data=None)

    @staticmethod
    def is_admin(user: str = "") -> bool:
        if os.environ.get("BBSCANNER_ADMIN", "").strip() == "1":
            return True
        u = (user or detect_user()).lower()
        return u in {a.strip().lower() for a in admin_policy.load().get("admins") or [] if a.strip()}

    @staticmethod
    def probely_key() -> str:
        return (admin_policy.load().get("probely") or {}).get("api_key", "").strip()

    @staticmethod
    def _app_keys(app: Optional[dict]) -> set:
        if not app:
            return set()
        return {str(app.get("id", "")).lower(), str(app.get("name", "")).lower()} - {""}

    @staticmethod
    def probely_enabled_for(app: Optional[dict]) -> bool:
        p = admin_policy.load().get("probely") or {}
        allowed = {str(a).lower() for a in p.get("apps") or []}
        return bool(p.get("api_key", "").strip()) and bool(admin_policy._app_keys(app) & allowed)

    @staticmethod
    def probely_fallback() -> bool:
        return bool((admin_policy.load().get("probely") or {}).get("fallback_open_source", True))

    @staticmethod
    def engine_label(app: Optional[dict]) -> tuple[str, str]:
        """(clave, texto) del motor web/API que usará la aplicación activa."""
        if admin_policy.probely_enabled_for(app):
            return "probely", "Probely · asignado por Ciberseguridad"
        return "oss", "ZAP + Nuclei · código abierto"


class _AdminTabMixin:
    # ── Diálogo «Motores» (visible para todos) ──────────────────────────────
    def _show_engines_popup(self):
        popup = self._popup("Motores de escaneo")
        self._popup_hdr(popup, "Motores de escaneo", subtitle="Herramientas de código abierto que se descargan y "
                        "verifican automáticamente la primera vez que se usan.")
        body = tk.Frame(popup, bg=T["bg"], padx=px(24), pady=px(4))
        body.pack(fill="both", expand=True)
        rows_box = tk.Frame(body, bg=T["bg"])
        rows_box.pack(fill="x")
        status = tk.Label(body, text="", font=(FUI, 10), bg=T["bg"], fg=T["muted"], anchor="w", justify="left",
                          wraplength=px(620))
        status.pack(fill="x", pady=(px(10), 0))

        def paint(statuses):
            if not rows_box.winfo_exists():
                return
            for w in rows_box.winfo_children():
                w.destroy()
            for st in statuses:
                row = tk.Frame(rows_box, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"])
                row.pack(fill="x", pady=(0, px(6)))
                inner = tk.Frame(row, bg=T["panel_bg"], padx=px(14), pady=px(10))
                inner.pack(fill="x")
                dot = T["ok"] if st.installed else T["muted"]
                tk.Label(inner, text="●", font=(FUI, 11), bg=T["panel_bg"], fg=dot).pack(side="left", padx=(0, px(10)))
                col = tk.Frame(inner, bg=T["panel_bg"])
                col.pack(side="left", fill="x", expand=True)
                tk.Label(col, text=st.label, font=(FUI, 11, "bold"), bg=T["panel_bg"], fg=T["text"],
                         anchor="w").pack(fill="x")
                tk.Label(col, text=tm.PURPOSE[st.key], font=(FUI, 10), bg=T["panel_bg"], fg=T["muted"],
                         anchor="w").pack(fill="x")
                tk.Label(inner, text=st.detail + (f" · {st.source}" if st.installed and st.source else ""),
                         font=(FUI, 10), bg=T["panel_bg"], fg=T["ok"] if st.installed else T["muted"]).pack(side="right")

        def refresh():
            def work():
                sts = tm.all_status()
                self._ui(paint, sts)
                self._ui(self._apply_engine_cache, sts)
            threading.Thread(target=work, daemon=True).start()

        def install_all():
            status.config(text="Preparando motores… el progreso se muestra en la consola.", fg=T["muted"])

            def work():
                errs = {}
                for k in tm.INSTALLABLE:
                    try:
                        tm.ensure(k, self._emit_log)
                    except Exception as e:
                        errs[k] = str(e)
                self._ui(lambda: status.winfo_exists() and status.config(
                    text=("Todos los motores están listos ✓" if not errs else
                          "Algunos motores no se pudieron preparar:\n" + "\n".join(f"· {tm.LABELS[k]}: {v[:160]}"
                                                                                 for k, v in errs.items())),
                    fg=T["ok"] if not errs else T["warn"]))
                self._ui(refresh)
            self._run_async(work, "preparar motores", busy_attr="_tools_busy")
        paint([tm.ToolStatus(k, tm.LABELS[k], detail="verificando…") for k in tm.ORDER])
        refresh()
        tk.Label(body, text="No se requiere Docker ni permisos de administrador. Las descargas se verifican con SHA-256 "
                 f"y se guardan en «{TOOLS_DIR.name}» dentro de la carpeta del programa.", font=(FUI, 10), bg=T["bg"],
                 fg=T["muted"], justify="left", anchor="w", wraplength=px(620)).pack(fill="x", pady=(px(6), 0))
        self._popup_foot(popup, ("Cerrar", popup.close), ("↻  Actualizar estado", refresh),
                         ("📥  Preparar todos ahora", install_all))

    def _engines_summary(self) -> tuple[str, str]:
        sts = getattr(self, "_engine_cache", None)
        if not sts:
            return "checking", "Motores: verificando…"
        ready = sum(1 for s in sts if s.installed)
        return ("auth" if ready == len(sts) else "checking" if ready else "unauth"), \
            f"Motores: {ready}/{len(sts)} listos — clic para ver"

    def _refresh_engine_cache(self):
        def work():
            try:
                sts = tm.all_status()
            except Exception:
                sts = []
            self._ui(self._apply_engine_cache, sts)
        threading.Thread(target=work, daemon=True).start()

    def _apply_engine_cache(self, sts):
        self._engine_cache = sts
        self._paint_badges()
        for hook in ("_refresh_scan_btn", "_refresh_engine_cards"):
            if callable(fn := getattr(self, hook, None)):
                fn()

    # ── Página «Administración» ─────────────────────────────────────────────
    def _build_tab_admin(self, parent):
        pad = self._scrollable(parent)
        pol = admin_policy.load()
        self._admin_vars = v = {
            "admins": tk.StringVar(value=", ".join(pol.get("admins") or [])),
            "key": tk.StringVar(value=(pol.get("probely") or {}).get("api_key", "")),
            "fallback": tk.BooleanVar(value=bool((pol.get("probely") or {}).get("fallback_open_source", True))),
            "mirror": tk.StringVar(value=(pol.get("tools") or {}).get("mirror_base", "")),
            "db": tk.StringVar(value=(pol.get("trivy") or {}).get("db_repository", "")),
            "javadb": tk.StringVar(value=(pol.get("trivy") or {}).get("java_db_repository", "")),
            "checks": tk.StringVar(value=(pol.get("trivy") or {}).get("checks_bundle_repository", "")),
        }
        self._admin_versions = {k: tk.StringVar(value=str((pol.get("tools") or {}).get("versions", {}).get(k, "")))
                                for k in tm.PINNED}
        self._admin_apps = {str(a).lower() for a in (pol.get("probely") or {}).get("apps") or []}
        bar = tk.Frame(pad, bg=T["bg"])
        bar.pack(fill="x", pady=(0, CARD_GAP))
        PillButton(bar, "Guardar política", self._admin_save, icon="save", variant="primary").pack(side="left")
        self._btn(bar, "📂  Abrir carpeta del programa", lambda: open_path(APP_DIR)).pack(side="left", padx=(px(8), 0))
        self._admin_meta = tk.Label(bar, text=self._admin_meta_text(pol), font=(FUI, 10), bg=T["bg"], fg=T["muted"])
        self._admin_meta.pack(side="right")
        cols = tk.Frame(pad, bg=T["bg"])
        cols.pack(fill="both", expand=True)
        cols.columnconfigure(0, weight=3, uniform="adm")
        cols.columnconfigure(1, weight=2, uniform="adm")
        left, right = tk.Frame(cols, bg=T["bg"]), tk.Frame(cols, bg=T["bg"])
        left.grid(row=0, column=0, sticky="nsew", padx=(0, CARD_GAP // 2))
        right.grid(row=0, column=1, sticky="nsew", padx=(CARD_GAP // 2, 0))
        # Probely
        c = self._card(left, "Probely — asignación de licencias", collapsible=False)
        self._lbl(c, "Solo las aplicaciones marcadas escanean Web/API con Probely. El resto usa ZAP + Nuclei. La clave "
                  "nunca se muestra a los usuarios.", size=10, fg=T["muted"], anchor="w", justify="left",
                  wraplength=px(560)).pack(fill="x", pady=(0, px(10)))
        kr = tk.Frame(c, bg=T["panel_bg"])
        kr.pack(fill="x")
        self._lbl(kr, "Clave de API", size=10, bold=True, fg=T["muted"]).pack(anchor="w")
        er = tk.Frame(kr, bg=T["panel_bg"])
        er.pack(fill="x", pady=(px(2), 0))
        entry = ttk.Entry(er, textvariable=v["key"], show="•")
        entry.pack(side="left", fill="x", expand=True)
        show = tk.BooleanVar(value=False)
        ToggleSwitch(er, text="Mostrar", variable=show,
                     command=lambda: entry.config(show="" if show.get() else "•")).pack(side="left", padx=(px(10), 0))
        self._btn(er, "✓  Validar", self._admin_validate_probely).pack(side="left", padx=(px(10), 0))
        self._admin_key_status = tk.Label(c, text="", font=(FUI, 10), bg=T["panel_bg"], fg=T["muted"], anchor="w",
                                          justify="left", wraplength=px(560))
        self._admin_key_status.pack(fill="x", pady=(px(6), px(10)))
        hdr = tk.Frame(c, bg=T["panel_bg"])
        hdr.pack(fill="x")
        self._lbl(hdr, "Aplicaciones con Probely", size=10, bold=True, fg=T["muted"]).pack(side="left")
        self._admin_count = tk.Label(hdr, text="", font=(FUI, 10, "bold"), bg=T["panel_bg"], fg=T["text"])
        self._admin_count.pack(side="right")
        box = tk.Frame(c, bg=T["panel_bg"])
        box.pack(fill="both", expand=True, pady=(px(4), 0))
        self._admin_tree = make_tree(box, ("on", "name", "env", "crit"), [("", 40, "center", False),
                                                                          ("Aplicación", 220), ("Entorno", 120),
                                                                          ("Criticidad", 150)], 9)
        self._admin_tree.bind("<Double-1>", lambda _e: self._admin_toggle_app())
        self._admin_tree.bind("<space>", lambda _e: self._admin_toggle_app())
        self._lbl(c, "Doble clic o barra espaciadora para asignar / quitar.", size=9, fg=T["muted"]).pack(
            anchor="w", pady=(px(4), 0))
        tip(ToggleSwitch(c, text="Si Probely falla o no hay licencia libre, usar ZAP + Nuclei automáticamente",
                         variable=v["fallback"]), "Desactivado, el escaneo web/API de una aplicación asignada falla "
                         "si Probely no responde (útil si el resultado debe venir siempre de Probely).").pack(
            anchor="w", pady=(px(10), 0))
        self._admin_fill_apps()
        # Motores
        c = self._card(left, "Motores de código abierto", collapsible=False)
        box = tk.Frame(c, bg=T["panel_bg"])
        box.pack(fill="both", expand=True)
        self._admin_tools = make_tree(box, ("tool", "purpose", "state", "pinned"), [
            ("Motor", 140), ("Uso", 280), ("Estado", 150), ("Versión fijada", 110)], len(tm.ORDER))
        brow = tk.Frame(c, bg=T["panel_bg"])
        brow.pack(fill="x", pady=(px(8), 0))
        self._btn(brow, "📥  Instalar / actualizar", self._admin_tool_install).pack(side="left")
        self._btn(brow, "↻  Refrescar", self._admin_tools_refresh).pack(side="left", padx=(px(8), 0))
        PillButton(brow, "Eliminar", self._admin_tool_remove, icon="delete", variant="danger_ghost").pack(side="right")
        self._admin_tools_refresh()
        # Columna derecha
        c = self._card(right, "Administradores", collapsible=False)
        self._lbl(c, "Usuarios de Windows (separados por coma) que ven esta sección.", size=10, fg=T["muted"],
                  anchor="w", justify="left", wraplength=px(380)).pack(fill="x")
        ttk.Entry(c, textvariable=v["admins"]).pack(fill="x", pady=(px(6), px(4)))
        self._lbl(c, f"Usuario actual: {self._user}", size=9, fg=T["muted"]).pack(anchor="w")
        c = self._card(right, "Versiones fijadas", collapsible=False)
        self._lbl(c, "Vacío = versión probada por defecto. Las versiones comprometidas conocidas se bloquean siempre.",
                  size=10, fg=T["muted"], anchor="w", justify="left", wraplength=px(380)).pack(fill="x", pady=(0, px(6)))
        grid = tk.Frame(c, bg=T["panel_bg"])
        grid.pack(fill="x")
        grid.columnconfigure(1, weight=1)
        for i, k in enumerate(tm.PINNED):
            self._lbl(grid, tm.LABELS[k], size=10).grid(row=i, column=0, sticky="w", pady=px(3), padx=(0, px(10)))
            e = ttk.Entry(grid, textvariable=self._admin_versions[k], width=12)
            e.grid(row=i, column=1, sticky="ew", pady=px(3))
            self._lbl(grid, f"por defecto {tm.PINNED[k]}", size=9, fg=T["muted"]).grid(row=i, column=2, sticky="w",
                                                                                       padx=(px(8), 0))
        c = self._card(right, "Red corporativa", collapsible=False)
        for label, key, hint in (("Espejo interno de descargas", "mirror",
                                  "URL base con los mismos nombres de archivo que GitHub (p. ej. Artifactory)."),
                                 ("Trivy — base de vulnerabilidades", "db", "p. ej. registro.interno/aquasec/trivy-db:2"),
                                 ("Trivy — base Java", "javadb", "p. ej. registro.interno/aquasec/trivy-java-db:1"),
                                 ("Trivy — paquete de reglas IaC", "checks", "p. ej. registro.interno/aquasec/trivy-checks:1")):
            self._lbl(c, label, size=10, bold=True, fg=T["muted"]).pack(anchor="w", pady=(px(6), 0))
            ttk.Entry(c, textvariable=v[key]).pack(fill="x", pady=(px(2), 0))
            self._lbl(c, hint, size=9, fg=T["muted"], anchor="w", justify="left", wraplength=px(380)).pack(fill="x")

    @staticmethod
    def _admin_meta_text(pol) -> str:
        return f"Última modificación: {pol.get('updated_by')} · {pol.get('updated_at')}" if pol.get("updated_at") else \
            "Política aún no guardada"

    def _admin_fill_apps(self):
        tree = getattr(self, "_admin_tree", None)
        if tree is None or not tree.winfo_exists():
            return
        clear_tree(tree)
        n = 0
        for a in sorted(self._inv_store.list_apps(), key=lambda a: a.get("name", "").lower()):
            on = bool({str(a.get("id", "")).lower(), str(a.get("name", "")).lower()} & self._admin_apps)
            n += on
            tree.insert("", "end", iid=a["id"], values=("●" if on else "", a.get("name", ""), a.get("environment", ""),
                                                         a.get("criticality", "")), tags=(stripe(tree),))
        maxa = (admin_policy.load().get("probely") or {}).get("max_apps", 5)
        self._admin_count.config(text=f"{n} / {maxa} licencias", fg=T["err"] if n > maxa else T["text"])

    def _admin_toggle_app(self):
        sel = self._admin_tree.selection()
        if not sel:
            return
        app = self._inv_store.get_app(sel[0]) or {}
        keys = {str(app.get("id", "")).lower(), str(app.get("name", "")).lower()} - {""}
        if keys & self._admin_apps:
            self._admin_apps -= keys
        else:
            maxa = (admin_policy.load().get("probely") or {}).get("max_apps", 5)
            current = sum(1 for a in self._inv_store.list_apps()
                          if {str(a.get("id", "")).lower(), str(a.get("name", "")).lower()} & self._admin_apps)
            if current >= maxa:
                return self._toast(f"Límite de {maxa} licencias alcanzado — quite una aplicación primero", "warn")
            self._admin_apps.add(str(app.get("name", "")).lower())
        self._admin_fill_apps()
        self._admin_tree.selection_set(sel[0])

    def _admin_validate_probely(self):
        key = self._admin_vars["key"].get().strip()
        if not key:
            return self._admin_key_status.config(text="Ingrese una clave.", fg=T["warn"])
        self._admin_key_status.config(text="Validando…", fg=T["muted"])

        def work():
            from probely_engine import check_snyk_api_web
            from web_common import ScanConfig
            try:
                ok, msg = check_snyk_api_web(ScanConfig(probely_token=key), self._emit_log)
            except Exception as e:
                ok, msg = False, repr(e)
            self._ui(lambda: self._admin_key_status.winfo_exists() and self._admin_key_status.config(
                text=("✓  " if ok else "✕  ") + msg, fg=T["ok"] if ok else T["err"]))
            self._ui(self._set_probely_status, "auth" if ok else "unauth")
        threading.Thread(target=work, daemon=True).start()

    def _admin_save(self):
        v = self._admin_vars
        pol = admin_policy.load()
        admins = [a.strip() for a in v["admins"].get().split(",") if a.strip()]
        if self._user.lower() not in {a.lower() for a in admins} and os.environ.get("BBSCANNER_ADMIN") != "1":
            return self._show_warn_popup("Guardar política", "Su usuario no está en la lista de administradores: al "
                                         "guardar perdería el acceso a esta sección. Agréguelo antes de guardar.")
        versions = {k: var.get().strip().lstrip("v") for k, var in self._admin_versions.items() if var.get().strip()}
        for k, ver in versions.items():
            if ver in tm.BLOCKED.get(k, set()):
                return self._show_error_popup("Versión bloqueada", f"{tm.LABELS[k]} {ver} es una versión comprometida "
                                              "conocida y no se puede fijar.")
        names = {str(a.get("id", "")).lower(): a.get("name", "") for a in self._inv_store.list_apps()}
        apps = sorted({names.get(a, a) for a in self._admin_apps}, key=str.lower)
        pol = {**pol, "admins": admins,
               "probely": {**pol.get("probely", {}), "api_key": v["key"].get().strip(), "apps": apps,
                           "fallback_open_source": bool(v["fallback"].get())},
               "tools": {"versions": versions, "mirror_base": v["mirror"].get().strip()},
               "trivy": {"db_repository": v["db"].get().strip(), "java_db_repository": v["javadb"].get().strip(),
                         "checks_bundle_repository": v["checks"].get().strip()}}
        try:
            admin_policy.save(pol, actor=self._user)
        except Exception as e:
            return self._show_error_popup("Guardar política", f"No se pudo escribir {admin_policy.POLICY_FILE}:\n{e!r}")
        audit(self._reports_var.get(), "admin_policy_saved", actor=self._user, probely_apps=apps,
              versions=versions, log=self._emit_log)
        self._admin_meta.config(text=self._admin_meta_text(admin_policy.load()))
        self._toast("Política guardada — distribuya admin_policy.json con el programa", "ok")
        self._refresh_engine_badge_text()
        if hasattr(self, "_refresh_engine_cards"):
            self._refresh_engine_cards()

    def _admin_tools_refresh(self):
        tree = getattr(self, "_admin_tools", None)
        if tree is None or not tree.winfo_exists():
            return

        def work():
            sts = tm.all_status()

            def paint():
                if not tree.winfo_exists():
                    return
                clear_tree(tree)
                for st in sts:
                    tree.insert("", "end", iid=st.key, tags=(stripe(tree),), values=(
                        st.label, tm.PURPOSE[st.key], ("✓ " if st.installed else "") + st.detail, tm.PINNED[st.key]))
                self._apply_engine_cache(sts)
            self._ui(paint)
        threading.Thread(target=work, daemon=True).start()

    def _admin_tool_install(self):
        sel = self._admin_tools.selection()
        keys = list(sel) or list(tm.INSTALLABLE)

        def work():
            for k in keys:
                try:
                    tm.ensure(k, self._emit_log, force=bool(sel))
                except Exception as e:
                    self._emit_log(f"[motores] {tm.LABELS[k]}: {e}")
            self._ui(self._admin_tools_refresh)
        self._run_async(work, "instalar motores", busy_attr="_tools_busy")

    def _admin_tool_remove(self):
        sel = self._admin_tools.selection()
        if not sel:
            return self._toast("Seleccione un motor de la lista", "warn")
        self._show_confirm_popup("Eliminar motor", f"¿Eliminar {tm.LABELS[sel[0]]} de la carpeta de herramientas? Se "
                                 "volverá a descargar al siguiente escaneo que lo necesite.",
                                 on_yes=lambda: (tm.remove(sel[0], self._emit_log), self._admin_tools_refresh()),
                                 yes_label="🗑  Eliminar", no_label="Cancelar")
