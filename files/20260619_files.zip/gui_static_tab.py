from __future__ import annotations

"""ScannerApp mixin: the Static tab (SCA + SAST + Secrets) -- target path management, the independent 'static lane' scan runner (separate busy/cancel state from the main pipeline so it can run concurrently with DAST/API), and findings-tree rendering for all three static engines.

Lives in its own file purely for editor sanity -- this is still
logically part of Snyk_Scanner_GUI.py: it shares that module's globals
(T, fonts, helper functions, the runtime-injected engine calls) via
_wire_mixin_globals(), the same trick _load_runtime() already uses to
pull static_scanner/dast_api/report_engine symbols into this module.
Do not import this file standalone or instantiate this class on its
own -- it has no meaning outside being mixed into ScannerApp."""

class _StaticTabMixin:
    def _sev_brand_color(self, sev):
        sev = _sev_norm(sev)
        if sev in ("critical", "high"): return T["err"]     # brand red
        if sev == "medium":             return T["accent"]  # brand gold
        return T["muted"]                                   # low / info

    def _sev_leaf_tag(self, sev):
        sev = _sev_norm(sev)
        if sev in ("critical", "high"): return "crit"
        if sev == "medium":             return "med"
        return "muted"

    def _apply_group_tags(self, tree):
        tree.tag_configure("group", foreground=T["text"], font=(_FUI, 10, "bold"))
        tree.tag_configure("crit",  foreground=T["err"])
        tree.tag_configure("med",   foreground=T["text"])
        tree.tag_configure("muted", foreground=T["muted"])

    def _group_tree(self, parent, tree_col, cols, headings, height):
        """A collapsible 2-level tree (group → findings) with brand chrome."""
        outer = tk.Frame(parent, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["accent"])
        outer.pack(fill="both", expand=True)
        tk.Frame(outer, bg=T["accent"], height=2).pack(fill="x", side="top")
        tf = tk.Frame(outer, bg=T["panel_bg"]); tf.pack(fill="both", expand=True)
        tree = ttk.Treeview(tf, columns=cols, show="tree headings", height=height)
        tcol_txt, tcol_w = tree_col
        tree.heading("#0", text=tcol_txt, anchor="w"); tree.column("#0", width=tcol_w, stretch=True, anchor="w")
        for c, (txt, w, anchor, stretch) in zip(cols, headings):
            tree.heading(c, text=txt, anchor=anchor); tree.column(c, width=w, anchor=anchor, stretch=stretch)
        tree.pack(side="left", fill="both", expand=True)
        ttk.Scrollbar(tf, command=tree.yview, orient="vertical").pack(side="right", fill="y")
        self._apply_group_tags(tree)
        return tree

    def _tree_empty(self, tree, msg="No findings — run a scan."):
        for iid in tree.get_children(): tree.delete(iid)
        tree.insert("", "end", text="  " + msg, tags=("muted",))

    def _set_panel_summary(self, lbl, total, worst):
        if lbl is None: return
        if total == 0:
            lbl.config(text="no findings")
        else:
            lbl.config(text=f"{total} finding{'' if total == 1 else 's'}  ·  worst: {worst.upper()}")

    def _render_sca(self, projects):
        """SCA is about *which dependency to upgrade* — group by package, surface
        the fix version, collapse the individual CVEs underneath."""
        tree = self._static_sca_tree
        for iid in tree.get_children(): tree.delete(iid)
        groups: dict = {}
        for proj in projects or []:
            for i in proj.get("issues", []):
                groups.setdefault(i.get("package", "—"), []).append(i)
        total = 0; worst = "info"
        for pkg in sorted(groups):
            issues = groups[pkg]; total += len(issues)
            gw = "info"; fix = ""
            for i in issues:
                s = _sev_norm(i.get("severity"))
                if _SEV_RANK[s] > _SEV_RANK[gw]: gw = s
                if not fix and i.get("fixedIn") not in (None, "", "—"): fix = str(i.get("fixedIn"))
            if _SEV_RANK[gw] > _SEV_RANK[worst]: worst = gw
            p = tree.insert("", "end", text=f"{pkg}   ({len(issues)})",
                            values=(gw.upper(), ("→ " + fix) if fix else "—"), tags=("group",), open=False)
            for i in issues:
                s = _sev_norm(i.get("severity"))
                fx = i.get("fixedIn"); fx = ("→ " + str(fx)) if fx not in (None, "", "—") else "—"
                tree.insert(p, "end", text="   " + (i.get("title", "") or ""),
                            values=(s.upper(), fx), tags=(self._sev_leaf_tag(s),))
        if total == 0: self._tree_empty(tree)
        self._set_panel_summary(self._sca_summary, total, worst)

    def _render_sast(self, files):
        """SAST is about *where in the code* — group by file (data already is),
        collapse the per-line findings underneath."""
        tree = self._static_sast_tree
        for iid in tree.get_children(): tree.delete(iid)
        total = 0; worst = "info"
        for fobj in files or []:
            issues = fobj.get("issues", [])
            if not issues: continue
            total += len(issues); gw = "info"
            for i in issues:
                s = _sev_norm(i.get("severity"))
                if _SEV_RANK[s] > _SEV_RANK[gw]: gw = s
            if _SEV_RANK[gw] > _SEV_RANK[worst]: worst = gw
            p = tree.insert("", "end", text=f"{fobj.get('file', '—')}   ({len(issues)})",
                            values=(gw.upper(), ""), tags=("group",), open=False)
            for i in issues:
                s = _sev_norm(i.get("severity"))
                tree.insert(p, "end", text="   " + (i.get("title", "") or ""),
                            values=(s.upper(), str(i.get("line", "?"))), tags=(self._sev_leaf_tag(s),))
        if total == 0: self._tree_empty(tree)
        self._set_panel_summary(self._sast_summary, total, worst)

    def _secret_card(self, parent, sev, stype, file, line, redacted):
        card = tk.Frame(parent, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"])
        card.pack(fill="x", pady=(0, 6))
        tk.Frame(card, bg=T["accent"], width=4).pack(side="left", fill="y")
        body = tk.Frame(card, bg=T["panel_bg"], padx=12, pady=8); body.pack(side="left", fill="both", expand=True)
        top = tk.Frame(body, bg=T["panel_bg"]); top.pack(fill="x")
        tk.Label(top, text="🔑", font=(_FUI, 11), bg=T["panel_bg"], fg=T["accent"]).pack(side="left", padx=(0, 6))
        tk.Label(top, text=stype, font=(_FUI, 10, "bold"), bg=T["panel_bg"], fg=T["text"]).pack(side="left")
        tk.Label(top, text=_sev_norm(sev).upper(), font=(_FUI, 9, "bold"),
                 bg=T["panel_bg"], fg=self._sev_brand_color(sev)).pack(side="right")
        self._lbl(body, f"📄 {file}   :   {line}", size=9, fg=T["muted"], anchor="w").pack(fill="x", pady=(2, 0))
        if redacted:
            tk.Label(body, text=redacted, font=(_FMONO, 9), bg=T["surface2"], fg=T["text"],
                     anchor="w", padx=8, pady=3).pack(fill="x", pady=(4, 0))

    def _render_secrets(self, findings):
        """Secrets are few and urgent — one alert card each, redacted value in mono."""
        box = self._secrets_box
        for w in box.winfo_children(): w.destroy()
        findings = findings or []; worst = "info"
        if not findings:
            self._lbl(box, "No secrets found — run a scan.", size=10, fg=T["muted"], anchor="w").pack(fill="x")
        else:
            for s in findings:
                sev = _sev_norm(s.get("severity"))
                if _SEV_RANK[sev] > _SEV_RANK[worst]: worst = sev
                self._secret_card(box, sev,
                                  s.get("secret_type", s.get("rule", "Secret")) or "Secret",
                                  s.get("file", "—"), s.get("line", "?"), s.get("match", ""))
        self._set_panel_summary(self._secrets_summary, len(findings), worst)

    def _build_tab_static(self, parent):
        self._section_header(parent, "🔍  Static Analysis  (SCA · SAST · Secrets)")
        pad = self._scrollable(parent)

        # ── Top row: target path(s) (left half) + run buttons (right half) ───────
        top_row = tk.Frame(pad, bg=T["bg"]); top_row.pack(fill="x", pady=(0, 8))

        fold = self._side_card(top_row, "TARGET  ·  folder(s), file(s), or .csproj")
        # Multi-path listbox + scrollbar
        lb_frame = tk.Frame(fold, bg=T["panel_bg"]); lb_frame.pack(fill="x")
        self._static_paths_lb = tk.Listbox(lb_frame, height=4, font=(_FMONO, 9),
                                           bg=T["surface2"], fg=T["text"], selectmode="extended",
                                           highlightthickness=1, highlightbackground=T["border"],
                                           activestyle="none", selectbackground=T["accent"],
                                           selectforeground=T["button_fg"], relief="flat")
        _sb = ttk.Scrollbar(lb_frame, orient="vertical", command=self._static_paths_lb.yview)
        self._static_paths_lb.configure(yscrollcommand=_sb.set)
        self._static_paths_lb.pack(side="left", fill="both", expand=True)
        _sb.pack(side="right", fill="y")

        # Buttons row for path management
        path_btns = tk.Frame(fold, bg=T["panel_bg"]); path_btns.pack(fill="x", pady=(4, 0))

        def _add_folder():
            initial = self._target_var.get() or str(SCRIPT_DIR)
            d = filedialog.askdirectory(title="Add folder to scan", initialdir=initial)
            if d:
                existing = list(self._static_paths_lb.get(0, "end"))
                if d not in existing:
                    self._static_paths_lb.insert("end", d)
                self._target_var.set(d)  # keep _target_var pointing to last selected
                self._persist_static_paths()

        def _add_files():
            initial = self._target_var.get() or str(SCRIPT_DIR)
            files = filedialog.askopenfilenames(
                title="Add files or .csproj to scan",
                initialdir=initial,
                filetypes=[
                    ("All supported", "*.csproj *.sln *.json *.py *.js *.ts *.cs *.java *.go *.rb *.php"),
                    ("Visual Studio projects", "*.csproj *.sln"),
                    ("Dependency manifests", "*.json *.xml *.lock *.toml *.gradle"),
                    ("Source code", "*.py *.js *.ts *.cs *.java *.go *.rb *.php *.cpp *.c *.h"),
                    ("All files", "*.*"),
                ])
            if files:
                existing = list(self._static_paths_lb.get(0, "end"))
                for f in files:
                    # If it's a .csproj, auto-add the containing folder too
                    p = Path(f)
                    if p.suffix.lower() == ".csproj":
                        folder = str(p.parent)
                        if folder not in existing:
                            self._static_paths_lb.insert("end", folder)
                            existing.append(folder)
                            self._log_line(f"[static] .csproj detected: using folder '{folder}'")
                    else:
                        if f not in existing:
                            self._static_paths_lb.insert("end", f)
                            existing.append(f)
                if files:
                    self._target_var.set(str(Path(files[-1]).parent))
                self._persist_static_paths()

        def _remove_selected():
            # Remove selected items in reverse order to keep indices valid
            sel = list(self._static_paths_lb.curselection())
            for idx in reversed(sel):
                self._static_paths_lb.delete(idx)
            # Update target_var to last remaining
            items = self._static_paths_lb.get(0, "end")
            if items: self._target_var.set(items[-1])
            self._persist_static_paths()

        def _clear_all():
            self._static_paths_lb.delete(0, "end")
            self._target_var.set("")
            self._persist_static_paths()

        # Placeholder text when empty
        def _on_lb_change(*_):
            items = self._static_paths_lb.get(0, "end")
            if not items:
                self._static_paths_lb.insert("end", "  (empty — add folders or files with the buttons below)")
                self._static_paths_lb.itemconfig(0, fg=T["muted"])

        self._btn(path_btns, "📂 + Folder", _add_folder, kind="outline").pack(side="left", padx=(0, 4))
        self._btn(path_btns, "📄 + File(s) / .csproj", _add_files, kind="outline").pack(side="left", padx=(0, 4))
        self._btn(path_btns, "✕ Quitar", _remove_selected, kind="flat").pack(side="left", padx=(0, 4))
        self._btn(path_btns, "🗑 Clear all", _clear_all, kind="flat").pack(side="left")
        # Run Static sits on the far right of the same button row.
        self._static_run_btns = []
        run_btn = self._btn(path_btns, "▶  Run Static",
                            lambda: self._start_static_scan({"sca", "code", "secrets"}), kind="accent")
        run_btn.pack(side="right")
        self._static_run_btns.append(run_btn)

        # Restore the path list saved on a previous run (clean close), falling
        # back to _target_var (e.g. set by an app profile) when nothing was saved.
        _saved_paths = getattr(self, "_saved_static_paths", None)
        if _saved_paths:
            for p in _saved_paths:
                self._static_paths_lb.insert("end", p)
        elif self._target_var.get():
            self._static_paths_lb.insert("end", self._target_var.get())

        # ── RESULTS — each analysis rendered in the form that suits its data ────
        results_row = tk.Frame(pad, bg=T["bg"]); results_row.pack(fill="x", pady=(0, 8))
        sca_half = tk.Frame(results_row, bg=T["bg"]); sca_half.pack(side="left", fill="both", expand=True, padx=(0, 6))
        sast_half = tk.Frame(results_row, bg=T["bg"]); sast_half.pack(side="left", fill="both", expand=True, padx=(6, 0))

        # SCA → grouped by package (the unit you actually upgrade), fix version surfaced.
        sca_inner, sca_right = self._panel(sca_half, "OPEN-SOURCE (SCA)  ·  grouped by package", pady=(0, 0))
        self._sca_summary = tk.Label(sca_right, text="no findings", font=(_FUI, 9, "bold"),
                                     bg=T["accent"], fg=T["button_fg"]); self._sca_summary.pack(side="right")
        self._static_sca_tree = self._group_tree(
            sca_inner, ("Package  /  Vulnerability", 220), ("sev", "fix"),
            [("Severity", 90, "w", False), ("Fix available", 140, "w", False)], height=7)
        self._tree_empty(self._static_sca_tree)

        # SAST → grouped by file (where the weakness lives), line surfaced on each leaf.
        sast_inner, sast_right = self._panel(sast_half, "STATIC CODE (SAST)  ·  grouped by file", pady=(0, 0))
        self._sast_summary = tk.Label(sast_right, text="no findings", font=(_FUI, 9, "bold"),
                                      bg=T["accent"], fg=T["button_fg"]); self._sast_summary.pack(side="right")
        self._static_sast_tree = self._group_tree(
            sast_inner, ("File  /  Finding", 220), ("sev", "line"),
            [("Severity", 90, "w", False), ("Line", 70, "center", False)], height=7)
        self._tree_empty(self._static_sast_tree)

        # Secrets → few + urgent: one alert card each, redacted value in monospace.
        sec_inner, sec_right = self._panel(pad, "SECRETS  ·  exposed credentials", pady=(0, 0))
        self._secrets_summary = tk.Label(sec_right, text="no findings", font=(_FUI, 9, "bold"),
                                         bg=T["accent"], fg=T["button_fg"]); self._secrets_summary.pack(side="right")
        self._secrets_box = tk.Frame(sec_inner, bg=T["panel_bg"]); self._secrets_box.pack(fill="both", expand=True)
        self._lbl(self._secrets_box, "No secrets found — run a scan.", size=10, fg=T["muted"], anchor="w").pack(fill="x")

    def _start_static_scan(self, sel: set):
        if self._static_busy:
            self._log_line("[static] a scan is already running"); return

        # Reflect the static run in the pipeline cards: any of SCA / SAST /
        # Secrets that were de-selected get selected now, so the cards always
        # show what Run Static actually executes (and that becomes the new
        # remembered default).
        changed = False
        for k in ("sca", "code", "secrets"):
            if k in sel:
                var = self._scan_vars.get(k)
                if var is not None and not var.get():
                    var.set(1); changed = True
                apply_fn = getattr(self, "_stage_apply", {}).get(k)
                if apply_fn:
                    try: apply_fn(True)
                    except Exception: pass
        if changed:
            self._refresh_scan_btn(); self._persist_scan_stages()

        # Collect paths from the multi-path listbox
        raw_paths = list(getattr(self, "_static_paths_lb", None) and
                         self._static_paths_lb.get(0, "end") or [])
        # Filter out the placeholder text
        paths = [p for p in raw_paths if p.strip() and not p.strip().startswith("(empty")]
        if not paths:
            # Fallback to _target_var for backward compat (e.g. loaded from app profile)
            tv = self._target_var.get().strip()
            if tv: paths = [tv]
        if not paths:
            self._show_warn_popup("Static analysis",
                "No folders or files selected.\n\n"
                "Use '📂 + Folder' or '📄 + File(s) / .csproj' to add targets."); return

        # Validate paths
        valid_paths = []
        for p in paths:
            pp = Path(p).resolve()
            if pp.exists():
                valid_paths.append(pp)
            else:
                self._log_line(f"[static] ⚠ path not found, skipping: {p}")
        if not valid_paths:
            self._show_warn_popup("Static analysis",
                "None of the selected paths exist on disk.\n\n"
                "Check the paths and try again."); return

        # Use first valid path as the primary target for the scan engine
        # (scan_path supports one dir; for multi-path we run it per-path)
        target = valid_paths[0]
        self._target_var.set(str(target))

        # Store multi-paths for multi-pass scanning
        self._static_scan_paths = valid_paths

        # SCA/SAST need a logged-in Snyk session (the CLI itself is installed at boot).
        if {"sca", "code"} & sel:
            checks = self._checks or {}
            auth_ok = bool(checks.get("auth") and checks["auth"].ok)
            if not auth_ok:
                self._show_warn_popup("Static analysis",
                    "SCA and SAST need an active SSO session in Snyk.\n\n"
                    "Go to the ▶ Scan tab → Prerequisites and click '🔑 Login via SSO'.")
                return
        self._static_run_sel = sel
        for b in getattr(self, "_static_run_btns", []):
            b.config(state="disabled")
        if hasattr(self, "_static_count_lbl"):
            self._static_count_lbl.config(text="Scanning… (" + " + ".join(sorted(sel)).upper() + ")")
        self._run_async(self._static_scan, label="static analysis",
                        busy_attr="_static_busy", done_kind="__static_done__")

    def _static_scan(self):
        """Run the selected folder-based analyses (SCA / SAST / Secrets) through
        the same unified report pipeline used by the Scan-tab pipeline."""
        self._static_cancel_evt.clear()
        sel = getattr(self, "_static_run_sel", {"sca", "code", "secrets"})
        target = Path(self._target_var.get()).resolve()
        reports_root = Path(self._reports_var.get()).resolve(); reports_root.mkdir(parents=True, exist_ok=True)
        active_app = getattr(self, "_active_app", None)
        _report_label, app_reports_root = self._scoped_report_paths(reports_root)
        mode = "+".join(sorted(sel))
        out_dir = app_reports_root / f"report_{_ts()}_{mode}"; out_dir.mkdir(parents=True, exist_ok=True)
        self._session_begin("static", set(sel))   # crash-recovery marker
        import audit_log
        audit_log.write_event(reports_root, "scan_start", actor=self._user,
                              app=(active_app.get("name") if active_app else ""),
                              mode=mode, target=str(target), out_dir=str(out_dir), lane="static",
                              log=self._emit_log)
        self._emit_log(f"[static] pipeline: {mode.upper()}")
        self._emit_log(f"[static] output → {out_dir}")
        _snyk_usable = True
        if {"sca", "code"} & sel:
            try:
                if not ensure_snyk_ready(self._emit_log):
                    _snyk_usable = False
                    self._emit_log("[static] Snyk CLI is not runnable — "
                                   "skipping SCA/SAST. Click Fix to repair it.")
            except Exception as e:
                self._emit_log(f"[static] snyk readiness check error: {e!r}")
        try: v = _run(["snyk", "--version"]).stdout.strip()
        except Exception: v = "?"

        results: dict[str, Any] = {"sca": None, "code": None, "dast": None, "api": None, "secrets": None}
        for k in ("sca", "code", "secrets"):
            running = k in sel and (_snyk_usable or k == "secrets")
            self._event_queue.put(("stage", (k, "running" if running else "skipped")))

        jobs: list[tuple[str, Callable[[], None]]] = []
        if "sca" in sel and _snyk_usable:
            jobs.append(("sca", lambda: results.__setitem__(
                "sca", run_snyk_test(target, out_dir, self._emit_log)[0])))
        if "code" in sel and _snyk_usable:
            jobs.append(("code", lambda: results.__setitem__(
                "code", run_snyk_code(target, out_dir, self._emit_log)[0])))
        if "secrets" in sel:
            def _run_secrets_stage():
                self._emit_log("[secrets] running secret scan…")
                result = scan_path(target, self._emit_log, cancel=self._static_cancel_evt,
                                   git_secrets_status=get_git_secrets_status())
                sec_dir = out_dir / "secrets"
                write_secrets_report(result, sec_dir)
                self._emit_log(f"[secrets] {result['total']} finding(s) across "
                               f"{result['scanned_files']} file(s)")
                results["secrets"] = result
            jobs.append(("secrets", _run_secrets_stage))

        def run_stage(item):
            key, fn = item
            try:
                fn(); self._event_queue.put(("stage", (key, "done")))
            except Exception as e:
                self._event_queue.put(("stage", (key, "failed")))
                self._emit_log(f"[static] {key} failed: {e!r}")
                if getattr(e, "is_auth", False):
                    self._event_queue.put(("auth_required", None))

        try:
            if len(jobs) > 1:
                self._emit_log(f"[static] running {len(jobs)} analyses concurrently")
                with ThreadPoolExecutor(max_workers=len(jobs)) as ex_:
                    list(ex_.map(run_stage, jobs))
            else:
                for j in jobs: run_stage(j)

            # Persist each completed kind so later cumulative reports stay complete.
            state = self._scan_state
            for kind in ("sca", "code", "secrets"):
                raw = results.get(kind)
                if raw is not None:
                    try:
                        state.save_kind(kind, raw, target=str(target), snyk_version=v, mode=mode)
                        self._emit_log(f"[state] {kind} result persisted")
                    except Exception as e:
                        self._emit_log(f"[state] could not save {kind}: {e!r}")

            ctx = build_cumulative_context(state, target_hint=target,
                                           snyk_version_hint=v, current_results=results)
            ctx["scan_mode"] = mode
            self._emit_log("[report] building cumulative report (all scan types merged)")
            _base = _report_basename(self._user, mode)
            report_html = render_html(ctx, out_dir, filename=f"{_base}.html")
            self._emit_log(f"[report] HTML → {report_html}")
            try:
                csv_path = export_csv(ctx, out_dir / f"{_base}.csv", report_label=_report_label)
                self._emit_log(f"[report] CSV bundle (ZIP): {csv_path}")
            except Exception as e:
                self._emit_log(f"[report] CSV export skipped: {e!r}")
            sec_html_src = out_dir / "secrets" / "secrets.html"
            if sec_html_src.exists():
                try:
                    sec_html_dst = out_dir / f"{_base}_secrets.html"
                    shutil.copyfile(sec_html_src, sec_html_dst)
                    self._emit_log(f"[report] Secrets HTML → {sec_html_dst}")
                except Exception as e:
                    self._emit_log(f"[report] secrets HTML copy skipped: {e!r}")
            try:
                sarif_path = export_sarif(out_dir)
                if sarif_path: self._emit_log(f"[report] SARIF: {sarif_path}")
            except Exception as e:
                self._emit_log(f"[report] SARIF export skipped: {e!r}")
            try:
                merged_path = export_merged_json(out_dir)
                if merged_path: self._emit_log(f"[report] merged JSON: {merged_path}")
            except Exception as e:
                self._emit_log(f"[report] merged JSON skipped: {e!r}")

            meta = {
                "generated_at": ctx["generated_at"], "target": ctx["target"], "mode": mode,
                "counts": ctx["counts"], "total": ctx["total"],
                "sca_total": ctx.get("sca_total", 0), "code_total": ctx.get("code_total", 0),
                "dast_total": ctx.get("dast_total", 0), "api_total": ctx.get("api_total", 0),
                "secrets_total": ctx.get("secrets_total", 0), "snyk_version": ctx.get("snyk_version", ""),
            }
            (out_dir / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
            try:
                rec = update_history_after_scan(reports_root, ctx, meta,
                                                actor=getattr(self, "_user", ""), report_dir=out_dir)
                self._emit_log(f"[history] recorded — remediated {rec.get('remediated_count', 0)}, "
                               f"new {rec.get('introduced_count', 0)}")
            except Exception as e:
                self._emit_log(f"[history] could not update: {e!r}")
            if active_app and active_app.get("id"):
                try:
                    self._inv_store.record_scan(active_app["id"], meta)
                    self._event_queue.put(("inv_refresh", active_app["id"]))
                except Exception as e:
                    self._emit_log(f"[inventory] could not update: {e!r}")

            self._last_context = ctx; self._last_report_dir = out_dir
            self._last_static_report = Path(report_html)
            audit_log.write_event(reports_root, "scan_end", actor=self._user,
                                  app=(active_app.get("name") if active_app else ""),
                                  mode=mode, total=ctx.get("total", 0), counts=ctx.get("counts", {}),
                                  report=str(report_html), lane="static",
                                  cancelled=self._static_cancel_evt.is_set(), log=self._emit_log)
            self._event_queue.put(("static_results", ctx))
            self._event_queue.put(("report", str(report_html)))
        except Exception as e:
            self._emit_log(f"[static] scan failed: {e!r}")
            audit_log.write_event(reports_root, "scan_failed", actor=self._user,
                                  app=(active_app.get("name") if active_app else ""),
                                  mode=mode, lane="static", error=repr(e), log=self._emit_log)
            self._event_queue.put(("static_results", None))
        finally:
            # Whether it finished or errored gracefully, the run is over — clear
            # the crash-recovery marker (it only survives a hard kill/close).
            self._session_end("static")
