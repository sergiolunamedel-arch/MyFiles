# Guía de instalación — SailPoint IdentityIQ 8.5p1 (Dev, 2 servidores) — Banco Base

**Tus dos servidores:**

| Rol | Nombre | IP | SO |
|---|---|---|---|
| IQ Service | `QVW-M0SLPOSIQ00` | 10.50.53.86 | Windows |
| App + Base de Datos | `QVL-M0SLPOMYS00` | 10.50.54.147 | Linux (RHEL) |

Transferencia de archivos: **CyberArk** hacia Windows, **PuTTY/WinSCP** hacia Linux.
Conectores opcionales (SAP Portal SDA, Oracle EBS, OIM, ITIM) y Cloud Gateway: se agregan en una fase posterior, no en el core inicial.

---

## Estado actual (resumen rápido)

| Sección | Estado |
|---|---|
| 1. Transferencia de archivos a Linux | ✅ Hecho |
| 2. Prep del servidor (RHEL, Java 17) | ✅ Hecho — Java **17.0.19** |
| 3. MySQL 8 instalado y configurado (`/mysqldata`, `sql_mode`, `innodb_file_per_table`) | ✅ Hecho |
| 3.x Firewall — puerto 3306 abierto | ✅ Hecho |
| 4.1 Usuario de servicio `tomcat` (UID/GID 982) + home directory | ✅ Hecho |
| 4.2 Descargar/extraer Tomcat 9 en `/opt/tomcat` | ✅ Hecho |
| 4.3 Servicio systemd de Tomcat + firewall 8080 | ✅ Hecho |
| 5. Expandir el instalador base GA (`identityiq-8.5.zip`) | ✅ Hecho |
| 6.1 Desplegar WAR en `/opt/tomcat/webapps/identityiq` | ✅ Hecho |
| 6.2 Crear bases de datos IdentityIQ | ✅ Hecho (226 tablas confirmadas) |
| 6.3 Configurar `iiq.properties` (passwords encriptados) | ✅ Hecho |
| 6.4 Importar configuración inicial (`import init.xml`) | ✅ Hecho |
| 6.5 Arrancar Tomcat | ✅ Hecho |
| 6.6 Verificar acceso (login carga bien vía túnel SSH) | ✅ Hecho |
| 6.7 Acceso de red formal (fuera de tu laptop) | 🔄 En progreso — se resuelve vía integración con OKTA, ver sección 10 |
| 7. Cloud Gateway | ✅ Hecho — aplicación creada en IIQ, Test Connection exitoso. Falta ir creando una app por cada sistema real del banco que se vaya a intermediar |
| 8. IQService en Windows | ✅ Hecho — `IQService-Instance1` instalado, `RUNNING`, corriendo bajo `dombase\usr_qasailpoint` |
| 8.5 Conectar IdentityIQ con el IQService (app `Active Directory - QA`) | ✅ Hecho — Test Connection exitoso. Ver 8.5 y 8.6 para el detalle real de lo que hizo falta (TLS, certificado, Client Authentication) |
| 13. Cargar identidades de AD en QA (Account Aggregation) | ⚠️ Tarea creada y ejecutada (`Execute Now`) — **falta revisar el Task Result** de esa corrida al retomar (creadas/actualizadas vs. Unmatched). No se confirmó el resultado antes de pasar a otros pendientes |
| 9. Aplicar patch 8.5p1 sobre el GA validado | ⬜ Pendiente (después de 6–8) |
| 14. Google Workspace en QA | 🔴 Bloqueante ahora mismo — formato de Private Key ya resuelto, pero el Test Connection falla al generar el token OAuth con Google (`Connection reset`, probablemente proxy saliente faltante). Ver sección 14 completa |
| 15. Intelexion en QA (`Intelexion - QA`) | 🔄 Red y TLS resueltos (ver 15.1/15.2). Account Correlation y Manager Correlation ya configuradas (idPersona→displayName, NIPJefe→idempleado) tras importar el `ObjectConfig:Identity` de prod. 🔴 Bloqueante actual: error 500 del backend real (`api.bancobase.com`), no de IIQ. Ver sección 15 |
| 10.1–10.3 SSO SAML configurado en IIQ (SP Entity ID, ACS URL, metadata de Okta cargada) | ✅ Hecho |
| 10.4 Regla de correlación por email (`OktaEmailCorrelation.xml`) | ✅ Hecho — importada (con fix de CDATA, ver 10.4) y seleccionada en el dropdown de SSO Configuration, guardada y confirmada tras refresh |
| 10.6 Application username format en Okta (email en vez de ID) | 🔄 En progreso — lo está haciendo directamente el equipo de Okta, no confirmado terminado |
| 10.7 / 10.9 Exposición pública de `iga-qa.bancobase.net` | 🔄 **Decisión cambiada:** ya NO se va a usar Imperva — acceso solo interno (sin exposición a internet), vía nginx propio. Workaround local (hosts+stunnel) sigue disponible mientras tanto. Ver 10.7/10.9 actualizado |
| 10.10 Certificado wildcard de `bancobase.net` para el nginx | ⬜ Pendiente — ya existe un wildcard corporativo (cert + llave); falta identificar quién lo emitió y verificar cert/llave (comandos en 10.10). **Prerrequisito de la sección 16** |
| 16. 🚨 **PLAN URGENTE:** reset/unlock de contraseñas vía SailPoint, con Okta como verificación de identidad | ⬜ Solo plan definido, nada implementado todavía. Ver sección 16 completa (incluye el problema de que SailPoint está detrás de Okta) |

---

## 1. Transferencia de archivos

### 1.1 Al servidor Windows (CyberArk)
No subas nada a Windows todavía — el único archivo que necesita (`IQService.zip`) sale de dentro del jar que se expande en Linux primero (sección 5.2).

### 1.2 Al servidor Linux (WinSCP / PuTTY)
1. Conéctate a `10.50.54.147` con tu usuario de acceso SSH.
2. Sube a un directorio temporal en tu home, ej. `~/iiq_install/`:
   - `identityiq-8.5.zip` (instalador **base GA** — se despliega primero, trae `identityiq.war`, `database/`, `doc/`, `integration/`)
   - `identityiq-8.5-CHECKSUM.txt`
   - `identityiq-8.5p1.jar` (**patch** — se aplica después, sobre el GA ya funcionando; solo trae scripts `upgrade_*`, no sirve para una instalación desde cero)
   - `identityiq-8.5p1-CHECKSUM.txt`
3. Verifica integridad antes de tocar nada más:
```bash
cd ~/iiq_install
cat identityiq-8.5-CHECKSUM.txt
sha256sum identityiq-8.5.zip
# compara el hash — si no coincide, vuelve a transferir en modo Binary (no Auto/Text) en WinSCP
```
Repite lo mismo con `identityiq-8.5p1.jar` cuando la vayas a usar (sección 9). No mezcles los dos — el flujo de este ambiente es: GA completo primero (secciones 5–8), patch p1 al final.

---

## 2. Preparar el servidor Linux

### 2.1 Confirmar versión de RHEL y estado de seguridad
```bash
cat /etc/redhat-release
getenforce
sudo systemctl status firewalld
```

**[Layout de disco — importante para todo lo que sigue]** Este servidor usa LVM con particiones separadas de tamaño desigual:

```bash
df -h
```

En este ambiente, `/home` es chica (5G) y se llena rápido — **no la uses como staging** para zips/instaladores grandes (GA, patch p1, Cloud Gateway). Usa `/opt` o `/var` en su lugar, que tienen bastante más espacio libre. Todos los comandos de esta guía ya asumen esto.

### 2.2 Actualizar el sistema
```bash
sudo dnf update -y
sudo dnf install -y wget tar unzip vim
```

### 2.3 Instalar Java
```bash
sudo dnf install -y java-17-openjdk java-17-openjdk-devel
java -version
```
Versión usada en este ambiente: **OpenJDK 17.0.19**.

Configura `JAVA_HOME` a nivel de sistema:
```bash
sudo tee /etc/profile.d/java.sh <<'EOF'
export JAVA_HOME=$(dirname $(dirname $(readlink -f $(which java))))
export PATH=$JAVA_HOME/bin:$PATH
EOF
source /etc/profile.d/java.sh
echo $JAVA_HOME
```

---

## 3. Instalar y configurar MySQL 8 en Linux

Datadir apuntado a un volumen dedicado `/mysqldata` (63GB LVM) en vez del default `/var/lib/mysql` — ajusta el tamaño/ruta a lo que tengas disponible.

```bash
sudo systemctl stop mysqld 2>/dev/null
sudo mkdir -p /mysqldata/mysql
sudo chown -R mysql:mysql /mysqldata
sudo chmod 750 /mysqldata
```

> Si MySQL ya viene preinstalado en la plantilla del servidor y ya se auto-inicializó en `/var/lib/mysql`, primero límpialo (solo si es una inicialización fresca sin datos que conservar):
> ```bash
> sudo rm -rf /var/lib/mysql/*
> ```

Edita `/etc/my.cnf` (en RHEL normalmente todo vive en un solo archivo, no en `/etc/my.cnf.d/`). Modifica las líneas existentes dentro de `[mysqld]` — no dupliques:
```ini
datadir=/mysqldata/mysql
socket=/mysqldata/mysql/mysql.sock
```
Agrega al final una sección `[client]` (evita "Can't connect to local MySQL server through socket" al usar el cliente `mysql` de consola):
```ini
[client]
socket=/mysqldata/mysql/mysql.sock
```

**[SELinux]** Si `getenforce` da `Enforcing`, ajusta el contexto del volumen nuevo — es la causa más común de que MySQL falle al arrancar con "permission denied" aunque el `chown` esté bien:
```bash
sudo semanage fcontext -a -t mysqld_db_t "/mysqldata(/.*)?"
sudo restorecon -R -v /mysqldata
# si semanage no existe:
sudo dnf install -y policycoreutils-python-utils
```

Inicializar y arrancar:
```bash
sudo mysqld --initialize --datadir=/mysqldata/mysql --user=mysql
sudo systemctl enable --now mysqld
sudo systemctl status mysqld
sudo grep 'temporary password' /var/log/mysqld.log
```

Corre `mysql_secure_installation` y contesta `Y` a todo (remove test database, disallow remote root, remove anonymous users, reload privilege tables) — importante en un ambiente bancario incluso en dev.

**Importante:** cualquier cambio en `/etc/my.cnf` requiere `sudo systemctl restart mysqld` para aplicarse. Editar el archivo no reinicia el servicio solo, y poner `sql_mode`/`innodb_file_per_table` como variable de bash en la terminal no tiene ningún efecto sobre MySQL — el cambio va siempre en el archivo de configuración.

### 3.5 `sql_mode`, `innodb_file_per_table` y `mysql_native_password` — requisitos de IdentityIQ

MySQL 8 trae `ONLY_FULL_GROUP_BY` activado por default, incompatible con IdentityIQ. Además, **MySQL 8.4 deshabilita por default el plugin `mysql_native_password`** — el script `create_identityiq_tables-8.5.mysql` de IdentityIQ crea sus usuarios con `IDENTIFIED WITH mysql_native_password`, así que si no activas el plugin **antes** de correr ese script, los `CREATE USER` fallan uno por uno **sin detener el script ni marcar error visible en el resumen final** — las tablas sí se crean, pero ningún usuario de aplicación llega a existir, y solo lo descubres horas después al intentar conectar. Actívalo desde ahora para evitar ese problema:

Dentro de `[mysqld]`:
```ini
sql_mode=STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION
innodb_file_per_table=1
mysql_native_password=ON
```
```bash
sudo systemctl restart mysqld
mysql -u root -p -e "SHOW VARIABLES WHERE variable_name='sql_mode';"
mysql -u root -p -e "SHOW VARIABLES WHERE variable_name='innodb_file_per_table';"
mysql -u root -p -e "SELECT PLUGIN_NAME, PLUGIN_STATUS FROM information_schema.PLUGINS WHERE PLUGIN_NAME LIKE '%native%';"
```
La última consulta debe regresar `ENABLED`. Los tres ajustes deben quedar activos **antes** de crear las tablas de IIQ (sección 6.2), no después.

**Nota sobre el flag `-p` en cualquier comando `mysql` de aquí en adelante:** si vas a pasar el password en la misma línea (`-p'TuPassword'`), va **pegado, sin espacio** después de `-p`. Con espacio (`-p 'TuPassword'`), `mysql` no lo toma como password — te pide uno interactivo y trata el texto como el nombre de la base de datos a la que te quieres conectar, dando errores confusos tipo `Unknown database` o `Access denied` que no tienen nada que ver con que el password esté mal.

**[firewalld]**
```bash
sudo firewall-cmd --permanent --add-port=3306/tcp
sudo firewall-cmd --reload
```

---

## 4. Instalar Apache Tomcat 9

IdentityIQ 8.5 requiere Tomcat 9.0.x reciente (cualquier build actual corre bien sobre Java 17).

### 4.1 Crear el usuario de servicio `tomcat`

En servidores con hardening de seguridad (común en banca), el `sudoers` del usuario de instalación suele **bloquear explícitamente `useradd`, `su` y `visudo`** aunque tenga `sudo` para casi todo lo demás. Antes de intentar `useradd`, confirma qué tienes permitido:
```bash
sudo -l
```
Si `useradd` aparece con `!` (negado) en la lista, crea el usuario del servicio manualmente en vez de depender del binario — es el método usado en este ambiente y no depende de ningún permiso adicional:

**a) Confirma el rango de UID/GID de sistema**
```bash
grep SYS_UID_MIN /etc/login.defs
grep SYS_UID_MAX /etc/login.defs
grep SYS_GID_MIN /etc/login.defs
grep SYS_GID_MAX /etc/login.defs
```
(Típicamente 201–999 en RHEL/CentOS.)

**b) Busca un UID/GID libre dentro de ese rango**
```bash
getent passwd <numero>
getent group <numero>
```
Prueba números hacia abajo desde el tope hasta que ambos comandos regresen vacío — varias cuentas de servicio del sistema (`sssd`, `chrony`, `sgx`, etc.) suelen ocupar buena parte del rango alto. En este ambiente, el UID/GID libre fue **982**.

**c) Crea el grupo, el usuario y la entrada de shadow editando los archivos directamente con `nano`** (más seguro que `echo ... | sudo tee`, que es propenso a errores de comillas):

```bash
sudo nano /etc/group
```
Agrega al final (usa tu UID/GID libre):
```
tomcat:x:982:
```

```bash
sudo nano /etc/passwd
```
Agrega al final:
```
tomcat:x:982:982::/opt/tomcat:/sbin/nologin
```

```bash
sudo nano /etc/shadow
```
Agrega al final — nota los **9 campos exactos** separados por `:`:
```
tomcat:!!:::::::
```
Verifica el número de campos automáticamente en vez de contarlos a ojo:
```bash
sudo awk -F: '$1=="tomcat"{print NF}' /etc/shadow
```
Debe regresar **9**.

**d) Valida consistencia**
```bash
sudo pwck -qr
sudo grpck -qr
```
`pwck` debe terminar sin preguntar nada ("no changes"). `grpck` puede preguntar si agregar `tomcat` a `/etc/gshadow` — responde `No`; ese archivo solo maneja contraseñas de grupo y no afecta el funcionamiento de la cuenta.

Confirma el resultado final:
```bash
id tomcat
```
Debe mostrar:
```
uid=982(tomcat) gid=982(tomcat) groups=982(tomcat)
```

**e) Crea el home directory**
```bash
sudo mkdir -p /opt/tomcat
sudo chown tomcat:tomcat /opt/tomcat
sudo chmod 750 /opt/tomcat
```

### 4.2 Descargar e instalar Tomcat

Si el servidor no tiene salida directa a internet (común en la red interna del banco), descarga el `.tar.gz` de https://tomcat.apache.org/download-90.cgi en tu máquina local y súbelo por WinSCP en vez de usar `wget`.

```bash
cd /tmp
# sube apache-tomcat-9.0.XX.tar.gz vía WinSCP
sudo tar xzvf apache-tomcat-9.0.XX.tar.gz -C /opt/tomcat --strip-components=1
sudo chown -R tomcat:tomcat /opt/tomcat
sudo bash -c 'chmod +x /opt/tomcat/bin/*.sh'
```
El `sudo bash -c '...'` en el `chmod` es necesario porque el comodín `*.sh` lo expande tu propia shell **antes** de que `sudo` entre en acción — sin el `bash -c`, si tu usuario no tiene permiso de lectura sobre esa carpeta, el comodín no expande nada y `chmod` termina buscando un archivo llamado literalmente `*.sh`.

**Verifica que quedó bien antes de seguir** (mismo truco del comodín, aplica también a `ls`):
```bash
sudo bash -c 'ls -la /opt/tomcat/bin/*.sh'
```
Deben verse con permisos `-rwxr-xr-x` y dueño `tomcat`.

### 4.3 Crear el servicio systemd

```bash
sudo tee /etc/systemd/system/tomcat.service <<EOF
[Unit]
Description=Apache Tomcat 9 (IdentityIQ)
After=network.target mysqld.service

[Service]
Type=forking
Environment=JAVA_HOME=$JAVA_HOME
Environment=CATALINA_PID=/opt/tomcat/temp/tomcat.pid
Environment=CATALINA_HOME=/opt/tomcat
Environment=CATALINA_BASE=/opt/tomcat
Environment="CATALINA_OPTS=-Xms1024M -Xmx2048M -server -XX:+UseG1GC --add-exports=java.naming/com.sun.jndi.ldap=ALL-UNNAMED"
ExecStart=/opt/tomcat/bin/startup.sh
ExecStop=/opt/tomcat/bin/shutdown.sh
User=tomcat
Group=tomcat
RestartSec=10
Restart=on-failure

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
```
**Las comillas dobles alrededor de todo el valor de `CATALINA_OPTS` son obligatorias.** Sin ellas, `systemd` interpreta cada palabra separada por espacio como una asignación de variable aparte — solo toma `-Xms1024M` como valor real y descarta el resto (`-Xmx2048M`, `-server`, `-XX:+UseG1GC`, y el `--add-exports` que necesitas para JDK 17) con mensajes tipo `Invalid environment assignment, ignoring: -Xmx2048M` en el log, sin que el servicio falle — Tomcat arranca igual, pero con memoria default y sin el flag de LDAP/JNDI.

El `--add-exports=java.naming/com.sun.jndi.ldap=ALL-UNNAMED` es obligatorio para JDK 17+ — sin esto habrá errores de LDAP/JNDI al configurar el conector de Active Directory más adelante. Ajusta `-Xms`/`-Xmx` según la RAM real disponible.

Como el servicio arranca con `User=tomcat`/`Group=tomcat` directamente en el unit file, systemd cambia de usuario internamente al iniciar Tomcat — esto evita depender del binario `su`, que en este tipo de servidores suele estar bloqueado igual que `useradd`.

**[firewalld]**
```bash
sudo firewall-cmd --permanent --add-port=8080/tcp
sudo firewall-cmd --reload
```
No arranques Tomcat todavía — falta poner el WAR de IdentityIQ adentro (sección 6).

---

## 5. Expandir el instalador base (GA)

### 5.1 Expandir el zip
```bash
cd ~/iiq_install
unzip identityiq-8.5.zip -d identityiq_staging
ls identityiq_staging
# deberías ver: identityiq.war  database/  doc/  integration/
```
Usa `unzip -d` (no `jar -xvf`) — `jar` no tiene forma de elegir carpeta destino, siempre extrae en la carpeta donde estás parado, y es fácil terminar con todo regado en el lugar equivocado si olvidas el `cd` antes.

**Confirma que trae el script de creación completo** (no solo `upgrade_*`, que es la firma de un patch, no de un instalador base):
```bash
find identityiq_staging -iname "create_identityiq_tables*.mysql"
```
Debe regresar `identityiq_staging/database/create_identityiq_tables-8.5.mysql`. Si no aparece, lo que tienes es un patch, no el instalador base — revisa el nombre del archivo que descargaste.

El `IQService.zip` para Windows **no hace falta sacarlo aparte** — queda incluido dentro del WAR y aparece automáticamente en `/opt/tomcat/webapps/identityiq/WEB-INF/bin/win/IQService.zip` una vez que despliegues en la sección 6.1. Lo subes a Windows desde ahí cuando llegues a la sección 8.

**Corrección:** a diferencia del IQService, el **Cloud Gateway NO viene incluido** dentro de `identityiq-8.5.zip` — es un paquete aparte (`identityiq-CloudGateway-<versión>.zip`) que se descarga del mismo portal donde bajaste el GA y el patch p1, y su versión debe coincidir con la de IdentityIQ (8.5). Ver sección 7.

---

## 6. Desplegar IdentityIQ en Tomcat

### 6.1 Copiar el WAR expandido a webapps
```bash
sudo mkdir -p /opt/tomcat/webapps/identityiq
cd /opt/tomcat/webapps/identityiq
pwd
```
Confirma que el `pwd` te regresa exactamente `/opt/tomcat/webapps/identityiq` antes de seguir — `jar` no tiene opción `-C`, siempre extrae en la carpeta actual, así que si el `cd` falló o quedaste en otro lado, todo se va a extraer en el lugar equivocado sin avisarte.
```bash
sudo jar -xvf ~/iiq_install/identityiq_staging/identityiq.war
sudo chown -R tomcat:tomcat /opt/tomcat/webapps/identityiq
sudo chmod +x /opt/tomcat/webapps/identityiq/WEB-INF/bin/iiq
```
El `chmod +x` en `WEB-INF/bin/iiq` es obligatorio — sin esto el script `iiq` no ejecuta.

**Importante para todos los pasos que siguen:** una vez que corres el `chown -R tomcat:tomcat`, tu usuario ya **no puede** hacer `cd` a esa carpeta ni con `sudo` delante (`sudo cd` no funciona — `cd` es un comando interno de bash, no un programa, así que `sudo` no tiene nada que elevar). A partir de aquí, todos los comandos dentro de `webapps/identityiq` se corren con su ruta completa y `sudo -u tomcat`, sin entrar a la carpeta — así están escritos los pasos 6.3 y 6.4 de abajo.

### 6.2 Crear las bases de datos de IdentityIQ
```bash
cd ~/iiq_install/identityiq_staging/database
ls *.mysql   # busca: create_identityiq_tables-8.5.mysql
```
El script trae **6 líneas `CREATE USER`** (una por `%` y una por `localhost`, para cada uno de los 3 usuarios: `identityiq`, `identityiqah`, `identityiqPlugin`), cada una con su propio password default de fábrica (igual al nombre de usuario). Ábrelo y cámbialas **las 6**, no solo el primer par — usa el mismo password real en todas para simplificar el resto de la instalación (una sola conexión que probar, un solo valor que encriptar más adelante):
```bash
vim create_identityiq_tables-8.5.mysql
```
Busca `IDENTIFIED WITH mysql_native_password BY '` con `/IDENTIFIED WITH` y Enter para saltar entre las 6 ocurrencias, y reemplaza el texto entre las últimas comillas simples de cada una por tu password real — el mismo en las 6 líneas.

Ejecútalo:
```bash
mysql -u root -p
```
```sql
source ~/iiq_install/identityiq_staging/database/create_identityiq_tables-8.5.mysql;
SHOW DATABASES;
quit
```

**Verifica que las 6 cuentas sí se crearon** (el script no avisa con un error visible si algún `CREATE USER` falla, como pasa si el plugin de la sección 3.5 no quedó activo):
```bash
mysql -u root -p'TuPasswordDeRoot' -e "SELECT user,host FROM mysql.user WHERE user LIKE '%identityiq%';"
```
Deben aparecer exactamente 6 filas. Si aparecen menos, revisa que `mysql_native_password` haya quedado `ENABLED` (sección 3.5) antes de volver a intentar.

**Prueba las tres conexiones de aplicación antes de seguir** (con tu password real, sin espacio después de `-p`):
```bash
mysql -h 127.0.0.1 -P 3306 -u identityiq -p'TuPasswordReal' identityiq -e "SELECT 1;"
mysql -h 127.0.0.1 -P 3306 -u identityiqah -p'TuPasswordReal' identityiqah -e "SELECT 1;"
mysql -h 127.0.0.1 -P 3306 -u identityiqPlugin -p'TuPasswordReal' identityiqPlugin -e "SELECT 1;"
```
Las tres deben regresar `1`. Confirmar esto aquí, antes de tocar `iiq.properties`, ahorra tener que diagnosticar a ciegas si algo falla más adelante en el `import init.xml`.

### 6.3 Configurar iiq.properties
Con el mismo password real en las tres cuentas (sección 6.2), solo necesitas **un** valor encriptado para las tres líneas:
```bash
sudo -u tomcat /opt/tomcat/webapps/identityiq/WEB-INF/bin/iiq encrypt 'TuPasswordReal'
```
Te regresa un string tipo `1:ACP:xxxxxxxxxxxxxxxxxxxxxxxxxxxxx=` — cópialo completo.

Reemplaza las tres líneas de golpe con `sed` (más confiable que pegar dentro de `vim`, sobre todo si el password tiene caracteres especiales):
```bash
ENC='1:ACP:PEGA_AQUI_EL_RESULTADO'
sudo sed -i "s|^dataSource.password=.*|dataSource.password=${ENC}|" /opt/tomcat/webapps/identityiq/WEB-INF/classes/iiq.properties
sudo sed -i "s|^pluginsDataSource.password=.*|pluginsDataSource.password=${ENC}|" /opt/tomcat/webapps/identityiq/WEB-INF/classes/iiq.properties
sudo sed -i "s|^dataSourceAccessHistory.password=.*|dataSourceAccessHistory.password=${ENC}|" /opt/tomcat/webapps/identityiq/WEB-INF/classes/iiq.properties
```

Verifica que las tres líneas quedaron con el mismo valor y que ninguna se quedó con el default de fábrica:
```bash
sudo grep -E '^(dataSource|pluginsDataSource|dataSourceAccessHistory)\.password=' /opt/tomcat/webapps/identityiq/WEB-INF/classes/iiq.properties
```

De paso, confirma que el `.username=` de cada bloque coincide exactamente con los usuarios creados en 6.2, y no toques las líneas `.url=jdbc:mysql://localhost/...` — `localhost` está bien porque Tomcat y MySQL corren en el mismo servidor.

**Recordatorio:** tu usuario ya **no puede** hacer `cd` a `/opt/tomcat/webapps/identityiq` ni con `sudo` delante (`sudo cd` no funciona — `cd` es un comando interno de bash, no un programa; ver nota en 6.1). Todos los comandos de aquí en adelante usan ruta completa y `sudo -u tomcat`, sin entrar a la carpeta.

### 6.4 Importar la configuración inicial (solo una vez)
```bash
sudo -u tomcat /opt/tomcat/webapps/identityiq/WEB-INF/bin/iiq console
```
Ya dentro del console:
```
import init.xml
quit
```

### 6.5 Arrancar Tomcat
```bash
sudo systemctl enable --now tomcat
sudo journalctl -u tomcat -f
```
Espera `Server startup in [XXXX] milliseconds` (puede tardar 1–3 min la primera vez). `Ctrl+C` para salir del log. Si ves líneas `Invalid environment assignment, ignoring: ...`, la sección 4.3 no quedó con las comillas en `CATALINA_OPTS` — corrígela y reinicia (`sudo systemctl daemon-reload && sudo systemctl restart tomcat`) antes de seguir.

**Verifica localmente antes de abrir el navegador** (aísla si el problema, si lo hay, es de la app o de la red):
```bash
curl -I http://localhost:8080/identityiq
```
Debe regresar `HTTP/1.1 302` con `Location: /identityiq/`. Si esto funciona pero el navegador desde tu laptop da timeout, el problema es de red entre tu laptop y el servidor (firewall perimetral, VLAN separada — común en redes bancarias segmentadas), no de la instalación. Confírmalo comparando un puerto que ya sabes que funciona (22, el de SSH) contra el 8080, desde PowerShell en tu laptop:
```powershell
Test-NetConnection -ComputerName 10.50.54.147 -Port 22
Test-NetConnection -ComputerName 10.50.54.147 -Port 8080
```
Si el 22 pasa y el 8080 no, hay que pedir al equipo de redes que abra `TCP 8080` entre tu subred/VPN y el servidor. Mientras tanto, puedes seguir trabajando con un túnel SSH (en PuTTY: `Connection → SSH → Tunnels`, `Source port: 8080`, `Destination: 127.0.0.1:8080`, `Add`, y reconecta) y navegar a `http://localhost:8080/identityiq` desde tu laptop — el tráfico va dentro del túnel SSH, que sí está permitido.

### 6.6 Verificar acceso

**Estado confirmado:** la aplicación arranca y responde bien — validado con `curl` local y con la pantalla de login cargando en el navegador vía el túnel SSH.

```
http://10.50.54.147:8080/identityiq
```
Si accedes vía el túnel SSH (`localhost:8080` en vez de la IP directa), escribe la URL con **`http://` explícito**:
```
http://localhost:8080/identityiq
```
Sin el `http://` explícito, algunos navegadores autocompletan `https://` para `localhost` y da `ERR_SSL_PROTOCOL_ERROR` — Tomcat en este puerto solo habla HTTP plano, sin certificado.

**Login default:**
```
Usuario: spadmin
Password: admin
```
**Cámbialo de inmediato** (Identities → Identity Warehouse → `spadmin` → Change Password) — no depende de nada de red, ya se puede hacer ahora mismo vía el túnel.

### 6.7 Acceso de red formal — en progreso vía Okta

Se decidió resolver el acceso general (fuera de tu laptop) vía una integración con **OKTA** en vez de la ruta original de reverse proxy/firewall. El detalle completo de esta integración (configuración SAML en IIQ, regla de correlación, configuración del lado Okta, y el bloqueo de acceso actual) está en la **sección 10**. Mientras el acceso real no esté resuelto, el único acceso funcional directo sigue siendo el túnel SSH (sección 6.5) desde una máquina con acceso SSH al servidor.

---

## 7. Cloud Gateway — decisión tomada

Trae su propio Tomcat empaquetado y corre como servicio aparte, no "dentro" del Tomcat de IdentityIQ. Da acceso a IdentityIQ hacia aplicaciones en otra zona de red — con solo un puerto perimetral abierto, IdentityIQ puede llegar a todas las apps que el Cloud Gateway intermedie.

**Decisiones ya tomadas:**
- **Servidor:** el mismo nodo Linux (`QVL-M0SLPOMYS00`, 10.50.54.147). No hay un tercer servidor en este ambiente.
- **Alcance:** se va a conectar a **todas las aplicaciones del banco** — no es un conector puntual hacia una sola app remota, sino un intermediario de alcance amplio. Implicación directa para la solicitud de reglas de firewall: en vez de una regla puntual hacia una zona de red específica (como con el nodo Windows), hay que coordinar con el equipo de red qué zonas/segmentos concretos necesitan alcanzar realmente las apps objetivo — vale la pena armar ese inventario antes de pedir reglas una por una.

### 7.1 Conseguir el paquete correcto

El Cloud Gateway **no viene incluido** en `identityiq-8.5.zip` — es un descargable aparte: `identityiq-CloudGateway-<versión>.zip`. Su versión debe coincidir exactamente con la de IdentityIQ (8.5); si no coinciden, la conexión falla. Bájalo del mismo portal donde conseguiste el GA y el patch p1.

**Transfiérelo directo a `/opt`, no a tu home (`~`).** En este servidor, `/home` es una partición separada y chica (5G) — se llena rápido con instaladores/zips. `/` tiene 15G libres y es donde de todos modos va a vivir el Cloud Gateway (sección 7.3), así que evita el problema desde la transferencia:
```bash
sudo mkdir -p /opt/cloudgateway_staging
sudo chown $(whoami):$(whoami) /opt/cloudgateway_staging
```
Transfiere el zip (WinSCP o `scp`) a `/opt/cloudgateway_staging/`.

### 7.2 Extraer e identificar la estructura interna

```bash
cd /opt/cloudgateway_staging
unzip identityiq-CloudGateway-8.5.zip
ls
```
Trae un Tomcat propio empaquetado adentro (ej. `apache-tomcat-7.0.32/` o similar — el número de versión exacto puede variar). Confirma el nombre real de esa carpeta antes de seguir, porque las rutas de las secciones 7.3–7.6 dependen de ella:
```bash
find . -maxdepth 2 -iname "apache-tomcat*"
```
Usa esa ruta (ya sustituida como `apache-tomcat-9.0.104` en los comandos de abajo, confirmada por tu `find`).

### 7.3 Mover a su ubicación final y dar permisos

```bash
sudo mkdir -p /opt/cloudgateway
sudo mv /opt/cloudgateway_staging/* /opt/cloudgateway/
sudo rmdir /opt/cloudgateway_staging
sudo chown -R tomcat:tomcat /opt/cloudgateway
sudo chmod +x /opt/cloudgateway/apache-tomcat-9.0.104/bin/*.sh
sudo chmod +x /opt/cloudgateway/apache-tomcat-9.0.104/webapps/CloudGateway/WEB-INF/bin/*
```
Los permisos de ejecución en esas dos carpetas son obligatorios en Linux — sin esto ni arranca ni corren los comandos de configuración de 7.4.

**El zip no trae las carpetas vacías que Tomcat necesita para arrancar** (`logs/`, `temp/`, `work/`) — créalas ahora para no toparte con el error hasta el arranque en 7.6:
```bash
sudo mkdir -p /opt/cloudgateway/apache-tomcat-9.0.104/logs
sudo mkdir -p /opt/cloudgateway/apache-tomcat-9.0.104/temp
sudo mkdir -p /opt/cloudgateway/apache-tomcat-9.0.104/work
sudo chown -R tomcat:tomcat /opt/cloudgateway/apache-tomcat-9.0.104/logs /opt/cloudgateway/apache-tomcat-9.0.104/temp /opt/cloudgateway/apache-tomcat-9.0.104/work
```

### 7.4 Generar la llave secreta y reemplazar la que viene por default

El zip trae un certificado autofirmado y una llave secreta de fábrica que **sí funcionan tal cual** (podrías arrancar ya con eso), pero en un ambiente bancario conviene reemplazar la llave desde ahora, no después:

```bash
cd /opt/cloudgateway/apache-tomcat-9.0.104
sudo -u tomcat keytool -keystore cibkeystore.jck -storetype jceks -genseckey -alias 2 -keysize 128 -keyAlg AES
```
Te va a pedir dos passwords (keystore y alias) — **deben ser el mismo valor exacto**; si no coinciden, luego truena con `Given final block not properly padded`. El `alias` debe ser un número mayor a 1 (`2` es el que usa el ejemplo oficial de SailPoint, úsalo tal cual salvo que ya tengas otro esquema).

Encripta el password del keystore con la herramienta `cib` que trae el propio Cloud Gateway:
```bash
cd /opt/cloudgateway/apache-tomcat-9.0.104/webapps/CloudGateway/WEB-INF/bin
sudo -u tomcat ./cib.sh encrypt keystorePassword
```
(Te pedirá el password del keystore que definiste arriba, y te regresa el valor ya encriptado — cópialo completo.)

Edita `iiq.properties` **del Cloud Gateway** — ⚠️ es un archivo distinto al `iiq.properties` de IdentityIQ de la sección 6.3, aunque se llame igual:
```bash
sudo vim /opt/cloudgateway/apache-tomcat-9.0.104/webapps/CloudGateway/WEB-INF/classes/iiq.properties
```
Descomenta (quita el `#`) y llena estas dos líneas con la ruta completa del keystore de 7.4 y el password encriptado que acabas de generar:
```
keyStore.file=/opt/cloudgateway/apache-tomcat-9.0.104/cibkeystore.jck
keyStore.password=PEGA_AQUI_EL_VALOR_ENCRIPTADO
```

### 7.5 Usuario/password de autenticación — se deja el default (ambiente QA/temporal)

Por default el Cloud Gateway acepta usuario `cibadmin` / password `admin` para cada request que le llega desde IdentityIQ. SailPoint recomienda cambiarlo antes de producción, pero como este ambiente es QA y temporal, **se deja el default tal cual** — no se ejecuta el `cib.sh encrypt RequestPassword`, y `cib.username`/`cib.password` en `iiq.properties` quedan sin tocar (con el valor de fábrica que ya viste en la captura: `cib.username=cibadmin`, `cib.password=1:ACP:...` ya encriptado por default).

⚠️ Si este ambiente llega a promoverse a producción o a manejar datos reales, este es el primer punto a revisar — no dejar credenciales default expuestas de forma permanente.

### 7.6 Puerto y arranque

El puerto **HTTPS** default del Cloud Gateway es **8443** — distinto al 8080 de IdentityIQ, no hay conflicto ahí. Como corre en el mismo servidor, tampoco necesitas abrir una regla de firewall entre servidores para que IdentityIQ lo alcance (solo `localhost`).

**El puerto de apagado (shutdown, 8005) sí choca** — el `server.xml` de este Tomcat empaquetado trae el mismo default que el Tomcat de IdentityIQ (`/opt/tomcat`), que nunca se tocó. Con los dos corriendo en el mismo servidor, van a competir por el 8005. Cámbiaselo al del Cloud Gateway antes del primer arranque:
```bash
sudo sed -i 's/<Server port="8005" shutdown="SHUTDOWN">/<Server port="8006" shutdown="SHUTDOWN">/' /opt/cloudgateway/apache-tomcat-9.0.104/conf/server.xml
```

**Deja `JAVA_HOME` permanente** en vez de tener que especificarlo cada vez — Tomcat lee automáticamente `bin/setenv.sh` si existe:
```bash
sudo tee /opt/cloudgateway/apache-tomcat-9.0.104/bin/setenv.sh <<'EOF'
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-17.0.19.0.10-2.el9.x86_64
EOF
sudo chown tomcat:tomcat /opt/cloudgateway/apache-tomcat-9.0.104/bin/setenv.sh
sudo chmod +x /opt/cloudgateway/apache-tomcat-9.0.104/bin/setenv.sh
```
Sin este archivo, `catalina.sh` no siempre resuelve bien `JRE_HOME` bajo `sudo -u tomcat` (lo vas a ver como `Using JRE_HOME: /` en el log, y el arranque falla por no encontrar java).

Arráncalo:
```bash
sudo -u tomcat /opt/cloudgateway/apache-tomcat-9.0.104/bin/startup.sh
sleep 3
ps -ef | grep -i cloudgateway
sudo tail -20 /opt/cloudgateway/apache-tomcat-9.0.104/logs/catalina.out
```
Debe mostrar `Using JRE_HOME:` con la ruta real del JDK, un proceso `java` corriendo en el `ps`, y `Server startup in [XXXX] milliseconds` sin ningún `SEVERE` después. Confirma que responde:
```bash
curl -k -I https://localhost:8443
```

### 7.7 Crear la aplicación Cloud Gateway en IdentityIQ

En IIQ: **Applications → Application Definition → Add New Application → Type: Cloud Gateway**.

**Pestaña Details:** `Name` (ej. `Cloud Gateway`) y `Owner` (`spadmin`) son los únicos campos obligatorios — `Revoker`, `Proxy Application` y `Profile Class` se dejan vacíos, y los 4 checkboxes (Authoritative Application, Case Insensitive, Native Change Detection, Maintenance Enabled) sin marcar; ninguno aplica al Cloud Gateway en sí.

**Pestaña Configuration:**
| Campo | Valor |
|---|---|
| IdentityIQ Cloud Gateway Host | `localhost` |
| IdentityIQ Cloud Gateway Port | `8443` |
| Username | `cibadmin` |
| Password | `admin` (default de fábrica — se dejó así en 7.5 por ser ambiente QA/temporal) |
| SSL Certificate (si aparece) | `Trust All` |

Guarda y corre **Test Connection**.

**Si el Test Connection falla con `(unsupported_certificate) Certificates do not conform to algorithm constraints`:** el certificado autofirmado que trae el zip de fábrica (`keystore/mykeystore.keystore`, alias `tomcat`, password `trustno1`) fue generado con parámetros que Java 17 ya rechaza. Regénéralo con el mismo archivo/alias/password para no tener que tocar `server.xml`:
```bash
cd /opt/cloudgateway/apache-tomcat-9.0.104/keystore
sudo mv mykeystore.keystore mykeystore.keystore.bak
sudo -u tomcat keytool -genkeypair -alias tomcat -keyalg RSA -keysize 2048 -sigalg SHA256withRSA -validity 3650 \
  -keystore mykeystore.keystore -storepass trustno1 -keypass trustno1 \
  -dname "CN=localhost, OU=IGA, O=BancoBase, L=CDMX, ST=CDMX, C=MX"
sudo -u tomcat /opt/cloudgateway/apache-tomcat-9.0.104/bin/shutdown.sh
sleep 2
sudo -u tomcat /opt/cloudgateway/apache-tomcat-9.0.104/bin/startup.sh
```
Confirma con `curl -k -I https://localhost:8443` (debe regresar `200`) y reintenta **Test Connection** en IIQ.

Después, por cada app real del banco que vaya a intermediar, se crea una aplicación aparte en IIQ configurada como proxy a través de esta.

---

## 8. Instalar el IQService en Windows

### 8.1 Prerrequisito: .NET Framework 4.5+
```powershell
Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full\" -Name Release -ErrorAction SilentlyContinue | Select Release
```
Si es menor a 4.5, instala .NET Framework 4.8 antes de continuar.

### 8.2 Transferir el IQService.zip (CyberArk)
Ya está listo en el servidor Linux en `/opt/tomcat/webapps/identityiq/WEB-INF/bin/win/IQService.zip` (quedó incluido al desplegar el WAR, sección 6.1).

**Esa carpeta es de `tomcat:tomcat`** — tu usuario normal no tiene permiso de entrar ahí vía WinSCP y da `Permission denied`. Cópialo primero a tu home con `sudo` (por SSH/PuTTY, no WinSCP):
```bash
sudo cp /opt/tomcat/webapps/identityiq/WEB-INF/bin/win/IQService.zip ~/IQService.zip
sudo chown $(whoami):$(whoami) ~/IQService.zip
```
Ahora sí bájalo por WinSCP desde tu home, y súbelo a Windows vía CyberArk, a `C:\iqservice\IQService.zip`.

### 8.3 Decidir la cuenta de servicio antes de instalar
En el nodo Windows ya existe la cuenta `Sailpoint.qa`, con password gestionado (rotado) por CyberArk. Si el servicio del IQService va a correr bajo esa cuenta ("Log On As"), confirma primero con quien administra CyberArk si tiene activo el plugin de gestión de cuentas de servicio de Windows — sin eso, cuando CyberArk rote el password, el servicio se queda con la credencial vieja y falla al reiniciar. Si no está ese plugin activo, es más seguro usar una cuenta dedicada sin rotación automática, o la cuenta local del sistema.

**Decisión tomada:** se usa `usr_qasailpoint`, una cuenta dedicada sin rotación automática — distinta de `Sailpoint.qa` — para correr el servicio.

**Si ya habías avanzado con otra cuenta y necesitas empezar limpio con `usr_qasailpoint`:**
1. Confirma que `usr_qasailpoint` es admin local (lo necesitas para los pasos siguientes): `net localgroup Administrators`.
2. Ubica los archivos/carpeta de la instalación anterior, sin importar de qué cuenta son: `dir C:\ /s /b | findstr /i iqservice`.
3. Revisa si ya se llegó a instalar el servicio: `sc query IQService`. Si dice que no existe, solo hay archivos sueltos que limpiar (ve al punto 5). Si regresa un estado, sigue al punto 4.
4. Desinstálalo desde su carpeta original: `sc qc IQService` (para ver `BINARY_PATH_NAME`), `cd` a esa ruta, y `IQService.exe -u`. Si `sc query IQService` lo sigue mostrando después, fuerza `sc delete IQService`.
5. Limpia la carpeta vieja: `takeown /f "<ruta_vieja>" /r /d y`, `icacls "<ruta_vieja>" /grant Administrators:F /t`, `rmdir /s /q "<ruta_vieja>"`.
6. Retransfiere el zip (8.2) ya logueado con `usr_qasailpoint`, a una carpeta fija nueva (`C:\iqservice\IQService.zip`), y continúa con 8.4 desde ahí.

### 8.4 Instalar y arrancar el servicio
```cmd
tar -xf IQService.zip
IQService.exe -i
IQService.exe -s
```
**El nombre real del servicio no es `IQService` — es `IQService-Instance1`** (default cuando no se usa `-n`). Verifica con ese nombre, no con "IQService" a secas:
```cmd
sc query IQService-Instance1
```
También lo puedes confirmar en `services.msc`, buscando "SailPoint IQService-Instance1".

**Si `-i` da `ERROR: Please install from another location as this location already exists in registry!`:** es rastro de un intento de instalación anterior desde esa misma ruta (`C:\iqservice`) que si sí alcanzó a registrar el servicio (con el nombre real `IQService-Instance1`, por eso un `sc query IQService` a secas engaña diciendo "no existe"). Desinstálalo con el mismo binario antes de reintentar — no hace falta pelear con el registro a mano:
```cmd
cd C:\iqservice
IQService.exe -u
sc query IQService-Instance1
```
Confirmado que ya no existe, reinstala normal (`IQService.exe -i` y `-s` de arriba).

**Configura el "Log On As" del servicio** — el `-i` lo deja corriendo con la cuenta con la que abriste la sesión (ej. la de administrador de CyberArk), no con la cuenta de servicio decidida en 8.3:
1. `services.msc` → **SailPoint IQService-Instance1** → pestaña **Log On** → **This account**.
2. Captura `usr_qasailpoint` y su password. Si es cuenta de **dominio** (lo normal), el picker de Windows puede buscar por default solo en la máquina local y decir "cannot be found" — en ese caso, clic en **Locations...** y selecciona el dominio (no el nombre de la máquina) antes de volver a escribir el usuario y darle **Check Names**.
3. Aplica y reinicia el servicio (clic derecho → Restart).
4. Confirma que la columna **Log On As** ya diga `usr_qasailpoint@bancobase.com` (no `Local System`) y que **Status** siga en `Running`. ✅ Confirmado — servicio corriendo bajo la cuenta correcta.

**⚠️ TLS por default:** el instalador de esta versión deja el puerto 5050 configurado directo en **TLS**, no en plano — el propio log lo advierte ("please ensure to enable TLS configuration flag from source/application"). Cuando configures en IIQ la aplicación que usa este IQService (8.5, AD, etc.), marca el checkbox de **Enable TLS**, o la conexión falla por protocolo aunque el puerto y el firewall estén bien.

**[Windows Firewall]** Abre el puerto usado (5050) para conexiones entrantes desde `10.50.54.147`.

### 8.5 Conectar IdentityIQ con el IQService — hecho

Se creó la aplicación **`Active Directory - QA`** (tipo `Active Directory - Direct`) apuntando al **mismo forest real de producción** usado por la app `BancoBase-Application-DirectorioActivo` — no es un AD aislado de prueba, QA lee identidades reales del banco:

| Campo | Valor |
|---|---|
| IQService Host | `10.50.53.86` |
| IQService Port | `5050` |
| Use TLS | ✅ (obligatorio, ver 8.6) |
| Forest Name | `dombase` |
| Global Catalog Server | `MTY-ALE-PMDC003.dombase.net:3268` |
| Domain DN | `DC=dombase,DC=net` |
| Domain Server | `MTY-ALE-PMDC002.dombase.net` |
| User Search Scope | `OU=Usuarios,DC=dombase,DC=net` y `OU=Disabled_Users,OU=Disabled,OU=Banco...` (copiado de la app de prod), filtro `(&(objectClass=User)(objectCategory=Person))` |

**Test Connection: ✅ exitoso.**

### 8.6 Troubleshooting real de 8.5 — por si se repite en otro ambiente

Cuatro problemas distintos, en cascada, antes de que el Test Connection pasara:

**1. Connection refused (Linux → Windows, puerto 5050) — firewall de red entre subredes**
Mismo patrón que ya se vivió con el puerto 8080 (sección 6.5). Windows Firewall local ya estaba bien configurado desde el inicio (`Get-NetFirewallRule` confirmó regla `Allow`, `RemoteAddress: 10.50.54.147` exacto) — el bloqueo estaba en el firewall perimetral entre los segmentos/VLANs de los dos servidores. Se resolvió con un ticket a redes pidiendo TCP 5050, origen `10.50.54.147` → destino `10.50.53.86`, mismo formato que el ticket del 8080.
Diagnóstico usado: `nc -zv 10.50.53.86 5050` desde Linux (refused, repetible) vs `Test-NetConnection -ComputerName localhost -Port 5050` en el propio Windows (exitoso) — confirma que el servicio sí escuchaba y el problema estaba en la red intermedia.

**2. TLS: `PKIX path building failed` — certificado del IQService no confiado por Java**
El Tomcat de Linux no confiaba en el certificado que presenta el IQService al hacer el handshake TLS. Se resolvió exportando el certificado e importándolo al truststore de Java que usa Tomcat:
```bash
openssl s_client -connect 10.50.53.86:5050 -showcerts
# confirmar que muestra el certificado, luego:
echo | openssl s_client -connect 10.50.53.86:5050 -showcerts 2>/dev/null | openssl x509 -outform PEM > /home/<usuario>/certs/iqservice.pem
sudo $JAVA_HOME/bin/keytool -import -trustcacerts -alias iqservice -file /home/<usuario>/certs/iqservice.pem -keystore $JAVA_HOME/lib/security/cacerts -storepass changeit
sudo systemctl restart tomcat
```
Para verificar que quedó importado sin pelear con rutas de `$JAVA_HOME` concatenadas por accidente (ver nota de copy/paste abajo), usar la bandera `-cacerts` en vez de escribir la ruta a mano:
```bash
sudo $JAVA_HOME/bin/keytool -list -alias iqservice -cacerts -storepass changeit
```

**3. `Client Authentication Failed` — IQService User/Password son obligatorios con TLS**
Confirmado en documentación oficial de SailPoint: cuando **Use TLS** está activado en la app, el **Client Authentication es obligatorio** — los campos `IQService User` / `IQService Password` dejan de ser opcionales. No es la cuenta de servicio de Windows (`usr_qasailpoint` como "Log On As"); es una identidad aparte que hay que registrar explícitamente en el propio IQService:
```cmd
cd C:\iqservice
IQService.exe -a dombase\usr_qasailpoint
sc stop IQService-Instance1
sc start IQService-Instance1
```
Y en IIQ, llenar **IQService User** = `dombase\usr_qasailpoint` (mismo formato `dominio\usuario`) y **IQService Password** = password real de esa cuenta. El password no se guarda en el IQService — se valida contra Windows en cada request.

**4. Dominio NetBIOS incorrecto — `BANCOBASE` no es el dominio real**
Primer intento usó `BANCOBASE\usr_qasailpoint` en el campo IQService User, pero el dominio NetBIOS real es `dombase` (confirmado con `whoami` en el servidor Windows, coincide con el Forest Name ya usado en 8.5). Corregido registrando la identidad de nuevo con `dombase\usr_qasailpoint` y actualizando el campo en IIQ.

**Nota sobre copy/paste vía RDP:** durante todo este proceso, el copy/paste hacia las sesiones RDP corrompió caracteres de forma repetida y silenciosa — `$` perdidos antes de `JAVA_HOME`, guiones pegados a la ruta siguiente (`-keystore -/usr/lib/...`), líneas completas concatenadas sin salto de línea, "trustcacerts" convertido en "trustcerts". Cuando un comando de `keytool` truena con errores que no tienen sentido a simple vista, **revisar carácter por carácter antes de re-ejecutar**, o mejor, escribir el bloque completo dentro de `nano` primero (donde el pegado solo inserta texto sin ejecutar nada) y correrlo como script con `bash archivo.sh`.

---

## 9. Aplicar el patch 8.5p1 (después de validar el GA)

Solo hasta que confirmes login exitoso en la sección 6.6 con el GA corriendo bien:

1. Verifica el contenido del patch — trae solo scripts `upgrade_*`, no `create_*`:
   ```bash
   find ~/iiq_install -iname "identityiq-8.5p1.jar"
   mkdir ~/iiq_install/identityiq_staging_p1
   cd ~/iiq_install/identityiq_staging_p1
   jar -xvf ~/iiq_install/identityiq-8.5p1.jar
   ls doc/   # revisa si trae instrucciones específicas de este patch
   ```
2. Para el patch generalmente hay que: parar Tomcat, sobreponer el `WEB-INF` del patch sobre el desplegado en `/opt/tomcat/webapps/identityiq/`, correr `upgrade_identityiq_tables-8.5p1.mysql` contra la base ya creada, y reiniciar Tomcat. Los pasos exactos varían por versión — el `doc/` del patch (si trae README o release notes) es la fuente más confiable para esto.
3. Después del patch, verifica la versión desde la UI (Configuración del sistema → About, o el pie de página) para confirmar que el parche aplicó.

## 10. Integración SSO con Okta (resuelve la sección 6.7)

### 10.1 Valores enviados al equipo de Okta (lado SP)

| Campo | Valor |
|---|---|
| **Entity ID** (Audience URI / SP Entity ID) | `https://iga-qa.bancobase.net/identityiq` |
| **ACS URL** (Single sign on URL) | `https://iga-qa.bancobase.net/identityiq/home.jsf` |
| SAML Binding | HTTP-POST |
| Name ID Format | `emailAddress` |

### 10.2 Metadata recibida de Okta (lado IdP)

- **SSO URL:** `https://secure.bancobase.com/app/bancobase_sailpointqa_1/exk26kbz4jdxOIcVU1d8/sso/saml`
- **Entity ID / Issuer:** `http://www.okta.com/exk26kbz4jdxOIcVU1d8`
- **Certificado X.509:** vigente hasta 2036

### 10.3 Configuración en IIQ

Ícono de engrane → **Global Settings → Login Configuration → SSO Configuration**:

1. Marca **"Enable SAML Based Single Sign-On (SSO)"**.
2. Pega la SSO URL y el Entity ID/Issuer de Okta (sección 10.2).
3. Pega el certificado X.509 de Okta.
4. Configura los valores del SP (sección 10.1): Entity ID, ACS URL, binding HTTP-POST, NameID format `emailAddress`.
5. **Guarda a mano, antes de seguir:** `http://localhost:8080/identityiq/login.jsf?prompt=true` — login directo que evita el SSO, para no quedarte fuera si algo queda mal configurado. **Nota:** una vez habilitado SAML SSO, el logout normal de la UI se deshabilita.

### 10.4 Regla de correlación por email — ✅ Hecho

La regla de ejemplo de SailPoint (`IdentityNowSAML`) correlaciona por **username**, pero el NameID Format que configuramos es `emailAddress` — con la regla default, el lookup casi seguro falla. Se creó una regla nueva que busca el Identity por el atributo `email` en vez de por username:

```xml
<?xml version='1.0' encoding='UTF-8'?>
<!DOCTYPE Rule PUBLIC "sailpoint.dtd" "sailpoint.dtd">
<Rule language="beanshell" name="Okta Email Correlation" type="SAMLCorrelation">
  <Signature>
    <Inputs>
      <Argument name="log">
        <Description>Logger to take care of logging.</Description>
      </Argument>
      <Argument name="context">
        <Description>SailPointContext</Description>
      </Argument>
      <Argument name="assertionAttributes">
        <Description>Map of attributes taken from the SAML assertion</Description>
      </Argument>
    </Inputs>
    <Returns>
      <Argument name="ident">
        <Description>Matching identity based on the nameId (email) taken from assertionAttributes</Description>
      </Argument>
    </Returns>
  </Signature>
  <Source><![CDATA[
        import sailpoint.object.Identity;
        import sailpoint.object.Filter;
        import sailpoint.object.QueryOptions;
        import java.util.List;

        // Okta SAML Name ID Format is set to emailAddress, so nameId
        // arrives here as the user's email, not their IIQ username.
        String nameId = (String) assertionAttributes.get("nameId");
        Identity ident = null;

        if (nameId != null) {
            QueryOptions qo = new QueryOptions();
            qo.addFilter(Filter.ignoreCase(Filter.eq("email", nameId)));
            List identities = context.getObjects(Identity.class, qo);

            if (identities != null && identities.size() == 1) {
                ident = (Identity) identities.get(0);
            } else if (identities != null && identities.size() > 1) {
                log.error("Multiple identities found with email: " + nameId);
            } else {
                log.warn("No identity found with email: " + nameId);
            }
        }

        return ident;
    ]]></Source>
</Rule>
```

**Importar y seleccionar:**
1. **Global Settings → Import from File** → sube este XML como `OktaEmailCorrelation.xml`.
2. Regresa a **SSO Configuration** → dropdown **SAML Correlation Rule** → cambia de `IdentityNowSAML` a **`Okta Email Correlation`**.
3. Guarda.

⚠️ **Gotcha real al importar — error de XML, no de SailPoint:** el primer intento de import falló con `Line: 38 Column:37: The entity name must immediately follow the '&' in the entity reference`. Causa: el código Beanshell dentro de `<Source>` tiene un `&&` (AND lógico), y XML interpreta cualquier `&` suelto como inicio de una entidad (`&amp;` etc.) — sin `CDATA`, el parser truena ahí. **Fix:** envolver todo el contenido de `<Source>` en `<![CDATA[ ... ]]>`. El XML de arriba ya viene con ese fix aplicado — si se necesita regenerar esta regla desde cero, no quitar el CDATA.

**✅ Confirmado:** import exitoso con el XML corregido (CDATA), regla seleccionada en el dropdown, guardada, y persistencia confirmada tras refrescar la página.

### 10.5 Validar sin identidades agregadas todavía

Como aún no se ha corrido ninguna agregación real (AD sigue pendiente del IQService, sección 8), hay dos formas de validar sin datos reales:

- **Opción 1 (solo lectura):** revisa `catalina.out` buscando el warning `No identity found with email:` — confirma que el mecanismo SAML llega hasta el lookup, sin necesidad de que exista una identidad real.
- **Opción 2 (prueba end-to-end real):** edita la identidad `spadmin` (Identities → Identity Warehouse → `spadmin` → atributos) y agrégale tu propio correo en el atributo `email`. Si el login vía Okta te deja entrar como `spadmin`, el flujo completo (SAML + correlación) está confirmado.

No le confirmes al equipo de Okta que "ya quedó" hasta pasar por la Opción 2 con éxito.

### 10.6 Corregir el "Application username format" en Okta — 🔄 en progreso con el equipo de Okta

Se asignó la app en Okta usando tu correo, pero el **formato de Application username quedó en su valor por default (ID interno)**, no en Email — eso significa que el NameID real que llega a IIQ no es tu correo, así que la regla de correlación de 10.4 no va a matchear nada aunque esté bien seleccionada.

1. Okta Admin → **Applications** → la app de SailPoint (`bancobase_sailpointqa_1`).
2. Pestaña **Sign On** → baja hasta **Credentials Details**.
3. Cambia **Application username format** a **Email**.
4. En **Update application username on**, deja "Create and update" para que corrija también tu asignación ya existente (o quítate y vuelve a asignarte la app si no se refresca solo).
5. En **Edit SAML Integration**, confirma también que el campo **Name ID** (Attribute Statements / General) esté mapeado a `user.email` y no solo el *formato* — puede estar declarado como `emailAddress` en formato pero seguir tomando `user.login` como valor real.
6. Guarda.

Para confirmar qué NameID se está mandando sin depender de que el front end de IIQ esté accesible (ver 10.7), instala la extensión **SAML-tracer** (Chrome/Firefox) antes de intentar el login — captura el SAMLResponse completo en Base64 aunque la página final no cargue.

**Estado:** el equipo de Okta está aplicando directamente este cambio (pasos 1–6). **Pendiente al retomar:** confirmar con ellos que ya quedó, y correr la verificación con SAML-tracer.

### 10.7 Bloqueo de acceso: DNS activo, reverse proxy 443 aún no existe

Con el registro DNS de `iga-qa.bancobase.net` ya activo, **el flujo SAML siempre termina ahí** (POST al ACS URL registrado en Okta), sin importar si entras desde el dashboard de Okta, desde `localhost`, o directo — el túnel SSH solo mapea `localhost:8080` a Tomcat, no hace que `iga-qa.bancobase.net` resuelva a eso ni hable HTTPS. Como el reverse proxy en el 443 (la sección de red pendiente, ver 10.9) nunca se implementó, nada escucha ahí — de ahí el `ERR_CONNECTION_TIMED_OUT` / "no se puede mostrar la página".

**Workaround local temporal** (solo para seguir probando la lógica de correlación mientras el proxy real avanza — no reemplaza la prueba real ni sirve para decirle a Okta que "ya quedó"):

1. Confirma que tu túnel SSH sigue vivo (`localhost:8080` → `10.50.54.147:8080`).
2. Edita el archivo hosts de tu máquina (`C:\Windows\System32\drivers\etc\hosts`) y agrega:
   ```
   127.0.0.1   iga-qa.bancobase.net
   ```
   Esto hace que *solo en tu máquina* ese hostname resuelva a localhost en vez del DNS real.
3. Tomcat habla HTTP plano en el 8080 — necesitas algo que reciba HTTPS en el 443 local y reenvíe a tu túnel. Opciones ligeras:
   - **stunnel** en Windows: escucha `443` con un certificado autofirmado y reenvía a `127.0.0.1:8080`.
   - O un **nginx local** con `listen 443 ssl; proxy_pass http://127.0.0.1:8080;`.
4. Intenta el login otra vez. El navegador va a marcar el certificado como no confiable — es esperado (self-signed), acepta la excepción.
5. Si 10.4 y 10.6 ya están corregidos, deberías caer al home de IdentityIQ autenticado.

### 10.8 Login directo de emergencia

Mientras el SSO no esté 100% validado, ten a la mano el login que evita SAML por completo (vía el túnel SSH):
```
http://localhost:8080/identityiq/login.jsf?prompt=true
```
⚠️ La documentación oficial de SailPoint (varias versiones, 8.3–8.4) trae esta URL mal escrita como `/identityiq/spt/login.jsf` — es un typo que arrastran ellos mismos y da 404. La ruta real, confirmada, es sin el `spt/`.

### 10.9 Pendiente real de fondo — ⚠️ DECISIÓN CAMBIADA: ya NO es Imperva

**El plan original de esta sección (exponer vía Imperva, con LB externo + NAT en DMZ) quedó descartado.** Decisión nueva: **acceso solo interno, sin exposición a internet en absoluto.** Esto simplifica bastante lo que hay que pedirle a redes — ya no se necesita DMZ, LB externo, ni regla NAT hacia IP pública.

**Arquitectura decidida:**
- Un **nginx** propio (ligero, sin WAF) termina TLS en el puerto **443**, en el mismo servidor Linux (`10.50.54.147`) o en uno dedicado
- `proxy_pass http://127.0.0.1:8080;` hacia el Tomcat de IIQ
- Se mantiene el puerto **443 estándar** a propósito, para que `https://iga-qa.bancobase.net/identityiq` y `.../home.jsf` (Entity ID / ACS URL ya enviados a Okta) sigan siendo válidos tal cual — **evita tener que volver a coordinar con Okta** por un cambio de puerto
- Regla de firewall interna: solo TCP 443, origen las subredes/VLANs de los usuarios que van a entrar, destino donde quede nginx — mucho más simple que el ticket original de Imperva

**Certificado — mismo proceso interno que ya se usó para `scan.bancobase.com`:**
1. En el servidor donde vaya a vivir nginx:
   ```bash
   mkdir -p ~/certs/iga-qa && cd ~/certs/iga-qa
   openssl genrsa -out iga-qa.bancobase.net.key 2048
   chmod 600 iga-qa.bancobase.net.key
   openssl req -new -key iga-qa.bancobase.net.key \
     -out iga-qa.bancobase.net.csr \
     -subj "/C=MX/O=Banco Base/CN=iga-qa.bancobase.net" \
     -addext "subjectAltName=DNS:iga-qa.bancobase.net"
   openssl req -text -noout -verify -in iga-qa.bancobase.net.csr
   ```
   (verificar que salga `Verify OK` y que el CSR traiga el SAN — obligatorio, los clientes modernos rechazan certs sin SAN)
2. Descargar solo el `.csr` (nunca el `.key`) y mandarlo por correo a **Gilberto Ruiz Camarillo**, con copia a **CISTI** y **Team Windows** — mismo flujo que `scan.bancobase.com`. Mencionar en el correo que es para QA de IdentityIQ, acceso **interno únicamente**.
3. Al recibir el cert firmado, pedir también la cadena de confianza (intermedio/root de la CA interna) para la config completa de nginx.

**Confirmar DNS interno:** el registro `iga-qa.bancobase.net` se documentó originalmente como DNS **externo** — falta confirmar si también resuelve desde la red interna, o si hay que crear/copiar el registro en la zona DNS interna apuntando al servidor donde quede nginx.

**Estado al cierre de la última sesión:** decisión de arquitectura tomada, pasos de generación del CSR entregados — **no confirmado si el CSR ya se generó/envió**. Esto es lo primero que hay que retomar de este hilo.

**El workaround local (10.7, hosts + stunnel) sigue siendo válido** mientras tanto, solo para que tú sigas probando 10.4/10.6/10.5 — no lo repliques para otros usuarios, no reemplaza al nginx interno.

### 10.10 Certificado wildcard de `bancobase.net` — identificar qué es antes de usarlo

**Situación (25/09/2026):** al entrar directo a `https://iga-qa.bancobase.net/identityiq/home.jsf` el navegador da `ERR_CONNECTION_TIMED_OUT` ("took too long to respond"). **Esto NO es un problema de certificado** — un timeout ocurre en la capa de red, *antes* del handshake TLS: significa que nada responde en el puerto 443 del destino al que resuelve `iga-qa.bancobase.net` (justamente lo descrito en 10.7: el reverse proxy del 443 nunca se implementó). Un certificado solo importa *después* de que algo conteste en ese puerto; instalarlo por sí solo no arregla este error. Un problema de certificado se vería como una advertencia ("Your connection is not private"), no como un timeout.

**Lo que sí hay:** un certificado **wildcard** de `bancobase.net` (con su llave) que la organización ya usa para varios sitios. Antes de decidir dónde instalarlo hay que saber **quién lo emitió**, porque cambia el plan:
- **Emitido por una CA pública** (GoDaddy, DigiCert, Sectigo…): cualquier navegador ya confía en él → puede ir directo en el nginx real (10.9) sin esperar el CSR firmado por la CA interna. Sería mejor que el plan original.
- **Emitido por la CA interna del banco:** equivale a lo que se pedía en 10.9; igual sirve para nginx.
- **Autofirmado** (issuer = subject): solo sirve para el workaround local (10.7), con excepción manual en el navegador.

**Cómo saberlo en Windows (PowerShell nativo, sin instalar nada)** — sobre el archivo del certificado (`.crt`/`.cer`/`.pem`, solo la parte pública):
```powershell
$cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2("C:\ruta\a\wildcard.crt")
$cert.Subject      # a quién pertenece, esperado: CN=*.bancobase.net
$cert.Issuer       # quién lo firmó (aquí está la respuesta)
$cert.NotBefore
$cert.NotAfter     # que no esté vencido
($cert.Extensions | Where-Object {$_.Oid.FriendlyName -eq "Subject Alternative Name"}).Format($true)   # debe traer DNS Name=*.bancobase.net
```
Si viene en un `.pfx` (cert + llave juntos): `$cert = Get-PfxCertificate -FilePath "C:\ruta\a\wildcard.pfx"` y los mismos campos (pide la contraseña del `.pfx` si tiene).

**Con OpenSSL (Git Bash en Windows, o en el Linux):**
```bash
openssl x509 -in wildcard.crt -noout -subject -issuer -dates -ext subjectAltName
# Verificar que la llave corresponde al certificado — los dos hashes deben ser IDÉNTICOS:
openssl x509 -noout -modulus -in wildcard.crt | openssl md5
openssl rsa  -noout -modulus -in wildcard.key | openssl md5
```
Si al leer la llave pide contraseña, está protegida con passphrase — hay que saberlo antes de configurarla en nginx/stunnel (esperan la llave sin cifrar, o hay que resolver cómo pasar la contraseña al arrancar el servicio).

**Pendiente:** correr esos comandos y anotar aquí `Subject`, `Issuer`, vigencia y SAN. Con eso se decide entre nginx real (10.9) o workaround local (10.7). **Aunque el cert esté perfecto, además hay que tener algo escuchando en el 443 y el DNS interno de `iga-qa.bancobase.net` apuntando ahí** — sin eso el timeout sigue igual.

---

## 13. Cargar identidades de AD en QA (Account Aggregation)

**Verificado primero:** la app `BancoBase-Application-DirectorioActivo` en producción **no es Authoritative** → se dejó igual (sin marcar) en `Active Directory - QA`, para replicar el comportamiento real.

**Importante — qué esperar:** como AD no es authoritative, las cuentas solo se convierten en identidad completa si correlacionan con una identidad **que ya exista** en el warehouse (normalmente creada por otra fuente authoritative, como HR o Intelexion, que en este QA probablemente todavía no está cargada). Es muy probable que la primera corrida deje las cuentas como **"Unmatched Accounts"** en vez de identidades pobladas — no es un error, es records sin fuente authoritative que las cree. Sirve igual para validar que la lectura de AD funciona de punta a punta.

**Menú Lifecycle Events no aparece bajo Setup:** confirmado que esto es normal si Lifecycle Manager no está habilitado/licenciado en este ambiente — significa que ningún workflow tipo Joiner/Mover/Leaver puede dispararse automáticamente, sin importar qué traiga la aggregation.

**Pasos:**
1. **Setup → Tasks → New Task → Account Aggregation**
2. **Application:** `Active Directory - QA`
3. Ejecución manual la primera vez (no programada)
4. **Execute Now**
5. Revisar **Task Results**: cuentas leídas, identidades creadas/actualizadas, cuentas sin correlacionar
6. Confirmar en **Identities → Identity Warehouse** (o el reporte de cuentas sin correlacionar) qué tanto quedó poblado

**⚠️ Estado al cierre de la última sesión:** los pasos 1–4 ya se hicieron (tarea creada y ejecutada con `Execute Now`), pero **el resultado del Task Result (paso 5) nunca se revisó** — se pasó a resolver otros pendientes (Okta, Google Workspace, Intelexion) mientras corría. **Esto es lo primero que hay que revisar al retomar:** entrar a la tarea ya completada en Setup → Tasks, ver cuántas cuentas se crearon/actualizaron vs. cuántas quedaron como Unmatched.

**Nota de manejo de datos:** esto trae PII real de empleados del banco hacia la base de datos de este ambiente de QA — ya asumido desde que se conectó contra el AD real, pero vale la pena confirmar con el equipo si hay algún requisito de alcance/retención para datos reales en QA antes de dejarlo como tarea recurrente.

---

## 14. Google Workspace en QA

**Decisión tomada:** QA va a **reutilizar el service account de producción** (mismo tenant real `bancobase.com` — no existe "un Google Workspace de QA" separado, igual que con AD).

**Configuración de referencia en producción** (`BancoBase-Application-GoogleWorkspace`, tipo `G Suite`):

| Campo | Valor en producción |
|---|---|
| Authentication Method | OAuth 2.0 |
| Grant Type | Service Account |
| Email Address of Service Account | `sailpoint-identityiq@integracion-gws-sailpoint.iam.gserviceaccount.com` (project GCP: `integracion-gws-sailpoint`) |
| Email Address of User to Impersonate | `usrsailpointprd@bancobase.com` |
| Scopes | lista larga de scopes `googleapis.com/auth/admin.directory.*`, `gmail.settings.*`, `mail.google.com/`, etc. — copiar exacta de prod, carácter por carácter |
| Private Key | ver receta completa abajo — **no** es tan simple como pegar el P12 |
| Private Key Password | `notasecret` (ver nota abajo) |
| Read Group Details | `Y` |
| Page Size | `100` |

### 14.1 Consiguiendo la Private Key

**Google nunca permite volver a descargar una llave ya existente** — ni desde la consola con super admin, ni de ninguna forma. Si no tienes el `.p12`/`.json` original guardado en algún vault, la única opción es generar una llave **nueva** para el mismo service account (esto NO requiere volver a autorizar Domain-Wide Delegation, porque esa autorización está ligada al **Client ID** del service account, no a la llave individual):

1. https://console.cloud.google.com → selecciona el proyecto **`integracion-gws-sailpoint`**
2. **IAM & Admin → Service Accounts** → abre `sailpoint-identityiq@...`
3. Pestaña **Keys → Add Key → Create new key**
4. Tipo **P12** (no JSON — el conector on-prem de IIQ espera este formato)
5. **Create** → se descarga el `.p12`. Password fijo siempre: **`notasecret`** (constante de Google para toda llave P12, no algo que Banco Base haya definido)

⚠️ Cada llave P12 nueva generada queda como **credencial viva adicional** sobre un service account con permisos admin amplios sobre todo el Workspace real — vale la pena, como práctica de seguridad, llevar registro de cuántas llaves activas tiene este service account y eventualmente limpiar las que ya no se usen.

**Si aparece una llave "vieja" guardada en algún lado (JSON o P12):** antes de usarla, validar dos cosas:
- **Pertenece al service account correcto:** en el JSON, el campo `client_email` debe decir exactamente `sailpoint-identityiq@integracion-gws-sailpoint.iam.gserviceaccount.com`. En el P12 no hay forma directa de ver esto en el archivo.
- **Sigue activa en GCP (no fue revocada):** compara el `private_key_id` (JSON) o el nombre del archivo `.p12` descargado (normalmente ES el key ID) contra la lista real en **Service Accounts → Keys** en GCP — si no aparece ahí, la llave fue borrada y no sirve aunque el archivo exista localmente.

### 14.2 Convertir la llave a un formato que el conector acepte (la parte que costó más trabajo)

El campo "Private Key" de IIQ es de texto — un `.p12` es binario, no se puede pegar tal cual. Y aquí viene el detalle importante que costó dos intentos fallidos: **el conector espera el formato PEM "tradicional" (PKCS#1, `-----BEGIN RSA PRIVATE KEY-----`)**, no el formato moderno PKCS#8 (`-----BEGIN ENCRYPTED PRIVATE KEY-----`) que OpenSSL genera por default desde la versión 3.x. Si le das el formato equivocado, el error es:
```
Failed to generate access token with service account: class org.bouncycastle.pkcs.PKCS8EncryptedPrivateKeyInfo cannot be cast to class org.bouncycastle.openssl.PEMKeyPair
```
(bug/comportamiento documentado de la librería BouncyCastle que usa el conector — no es un problema del certificado en sí).

**Receta correcta, paso a paso** (todo en el servidor Linux, con `openssl`):

```bash
# 1. Extraer la llave sin encriptar del P12
openssl pkcs12 -in <archivo>.p12 -nocerts -nodes -passin pass:notasecret -out privatekey_plain.pem

# 2. Convertir a formato tradicional PKCS#1, encriptada con el método viejo de OpenSSL
#    (el flag -traditional es OBLIGATORIO en OpenSSL 3.x — sin él, sigue dando PKCS#8
#    aunque uses "openssl rsa" en vez de "openssl pkcs8")
openssl rsa -in privatekey_plain.pem -des3 -traditional -passout pass:notasecret -out privatekey_legacy_encrypted.pem

# 3. Verificar el resultado
cat privatekey_legacy_encrypted.pem
```

El resultado correcto debe verse así:
```
-----BEGIN RSA PRIVATE KEY-----
Proc-Type: 4,ENCRYPTED
DEK-Info: DES-EDE3-CBC,XXXXXXXXXXXXXXXX

<base64>
-----END RSA PRIVATE KEY-----
```

**Qué copiar a IIQ:** todo el bloque de arriba, **incluyendo** las líneas `Proc-Type:` y `DEK-Info:` (son parte necesaria de la llave, no metadata a descartar). Password en IIQ: `notasecret`.

**Nota aparte — si conviertes directo desde `openssl pkcs12` sin pasar por el paso 2:** el output trae unas líneas de comentario al inicio (`Bag Attributes`, `friendlyName`, `localKeyID`, `Key Attributes: <No Attributes>`) — **esas sí hay que excluirlas**, no son parte de la llave. Solo se copia desde `-----BEGIN...-----` hasta `-----END...-----`. (Es un caso distinto al de arriba: ahí el header con Proc-Type/DEK-Info sí se incluye porque es parte del formato legacy; estas líneas de "Bag Attributes" nunca se incluyen, sea cual sea el formato final.)

### 14.3 Estado actual — bloqueante

Con la llave ya en el formato correcto, el error de parsing desapareció. Ahora falla un paso más adelante:
```
[InvalidConfigurationException] Failed to generate access token with service account. Unable to generate access token. 
Response returned: java.net.SocketException: Connection reset
```

Esto **ya no es de la llave ni de la configuración de la app** — es de red, pero hacia **internet** (los servidores OAuth de Google), no hacia un host interno del banco como los bloqueos anteriores. Hipótesis principal: producción tiene un **proxy de salida corporativo** configurado para el Tomcat que sale a internet, y el Tomcat de QA no lo tiene.

**Diagnóstico pendiente al retomar:**
```bash
# ¿Hay variables de proxy ya configuradas?
env | grep -i proxy
grep -ri proxy /opt/tomcat/bin/setenv.sh 2>/dev/null
grep -ri proxy /opt/tomcat/bin/catalina.sh 2>/dev/null

# ¿Hay salida directa a internet desde este segmento?
curl -v https://oauth2.googleapis.com/token
curl -v https://www.googleapis.com
```
Si en producción existe algo como `-Dhttps.proxyHost=... -Dhttps.proxyPort=...` en el arranque de Tomcat y en QA no, esa es la diferencia — replicarlo y reiniciar Tomcat. Si de plano no hay salida a internet desde ningún lado en este segmento, es ticket a redes: origen `10.50.54.147`, destino `oauth2.googleapis.com` / `www.googleapis.com` (dominios de Google, IP dinámica), TCP 443 saliente.

**Recomendación de seguridad (vigente):** este conector, a diferencia de AD, si tiene Provisioning Policies activas puede **escribir** cambios reales en cuentas de Google Workspace de producción. Mientras la app en QA sea solo para pruebas de lectura, dejar las Provisioning Policies vacías y sin conectar a certificaciones o lifecycle events.

---

## 15. Intelexion en QA (`Intelexion - QA`)

App de tipo **Web Services** que replica la de producción (`BancoBase-Application-IntelexionWebService`) — maneja el alta de nuevos usuarios (onboarding) en Banco Base.

**Configuración** (idéntica a producción, confirmado campo por campo en Details y Configuration):
- **Base URL:** `https://api.bancobase.com`
- **Authentication Method:** No / Custom Authentication
- **Schema Attribute for Account Enable status:** `Status=Candidato`
- **Request Timeout:** 60 segundos
- **Connector Operations:** `Custom Authentication` (Obtener token) → `Test Connection` (Probar conexión) → `Account Aggregation` (Agregar cuentas) → `Get Object` (Obtener cuenta), en ese orden

### 15.1 Bloqueante de red — resuelto (ticket a redes)

Primer bloqueante, mismo patrón que 8080 (Cloud Gateway) y 5050 (IQService):
```
Exception occurred in Test Connection. Url: https://identity.bancobase.com/connect/token, 
Message: 0 : org.apache.http.conn.HttpHostConnectException: Connect to identity.bancobase.com:443 
[identity.bancobase.com/10.48.17.85] failed: Connection refused, HTTP Error Code: 0
```
`10.48.17.85` es IP privada (RFC1918) → `identity.bancobase.com` es un servicio interno del banco. Se mandó ticket a redes (origen `10.50.54.147`, destino `identity.bancobase.com`/`10.48.17.85`, TCP 443) — **✅ resuelto**, la comunicación ya quedó habilitada.

### 15.2 Bloqueante de TLS — resuelto (certificado GoDaddy)

Al habilitarse la red, el error cambió a un problema de confianza TLS:
```
javax.net.ssl.SSLHandshakeException: (certificate_unknown) PKIX path building failed:
unable to find valid certification path to requested target
```
Diagnóstico con `openssl s_client -connect identity.bancobase.com:443 -servername identity.bancobase.com -showcerts`: la cadena es de una CA **pública** (GoDaddy TLS Intermediate CA DV - R1v1 → GoDaddy TLS Root CA - R1), no una CA interna del banco — el JDK 17.0.19 de este ambiente simplemente no traía todavía esa jerarquía. Se resolvió importando el certificado intermedio al truststore de Java, igual que se hizo con el IQService en 8.6:
```bash
sudo $JAVA_HOME/bin/keytool -import -trustcacerts -alias godaddy-tls-intermediate-r1v1 \
  -file /home/<usuario>/certs/godaddy-intermediate-r1v1.pem \
  -keystore $JAVA_HOME/lib/security/cacerts -storepass changeit
sudo systemctl restart tomcat
```
**✅ resuelto** — no fue necesario tocar el firewall ni salir a internet, el certificado completo venía en el propio handshake.

### 15.3 Bloqueante de autenticación — resuelto (client_id/secret)

Con TLS resuelto, el error avanzó a la capa OAuth:
```
Exception occurred in Test Connection. Url: https://identity.bancobase.com/connect/token,
Message: 400 : Bad Request : {"error":"invalid_client"}, HTTP Error Code: 400
```
Causa: al copiar la operación **Custom Authentication (Obtener token)** de prod a QA, algún carácter del client_id/client_secret no quedó exactamente igual. **✅ resuelto** al re-copiar esos campos carácter por carácter desde la app de producción.

### 15.4 Correlation — Account/Manager Correlation configuradas

El wizard de **Attribute Based Correlation** (pestaña Correlation) mostraba el dropdown de "Application Attribute" completamente vacío. La causa real **no** era el Account Schema de la app, sino el **`ObjectConfig:Identity`** (atributos extendidos de Identity a nivel global de IIQ) — en prod tiene ~50 atributos extendidos (`idPersona`, `idempleado`, `NIPJefe`, etc., con `AttributeSource` apuntando a `BancoBase-Application-IntelexionWebService` y `BancoBase-Application-DirectorioActivo`), y en QA ese `ObjectConfig` estaba prácticamente vacío por ser una instalación nueva.

**Solución:** exportar el `ObjectConfig:Identity` completo de prod (Debug page → Class `ObjectConfig` → `Identity`), remapear las referencias de aplicación (`id`/`name`) a las apps reales de QA (`Intelexion - QA`, `Active Directory - QA`), conservar el `id` original del `ObjectConfig` de QA, e importarlo con `iiq console` (más confiable que pegarlo en el editor web de Debug, que dio varios errores de sincronización de sesión — `Duplicate entry`, `checkIllegalRename`):
```bash
sudo cp /home/<usuario>/identity_objectconfig_prod.xml /tmp/identity_objectconfig_prod.xml
sudo chmod 644 /tmp/identity_objectconfig_prod.xml
sudo -u tomcat /opt/tomcat/webapps/identityiq/WEB-INF/bin/iiq console
> import /tmp/identity_objectconfig_prod.xml
```
**Script de remapeo usado (PowerShell en Windows, sobre el XML exportado de prod).** Referencia de ids: `ObjectConfig:Identity` de QA `0a32315395c816138195c8ed2659011e` · `Intelexion - QA` `0a323693a0b5123d81a0c51dc43f3334` (prod: `0a32315395cf1fac8195d031ebe30254`) · `Active Directory - QA` `0a323693a068141d81a0b54d3b0b0650` (prod: `0a32315395ca16b58195ceda3f73069c`). Ojo: el XML exportado de prod ya trae `created=`/`modified=` antes del `id=` en la etiqueta `<ObjectConfig>` — en este caso el `id` de QA ya coincidía tal cual; verificar en la línea 3 antes de importar (si no está el `id` correcto de QA, el import intenta crear un objeto nuevo y choca contra la restricción UNIQUE del `name`):
```powershell
$file = "C:\ruta\identity_objectconfig_prod.xml"
$content = Get-Content -Path $file -Raw
$content = $content.Replace('id="0a32315395cf1fac8195d031ebe30254" name="BancoBase-Application-IntelexionWebService"', 'id="0a323693a0b5123d81a0c51dc43f3334" name="Intelexion - QA"')
$content = $content.Replace('id="0a32315395ca16b58195ceda3f73069c" name="BancoBase-Application-DirectorioActivo"', 'id="0a323693a068141d81a0b54d3b0b0650" name="Active Directory - QA"')
# Textos descriptivos de AttributeSource/@name (no son referencias reales, solo evitan que la UI diga "prod"):
$content = $content.Replace('AppRule: BancoBase-identityMap-type BancoBase-Application-IntelexionWebService', 'AppRule: BancoBase-identityMap-type Intelexion - QA')
$content = $content.Replace('AppRule: BancoBase-IdentityMap-MX BancoBase-Application-IntelexionWebService', 'AppRule: BancoBase-IdentityMap-MX Intelexion - QA')
[System.IO.File]::WriteAllText($file, $content, (New-Object System.Text.UTF8Encoding($false)))   # sin BOM
```
Verificación esperada: 0 ocurrencias de `BancoBase-Application-IntelexionWebService` y `BancoBase-Application-DirectorioActivo`; ~62 de `Intelexion - QA`; 1 de `Active Directory - QA`.

**Gotcha de permisos:** el usuario `tomcat` no puede leer archivos dentro de `/home/<usuario>/` (home en `700`) → `Permission denied` en el `import`. Por eso el archivo se copia a `/tmp` con `chmod 644` antes de importar.

**⚠️ Pendiente de verificar:** el `ObjectConfig` importado referencia 3 Rules de prod: `BancoBase-IdentityMap-Inactive`, `BancoBase-identityMap-type` y `BancoBase-IdentityMap-MX` (alimentan los atributos `inactive`, `type` y `pais`). El import pasó, pero **no se confirmó que esos Rules existan en QA** — si no existen, esos tres atributos no se calcularán al agregar. Verificar en el Object Browser (Class `Rule`) o con `list Rule` en `iiq console`; si faltan, se exportan de prod y se importan igual que el ObjectConfig.

**✅ resuelto** — los atributos ya aparecen en los dropdowns de Correlation. Con eso se configuró:
- **Account Correlation:** `idPersona` (Application Attribute) → `displayName` (Identity Attribute)
- **Manager Correlation:** `NIPJefe` (Application Attribute) → `idempleado` (Identity Attribute)

**Nota cosmética (no bloqueante):** los atributos aparecen en los dropdowns con su `displayName` crudo (ej. `att_idempleado`) en vez de una etiqueta traducida, porque el catálogo de mensajes/idioma personalizado de prod (que traduce esas claves `att_*` a español legible) no se importó — es solo estético, no afecta la correlación real. Pendiente si se quiere replicar más adelante.

### 15.5 Bloqueante actual — error 500 del backend real (`api.bancobase.com`)

Con TLS, auth y Correlation resueltos, el Test Connection avanza hasta el endpoint real de negocio y falla ahí:
```
Exception occurred in Test Connection. Url: https://api.bancobase.com/api/integration/adm/empleados,
Message: 500 : "Object reference not set to an instance of an object.", HTTP Error Code: 500
```
Ese mensaje es el texto clásico de una excepción de referencia nula en .NET/C# — **ya no es un problema de configuración de IIQ**, es una excepción del lado del servidor de `api.bancobase.com`. Como la configuración se copió campo por campo de prod (donde sí funciona), la sospecha es algún parámetro/header que la operación **"Probar conexion"** manda vacío en QA y que en prod trae un valor válido.

**Diagnóstico pendiente al retomar:** abrir la operación "Probar conexion" (ícono de lápiz) y comparar método, path, headers y query params contra la misma operación en `BancoBase-Application-IntelexionWebService` de producción. Si están idénticas, es ticket al equipo dueño de `api.bancobase.com` con la evidencia (URL, método, hora del intento, el 500 completo) para que revisen sus logs de servidor.

---

## 16. 🚨 PLAN URGENTE — reset y desbloqueo de contraseñas con SailPoint (Okta como verificación de identidad)

**Estado: solo plan definido — nada de esto está implementado ni verificado todavía.** Es la prioridad #1 para la siguiente sesión.

### 16.1 Objetivo

Que los usuarios puedan **desbloquear su cuenta** y **cambiar/resetear su contraseña** por autoservicio usando SailPoint, usando **Okta para verificar su identidad** (en vez de depender de otro mecanismo de verificación).

### 16.2 El problema de fondo (huevo y gallina)

SailPoint está detrás de Okta (SSO por SAML, sección 10). Si a un usuario se le **bloquea** la contraseña, no puede autenticarse en Okta → no puede llegar a SailPoint → no puede usar SailPoint para desbloquearse. Por eso el plan tiene que ir **en este orden**:

1. **Fase 1 — Desbloqueo (primero):** un punto de entrada que funcione *aunque el usuario esté bloqueado*, es decir, **fuera del flujo normal de login de Okta**: una **liga en la pantalla de inicio de sesión de Okta Preview** ("¿Cuenta bloqueada? Desbloquéala aquí") que lleve al flujo de desbloqueo.
2. **Fase 2 — Cambio/actualización de contraseña (después):** ya con acceso, el usuario cambia o resetea su contraseña desde SailPoint (autenticado vía Okta, flujo normal).

### 16.3 Dependencias con lo ya construido

- **La liga de Fase 1 necesita una URL alcanzable por los usuarios reales**, no solo por tu túnel SSH. Hoy `iga-qa.bancobase.net` da `ERR_CONNECTION_TIMED_OUT` porque nada escucha en el 443 (10.7/10.9). **Por eso el hilo del nginx interno + el certificado wildcard (10.9/10.10) es prerrequisito de este plan.**
- Como SSO está activo, la pantalla de login nativa de IIQ (donde viven los enlaces de olvidé contraseña / desbloquear cuenta, si están habilitados) solo se ve con el bypass ya documentado en 10.8: `.../identityiq/login.jsf?prompt=true`.
- **AD ya está conectado** (8.5/8.6, `Active Directory - QA`, service account `dombase\usr_qasailpoint`) — es el sistema donde se aplicaría el desbloqueo/reset.

### 16.4 Preguntas abiertas — verificar ANTES de construir nada

| # | Pregunta | Por qué importa | Cómo verificarla |
|---|---|---|---|
| 1 | ¿Está **Lifecycle Manager (LCM)** habilitado/licenciado en este ambiente? | Hasta donde sé, las funciones de autoservicio de IIQ (Manage Passwords, Forgot Password, Unlock Account) se administran desde la configuración de LCM. En la sección 13 ya se vio que el menú *Lifecycle Events* **no aparece** bajo Setup, lo cual sugiere que LCM no está activo — si es así, esto cambia el enfoque por completo | Revisar si existe la opción de Lifecycle Manager en el menú de engrane de IIQ y qué ofrece; confirmar con quien lleva la licencia |
| 2 | ¿Cómo autentica Okta a los usuarios: **contra AD** (delegated auth / agente de AD) o con contraseña propia de Okta? | Define *dónde* vive el bloqueo. Si Okta delega a AD, un bloqueo en AD deja fuera de Okta; si Okta tiene su propia contraseña, el bloqueo de AD no afectaría el login a SailPoint | Preguntar al equipo de Okta / revisar la configuración de la org |
| 3 | ¿El service account `dombase\usr_qasailpoint` tiene permisos delegados en AD para **resetear contraseña** y **desbloquear cuentas** (escribir `lockoutTime`)? | Sin esos permisos, el conector no puede ejecutar ninguna de las dos operaciones aunque la UI de IIQ lo ofrezca | Equipo de AD/Windows; probar un unlock/reset sobre una cuenta de prueba |
| 4 | ¿Qué **política de contraseñas** aplica (la de AD) y está reflejada en la pestaña *Password Policy* de la app? | Que IIQ no acepte o rechace contraseñas distinto a AD | Comparar con la política de dominio |
| 5 | ¿Cómo se verificará la identidad **sin contraseña** durante el desbloqueo? | Ver opciones en 16.5 | Decisión de diseño (con Okta/seguridad) |

### 16.5 Opciones de diseño para verificar identidad con Okta (por decidir)

- **Opción A — Flujo nativo de IIQ:** la liga en Okta apunta a la pantalla de IIQ (`login.jsf?prompt=true`) con *Unlock Account* / *Forgot Password*. Verificación con lo que IIQ soporte de forma nativa (por ejemplo preguntas de reto), no con Okta. Más simple; depende de la respuesta a la pregunta #1.
- **Opción B — Okta verifica, IIQ ejecuta:** el usuario se verifica con los factores de recuperación/MFA de Okta (cuya disponibilidad depende de cómo esté configurada la org — ver pregunta #2), y eso dispara el desbloqueo/reset en IIQ o directo hacia AD. Es lo más cercano a lo que se busca (Okta como verificador), pero requiere diseñar cómo Okta le indica a IIQ que el usuario ya fue verificado (integración adicional, no construida). **No está validado que sea factible sin más piezas** — a confirmar con el equipo de Okta.

### 16.6 Orden de trabajo propuesto

1. Resolver las preguntas 1–3 de 16.4 (son de verificación, rápidas, y pueden invalidar el enfoque).
2. Decidir entre Opción A u B (16.5).
3. **Fase 1:** dejar `iga-qa.bancobase.net` alcanzable en el 443 (10.9/10.10) y agregar la liga de desbloqueo en la pantalla de login de **Okta Preview** — la configuración exacta de la liga (widget de inicio de sesión / enlaces de ayuda personalizados) la debe hacer o confirmar el equipo de Okta.
4. **Fase 2:** habilitar el cambio/reset autenticado de contraseña en SailPoint y probarlo con una cuenta de prueba.
5. Probar el caso completo: cuenta bloqueada → liga en Okta → desbloqueo → login normal → cambio de contraseña.

---

## 11. Siguientes pasos inmediatos

**Ya resuelto por completo:**
- Cloud Gateway (sección 7) — Tomcat propio en 8443, Test Connection exitoso.
- IQService en Windows (sección 8) — `IQService-Instance1` corriendo bajo `dombase\usr_qasailpoint`, TLS en 5050.
- **AD conectado (8.5/8.6)** — Test Connection exitoso, después de resolver firewall de red, TLS del certificado, Client Authentication, y el dominio NetBIOS correcto (`dombase`).
- **Regla de correlación de Okta (10.4)** — importada (con fix de CDATA), seleccionada, guardada y confirmada.

**🚨 PRIORIDAD #1 (nueva, 25/09/2026): sección 16 — plan de reset/unlock de contraseñas con SailPoint + Okta.** Empezar por las preguntas abiertas de 16.4 (sobre todo: ¿LCM habilitado? ¿cómo autentica Okta? ¿permisos del service account en AD?), antes de construir nada.

**Además hay 4 hilos abiertos en paralelo — este es el estado exacto de cada uno para retomar sin repetir trabajo:**

### 1. Account Aggregation de AD (sección 13) — revisar resultado
La tarea ya se creó y se ejecutó (`Execute Now`), pero **el Task Result nunca se revisó**. Primer paso al retomar: entrar a **Setup → Tasks**, abrir esa tarea ya completada, y ver cuántas cuentas se crearon/actualizaron vs. cuántas quedaron como `Unmatched` (esperado, dado que AD no es Authoritative — ver sección 13).

### 2. Google Workspace (sección 14) — bloqueado en conectividad a internet
El formato de la Private Key ya quedó resuelto (receta completa en 14.2, incluye el fix de `-traditional` para OpenSSL 3.x). El bloqueo actual es un `SocketException: Connection reset` al generar el token OAuth contra Google — probablemente falta un proxy de salida corporativo en el Tomcat de QA que sí existe en prod. Diagnóstico pendiente: revisar variables de proxy / `curl` directo a `oauth2.googleapis.com` (comandos exactos en 14.3).

### 3. Intelexion (sección 15) — bloqueado en el backend real de negocio
Red, TLS, autenticación OAuth y Correlation ya resueltos (15.1–15.4). Bloqueante actual: error 500 (`Object reference not set to an instance of an object.`) del propio `api.bancobase.com` al llegar a `Test Connection` → `Account Aggregation`. Pendiente al retomar: comparar la operación "Probar conexion" campo por campo contra prod (15.5); si están idénticas, es ticket al equipo dueño de esa API.

### 4. Okta/SSO (10.6 y 10.9) — en progreso con otros equipos
- **10.6:** el equipo de Okta está corrigiendo el Application username format directamente — falta confirmar con ellos que ya quedó, y validar con SAML-tracer.
- **10.9:** decisión de arquitectura cambiada (ya NO Imperva — acceso interno vía nginx propio). CSR para `iga-qa.bancobase.net` con pasos listos en 10.9, no confirmado si ya se generó/mandó a Gilberto Ruiz Camarillo.
- Mientras tanto, login directo de emergencia sigue disponible (10.8) y el workaround local hosts+stunnel (10.7) para seguir probando.
- **10.10:** ya existe un certificado wildcard de `bancobase.net` (con llave) usado en varios sitios. Falta identificar quién lo emitió y verificar que cert y llave coinciden (comandos en 10.10). Recordar: el `ERR_CONNECTION_TIMED_OUT` actual es de red (nada escucha en el 443), no de certificado — el cert solo sirve una vez que nginx esté escuchando y el DNS interno apunte ahí. Este hilo es **prerrequisito de la sección 16**.

**En pausa, retomar cuando se decida:**
- Sección 7.1 en adelante — ir creando en IIQ una aplicación por cada sistema real del banco que se vaya a intermediar a través del Cloud Gateway, conforme el equipo de red vaya confirmando zonas/reglas.

**Pendiente, al final de todo lo anterior:**
- Aplicar el patch 8.5p1 sobre el GA ya validado (sección 9).

**Sugerencia para la siguiente sesión:** arrancar por la **sección 16** (prioridad #1, empezando por verificar las preguntas de 16.4). Aparte, el hilo **#1 (revisar el Task Result de AD)** es el único que no depende de nadie más y toma minutos — buen punto de paso rápido.

---

## 17. 🐛 Hallazgos en PRODUCCIÓN a corregir a futuro (detectados durante la corrección de correlación de AD en QA, 28/09/2026)

**Estado: solo documentado — nada de esto se ha tocado en producción.** Se descubrieron revisando en detalle el Application, las Provisioning Rules y los Custom objects de `BancoBase-Application-DirectorioActivo` (AD prod) para poder replicarlos correctamente en `Active Directory - QA`. Ninguno de estos bloquea el trabajo en QA — para QA ya se corrigieron en las copias que se importan ahí — pero **en producción siguen tal cual** y conviene revisarlos cuando haya ventana.

### 17.1 "SP Dynamic Field Value Rule" — referencia rota en los ProvisioningForms de AD prod

Los formularios `Create` y `Update` (objectType=account) de `BancoBase-Application-DirectorioActivo` referencian, en prácticamente cada campo, un `RuleRef` a un Rule llamado **"SP Dynamic Field Value Rule"** (id `0a32315395c816138195c902a2f603a7`). Al buscarlo en Debug → Object Browser → Class `Rule` en producción, **el objeto no existe** — fue borrado o renombrado en algún momento y nadie corrigió las referencias.

**Impacto:** cualquier campo de esos formularios que dependa de ese Rule para calcular su valor (casi todos: distinguishedName, password, givenName, sn, displayName, department, manager, employeeID, etc.) no obtiene el valor dinámico esperado cuando alguien pasa por esos forms manualmente (por ejemplo, LCM o "Create Account" directo desde la consola de administración). Si el aprovisionamiento real de AD no pasa por ahí (p. ej. corre por Intelexion → AD sin usar estos forms), puede que nunca se haya notado.

**Acción sugerida:** ubicar si el Rule fue renombrado (buscar algo similar por contenido/función) o si de verdad se perdió; si se perdió, reconstruirlo o quitar las referencias rotas de los forms.

### 17.2 `BancoBase-AD-BeforeProvisioningRule` — inicialización del logger acoplada al nombre de la app

El Rule solo inicializa el objeto `log` si `applicationName.equalsIgnoreCase("BancoBase-Application-DirectorioActivo")`. Hoy no truena en prod porque el nombre siempre matchea, pero es frágil: si el Application se renombra alguna vez, o si este mismo Rule se reutiliza en otra app (como se hizo en QA), la condición deja de cumplirse, `log` queda `null`, y la regla completa truena con `NullPointerException` en la primera línea que loguea.

**Acción sugerida (no urgente):** quitar el `if` y dejar `log = LogFactory.getLog(...)` incondicional — así quedó corregido en la copia que se importa a QA.

### 17.3 `BancoBase-AD-AfterProvisioningRule` — nombre de aplicación fijo como string literal

La línea `String applicationName = "BancoBase-Application-DirectorioActivo";` está hardcodeada en vez de tomar `application.getName()`. Ese valor se usa para filtrar `plan.getAccountRequests(applicationName)` — si el Application se renombrara, el filtro dejaría de encontrar nada y toda la lógica de notificaciones por correo (create/disable/enable/delete) se ejecutaría en silencio sin hacer nada, sin ningún error visible.

**Acción sugerida (no urgente):** cambiar a `String applicationName = application.getName();` — así quedó corregido en la copia que se importa a QA.

### 17.4 `BancoBase-Application-DirectorioActivo_Valid_Domains` — typo `bancobase` en vez de `dombase`

El Custom object tiene como único valor `order:00001|DC=bancobase,DC=net`. El método `getValueFromADAccount()` de `BancoBase-AD-BeforeProvisioningRule` usa este valor para encontrar la entrada correspondiente en `domainSettings` del Application (comparando contra `domainDN`), y **el `domainDN` real configurado en el Application es `DC=dombase,DC=net`** (sin "banco"), tanto en prod como en QA. Como los dos strings nunca matchean, la búsqueda del DN del manager en AD (usada para poblar el atributo `manager` al crear una cuenta) probablemente **nunca encuentra el dominio** y falla en silencio — `val` se queda vacío.

**Impacto probable:** el campo `manager` no se está poblando correctamente en las cuentas de AD nuevas en producción vía este mecanismo (puede que sí se llene por otra vía, como el propio Create form, pero esta ruta específica de búsqueda por LDAP está rota).

**Acción sugerida:** confirmar revisando cuentas de AD recién creadas si el campo manager quedó vacío, y si es así, corregir el valor a `order:00001|DC=dombase,DC=net` en el Custom object de producción.

**Nota para QA:** se importó una copia idéntica (con el mismo typo, `DC=bancobase,DC=net`) para no divergir de prod sin confirmarlo contigo primero. Si quieres que la copia de QA ya traiga el valor corregido (`dombase`) para que esta función sí trabaje en QA aunque en prod siga rota, avísame y te regreso el archivo actualizado — es un cambio de una sola línea.

### 17.5 `BancoBase-CustomizationRule` — riesgo latente de NullPointerException

Detectado en una sesión anterior, sigue sin corregirse en prod: la regla hace `object.get("ProcesoBaja").toString()` sin validar que el campo no sea `null` antes de llamar `.toString()`. Si alguna cuenta de Intelexion llega sin `ProcesoBaja`, la regla truena. Bajo riesgo mientras el campo venga siempre poblado desde el origen, pero vale la pena blindarlo con una validación de null.

### 17.6 QA no tenía ningún Custom object propio

Al pedir `BancoBase-Custom-CountryData` para QA se confirmó que **QA no tenía ningún Custom object dado de alta** — ni siquiera los genéricos no ligados a ninguna app. Se importaron a QA únicamente los tres necesarios para la corrección de correlación de AD y para lo que requiere la sección 16 (`BancoBase-Custom-CountryData`, `Active Directory - QA_Valid_Countries`, `Active Directory - QA_Valid_Domains`). **Falta un inventario completo** de qué otros Custom objects/Rules existen en prod y cuáles hacen falta en QA conforme se vayan necesitando (por ejemplo, los Custom objects de mapeo de OU y las plantillas de email que aparecen referenciados dentro de `BancoBase-Custom-CountryData`, como `BancoBase-Active Directory_OU_Mapping_MX`, `BancoBase-AD-AccountCreationSuccess`, etc. — ninguno de estos se ha verificado ni importado todavía, solo se documentan aquí porque aparecieron referenciados).
