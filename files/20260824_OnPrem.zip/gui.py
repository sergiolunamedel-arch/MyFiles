#!/usr/bin/env python3
"""
gui.py - GUI (Tkinter) para configurar, probar búsquedas y lanzar scans en
el entorno Tenable on-prem (Security Center + 3 Nessus Manager).

Toda la configuración (URLs, access key, secret key) se guarda en SQLite
(tenable_sc_scanner.db, junto a este script) EN TEXTO PLANO -- decisión
aceptada explícitamente para agilizar las pruebas. No subas ese archivo .db
a ningún repositorio; en Linux/Mac considera "chmod 600 tenable_sc_scanner.db".

Pestañas:
  - Configuración : URLs y llaves de Security Center + los 3 Nessus Manager.
  - Buscar        : busca un host en la caché local (instantáneo) y permite
                    sincronizar esa caché contra los 3 Nessus Manager.
  - Lanzar Scan   : crea y lanza un scan en Security Center.
  - Historial     : scans lanzados desde esta herramienta.
"""

import queue
import threading
import time
import tkinter as tk
from tkinter import messagebox, ttk

import db
from tenable_core import NessusManagerClient, SecurityCenterClient


def construir_nessus_clientes():
    return [
        NessusManagerClient(m["name"], m["url"], m["access_key"], m["secret_key"], m["verify_ssl"])
        for m in db.list_nessus_managers()
    ]


def construir_sc_cliente():
    sc_cfg = db.get_sc_config()
    if not sc_cfg or not sc_cfg["access_key"] or not sc_cfg["secret_key"]:
        return None
    return SecurityCenterClient(sc_cfg["url"], sc_cfg["access_key"], sc_cfg["secret_key"], sc_cfg["verify_ssl"])


# ---------------------------------------------------------------------------
# Pestaña Configuración
# ---------------------------------------------------------------------------
class LabeledEntry(ttk.Frame):
    def __init__(self, parent, label, show=None, width=50):
        super().__init__(parent)
        ttk.Label(self, text=label, width=14, anchor="w").pack(side="left")
        self.var = tk.StringVar()
        self.entry = ttk.Entry(self, textvariable=self.var, show=show, width=width)
        self.entry.pack(side="left", fill="x", expand=True, padx=(4, 0))

    def get(self):
        return self.var.get().strip()

    def set(self, value):
        self.var.set(value or "")


class CredBlock(ttk.LabelFrame):
    """Bloque reusable: URL + access key + secret key (mostrar/ocultar) + verify_ssl."""

    def __init__(self, parent, titulo):
        super().__init__(parent, text=titulo, padding=8)
        self.url = LabeledEntry(self, "URL")
        self.url.pack(fill="x", pady=2)

        self.access_key = LabeledEntry(self, "Access Key")
        self.access_key.pack(fill="x", pady=2)

        self.secret_key = LabeledEntry(self, "Secret Key", show="*")
        self.secret_key.pack(fill="x", pady=2)

        fila = ttk.Frame(self)
        fila.pack(fill="x", pady=2)
        self.mostrar_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(fila, text="Mostrar secret key", variable=self.mostrar_var, command=self._toggle_show).pack(
            side="left"
        )
        self.verify_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(fila, text="Verificar certificado SSL", variable=self.verify_var).pack(
            side="left", padx=(16, 0)
        )

    def _toggle_show(self):
        self.secret_key.entry.configure(show="" if self.mostrar_var.get() else "*")

    def cargar(self, row):
        self.url.set(row["url"])
        self.access_key.set(row["access_key"])
        self.secret_key.set(row["secret_key"])
        self.verify_var.set(bool(row["verify_ssl"]))

    def valores(self):
        return self.url.get(), self.access_key.get(), self.secret_key.get(), self.verify_var.get()


class ConfigTab(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent, padding=10)

        aviso = (
            "Las llaves se guardan en TEXTO PLANO en tenable_sc_scanner.db, junto a estos scripts.\n"
            "No lo subas a ningún repositorio."
        )
        ttk.Label(self, text=aviso, foreground="#b03a2e", wraplength=900, justify="left").pack(
            fill="x", pady=(0, 10)
        )

        contenedor = ttk.Frame(self)
        contenedor.pack(fill="both", expand=True)
        canvas = tk.Canvas(contenedor, highlightthickness=0)
        scroll = ttk.Scrollbar(contenedor, orient="vertical", command=canvas.yview)
        inner = ttk.Frame(canvas)
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        self.bloque_sc = CredBlock(inner, "Security Center")
        self.bloque_sc.pack(fill="x", pady=6, padx=2)

        self.bloques_nessus = {}
        for m in db.list_nessus_managers():
            bloque = CredBlock(inner, f"Nessus Manager — {m['name']}")
            bloque.pack(fill="x", pady=6, padx=2)
            self.bloques_nessus[m["name"]] = bloque

        self._cargar_desde_db()

        botones = ttk.Frame(self)
        botones.pack(fill="x", pady=(10, 0))
        ttk.Button(botones, text="Guardar todo", command=self._guardar).pack(side="left")
        self.status_lbl = ttk.Label(botones, text="")
        self.status_lbl.pack(side="left", padx=10)

    def _cargar_desde_db(self):
        sc = db.get_sc_config()
        if sc:
            self.bloque_sc.cargar(sc)
        for m in db.list_nessus_managers():
            self.bloques_nessus[m["name"]].cargar(m)

    def _guardar(self):
        url, ak, sk, vs = self.bloque_sc.valores()
        db.save_sc_config(url, ak, sk, vs)
        for nombre, bloque in self.bloques_nessus.items():
            url, ak, sk, vs = bloque.valores()
            db.save_nessus_manager(nombre, url, ak, sk, vs)
        self.status_lbl.config(text="Guardado.")
        self.after(2500, lambda: self.status_lbl.config(text=""))


# ---------------------------------------------------------------------------
# Pestaña Buscar
# ---------------------------------------------------------------------------
class BuscarTab(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent, padding=10)
        self._queue = queue.Queue()

        top = ttk.Frame(self)
        top.pack(fill="x")
        ttk.Label(top, text="Host / IP:").pack(side="left")
        self.objetivo_var = tk.StringVar()
        entry = ttk.Entry(top, textvariable=self.objetivo_var, width=30)
        entry.pack(side="left", padx=6)
        entry.bind("<Return>", lambda e: self._buscar())
        ttk.Button(top, text="Buscar en caché", command=self._buscar).pack(side="left")

        sync_frame = ttk.LabelFrame(self, text="Caché local", padding=8)
        sync_frame.pack(fill="x", pady=10)
        self.estado_lbl = ttk.Label(sync_frame, text="", justify="left")
        self.estado_lbl.pack(anchor="w")

        btns = ttk.Frame(sync_frame)
        btns.pack(fill="x", pady=(6, 0))
        ttk.Button(btns, text="Sincronizar los 3 Nessus Manager", command=lambda: self._sincronizar(None)).pack(
            side="left"
        )
        for nombre in [m["name"] for m in db.list_nessus_managers()]:
            ttk.Button(btns, text=f"Sincronizar {nombre}", command=lambda n=nombre: self._sincronizar([n])).pack(
                side="left", padx=(6, 0)
            )

        self.progress = ttk.Progressbar(sync_frame, mode="indeterminate")
        self.log_txt = tk.Text(sync_frame, height=5, state="disabled")
        self.log_txt.pack(fill="x", pady=(6, 0))

        cols = ("nessus_manager", "scan_name", "host", "last_modification")
        headers = ("Nessus Manager", "Scan", "Host", "Última mod. scan")
        self.tree = ttk.Treeview(self, columns=cols, show="headings", height=15)
        for c, h, w in zip(cols, headers, (120, 260, 200, 180)):
            self.tree.heading(c, text=h)
            self.tree.column(c, width=w)
        self.tree.pack(fill="both", expand=True, pady=(10, 0))

        self._refrescar_estado_cache()
        self.after(150, self._poll_queue)

    def on_show(self):
        self._refrescar_estado_cache()

    def _refrescar_estado_cache(self):
        estados = db.estado_cache()
        if not estados:
            self.estado_lbl.config(text="Caché vacía. Sincroniza al menos una vez antes de buscar.")
            return
        partes = []
        for e in estados:
            if e["error"]:
                partes.append(f"{e['nessus_manager']}: ERROR ({e['error']}) — últ. intento {e['synced_at']}")
            else:
                partes.append(
                    f"{e['nessus_manager']}: {e['hosts_indexados']} hosts / {e['scans_revisados']} scans "
                    f"— {e['synced_at']}"
                )
        self.estado_lbl.config(text="\n".join(partes))

    def _log(self, msg):
        self.log_txt.configure(state="normal")
        self.log_txt.insert("end", msg + "\n")
        self.log_txt.see("end")
        self.log_txt.configure(state="disabled")

    def _buscar(self):
        objetivo = self.objetivo_var.get().strip()
        if not objetivo:
            return
        for item in self.tree.get_children():
            self.tree.delete(item)
        resultados = db.buscar_en_cache(objetivo)
        if not resultados:
            messagebox.showinfo("Buscar", "Sin coincidencias en la caché local.")
            return
        for r in resultados:
            self.tree.insert(
                "", "end", values=(r["nessus_manager"], r["scan_name"], r["host"], r["last_modification"])
            )

    def _sincronizar(self, nombres):
        self.progress.pack(fill="x", pady=(6, 0))
        self.progress.start(10)
        self._log("Iniciando sincronización...")

        def trabajo():
            for nm in construir_nessus_clientes():
                if nombres and nm.nombre not in nombres:
                    continue
                self._queue.put(("log", f"[{nm.nombre}] consultando scans..."))
                try:
                    def progreso_cb(i, t, nombre_scan, nm=nm):
                        self._queue.put(("log", f"[{nm.nombre}] scan {i}/{t}: {nombre_scan}"))

                    filas, total = nm.indexar_hosts(progreso_cb=progreso_cb)
                    db.reemplazar_cache_manager(nm.nombre, filas, total)
                    self._queue.put(("log", f"[{nm.nombre}] OK: {total} scans, {len(filas)} hosts indexados."))
                except Exception as e:
                    db.reemplazar_cache_manager(nm.nombre, [], 0, error=str(e))
                    self._queue.put(("log", f"[{nm.nombre}] ERROR: {e}"))
            self._queue.put(("done", None))

        threading.Thread(target=trabajo, daemon=True).start()

    def _poll_queue(self):
        try:
            while True:
                kind, payload = self._queue.get_nowait()
                if kind == "log":
                    self._log(payload)
                elif kind == "done":
                    self.progress.stop()
                    self.progress.pack_forget()
                    self._refrescar_estado_cache()
        except queue.Empty:
            pass
        self.after(150, self._poll_queue)


# ---------------------------------------------------------------------------
# Pestaña Lanzar Scan
# ---------------------------------------------------------------------------
class ScanTab(ttk.Frame):
    def __init__(self, parent, on_scan_registrado=None):
        super().__init__(parent, padding=10)
        self._queue = queue.Queue()
        self._on_scan_registrado = on_scan_registrado

        form = ttk.Frame(self)
        form.pack(fill="x")
        form.columnconfigure(1, weight=1)

        ttk.Label(form, text="Nombre del scan:").grid(row=0, column=0, sticky="w")
        self.nombre_var = tk.StringVar()
        ttk.Entry(form, textvariable=self.nombre_var).grid(row=0, column=1, sticky="we", padx=6, pady=2)

        ttk.Label(form, text="IPs/hosts (coma):").grid(row=1, column=0, sticky="w")
        self.ips_var = tk.StringVar()
        ttk.Entry(form, textvariable=self.ips_var).grid(row=1, column=1, sticky="we", padx=6, pady=2)

        ttk.Label(form, text="Política:").grid(row=2, column=0, sticky="w")
        self.politica_cb = ttk.Combobox(form, state="readonly")
        self.politica_cb.grid(row=2, column=1, sticky="we", padx=6, pady=2)

        ttk.Label(form, text="Repositorio:").grid(row=3, column=0, sticky="w")
        self.repo_cb = ttk.Combobox(form, state="readonly")
        self.repo_cb.grid(row=3, column=1, sticky="we", padx=6, pady=2)

        ttk.Label(form, text="Zona (opcional):").grid(row=4, column=0, sticky="w")
        self.zona_cb = ttk.Combobox(form, state="readonly")
        self.zona_cb.grid(row=4, column=1, sticky="we", padx=6, pady=2)

        botones = ttk.Frame(self)
        botones.pack(fill="x", pady=8)
        ttk.Button(botones, text="Cargar catálogos de SC", command=self._cargar_catalogos).pack(side="left")

        self.buscar_primero_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(botones, text="Buscar primero en caché", variable=self.buscar_primero_var).pack(
            side="left", padx=10
        )
        self.seguir_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(botones, text="Seguir estado tras lanzar", variable=self.seguir_var).pack(side="left")

        ttk.Button(botones, text="Lanzar scan", command=self._lanzar).pack(side="right")

        self.log_txt = tk.Text(self, height=18, state="disabled")
        self.log_txt.pack(fill="both", expand=True, pady=(6, 0))

        self.after(150, self._poll_queue)

    def on_show(self):
        pass

    def _log(self, msg):
        self.log_txt.configure(state="normal")
        self.log_txt.insert("end", msg + "\n")
        self.log_txt.see("end")
        self.log_txt.configure(state="disabled")

    def _cargar_catalogos(self):
        sc = construir_sc_cliente()
        if not sc:
            messagebox.showwarning(
                "Security Center", "Configura la URL y las llaves de Security Center primero (pestaña Configuración)."
            )
            return

        def trabajo():
            try:
                politicas = sc.listar_politicas()
                repos = sc.listar_repositorios()
                zonas = sc.listar_zonas()
                self._queue.put(("catalogos", (politicas, repos, zonas)))
            except Exception as e:
                self._queue.put(("log", f"ERROR cargando catálogos: {e}"))

        threading.Thread(target=trabajo, daemon=True).start()

    def _lanzar(self):
        nombre = self.nombre_var.get().strip()
        ips = [x.strip() for x in self.ips_var.get().split(",") if x.strip()]
        politica = self.politica_cb.get()
        repo = self.repo_cb.get()
        zona = self.zona_cb.get()

        if not nombre or not ips or not politica or not repo:
            messagebox.showwarning("Lanzar scan", "Falta nombre, IPs, política o repositorio.")
            return

        policy_id = politica.split(" — ")[0]
        repository_id = repo.split(" — ")[0]
        zone_id = zona.split(" — ")[0] if zona else None

        sc = construir_sc_cliente()
        if not sc:
            messagebox.showwarning("Security Center", "Configura Security Center primero.")
            return

        if self.buscar_primero_var.get():
            hay_historial = False
            for objetivo in ips:
                resultados = db.buscar_en_cache(objetivo)
                if resultados:
                    hay_historial = True
                    self._log(
                        f"'{objetivo}' ya tiene {len(resultados)} coincidencia(s) en caché "
                        f"— revisa la pestaña Buscar para el detalle."
                    )
            if hay_historial and not messagebox.askyesno("Confirmar", "Ya hay historial. ¿Lanzar de todas formas?"):
                return

        def trabajo():
            try:
                creado = sc.crear_scan(nombre, ips, policy_id, repository_id, zone_id)
                scan_id = creado["id"]
                self._queue.put(("log", f"Scan creado: id={scan_id}"))

                lanzado = sc.lanzar_scan(scan_id)
                scan_result_id = (lanzado.get("scanResult") or {}).get("id") or lanzado.get("id")
                self._queue.put(("log", f"Scan lanzado. scanResultID={scan_result_id}"))

                db.registrar_scan_lanzado(nombre, ips, policy_id, repository_id, zone_id, scan_id, scan_result_id)
                self._queue.put(("historial_actualizado", None))

                if self.seguir_var.get() and scan_result_id:
                    while True:
                        estado = sc.estado_resultado(scan_result_id)
                        status = estado.get("status")
                        self._queue.put(("log", f"  status={status} progress={estado.get('progress')}"))
                        db.actualizar_estado_scan(scan_result_id, status)
                        if status in ("Completed", "Canceled", "Aborted", "Error"):
                            self._queue.put(("historial_actualizado", None))
                            break
                        time.sleep(30)
            except Exception as e:
                self._queue.put(("log", f"ERROR: {e}"))

        threading.Thread(target=trabajo, daemon=True).start()

    def _poll_queue(self):
        try:
            while True:
                kind, payload = self._queue.get_nowait()
                if kind == "log":
                    self._log(payload)
                elif kind == "catalogos":
                    politicas, repos, zonas = payload
                    self.politica_cb["values"] = [f"{p['id']} — {p['name']}" for p in politicas]
                    self.repo_cb["values"] = [f"{r['id']} — {r['name']}" for r in repos]
                    self.zona_cb["values"] = [""] + [f"{z['id']} — {z['name']}" for z in zonas]
                    self._log("Catálogos cargados.")
                elif kind == "historial_actualizado" and self._on_scan_registrado:
                    self._on_scan_registrado()
        except queue.Empty:
            pass
        self.after(150, self._poll_queue)


# ---------------------------------------------------------------------------
# Pestaña Historial
# ---------------------------------------------------------------------------
class HistorialTab(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent, padding=10)
        top = ttk.Frame(self)
        top.pack(fill="x")
        ttk.Button(top, text="Actualizar", command=self._refrescar).pack(side="left")

        cols = ("id", "nombre", "ips", "estado", "sc_scan_id", "lanzado_at")
        headers = ("ID", "Nombre", "IPs", "Estado", "SC scan id", "Lanzado")
        self.tree = ttk.Treeview(self, columns=cols, show="headings", height=20)
        for c, h, w in zip(cols, headers, (40, 200, 220, 100, 90, 180)):
            self.tree.heading(c, text=h)
            self.tree.column(c, width=w)
        self.tree.pack(fill="both", expand=True, pady=(10, 0))

        self._refrescar()

    def on_show(self):
        self._refrescar()

    def _refrescar(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        for r in db.listar_historial():
            self.tree.insert(
                "", "end", values=(r["id"], r["nombre"], r["ips"], r["estado"], r["sc_scan_id"], r["lanzado_at"])
            )


# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Tenable SC Scanner")
        self.geometry("1000x700")

        db.init_db()

        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True, padx=8, pady=8)

        self.tab_config = ConfigTab(nb)
        self.tab_buscar = BuscarTab(nb)
        self.tab_historial = HistorialTab(nb)
        self.tab_scan = ScanTab(nb, on_scan_registrado=self.tab_historial.on_show)

        nb.add(self.tab_config, text="Configuración")
        nb.add(self.tab_buscar, text="Buscar")
        nb.add(self.tab_scan, text="Lanzar Scan")
        nb.add(self.tab_historial, text="Historial")

        nb.bind("<<NotebookTabChanged>>", self._on_tab_changed)

    def _on_tab_changed(self, event):
        nb = event.widget
        tab = nb.nametowidget(nb.select())
        if hasattr(tab, "on_show"):
            tab.on_show()


if __name__ == "__main__":
    App().mainloop()
