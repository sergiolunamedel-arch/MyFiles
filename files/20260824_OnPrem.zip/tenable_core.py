"""
tenable_core.py - Clientes mínimos para las APIs REST de Nessus Manager y
Tenable Security Center. No conoce SQLite ni la GUI: solo hace requests.
Compartido entre cli.py y gui.py.
"""

import sys

import requests
import urllib3

# Las 4 URLs (SC + 3 Nessus Manager) usan certificados internos.
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

TIMEOUT = 30


class NessusManagerClient:
    def __init__(self, nombre, url, access_key, secret_key, verify_ssl=False):
        self.nombre = nombre
        self.url = url.rstrip("/")
        self.headers = {
            "X-ApiKeys": f"accessKey={access_key}; secretKey={secret_key}",
            "Content-Type": "application/json",
        }
        self.verify_ssl = bool(verify_ssl)

    def _get(self, path, **kwargs):
        r = requests.get(
            f"{self.url}{path}", headers=self.headers, verify=self.verify_ssl, timeout=TIMEOUT, **kwargs
        )
        r.raise_for_status()
        return r.json()

    def listar_scans(self):
        return self._get("/scans").get("scans") or []

    def detalle_scan(self, scan_id):
        return self._get(f"/scans/{scan_id}")

    def indexar_hosts(self, progreso_cb=None):
        """
        Recorre TODOS los scans de este Nessus Manager y devuelve
        (filas, total_scans), donde filas es una lista de dicts
        {scan_id, scan_name, host, last_modification} lista para meterse
        en la caché SQLite.

        progreso_cb(actual, total, scan_name) es opcional, para reportar
        avance (p.ej. a una barra de progreso en la GUI).
        """
        filas = []
        scans = self.listar_scans()
        total = len(scans)
        for i, scan in enumerate(scans, start=1):
            scan_id = scan.get("id")
            scan_name = scan.get("name", "")
            if progreso_cb:
                progreso_cb(i, total, scan_name)
            try:
                detalle = self.detalle_scan(scan_id)
            except requests.RequestException as e:
                print(f"  [{self.nombre}] error en scan {scan_id} ({scan_name}): {e}", file=sys.stderr)
                continue
            for h in detalle.get("hosts") or []:
                hostname = str(h.get("hostname", ""))
                if not hostname:
                    continue
                filas.append(
                    {
                        "scan_id": scan_id,
                        "scan_name": scan_name,
                        "host": hostname,
                        "last_modification": scan.get("last_modification_date"),
                    }
                )
        return filas, total


class SecurityCenterClient:
    def __init__(self, url, access_key, secret_key, verify_ssl=False):
        self.url = url.rstrip("/")
        self.headers = {
            "x-apikey": f"accesskey={access_key}; secretkey={secret_key}",
            "Content-Type": "application/json",
        }
        self.verify_ssl = bool(verify_ssl)

    def _get(self, path, **kwargs):
        r = requests.get(
            f"{self.url}/rest{path}", headers=self.headers, verify=self.verify_ssl, timeout=TIMEOUT, **kwargs
        )
        r.raise_for_status()
        return r.json().get("response")

    def _post(self, path, payload, **kwargs):
        r = requests.post(
            f"{self.url}/rest{path}",
            headers=self.headers,
            json=payload,
            verify=self.verify_ssl,
            timeout=TIMEOUT,
            **kwargs,
        )
        r.raise_for_status()
        return r.json().get("response")

    def listar_politicas(self):
        return self._get("/policy?fields=id,name,type,description")

    def listar_repositorios(self):
        return self._get("/repository?fields=id,name,type,dataFormat")

    def listar_zonas(self):
        return self._get("/zone?fields=id,name")

    def crear_scan(self, nombre, ips, policy_id, repository_id, zone_id=None, descripcion=""):
        payload = {
            "name": nombre,
            "description": descripcion,
            "type": "policy",
            "ipList": ",".join(ips) if isinstance(ips, list) else ips,
            "policy": {"id": str(policy_id)},
            "repository": {"id": str(repository_id)},
        }
        if zone_id:
            payload["zone"] = {"id": str(zone_id)}
        return self._post("/scan", payload)

    def lanzar_scan(self, scan_id):
        return self._post(f"/scan/{scan_id}/launch", {})

    def estado_resultado(self, scan_result_id):
        return self._get(
            f"/scanResult/{scan_result_id}"
            "?fields=id,name,status,progress,scannedIPs,startTime,finishTime"
        )
