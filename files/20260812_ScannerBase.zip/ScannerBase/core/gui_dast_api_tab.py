from __future__ import annotations

import base64
import json
import mimetypes
import os
import os as _os
import re
import re as _re
import ssl
import tempfile as _tempfile
import threading
import time
import uuid
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Optional
from urllib.parse import urlparse, urlencode, urljoin, parse_qsl
from urllib.request import Request, build_opener, HTTPCookieProcessor, HTTPSHandler
from urllib.error import HTTPError, URLError
from http.cookiejar import CookieJar

_MACRO_JS = r"""
(function(){
  if (window.__macro_installed) return;
  window.__macro_installed = true;
  var KEY = '__vulnscan_macro__';

  // Use BOTH localStorage and sessionStorage. localStorage survives full-page
  // navigations within the same origin more reliably than sessionStorage in
  // some browsers, which matters for logout flows that redirect immediately
  // after the click. We merge both on load and de-dup by the running index `i`.
  function _readStore(store){
    try { return JSON.parse(store.getItem(KEY) || '[]'); } catch(e){ return []; }
  }
  function load(){
    var a = _readStore(sessionStorage);
    var b = _readStore(localStorage);
    if (!b.length) return a;
    if (!a.length) return b;
    // Merge, de-dup by i
    var seen = {}, out = [];
    a.concat(b).forEach(function(e){
      var k = e && e.i;
      if (k == null || !seen[k]) { if (k != null) seen[k] = 1; out.push(e); }
    });
    out.sort(function(x, y){ return (x.i || 0) - (y.i || 0); });
    return out;
  }
  function save(a){
    var s = JSON.stringify(a);
    try { sessionStorage.setItem(KEY, s); } catch(e){}
    try { localStorage.setItem(KEY, s); } catch(e){}
  }
  function push(entry){
    var a = load();
    entry.i   = (a.length ? a[a.length-1].i : 0) + 1;
    entry.url = location.href;
    a.push(entry); save(a);
  }

  function esc(s){
    return (window.CSS && CSS.escape) ? CSS.escape(s)
      : String(s).replace(/[^a-zA-Z0-9_-]/g, function(c){ return '\\' + c; });
  }
  function attr(el, name){ try { return el.getAttribute(name); } catch(e){ return null; } }

  // True for ephemeral framework IDs that change every page load:
  // _xfUid-1-1781304878 (XenForo), :r0: (React 18), ember123 (Ember),
  // mat-input-0 (Angular Material), yui_… (YUI) — or any id with 6+ digits.
  function _isDynId(id){
    if (!id) return false;
    if (/\d{6,}/.test(id)) return true;
    if (/^:r[0-9a-z]+:$/i.test(id)) return true;
    if (/^ember\d+$/i.test(id)) return true;
    if (/^__BVID__\d+/.test(id)) return true;
    if (/^yui_/.test(id)) return true;
    if (/^mat-(input|select|checkbox|radio|slide-toggle)-\d+$/.test(id)) return true;
    return false;
  }

  // Stable selector: skips dynamic IDs, prefers name/autocomplete/aria-label.
  function sel(el){
    if (!el || el.nodeType !== 1) return null;
    var tag = el.tagName.toLowerCase();
    if (el.id && !_isDynId(el.id)) return '#' + esc(el.id);
    var dt = attr(el,'data-testid')||attr(el,'data-test')||attr(el,'data-cy')||attr(el,'data-qa');
    if (dt) return tag + '[data-testid="' + String(dt).replace(/"/g,'\\"') + '"]';
    if (el.name) return tag + '[name="' + esc(el.name) + '"]';
    var ac = attr(el,'autocomplete');
    if (ac && ac !== 'on' && ac !== 'off'){
      var t2 = attr(el,'type');
      return tag + (t2 ? '[autocomplete="'+ac+'"][type="'+t2+'"]'
                       : '[autocomplete="'+ac+'"]');
    }
    var al = attr(el,'aria-label');
    if (al) return tag + '[aria-label="' + String(al).replace(/"/g,'\\"').slice(0,60) + '"]';
    var parts = [], p = el, depth = 0;
    while (p && p.nodeType === 1 && depth < 6){
      if (p.id && !_isDynId(p.id)){ parts.unshift('#' + esc(p.id)); break; }
      var n = p.tagName.toLowerCase();
      if (p.classList && p.classList.length)
        n += '.' + Array.from(p.classList).slice(0,2).map(esc).join('.');
      var par = p.parentNode;
      if (par){ var idx = Array.from(par.children).indexOf(p)+1; if(idx) n+=':nth-child('+idx+')'; }
      parts.unshift(n); p = p.parentElement; depth++;
    }
    return parts.join(' > ');
  }

  // Ordered fallback selectors stored alongside the stable primary.
  // Tried in sequence when the primary doesn't match at replay time.
  function fallbackSels(el){
    if (!el || el.nodeType !== 1) return [];
    var tag = el.tagName.toLowerCase(), fb = [];
    if (el.id) fb.push('#' + esc(el.id));          // dynamic id (same session)
    var t = attr(el,'type'); if (t) fb.push(tag+'[type="'+t+'"]');
    var ph = attr(el,'placeholder');
    if (ph) fb.push(tag+'[placeholder="'+String(ph).replace(/"/g,'\\"').slice(0,60)+'"]');
    // Full structural path including dynamic-id ancestors
    var parts2=[], p2=el, d2=0;
    while(p2 && p2.nodeType===1 && d2<6){
      if(p2.id){ parts2.unshift('#'+esc(p2.id)); break; }
      var n2=p2.tagName.toLowerCase();
      if(p2.classList && p2.classList.length) n2+='.'+Array.from(p2.classList).slice(0,2).map(esc).join('.');
      var par2=p2.parentNode;
      if(par2){ var idx2=Array.from(par2.children).indexOf(p2)+1; if(idx2) n2+=':nth-child('+idx2+')'; }
      parts2.unshift(n2); p2=p2.parentElement; d2++;
    }
    var fp=parts2.join(' > '); if(fp && fp!==fb[0]) fb.push(fp);
    return fb;
  }

  function role(el){
    var type = (el.type || '').toLowerCase();
    var ac   = (attr(el,'autocomplete') || '').toLowerCase();
    if (type === 'password' || ac === 'current-password' || ac === 'new-password') return 'password';
    if (ac === 'username' || ac === 'email' || type === 'email') return 'username';
    var hay = ((el.name||'')+' '+(el.id||'')+' '+(el.placeholder||'')+' '+(attr(el,'aria-label')||'')).toLowerCase();
    if (/(user|email|e-?mail|login|logon|correo|usuario|account|cuenta|phone|tel|m[oó]vil|dni|nif|rfc|curp)/.test(hay)) return 'username';
    return 'other';
  }

  function recordField(el){
    if (!el || !('value' in el) || el.type === 'hidden') return;
    var r = role(el);
    push({ kind:'field', selector: sel(el), fallback_selectors: fallbackSels(el),
           value: el.value, ftype: (el.type || 'text').toLowerCase(), role: r });
  }

  document.addEventListener('input',  function(e){ recordField(e.target); }, true);
  document.addEventListener('change', function(e){ recordField(e.target); }, true);
  document.addEventListener('click',  function(e){
    if (!e.isTrusted) return;
    var t = e.target;
    var b = (t && t.closest) ? t.closest('button,a,input[type=submit],input[type=button],[role=button]') : null;
    var tgt = b || t;
    // Capture href from <a> tags; also check parent anchors for SPAs where the
    // click target is a child <span> or <svg> inside the <a>.
    var href = '';
    if (tgt.tagName === 'A') {
      href = tgt.getAttribute('href') || '';
    } else {
      var anc = tgt.closest ? tgt.closest('a') : null;
      if (anc) href = anc.getAttribute('href') || '';
    }
    // Collect all text signals: innerText + aria-label + id + classes + data-*.
    // Walk up to 3 ancestors so buttons like <li id="logout-item"><button><span>Salir</span>
    // are still detected even when the leaf element itself has no keyword.
    var rawText = (tgt.innerText || tgt.value || tgt.getAttribute('aria-label') || '').trim();
    var rawId   = (tgt.id || '');
    var rawCls  = (tgt.className && typeof tgt.className === 'string') ? tgt.className : '';
    var anc2 = tgt.parentElement;
    for (var d = 0; d < 3 && anc2 && anc2.nodeType === 1; d++, anc2 = anc2.parentElement) {
      if (!rawId  && anc2.id)       rawId  = anc2.id;
      if (!rawCls && anc2.className && typeof anc2.className === 'string') rawCls = anc2.className;
      if (!rawText && anc2.innerText) rawText = anc2.innerText.trim().slice(0, 80);
    }
    var dataAction = attr(tgt,'data-action')||attr(tgt,'data-event')||
                     attr(tgt,'data-cy')||attr(tgt,'data-testid')||'';
    push({ kind:'click', selector: sel(tgt),
           fallback_selectors: fallbackSels(tgt),
           href: href,
           text: rawText.slice(0, 80),
           el_id: rawId.slice(0, 80),
           el_cls: rawCls.slice(0, 120),
           data_action: dataAction.slice(0, 80) });
  }, true);
  document.addEventListener('submit', function(e){
    var f = e.target;
    var b = (f && f.querySelector)
      ? f.querySelector('button[type=submit],input[type=submit],button:not([type])') : null;
    push({ kind:'submit', form: sel(f), button: b ? sel(b) : null });
  }, true);
  document.addEventListener('keydown', function(e){
    if (!e.isTrusted || e.key !== 'Enter') return;
    var t = e.target;
    if (t && 'value' in t) recordField(t);          // flush the current value first
    var f = (t && t.form) ? t.form : (t && t.closest ? t.closest('form') : null);
    push({ kind:'enter', selector: sel(t), form: f ? sel(f) : null });
  }, true);
})();
"""

_MACRO_DRAIN_JS = r"""
return (function(){
  try {
    var KEY = '__vulnscan_macro__';
    function rd(store){ try { return JSON.parse(store.getItem(KEY) || '[]'); } catch(e){ return []; } }
    // Merge both stores (de-dup by running index i) so a click captured just
    // before a navigation isn't lost if only one backend kept it.
    var a = rd(sessionStorage), b = rd(localStorage);
    var seen = {}, out = [];
    a.concat(b).forEach(function(e){
      var k = e && e.i;
      if (k == null || !seen[k]) { if (k != null) seen[k] = 1; out.push(e); }
    });
    out.sort(function(x, y){ return (x.i || 0) - (y.i || 0); });
    // Clear both
    try { sessionStorage.setItem(KEY, '[]'); } catch(e){}
    try { localStorage.setItem(KEY, '[]'); } catch(e){}
    return JSON.stringify(out);
  } catch(e){ return '[]'; }
})();
"""

_LOGOUT_CAPTURE_JS = r"""
return (function(){
    var url   = window.location.href;
    var title = document.title || '';
    var hints = [];
    var seen  = {};
    // NOTE: no `form` or other big containers here — a form's innerText is the
    // whole multi-line form text, which used to flood the review popup with a
    // giant blob. Containers are summarised by the has_* flags below instead.
    var nodes = document.querySelectorAll(
        'h1,h2,input[type=email],input[type=text],input[type=password],' +
        'input[name*=user],input[name*=login],a[href*=login],a[href*=signin],' +
        'button,input[type=submit]');
    nodes.forEach(function(el){
        // Skip invisible elements — they aren't evidence of anything on screen.
        if (el.offsetParent === null && el.tagName !== 'INPUT') return;
        var t = (el.innerText||el.value||el.placeholder||'')+'';
        t = t.replace(/\s+/g,' ').trim().slice(0,80);   // collapse newlines/runs
        if(!t || seen[t.toLowerCase()]) return;
        seen[t.toLowerCase()] = 1;
        hints.push(t);
    });
    // Strong signals that this is a logged-OUT page: a password field and/or a
    // recognisable login form re-appeared. The GUI uses these to help the user
    // confirm they really reached the logout state.
    var hasPassword  = !!document.querySelector('input[type=password]');
    var hasLoginForm = !!document.querySelector(
        'form[action*=login],form[action*=signin],form[id*=login],' +
        'form[class*=login],form[id*=signin],form[class*=signin]');
    return JSON.stringify({
        url: url,
        title: title,
        hints: hints.slice(0, 12),
        has_password_field: hasPassword,
        has_login_form: hasLoginForm
    });
})();
"""

@dataclass
class _BaseDastConfig:
    url: str = ""
    auth_type: str = "none"
    username: str = "";     password: str = ""
    token: str = "";        cookie: str = ""
    header_name: str = "";  header_value: str = ""
    login_url: str = "";    login_data: str = ""
    profile: str = "passive"; max_pages: int = 30
    timeout: int = 12;      verify_tls: bool = True
    include_subdomains: bool = False
    selenium_browser: str = "chrome"; selenium_binary: str = ""
    selenium_headless: bool = True
    selenium_wait_seconds: int = 15
    selenium_login_url: str = "";      selenium_user_selector: str = ""
    selenium_user_value: str = "";     selenium_pass_selector: str = ""
    selenium_pass_value: str = "";     selenium_submit_selector: str = ""
    selenium_extra_steps: str = ""
    selenium_macro: str = ""
    selenium_logout_macro: str = ""
    login_success_selector: str = "";  login_success_text: str = ""
    logout_url_re: str = "";           auto_relogin: bool = True
    exclude_re: str = (r"(?i)/(logout|log-?out|log-?off|signout|sign-?out|"
                       r"cerrar[-_]?sesi[oó]n|cerrarsesi[oó]n|cerrar[-_]?session|salir|"
                       r"desconectar|desconexion|deslog\w*|api/logout)\b")
    rate_limit_rps: float = 8.0;       proxy: str = ""
    concurrency: int = 4

@dataclass
class _BaseApiConfig:
    spec_source: str = "";  base_url: str = ""
    auth_type: str = "none"
    username: str = "";     password: str = ""
    token: str = "";        cookie: str = ""
    header_name: str = "";  header_value: str = ""
    profile: str = "passive"; max_endpoints: int = 80
    timeout: int = 12;      verify_tls: bool = True
    rate_limit_rps: float = 8.0; proxy: str = ""
    exclude_re: str = (r"(?i)/(logout|log-?out|log-?off|signout|sign-?out|"
                       r"cerrar[-_]?sesi[oó]n|cerrarsesi[oó]n|cerrar[-_]?session|salir|"
                       r"desconectar|desconexion|deslog\w*)\b")
    concurrency: int = 6
    url: str = ""

def _make_opener(cfg) -> tuple[Any, CookieJar, dict]:
    jar = CookieJar()
    ctx = ssl.create_default_context()
    if not cfg.verify_tls:
        ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
    from urllib.request import HTTPSHandler, ProxyHandler
    handlers: list = [HTTPCookieProcessor(jar), HTTPSHandler(context=ctx)]
    if cfg.proxy:
        handlers.append(ProxyHandler({"http": cfg.proxy, "https": cfg.proxy}))
    opener = build_opener(*handlers)
    hdrs = {"User-Agent": _DAST_UA, "Accept": "*/*"}
    if   cfg.auth_type == "basic"  and cfg.username:
        tok = base64.b64encode(
            f"{cfg.username}:{cfg.password}".encode()).decode()
        hdrs["Authorization"] = f"Basic {tok}"
    elif cfg.auth_type == "bearer" and cfg.token:
        hdrs["Authorization"] = f"Bearer {cfg.token}"
    elif cfg.auth_type == "cookie" and cfg.cookie:
        hdrs["Cookie"] = cfg.cookie
    elif cfg.auth_type == "header" and cfg.header_name:
        hdrs[cfg.header_name] = cfg.header_value
    return opener, jar, hdrs

def _fetch(opener, hdrs, url, *, method="GET", data=None,
           timeout=12, extra=None) -> tuple[int, dict, bytes, str]:
    req = Request(url, data=data, method=method,
                  headers={**hdrs, **(extra or {})})
    try:
        with opener.open(req, timeout=timeout) as r:
            return r.status, dict(r.headers), r.read(1_500_000), r.geturl()
    except HTTPError as e:
        try: body = e.read(500_000)
        except Exception: body = b""
        return e.code, dict(e.headers or {}), body, url
    except Exception as e:
        return 0, {}, b"", f"error: {e!r}"

_BROWSER_ENGINE = {
    "chrome": "chromium", "chromium": "chromium", "brave": "chromium",
    "opera": "chromium", "opera_gx": "chromium", "vivaldi": "chromium",
    "edge": "edge", "firefox": "firefox",
}

def detect_browsers() -> "dict[str, dict]":
    """Probe the host for installed browsers."""
    import os, shutil, platform
    system = platform.system()

    def _first(paths):
        for p in paths:
            if not p:
                continue
            q = os.path.expandvars(os.path.expanduser(p))
            looks_like_path = (os.sep in q) or ("/" in q) or (":" in q[1:3])
            if looks_like_path:
                if os.path.exists(q):
                    return q
            else:
                w = shutil.which(q)
                if w:
                    return w
        return None

    if system == "Windows":
        catalog = [
            ("chrome", "Google Chrome", "chromium", [
                r"%ProgramFiles%\Google\Chrome\Application\chrome.exe",
                r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe",
                r"%LocalAppData%\Google\Chrome\Application\chrome.exe"]),
            ("edge", "Microsoft Edge", "edge", [
                r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe",
                r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"]),
            ("firefox", "Mozilla Firefox", "firefox", [
                r"%ProgramFiles%\Mozilla Firefox\firefox.exe",
                r"%ProgramFiles(x86)%\Mozilla Firefox\firefox.exe"]),
            ("brave", "Brave", "chromium", [
                r"%ProgramFiles%\BraveSoftware\Brave-Browser\Application\brave.exe",
                r"%ProgramFiles(x86)%\BraveSoftware\Brave-Browser\Application\brave.exe",
                r"%LocalAppData%\BraveSoftware\Brave-Browser\Application\brave.exe"]),
            ("opera", "Opera", "chromium", [
                r"%LocalAppData%\Programs\Opera\opera.exe",
                r"%ProgramFiles%\Opera\opera.exe",
                r"%ProgramFiles(x86)%\Opera\opera.exe"]),
            ("opera_gx", "Opera GX", "chromium", [
                r"%LocalAppData%\Programs\Opera GX\opera.exe",
                r"%ProgramFiles%\Opera GX\opera.exe"]),
            ("vivaldi", "Vivaldi", "chromium", [
                r"%LocalAppData%\Vivaldi\Application\vivaldi.exe",
                r"%ProgramFiles%\Vivaldi\Application\vivaldi.exe"]),
            ("chromium", "Chromium", "chromium", [
                r"%LocalAppData%\Chromium\Application\chrome.exe",
                r"%ProgramFiles%\Chromium\Application\chrome.exe"]),
        ]
    elif system == "Darwin":
        catalog = [
            ("chrome", "Google Chrome", "chromium",
             ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"]),
            ("edge", "Microsoft Edge", "edge",
             ["/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"]),
            ("firefox", "Mozilla Firefox", "firefox",
             ["/Applications/Firefox.app/Contents/MacOS/firefox"]),
            ("brave", "Brave", "chromium",
             ["/Applications/Brave Browser.app/Contents/MacOS/Brave Browser"]),
            ("opera", "Opera", "chromium",
             ["/Applications/Opera.app/Contents/MacOS/Opera"]),
            ("opera_gx", "Opera GX", "chromium",
             ["/Applications/Opera GX.app/Contents/MacOS/Opera"]),
            ("vivaldi", "Vivaldi", "chromium",
             ["/Applications/Vivaldi.app/Contents/MacOS/Vivaldi"]),
            ("chromium", "Chromium", "chromium",
             ["/Applications/Chromium.app/Contents/MacOS/Chromium"]),
        ]
    else:
        catalog = [
            ("chrome", "Google Chrome", "chromium",
             ["google-chrome", "google-chrome-stable",
              "/usr/bin/google-chrome", "/opt/google/chrome/chrome"]),
            ("edge", "Microsoft Edge", "edge",
             ["microsoft-edge", "microsoft-edge-stable", "/usr/bin/microsoft-edge"]),
            ("firefox", "Mozilla Firefox", "firefox",
             ["firefox", "firefox-esr", "/usr/bin/firefox", "/snap/bin/firefox"]),
            ("brave", "Brave", "chromium",
             ["brave-browser", "brave", "/usr/bin/brave-browser"]),
            ("opera", "Opera", "chromium", ["opera", "/usr/bin/opera"]),
            ("vivaldi", "Vivaldi", "chromium",
             ["vivaldi", "vivaldi-stable", "/usr/bin/vivaldi"]),
            ("chromium", "Chromium", "chromium",
             ["chromium", "chromium-browser", "/usr/bin/chromium", "/snap/bin/chromium"]),
        ]

    found: "dict[str, dict]" = {}
    for key, name, engine, paths in catalog:
        binp = _first(paths)
        if binp:
            found[key] = {"name": name, "binary": binp, "engine": engine}
    return found

def _driver_cache_file() -> Path:
    base = _os.environ.get("LOCALAPPDATA") or _os.environ.get("XDG_CACHE_HOME")\
        or str(Path.home() / ".cache")
    d = Path(base) / "vuln-scanner"
    try:
        d.mkdir(parents=True, exist_ok=True)
    except Exception:
        d = Path(_tempfile.gettempdir())
    return d / "driver_paths.json"

def _load_driver_cache() -> dict:
    try:
        return json.loads(_driver_cache_file().read_text(encoding="utf-8"))
    except Exception:
        return {}

def _save_driver_path(engine: str, path: str) -> None:
    if not path:
        return
    try:
        data = _load_driver_cache()
        if data.get(engine) == path:
            return
        data[engine] = path
        _driver_cache_file().write_text(json.dumps(data, indent=2), encoding="utf-8")
    except Exception:
        pass

def _cached_service(engine: str, service_cls):
    """Return a Service bound to the cached driver path, or None if no valid cached path exists for this engine."""
    path = _load_driver_cache().get(engine)
    if path and Path(path).exists():
        try:
            return service_cls(executable_path=path)
        except Exception:
            return None
    return None

def _remember_service_path(engine: str, drv) -> None:
    """Capture whatever driver path Selenium Manager just resolved so the next launch can reuse it directly."""
    try:
        p = getattr(getattr(drv, "service", None), "path", None)
        if p and Path(p).exists():
            _save_driver_path(engine, str(p))
    except Exception:
        pass

def _set_command_timeout(drv, seconds: float = 60.0) -> None:
    """Best-effort: cap the read timeout on the driver's HTTP connection so a dead browser process bounds the next Se…"""
    ce = getattr(drv, "command_executor", None)
    if ce is None:
        return
    try:
        cc = getattr(ce, "_client_config", None)
        if cc is not None:
            cc.timeout = seconds
            return
    except Exception:
        pass
    try:
        ce._timeout = seconds
        return
    except Exception:
        pass
    try:
        ce.set_timeout(seconds)
    except Exception:
        pass

_BROWSER_GONE_MARKERS = (
    "no such window", "target window already closed", "web view not found",
    "browsing context has been discarded", "disconnected",
    "invalid session id", "session deleted", "session not found",
    "chrome not reachable", "unable to connect to renderer",
    "connection refused", "connection reset", "connection aborted",
    "remote end closed connection", "read timed out", "newconnectionerror",
    "max retries exceeded",
)

def _browser_is_gone(exc: BaseException) -> bool:
    """True when `exc` indicates the controlled browser window/session is gone (closed/crashed/killed) — as opposed t…"""
    msg = f"{exc!r} {exc}".lower()
    return any(marker in msg for marker in _BROWSER_GONE_MARKERS)

def _make_driver(cfg: DastConfig, *, headless: bool,
                 log: Callable[[str], None] = lambda _: None):
    from selenium import webdriver

    browser = (cfg.selenium_browser or "chrome").lower()
    engine  = _BROWSER_ENGINE.get(browser, "chromium")
    binary  = (getattr(cfg, "selenium_binary", "") or "").strip()

    if not binary and browser not in ("chrome", "edge", "firefox"):
        try:
            d = detect_browsers().get(browser)
            if d:
                binary = d["binary"]
        except Exception:
            pass

    log(f"[dast] launching {browser} (engine={engine}, headless={headless}, "
        f"binary={binary or 'auto'})")

    if engine == "firefox":
        from selenium.webdriver.firefox.service import Service as _FxService
        opts = webdriver.FirefoxOptions()
        if headless: opts.add_argument("-headless")
        if binary:   opts.binary_location = binary
        try: opts.page_load_strategy = "eager"
        except Exception: pass
        if not cfg.verify_tls: opts.accept_insecure_certs = True
        if cfg.proxy:
            host, _, port = cfg.proxy.replace("http://", "").replace("https://", "").partition(":")
            opts.set_preference("network.proxy.type", 1)
            for scheme in ("http", "ssl"):
                opts.set_preference(f"network.proxy.{scheme}", host)
                opts.set_preference(f"network.proxy.{scheme}_port", int(port or 8080))
        try:
            svc = _cached_service("firefox", _FxService)
            if svc is not None:
                drv = webdriver.Firefox(service=svc, options=opts)
            else:
                drv = webdriver.Firefox(options=opts)
                _remember_service_path("firefox", drv)
            _set_command_timeout(drv)
            return drv
        except Exception as e:
            log(f"[dast] Selenium Manager (firefox) failed ({e!r}); webdriver-manager")
            from webdriver_manager.firefox import GeckoDriverManager
            from selenium.webdriver.firefox.service import Service
            p = GeckoDriverManager().install()
            _save_driver_path("firefox", str(p))
            drv = webdriver.Firefox(service=Service(p), options=opts)
            _set_command_timeout(drv)
            return drv

    def _chromium_speed(opts):
        for a in (
            "--no-first-run", "--no-default-browser-check", "--no-service-autorun",
            "--disable-extensions", "--disable-background-networking",
            "--disable-component-update", "--disable-default-apps",
            "--disable-sync", "--disable-translate",
            "--disable-background-timer-throttling",
            "--disable-backgrounding-occluded-windows",
            "--disable-renderer-backgrounding", "--metrics-recording-only",
            "--mute-audio", "--password-store=basic", "--use-mock-keychain",
            "--disable-features=Translate,OptimizationHints,MediaRouter,"
            "CalculateNativeWinOcclusion",
        ):
            opts.add_argument(a)
        try: opts.page_load_strategy = "eager"
        except Exception: pass
        return opts

    if engine == "edge":
        from selenium.webdriver.edge.options import Options as EdgeOptions
        opts = EdgeOptions()
        if headless: opts.add_argument("--headless=new")
        opts.add_argument("--no-sandbox"); opts.add_argument("--disable-dev-shm-usage")
        opts.add_argument("--disable-gpu")
        _chromium_speed(opts)
        if binary: opts.binary_location = binary
        if not cfg.verify_tls:
            opts.add_argument("--ignore-certificate-errors")
            opts.set_capability("acceptInsecureCerts", True)
        if cfg.proxy: opts.add_argument(f"--proxy-server={cfg.proxy}")
        from selenium.webdriver.edge.service import Service as _EdgeService
        try:
            svc = _cached_service("edge", _EdgeService)
            if svc is not None:
                drv = webdriver.Edge(service=svc, options=opts)
            else:
                drv = webdriver.Edge(options=opts)
                _remember_service_path("edge", drv)
            _set_command_timeout(drv)
            return drv
        except Exception as e:
            log(f"[dast] Selenium Manager (edge) failed ({e!r}); webdriver-manager")
            from webdriver_manager.microsoft import EdgeChromiumDriverManager
            p = EdgeChromiumDriverManager().install()
            _save_driver_path("edge", str(p))
            drv = webdriver.Edge(service=_EdgeService(p), options=opts)
            _set_command_timeout(drv)
            return drv

    opts = webdriver.ChromeOptions()
    if headless: opts.add_argument("--headless=new")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-dev-shm-usage")
    opts.add_argument("--disable-gpu")
    _chromium_speed(opts)
    if binary: opts.binary_location = binary
    if not cfg.verify_tls:
        opts.add_argument("--ignore-certificate-errors")
        opts.set_capability("acceptInsecureCerts", True)
    if cfg.proxy: opts.add_argument(f"--proxy-server={cfg.proxy}")

    from selenium.webdriver.chrome.service import Service as _ChromeService
    try:
        svc = _cached_service("chromium", _ChromeService)
        if svc is not None:
            drv = webdriver.Chrome(service=svc, options=opts)
        else:
            drv = webdriver.Chrome(options=opts)
            _remember_service_path("chromium", drv)
        _set_command_timeout(drv)
        return drv
    except Exception as e:
        log(f"[dast] Selenium Manager (chromium) failed ({e!r}); webdriver-manager")
        from webdriver_manager.chrome import ChromeDriverManager
        try:
            from webdriver_manager.core.os_manager import ChromeType
            ctype = (ChromeType.BRAVE if browser == "brave"
                     else ChromeType.CHROMIUM if browser == "chromium"
                     else ChromeType.GOOGLE)
            p = ChromeDriverManager(chrome_type=ctype).install()
        except Exception:
            p = ChromeDriverManager().install()
        _save_driver_path("chromium", str(p))
        drv = webdriver.Chrome(service=_ChromeService(p), options=opts)
        _set_command_timeout(drv)
        return drv

def prewarm_driver(cfg: "DastConfig | None" = None,
                   log: Callable[[str], None] = lambda _: None) -> None:
    """Resolve & cache the webdriver path in the background at app start."""
    try:
        cfg = cfg or DastConfig(url="https://")
        engine = _BROWSER_ENGINE.get((cfg.selenium_browser or "chrome").lower(), "chromium")
        if _load_driver_cache().get(engine) and Path(_load_driver_cache()[engine]).exists():
            return
        log("[dast] pre-warming webdriver (one-time, background)…")
        drv = _make_driver(cfg, headless=True, log=log)
        try: drv.quit()
        except Exception: pass
        log("[dast] webdriver ready — browser will open instantly from now on.")
    except Exception as e:
        log(f"[dast] driver pre-warm skipped: {e!r}")

def _replay_login_macro(driver, macro, *, pass_value=None, wait_seconds=15,
                        log=lambda *_: None) -> bool:
    """Replay every recorded step in order, handling: - Dynamic IDs (XenForo _xfUid-*, React :r0:) via fallback_selec…"""
    import time as _t
    from selenium.webdriver.common.by import By
    from selenium.webdriver.common.keys import Keys

    if not isinstance(macro, list) or not macro:
        return False

    def _vis(css, timeout):
        """First visible element matching css (main doc + iframes)."""
        deadline = _t.time() + max(timeout, 0.5)
        while _t.time() < deadline:
            try:
                driver.switch_to.default_content()
                for el in driver.find_elements(By.CSS_SELECTOR, css):
                    try:
                        r = driver.execute_script(
                            "var r=arguments[0].getBoundingClientRect(),"
                            "s=window.getComputedStyle(arguments[0]);"
                            "return {w:r.width,h:r.height,"
                            "v:s.visibility,d:s.display,o:s.opacity};", el)
                        if (r and r.get("w",0)>0 and r.get("h",0)>0
                                and r.get("v")!="hidden"
                                and r.get("d")!="none"
                                and r.get("o")!="0"):
                            return el
                    except Exception:
                        try:
                            if el.is_displayed(): return el
                        except Exception:
                            pass
                for fr in driver.find_elements(By.TAG_NAME, "iframe"):
                    try:
                        driver.switch_to.default_content()
                        driver.switch_to.frame(fr)
                        for el in driver.find_elements(By.CSS_SELECTOR, css):
                            try:
                                if el.is_displayed(): return el
                            except Exception:
                                pass
                    except Exception:
                        pass
                driver.switch_to.default_content()
            except Exception:
                pass
            _t.sleep(0.15)
        try: driver.switch_to.default_content()
        except Exception: pass
        return None

    _ROLE_SEL = {
        "password": ["input[type=password]"],
        "username": [
            "input[type=email]",
            "input[autocomplete=username]",
            "input[autocomplete=email]",
            "input[type=text][name*=user]",
            "input[type=text][name*=email]",
            "input[type=text][name*=login]",
            "input[type=text]",
        ],
    }

    def _find_field(step, timeout):
        """Try: primary selector → fallback_selectors → role-based."""
        primary = step.get("selector")
        candidates = []
        if primary:
            candidates.append(("primary", primary))
        for fb in (step.get("fallback_selectors") or []):
            if fb and fb != primary:
                candidates.append(("fallback", fb))
        for label, css in candidates:
            el = _vis(css, timeout)
            if el:
                if label != "primary":
                    log(f"[replay] {label} matched: {css}")
                return el
            log(f"[replay] {label} not visible: {css}")
        role_k = None
        if step.get("role") == "password" or step.get("ftype") == "password":
            role_k = "password"
        elif step.get("role") == "username":
            role_k = "username"
        if role_k:
            for css in _ROLE_SEL.get(role_k, []):
                el = _vis(css, max(timeout * 0.4, 1.5))
                if el:
                    log(f"[replay] role-fallback ({role_k}): {css}")
                    return el
        return None

    def _type(el, val):
        try: el.click()
        except Exception: pass
        try: el.clear()
        except Exception: pass
        try: el.send_keys(val)
        except Exception as e:
            log(f"[replay] send_keys failed: {e!r}")
        try:
            if (el.get_attribute("value") or "") == str(val):
                return True
            driver.execute_script(
                "arguments[0].value=arguments[1];"
                "arguments[0].dispatchEvent(new Event('input',{bubbles:true}));"
                "arguments[0].dispatchEvent(new Event('change',{bubbles:true}));",
                el, str(val))
            return (el.get_attribute("value") or "") != ""
        except Exception:
            return False

    _LOGOUT_KW = ("logout","log-out","signout","sign-out","cerrar sesión",
                  "cerrar sesion","cerrar","salir","log out","sign out",
                  "desconectar","logoff","log-off")

    typed_password = False
    per_wait = max(3, min(int(wait_seconds or 15), 15))

    for step in macro:
        if not isinstance(step, dict):
            continue
        kind = step.get("kind")
        sel  = step.get("selector")
        try:
            if kind == "field":
                if not sel and not step.get("fallback_selectors"):
                    continue
                is_pass = (step.get("role") == "password"
                           or step.get("ftype") == "password")
                val = step.get("value")
                if is_pass and (val in (None, "")) and pass_value:
                    val = pass_value
                if val in (None, ""):
                    continue
                el = _find_field(step, per_wait)
                if not el:
                    log(f"[replay] field not found: {sel}")
                    continue
                if _type(el, val):
                    if is_pass:
                        typed_password = True
                        log("[replay] typed password ✓")
                    else:
                        log(f"[replay] typed into {sel[:60]}")

            elif kind == "click":
                if not sel:
                    continue
                step_href = step.get("href", "")
                step_text = (step.get("text") or "").lower()
                step_id       = (step.get("el_id") or "").lower()
                step_cls      = (step.get("el_cls") or "").lower()
                step_data_act = (step.get("data_action") or "").lower()
                _combined     = " ".join([step_href.lower(), step_text,
                                           step_id, step_cls, step_data_act])
                is_logout = any(k in _combined for k in _LOGOUT_KW)

                el = _vis(sel, per_wait)

                if el and is_logout:
                    live_href = ""
                    try:
                        live_href = driver.execute_script(
                            """
                            var el = arguments[0];
                            // Check the element itself and the nearest <a> ancestor.
                            if (el.tagName === 'A') return el.getAttribute('href') || '';
                            var anc = el.closest ? el.closest('a') : null;
                            return anc ? (anc.getAttribute('href') || '') : '';
                            """, el)
                    except Exception:
                        pass
                    if live_href and live_href not in ('#', 'javascript:void(0)',
                                                       'javascript:;', ''):
                        try:
                            from urllib.parse import urljoin
                            full = urljoin(driver.current_url, live_href)
                            log(f"[replay] logout → navigating: {full}")
                            driver.get(full)
                            _t.sleep(1.5)
                        except Exception as ex:
                            log(f"[replay] logout nav failed ({ex!r}), clicking")
                            try:
                                driver.execute_script(
                                    "arguments[0].scrollIntoView({block:'nearest'});", el)
                                _t.sleep(0.1)
                                el.click()
                            except Exception: pass
                    else:
                        try:
                            driver.execute_script(
                                "arguments[0].scrollIntoView({block:'nearest'});", el)
                            _t.sleep(0.1)
                        except Exception: pass
                        try:
                            el.click()
                        except Exception:
                            try:
                                driver.execute_script(
                                    "arguments[0].dispatchEvent("                                     "new MouseEvent('click',{"                                     "bubbles:true,cancelable:true,view:window}));", el)
                            except Exception: pass
                        _t.sleep(1.0)
                    log("[replay] logout done")

                elif el:
                    try:
                        driver.execute_script(
                            "arguments[0].scrollIntoView({block:'nearest'});", el)
                        _t.sleep(0.1)
                    except Exception:
                        pass
                    try:
                        el.click()
                    except Exception:
                        try:
                            driver.execute_script(
                                "arguments[0].dispatchEvent("
                                "new MouseEvent('click',{"
                                "bubbles:true,cancelable:true,view:window}));", el)
                        except Exception:
                            pass
                    log(f"[replay] clicked {sel[:60]}")
                    _t.sleep(0.8)

                else:
                    try:
                        driver.execute_script(
                            "var el=document.querySelector(arguments[0]);"
                            "if(el) el.dispatchEvent(new MouseEvent('click',"
                            "{bubbles:true,cancelable:true,view:window}));", sel)
                        log(f"[replay] JS-clicked (not visible): {sel[:60]}")
                        _t.sleep(0.8)
                    except Exception:
                        log(f"[replay] click target not found: {sel[:60]}")

            elif kind == "enter":
                el = _vis(sel, 2) if sel else None
                if el:
                    el.send_keys(Keys.ENTER)
                    log("[replay] pressed Enter")
                    _t.sleep(0.6)
                elif step.get("form"):
                    driver.switch_to.default_content()
                    driver.execute_script(
                        "var f=document.querySelector(arguments[0]);"
                        "if(f){if(f.requestSubmit)f.requestSubmit();"
                        "else f.submit();}", step["form"])
                    log("[replay] submitted form (enter→form)")
                    _t.sleep(0.6)

            elif kind == "submit":
                btn = step.get("button")
                frm = step.get("form")
                done = False
                if btn:
                    el = _vis(btn, 2)
                    if el:
                        try:
                            el.click()
                        except Exception:
                            try:
                                driver.execute_script(
                                    "arguments[0].scrollIntoView({block:'nearest'});",
                                    el)
                                _t.sleep(0.1)
                                el.click()
                            except Exception:
                                driver.execute_script(
                                    "arguments[0].dispatchEvent("
                                    "new MouseEvent('click',{bubbles:true,"
                                    "cancelable:true,view:window}));", el)
                        done = True
                        log("[replay] clicked submit button")
                        _t.sleep(0.8)
                if not done and frm:
                    driver.switch_to.default_content()
                    driver.execute_script(
                        "var fs=document.querySelectorAll(arguments[0]);"
                        "for(var i=0;i<fs.length;i++){"
                        "  if(fs[i].offsetParent!==null){"
                        "    if(fs[i].requestSubmit) fs[i].requestSubmit();"
                        "    else fs[i].submit(); return;}}", frm)
                    log("[replay] submitted form")
                    _t.sleep(0.8)

        except Exception as e:
            log(f"[replay] step {step!r} failed: {e!r}")

    try: driver.switch_to.default_content()
    except Exception: pass
    return typed_password

def _api_load_spec(opener, hdrs, cfg: ApiConfig,
                   log) -> Optional[dict]:
    src = (cfg.spec_source or "").strip()
    if not src: return None
    raw: Optional[str] = None
    if src.startswith(("http://", "https://")):
        log(f"[api] fetching spec: {src}")
        st, _, bb, _ = _fetch(opener, hdrs, src, timeout=cfg.timeout)
        if st and bb: raw = bb.decode("utf-8", errors="replace")
        else: log(f"[api] could not fetch spec (HTTP {st})"); return None
    else:
        p = Path(src)
        if not p.exists():
            log(f"[api] spec not found: {src}"); return None
        raw = p.read_text(encoding="utf-8", errors="replace")
    try: return json.loads(raw)
    except json.JSONDecodeError: pass
    try:
        import importlib
        yaml = importlib.import_module("yaml")
    except ModuleNotFoundError:
        log("[api] la especificación no es JSON y PyYAML no está instalado; "
            "instale 'pyyaml' para soportar specs YAML (pip install pyyaml).")
        return None
    try:
        return yaml.safe_load(raw)
    except Exception as e:
        log(f"[api] spec is neither JSON nor valid YAML: {e!r}"); return None

def _api_deref(spec: dict, node: Any, _seen=None) -> Any:
    seen = _seen or set()
    while isinstance(node, dict) and "$ref" in node:
        ref = node["$ref"]
        if not isinstance(ref, str) or not ref.startswith("#/") or ref in seen:
            return node
        seen.add(ref); cur: Any = spec
        for part in ref[2:].split("/"):
            part = part.replace("~1", "/").replace("~0", "~")
            if isinstance(cur, dict) and part in cur: cur = cur[part]
            else: return node
        node = cur
    return node

def _api_sample(spec: dict, schema: Any, depth: int = 0) -> Any:
    schema = _api_deref(spec, schema) or {}
    if not isinstance(schema, dict) or depth > 4: return "test"
    for k in ("example", "default"):
        if k in schema: return schema[k]
    if schema.get("enum"): return schema["enum"][0]
    t = schema.get("type")
    if t == "object" or "properties" in schema:
        props = schema.get("properties") or {}
        req = set(schema.get("required") or [])
        keys = [k for k in props if not req or k in req] or list(props)[:3]
        return {k: _api_sample(spec, props[k], depth + 1) for k in keys}
    if t == "array":   return [_api_sample(spec, schema.get("items") or {}, depth + 1)]
    if t in ("integer", "number"): return 1
    if t == "boolean": return True
    return {"date-time": "2020-01-01T00:00:00Z", "date": "2020-01-01",
            "email": "test@example.com",
            "uuid": "00000000-0000-0000-0000-000000000000"}.get(
                schema.get("format"), "test")

def _api_subst_server_vars(url: str, server: dict) -> str:
    """OpenAPI 3 server URLs may be templates like 'https://{accountName}.api-us1.com/{ver}' with a sibling `variable…"""
    if not isinstance(url, str) or "{" not in url:
        return url
    variables = server.get("variables") if isinstance(server, dict) else None
    variables = variables if isinstance(variables, dict) else {}
    def _repl(mobj):
        name = mobj.group(1)
        v = variables.get(name)
        if isinstance(v, dict):
            if v.get("default") not in (None, ""): return str(v["default"])
            enum = v.get("enum")
            if isinstance(enum, list) and enum:       return str(enum[0])
        return "1"
    return _re.sub(r"\{([^/{}]+)\}", _repl, url)

def _api_base_url(spec: dict, cfg: ApiConfig, spec_src: str) -> str:
    base = ""
    if cfg.base_url.strip():
        base = cfg.base_url.strip()
    elif isinstance(spec.get("servers"), list) and spec["servers"]:
        srv = spec["servers"][0]
        srv = srv if isinstance(srv, dict) else {}
        base = _api_subst_server_vars(srv.get("url", "") or "", srv)
    elif spec.get("host"):
        scheme = (spec.get("schemes") or ["https"])[0]
        base = f"{scheme}://{spec['host']}{spec.get('basePath', '')}"
    if base.startswith("/") or not base:
        if spec_src.startswith(("http://", "https://")):
            base = urljoin(spec_src, base or "/")
    if base and not base.startswith(("http://", "https://")):
        base = "https://" + base.lstrip("/")
    return base.rstrip("/")

def _api_ops_postman(coll: dict, base: str) -> list[dict]:
    ops: list[dict] = []

    cvars: dict[str, str] = {}
    for v in (coll.get("variable") or []):
        if isinstance(v, dict) and v.get("key") is not None:
            cvars[str(v["key"])] = "" if v.get("value") is None else str(v["value"])

    def _resolve_vars(text: str) -> str:
        def _repl(mobj):
            name = mobj.group(1)
            if name in cvars:
                return cvars[name]
            if name.lower() in ("baseurl", "base_url", "url", "host", "server",
                                 "endpoint", "apiurl", "api_url", "domain"):
                return ""
            return "test"
        return _re.sub(r"\{\{\s*([^}]+?)\s*\}\}", _repl, text)

    def walk(items):
        for it in items or []:
            if not isinstance(it, dict): continue
            if "item" in it: walk(it.get("item")); continue
            req = it.get("request")
            if not isinstance(req, dict): continue
            method = (req.get("method") or "GET").upper()
            u = req.get("url")
            if isinstance(u, dict):
                url   = u.get("raw") or ""
                query = [(q.get("key"), q.get("value") or "test")
                         for q in (u.get("query") or []) if isinstance(q, dict) and q.get("key")]
            else:
                url = u if isinstance(u, str) else ""; query = []
            url = _resolve_vars(url).split("#", 1)[0]
            url = _re.sub(r"/:(\w+)", "/test", url)
            url = _re.sub(r"\{[^/{}]+\}", "1", url)
            if url and not url.startswith(("http://", "https://")) and base:
                url = base + "/" + url.lstrip("/")
            secured = bool(req.get("auth")) or any(
                isinstance(h, dict) and (h.get("key") or "").lower() == "authorization"
                for h in (req.get("header") or []))
            body = ctype = json_body = None
            b = req.get("body") or {}
            if isinstance(b, dict) and b.get("mode") == "raw" and b.get("raw"):
                try:
                    json_body = json.loads(b["raw"])
                    body = b["raw"].encode(); ctype = "application/json"
                except Exception: pass
            if url.startswith(("http://", "https://")):
                ops.append({"method": method, "url": url, "secured": secured,
                            "query": query, "body": body, "ctype": ctype,
                            "json_body": json_body})

    walk(coll.get("item")); return ops

def _api_operations(spec: dict, base: str, spec_src: str) -> list[dict]:
    if "item" in spec and "paths" not in spec:
        return _api_ops_postman(spec, base)
    ops: list[dict] = []; global_sec = spec.get("security")
    methods = ("get", "post", "put", "patch", "delete", "options", "head")
    paths = spec.get("paths")
    if not isinstance(paths, dict): return ops
    for path, item in paths.items():
        if not isinstance(path, str): continue
        item = _api_deref(spec, item)
        if not isinstance(item, dict): continue
        common = [_api_deref(spec, p) for p in (item.get("parameters") or [])]
        for method in methods:
            op = item.get(method)
            if not isinstance(op, dict): continue
            params = common + [_api_deref(spec, p)
                               for p in (op.get("parameters") or [])]
            sec = op.get("security", global_sec)
            secured = bool(sec) and sec != [{}]
            filled = path; query: list[tuple[str, str]] = []
            for p in params:
                if not isinstance(p, dict) or not p.get("name"): continue
                schema = p.get("schema") or {
                    k: p[k] for k in ("type", "enum", "format") if k in p}
                val = _api_sample(spec, schema)
                if not isinstance(val, (str, int, float, bool)): val = "test"
                loc = p.get("in")
                if   loc == "path":  filled = filled.replace("{" + p["name"] + "}", str(val))
                elif loc == "query": query.append((p["name"], str(val)))
            filled = _re.sub(r"\{[^/{}]+\}", "1", filled)
            rb = (_api_deref(spec, op.get("requestBody"))
                  if op.get("requestBody") else None)
            body = ctype = json_body = None
            if isinstance(rb, dict):
                content = rb.get("content") or {}
                if "application/json" in content:
                    sample = _api_sample(
                        spec, (content["application/json"] or {}).get("schema") or {})
                    body = json.dumps(sample).encode()
                    ctype = "application/json"; json_body = sample
                else:
                    for ct in ("application/x-www-form-urlencoded",
                               "multipart/form-data"):
                        if ct in content:
                            sample = _api_sample(
                                spec, (content[ct] or {}).get("schema") or {})
                            if isinstance(sample, dict):
                                body = urlencode(
                                    {k: v for k, v in sample.items()}).encode()
                                ctype = "application/x-www-form-urlencoded"
                                break
            url = base + (filled if filled.startswith("/") else "/" + filled)
            if query: url += ("&" if "?" in url else "?") + urlencode(query)
            ops.append({"method": method.upper(), "url": url,
                        "secured": secured, "query": query,
                        "body": body, "ctype": ctype, "json_body": json_body})
    return ops

def analyze_login_macro(macro: list) -> tuple:
    """Industry-standard credential-field detection from recorded events."""
    pass_entry = None
    for s in macro:
        if s.get("kind") == "field" and s.get("selector") and (
                s.get("role") == "password" or s.get("ftype") == "password"):
            pass_entry = s
    pass_sel = pass_entry.get("selector") if pass_entry else None
    pass_val = pass_entry.get("value") if pass_entry else None

    user_sel = user_val = None
    pass_pos = macro.index(pass_entry) if pass_entry in macro else len(macro)
    role_user = [s for s in macro[:pass_pos]
                 if s.get("kind") == "field" and s.get("role") == "username"
                 and s.get("selector")]
    if role_user:
        user_sel = role_user[-1]["selector"]; user_val = role_user[-1].get("value")
    else:
        for s in reversed(macro[:pass_pos]):
            if s.get("kind") == "field" and s.get("selector")\
                    and s.get("role") != "password" and s.get("ftype") != "password":
                user_sel = s["selector"]; user_val = s.get("value"); break

    submit_sel = None
    for s in macro[pass_pos + 1:]:
        if s.get("kind") == "click" and s.get("selector"):
            submit_sel = s["selector"]; break
    if not submit_sel:
        sub = next((s for s in macro if s.get("kind") == "submit"
                    and s.get("button")), None)
        if sub: submit_sel = sub["button"]
    return user_sel, user_val, pass_sel, pass_val, submit_sel

def record_macro_work(cfg: DastConfig,
                      emit_log: Callable[[str], None] = lambda _: None):
    """Return a `work` callable that records a login macro."""
    def _work(driver, url, done, result, set_status=lambda _: None):
        emit_log(f"[macro] opening {url} — log in, then press "
                 "Ctrl+Shift+F12 to capture")
        driver.get(url)
        _nav = result.get("_nav_done")
        if _nav is not None:
            _nav.set()
        set_status("✅  Log in normally, then press Ctrl+Shift+F12")
        acc: list = []
        try:
            driver.execute_script(_MACRO_JS)
        except Exception:
            pass
        while not done.is_set():
            _gone = False
            try:
                driver.execute_script(
                    "if(!window.__macro_installed){" + _MACRO_JS + "}")
            except Exception as e:
                if _browser_is_gone(e):
                    _gone = True
            try:
                chunk = json.loads(driver.execute_script(_MACRO_DRAIN_JS) or "[]")
                if chunk:
                    acc.extend(chunk)
            except Exception as e:
                if _browser_is_gone(e):
                    _gone = True
            if _gone:
                emit_log("[macro] browser window was closed — stopping recorder.")
                result["_cancelled"] = True
                return
            if done.wait(0.4):
                break
        try:
            chunk = json.loads(driver.execute_script(_MACRO_DRAIN_JS) or "[]")
            if chunk:
                acc.extend(chunk)
        except Exception:
            pass
        result["macro"] = json.dumps(acc)
        try:
            result["cookies"] = driver.get_cookies() or []
        except Exception:
            result["cookies"] = []
    return _work

def record_logout_work(cfg: DastConfig,
                       emit_log: Callable[[str], None] = lambda _: None):
    """Return a `work` callable that replays login then records the logout state."""
    _LOGOUT_KW = ("logout", "log-out", "signout", "sign-out",
                  "cerrar sesión", "cerrar sesion", "cerrar", "salir",
                  "log out", "sign out", "desconectar", "logoff", "log-off")

    def _work(driver, url, done, result, set_status=lambda _: None):
        import time as _t
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC
        from selenium.webdriver.common.by import By

        login_url  = (cfg.selenium_login_url or url).strip()
        pass_val   = cfg.selenium_pass_value.strip()
        macro_raw  = cfg.selenium_macro.strip()
        succ_sel   = cfg.login_success_selector.strip()
        succ_txt   = cfg.login_success_text.strip()

        password_missing = bool(cfg.selenium_pass_selector and not pass_val)
        can_replay = bool(
            (macro_raw or cfg.selenium_user_selector or
             (cfg.selenium_pass_selector and pass_val) or
             cfg.selenium_submit_selector or cfg.selenium_extra_steps)
            and not password_missing)

        per_wait = max(2, min(int(cfg.selenium_wait_seconds or 15), 8))

        emit_log(f"[logout-rec] navigating to login page: {login_url}")
        set_status("⏳  Opening login page…")
        try:
            driver.get(login_url)
        except Exception as e:
            emit_log(f"[logout-rec] navigation error: {e!r}")
        _nav = result.get("_nav_done")
        if _nav is not None:
            _nav.set()
        _t.sleep(1.0)

        if not can_replay:
            emit_log("[logout-rec] no replayable login — waiting for MANUAL login")
            set_status("👤  Log in by hand, then go to the logged-OUT page "
                       "→ Ctrl+Shift+F12")
        else:
            emit_log("[logout-rec] replaying saved login (literal)…")
            set_status("🔁  Replaying saved login…")
            try:
                macro = json.loads(macro_raw) if macro_raw else []
            except Exception as ex:
                macro = []
                emit_log(f"[logout-rec] macro JSON invalid: {ex!r}")

            if macro:
                _replay_login_macro(
                    driver, macro, pass_value=(pass_val or None),
                    wait_seconds=cfg.selenium_wait_seconds, log=emit_log)
            else:
                def _find(sel, timeout=per_wait):
                    try:
                        return WebDriverWait(driver, timeout).until(
                            EC.presence_of_element_located((By.CSS_SELECTOR, sel)))
                    except Exception:
                        emit_log(f"[logout-rec] selector not found: {sel}")
                        return None

                if cfg.selenium_user_selector and cfg.selenium_user_value:
                    el = _find(cfg.selenium_user_selector)
                    if el:
                        try: el.clear(); el.send_keys(cfg.selenium_user_value)
                        except Exception: pass
                if cfg.selenium_pass_selector and pass_val:
                    el = _find(cfg.selenium_pass_selector)
                    if el:
                        try:
                            el.clear(); el.send_keys(pass_val)
                        except Exception: pass
                if cfg.selenium_submit_selector:
                    el = _find(cfg.selenium_submit_selector)
                    if el:
                        try: el.click()
                        except Exception: pass
                elif cfg.selenium_pass_selector and pass_val:
                    try:
                        from selenium.webdriver.common.keys import Keys as _K
                        driver.find_element(
                            By.CSS_SELECTOR, cfg.selenium_pass_selector).send_keys(_K.ENTER)
                    except Exception: pass

            try: driver.switch_to.default_content()
            except Exception: pass

            set_status("⏳  Waiting for login to complete…")

            def _confirm_logged_in():
                if done.is_set():
                    emit_log("[logout-rec] capture requested early — skipping login confirmation")
                    return False
                try:
                    if succ_sel:
                        WebDriverWait(driver, per_wait).until(
                            EC.presence_of_element_located((By.CSS_SELECTOR, succ_sel)))
                        emit_log("[logout-rec] login confirmed (selector present)")
                        return True
                    if succ_txt:
                        WebDriverWait(driver, per_wait).until(
                            lambda d: succ_txt in d.page_source)
                        emit_log("[logout-rec] login confirmed (text present)")
                        return True
                    _t.sleep(2.5)
                    gone = not driver.execute_script(
                        "var ps=document.querySelectorAll('input[type=password]');"
                        "for(var i=0;i<ps.length;i++){"
                        "  var r=ps[i].getBoundingClientRect();"
                        "  var st=window.getComputedStyle(ps[i]);"
                        "  var visible=(r.width>0&&r.height>0"
                        "    &&st.visibility!=='hidden'"
                        "    &&st.display!=='none'"
                        "    &&st.opacity!=='0');"
                        "  if(visible) return true;"
                        "}"
                        "return false;")
                    emit_log(f"[logout-rec] login replayed (heuristic logged_in={gone})")
                    return gone
                except Exception:
                    emit_log("[logout-rec] login confirmation timed out — continuing anyway")
                    return False

            logged_in = _confirm_logged_in()
            if logged_in:
                set_status("✅  Logged in — go to the logged-OUT page, then Ctrl+Shift+F12")
            else:
                set_status("🔓  Login replayed — navigate to the logged-OUT page, then Ctrl+Shift+F12")

        set_status("✅  Logged in — open user menu, click Log Out, then Ctrl+Shift+F12")
        emit_log("[logout-rec] recording started — click Log Out now")

        logout_acc: list = []
        try: driver.execute_script(_MACRO_JS)
        except Exception: pass

        while not done.is_set():
            _gone = False
            try:
                driver.execute_script(
                    "if(!window.__macro_installed){" + _MACRO_JS + "}")
            except Exception as e:
                if _browser_is_gone(e):
                    _gone = True
            try:
                chunk = json.loads(driver.execute_script(_MACRO_DRAIN_JS) or "[]")
                if chunk:
                    logout_acc.extend(chunk)
                    emit_log(
                        f"[logout-rec] {len(logout_acc)} steps so far: "
                        + str([s.get("kind") for s in logout_acc]))
            except Exception as e:
                if _browser_is_gone(e):
                    _gone = True
            if _gone:
                emit_log("[logout-rec] browser window was closed — stopping recorder.")
                result["_cancelled"] = True
                return
            if done.wait(0.15): break

        try:
            chunk = json.loads(driver.execute_script(_MACRO_DRAIN_JS) or "[]")
            if chunk: logout_acc.extend(chunk)
        except Exception: pass

        emit_log(
            f"[logout-rec] recorded {len(logout_acc)} steps: "
            + str([s.get("kind") + ":" + str(s.get("selector", ""))[:30]
                   for s in logout_acc]))

        logout_href_candidates: list = []
        result["last_logout_click"] = {}
        for s in logout_acc:
            if s.get("kind") == "click":
                h    = s.get("href", "")
                txt  = (s.get("text",        "") or "").lower()
                eid  = (s.get("el_id",       "") or "").lower()
                ecls = (s.get("el_cls",      "") or "").lower()
                dact = (s.get("data_action", "") or "").lower()
                combined = " ".join([h.lower(), txt, eid, ecls, dact])
                is_kw = any(k in combined for k in _LOGOUT_KW)
                if h and is_kw:
                    if h not in logout_href_candidates:
                        logout_href_candidates.append(h)
        for s in reversed(logout_acc):
            if s.get("kind") == "click":
                result["last_logout_click"] = {
                    "selector":          s.get("selector",    ""),
                    "fallback_selectors": s.get("fallback_selectors", []),
                    "href":              s.get("href",         ""),
                    "text":              s.get("text",         ""),
                    "el_id":             s.get("el_id",        ""),
                    "el_cls":            s.get("el_cls",       ""),
                    "data_action":       s.get("data_action",  ""),
                }
                emit_log(
                    f"[logout-rec] last click → sel={s.get('selector','')[:60]!r} "                     f"text={s.get('text','')!r} id={s.get('el_id','')!r}"
                )
                break

        set_status("📸  Capturing logout state…")
        snap = {}
        try:
            raw = driver.execute_script(_LOGOUT_CAPTURE_JS)
            if raw: snap = json.loads(raw)
        except Exception as e:
            emit_log(f"[logout-rec] JS capture error: {e!r}")
        result["snapshot"] = snap if isinstance(snap, dict) else {}
        result["logout_macro"] = logout_acc
        result["logout_href_candidates"] = logout_href_candidates
        try: result["final_url"] = driver.current_url
        except Exception:
            result["final_url"] = snap.get("url", "") if isinstance(snap, dict) else ""
        try: result["cookies"] = driver.get_cookies() or []
        except Exception: result["cookies"] = []
        emit_log(
            f"[logout-rec] done. final_url={result.get('final_url', '')!r} "
            f"steps={len(logout_acc)} hrefs={logout_href_candidates!r}")

    return _work

def test_logout_work(cfg: DastConfig,
                     emit_log: Callable[[str], None] = lambda _: None):
    """Return a `work` callable that tests login + logout end-to-end."""
    def _work(driver, url, done, result, set_status=lambda _: None):
        import time as _t
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC
        from selenium.webdriver.common.by import By

        login_url  = (cfg.selenium_login_url or url).strip()
        pass_val   = cfg.selenium_pass_value.strip()
        macro_raw  = cfg.selenium_macro.strip()
        succ_sel   = cfg.login_success_selector.strip()
        succ_txt   = cfg.login_success_text.strip()
        logout_macro_raw = (getattr(cfg, "selenium_logout_macro", "") or "").strip()

        per_wait = max(2, min(int(cfg.selenium_wait_seconds or 15), 10))

        emit_log(f"[test-logout] navigating to login page: {login_url}")
        set_status("⏳  Opening login page…")
        try:
            driver.get(login_url)
        except Exception as e:
            emit_log(f"[test-logout] navigation error: {e!r}")
        _nav = result.get("_nav_done")
        if _nav is not None:
            _nav.set()
        _t.sleep(1.0)

        set_status("🔁  Replaying login condition…")
        try:
            macro = json.loads(macro_raw) if macro_raw else []
        except Exception as ex:
            macro = []
            emit_log(f"[test-logout] macro JSON invalid: {ex!r}")

        if macro:
            _replay_login_macro(
                driver, macro, pass_value=(pass_val or None),
                wait_seconds=cfg.selenium_wait_seconds, log=emit_log)
        elif cfg.selenium_user_selector or cfg.selenium_pass_selector:
            def _find(sel, timeout=per_wait):
                try:
                    return WebDriverWait(driver, timeout).until(
                        EC.presence_of_element_located((By.CSS_SELECTOR, sel)))
                except Exception:
                    return None
            if cfg.selenium_user_selector and cfg.selenium_user_value:
                el = _find(cfg.selenium_user_selector)
                if el:
                    try: el.clear(); el.send_keys(cfg.selenium_user_value)
                    except Exception: pass
            if cfg.selenium_pass_selector and pass_val:
                el = _find(cfg.selenium_pass_selector)
                if el:
                    try:
                        el.clear(); el.send_keys(pass_val)
                    except Exception: pass
            if cfg.selenium_submit_selector:
                el = _find(cfg.selenium_submit_selector)
                if el:
                    try: el.click()
                    except Exception: pass
            elif cfg.selenium_pass_selector and pass_val:
                try:
                    from selenium.webdriver.common.keys import Keys as _K
                    driver.find_element(
                        By.CSS_SELECTOR, cfg.selenium_pass_selector).send_keys(_K.ENTER)
                except Exception: pass

        try: driver.switch_to.default_content()
        except Exception: pass

        set_status("⏳  Waiting for login to complete…")
        logged_in = False
        try:
            if succ_sel:
                WebDriverWait(driver, per_wait).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, succ_sel)))
                logged_in = True
                emit_log("[test-logout] login confirmed (selector)")
            elif succ_txt:
                WebDriverWait(driver, per_wait).until(
                    lambda d: succ_txt in d.page_source)
                logged_in = True
                emit_log("[test-logout] login confirmed (text)")
            else:
                _t.sleep(2)
                gone = not driver.execute_script(
                    "var ps=document.querySelectorAll('input[type=password]');"
                    "for(var i=0;i<ps.length;i++)"
                    " if(ps[i].offsetParent!==null) return true;"
                    "return false;")
                logged_in = gone
                emit_log(f"[test-logout] login heuristic logged_in={gone}")
        except Exception as e:
            emit_log(f"[test-logout] login confirmation error: {e!r}")

        if logged_in:
            set_status("✅  Logged in — navigating to logout URL…")
        else:
            set_status("⚠️  Login uncertain — attempting logout navigation anyway…")
            emit_log("[test-logout] login could not be confirmed; proceeding")

        _t.sleep(1.0)

        replayed_logout = False
        emit_log(f"[test-logout] logout_macro_raw length={len(logout_macro_raw)}")
        if logout_macro_raw:
            try:
                lo_macro = json.loads(logout_macro_raw)
            except Exception as ex:
                lo_macro = []
                emit_log(f"[test-logout] logout macro JSON invalid: {ex!r}")
            if lo_macro:
                set_status("🚪  Replaying logout steps…")
                emit_log(
                    f"[test-logout] replaying logout macro ({len(lo_macro)} steps): "
                    + str([s.get("kind") + ":" + str(s.get("selector", ""))[:30]
                           for s in lo_macro]))
                url_before = driver.current_url
                try:
                    _replay_login_macro(
                        driver, lo_macro, pass_value=None,
                        wait_seconds=cfg.selenium_wait_seconds, log=emit_log)
                    _t.sleep(2.5)
                    url_after = driver.current_url
                    replayed_logout = True
                    result["logout_url_reached"] = url_after
                    result["logout_replayed"]    = True
                    url_changed = (url_after.rstrip("/") != url_before.rstrip("/"))
                    emit_log(
                        f"[test-logout] after logout: {url_after!r} "
                        f"(url_changed={url_changed})")
                except Exception as ex:
                    emit_log(f"[test-logout] logout macro replay raised: {ex!r}")
            else:
                emit_log("[test-logout] logout macro parsed but empty (0 steps)")
        else:
            emit_log("[test-logout] selenium_logout_macro is EMPTY — "
                     "the Logout Condition was never saved into the config")
        if not replayed_logout:
            emit_log("[test-logout] no logout macro — re-record Logout Condition")

        if replayed_logout:
            set_status("✅  Logout replayed — closing browser…")
        else:
            set_status("⚠️  Logout not completed — re-record Logout Condition")

        _t.sleep(1.5)
        result["test_done"] = True
        done.set()

    return _work

@dataclass
class DastConfig(_BaseDastConfig):
    probely_token: str = ""
    probely_api_base: str = "https://api.probely.com"
    probely_auth_scheme: str = "JWT"
    probely_target_id: str = ""
    probely_scan_profile: str = ""
    probely_login_sequence_path: str = ""
    probely_poll_interval: float = 15.0
    probely_max_wait_minutes: float = 180.0
    probely_reuse_by_url: bool = True
    probely_blacklist: str = ""
    probely_logout_detection: bool = True
    probely_check_session_url: str = ""
    probely_logout_markers: str = ""
    probely_logout_condition: str = "any"
    probely_logout_url_detector: bool = True
    probely_logout_code_detector: bool = True
    probely_logout_selector: str = ""
    probely_login_url: str = ""
    probely_protect_session: bool = True
    probely_form_login: str = "auto"
    probely_form_login_check_pattern: str = ""
    probely_form_submit_selector: str = ""
    probely_region: str = ""
    probely_2fa_enabled: bool = False
    probely_otp_secret: str = ""
    probely_otp_field: str = ""
    probely_otp_submit: str = ""
    probely_otp_algorithm: str = "SHA1"
    probely_otp_digits: int = 6
    probely_reduced_scopes: str = ""
    probely_extra_hosts: str = ""
    probely_ignore_blackout: bool = False
    probely_compliance_report: str = ""
    probely_agent_warn: bool = True
    probely_require_verified: bool = False
    probely_logout_body_markers: str = ""
    probely_logout_header_markers: str = ""

    probely_orchestrate: bool = True
    probely_pool_size: int = 5
    probely_slot_cooldown_minutes: float = 60.0
    probely_ledger_path: str = ""

@dataclass
class ApiConfig(_BaseApiConfig):
    probely_token: str = ""
    probely_api_base: str = "https://api.probely.com"
    probely_auth_scheme: str = "JWT"
    probely_target_id: str = ""
    probely_scan_profile: str = ""
    probely_login_sequence_path: str = ""
    probely_poll_interval: float = 15.0
    probely_max_wait_minutes: float = 180.0
    probely_reuse_by_url: bool = True
    probely_protect_session: bool = True
    probely_region: str = ""
    probely_reduced_scopes: str = ""
    probely_ignore_blackout: bool = False
    probely_compliance_report: str = ""
    probely_check_login: bool = True
    probely_require_verified: bool = False
    probely_api_schema_type: str = ""
    probely_api_login_url: str = ""
    probely_api_login_payload: str = ""
    probely_api_login_media_type: str = "application/json"
    probely_api_login_token_field: str = ""
    probely_api_login_token_param: str = "Authorization"
    probely_api_login_token_prefix: str = ""
    probely_api_login_place: str = "header"

    probely_orchestrate: bool = True
    probely_pool_size: int = 5
    probely_slot_cooldown_minutes: float = 60.0
    probely_ledger_path: str = ""

def _norm_severity(prob_sev: Any, cvss: Any) -> str:
    try:
        s = int(prob_sev)
    except (TypeError, ValueError):
        s = 0
    try:
        c = float(cvss)
    except (TypeError, ValueError):
        c = 0.0
    if s >= 30:
        return "critical" if c >= 9.0 else "high"
    if s >= 20:
        return "medium"
    if s >= 10:
        return "low"
    return "low"

_CATEGORY_KEYWORDS = (
    ("sql", "sqli"), ("cross-site scripting", "xss"), ("xss", "xss"),
    ("authentication", "auth"), ("authorization", "auth"),
    ("bola", "auth"), ("object level", "auth"),
    ("redirect", "redirect"), ("ssrf", "ssrf"),
    ("header", "headers"), ("csp", "headers"), ("hsts", "headers"),
    ("cors", "headers"), ("tls", "transport"), ("unencrypted", "transport"),
    ("csrf", "csrf"), ("injection", "injection"),
    ("information", "info"), ("disclosure", "info"),
)

def _category_for(name: str, default: str) -> str:
    low = (name or "").lower()
    for kw, cat in _CATEGORY_KEYWORDS:
        if kw in low:
            return cat
    return default

def _evidence_for(f: dict) -> str:
    parts = []
    ev = (f.get("evidence") or "").strip()
    if ev:
        parts.append(ev)
    reqs = f.get("requests") or []
    if reqs and isinstance(reqs, list) and isinstance(reqs[0], dict):
        rq = (reqs[0].get("request") or "").strip()
        if rq:
            parts.append(rq)
    cvss = f.get("cvss_vector")
    if cvss:
        parts.append(f"CVSS: {cvss}")
    return ("\n".join(parts))[:600]

def _normalise_finding(f: dict, default_category: str) -> dict:
    definition = f.get("definition") or {}
    name = definition.get("name") or "Finding"
    param = f.get("parameter") or ""
    title = f"{name} in '{param}'" if param else name
    return {
        "severity": _norm_severity(f.get("severity"), f.get("cvss_score")),
        "title": title,
        "url": f.get("url") or f.get("path") or "",
        "evidence": _evidence_for(f),
        "cwe": definition.get("cwe") or "",
        "category": _category_for(name, default_category),
    }

_REGION_BASES = {
    "eu": "https://api.probely.com",
    "us": "https://api.us.probely.com",
    "au": "https://api.au.probely.com",
}
_DEFAULT_BASE = "https://api.probely.com"

def _resolve_api_base(cfg) -> str:
    base = (getattr(cfg, "probely_api_base", "") or "").strip()
    region = (getattr(cfg, "probely_region", "") or "").strip().lower()
    if base and base.rstrip("/") != _DEFAULT_BASE:
        return base
    if region in _REGION_BASES:
        return _REGION_BASES[region]
    return base or _DEFAULT_BASE

def _app_base(cfg) -> str:
    region = (getattr(cfg, "probely_region", "") or "").strip().lower()
    if region in ("us", "au"):
        return f"https://plus.{region}.probely.app"
    base = (getattr(cfg, "probely_api_base", "") or "").lower()
    if ".us.probely.com" in base:
        return "https://plus.us.probely.app"
    if ".au.probely.com" in base:
        return "https://plus.au.probely.app"
    return "https://plus.probely.app"

def _host_looks_non_public(url: str) -> bool:
    """Heuristic: True if the target host is almost certainly NOT reachable from Probely's cloud (private/loopback/li…"""
    import ipaddress
    import socket
    try:
        host = (urlparse(url).hostname or "").strip().lower()
    except Exception:
        return False
    if not host:
        return False
    if host in ("localhost",) or host.endswith((".local", ".internal", ".lan", ".test", ".localhost")):
        return True
    try:
        ip = ipaddress.ip_address(host)
        return ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved
    except ValueError:
        pass
    try:
        infos = socket.getaddrinfo(host, None)
        addrs = {i[4][0] for i in infos}
        if not addrs:
            return True
        for a in addrs:
            try:
                ip = ipaddress.ip_address(a)
                if not (ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved):
                    return False
            except ValueError:
                return False
        return True
    except Exception:
        return True

class ProbelyError(Exception):
    """Raised for non-retryable API errors (auth, validation, not found)."""
    def __init__(self, message: str, *, status: int = 0, is_auth: bool = False):
        super().__init__(message)
        self.status = status
        self.is_auth = is_auth

def _truthy_env(name: str) -> bool:
    return (os.environ.get(name, "") or "").strip().lower() in ("1", "true", "yes", "on")

def _find_corporate_ca() -> Optional[str]:
    """Locate a corporate CA bundle that IT/MDM may already have configured, so we can trust a TLS-inspecting proxy *…"""
    for var in ("PROBELY_CA_BUNDLE", "SNYK_CA_BUNDLE", "REQUESTS_CA_BUNDLE",
                "SSL_CERT_FILE", "CURL_CA_BUNDLE", "NODE_EXTRA_CA_CERTS"):
        p = os.environ.get(var)
        try:
            if p and Path(p).is_file() and Path(p).stat().st_size > 0:
                return p
        except OSError:
            continue
    return None

def _build_probely_ssl_context(log: Callable[[str], None]) -> ssl.SSLContext:
    """TLS context for every Probely API call, hardened for corporate TLS-inspecting proxies: loads the corporate CA…"""
    ca = _find_corporate_ca()
    if not ca and os.name == "nt":

        try:
            from static_scanner import _export_windows_ca_bundle
            ca = _export_windows_ca_bundle(log)
        except Exception:
            ca = None
    try:
        ctx = ssl.create_default_context(cafile=ca) if ca else ssl.create_default_context()
        if ca:
            log(f"[snyk-aw] using corporate CA bundle for TLS: {ca}")
    except Exception as e:
        log(f"[snyk-aw] could not load CA bundle {ca!r} ({e!r}); "
            f"falling back to the system trust store")
        ctx = ssl.create_default_context()

    strict = getattr(ssl, "VERIFY_X509_STRICT", 0)
    if strict and (ctx.verify_flags & strict):
        ctx.verify_flags &= ~strict
        log("[snyk-aw] cleared X.509-strict verification flag (allows a trusted "
            "corporate CA whose basicConstraints isn't marked critical).")

    if _truthy_env("PROBELY_INSECURE_TLS"):
        log("[snyk-aw] WARNING: PROBELY_INSECURE_TLS=1 — TLS certificate "
            "verification is DISABLED for Probely API calls. Use only as a "
            "temporary workaround on a trusted network.")
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    return ctx

def _is_tls_verify_error(exc: BaseException) -> bool:
    """True if a urllib error was caused by TLS certificate verification."""
    reason = getattr(exc, "reason", exc)
    if isinstance(reason, ssl.SSLCertVerificationError):
        return True
    return "CERTIFICATE_VERIFY_FAILED" in repr(exc)

def _tls_error_help(exc: BaseException, base: str) -> str:
    return (
        f"No se pudo verificar el certificado TLS de {base}. Tu red corporativa "
        "intercepta el tráfico HTTPS y presenta un certificado emitido por una CA "
        "interna. Soluciones, en orden:\n"
        "  1) Exporta la CA raíz de tu empresa a un archivo .pem y apunta la "
        "variable de entorno PROBELY_CA_BUNDLE a ese archivo, luego reinicia la app.\n"
        "  2) Si el detalle menciona «Basic Constraints of CA cert not marked "
        "critical», la app ya relaja esa comprobación automáticamente; reinstálala/"
        "reiníciala para tomar el cambio.\n"
        "  3) Último recurso temporal, solo en una red de confianza: define "
        "PROBELY_INSECURE_TLS=1 antes de abrir la app.\n"
        f"Detalle técnico: {exc!r}"
    )

_DEFAULT_UA = "BBScanner/1.0 (Snyk API & Web / Probely API client)"

def _resolve_user_agent() -> str:
    return (os.environ.get("PROBELY_USER_AGENT") or "").strip() or _DEFAULT_UA

def _looks_like_cloudflare_block(body: str) -> bool:
    """True if a 403 body is actually a Cloudflare WAF/Browser-Integrity block (Error 1010) rather than a Probely aut…"""
    low = (body or "").lower().replace(" ", "")
    return ('"error_code":1010' in low or "error1010" in low
            or "browser'ssignature" in low or "browsersignature" in low
            or ("cloudflare" in low and "accessdenied" in low))

def _cloudflare_block_help(body: str) -> str:
    return (
        "Bloqueo de Cloudflare (Error 1010, «Access denied»). NO es un problema "
        "del token ni de su rol: la petición se rechazó por la «firma» del cliente "
        "HTTP (su User-Agent / huella) ANTES de llegar a Probely. La prueba es que "
        "incluso /profile/ —que cualquier token puede leer— fue bloqueado.\n"
        "Qué hacer, en orden:\n"
        "  1) La app ahora envía un User-Agent propio en vez del de Python; "
        "reiníciala. Si tu WAF exige un navegador real, define la variable de "
        "entorno PROBELY_USER_AGENT con un User-Agent de Chrome/Edge.\n"
        "  2) Si persiste, casi siempre es el proxy/WAF corporativo o la IP de "
        "salida: pide a Ciberseguridad (slunam@bancobase.com) que permita el "
        "tráfico saliente hacia api.probely.com sin «Browser Integrity Check» / "
        "inspección de bots.\n"
        f"Detalle de Cloudflare: {body[:300]}"
    )

class _Probely:
    def __init__(self, token: str, base: str, log: Callable[[str], None],
                 scheme: str = "JWT"):
        if not token:
            raise ProbelyError(
                "No Snyk API & Web (Probely) credential available. Sign in to Snyk "
                "(SSO) so the scan can reuse that session before scanning.",
                is_auth=True)
        self._token = token
        self._scheme = (scheme or "JWT").strip() or "JWT"
        self._base = (base or "https://api.probely.com").rstrip("/")
        self._log = log
        self._ua = _resolve_user_agent()
        ctx = _build_probely_ssl_context(log)
        self._opener = build_opener(HTTPSHandler(context=ctx))

    def _url(self, path: str) -> str:
        return self._base + "/" + path.lstrip("/")

    def _request(self, method: str, path: str, *, body: Optional[bytes] = None,
                 content_type: Optional[str] = None, params: Optional[dict] = None,
                 expect=(200, 201), timeout: int = 60, retries: int = 4) -> Any:
        url = self._url(path)
        if params:
            url += ("&" if "?" in url else "?") + urlencode(params)
        headers = {
            "Authorization": f"{self._scheme} {self._token}",
            "Accept": "application/json",

            "User-Agent": self._ua,
            "Accept-Language": "en-US,en;q=0.9",
        }
        if content_type:
            headers["Content-Type"] = content_type
        last_exc: Optional[BaseException] = None
        for attempt in range(retries):
            req = Request(url, data=body, method=method, headers=headers)
            try:
                with self._opener.open(req, timeout=timeout) as r:
                    raw = r.read()
                    if r.status not in expect:
                        raise ProbelyError(f"{method} {path} → HTTP {r.status}",
                                           status=r.status)
                    return json.loads(raw) if raw else {}
            except HTTPError as e:
                code = e.code
                try:
                    detail = e.read(8000).decode("utf-8", "replace")
                except Exception:
                    detail = ""
                if code == 403 and _looks_like_cloudflare_block(detail):

                    raise ProbelyError(_cloudflare_block_help(detail),
                                       status=code, is_auth=False)
                if code in (401, 403):
                    raise ProbelyError(
                        f"Authentication/permission error (HTTP {code}). Check the "
                        f"API token and its role. {detail[:300]}",
                        status=code, is_auth=True)
                if code == 429 or 500 <= code < 600:
                    wait = _retry_after(e) or (2 ** attempt)
                    self._log(f"[snyk-aw] HTTP {code} on {method} {path}; "
                              f"retry in {wait:.0f}s")
                    last_exc = ProbelyError(f"HTTP {code}: {detail[:200]}", status=code)
                    time.sleep(min(wait, 30))
                    continue
                raise ProbelyError(f"{method} {path} → HTTP {code}: {detail[:300]}",
                                   status=code)
            except (URLError, TimeoutError) as e:
                if _is_tls_verify_error(e):

                    raise ProbelyError(_tls_error_help(e, self._base), is_auth=False)
                last_exc = e
                self._log(f"[snyk-aw] network error on {method} {path}: {e!r} "
                          f"(attempt {attempt + 1}/{retries})")
                time.sleep(min(2 ** attempt, 30))
            except json.JSONDecodeError as e:
                raise ProbelyError(f"Malformed JSON from {method} {path}: {e!r}")
        raise ProbelyError(f"{method} {path} failed after {retries} attempts: {last_exc!r}")

    def _get(self, path, **kw):  return self._request("GET", path, **kw)
    def _post(self, path, **kw): return self._request("POST", path, **kw)
    def _patch(self, path, **kw): return self._request("PATCH", path, **kw)
    def _delete(self, path, **kw):
        kw.setdefault("expect", (200, 202, 204))
        return self._request("DELETE", path, **kw)

    def whoami(self) -> dict:
        return self._get("/profile/")

    def find_target_by_url(self, url: str, ttype: Optional[str]) -> Optional[dict]:
        """Best-effort: page through targets and match site.url (and type)."""
        want = url.rstrip("/")
        page = 1
        while page <= 50:
            data = self._get("/targets/", params={"page": page})
            results = data.get("results") if isinstance(data, dict) else None
            if not results:
                break
            for t in results:
                site = t.get("site") or {}
                if (site.get("url") or "").rstrip("/") == want:
                    if ttype is None or (t.get("type") or "single") == ttype:
                        return t
            if data.get("page_total") and page >= data["page_total"]:
                break
            page += 1
        return None

    def create_web_target(self, name: str, url: str) -> dict:
        body = json.dumps({"site": {"name": name, "url": url}}).encode()
        return self._post("/targets/", body=body, content_type="application/json")

    def create_api_target(self, name: str, url: str, schema_type: str,
                          schema_url: str = "") -> dict:
        site: dict[str, Any] = {"name": name, "url": url,
                                "api_scan_settings": {"api_schema_type": schema_type}}
        if schema_url:
            site["api_scan_settings"]["api_schema_url"] = schema_url
        body = json.dumps({"site": site, "type": "api"}).encode()
        return self._post("/targets/", body=body, content_type="application/json")

    def upload_api_schema_file(self, target_id: str, file_path: str) -> dict:
        data, ctype = _multipart_file("file", file_path)
        return self._post(f"/targets/{target_id}/upload_api_schema_file/",
                          body=data, content_type=ctype)

    def add_login_sequence(self, target_id: str, name: str, content_json: str) -> dict:
        body = json.dumps({"name": name, "content": content_json,
                           "type": "login", "enabled": True}).encode()
        return self._post(f"/targets/{target_id}/sequences/", body=body,
                          content_type="application/json")

    def enable_sequence_auth(self, target_id: str) -> dict:
        body = json.dumps({"site": {"has_sequence_login": True,
                                    "has_form_login": False,
                                    "auth_enabled": True}}).encode()
        return self._patch(f"/targets/{target_id}/", body=body,
                           content_type="application/json")

    def configure_form_login(self, target_id: str, *, form_login_url: str,
                             fields: list[dict], check_pattern: str = "") -> dict:
        """Configure FORM-based authentication on the target."""
        site: dict[str, Any] = {
            "has_form_login": True,
            "has_sequence_login": False,
            "auth_enabled": True,
            "form_login_url": form_login_url,
            "form_login": fields,
        }
        site["form_login_check_pattern"] = (check_pattern or "")[:255]
        body = json.dumps({"site": site}).encode()
        return self._patch(f"/targets/{target_id}/", body=body,
                           content_type="application/json")

    def set_blacklist(self, target_id: str, urls: list[str]) -> dict:
        """Replace the target's blacklist (URLs the crawler must never visit)."""
        body = json.dumps({"site": {"blacklist": urls}}).encode()
        return self._patch(f"/targets/{target_id}/", body=body,
                           content_type="application/json")

    def list_logout_detectors(self, target_id: str) -> dict:
        return self._get(f"/targets/{target_id}/logout/")

    def create_logout_detector(self, target_id: str, value: str,
                               type_: str = "text") -> dict:
        body = json.dumps({"type": type_, "value": value}).encode()
        return self._post(f"/targets/{target_id}/logout/", body=body,
                          content_type="application/json")

    def update_logout_detector(self, target_id: str, detector_id: str,
                               type_: str, value: str) -> dict:
        """Update an existing logout detector."""
        body = json.dumps({"type": type_, "value": value}).encode()
        return self._patch(f"/targets/{target_id}/logout/{detector_id}/",
                           body=body, content_type="application/json")

    def enable_logout_detection(self, target_id: str, check_session_url: str,
                                condition: str = "any") -> dict:
        body = json.dumps({"site": {"check_session_url": check_session_url,
                                    "logout_detection_enabled": True,
                                    "logout_condition": condition}}).encode()
        return self._patch(f"/targets/{target_id}/", body=body,
                           content_type="application/json")

    def set_basic_auth(self, target_id: str, *, username: str, password: str) -> dict:
        """Configure Probely's NATIVE HTTP Basic authentication on the target (site.has_basic_auth / site.basic_auth), in…"""
        site: dict[str, Any] = {
            "has_basic_auth": True,
            "auth_enabled": True,
            "basic_auth": {"username": username, "password": password},
        }
        body = json.dumps({"site": site}).encode()
        return self._patch(f"/targets/{target_id}/", body=body,
                           content_type="application/json")

    def list_scan_profiles(self, target_type: str = "", *,
                           verified: Optional[bool] = None) -> list[dict]:
        """List built-in + custom scan profiles."""
        params: dict[str, Any] = {}
        if target_type:
            params["type"] = target_type
        if verified is not None:
            params["verified"] = "true" if verified else "false"
        profiles: list[dict] = []
        page = 1
        while page <= 20:
            params["page"] = page
            data = self._get("/scan-profiles/", params=params)
            for p in (data.get("results") or []):
                profiles.append(p)
            if not data.get("page_total") or page >= data["page_total"]:
                break
            page += 1
        return profiles

    def set_auth_credentials(self, target_id: str, *, cookies=None, headers=None,
                             auth_enabled: bool = True) -> dict:
        """Register static auth cookies/headers on the target."""
        site: dict[str, Any] = {"auth_enabled": auth_enabled}
        if cookies is not None:
            site["cookies"] = cookies
        if headers is not None:
            site["headers"] = headers
        body = json.dumps({"site": site}).encode()
        return self._patch(f"/targets/{target_id}/", body=body,
                           content_type="application/json")

    def scan_now(self, target_id: str, *, scan_profile: str = "",
                 reduced_scopes: Optional[list] = None,
                 ignore_blackout: bool = False) -> dict:
        payload: dict[str, Any] = {}
        if scan_profile:
            payload["scan_profile"] = scan_profile
        if reduced_scopes:
            payload["reduced_scopes"] = reduced_scopes
        if ignore_blackout:
            payload["ignore_blackout"] = True
        body = json.dumps(payload).encode() if payload else b"{}"
        return self._post(f"/targets/{target_id}/scan_now/", body=body,
                          content_type="application/json")

    def get_scan(self, target_id: str, scan_id: str) -> dict:
        return self._get(f"/targets/{target_id}/scans/{scan_id}")

    def cancel_scan(self, target_id: str, scan_id: str) -> dict:
        return self._post(f"/targets/{target_id}/scans/{scan_id}/cancel/",
                          body=b"{}", content_type="application/json",
                          expect=(200, 201, 202))

    def list_targets(self) -> list[dict]:
        """Page through every target in the account (the orchestrator pool)."""
        out: list[dict] = []
        page = 1
        while page <= 50:
            data = self._get("/targets/", params={"page": page})
            results = data.get("results") if isinstance(data, dict) else None
            if not results:
                break
            out.extend(results)
            if not data.get("page_total") or page >= data["page_total"]:
                break
            page += 1
        return out

    def delete_target(self, target_id: str) -> dict:
        """DELETE a target, freeing its slot in the pool."""
        return self._delete(f"/targets/{target_id}/")

    def list_scans_for_target(self, target_id: str) -> list[dict]:
        """All scans for a target."""
        out: list[dict] = []
        try:
            page = 1
            while page <= 50:
                data = self._get("/scans/", params={"f_target": target_id, "page": page})
                results = data.get("results") if isinstance(data, dict) else None
                if results is None:
                    raise ProbelyError("no results key on /scans/")
                out.extend(results)
                if not data.get("page_total") or page >= data["page_total"]:
                    break
                page += 1
            return out
        except ProbelyError:
            out = []
            page = 1
            while page <= 50:
                data = self._get(f"/targets/{target_id}/scans/", params={"page": page})
                results = data.get("results") if isinstance(data, dict) else None
                if not results:
                    break
                out.extend(results)
                if not data.get("page_total") or page >= data["page_total"]:
                    break
                page += 1
            return out

    def iter_findings(self, target_id: str, *, state: str = "notfixed"):
        page = 1
        while page <= 200:
            data = self._get(f"/targets/{target_id}/findings/",
                             params={"state": state, "page": page})
            for f in (data.get("results") or []):
                yield f
            if not data.get("page_total") or page >= data["page_total"]:
                break
            page += 1

    def configure_2fa(self, target_id: str, *, secret: str, otp_field: str = "",
                      otp_submit: str = "", algorithm: str = "SHA1",
                      digits: int = 6) -> dict:
        """Enable TOTP-based 2FA on the target."""
        site: dict[str, Any] = {"has_otp": True, "otp_secret": secret}
        if otp_field:
            site["otp_field"] = otp_field
        if otp_submit:
            site["otp_submit"] = otp_submit
        if algorithm:
            site["otp_algorithm"] = algorithm
        if digits:
            site["otp_digits"] = int(digits)
        body = json.dumps({"site": site}).encode()
        return self._patch(f"/targets/{target_id}/", body=body,
                           content_type="application/json")

    def add_extra_host(self, target_id: str, url: str) -> dict:
        body = json.dumps({"url": url}).encode()
        return self._post(f"/targets/{target_id}/extra_hosts/", body=body,
                          content_type="application/json")

    def check_api_login(self, target_id: str) -> dict:
        """Ask Probely to test the configured API login by performing a login request."""
        return self._post(f"/targets/{target_id}/check_api_login/", body=b"{}",
                          content_type="application/json",
                          expect=(200, 201, 202))

    def configure_api_login(self, target_id: str, *, login_url: str, payload: str,
                            media_type: str, token_field: str, token_param: str,
                            token_prefix: str, place: str = "header") -> dict:
        """Configure API Target Authentication via a login ENDPOINT (token retrieval): POST ``payload`` to ``login_url``…"""
        site: dict[str, Any] = {
            "api_login_url": login_url,
            "api_login_payload": payload,
            "api_login_media_type": media_type or "application/json",
            "api_login_token_field": token_field,
            "api_login_token_param": token_param or "Authorization",
            "api_login_token_prefix": token_prefix or "",
            "api_login_token_place": place or "header",
            "auth_enabled": True,
        }
        body = json.dumps({"site": site}).encode()
        return self._patch(f"/targets/{target_id}/", body=body,
                           content_type="application/json")

    def download_report(self, target_id: str, scan_id: str, template: str,
                        timeout: int = 120) -> bytes:
        """Download a scan report as PDF for the given compliance template."""
        url = self._url(f"/targets/{target_id}/scans/{scan_id}/report/")
        url += ("&" if "?" in url else "?") + urlencode({"report_type": template})
        headers = {"Authorization": f"{self._scheme} {self._token}",
                   "Accept": "application/pdf"}
        req = Request(url, method="GET", headers=headers)
        with self._opener.open(req, timeout=timeout) as r:
            if r.status not in (200, 201):
                raise ProbelyError(f"report download → HTTP {r.status}", status=r.status)
            return r.read()

def _retry_after(exc: HTTPError) -> float:
    try:
        v = exc.headers.get("Retry-After")
        return float(v) if v else 0.0
    except Exception:
        return 0.0

def _multipart_file(field_name: str, file_path: str) -> tuple[bytes, str]:
    """Build a minimal multipart/form-data body for a single file upload."""
    p = Path(file_path)
    payload = p.read_bytes()
    filename = p.name
    ctype = mimetypes.guess_type(filename)[0] or "application/octet-stream"
    boundary = "----snykaw" + uuid.uuid4().hex
    pre = (f"--{boundary}\r\n"
           f'Content-Disposition: form-data; name="{field_name}"; '
           f'filename="{filename}"\r\n'
           f"Content-Type: {ctype}\r\n\r\n").encode()
    post = f"\r\n--{boundary}--\r\n".encode()
    return pre + payload + post, f"multipart/form-data; boundary={boundary}"

def macro_to_probely_sequence(macro: list) -> str:
    """Convert the local Selenium macro (list of recorded events) into a JSON string suitable for a Probely login seq…"""
    commands: list = []

    start_url = ""
    for ev in (macro or []):
        if isinstance(ev, dict) and (ev.get("url") or "").strip():
            start_url = ev["url"].strip()
            break
    if start_url:
        commands.append({"command": "open", "target": start_url, "value": ""})

    for ev in (macro or []):
        if not isinstance(ev, dict):
            continue
        kind = ev.get("kind") or ev.get("type")
        sel  = ev.get("selector") or ev.get("sel") or ""
        url  = ev.get("url") or ""
        val  = ev.get("value")

        if kind in ("navigate", "open"):
            if url and (not commands or commands[-1].get("target") != url):
                commands.append({"command": "open", "target": url, "value": ""})
        elif kind in ("field", "input", "change") and sel:
            tgt = _css(sel)
            v = "" if val is None else str(val)
            if (commands and commands[-1].get("command") == "type"
                    and commands[-1].get("target") == tgt):
                commands[-1]["value"] = v
            else:
                commands.append({"command": "type", "target": tgt, "value": v})
        elif kind == "click" and sel:
            commands.append({"command": "click", "target": _css(sel), "value": ""})
        elif kind == "submit":
            btn  = ev.get("button") or sel
            form = ev.get("form") or sel
            if btn:
                tgt = _css(btn)
                if not (commands and commands[-1].get("command") == "click"
                        and commands[-1].get("target") == tgt):
                    commands.append({"command": "click", "target": tgt, "value": ""})
            elif form:
                commands.append({"command": "submit", "target": _css(form), "value": ""})
        elif kind in ("enter", "keydown"):
            tgt = sel or ev.get("form") or ""
            if tgt and not (commands and commands[-1].get("command")
                            in ("click", "submit", "sendKeys")):
                commands.append({"command": "sendKeys", "target": _css(tgt),
                                 "value": "${KEY_ENTER}"})
    seq = {"version": "selenium-ide-compatible", "commands": commands}
    return json.dumps(seq)

def _css(sel: str) -> str:
    return sel if sel.startswith(("css=", "id=", "name=", "xpath=")) else f"css={sel}"

def _resolve_login_sequence(cfg, log) -> Optional[tuple[str, str]]:
    """Return (name, content_json) for the login sequence, or None."""
    path = getattr(cfg, "probely_login_sequence_path", "") or ""
    if path:
        p = Path(path)
        if p.exists():
            log(f"[snyk-aw] using Probely login sequence file: {p.name}")
            return (p.stem or "login sequence", p.read_text(encoding="utf-8"))
        log(f"[snyk-aw] login sequence file not found: {path}")
    macro_raw = getattr(cfg, "selenium_macro", "") or ""
    if macro_raw:
        try:
            macro = json.loads(macro_raw) if isinstance(macro_raw, str) else macro_raw
        except Exception:
            macro = None
        if macro:
            log("[snyk-aw] converting recorded Selenium macro → Probely sequence "
                "(best-effort; validate against a real Probely export).")
            return ("converted login sequence", macro_to_probely_sequence(macro))
    return None

def _resolve_form_login(cfg, base_url: str, log) -> Optional[tuple[str, list[dict], str]]:
    """Build a Probely FORM-login config from cfg (login_data, or the Selenium user/pass selector+value pairs), or No…"""
    mode = (getattr(cfg, "probely_form_login", "auto") or "auto").strip().lower()
    if mode == "off":
        return None
    auth = (getattr(cfg, "auth_type", "none") or "none").strip().lower()

    fields: list[dict] = []
    login_data = (getattr(cfg, "login_data", "") or "").strip()
    if login_data:
        for k, val in parse_qsl(login_data, keep_blank_values=True):
            if k:
                fields.append({"name": k, "value": val})
    else:
        user_sel = (getattr(cfg, "selenium_user_selector", "") or "").strip()
        user_val = (getattr(cfg, "selenium_user_value", "") or
                    getattr(cfg, "username", "") or "")
        pass_sel = (getattr(cfg, "selenium_pass_selector", "") or "").strip()
        pass_val = (getattr(cfg, "selenium_pass_value", "") or
                    getattr(cfg, "password", "") or "")
        if user_sel and user_val:
            fields.append({"name": user_sel, "value": user_val})
        if pass_sel and pass_val:
            fields.append({"name": pass_sel, "value": pass_val})

    cred_fields = [f for f in fields if f["name"] != "submit_button"]
    submit = (getattr(cfg, "probely_form_submit_selector", "") or
              getattr(cfg, "selenium_submit_selector", "") or "").strip()
    if submit:
        fields.append({"name": "submit_button", "value": submit})

    explicit = (mode == "on") or (auth == "form")
    if not cred_fields:
        if explicit:
            log("[snyk-aw] form login requested but no username/password field "
                "pairs were found (set login_data, or the user/password selectors "
                "and values). Skipping form login.")
        return None

    form_url = (getattr(cfg, "login_url", "") or
                getattr(cfg, "selenium_login_url", "") or base_url or "").strip()
    check = (getattr(cfg, "probely_form_login_check_pattern", "") or
             getattr(cfg, "login_success_text", "") or "").strip()
    return (form_url, fields, check[:255])

def _decide_login_method(cfg, url: str, log
                         ) -> tuple[Optional[str], Optional[tuple], Optional[tuple]]:
    """Pick exactly one crawler auth method (form/sequence are mutually exclusive in Probely) by precedence: sequence…"""
    seq = _resolve_login_sequence(cfg, log)
    form = _resolve_form_login(cfg, url, log)
    seq_from_file = bool((getattr(cfg, "probely_login_sequence_path", "") or "").strip())
    form_mode = (getattr(cfg, "probely_form_login", "auto") or "auto").strip().lower()
    auth = (getattr(cfg, "auth_type", "none") or "none").strip().lower()
    form_forced = form is not None and (form_mode == "on" or auth == "form")

    if seq and seq_from_file:
        return "sequence", seq, form
    if form_forced:
        return "form", seq, form
    if seq:
        return "sequence", seq, form
    if form:
        return "form", seq, form
    return None, seq, form

_LOGOUT_PATH_RE = re.compile(
    r"(?i)(log-?out|log-?off|sign-?out|signout|cerrar[-_]?sesi|salir|"
    r"desconect|deslog|/exit\b|/api/logout)")

def _abs_url(u: str, base_url: str) -> str:
    u = (u or "").strip()
    if not u:
        return ""
    if not u.startswith(("http://", "https://")):
        u = urljoin(base_url.rstrip("/") + "/", u.lstrip("/"))
    return u

def _would_exclude_whole_site(u: str, base_url: str) -> bool:
    """True if blacklisting u would knock out the start URL / the whole site."""
    try:
        p, b = urlparse(u), urlparse(base_url)
    except Exception:
        return False
    path = (p.path or "").rstrip("/")
    base_path = (b.path or "").rstrip("/")
    if path in ("", "/"):
        return True
    if p.netloc == b.netloc and path == base_path:
        return True
    return False

def logout_macro_to_blacklist(cfg, base_url: str, log) -> list[str]:
    """Derive SAFE absolute, wildcarded blacklist URLs from the recorded logout macro, the logout regex, and any expl…"""
    out: list[str] = []
    coincided = False

    def _add(u: str, *, require_logout_pathy: bool):
        nonlocal coincided
        u = _abs_url(u, base_url)
        if not u:
            return
        if _would_exclude_whole_site(u, base_url):
            coincided = True
            return
        if require_logout_pathy and not _LOGOUT_PATH_RE.search(u):
            return
        if "*" not in u:
            u = u.rstrip("/") + "*"
        if u not in out:
            out.append(u)

    macro_raw = getattr(cfg, "selenium_logout_macro", "") or ""
    if macro_raw:
        try:
            macro = json.loads(macro_raw) if isinstance(macro_raw, str) else macro_raw
        except Exception:
            macro = []
        for ev in (macro or []):
            if isinstance(ev, dict) and ev.get("url"):
                _add(ev["url"], require_logout_pathy=True)

    for chunk in _re_split(getattr(cfg, "probely_blacklist", "") or ""):
        _add(chunk, require_logout_pathy=False)

    if getattr(cfg, "logout_url_re", "") or getattr(cfg, "exclude_re", ""):
        b = urlparse(base_url)
        root = f"{b.scheme or 'https'}://{b.netloc}"
        for path in ("/logout", "/logoff", "/log-off", "/signout", "/sign-out",
                     "/cerrar-sesion", "/cerrarsesion", "/cerrar_sesion",
                     "/salir", "/desconectar", "/desconexion", "/api/logout"):
            _add(root + path, require_logout_pathy=False)

    if coincided:
        log("[snyk-aw] WARNING: a logout URL resolves to the site root / the "
            "target start URL, so it cannot be blacklisted without excluding the "
            "whole site. Skipped it. Relying on the login sequence to re-login if "
            "the session drops; for robustness configure a Probely logout detector "
            "(session-check pattern) instead of URL exclusion.")
    if out:
        log(f"[snyk-aw] logout/exclusion blacklist ({len(out)} URL globs): "
            + ", ".join(out[:8]) + (" …" if len(out) > 8 else ""))
    elif not coincided:
        log("[snyk-aw] no logout URLs to blacklist.")
    return out

def _re_split(s: str) -> list[str]:
    return [p.strip() for p in re.split(r"[\n,]+", s) if p.strip()]

_DEFAULT_LOGOUT_MARKERS = (
    "Iniciar sesión", "Iniciar sesion", "Su sesión ha expirado",
    "Su sesión ha caducado", "Sesión expirada", "Sesión caducada",
    "Vuelva a iniciar sesión", "Usuario y contraseña", "Acceso denegado",
    "Sign in", "Log in", "Your session has expired",
    "Session expired", "Please log in again",
)

def resolve_logout_markers(cfg) -> list[str]:
    custom = _re_split(getattr(cfg, "probely_logout_markers", "") or "")
    return custom or list(_DEFAULT_LOGOUT_MARKERS)

_TERMINAL = {"completed", "completed_with_errors", "under_review",
             "canceled", "cancelled", "failed", "over"}

def _ensure_target(client: _Probely, cfg, *, url: str, is_api: bool,
                   log) -> dict:
    """Reuse or create a Probely target. Aborts (raises) if it can't be verified."""
    name = f"{'API' if is_api else 'Web'}: {urlparse(url).hostname or url}"

    tid = getattr(cfg, "probely_target_id", "") or ""
    target = None
    if tid:
        target = client._get(f"/targets/{tid}")
        log(f"[snyk-aw] reusing configured target {tid}")
    if target is None and getattr(cfg, "probely_reuse_by_url", True):
        target = client.find_target_by_url(url, "api" if is_api else None)
        if target:
            log(f"[snyk-aw] reusing existing target {target.get('id')} (matched URL)")
    if target is None:

        orch = make_orchestrator(client, cfg, log)
        _ttype = "api" if is_api else "single"
        import contextlib as _contextlib
        _lock_cm = orch.account_lock() if orch else _contextlib.nullcontext()
        with _lock_cm:
            if orch is not None:
                try:
                    orch.ensure_capacity(
                        url, _ttype,
                        protect_ids=(getattr(cfg, "probely_target_id", "") or "",))
                except SlotUnavailable as e:
                    raise ProbelyError(str(e))
            if is_api:
                schema_src = (getattr(cfg, "spec_source", "") or "").strip()
                forced = (getattr(cfg, "probely_api_schema_type", "") or "").strip().lower()
                if forced in ("openapi", "postman", "graphql"):
                    schema_type = forced
                elif _looks_postman(schema_src):
                    schema_type = "postman"
                elif _looks_graphql(schema_src):
                    schema_type = "graphql"
                else:
                    schema_type = "openapi"
                schema_url = schema_src if schema_src.startswith(("http://", "https://")) else ""
                target = client.create_api_target(name, url, schema_type, schema_url)
                tid = target["id"]
                log(f"[snyk-aw] created API target {tid} (schema_type={schema_type})")
                if not schema_url and schema_src:
                    client.upload_api_schema_file(tid, schema_src)
                    log(f"[snyk-aw] uploaded API schema file: {Path(schema_src).name}")
            else:
                target = client.create_web_target(name, url)
                log(f"[snyk-aw] created web target {target['id']}")
            if orch is not None:
                try:
                    orch.register_created(target, url=url, ttype=_ttype)
                except Exception as e:
                    log(f"[snyk-aw] could not record target in pool ledger: {e!r}")

    site = target.get("site") or {}
    if not site.get("verified", False):
        token = site.get("verification_token", "")
        if getattr(cfg, "probely_require_verified", False):
            raise ProbelyError(
                "Target domain is NOT verified in Snyk API & Web. Probely will not "
                "scan it (unverified scans are treated as attacks). Verify the domain "
                f"first (verification token: {token}).")
        log("[snyk-aw] WARNING: target domain is NOT verified. Probely restricts "
            "unverified targets to LIGHTNING scans only — forcing the lightning "
            f"profile. Verify the domain to unlock full scans (token: {token}).")
        target["_force_lightning"] = True

    if not is_api and getattr(cfg, "probely_agent_warn", True):
        try:
            if _host_looks_non_public(url):
                log("[snyk-aw] WARNING: the target host looks non-public "
                    "(private/loopback/unresolvable). Probely's cloud scanner cannot "
                    "reach it without a Scanning Agent deployed in your network. "
                    "If you already configured an agent on this target, ignore this.")
        except Exception:
            pass

    method, seq, form = _decide_login_method(cfg, url, log)
    has_login = False
    if method == "sequence" and seq:
        name_, content_ = seq
        try:
            client.add_login_sequence(target["id"], name_, content_)
            client.enable_sequence_auth(target["id"])
            has_login = True
            log("[snyk-aw] login sequence attached and authentication enabled.")
        except ProbelyError as e:
            log(f"[snyk-aw] could not attach login sequence: {e} "
                "(scan will run unauthenticated).")
    elif method == "form" and form:
        form_url, fields, check = form
        try:
            client.configure_form_login(target["id"], form_login_url=form_url,
                                        fields=fields, check_pattern=check)
            has_login = True
            n_creds = len([f for f in fields if f["name"] != "submit_button"])
            log(f"[snyk-aw] form login configured at {form_url or '(target URL)'} "
                f"({n_creds} field(s); check_pattern="
                f"{'set' if check else 'none'}). Probely re-fills this form to "
                "authenticate the scan.")
        except ProbelyError as e:
            log(f"[snyk-aw] could not configure form login: {e} "
                "(scan will run unauthenticated).")

    if is_api and not has_login and getattr(cfg, "probely_api_login_url", "").strip():
        try:
            client.configure_api_login(
                target["id"],
                login_url=cfg.probely_api_login_url.strip(),
                payload=getattr(cfg, "probely_api_login_payload", "") or "",
                media_type=getattr(cfg, "probely_api_login_media_type", "application/json"),
                token_field=getattr(cfg, "probely_api_login_token_field", "") or "",
                token_param=getattr(cfg, "probely_api_login_token_param", "Authorization"),
                token_prefix=getattr(cfg, "probely_api_login_token_prefix", "") or "",
                place=getattr(cfg, "probely_api_login_place", "header"))
            has_login = True
            log("[snyk-aw] API login endpoint configured (token retrieval). "
                "Best-effort: if the login self-test fails, validate the api_login_* "
                "field names against your account's API reference.")
        except ProbelyError as e:
            log(f"[snyk-aw] could not configure API login endpoint: {e} "
                "(scan will run with whatever static auth is set).")

    if not has_login and getattr(cfg, "probely_protect_session", True):
        if _protect_session_credentials(client, cfg, target, log):
            has_login = True

    if getattr(cfg, "probely_2fa_enabled", False) and getattr(cfg, "probely_otp_secret", ""):
        if not has_login:
            log("[snyk-aw] 2FA requested but no login method is configured — "
                "skipped (2FA layers on top of form/sequence login).")
        else:
            try:
                client.configure_2fa(
                    target["id"], secret=cfg.probely_otp_secret,
                    otp_field=getattr(cfg, "probely_otp_field", "") or "",
                    otp_submit=getattr(cfg, "probely_otp_submit", "") or "",
                    algorithm=getattr(cfg, "probely_otp_algorithm", "SHA1") or "SHA1",
                    digits=int(getattr(cfg, "probely_otp_digits", 6) or 6))
                log("[snyk-aw] 2FA (TOTP) configured on the target.")
            except ProbelyError as e:
                log(f"[snyk-aw] could not configure 2FA: {e}")

    if not is_api:
        for host_url in _re_split(getattr(cfg, "probely_extra_hosts", "") or ""):
            hu = _abs_url(host_url, url)
            try:
                client.add_extra_host(target["id"], hu)
                log(f"[snyk-aw] extra host added to scope: {hu}")
            except ProbelyError as e:
                log(f"[snyk-aw] could not add extra host {hu}: {e}")

    if is_api and has_login and getattr(cfg, "probely_check_login", True):
        try:
            client.check_api_login(target["id"])
            log("[snyk-aw] API login configuration test requested.")
        except ProbelyError as e:
            log(f"[snyk-aw] API login test not available/failed: {e}")

    if not is_api:
        blacklist = logout_macro_to_blacklist(cfg, url, log)
        if blacklist:
            existing = (target.get("site") or {}).get("blacklist") or []
            merged = list(dict.fromkeys(list(existing) + blacklist))
            try:
                client.set_blacklist(target["id"], merged)
                log(f"[snyk-aw] blacklist set ({len(merged)} entries).")
            except ProbelyError as e:
                log(f"[snyk-aw] could not set blacklist: {e}")

        if getattr(cfg, "probely_logout_detection", True):
            if not has_login:
                log("[snyk-aw] logout detection requested but no login is "
                    "configured — skipped (nothing to re-login with).")
            else:
                _setup_logout_detection(client, cfg, target, url, log)
    return target

def _setup_logout_detection(client: _Probely, cfg, target: dict, url: str,
                            log) -> None:
    tid = target["id"]
    check_url = (getattr(cfg, "probely_check_session_url", "") or "").strip() or url
    condition = (getattr(cfg, "probely_logout_condition", "any") or "any").strip().lower()
    if condition not in ("any", "all"):
        condition = "any"

    detectors: list[tuple[str, str]] = [("text", mk) for mk in resolve_logout_markers(cfg)]
    if getattr(cfg, "probely_logout_url_detector", True):
        login_url = (getattr(cfg, "probely_login_url", "") or
                     getattr(cfg, "selenium_login_url", "") or
                     getattr(cfg, "login_url", "") or "").strip()
        if login_url:
            detectors.append(("url", login_url))
    if getattr(cfg, "probely_logout_code_detector", True):
        detectors.append(("code", "401"))
        detectors.append(("code", "403"))
    sel = (getattr(cfg, "probely_logout_selector", "") or "").strip()
    if sel:
        detectors.append(("sel", sel))
    for mk in _re_split(getattr(cfg, "probely_logout_body_markers", "") or ""):
        detectors.append(("body", mk))
    for mk in _re_split(getattr(cfg, "probely_logout_header_markers", "") or ""):
        detectors.append(("header", mk))

    try:
        existing = {(d.get("type"), d.get("value")) for d in
                    (client.list_logout_detectors(tid).get("results") or [])}
    except ProbelyError:
        existing = set()
    _CREATABLE_DET = {"text", "url", "sel"}
    by_type: dict[str, int] = {}
    for typ, val in detectors:
        if (typ, val) in existing:
            continue
        try:
            if typ in _CREATABLE_DET:
                client.create_logout_detector(tid, val, type_=typ)
            else:
                created = client.create_logout_detector(tid, val, type_="text")
                det_id = created.get("id")
                if det_id:
                    client.update_logout_detector(tid, det_id, typ, val)
                else:
                    raise ProbelyError("create returned no detector id")
            by_type[typ] = by_type.get(typ, 0) + 1
        except ProbelyError as e:
            log(f"[snyk-aw] could not add {typ} logout detector {val!r}: {e}")
    try:
        client.enable_logout_detection(tid, check_url, condition)
        summary = ", ".join(f"{n} {t}" for t, n in by_type.items()) or "0 new"
        log(f"[snyk-aw] logout detection ON (condition={condition}; added {summary}; "
            f"check_session_url={check_url}). If logged out, it re-logins automatically "
            "instead of scanning as anonymous.")
    except ProbelyError as e:
        log(f"[snyk-aw] could not enable logout detection: {e} "
            "(needs a login method + check_session_url defined).")

def _protect_session_credentials(client: _Probely, cfg, target: dict, log) -> bool:
    """Register the user's static auth credential (cookie/header/bearer/basic) on the Probely target with authenticat…"""
    auth = (getattr(cfg, "auth_type", "none") or "none").lower()
    new_cookies: list[dict] = []
    new_headers: list[dict] = []
    if auth == "basic" and getattr(cfg, "username", ""):
        try:
            client.set_basic_auth(target["id"], username=cfg.username,
                                  password=getattr(cfg, "password", "") or "")
            log("[snyk-aw] native HTTP Basic authentication configured on the target.")
            return True
        except ProbelyError as e:
            log(f"[snyk-aw] could not set native basic auth ({e}); "
                "falling back to an Authorization header.")
            new_headers.append({
                "name": "Authorization",
                "value": "Basic " + base64.b64encode(
                    f"{cfg.username}:{getattr(cfg, 'password', '')}".encode()).decode(),
                "authentication": True, "allow_testing": False})
    if auth == "cookie" and getattr(cfg, "cookie", ""):
        for part in str(cfg.cookie).split(";"):
            if "=" in part:
                n, v = part.split("=", 1)
                if n.strip():
                    new_cookies.append({"name": n.strip(), "value": v.strip(),
                                        "authentication": True, "allow_testing": False})
    elif auth == "header" and getattr(cfg, "header_name", ""):
        new_headers.append({"name": cfg.header_name.strip(),
                            "value": getattr(cfg, "header_value", "") or "",
                            "authentication": True, "allow_testing": False})
    elif auth == "bearer" and getattr(cfg, "token", ""):
        new_headers.append({"name": "Authorization", "value": f"Bearer {cfg.token}",
                            "authentication": True, "allow_testing": False})
    if not new_cookies and not new_headers:
        return False

    site = target.get("site") or {}

    def _merge(existing, new):
        names = {e.get("name") for e in new}
        kept = [e for e in (existing or []) if e.get("name") not in names]
        return kept + new

    cookies = _merge(site.get("cookies"), new_cookies) if new_cookies else None
    headers = _merge(site.get("headers"), new_headers) if new_headers else None
    try:
        client.set_auth_credentials(target["id"], cookies=cookies, headers=headers)
        what = []
        if new_cookies:
            what.append(f"{len(new_cookies)} cookie(s)")
        if new_headers:
            what.append(f"{len(new_headers)} header(s)")
        log(f"[snyk-aw] static auth registered ({', '.join(what)}) as "
            "authentication + non-testable — the scanner won't fuzz the session "
            "token, so it can't log itself out that way.")
        return True
    except ProbelyError as e:
        log(f"[snyk-aw] could not register static auth credentials: {e}")
        return False

def _looks_postman(src: str) -> bool:
    if not src:
        return False
    if src.startswith(("http://", "https://")):
        return False
    try:
        data = json.loads(Path(src).read_text(encoding="utf-8", errors="replace"))
        return isinstance(data, dict) and "item" in data and "paths" not in data
    except Exception:
        return False

def _looks_graphql(src: str) -> bool:
    """Heuristic: a GraphQL SDL file (.graphql/.gql) or a saved introspection result."""
    if not src:
        return False
    low = src.lower()
    if low.endswith((".graphql", ".gql", ".graphqls")):
        return True
    if src.startswith(("http://", "https://")):
        return False
    try:
        txt = Path(src).read_text(encoding="utf-8", errors="replace")
        tl = txt.lower()
        if "__schema" in txt and '"data"' in tl:
            return True
        return ("type query" in tl) or ("schema {" in tl and "query:" in tl)
    except Exception:
        return False

def _profile_for(cfg) -> str:
    """Pick the Probely scan profile."""
    explicit = (getattr(cfg, "probely_scan_profile", "") or "").strip()
    if explicit:
        return explicit
    legacy = (getattr(cfg, "profile", "") or "").lower()
    if legacy == "active":
        return "full"
    return ""

def _drive_scan(client: _Probely, cfg, target: dict, *, out_name: str,
                default_category: str, log, cancel: threading.Event,
                progress: Optional[Callable[[int, int], None]],
                out_dir: Optional[Path] = None) -> dict:
    tid = target["id"]
    profile = _profile_for(cfg)
    if target.get("_force_lightning"):
        if profile and profile != "lightning":
            log(f"[snyk-aw] overriding profile '{profile}' → 'lightning' "
                "(target domain not verified).")
        profile = "lightning"
    reduced = []
    for u in _re_split(getattr(cfg, "probely_reduced_scopes", "") or ""):
        reduced.append({"url": u, "enabled": True})
    ignore_blackout = bool(getattr(cfg, "probely_ignore_blackout", False))
    scan = client.scan_now(tid, scan_profile=profile,
                           reduced_scopes=reduced or None,
                           ignore_blackout=ignore_blackout)
    sid = scan["id"]
    log(f"[snyk-aw] scan {sid} queued on target {tid} "
        f"(profile={profile or 'target-default'}"
        f"{', reduced scope' if reduced else ''}"
        f"{', ignore-blackout' if ignore_blackout else ''})")

    poll = max(5.0, float(getattr(cfg, "probely_poll_interval", 15.0) or 15.0))
    deadline = time.monotonic() + float(getattr(cfg, "probely_max_wait_minutes",
                                                180.0) or 180.0) * 60.0
    status = scan.get("status", "queued")
    cancelled = False

    def _emit_progress(sc: dict):
        if progress is None:
            return
        try:
            scanner = sc.get("scanner") or {}
            st = scanner.get("status") or []
            if isinstance(st, list) and len(st) >= 2 and st[1]:
                done, total = int(st[0]), int(st[1])
                progress(min(done, total), max(total, 1))
            else:
                phase = {"queued": 5, "started": 50, "finishing_up": 90,
                         "completed": 100, "completed_with_errors": 100,
                         "under_review": 100}.get(
                    sc.get("status", ""), 25)
                progress(phase, 100)
        except Exception:
            pass

    while True:
        if cancel.is_set() and not cancelled:
            log("[snyk-aw] cancel requested → cancelling cloud scan")
            try:
                client.cancel_scan(tid, sid)
            except ProbelyError as e:
                log(f"[snyk-aw] cancel call failed: {e}")
            cancelled = True
        if time.monotonic() > deadline:
            log("[snyk-aw] max wait exceeded → cancelling cloud scan")
            try:
                client.cancel_scan(tid, sid)
            except ProbelyError:
                pass
            cancelled = True
            break
        time.sleep(poll)
        try:
            sc = client.get_scan(tid, sid)
        except ProbelyError as e:
            log(f"[snyk-aw] poll error: {e}")
            continue
        status = sc.get("status", status)
        _emit_progress(sc)
        log(f"[snyk-aw] scan {sid} status={status} "
            f"(L{sc.get('lows', '?')}/M{sc.get('mediums', '?')}/H{sc.get('highs', '?')})")
        if status in _TERMINAL:
            break

    findings: list[dict] = []
    try:
        for f in client.iter_findings(tid, state="notfixed"):
            findings.append(_normalise_finding(f, default_category))
    except ProbelyError as e:
        log(f"[snyk-aw] could not list findings: {e}")

    _SVR = {"critical": 4, "high": 3, "medium": 2, "low": 1}
    findings.sort(key=lambda x: -_SVR.get(x["severity"], 0))

    report_path = ""
    template = (getattr(cfg, "probely_compliance_report", "") or "").strip()
    if template and out_dir is not None:
        try:
            pdf = client.download_report(tid, sid, template)
            rp = out_dir / f"probely_report_{template}.pdf"
            rp.write_bytes(pdf)
            report_path = str(rp)
            log(f"[snyk-aw] compliance report ({template}) saved → {rp}")
        except ProbelyError as e:
            log(f"[snyk-aw] could not download {template} report: {e}")

    return {
        "status": status,
        "cancelled": cancelled or cancel.is_set(),
        "findings": findings,
        "target_id": tid,
        "scan_id": sid,
        "scan_url": f"{_app_base(cfg)}/targets/{tid}/scans/{sid}",
        "report_path": report_path,
    }

def _run_probely_scan(cfg, out_dir: Path, log: Callable[[str], None],
                      cancel: threading.Event,
                      progress: Optional[Callable[[int, int], None]], *,
                      out_name: str, is_api: bool, category: str,
                      error_category: str, target_url: str,
                      base_summary: dict, skip: bool = False,
                      skip_log: Optional[str] = None) -> tuple[dict, Path]:
    """Shared skeleton for run_api/run_dast: authenticate, ensure the Probely target, drive the scan, and write <out_…"""
    out_path = out_dir / out_name

    def _write(s: dict) -> Path:
        out_path.write_text(json.dumps(s, indent=2), encoding="utf-8")
        return out_path

    if skip:
        if skip_log:
            log(skip_log)
        return base_summary, _write(base_summary)

    try:
        client = _Probely(cfg.probely_token, _resolve_api_base(cfg), log,
                          getattr(cfg, "probely_auth_scheme", "JWT"))
        who = client.whoami()
        log(f"[snyk-aw] authenticated as {who.get('name') or who.get('email') or '?'}")
        target = _ensure_target(client, cfg, url=target_url, is_api=is_api, log=log)
        result = _drive_scan(client, cfg, target, out_name=out_name,
                             default_category=category, log=log, cancel=cancel,
                             progress=progress, out_dir=out_dir)
    except ProbelyError as e:
        log(f"[snyk-aw] {category.upper()} scan failed: {e}")
        base_summary["findings"] = [{
            "severity": "high", "title": "Snyk API & Web scan failed",
            "url": target_url, "evidence": str(e), "cwe": "", "category": error_category}]
        exc_summary = dict(base_summary)
        if getattr(e, "is_auth", False):
            exc_summary["auth_error"] = True
        return exc_summary, _write(exc_summary)

    summary = dict(base_summary)
    summary.update({
        "cancelled": result["cancelled"], "findings": result["findings"],
        "target_id": result["target_id"], "scan_id": result["scan_id"],
        "scan_url": result["scan_url"], "engine": "snyk-api-web",
        "report_path": result.get("report_path", ""),
    })
    log(f"[snyk-aw] {category.upper()} scan complete: {len(summary['findings'])} findings "
        f"({result['status']}) → {out_path}")
    return summary, _write(summary)

def run_api(cfg: ApiConfig, out_dir: Path,
            log: Callable[[str], None],
            cancel: Optional[threading.Event] = None,
            progress: Optional[Callable[[int, int], None]] = None) -> tuple[dict, Path]:
    cancel = cancel or threading.Event()

    spec_src = (getattr(cfg, "spec_source", "") or "").strip()
    base_url = (getattr(cfg, "base_url", "") or "").strip()
    api_url = base_url
    if not api_url and spec_src:
        try:
            opener, _, hdrs = _make_opener(cfg)
            spec = _api_load_spec(opener, hdrs, cfg, log)
            if isinstance(spec, dict):
                api_url = _api_base_url(spec, cfg, spec_src)
        except Exception as e:
            log(f"[snyk-aw] could not derive API base URL from spec: {e!r}")

    base_summary = {
        "target": api_url, "spec_source": spec_src, "profile": cfg.profile,
        "endpoints_total": 0, "endpoints_tested": 0,
        "cancelled": cancel.is_set(), "findings": [],
    }

    skip = not spec_src and not base_url
    skip_log = "[snyk-aw] no API spec/URL configured — skipping API scan" if skip else None
    if not skip and not api_url:
        base_summary["findings"] = [{
            "severity": "high", "title": "No API base URL",
            "url": spec_src, "evidence": "Could not determine the API server URL "
            "to register as a Probely target.", "cwe": "", "category": "spec"}]
        skip = True

    return _run_probely_scan(cfg, out_dir, log, cancel, progress,
        out_name="api.json", is_api=True, category="api", error_category="spec",
        target_url=api_url, base_summary=base_summary, skip=skip, skip_log=skip_log)

def run_dast(cfg: DastConfig, out_dir: Path,
             log: Callable[[str], None],
             cancel: Optional[threading.Event] = None,
             progress: Optional[Callable[[int, int], None]] = None) -> tuple[dict, Path]:
    cancel = cancel or threading.Event()

    url = (getattr(cfg, "url", "") or "").strip()
    if url and not url.startswith(("http://", "https://")):
        url = "https://" + url

    base_summary = {
        "target": url, "final_url": url, "profile": cfg.profile,
        "auth_type": cfg.auth_type, "pages_visited": 0, "forms_discovered": 0,
        "relogins": 0, "cancelled": cancel.is_set(), "findings": [],
    }

    skip = not url or url == "https://"
    skip_log = "[snyk-aw] no DAST URL configured — skipping DAST scan" if skip else None

    return _run_probely_scan(cfg, out_dir, log, cancel, progress,
        out_name="dast.json", is_api=False, category="dast", error_category="dast",
        target_url=url, base_summary=base_summary, skip=skip, skip_log=skip_log)

def check_snyk_api_web(cfg, log: Callable[[str], None] = lambda *_: None) -> tuple[bool, str]:
    """Return (ok, message)."""
    token = getattr(cfg, "probely_token", "") or ""
    if not token:
        return False, "No Snyk session to reuse — sign in to Snyk (SSO) first."
    try:
        who = _Probely(token, _resolve_api_base(cfg), log,
                       getattr(cfg, "probely_auth_scheme", "JWT")).whoami()
        return True, f"Authenticated as {who.get('name') or who.get('email') or '?'}"
    except ProbelyError as e:
        return False, str(e)

def fetch_scan_profiles(cfg, target_type: str = "web",
                        log: Callable[[str], None] = lambda *_: None
                        ) -> list[tuple[str, str]]:
    """Return [(id, name), …] of the scan profiles available for ``target_type`` ("web" or "api")."""
    token = getattr(cfg, "probely_token", "") or ""
    if not token:
        return []
    try:
        client = _Probely(token, _resolve_api_base(cfg), log,
                          getattr(cfg, "probely_auth_scheme", "JWT"))
        out: list[tuple[str, str]] = []
        for p in client.list_scan_profiles(target_type):
            pid = (p.get("id") or "").strip()
            name = (p.get("name") or pid).strip()
            if pid:
                out.append((pid, name))
        return out
    except ProbelyError as e:
        log(f"[snyk-aw] could not list scan profiles: {e}")
        return []

TERMINAL_STATES = {
    "completed", "completed_with_errors", "failed", "canceled", "cancelled",
}

BUSY_STATES = {
    "queued", "started", "resuming", "pausing", "finishing_up", "under_review",
    "canceling", "cancelling", "paused", "over",
}

_DEFAULT_POOL_SIZE = 5
_DEFAULT_COOLDOWN_MIN = 60.0
_LEDGER_DIRNAME = ".orchestrator"
_LEDGER_FILENAME = "pool_ledger.json"

_ACCOUNT_LOCKS: dict[str, threading.RLock] = {}
_ACCOUNT_LOCKS_META = threading.Lock()

def _account_lock(key: str) -> threading.RLock:
    with _ACCOUNT_LOCKS_META:
        lk = _ACCOUNT_LOCKS.get(key)
        if lk is None:
            lk = threading.RLock()
            _ACCOUNT_LOCKS[key] = lk
        return lk

def _now_utc() -> datetime:
    return datetime.now(timezone.utc)

def _parse_iso(value) -> Optional[datetime]:
    """Tolerant ISO-8601 parser (handles a trailing 'Z' and fractional seconds on Python versions where fromisoformat…"""
    if not value or not isinstance(value, str):
        return None
    s = value.strip()
    if not s:
        return None
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(s)
    except ValueError:

        try:
            head, _, tail = s.partition(".")
            digits = ""
            rest = ""
            for ch in tail:
                if ch.isdigit() and len(digits) < 6:
                    digits += ch
                elif ch.isdigit():
                    continue
                else:
                    rest += ch
            dt = datetime.fromisoformat(f"{head}.{digits or '0'}{rest}")
        except Exception:
            return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)

def _target_changed(target: dict) -> Optional[datetime]:
    """Best-effort read of the API-provided last-change timestamp."""
    if not isinstance(target, dict):
        return None
    site = target.get("site") or {}
    for src in (target.get("changed"), site.get("changed"),
                target.get("last_scan", {}).get("started") if isinstance(target.get("last_scan"), dict) else None):
        dt = _parse_iso(src)
        if dt:
            return dt
    return None

def _target_url(target: dict) -> str:
    site = target.get("site") or {}
    return (site.get("url") or target.get("url") or "").rstrip("/")

def _target_type(target: dict) -> str:
    return (target.get("type") or "single") or "single"

class PoolLedger:
    """Tiny JSON ledger of {target_id: {created_at, source, url, type}}."""

    def __init__(self, root):
        self._dir = Path(root) / _LEDGER_DIRNAME
        self._path = self._dir / _LEDGER_FILENAME
        self._lock = threading.Lock()

    def _read(self) -> dict:
        try:
            return json.loads(self._path.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def _write(self, data: dict) -> None:
        try:
            self._dir.mkdir(parents=True, exist_ok=True)
            self._path.write_text(json.dumps(data, indent=2, default=str),
                                  encoding="utf-8")
        except Exception:
            pass

    def get(self, target_id: str) -> Optional[dict]:
        with self._lock:
            return self._read().get(target_id)

    def record_created(self, target_id: str, *, url: str = "", ttype: str = "",
                       when: Optional[datetime] = None) -> None:
        when = when or _now_utc()
        with self._lock:
            data = self._read()
            data[target_id] = {"created_at": when.isoformat(), "source": "created",
                               "url": url, "type": ttype}
            self._write(data)

    def record_first_seen(self, target_id: str, *, url: str = "", ttype: str = "",
                          when: Optional[datetime] = None) -> datetime:
        when = when or _now_utc()
        with self._lock:
            data = self._read()
            existing = data.get(target_id)
            if existing and existing.get("created_at"):
                dt = _parse_iso(existing["created_at"])
                if dt:
                    return dt
            data[target_id] = {"created_at": when.isoformat(), "source": "first_seen",
                               "url": url, "type": ttype}
            self._write(data)
            return when

    def forget(self, target_id: str) -> None:
        with self._lock:
            data = self._read()
            if target_id in data:
                data.pop(target_id, None)
                self._write(data)

    def created_at(self, target_id: str) -> tuple[Optional[datetime], str]:
        rec = self.get(target_id)
        if rec and rec.get("created_at"):
            return _parse_iso(rec["created_at"]), (rec.get("source") or "ledger")
        return None, ""

@dataclass
class SlotInfo:
    target_id: str
    name: str
    url: str
    ttype: str
    scan_states: list[str] = field(default_factory=list)
    free: bool = False
    created_at: Optional[datetime] = None
    age_source: str = ""
    age_minutes: Optional[float] = None
    eligible: bool = False
    reason: str = ""

    @property
    def age_human(self) -> str:
        if self.age_minutes is None:
            return "?"
        m = self.age_minutes
        if m < 1:
            return "<1 min"
        if m < 90:
            return f"{int(round(m))} min"
        return f"{m / 60:.1f} h"

    @property
    def state_human(self) -> str:
        if not self.scan_states:
            return "sin escaneos"
        return ", ".join(self.scan_states[:4]) + (" …" if len(self.scan_states) > 4 else "")

class SlotUnavailable(ProbelyError):
    """Raised when the pool is full and no slot can be recycled right now."""

class Orchestrator:
    def __init__(self, client, ledger: PoolLedger, *,
                 pool_size: int = _DEFAULT_POOL_SIZE,
                 cooldown_minutes: float = _DEFAULT_COOLDOWN_MIN,
                 account_key: str = "",
                 log: Callable[[str], None] = lambda *_: None):
        self.client = client
        self.ledger = ledger
        self.pool_size = max(1, int(pool_size or _DEFAULT_POOL_SIZE))
        self.cooldown = max(0.0, float(cooldown_minutes if cooldown_minutes is not None
                                       else _DEFAULT_COOLDOWN_MIN))
        self._account_key = account_key or getattr(client, "_base", "probely")
        self.log = log

    @contextmanager
    def account_lock(self):
        lk = _account_lock(self._account_key)
        lk.acquire()
        try:
            yield
        finally:
            lk.release()

    def scan_states(self, target_id: str) -> list[str]:
        try:
            scans = self.client.list_scans_for_target(target_id)
        except ProbelyError as e:
            self.log(f"[orchestrator] could not list scans for {target_id}: {e}")

            return ["unknown"]
        states = []
        for s in scans or []:
            st = (s.get("status") or s.get("state") or "").strip().lower()
            states.append(st or "unknown")
        return states

    @staticmethod
    def is_free(states: list[str]) -> bool:
        if not states:
            return True
        return all(st in TERMINAL_STATES for st in states)

    def created_at(self, target: dict) -> tuple[Optional[datetime], str]:
        tid = target.get("id") or ""
        dt, src = self.ledger.created_at(tid)
        if dt:
            return dt, src
        dt = _target_changed(target)
        if dt:
            return dt, "changed"

        seen = self.ledger.record_first_seen(
            tid, url=_target_url(target), ttype=_target_type(target))
        return seen, "first_seen"

    def survey(self) -> list[SlotInfo]:
        targets = self.client.list_targets()
        now = _now_utc()
        out: list[SlotInfo] = []
        for t in targets or []:
            tid = t.get("id") or ""
            site = t.get("site") or {}
            states = self.scan_states(tid)
            free = self.is_free(states)
            created, src = self.created_at(t)
            age_min = ((now - created).total_seconds() / 60.0) if created else None
            if not free:
                eligible, reason = False, "escaneo activo"
            elif age_min is not None and age_min < self.cooldown:
                eligible, reason = False, f"enfriamiento ({self.cooldown - age_min:.0f} min restantes)"
            else:
                eligible, reason = True, "reciclable"
            out.append(SlotInfo(
                target_id=tid, name=(site.get("name") or t.get("name") or tid),
                url=_target_url(t), ttype=_target_type(t), scan_states=states,
                free=free, created_at=created, age_source=src, age_minutes=age_min,
                eligible=eligible, reason=reason))
        return out

    def pick_recyclable(self, survey: list[SlotInfo], *,
                        exclude_url: str = "", protect_ids=()) -> Optional[SlotInfo]:
        prot = {i for i in (protect_ids or ()) if i}
        want = (exclude_url or "").rstrip("/")
        cands = [s for s in survey if s.eligible and s.target_id not in prot]

        preferred = [s for s in cands if s.url != want] or cands
        preferred.sort(key=lambda s: (s.age_minutes if s.age_minutes is not None else 1e9),
                       reverse=True)
        return preferred[0] if preferred else None

    def free_slot(self, slot: SlotInfo) -> None:
        self.log(f"[orchestrator] reciclando slot {slot.target_id} "
                 f"({slot.url or slot.name}; edad={slot.age_human}, fuente={slot.age_source}) "
                 f"→ DELETE")
        self.client.delete_target(slot.target_id)
        self.ledger.forget(slot.target_id)

    def ensure_capacity(self, new_url: str, new_type: str,
                        protect_ids=()) -> Optional[SlotInfo]:
        """Make sure there's room for one more target."""
        prot = {i for i in (protect_ids or ()) if i}
        survey = self.survey()
        if prot:
            for s in survey:
                if s.target_id in prot and s.eligible:
                    s.eligible = False
                    s.reason = "fijado (reuse por ID)"
        live = len(survey)
        self.log(f"[orchestrator] pool: {live}/{self.pool_size} targets vivos "
                 f"({sum(1 for s in survey if s.free)} libres, "
                 f"{sum(1 for s in survey if s.eligible)} reciclables).")
        if live < self.pool_size:
            return None
        slot = self.pick_recyclable(survey, exclude_url=new_url, protect_ids=prot)
        if slot is None:
            raise SlotUnavailable(self._no_slot_message(survey))
        self.free_slot(slot)
        return slot

    def _no_slot_message(self, survey: list[SlotInfo]) -> str:
        busy = [s for s in survey if not s.free]
        cooling = [s for s in survey if s.free and not s.eligible]
        lines = [f"Pool de Probely lleno ({len(survey)}/{self.pool_size}) y ningún "
                 "slot es reciclable ahora mismo:"]
        for s in survey:
            lines.append(f"  • {s.url or s.name}: {s.state_human}; "
                         f"edad={s.age_human}; {s.reason}")
        if cooling and not busy:
            soonest = min((self.cooldown - (s.age_minutes or 0)) for s in cooling)
            lines.append(f"El próximo slot se libera del enfriamiento en ~{soonest:.0f} min. "
                         "Baje el enfriamiento o espere, y reintente.")
        elif busy:
            lines.append("Hay escaneos activos. Espere a que terminen (o cancélelos) "
                         "y reintente.")
        return "\n".join(lines)

    def register_created(self, target: dict, *, url: str = "", ttype: str = "") -> None:
        tid = target.get("id") or ""
        if not tid:
            return
        self.ledger.record_created(
            tid, url=url or _target_url(target), ttype=ttype or _target_type(target))
        self.log(f"[orchestrator] target {tid} registrado en el ledger "
                 f"(created_at=ahora).")

def make_orchestrator(client, cfg, log: Callable[[str], None]) -> Optional[Orchestrator]:
    """Build an Orchestrator from a DastConfig/ApiConfig, or None if disabled."""
    if not getattr(cfg, "probely_orchestrate", True):
        return None
    root = (getattr(cfg, "probely_ledger_path", "") or ".").strip() or "."
    ledger = PoolLedger(root)
    return Orchestrator(
        client, ledger,
        pool_size=int(getattr(cfg, "probely_pool_size", _DEFAULT_POOL_SIZE) or _DEFAULT_POOL_SIZE),
        cooldown_minutes=float(getattr(cfg, "probely_slot_cooldown_minutes", _DEFAULT_COOLDOWN_MIN)
                               or _DEFAULT_COOLDOWN_MIN),
        account_key=getattr(client, "_base", ""),
        log=log)

class _ScanTabMixin:
    def _build_tab_scan(self, parent):

        pad = tk.Frame(parent, bg=T["bg"], padx=4, pady=3)
        pad.pack(fill="both", expand=True)

        self._auth_banner = tk.Frame(pad, bg=T["bg"], highlightthickness=1,
                                     highlightbackground=T["err"])
        auth_inner = tk.Frame(self._auth_banner, bg=T["bg"], padx=4, pady=2)
        auth_inner.pack(fill="x")
        tk.Label(auth_inner, text="🔒", font=(_FUI, 10), bg=T["bg"], fg=T["err"]).pack(side="left")
        self._auth_banner_lbl = tk.Label(auth_inner,
            text="Snyk no conectado — haga clic en el icono de llave",
            font=(_FUI, 10, "bold"), bg=T["bg"], fg=T["err"], anchor="w")
        self._auth_banner_lbl.pack(side="left", padx=(2, 0), fill="x", expand=True)
        self._btn(auth_inner, "🔑 Iniciar sesión →", self._show_auth_status_popup, kind="accent").pack(side="right")
        self._auth_banner_visible = False

        self._probely_banner = tk.Frame(pad, bg=T["bg"], highlightthickness=1,
                                        highlightbackground=T["err"])
        prob_inner = tk.Frame(self._probely_banner, bg=T["bg"], padx=4, pady=2)
        prob_inner.pack(fill="x")
        tk.Label(prob_inner, text="🌐", font=(_FUI, 10), bg=T["bg"], fg=T["err"]).pack(side="left")
        self._probely_banner_lbl = tk.Label(prob_inner,
            text="Probely no conectado — se requiere para DAST / API",
            font=(_FUI, 10, "bold"), bg=T["bg"], fg=T["err"], anchor="w")
        self._probely_banner_lbl.pack(side="left", padx=(2, 0), fill="x", expand=True)
        self._btn(prob_inner, "🌐 Conectar Probely →", self._show_probely_key_popup, kind="accent").pack(side="right")
        self._probely_banner_visible = False

        cards_row = tk.Frame(pad, bg=T["bg"])
        self._cards_row = cards_row

        pipe_outer = tk.Frame(cards_row, bg=T["panel_bg"],
                              highlightthickness=1, highlightbackground=T["accent"])
        pipe_outer.pack(side="left", fill="both", expand=True)

        self._pipe_progress_pct = 0.0
        self._pipe_stage_states: dict[str, str] = {}

        pipe = tk.Frame(pipe_outer, bg=T["panel_bg"], padx=2, pady=2)
        pipe.pack(fill="both", expand=True)

        _STAGES = [
            ("sca",     "1", "Dependencias (SCA)"),
            ("code",    "2", "Código (SAST)"),
            ("secrets", "3", "Secretos"),
            ("dast",    "4", "Web (DAST)"),
            ("api",     "5", "API"),
        ]
        _COLS = 3

        for _col in range(_COLS):
            pipe.columnconfigure(_col, weight=1, uniform="sc")
        for _row in range(2):
            pipe.rowconfigure(_row, weight=1, uniform="sr")

        def _make_stage_card(key, num, name, grid_row, col):

            shadow_wrap = self._shadow_wrap(pipe, visible=False)
            shadow_wrap.grid(row=grid_row, column=col, padx=1, pady=1, sticky="nsew")
            cell = tk.Frame(shadow_wrap, bg=T["surface2"], highlightthickness=1, highlightbackground=_PIPELINE_CARD_OUTLINE, cursor="hand2")
            cell.pack(fill="both", expand=True, padx=(0, _CARD_SHADOW_OFFSET), pady=(0, _CARD_SHADOW_OFFSET))
            top = tk.Frame(cell, bg=T["surface2"], padx=2, pady=2); top.pack(fill="x")
            switch = ToggleSwitch(top, variable=self._scan_vars[key])
            switch.pack(side="left")
            name_lbl = tk.Label(top, text=name, font=(_FUI_TITLE, 13, "bold"), bg=T["surface2"], fg=T["card_fg"],
                                anchor="w", justify="left")
            name_lbl.pack(side="left", padx=(2, 0), fill="x", expand=True)

            _BAR_H = 8
            bar_canvas = tk.Canvas(cell, height=_BAR_H, highlightthickness=0, bd=0,
                                   bg=T["surface2"])
            bar_canvas.pack(fill="x", padx=2, pady=(0, 2))

            if not hasattr(self, "_stage_bar_update"):
                self._stage_bar_update: dict[str, object] = {}
            self._stage_bar_update[key] = _make_progress_strip(bar_canvas, height=_BAR_H)

            def _apply_state(active):

                cell.configure(bg=T["surface2"], highlightbackground=_PIPELINE_CARD_OUTLINE, highlightthickness=1)
                top.configure(bg=T["surface2"])
                name_lbl.configure(bg=T["surface2"], fg=T["card_fg"])
                bar_canvas.configure(bg=T["surface2"])
                bar_canvas.itemconfigure("bar_bg", fill=T["border"])

            def _on_toggle_effects():
                v = self._scan_vars[key]
                _apply_state(bool(v.get()))
                self._refresh_scan_btn()
                self._persist_scan_stages()

                if key in ("dast", "api") and v.get()\
                        and getattr(self, "_probely_auth_status", "unauth") != "auth":
                    try:
                        self._refresh_probely_banner()
                        self._show_probely_key_popup()
                    except Exception:
                        pass
            switch._command = _on_toggle_effects

            def _cell_click(_evt=None):

                v = self._scan_vars[key]; v.set(0 if v.get() else 1)
                _on_toggle_effects()

            def _on_enter(e):
                if not self._scan_vars[key].get(): cell.configure(highlightbackground=T["accent"])

            def _on_leave(e):
                if not self._scan_vars[key].get(): cell.configure(highlightbackground=_PIPELINE_CARD_OUTLINE)

            def _press(_evt=None):
                cell.pack_configure(padx=(_CARD_SHADOW_OFFSET, 0), pady=(_CARD_SHADOW_OFFSET, 0))

            def _release(_evt=None):
                cell.pack_configure(padx=(0, _CARD_SHADOW_OFFSET), pady=(0, _CARD_SHADOW_OFFSET))

            for w in (cell, top, name_lbl, bar_canvas):
                w.bind("<Button-1>", _cell_click); w.bind("<Enter>", _on_enter); w.bind("<Leave>", _on_leave)
                w.bind("<ButtonPress-1>", _press, add="+")
                w.bind("<ButtonRelease-1>", _release, add="+")
            self._stage_apply[key] = _apply_state
            _apply_state(bool(self._scan_vars[key].get()))

        for i, (k, n, nm) in enumerate(_STAGES):
            r, c = divmod(i, _COLS)
            _make_stage_card(k, n, nm, r, c)

        def _make_play_card(grid_row, col):
            shadow_wrap = self._shadow_wrap(pipe, visible=False)
            shadow_wrap.grid(row=grid_row, column=col, padx=1, pady=1, sticky="nsew")
            cell = tk.Canvas(shadow_wrap, highlightthickness=1, highlightbackground=_PIPELINE_CARD_OUTLINE,
                             bg=T["surface2"], bd=0, cursor="arrow")
            cell.pack(fill="both", expand=True, padx=(0, _CARD_SHADOW_OFFSET), pady=(0, _CARD_SHADOW_OFFSET))

            cell.create_oval(0, 0, 0, 0, outline=T["border"], width=3,
                             state="hidden", tags="ring_track")
            cell.create_arc(0, 0, 0, 0, start=90, extent=0, outline=_progress_bar_color(),
                            width=3, style="arc", state="hidden", tags="ring_fill")
            cell.create_text(0, 0, text="▶", fill=T["muted"], font=(_FUI, 8, "bold"),
                             anchor="center", tags="arrow")

            cell.create_text(0, 0, text="0%", fill=_progress_bar_color(), font=(_FUI, 8, "bold"),
                             anchor="center", state="hidden", tags="pct_text")
            self._play_ring_pct = 0.0

            def _ring_bbox(w, h):
                d = min(w, h) * 0.75
                cx, cy = w / 2, h / 2
                return (cx - d / 2, cy - d / 2, cx + d / 2, cy + d / 2)

            def _redraw(evt=None):
                w = max(cell.winfo_width(), 1)
                h = max(cell.winfo_height(), 1)
                pt = max(int(min(w, h) * 0.60), 8)

                cell.itemconfigure("arrow", font=(_FUI, pt, "bold"))

                cell.coords("arrow", w / 2, h / 2 - max(2, pt * 0.08))
                bbox = _ring_bbox(w, h)
                cell.coords("ring_track", *bbox)
                cell.coords("ring_fill", *bbox)
                ring_d = bbox[2] - bbox[0]
                pct_pt = max(int(ring_d * 0.30), 7)
                cell.itemconfigure("pct_text", font=(_FUI, pct_pt, "bold"))
                cell.coords("pct_text", w / 2, h / 2)

            cell.bind("<Configure>", _redraw)

            def _on_click(_evt=None):
                if getattr(self, "_play_card_ready", False) and not getattr(self, "_play_card_busy", False):
                    self._start_scan()

            cell.bind("<Button-1>", _on_click)
            self._scan_btn = cell
            self._play_card_ready = False
            self._play_card_busy = False
            return cell

        _play_row, _play_col = divmod(len(_STAGES), _COLS)
        _make_play_card(_play_row, _play_col)

        prereq_outer = tk.Frame(pad, bg=T["panel_bg"],
                                highlightthickness=1, highlightbackground=T["border"])
        # Deliberately NOT packed: this whole PRERREQUISITOS block (auth check row +
        # Verificar/Iniciar sesión/Reiniciar sesión) is redundant with the 🔑 ribbon
        # icon's own popup (_show_auth_status_popup, top-right) — kept built (not
        # deleted) only because _apply_checks()/_prompt_relogin() still reference
        # self._login_btn/self._relogin_btn/self._check_rows directly.
        self._prereq_hdr_frame = tk.Frame(prereq_outer, bg=T["accent"], padx=4, pady=1)
        self._prereq_hdr_frame.pack(fill="x")
        self._prereq_hdr_lbl = tk.Label(self._prereq_hdr_frame, text="PRERREQUISITOS",
                                        font=(_FUI_TITLE, 13, "bold"),
                                        bg=T["accent"], fg=T["button_fg"], anchor="w")
        self._prereq_hdr_lbl.pack(side="left")
        self._prereq_warn_lbl = tk.Label(self._prereq_hdr_frame, text="",
                                         font=(_FUI, 10, "bold"),
                                         bg=T["accent"], fg=T["button_fg"], anchor="e")
        self._prereq_warn_lbl.pack(side="right")
        env_card = tk.Frame(prereq_outer, bg=T["panel_bg"], padx=2, pady=2)
        env_card.pack(fill="both", expand=True)
        self._check_rows: dict[str, dict] = {}
        for key, name in [("auth", "Autenticación Snyk")]:
            row = tk.Frame(env_card, bg=T["panel_bg"]); row.pack(fill="x", pady=1)
            status = tk.Label(row, text="●", font=(_FUI, 10, "bold"),
                              bg=T["panel_bg"], fg=T["muted"], width=2)
            status.pack(side="left")
            self._lbl(row, name, size=10, bold=True, width=16, anchor="w").pack(side="left")
            detail = self._lbl(row, "…", size=10, fg=T["muted"], anchor="w")
            detail.pack(side="left", fill="x", expand=True, padx=(1, 1))
            fix = self._btn(row, "Reparar", lambda k=key: self._fix(k), kind="outline")
            fix.pack(side="right"); fix.config(state="disabled")
            self._check_rows[key] = {"status": status, "detail": detail, "fix": fix}
        btn_row_env  = tk.Frame(env_card, bg=T["panel_bg"]); btn_row_env.pack(fill="x", pady=(1, 0))
        btn_row_env2 = tk.Frame(env_card, bg=T["panel_bg"]); btn_row_env2.pack(fill="x", pady=(2, 0))
        self._btn(btn_row_env2, '🔄 Verificar',
                  lambda: self._run_async(self._recheck, label="verificación de entorno"),
                  kind="outline").pack(side="left")
        self._login_btn = self._btn(btn_row_env2, '🔑 Iniciar sesión SSO',
                                    lambda: self._run_async(self._do_login, label="snyk auth"),
                                    kind="accent")
        self._login_btn.pack(side="left", padx=(2, 0))
        self._login_btn.config(state="disabled")
        self._relogin_btn = self._btn(btn_row_env2, '🔁 Reiniciar sesión (SSO)',
                                      lambda: self._run_async(self._do_login, label="snyk re-auth"),
                                      kind="outline")
        self._relogin_btn.pack(side="left", padx=(2, 0))

        # Packed last on purpose: prereq_outer (side="bottom", fixed height) must be
        # packed BEFORE cards_row (expand=True, fill="both") for Tk's packer to give it
        # a real height instead of near-zero — packing an expand widget first lets it
        # greedily claim the whole cavity, starving whatever's packed after it. See the
        # 6-cell pipeline grid immediately above for how much a 402x420 min-per-card
        # grid alone eats into a normal 1280-1600px window; this bar could not also fit
        # beside it as a side panel (measured empirically, hence full-width + bottom).
        cards_row.pack(fill="both", expand=True, pady=(0, 0))

        self._open_btn = tk.Button(pad, state="disabled")
        self._csv_btn  = tk.Button(pad, state="disabled")

    def _refresh_stage_cards(self):
        """Re-paint every pipeline stage card so it visually matches its BooleanVar — used after something other than a c…"""
        for key, apply_fn in getattr(self, "_stage_apply", {}).items():
            try:
                apply_fn(bool(self._scan_vars[key].get()))
            except Exception:
                pass

    def _update_pipeline_progress(self, key: str, stage_label: str):
        """Llamado desde _drain_events en eventos 'stage'."""
        _terminal_pcts = {
            "done":    1.0,
            "failed":  1.0,
            "skipped": 0.0,
            "inactivo":    0.0,
        }

        if not hasattr(self, "_pipe_stage_states"):
            self._pipe_stage_states = {}
        if not hasattr(self, "_pipe_card_pcts"):
            self._pipe_card_pcts = {}

        self._pipe_stage_states[key] = stage_label

        card_clr = T["err"] if stage_label == "failed" else _progress_bar_color()

        if stage_label == "running" and key in ("sca", "code"):

            self._start_stage_pulse(key)

        if stage_label != "running":
            card_pct = _terminal_pcts.get(stage_label, 0.0)
            self._pipe_card_pcts[key] = card_pct
            bar_fn = getattr(self, "_stage_bar_update", {}).get(key)
            if bar_fn:
                try:
                    bar_fn(card_pct, card_clr)
                except Exception:
                    pass
        self._recompute_pipeline_header()

    def _start_stage_pulse(self, stage_key: str):
        """Programa actualizaciones periódicas de la barra desde el UI thread."""
        _PULSE_INTERVAL_MS = 400
        _PULSE_STEP = 0.015
        _PULSE_MAX = 0.90

        def _tick(key=stage_key):
            if self._pipe_stage_states.get(key) != "running":
                return
            bar_fn = getattr(self, "_stage_bar_update", {}).get(key)
            if bar_fn:
                pcts = getattr(self, "_pipe_card_pcts", {})
                cur = pcts.get(key, 0.0)
                nxt = min(cur + _PULSE_STEP, _PULSE_MAX)
                try:
                    bar_fn(nxt, _progress_bar_color())
                    pcts[key] = nxt
                    self._recompute_pipeline_header()
                except Exception:
                    pass
            self.after(_PULSE_INTERVAL_MS, _tick)

        self.after(_PULSE_INTERVAL_MS, _tick)

    def _update_card_progress(self, key: str, done: int, total: int):
        """Llamado desde _drain_events en eventos 'card_progress'."""
        if not hasattr(self, "_pipe_card_pcts"):
            self._pipe_card_pcts = {}
        if total <= 0:
            return
        pct = min(done / total, 0.99)
        self._pipe_card_pcts[key] = pct
        bar_fn = getattr(self, "_stage_bar_update", {}).get(key)
        if bar_fn:
            try:
                bar_fn(pct, _progress_bar_color())
            except Exception:
                pass
        self._recompute_pipeline_header()

    def _update_play_ring(self, pct: float) -> None:
        """Shows/fills the giant play button's circular progress ring — only visible while a scan is actually running (se…"""
        cell = getattr(self, "_scan_btn", None)
        if cell is None:
            return
        self._play_ring_pct = max(0.0, min(1.0, pct))
        busy = bool(getattr(self, "_play_card_busy", False))
        try:
            state = "normal" if busy else "hidden"
            cell.itemconfigure("ring_track", state=state)
            cell.itemconfigure("ring_fill", state=state,
                               extent=-360 * self._play_ring_pct,
                               outline=_progress_bar_color())

            cell.itemconfigure("arrow", state="hidden" if busy else "normal")
            cell.itemconfigure("pct_text", state="normal" if busy else "hidden",
                               text=f"{int(round(self._play_ring_pct * 100))}%",
                               fill=_progress_bar_color())
        except Exception:
            pass

    def _recompute_pipeline_header(self):
        """Recalcula el progreso de cada lane a partir de los pcts actuales de cada card, y lo refleja como barra de carg…"""
        if not hasattr(self, "_pipe_stage_states") or not hasattr(self, "_pipe_card_pcts"):
            return
        selected = {k for k, v in getattr(self, "_scan_vars", {}).items() if v.get()}
        active_states = {k: v for k, v in self._pipe_stage_states.items() if k in selected}

        def _lane_pct(keys):
            lane = [k for k in active_states if k in keys]
            if not lane:
                return 0.0
            return sum(self._pipe_card_pcts.get(k, 0.0) for k in lane) / len(lane)

        pct_general = _lane_pct({"sca", "code", "secrets", "dast", "api"})
        self._pipe_progress_pct = pct_general
        self._update_play_ring(pct_general)
        try:
            self._update_app_tab_progress(pct_general)
        except Exception:
            pass

        route_total = getattr(self, "_static_route_total", 1) or 1
        route_index = getattr(self, "_static_route_index", 0)
        static_stage_pct = _lane_pct({"sca", "code", "secrets"})
        if route_total > 1:
            static_pct = (route_index + static_stage_pct) / route_total
        else:
            static_pct = static_stage_pct

        set_ribbon = getattr(self, "_set_ribbon_tab_progress", None)
        if set_ribbon:
            try:
                set_ribbon("scan", pct_general)
                set_ribbon("static", static_pct)
                set_ribbon("dast", _lane_pct({"dast"}))
                set_ribbon("api", _lane_pct({"api"}))
            except Exception:
                pass

    _STATIC_STAGES = {"sca", "code", "secrets", "iac"}

    def _has_static_target(self) -> bool:
        """True if there's at least one real (non-placeholder) folder/file queued — the multi-path listbox if the Estátic…"""
        lb = getattr(self, "_static_paths_lb", None)
        if lb is not None:
            for p in lb.get(0, "end"):
                if p.strip() and not p.strip().startswith("("):
                    return True
            return False
        return bool(self._target_var.get().strip())

    def _refresh_scan_btn(self):
        sel = {k for k, v in self._scan_vars.items() if v.get()}
        needs_snyk = bool({"sca", "code"} & sel)
        checks = self._checks or {}
        auth_ok = bool(checks.get("auth") and checks["auth"].ok)
        ready = bool(sel) and ((not needs_snyk) or auth_ok)

        if ready and sel.issubset(self._STATIC_STAGES) and not self._has_static_target():
            ready = False

        try:
            self._refresh_probely_banner()
        except Exception:
            pass

        scan_btn = getattr(self, "_scan_btn", None)
        busy = getattr(self, "_busy", False) or getattr(self, "_static_busy", False)

        if scan_btn is not None:
            try:
                self._play_card_ready = ready
                self._play_card_busy = busy
                self._update_play_ring(getattr(self, "_play_ring_pct", 0.0))
                try:
                    self._update_app_tab_progress(getattr(self, "_pipe_progress_pct", 0.0))
                except Exception:
                    pass
                _dark = (T["bg"] != "#ffffff")
                if busy or not ready:
                    scan_btn.configure(bg=T["surface2"], cursor="arrow")
                    scan_btn.itemconfigure("arrow", fill="#ffffff" if _dark else T["muted"])
                else:
                    scan_btn.configure(bg=T["accent"], cursor="hand2")
                    scan_btn.itemconfigure("arrow", fill="#ffffff" if _dark else T["button_fg"])
            except Exception:
                pass

        run_btn  = getattr(self, "_run_icon_btn", None)
        run_wrap = getattr(self, "_run_icon_wrap", None)
        if run_btn:
            try:
                if busy or not ready:
                    run_btn.config(state="disabled", fg=T["muted"], bg=T["surface2"])
                    if run_wrap: run_wrap.config(bg=T["muted"])
                else:
                    run_btn.config(state="normal", fg=T["accent"], bg=T["panel_bg"],
                                   activebackground=T["surface2"],
                                   activeforeground=T["accent"])
                    if run_wrap: run_wrap.config(bg=T["accent"])
            except Exception:
                pass

        static_ready = self._has_static_target() and auth_ok
        for b in getattr(self, "_static_run_btns", []):
            try:
                wrap = getattr(b, "wrap", None)
                if static_ready and not busy:
                    b.config(state="normal", fg="#ffffff", bg=T["accent"],
                             activebackground=T["accent_hi"], activeforeground="#ffffff")
                    if wrap: wrap.config(bg=T["accent"])
                else:
                    b.config(state="disabled", fg=T["muted"], bg=T["surface2"])
                    if wrap: wrap.config(bg=T["surface2"])
            except Exception:
                pass

    def _refresh_auth_banner(self, auth_ok: bool) -> None:
        banner = getattr(self, "_auth_banner", None)
        if banner is None:
            return
        if auth_ok:
            if getattr(self, "_auth_banner_visible", False):
                banner.pack_forget()
                self._auth_banner_visible = False
        else:
            if not getattr(self, "_auth_banner_visible", False):

                cards_row = getattr(self, "_cards_row", None)
                if cards_row is not None:
                    banner.pack(fill="x", pady=(0, 2), before=cards_row)
                else:
                    banner.pack(fill="x", pady=(0, 2))
                self._auth_banner_visible = True

    def _recheck(self):
        self._event_queue.put(("checks", {"auth": check_auth()}))

    def _apply_checks(self, results: dict[str, CheckResult]):
        self._checks = results
        for key, res in results.items():
            row = self._check_rows.get(key)
            if not row: continue
            row["status"].config(text="●", fg=T["ok"] if res.ok else (
                T["muted"] if not res.detail or res.detail == "…" else T["err"]))
            row["detail"].config(text=res.detail or ("listo" if res.ok else "no configurado"))
            row["fix"].config(state="disabled" if (res.ok or not res.fixable) else "normal")

        auth_res = results.get("auth")
        auth_ok = bool(auth_res and auth_res.ok)

        sso_ok = False
        if auth_ok:
            detail_low = (auth_res.detail or "").lower()
            if "sso" in detail_low or "oauth" in detail_low:
                sso_ok = True
            else:
                auth_ok = False
                sso_ok = False
                row = self._check_rows.get("auth")
                if row:
                    row["status"].config(text="●", fg=T["err"])
                    row["detail"].config(text="⚠ Token detectado — se requiere SSO")
                    row["fix"].config(state="normal")
                self._log_line(
                    "[auth] ⚠ Se detectó un token API pero NO una sesión SSO/OAuth. "
                    "Haga clic en el ícono 🔑 (arriba a la derecha, junto a ▶) → Re-login, y en la "
                    "Snyk window choose 'Iniciar sesión SSO' (the grayed-out option below "
                    "'Log in with Google'). A plain token is not enough for organization scans.")

        prereq_hdr = getattr(self, "_prereq_hdr_frame", None)
        prereq_warn = getattr(self, "_prereq_warn_lbl", None)
        if prereq_hdr and prereq_warn:
            if not auth_ok:
                prereq_hdr.config(bg=T["err"]); prereq_warn.config(bg=T["err"], text="⚠ Acción requerida")
                hdr_lbl = getattr(self, "_prereq_hdr_lbl", None)
                if hdr_lbl: hdr_lbl.config(bg=T["err"])
            else:
                prereq_hdr.config(bg=T["accent"]); prereq_warn.config(bg=T["accent"], text="✔ Listo")
                hdr_lbl = getattr(self, "_prereq_hdr_lbl", None)
                if hdr_lbl: hdr_lbl.config(bg=T["accent"])
        if not auth_ok:
            self._login_btn.config(state="normal", text="🔑 Iniciar sesión SSO")
        else:
            self._login_btn.config(state="disabled", text="✓ Sesión SSO activa")
        self._set_key_status("auth" if auth_ok else "unauth")
        self._refresh_auth_banner(auth_ok)
        self._refresh_scan_btn()

    def _fix(self, key: str):
        if key in ("node", "npm", "snyk"):
            self._reinstall_missing_deps(key)
        elif key == "auth":
            self._run_async(self._do_login, label="snyk auth")

    def _reinstall_missing_deps(self, key: str):
        """Re-run the *full* boot installer (pip deps + Node/npm + git-secrets + Snyk CLI) inside the same BootSplash win…"""
        if self._any_busy():
            self._log_line(f"[busy] ignoring fix for '{key}' — another op in progress"); return
        self._busy = True; self._update_stop_btn_style()
        self._set_status(f"Reinstalando dependencias ({key})…")
        try:
            err, warnings = run_boot(master=self)
        finally:
            self._busy = False; self._update_stop_btn_style()
            self._set_status('✔  Listo'); self._refresh_scan_btn()
        if err:
            self._log_line(f"[fix] falló la instalación de dependencias: {err.splitlines()[0]}")
        else:
            self._log_line(f"[fix] verificación/instalación de dependencias finalizada para '{key}'.")
        for label, detail in warnings:
            self._log_line(f"[fix] ⚠ {label}: {detail}")
        self._recheck()

    def _prompt_relogin(self):
        """Called (on the UI thread) when a scan fails because Snyk auth is stale/expired."""
        if getattr(self, "_relogin_prompted", False):
            return
        self._relogin_prompted = True
        self._set_status("Sesión Snyk expirada — haga clic en 🔑 → Reiniciar sesión")
        self._log_line("[auth] ⚠ Snyk rechazó la credencial guardada (expirada o "
                       "invalid). Click the 🔑 key icon (top-right, next to ▶) → "
                       "Vuelva a iniciar sesión mediante el SSO de su organización. "
                       "then re-run the scan.")
        self._set_key_status("unauth")
        try:
            hdr = getattr(self, "_prereq_hdr_frame", None)
            warn = getattr(self, "_prereq_warn_lbl", None)
            if hdr and warn:
                hdr.config(bg=T["err"]); warn.config(bg=T["err"], text="⚠ Se requiere reinicio de sesión")
                lbl = getattr(self, "_prereq_hdr_lbl", None)
                if lbl: lbl.config(bg=T["err"])
            if getattr(self, "_relogin_btn", None):
                self._relogin_btn.config(state="normal")
        except Exception:
            pass

    def _clean_reinstall_snyk(self):
        """Manual escalation for when Snyk *runs* (`snyk --version` succeeds, so the
        routine 🔑/Fix repair paths see nothing wrong) but the backend rejects real
        scan requests — see reinstall_snyk_clean() in static_scanner.py. Disruptive
        (signs the user out), so it's opt-in with a confirmation, never automatic."""
        if self._any_busy():
            self._emit_log("[busy] ignorando reinstalación limpia — otra operación en curso")
            return
        self._show_confirm_popup(
            "¿Reinstalar Snyk desde cero?",
            "Esto desinstala la CLI de Snyk actual, borra por completo su "
            "configuración local (incluida la sesión guardada) y descarga la "
            "versión más reciente. Tendrá que volver a iniciar sesión SSO antes de "
            "poder escanear.\n\nEsto NO borra sus reportes ni las aplicaciones "
            "configuradas — ambos viven aparte, en la carpeta de Reportes.",
            on_yes=lambda: self._run_async(self._do_clean_reinstall_snyk,
                                           label="reinstalación limpia de Snyk"),
            yes_label="  🧹  Reinstalar  ", no_label="  Cancelar  ")

    def _do_clean_reinstall_snyk(self):
        from static_scanner import reinstall_snyk_clean
        ok = reinstall_snyk_clean(self._emit_log)
        self._relogin_prompted = False
        self._set_key_status("unauth")
        if ok:
            self._emit_log("[snyk] reinstalación limpia completa — inicie sesión con "
                           "🔑 antes de escanear.")
        else:
            self._emit_log("[snyk] la reinstalación limpia no terminó bien — revise "
                           "el log anterior.")
        self.after(0, self._recheck)

    def _do_login(self):
        self._relogin_prompted = False
        if self._auth_proc and self._auth_proc.poll() is None:
            self._emit_log("[auth] cancelling previous auth attempt and starting a new one…")
            _kill_process_tree(self._auth_proc)
            self._auth_proc = None
        self.after(0, self._show_snyk_login_popup)

    def _show_snyk_login_popup(self):

        popup = self._create_popup("Iniciar sesión en Snyk (SSO)")
        _raw_close = popup.close

        _popup_closed   = [False]
        _auth_succeeded = [False]

        def _safe_close(success: bool = False):
            if _popup_closed[0]:
                return
            _popup_closed[0] = True
            self._login_popup_close = None
            if success:
                _auth_succeeded[0] = True
            try:
                _raw_close()
            except Exception:
                pass
            if not _auth_succeeded[0]:
                self._run_async(self._recheck, label="post-login-popup recheck")

        popup.close = lambda: _safe_close(False)
        self._login_popup_close = lambda: _safe_close(True)

        self._popup_hdr(popup, "Iniciar sesión en Snyk", subtitle="Autenticación SSO", icon="🔑",
                        icon_image=self._load_status_icon("snyk"))
        popup._win.bind("<Escape>", lambda e: _safe_close(False))
        body = tk.Frame(popup, bg=T["bg"]); body.pack(fill="both", expand=True)

        img_frame = tk.Frame(body, bg=T["bg"]); img_frame.pack(pady=(4, 2))
        _img_ref = [None]
        img_path = LOGO_PATH
        try:
            _img_ref[0] = tk.PhotoImage(file=str(img_path))
            w, h = _img_ref[0].width(), _img_ref[0].height()
            factor = max(1, max(w // 360, h // 230))
            if factor > 1:
                _img_ref[0] = _img_ref[0].subsample(factor, factor)
            img_lbl = tk.Label(img_frame, image=_img_ref[0], bg=T["bg"],
                               highlightthickness=1, highlightbackground=T["border"])
            img_lbl.image = _img_ref[0]
            img_lbl.pack()
        except Exception:
            fb = tk.Frame(img_frame, bg=T["text"], padx=8, pady=4,
                          highlightthickness=1, highlightbackground=T["text"])
            fb.pack()
            tk.Label(fb, text="🔑", font=(_FUI, 19), bg=T["text"], fg=T["panel_bg"]).pack()
            tk.Label(fb, text="Snyk SSO", font=(_FUI, 10, "bold"),
                     bg=T["text"], fg=T["panel_bg"]).pack(pady=(1, 0))

        inst = tk.Frame(body, bg=T["panel_bg"], highlightthickness=1,
                        highlightbackground=T["border"], padx=5, pady=3)
        inst.pack(fill="x", padx=6, pady=(1, 3))
        tk.Label(inst, text="ℹ️  Debe iniciar sesión con SSO",
                 font=(_FUI, 10, "bold"), bg=T["panel_bg"], fg=T["text"]).pack(anchor="w", pady=(0, 2))
        tk.Label(inst,
                 text=("Su navegador se abrirá en un momento.\n\n"
                       "En la ventana de Snyk que aparece:\n\n"
                       "  1. Haga clic en 'Iniciar sesión con SSO de su empresa' — NO Google ni usuario/contraseña.\n"
                       "  2. Ingrese el dominio de su organización cuando se le solicite.\n"
                       "  3. Complete la autenticación en el navegador.\n"
                       "  4. Regrese aquí — esta ventana se cierra automáticamente al terminar."),
                 font=(_FUI, 10), bg=T["panel_bg"], fg=T["text"],
                 justify="left", wraplength=440, anchor="w").pack(anchor="w")

        _cli_ready    = [False]
        _btn_clicked  = [False]
        open_btn_ref  = [None]
        spinner_lbl   = [None]

        _spinner_frames = ["◐", "◓", "◑", "◒"]
        _spinner_idx    = [0]
        _spinner_after  = [None]

        def _spinner_tick():
            lbl = spinner_lbl[0]
            if lbl is None:
                return
            try:
                _spinner_idx[0] = (_spinner_idx[0] + 1) % len(_spinner_frames)
                lbl.config(text=f"  {_spinner_frames[_spinner_idx[0]]}  preparando sesión SSO, por favor espere")
                _spinner_after[0] = popup._win.after(160, _spinner_tick)
            except Exception:
                pass

        def _spinner_start():
            lbl = spinner_lbl[0]
            if lbl is None:
                return
            try:
                lbl.config(text=f"  {_spinner_frames[0]}  preparando sesión SSO, por favor espere",
                           fg=T["accent"])
                lbl.pack(side="left")
            except Exception:
                pass
            _spinner_tick()

        def _spinner_stop():
            if _spinner_after[0]:
                try:
                    popup._win.after_cancel(_spinner_after[0])
                except Exception:
                    pass
                _spinner_after[0] = None
            lbl = spinner_lbl[0]
            if lbl is None:
                return
            try:
                lbl.pack_forget()
            except Exception:
                pass

        def _prepare_cli():
            """Runs on a daemon thread: checks/repairs the Snyk CLI and clears stale credentials."""
            try:
                # Pre-warm the proxy/TLS env (can spawn a slow PowerShell Windows
                # cert-store export the first time) HERE, off the main thread — not
                # left to start_snyk_auth() below, which runs via popup._win.after(0,
                # ...) i.e. ON the Tk main thread, where a slow subprocess call would
                # freeze the whole GUI for its duration ("browser tarda mucho en
                # abrir" was really "the whole app looks frozen while this runs").
                # setup_proxy_tls_env() caches its result (NODE_EXTRA_CA_CERTS env var
                # + a temp-dir PEM file), so start_snyk_auth()'s own call to it later
                # just hits that cache and returns immediately.
                setup_proxy_tls_env(self._emit_log)
                if not _which("snyk") or not ensure_snyk_ready(self._emit_log):
                    self._emit_log(
                        "[auth] Snyk CLI is not runnable yet — could not repair it "
                        "automatically. If your network uses a TLS-inspecting proxy, "
                        "configure NODE_EXTRA_CA_CERTS con el certificado raíz CA de su empresa (.pem) e intente de nuevo."
                    )
                else:
                    clear_snyk_credentials(self._emit_log)
                    self._event_queue.put(("status", "Abriendo navegador para Snyk SSO…"))
            except Exception as exc:
                self._emit_log(f"[auth] CLI preparation error: {exc!r}")
            finally:
                _cli_ready[0] = True
                try:
                    popup._win.after(0, _auto_launch)
                except Exception:
                    pass

        def _launch_browser():
            _spinner_stop()
            self._auth_proc = start_snyk_auth(self._emit_log)
            self._auth_deadline = time.time() + AUTH_POLL_TIMEOUT
            self._auth_lines: queue.Queue = queue.Queue()
            proc_ref = self._auth_proc
            def _reader(proc=proc_ref):
                try:
                    if proc.stdout:
                        for line in iter(proc.stdout.readline, ""):
                            if not line:
                                break
                            self._auth_lines.put(line)
                except Exception:
                    pass
            threading.Thread(target=_reader, daemon=True).start()
            try:
                open_btn_ref[0].config(
                    state="normal",
                    text="🌐  Abrir navegador nuevamente"
                )
            except Exception:
                pass

        def _auto_launch():
            """Called automatically from _prepare_cli when CLI is ready."""
            if _btn_clicked[0]:
                return
            _btn_clicked[0] = True
            _launch_browser()

        def _open_browser():
            """Retry / manual-launch: re-opens a new snyk auth process even if one already ran automatically, so the user can…"""
            _btn_clicked[0] = False
            if _cli_ready[0]:
                _btn_clicked[0] = True
                _launch_browser()
            else:
                _btn_clicked[0] = True
                _spinner_start()

        foot_bar, _ = self._popup_foot(
            popup,
            ("  Cerrar  ", _safe_close, "flat"),
            ("🌐  Abrir navegador nuevamente", _open_browser, "accent"),
            with_status=True,
        )
        try:
            spinner_lbl[0] = foot_bar.winfo_children()[0]
            spinner_lbl[0].config(text="", font=(_FUI, 10))
        except Exception:
            pass
        try:
            open_btn_ref[0] = foot_bar.winfo_children()[-1]
        except Exception:
            pass

        # Started only now (after spinner_lbl/open_btn_ref are wired) so the very
        # first automatic preparation pass — which can include a slow one-time TLS/CA
        # export — shows immediate "◐ preparando…" feedback instead of a static-
        # looking popup with no sign anything is happening.
        _spinner_start()
        threading.Thread(target=_prepare_cli, daemon=True).start()

    def _show_auth_status_popup(self):
        """Popup behind the 🔑 key icon (top-right ribbon, left of ▶)."""
        checks = getattr(self, "_checks", None) or {}
        auth_res = checks.get("auth")
        auth_ok = bool(auth_res and auth_res.ok)
        if auth_ok:
            icon, icon_color, title = "✓", T["ok"], "Autenticado"
            detail = auth_res.detail or "Sesión SSO activa."
            msg_fg = T["text"]
        else:
            icon, icon_color, title = "✕", T["err"], "Sin autenticación"
            detail = (auth_res.detail if auth_res else None) or "Sin sesión Snyk detectada."
            msg_fg = T["err"]

        popup = self._create_popup("Autenticación Snyk")
        self._popup_hdr(popup, "Autenticación Snyk", subtitle="Estado de sesión SSO", icon="🔑",
                        icon_image=self._load_status_icon("snyk"))
        self._centered_msg(popup, icon, icon_color, title, detail, msg_fg)

        def _go(fn):
            popup.close()
            self._set_key_status("checking")
            fn()

        self._popup_foot(
            popup,
            ("🔑 Inicio SSO", lambda: _go(lambda: self._run_async(self._do_login, label="snyk auth")), "accent"),
            ("🔁 Re-iniciar sesión",  lambda: _go(lambda: self._run_async(self._do_login, label="snyk re-auth")), "outline"),
            ("🔄 Verificar",  lambda: _go(lambda: self._run_async(self._recheck, label="verificación de entorno")), "outline"),
            ("🧹 Reinstalar (limpio)", lambda: (popup.close(), self._clean_reinstall_snyk()), "outline"),
        )

    def _kick_auth_check(self):
        """Run check_auth() on a background thread."""
        if getattr(self, "_auth_check_inflight", False):
            return
        self._auth_check_inflight = True
        def _bg():
            try:
                res = check_auth()
            except Exception:
                res = None
            self._event_queue.put(("auth_check_done", res))
        threading.Thread(target=_bg, daemon=True).start()

    def _tick_auth_poll(self):
        proc = self._auth_proc
        if proc is None: return
        try:
            lines_q = getattr(self, "_auth_lines", None)
            while lines_q is not None:
                try:
                    line = lines_q.get_nowait()
                except queue.Empty:
                    break
                self._log_line(line.rstrip())
        except Exception: pass
        now = time.time()
        if not hasattr(self, "_next_auth_check") or now >= self._next_auth_check:
            self._next_auth_check = now + AUTH_POLL_INTERVAL
            self._kick_auth_check()
        if proc.poll() is not None:
            self._log_line(f"[auth] snyk auth exited ({proc.returncode})")
            self._auth_proc = None
            self._run_async(self._recheck, label="verificación post-auth"); return
        if now > self._auth_deadline:
            self._log_line("[auth] tiempo de espera agotado — cancelando.")
            _kill_process_tree(proc)
            self._auth_proc = None

    def _start_scan(self):
        """Public entry point for ribbon ▶, the Run-scan tab button, and the DAST/API tab button — the manual 'run a scan…"""
        has_app = bool(getattr(self, "_active_app", None) and self._active_app.get("name"))
        if not has_app:
            sel = {k for k, v in self._scan_vars.items() if v.get()}
            has_static = bool(sel & {"sca", "code", "secrets"})
            has_dynamic = bool(sel & {"dast", "api"})
            if has_static and has_dynamic:
                self._drop_static_no_app()
                return
        self._confirm_scan_without_app(self._run_scan_pipeline)

    def _drop_static_no_app(self):
        """No app/target loaded, but both a static and a dynamic stage are selected together."""
        names = {"sca": "Dependencias (SCA)", "code": "Código (SAST)", "secrets": "Secretos"}
        dropped = []
        for k in ("sca", "code", "secrets"):
            v = self._scan_vars.get(k)
            if v and v.get():
                v.set(False)
                apply_fn = self._stage_apply.get(k)
                if apply_fn:
                    try: apply_fn(False)
                    except Exception: pass
                dropped.append(k)
        if not dropped:
            self._run_scan_pipeline()
            return
        self._persist_scan_stages()
        self._refresh_scan_btn()
        dropped_names = ", ".join(names[k] for k in dropped)
        self._emit_log(
            f"[scan] {dropped_names} deseleccionado(s) — necesitan una "
            "aplicación cargada (ruta de objetivo) y no hay ninguna activa. "
            "Se continúa solo con las etapas web/API seleccionadas.")
        self._show_info_popup(
            "Etapas estáticas omitidas",
            f"{dropped_names} necesitan una aplicación cargada (ruta de "
            "objetivo) y no hay ninguna activa, así que se "
            "deseleccionaron.\n\n"
            "Se continúa solo con las etapas web/API seleccionadas, si "
            "cumplen sus propios requisitos (por ejemplo, Probely "
            "conectado).")
        sel = {k for k, v in self._scan_vars.items() if v.get()}
        if not sel:
            return

        self._run_scan_pipeline()

    def _run_scan_pipeline(self):
        self._run_async(self._do_scan, label="escaneo completo de pipeline")

    def _request_cancel(self):
        if not self._any_busy():
            self._emit_log("[scan] nothing to cancel.")
            return
        self._show_confirm_popup(
            "¿Detener escaneo?",
            "Hay un escaneo en ejecución. Detenerlo descartará los "
            "resultados no guardados aún.\n\nDo you want to stop it?",
            on_yes=self._do_cancel,
            yes_label="  ■  Detener escaneo  ", no_label="  Continuar  ")

    def _do_cancel(self):
        if not self._any_busy():
            self._emit_log("[scan] nothing to cancel.")
            return
        if self._busy: self._cancel_evt.set()
        if self._static_busy: self._static_cancel_evt.set()
        self._emit_log("[scan] cancel requested…"); self._set_status('Cancelando…')
        try:
            import audit_log
            audit_log.write_event(Path(self._reports_var.get()), "scan_cancel_requested",
                                  actor=self._user, log=self._emit_log)
        except Exception: pass

    def _probely_ready(self, cfg, kind: str) -> bool:
        """Pre-flight gate for the cloud DAST/API stages, mirroring how SCA/SAST gate on ensure_snyk_ready()."""
        if not (getattr(cfg, "probely_token", "") or "").strip():
            self._emit_log(f"[{kind}] Snyk API & Web: no hay clave de Probely — "
                           f"omitiendo {kind.upper()}. Conecte Probely (🌐).")
            self._event_queue.put(("probely_required", None))
            return False
        try:
            ok, msg = check_snyk_api_web(cfg, self._emit_log)
        except Exception as e:
            self._emit_log(f"[{kind}] Snyk API & Web readiness check error: {e!r}")
            return True
        if ok:
            self._emit_log(f"[{kind}] Snyk API & Web: {msg}")
            self._event_queue.put(("probely_ok", None))
            return True
        self._emit_log(f"[{kind}] Snyk API & Web not ready — skipping {kind.upper()}: {msg}")
        self._event_queue.put(("probely_required", None))
        return False

    def _scoped_report_paths(self, reports_root: Path):
        """Return (report_label, app_reports_root) scoped to the active app."""
        active_app = getattr(self, "_active_app", None)
        slug = (_re.sub(r"[^A-Za-z0-9\-_]", "_", active_app["name"].strip())
                if active_app and active_app.get("name") else "")
        label = f"{self._user}+{slug}" if slug else self._user
        app_reports_root = reports_root / (slug if slug else "_unscoped")
        app_reports_root.mkdir(parents=True, exist_ok=True)
        return label, app_reports_root

    def _do_scan(self):
        selected = {k for k, v in self._scan_vars.items() if v.get()}
        if not selected:
            self._emit_log("[scan] nothing selected"); return
        self._cancel_evt.clear()
        _raw_target = self._target_var.get().strip()
        _needs_folder = bool({"sca", "code", "secrets"} & selected)
        if _needs_folder and not _raw_target:

            _static_items = []
            try:
                lb = getattr(self, "_static_paths_lb", None)
                if lb is not None:
                    _static_items = [p for p in lb.get(0, "end") if p.strip()]
            except Exception:
                pass
            if not _static_items:
                _static_items = [str(p) for p in (getattr(self, "_static_targets", None) or [])]
            if _static_items:
                _raw_target = _static_items[0]
                self._target_var.set(_raw_target)
                self._emit_log(f"[scan] usando carpeta de la pestaña Estático: {_raw_target}")
        if _needs_folder and not _raw_target:

            self._emit_log("[scan] sin carpeta objetivo — seleccione una carpeta "
                           "antes de escanear (SCA/SAST/Secrets la necesitan)")
            return
        target = Path(_raw_target).resolve() if _raw_target else Path(".").resolve()
        reports_root = Path(self._reports_var.get()).resolve(); reports_root.mkdir(parents=True, exist_ok=True)
        if bool({"sca","code"} & selected) and (not target.exists() or not target.is_dir()):
            self._emit_log(f"[scan] carpeta objetivo no encontrada: {target}"); return
        if _needs_folder and target.is_dir() and not self._dir_has_files(target):

            self._emit_log(f"[scan] ⚠ carpeta objetivo vacía (sin archivos): "
                           f"{target} — no hay nada que escanear")
            return
        mode = "+".join(sorted(selected))
        active_app = getattr(self, "_active_app", None)
        _report_label, app_reports_root = self._scoped_report_paths(reports_root)
        out_dir = app_reports_root / f"report_{_ts()}_{mode}"; out_dir.mkdir(parents=True, exist_ok=True)
        self._session_begin("pipeline", selected)
        import audit_log
        audit_log.write_event(reports_root, "scan_start", actor=self._user,
                              app=(active_app.get("name") if active_app else ""),
                              mode=mode, target=str(target), out_dir=str(out_dir),
                              log=self._emit_log)
        self._emit_log(f"[scan] pipeline: {mode.upper()}")
        self._emit_log(f"[scan] output → {out_dir}")
        _snyk_usable = True
        if {"sca", "code"} & selected:
            try:
                if not ensure_snyk_ready(self._emit_log):
                    _snyk_usable = False
                    self._emit_log("[scan] Snyk CLI is not runnable — skipping "
                                   "SCA/SAST. Click Fix to repair it.")
            except Exception as e:
                self._emit_log(f"[scan] snyk readiness check error: {e!r}")
        try: v = _run(["snyk","--version"]).stdout.strip()
        except Exception: v = "?"
        results: dict[str, Any] = {"sca":None,"code":None,"dast":None,"api":None,"secrets":None}

        failed_stages: set[str] = set()
        failed_reasons: dict[str, str] = {}
        self._event_queue.put(("pipeline_reset", None))
        for k in ("sca","code","dast","api","secrets"):
            running = k in selected and (_snyk_usable or k not in ("sca", "code"))
            self._event_queue.put(("stage", (k, "running" if running else "skipped")))
        jobs: list[tuple[str, Callable[[], None]]] = []
        def _stage(key, fn, *a, **kw):
            jobs.append((key, lambda: results.__setitem__(key, fn(*a, **kw)[0])))

        if "sca" in selected and _snyk_usable:
            _stage("sca", run_snyk_test, target, out_dir, self._emit_log)
        if "code" in selected and _snyk_usable:
            _stage("code", run_snyk_code, target, out_dir, self._emit_log)
        if "dast" in selected:
            dast_cfg = self._collect_dast_cfg()
            if not dast_cfg.url or dast_cfg.url == "https://":
                self._emit_log("[dast] sin URL configurada — se omite DAST")
                self._event_queue.put(("stage",("dast","skipped")))
            elif not self._probely_ready(dast_cfg, "dast"):
                self._event_queue.put(("stage",("dast","skipped")))
            else:
                _stage("dast", run_dast, dast_cfg, out_dir, self._emit_log, cancel=self._cancel_evt,
                       progress=lambda n, t: self._event_queue.put(("card_progress", ("dast", n, t))))
        if "api" in selected:
            api_cfg = self._collect_api_cfg()
            if not api_cfg.spec_source and not getattr(api_cfg, "base_url", ""):
                self._emit_log("[api] no spec/base URL configured — skipping API scan")
                self._event_queue.put(("stage",("api","skipped")))
            elif not self._probely_ready(api_cfg, "api"):
                self._event_queue.put(("stage",("api","skipped")))
            else:
                _stage("api", run_api, api_cfg, out_dir, self._emit_log, cancel=self._cancel_evt,
                       progress=lambda n, t: self._event_queue.put(("card_progress", ("api", n, t))))
        if "secrets" in selected:
            def _run_secrets_stage():
                try:
                    self._emit_log("[secrets] running secret scan as pipeline stage…")
                    result = scan_path(
                        target, self._emit_log, cancel=self._cancel_evt,
                        git_secrets_status=get_git_secrets_status(),
                        progress=lambda n, t: self._event_queue.put(("card_progress", ("secrets", n, t))),
                    )
                    sec_dir = out_dir / "secrets"
                    write_secrets_report(result, sec_dir)
                    self._emit_log(f"[secrets] {result['total']} finding(s) across {result['scanned_files']} file(s)")
                    results["secrets"] = result
                except Exception as e:
                    self._emit_log(f"[secrets] stage failed: {e!r}"); results["secrets"] = None
            jobs.append(("secrets", _run_secrets_stage))
        def run_stage(item):
            key, fn = item
            try:
                fn(); self._event_queue.put(("stage",(key,"done")))
            except Exception as e:
                self._event_queue.put(("stage",(key,"failed"))); self._emit_log(f"[scan] {key} failed: {e!r}")
                failed_stages.add(key)
                failed_reasons[key] = str(e)
                if getattr(e, "is_auth", False):

                    self._event_queue.put(("probely_required" if key in ("dast", "api")
                                           else "auth_required", None))
        if len(jobs) > 1:
            self._emit_log(f"[scan] running {len(jobs)} stages concurrently")
            with ThreadPoolExecutor(max_workers=len(jobs)) as ex_:
                list(ex_.map(run_stage, jobs))
        else:
            for j in jobs: run_stage(j)
        if failed_stages:

            self._emit_log(
                "[scan] ⚠ " + "/".join(sorted(failed_stages)).upper() +
                " did not complete — this run's totals and gate result are "
                "INCOMPLETE, not a confirmed clean scan.")

        # Matches ONLY the genuine SNYK-0003 backend-rejection signature -- NOT the
        # wrapper phrase "could not analyse the target" (our own text, present on
        # every Snyk envelope error regardless of cause). See static_scanner.py's
        # _static_scan_one for the full explanation of the bug this fixes.
        _backend_rejected = {k for k in failed_stages
                             if "the request cannot be processed" in failed_reasons.get(k, "").lower()}
        if _backend_rejected and not getattr(self, "_snow_snyk_auto_reinstall_done", False):
            self._snow_snyk_auto_reinstall_done = True
            self._emit_log(
                "[snyk] ⚠ Snyk rechazó la solicitud a nivel de servidor para "
                + "/".join(sorted(_backend_rejected)).upper() +
                " aunque la CLI local corre sin problemas — normalmente esto "
                "significa que el backend ya no acepta esta versión/instalación de "
                "la CLI. Reinstalando automáticamente la versión más reciente "
                "(misma acción que '🧹 Reinstalar (limpio)')…")
            try:
                from static_scanner import reinstall_snyk_clean
                reinstall_snyk_clean(self._emit_log)
                self._emit_log(
                    "[snyk] reinstalación automática completa — inicie sesión de "
                    "nuevo (icono 🔑, arriba a la derecha) antes de re-escanear "
                    "esta carpeta.")
            except Exception as e:
                self._emit_log(f"[snyk] la reinstalación automática falló: {e!r}")
        elif _backend_rejected:
            self._emit_log(
                "[snyk] ⚠ Snyk sigue rechazando la solicitud para "
                + "/".join(sorted(_backend_rejected)).upper() +
                " incluso tras la reinstalación automática de esta sesión — puede "
                "requerir revisión manual (versión de CLI, organización, proxy).")

        # "Cannot build Maven dependency tree" -- never a CLI-version problem (same
        # failure reproduces running `snyk test` directly, outside this app). See
        # static_scanner.py's _static_scan_one for the full explanation.
        _maven_tree_issue = {k for k in failed_stages
                             if "cannot build maven dependency tree" in failed_reasons.get(k, "").lower()}
        if _maven_tree_issue:
            self._emit_log(
                "[snyk] ℹ️ " + "/".join(sorted(_maven_tree_issue)).upper() +
                ": Snyk no pudo construir el árbol de dependencias de Maven — esto "
                "es un problema del proyecto/Maven, NO de la versión de Snyk ni de "
                "este programa (el mismo error ocurre corriendo 'snyk test' directo "
                "en terminal/IDE, fuera de este escáner). Para diagnosticar la "
                'causa real, corra esto en esa carpeta: mvn dependency:tree '
                '-DoutputType=dot --file="pom.xml" — si ese comando TAMBIÉN falla, '
                "el problema está en Maven/el proyecto (mvn no está en el PATH, "
                "repositorio interno inalcanzable, plugin Maven Dependency <2.2, "
                "versión de JDK, settings.xml); si el comando SÍ funciona pero "
                "Snyk sigue fallando, es caso para soporte de Snyk.")

        # Org access/permissions -- Snyk's own documented V1 API 404 response.
        # Confirmed real-world root cause: logging in via email/password instead of
        # "Login with SSO" enters a PERSONAL Snyk instance, not the company's org --
        # see static_scanner.py's _static_scan_one for the full explanation.
        _org_access_issue = {k for k in failed_stages
                             if "permissions to access the org" in failed_reasons.get(k, "").lower()}
        if _org_access_issue:
            _org_m = re.search(r"[Oo]rg (\S+) was not found", " ".join(
                failed_reasons.get(k, "") for k in _org_access_issue))
            if _org_m:
                _org_id = _org_m.group(1)
            else:
                from static_scanner import _DEFAULT_SNYK_ORG
                _org_id = _DEFAULT_SNYK_ORG
            self._emit_log(
                "[snyk] ℹ️ " + "/".join(sorted(_org_access_issue)).upper() +
                f": esta sesión de Snyk no tiene acceso a la organización "
                f"{_org_id}. Causa más común: se inició sesión con correo y "
                f"password directo en vez de SSO — eso entra a una instancia "
                f"PERSONAL de Snyk (la de ese correo), no a la de la empresa. "
                f"SOLUCIÓN: dé clic en el ícono de Snyk (esquina superior derecha) "
                f"→ '🔁 Re-iniciar sesión' → en la página que abre el navegador, "
                f"elija 'Login with SSO' — NO capture correo y password "
                f"directamente ahí. Si ya inició sesión con SSO y el error "
                f"persiste, puede que la cuenta no esté agregada a esta "
                f"organización específica (pertenecer al grupo de Snyk no basta) "
                f"— en ese caso pida a un admin de Snyk que la agregue en "
                f"Settings → Members, a nivel Organización.")

        for _k in ("dast", "api"):
            _r = results.get(_k)
            if not isinstance(_r, dict):
                continue
            if _r.get("auth_error"):
                self._emit_log(f"[{_k}] Snyk API & Web auth error — clave de Probely inválida o expirada.")
                self._event_queue.put(("probely_required", None))
            su = _r.get("scan_url")
            if su:
                self._emit_log(f"[{_k}] ver el escaneo en Probely: {su}")
            rp = _r.get("report_path")
            if rp:
                self._emit_log(f"[{_k}] reporte de cumplimiento: {rp}")
            for f in (_r.get("findings") or []):
                ev = (f.get("evidence") or "")
                if "not verified" in ev.lower() or "verification token" in ev.lower():
                    self._event_queue.put(("probely_verify", (_k, ev)))
                    break
        dast_url_hint = ""; api_spec_hint = ""
        try: dast_url_hint = self._dast_url_var.get().strip()
        except Exception: pass
        try: api_spec_hint = self._api_spec_var.get().strip()
        except Exception: pass
        _kind_targets = {
            "sca": str(target), "code": str(target), "dast": dast_url_hint or str(target),
            "api": api_spec_hint or str(target), "secrets": str(target),
        }
        state = self._scan_state
        for kind in ("sca", "code", "dast", "api", "secrets"):
            raw = results.get(kind)
            if raw is not None:
                try:
                    state.save_kind(kind, raw, target=_kind_targets.get(kind, str(target)),
                                    snyk_version=v, mode=mode)
                    self._emit_log(f"[state] {kind} result persisted to cumulative store")
                except Exception as e:
                    self._emit_log(f"[state] could not save {kind}: {e!r}")
        ctx = build_cumulative_context(state, target_hint=target, snyk_version_hint=v, current_results=results)
        self._emit_log("[report] building cumulative report (all scan types merged)")
        ctx["scan_mode"] = mode
        ctx["failed_stages"] = sorted(failed_stages)
        ctx["incomplete"] = bool(failed_stages)

        ctx["batch_targets"] = [str(target)]

        _snow_static_rec = None
        _snow_dynamic_rec = None
        try:
            from servicenow_tickets import summarize_static, summarize_dynamic, sync_ticket, public_view
            _snow_static_sel = {"sca", "code", "secrets"} & selected
            _snow_static_data = any(results.get(k) is not None for k in ("sca", "code", "secrets"))
            if _snow_static_sel & failed_stages:
                self._emit_log("[servicenow] etapa(s) estática(s) incompleta(s) — se omite "
                               "sincronización de ticket de repositorio")
            elif _snow_static_sel and _snow_static_data:
                _snow_static_summary = summarize_static(results.get("sca"), results.get("code"),
                                                         results.get("secrets"), target, v)
                _snow_static_rec = sync_ticket(
                    reports_root, kind="static", name=target.name, summary=_snow_static_summary,
                    app_name=(active_app.get("name") if active_app else ""),
                    actor=self._user, log=self._emit_log)

            _snow_dynamic_sel = {"dast", "api"} & selected
            _snow_dynamic_data = any(results.get(k) is not None for k in ("dast", "api"))
            if _snow_dynamic_sel & failed_stages:
                self._emit_log("[servicenow] etapa(s) dast/api incompleta(s) — se omite "
                               "sincronización de ticket de aplicación")
            elif _snow_dynamic_sel and _snow_dynamic_data:
                if active_app and active_app.get("name"):
                    _snow_dynamic_summary = summarize_dynamic(results.get("dast"), results.get("api"), target, v)
                    _snow_dynamic_rec = sync_ticket(
                        reports_root, kind="dynamic", name=active_app["name"],
                        summary=_snow_dynamic_summary, app_name=active_app["name"],
                        actor=self._user, log=self._emit_log)
                else:
                    self._emit_log("[servicenow] sin aplicación activa — se omite ticket de "
                                   "DAST/API (se identifica por el nombre de la aplicación)")
        except ImportError as e:
            self._emit_log(
                f"[servicenow] no se pudo importar servicenow_tickets.py ({e!r}) — "
                f"ese archivo (y test_servicenow_ticket.py) deben estar en la MISMA "
                f"carpeta que gui_dast_api_tab.py para que el escáner pueda crear/"
                f"actualizar tickets automáticamente. Se omite la sincronización.")
        except Exception as e:
            self._emit_log(f"[servicenow] no se pudo sincronizar el/los ticket(s): {e!r}")
        ctx["servicenow_tickets"] = [public_view(r) for r in (_snow_static_rec, _snow_dynamic_rec) if r]

        self._emit_log(f"[scan] cumulative total: {ctx['total']}  "
                       f"crit={ctx['counts']['critical']}  high={ctx['counts']['high']}  "
                       f"med={ctx['counts']['medium']}  low={ctx['counts']['low']}  "
                       f"secrets={ctx.get('secrets_total',0)}")
        _base = _report_basename(self._user, mode)
        report = render_html(ctx, out_dir, filename=f"{_base}.html")
        csv_path = export_csv(ctx, out_dir / f"{_base}.csv", report_label=_report_label)
        self._emit_log(f"[report] CSV bundle (ZIP): {csv_path}  (sca/sast/dast/api/secrets sheets + summary)")
        sec_html_src = out_dir / "secrets" / "secrets.html"
        if sec_html_src.exists():
            try:
                sec_html_dst = out_dir / f"{_base}_secrets.html"
                shutil.copyfile(sec_html_src, sec_html_dst)
                self._emit_log(f"[report] Secrets HTML → {sec_html_dst}")
            except Exception as e:
                self._emit_log(f"[report] secrets HTML copy skipped: {e!r}")
        try:
            sarif_path = export_sarif(out_dir)
            if sarif_path: self._emit_log(f"[report] SARIF: {sarif_path}")
        except Exception as e:
            self._emit_log(f"[report] SARIF export skipped: {e!r}")
        try:
            merged_path = export_merged_json(out_dir)
            if merged_path: self._emit_log(f"[report] merged JSON: {merged_path}")
        except Exception as e:
            self._emit_log(f"[report] merged JSON skipped: {e!r}")
        meta = {
            "generated_at": ctx["generated_at"], "target": ctx["target"], "mode": mode,
            "counts": ctx["counts"], "total": ctx["total"], "sca_total": ctx["sca_total"],
            "code_total": ctx["code_total"], "dast_total": ctx.get("dast_total",0),
            "api_total": ctx.get("api_total",0), "snyk_version": ctx["snyk_version"],
            "secrets_total": ctx.get("secrets_total", 0),
            "failed_stages": sorted(failed_stages), "incomplete": bool(failed_stages),
            "servicenow_tickets": ctx.get("servicenow_tickets", []),
        }
        (out_dir / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
        try:
            rec = update_history_after_scan(reports_root, ctx, meta,
                                            actor=getattr(self, "_user", ""), report_dir=out_dir)
            self._emit_log(f"[history] recorded scan — remediated {rec.get('remediated_count',0)}, "
                           f"new {rec.get('introduced_count',0)} since last {mode.upper()} run")
        except Exception as e:
            self._emit_log(f"[history] could not update remediation history: {e!r}")
        active_app = getattr(self, "_active_app", None)
        if active_app and active_app.get("id"):
            try:
                self._inv_store.record_scan(active_app["id"], meta)
                self._emit_log(f"[inventory] scan recorded for app '{active_app['name']}'")
                self._event_queue.put(("inv_refresh", active_app["id"]))
            except Exception as e:
                self._emit_log(f"[inventory] could not update app record: {e!r}")
        c = ctx["counts"]
        secrets_crit = sum(1 for s in ctx.get("secrets", {}).get("findings", [])
                           if s.get("severity") in ("critical", "high"))
        _raw_gate = "FAIL" if (c.get("critical",0) or c.get("high",0) or secrets_crit) else "PASS"

        gate = "INCOMPLETE" if failed_stages else _raw_gate
        _gate_suffix = (f"  — {'/'.join(sorted(failed_stages)).upper()} did not complete; "
                        f"re-run before treating this as {_raw_gate}") if failed_stages else ""
        self._emit_log(f"[gate] {gate}  (critical={c.get('critical',0)} high={c.get('high',0)} "
                       f"medium={c.get('medium',0)} low={c.get('low',0)} "
                       f"secrets_crit_high={secrets_crit}){_gate_suffix}")
        self._last_context = ctx; self._last_report_dir = out_dir
        self._last_static_report = Path(report)
        self._emit_log(f"[report] HTML: {report}")
        self._emit_log(f"[report] CSV:  {csv_path}")
        audit_log.write_event(reports_root, "scan_end", actor=self._user,
                              app=(active_app.get("name") if active_app else ""),
                              mode=mode, total=ctx["total"], counts=ctx["counts"],
                              gate=gate, secrets_crit_high=secrets_crit,
                              failed_stages=sorted(failed_stages), incomplete=bool(failed_stages),
                              report=str(report), cancelled=self._cancel_evt.is_set(),
                              log=self._emit_log)
        self._event_queue.put(("static_results", ctx))
        self._event_queue.put(("report", str(report)))
        self._session_end("pipeline")

class _ApiTabMixin:
    def _build_tab_api(self, parent):
        pad = self._scrollable(parent)
        self._safety_banner(pad,
            "Asegúrate de que la URL apunte a un entorno que NO sea de producción.")
        body = self._card(pad, 'Especificación'); body.columnconfigure(1, weight=1); body.columnconfigure(3, weight=1)
        def gl(text, r, c): return self._glabel(body, text, r, c)
        gl('Especificación (URL o archivo)', 0, 0); self._gentry(body, self._api_spec_var, 0, 1, span=2)
        self._icon_square_btn(body, '📄', self._browse_api_spec).grid(row=0, column=3, sticky="w", padx=(1, 0))

        self._api_basic_rows: list = []
        lbl_base = self._lbl(body, 'URL base del API objetivo (opcional)', anchor="e")
        lbl_base.grid(row=1, column=0, sticky="e", padx=(0, 2), pady=1)
        ent_base = ttk.Entry(body, textvariable=self._api_base_var)
        ent_base.grid(row=1, column=1, columnspan=3, sticky="ew", pady=1)
        self._api_basic_rows += [lbl_base, ent_base]
        lbl_auth = self._lbl(body, 'Tipo de autenticación', anchor="e")
        lbl_auth.grid(row=2, column=0, sticky="e", padx=(0, 2), pady=1)
        api_ac = ttk.Combobox(body, textvariable=self._api_auth_var,
                              values=["none","basic","bearer","cookie","header"],
                              state="readonly", width=10)
        api_ac.grid(row=2, column=1, sticky="w", pady=1)
        api_ac.bind("<<ComboboxSelected>>", lambda _: self._refresh_api_creds())
        lbl_prof = self._lbl(body, 'Perfil de escaneo', anchor="e")
        lbl_prof.grid(row=3, column=0, sticky="e", padx=(0, 2), pady=1)
        prof_row = tk.Frame(body, bg=T["panel_bg"])
        prof_row.grid(row=3, column=1, sticky="w", pady=1)
        prof_refresh_btn = self._icon_square_btn(prof_row, "↻", lambda: self._refresh_scan_profiles("api"))
        prof_refresh_btn.pack(side="left", padx=(0, 1))
        api_pc = ttk.Combobox(prof_row, textvariable=self._api_profile_var,
                              values=["(predeterminado)","lightning","safe","normal","full"],
                              state="readonly", width=14)
        api_pc.pack(side="left")
        self._api_profile_cb = api_pc
        lbl_schema = self._lbl(body, 'Tipo de esquema', anchor="e")
        lbl_schema.grid(row=3, column=2, sticky="e", padx=(0, 2), pady=1)
        schema_cb = ttk.Combobox(body, textvariable=self._api_schema_type_var,
                     values=["(auto)","openapi","postman","graphql"],
                     state="readonly", width=12)
        schema_cb.grid(row=3, column=3, sticky="w", pady=1)
        self._api_basic_rows += [lbl_prof, prof_row, lbl_schema, schema_cb]

        self._api_advanced_var = tk.BooleanVar(value=False)
        adv_row = tk.Frame(body, bg=T["panel_bg"]); adv_row.grid(row=4, column=0, columnspan=4, sticky="w", pady=(2, 0))
        ToggleSwitch(adv_row, text="Avanzado", variable=self._api_advanced_var,
                     command=self._refresh_api_advanced_visibility).pack(side="left")

        self._api_adv_wrap = tk.Frame(body, bg=T["panel_bg"])
        self._api_adv_wrap.grid(row=5, column=0, columnspan=4, sticky="ew", pady=(1, 0))
        self._api_cred_frame = tk.Frame(self._api_adv_wrap, bg=T["panel_bg"])
        self._api_cred_frame.pack(fill="x")
        self._api_cred_frame.columnconfigure(1, weight=1)
        scope = tk.Frame(self._api_adv_wrap, bg=T["panel_bg"]); scope.pack(fill="x", pady=(2, 0))
        ToggleSwitch(scope, text="Verificar TLS (solo vista previa local)", variable=self._api_tls_var).pack(side="left", padx=(0, 4))
        self._lbl(scope, 'Proxy HTTP (solo vista previa)').pack(side="left", padx=(0, 1))
        ttk.Entry(scope, textvariable=self._api_proxy_var, width=24).pack(side="left")
        conv_card = self._card(pad, 'Endpoints', pady=(0, _CARD_GAP))
        btn_row_conv = tk.Frame(conv_card, bg=T["panel_bg"]); btn_row_conv.pack(fill="x", pady=(0, 2))
        self._btn(btn_row_conv, '🔍 Vista previa', self._api_preview_spec, kind="accent").pack(side="left")
        self._btn(btn_row_conv, '📥 Importar…', self._api_import_popup, kind="flat").pack(side="left", padx=(2, 0))
        self._btn(btn_row_conv, "💾 Exportar…", self._api_export_popup, kind="flat").pack(side="left", padx=(2, 0))
        tree_wrap = tk.Frame(conv_card, bg=T["panel_bg"]); tree_wrap.pack(fill="both", expand=True)
        self._ep_tree = _make_tree(tree_wrap, ("method","url","secured","body"),
                                   [("Método",70),("URL del endpoint",480),("Auth req.",70),("Tipo de cuerpo",120)], height=10)
        self._ep_count_lbl = self._lbl(conv_card, "", size=10, fg=T["muted"]); self._ep_count_lbl.pack(anchor="w", pady=(1, 0))
        self._api_probely_outer = self._card_shadow_wrap(self._build_api_probely_card(pad))
        self._api_orch_outer = self._card_shadow_wrap(self._build_api_orchestrator_card(pad))
        self._refresh_api_advanced_visibility()
        self._refresh_api_creds()
        self._setup_api_field_persistence()

    def _build_api_probely_card(self, pad):
        REPORTS = ["(ninguno)", "owasp", "owasp_web_2021", "owasp_web_2025",
                   "pci", "pci4", "pci_v3_2_1", "pci_v4_0_1",
                   "iso27001", "hipaa", "executive_summary"]
        c = self._card(pad, 'Probely', pady=(0, _CARD_GAP))
        c.columnconfigure(1, weight=1); c.columnconfigure(3, weight=1)

        def L(t, r, col=0): self._lbl(c, t, anchor="e").grid(
            row=r, column=col, sticky="e", padx=(0, 2), pady=1)
        L('Reutilizar target por ID', 1)
        ttk.Entry(c, textvariable=self._api_target_id_var).grid(row=1, column=1, sticky="ew", pady=1)
        rr = tk.Frame(c, bg=T["panel_bg"]); rr.grid(row=1, column=2, columnspan=2, sticky="w", pady=1)
        ToggleSwitch(rr, text="Reutilizar por URL", variable=self._api_reuse_url_var).pack(side="left", padx=(2, 3))
        self._spin(rr, 'Espera máx. (min)', self._api_maxwait_var, 5, 1440, width=6)
        L('Alcance reducido (URLs, una por línea/coma)', 2)
        ttk.Entry(c, textvariable=self._api_reduced_scopes_var).grid(row=2, column=1, columnspan=3, sticky="ew", pady=1)
        L('Secuencia de login (archivo del Probely Recorder)', 3)
        sf = tk.Frame(c, bg=T["panel_bg"]); sf.grid(row=3, column=1, columnspan=3, sticky="ew", pady=1)
        sf.columnconfigure(0, weight=1)
        ttk.Entry(sf, textvariable=self._api_seq_path_var).grid(row=0, column=0, sticky="ew")
        self._icon_square_btn(sf, '📄', self._api_browse_sequence).grid(row=0, column=1, padx=(1, 0))
        tg = tk.Frame(c, bg=T["panel_bg"]); tg.grid(row=4, column=0, columnspan=4, sticky="ew", pady=(2, 0))
        ToggleSwitch(tg, text="Ignorar blackout", variable=self._api_ignore_blackout_var).pack(side="left", padx=(0, 3))
        ToggleSwitch(tg, text="Proteger sesión", variable=self._api_protect_session_var).pack(side="left", padx=(0, 3))
        ToggleSwitch(tg, text="Probar login API antes de escanear", variable=self._api_check_login_var).pack(side="left", padx=(0, 3))
        ToggleSwitch(tg, text="Exigir dominio verificado", variable=self._api_require_verified_var).pack(side="left", padx=(0, 3))
        tg2 = tk.Frame(c, bg=T["panel_bg"]); tg2.grid(row=5, column=0, columnspan=4, sticky="ew", pady=(1, 0))
        self._lbl(tg2, 'Reporte de cumplimiento').pack(side="left", padx=(0, 1))
        ttk.Combobox(tg2, textvariable=self._api_report_var, values=REPORTS, state="readonly", width=18).pack(side="left")
        sep = tk.Frame(c, bg=T["border"], height=1); sep.grid(row=6, column=0, columnspan=4, sticky="ew", pady=2)
        tk.Label(c, text="LOGIN POR ENDPOINT (obtención de token) — opcional",
                 font=(_FUI_TITLE, 12, "bold"), bg=T["panel_bg"], fg=T["card_fg"], anchor="w"
                 ).grid(row=7, column=0, columnspan=4, sticky="w")
        L('URL de login', 8)
        ttk.Entry(c, textvariable=self._api_login_url_var).grid(row=8, column=1, columnspan=3, sticky="ew", pady=1)
        L('Payload de autenticación', 9)
        ttk.Entry(c, textvariable=self._api_login_payload_var).grid(row=9, column=1, columnspan=3, sticky="ew", pady=1)
        L('Media type', 10)
        ttk.Combobox(c, textvariable=self._api_login_media_var,
                     values=["application/json", "application/x-www-form-urlencoded"],
                     state="readonly", width=30).grid(row=10, column=1, sticky="w", pady=1)
        L('Campo del token en la respuesta', 10, 2)
        ttk.Entry(c, textvariable=self._api_login_token_field_var).grid(row=10, column=3, sticky="ew", pady=1)
        L('Cabecera/cookie del token', 11)
        ttk.Entry(c, textvariable=self._api_login_token_param_var).grid(row=11, column=1, sticky="ew", pady=1)
        L('Prefijo del token', 11, 2)
        pf = tk.Frame(c, bg=T["panel_bg"]); pf.grid(row=11, column=3, sticky="ew", pady=1)
        ttk.Entry(pf, textvariable=self._api_login_token_prefix_var, width=10).pack(side="left")
        ttk.Combobox(pf, textvariable=self._api_login_place_var, values=["header", "cookie"],
                     state="readonly", width=8).pack(side="left", padx=(2, 0))
        return c

    def _build_api_orchestrator_card(self, pad):
        """Same account-wide pool as the DAST tab."""
        c = self._card(pad, 'Orquestador', pady=(0, _CARD_GAP))

        opts = tk.Frame(c, bg=T["panel_bg"]); opts.pack(fill="x", pady=(0, 2))
        self._icon_square_btn(opts, '🔄', lambda: self._refresh_pool_status("api")).pack(side="left", padx=(0, 4))
        ToggleSwitch(opts, text="Orquestar el pool automáticamente al escanear",
                        variable=self._dast_orch_var).pack(side="left", padx=(0, 4))
        self._spin(opts, 'Enfriamiento por slot (min)', self._dast_cooldown_var, 0, 1440, width=6)

        self._api_orch_status_var = tk.StringVar(value="")
        tk.Label(c, textvariable=self._api_orch_status_var, font=(_FUI, 10),
                 bg=T["panel_bg"], fg=T["muted"], anchor="w", justify="left",
                 wraplength=900).pack(fill="x", pady=(0, 2))

        tree_frame = tk.Frame(c, bg=T["panel_bg"]); tree_frame.pack(fill="both", expand=True)
        self._api_orch_tree = _make_tree(
            tree_frame, ("target", "type", "url", "scans", "age", "elig"),
            [("Target", 110), ("Tipo", 60), ("URL", 300), ("Escaneos", 200),
             ("Edad", 80), ("Reciclable", 150)], height=6)
        return c

    def _api_browse_sequence(self):
        p = filedialog.askopenfilename(title="Secuencia de login de Probely",
            filetypes=[("Secuencia Probely (JSON)", "*.json"), ("Todos", "*.*")])
        if p: self._api_seq_path_var.set(p)

    def _refresh_api_creds(self):
        self._refresh_creds(self._api_cred_frame, self._api_auth_var, self._api_cred_vars)

    def _refresh_api_advanced_visibility(self):
        show = bool(self._api_advanced_var.get())
        wrap = getattr(self, "_api_adv_wrap", None)
        if wrap is not None:
            if show: wrap.grid()
            else:    wrap.grid_remove()
        for w in getattr(self, "_api_basic_rows", []):
            try:
                if show: w.grid()
                else:    w.grid_remove()
            except Exception:
                pass

        probely = getattr(self, "_api_probely_outer", None)
        orch    = getattr(self, "_api_orch_outer", None)
        for w in (probely, orch):
            if w is not None:
                w.pack_forget()
        if show:
            if probely is not None: probely.pack(fill="x", pady=(0, _CARD_GAP))
            if orch is not None:    orch.pack(fill="x", pady=(0, _CARD_GAP))

    def _browse_api_spec(self):
        p = filedialog.askopenfilename(title="Seleccionar especificación de API",
            filetypes=[("Archivos de especificación","*.json *.yaml *.yml"),("Todos","*.*")])
        if p: self._api_spec_var.set(p)

    def _api_load_spec_file(self, title: str, filetypes: list, log_label: str):
        p = filedialog.askopenfilename(title=title, filetypes=filetypes)
        if p:
            self._api_spec_var.set(p); self._emit_log(f"[api] cargado {log_label}: {p}"); self._api_preview_spec()

    def _api_import_postman(self):
        self._api_load_spec_file("Importar colección Postman",
            [("Colección Postman", "*.json"), ("Todos", "*.*")], "Colección Postman")

    def _api_import_openapi(self):
        self._api_load_spec_file("Importar especificación OpenAPI / Swagger",
            [("OpenAPI/Swagger", "*.json *.yaml *.yml"), ("Todos", "*.*")], "especificación OpenAPI/Swagger")

    def _api_import_graphql(self):
        self._api_schema_type_var.set("graphql")
        self._api_load_spec_file("Importar esquema GraphQL (SDL o endpoint)",
            [("GraphQL", "*.graphql *.gql *.graphqls *.json"), ("Todos", "*.*")], "esquema GraphQL")

    def _api_import_popup(self):
        popup = self._create_popup("Importar especificación")
        self._popup_hdr(popup, "Importar especificación", icon="📥")
        body = tk.Frame(popup, bg=T["bg"]); body.pack(fill="both", expand=True)
        tk.Frame(body, bg=T["bg"]).pack(fill="both", expand=True)
        tk.Label(body, text="Elija el formato a importar:", font=(_FUI, 10), bg=T["bg"], fg=T["muted"]).pack(pady=(0, 7))
        card_row = tk.Frame(body, bg=T["bg"]); card_row.pack(padx=20)
        tk.Frame(body, bg=T["bg"]).pack(fill="both", expand=True)
        def _pick(kind):
            popup.close()
            {"postman": self._api_import_postman,
             "graphql": self._api_import_graphql}.get(kind, self._api_import_openapi)()
        for icon_txt, label, desc, kind in [
            ("📦", "Colección Postman", "Importar una colección Postman v2.1 (.json)", "postman"),
            ("📄", "Swagger / OpenAPI", "Importar una especificación OpenAPI v2/v3 o Swagger\n(.json o .yaml)", "openapi"),
            ("◢", "GraphQL", "Esquema GraphQL (SDL .graphql) o introspección\nde un endpoint", "graphql"),
        ]:
            card = self._choice_card(card_row, icon_txt, label, desc, ipadx=7, ipady=6, padx=5, desc_pady=(2, 5))
            def _mk_click(k=kind):
                def _fn(e=None): _pick(k)
                return _fn
            click_fn = _mk_click(); card.bind("<Button-1>", click_fn)
            for child in card.winfo_children(): child.bind("<Button-1>", click_fn)
            card.bind("<Enter>", lambda e, c=card: c.configure(highlightbackground=T["accent"]))
            card.bind("<Leave>", lambda e, c=card: c.configure(highlightbackground=T["border"]))
        self._popup_foot(popup, ("  Cancelar  ", popup.close, "flat"))

    def _api_export_popup(self):
        rows = self._ep_tree.get_children()
        if not rows:
            self._show_warn_popup("Exportar endpoints", "Sin endpoints — ejecute Vista previa primero."); return
        ops = [{"method": self._ep_tree.set(iid, "method"), "url": self._ep_tree.set(iid, "url"),
                "secured": self._ep_tree.set(iid, "secured"), "body": self._ep_tree.set(iid, "body")} for iid in rows]
        popup = self._create_popup("Exportar endpoints")
        self._popup_hdr(popup, "Exportar endpoints", icon="💾", subtitle=f"{len(ops)} endpoint(s)")
        body = tk.Frame(popup, bg=T["bg"]); body.pack(fill="both", expand=True)
        tk.Frame(body, bg=T["bg"]).pack(fill="both", expand=True)
        tk.Label(body, text="Elija el formato de exportación:", font=(_FUI, 10), bg=T["bg"], fg=T["muted"]).pack(pady=(0, 5))
        card_row = tk.Frame(body, bg=T["bg"]); card_row.pack(padx=15)
        tk.Frame(body, bg=T["bg"]).pack(fill="both", expand=True)
        fmt_var = tk.StringVar(value="CSV"); _cards = {}
        _FORMAT_META = [
            ("CSV", "📊", "Valores separados por comas\nExcel / Sheets"),
            ("JSON", "📋", "Arreglo JSON sin formato\nScripts / APIs"),
            ("YAML", "📄", "Formato YAML\nHerramientas OpenAPI"),
            ("Postman v2.1", "📦", "Colección Postman v2.1\nImportación directa en Postman"),
        ]
        def _refresh_cards(*_):
            for f, c in _cards.items():
                c.configure(highlightbackground=T["accent"] if f == fmt_var.get() else T["border"])
        for fmt, icon_txt, desc in _FORMAT_META:
            card = self._choice_card(card_row, icon_txt, fmt, desc, ipadx=5, ipady=4, padx=3, desc_pady=(2, 4))
            _cards[fmt] = card
            def _mk_click(f=fmt):
                def _click(e=None): fmt_var.set(f)
                return _click
            click_fn = _mk_click(); card.bind("<Button-1>", click_fn)
            for child in card.winfo_children(): child.bind("<Button-1>", click_fn)
            def _enter(e, c=card, f=fmt):
                if f != fmt_var.get(): c.configure(highlightbackground=T["accent_hi"])
            card.bind("<Enter>", _enter)
            card.bind("<Leave>", lambda e: _refresh_cards())
        fmt_var.trace_add("write", _refresh_cards); _refresh_cards()
        def _do_export():
            fmt = fmt_var.get(); popup.close(); self._api_export_converted_with(ops, fmt)
        self._popup_foot(popup, ("  Cancelar  ", popup.close, "flat"), ("💾  Exportar  ", _do_export, "accent"))

    def _api_preview_spec(self):
        src = self._api_spec_var.get().strip()
        if not src:
            self._show_warn_popup("Vista previa", "Configure una especificación primero."); return
        def _load_and_render():
            cfg = self._collect_api_cfg()
            opener, _, hdrs = _make_opener(cfg)
            spec = _api_load_spec(opener, hdrs, cfg, self._emit_log)
            if not spec or not isinstance(spec, dict):
                self._event_queue.put(("log","[api-preview] no se pudo cargar o parsear la especificación.")); return
            if "item" in spec and "paths" not in spec: fmt = "Colección Postman"
            elif spec.get("openapi","").startswith("3"): fmt = f"OpenAPI {spec.get('openapi','3.x')}"
            elif spec.get("swagger","").startswith("2"): fmt = f"Swagger {spec.get('swagger','2.x')}"
            else: fmt = "Formato desconocido"
            base = _api_base_url(spec, cfg, src)
            ops = _api_operations(spec, base or "https://example.com", src)
            self._event_queue.put(("api_preview", (fmt, ops, len(ops))))
        self._run_async(_load_and_render, label="vista previa de especificación")

    def _api_export_converted_with(self, ops, fmt):
        if fmt == "CSV":
            path = filedialog.asksaveasfilename(title="Exportar endpoints como CSV", defaultextension=".csv",
                initialfile="endpoints.csv", filetypes=[("CSV","*.csv"),("Todos","*.*")])
            if not path: return
            import csv
            with open(path,"w",newline="",encoding="utf-8") as f:
                w = csv.DictWriter(f, fieldnames=["method","url","secured","body"]); w.writeheader(); w.writerows(ops)
        elif fmt == "JSON":
            path = filedialog.asksaveasfilename(title="Exportar endpoints como JSON", defaultextension=".json",
                initialfile="endpoints.json", filetypes=[("JSON","*.json"),("Todos","*.*")])
            if not path: return
            Path(path).write_text(json.dumps(ops, indent=2), encoding="utf-8")
        elif fmt == "YAML":
            path = filedialog.asksaveasfilename(title="Exportar endpoints como YAML", defaultextension=".yaml",
                initialfile="endpoints.yaml", filetypes=[("YAML","*.yaml *.yml"),("Todos","*.*")])
            if not path: return
            lines = ["endpoints:\n"]
            for op in ops:
                lines += [f"  - method: {op['method']}\n", f"    url: '{op['url']}'\n",
                          f"    secured: '{op['secured']}'\n", f"    body: '{op['body']}'\n"]
            Path(path).write_text("".join(lines), encoding="utf-8")
        elif fmt == "Postman v2.1":
            path = filedialog.asksaveasfilename(title="Exportar como Colección Postman v2.1", defaultextension=".json",
                initialfile="endpoints_postman.json", filetypes=[("JSON / Postman","*.json"),("Todos","*.*")])
            if not path: return
            items = []
            for op in ops:
                url_parts = op["url"].split("://",1); raw_url = op["url"]
                items.append({"name": f"{op['method']} {raw_url}",
                              "request": {"method": op["method"], "header": [],
                                          "url": {"raw": raw_url,
                                                  "protocol": url_parts[0] if len(url_parts)>1 else "https",
                                                  "host": (url_parts[1].split("/")[0].split(".") if len(url_parts)>1 else []),
                                                  "path": (url_parts[1].split("/")[1:] if len(url_parts)>1 else [])},
                                          "description": f"Auth requerida: {op['secured']}  Tipo de cuerpo: {op['body']}"},
                              "response": []})
            collection = {"info": {"name":"Endpoints exportados",
                                   "schema":"https://schema.getpostman.com/json/collection/v2.1.0/collection.json"},
                          "item": items}
            Path(path).write_text(json.dumps(collection, indent=2), encoding="utf-8")
        else:
            self._show_warn_popup("Exportar endpoints", f"Formato desconocido: {fmt}"); return
        self._log_line(f"[api-export] {fmt} → {path}")
        self._show_info_popup("Exportación completada", f"Se guardaron {len(ops)} endpoint(s) en:\n{path}")

    def _collect_api_cfg(self) -> ApiConfig:
        v = self._api_cred_vars
        def _opt(s):
            s = (s or "").strip()
            return "" if s in ("(predeterminado)", "(ninguno)", "") else s
        return ApiConfig(
            spec_source=self._api_spec_var.get().strip(), base_url=self._api_base_var.get().strip(),
            auth_type=self._api_auth_var.get(), username=v["username"].get(), password=v["password"].get(),
            token=v["token"].get(), cookie=v["cookie"].get(), header_name=v["header_name"].get(),
            header_value=v["header_value"].get(), profile=self._api_profile_var.get(),
            verify_tls=bool(self._api_tls_var.get()), proxy=self._api_proxy_var.get(),
            probely_token=static_scanner.get_probely_key(),
            probely_auth_scheme=static_scanner.get_probely_auth_scheme(),
            probely_region="us",
            probely_api_base=(self._api_apibase_var.get().strip() or "https://api.probely.com"),
            probely_target_id=self._api_target_id_var.get().strip(),
            probely_reuse_by_url=bool(self._api_reuse_url_var.get()),
            probely_scan_profile=_opt(self._api_profile_var.get()),
            probely_max_wait_minutes=float(self._api_maxwait_var.get() or 180),
            probely_reduced_scopes=self._api_reduced_scopes_var.get(),
            probely_ignore_blackout=bool(self._api_ignore_blackout_var.get()),
            probely_compliance_report=_opt(self._api_report_var.get()),
            probely_protect_session=bool(self._api_protect_session_var.get()),
            probely_login_sequence_path=self._api_seq_path_var.get().strip(),
            probely_check_login=bool(self._api_check_login_var.get()),
            probely_require_verified=bool(self._api_require_verified_var.get()),
            probely_api_schema_type=_opt(self._api_schema_type_var.get()),
            probely_api_login_url=self._api_login_url_var.get().strip(),
            probely_api_login_payload=self._api_login_payload_var.get(),
            probely_api_login_media_type=(self._api_login_media_var.get() or "application/json"),
            probely_api_login_token_field=self._api_login_token_field_var.get().strip(),
            probely_api_login_token_param=(self._api_login_token_param_var.get().strip() or "Authorization"),
            probely_api_login_token_prefix=self._api_login_token_prefix_var.get().strip(),
            probely_api_login_place=(self._api_login_place_var.get() or "header"),
            probely_orchestrate=bool(self._dast_orch_var.get()),
            probely_pool_size=5,
            probely_slot_cooldown_minutes=float(self._dast_cooldown_var.get() or 60),
            probely_ledger_path=str(getattr(self, "_reports_root", ".")))

    def _setup_api_field_persistence(self):
        delay = [None]
        def _on_change(*_):
            if delay[0] is not None:
                try: self.after_cancel(delay[0])
                except Exception: pass
            delay[0] = self.after(800, self._save_settings)
        for v in [self._api_spec_var, self._api_base_var, self._api_auth_var,
                  self._api_profile_var, self._api_tls_var, self._api_proxy_var,
                  self._api_region_var, self._api_apibase_var, self._api_target_id_var,
                  self._api_reuse_url_var, self._api_maxwait_var, self._api_reduced_scopes_var,
                  self._api_ignore_blackout_var, self._api_report_var, self._api_protect_session_var,
                  self._api_seq_path_var, self._api_check_login_var,
                  self._api_require_verified_var, self._api_schema_type_var,
                  self._api_login_url_var, self._api_login_payload_var, self._api_login_media_var,
                  self._api_login_token_field_var, self._api_login_token_param_var,
                  self._api_login_token_prefix_var, self._api_login_place_var]:
            try: v.trace_add("write", _on_change)
            except Exception: pass
        for k, v in self._api_cred_vars.items():
            if k not in self._SECRET_KEYS:
                try: v.trace_add("write", _on_change)
                except Exception: pass

    def _restore_api_fields(self):
        saved = getattr(self, "_saved_api_fields", None)
        if not isinstance(saved, dict): return
        try:
            if saved.get("spec"):         self._api_spec_var.set(saved["spec"])
            if "base"     in saved:       self._api_base_var.set(saved["base"])
            if saved.get("auth"):         self._api_auth_var.set(saved["auth"])
            if saved.get("profile"):
                _p = saved["profile"]
                _p = {"passive": "(predeterminado)", "active": "full"}.get(_p, _p)
                self._api_profile_var.set(_p)
            if "tls"      in saved:       self._api_tls_var.set(bool(saved["tls"]))
            if "proxy"    in saved:       self._api_proxy_var.set(saved["proxy"])
            for k, val in (saved.get("creds") or {}).items():
                if k in self._api_cred_vars and k not in self._SECRET_KEYS:
                    self._api_cred_vars[k].set(str(val))
            pb = saved.get("probely") or {}
            if pb:
                _m = {
                    "region": self._api_region_var, "apibase": self._api_apibase_var,
                    "target_id": self._api_target_id_var, "reduced": self._api_reduced_scopes_var,
                    "report": self._api_report_var, "seq_path": self._api_seq_path_var,
                }
                for k, var in _m.items():
                    if k in pb: var.set(str(pb[k]))
                if "reuse_url" in pb:       self._api_reuse_url_var.set(bool(pb["reuse_url"]))
                if "maxwait" in pb:         self._api_maxwait_var.set(int(pb["maxwait"]))
                if "ignore_blackout" in pb: self._api_ignore_blackout_var.set(bool(pb["ignore_blackout"]))
                if "protect" in pb:        self._api_protect_session_var.set(bool(pb["protect"]))
                if "check_login" in pb:    self._api_check_login_var.set(bool(pb["check_login"]))
        except Exception:
            pass

class _DastTabMixin:
    _CRED_KEYS = [
        "username", "password", "token", "cookie", "header_name", "header_value",
        "login_url", "login_data", "selenium_login_url", "selenium_user_selector",
        "selenium_user_value", "selenium_pass_selector", "selenium_pass_value",
        "selenium_submit_selector", "selenium_extra_steps", "selenium_macro",
        "login_success_text", "logout_url_re",
        "selenium_logout_macro",
        "probely_form_login_check_pattern",
        "probely_check_session_url",
        "probely_logout_markers",
    ]
    _DAST_AUTH_FIELDS = {
        "none":     [],
        "basic":    [("username", "Usuario", False), ("password", "Contraseña", True)],
        "bearer":   [("token", "Token Bearer", True)],
        "cookie":   [("cookie", "Valor de cabecera Cookie", False)],
        "header":   [("header_name", "Nombre de cabecera", False), ("header_value", "Valor de cabecera", True)],
        "form":     [("login_url", "URL de la página de login", False),
                     ("login_data", "Campos del formulario (campo=valor&…)", False),
                     ("probely_form_login_check_pattern",
                      "Patrón de verificación de login (regex/texto)", False)],
        "selenium": [("selenium_login_url", "URL de página de login", False),
                     ("selenium_user_selector", "Selector CSS de usuario", False),
                     ("selenium_user_value", "Valor de usuario", False),
                     ("selenium_pass_selector", "Selector CSS de contraseña", False),
                     ("selenium_pass_value", "Valor de contraseña", True),
                     ("selenium_submit_selector", "Selector CSS de enviar", False),
                     ("selenium_extra_steps", "Pasos adicionales JSON", False)],
    }
    _SESSION_FIELDS = [
        ("login_success_text",        "Texto visible SOLO con sesión activa"),
        ("probely_check_session_url", "URL de verificación de sesión (opcional)"),
        ("probely_logout_markers",    "Marcadores de 'sesión cerrada' (uno por línea/coma)"),
        ("logout_url_re",             "Regex de URL de logout (excluir del rastreo)"),
    ]
    _LOGIN_CONDITION_KEYS = [
        "selenium_login_url", "selenium_user_selector", "selenium_user_value",
        "selenium_pass_selector", "selenium_submit_selector", "selenium_extra_steps",
        "selenium_macro", "login_success_text",
    ]
    _LOGOUT_CONDITION_KEYS = ["logout_url_re",
                              "login_success_text", "selenium_logout_macro"]
    _SECRET_KEYS = {"password", "token", "cookie", "header_value",
                    "selenium_pass_value", "login_data"}

    def _build_tab_dast(self, parent):
        pad = self._scrollable(parent)
        self._safety_banner(pad,
            "Asegúrate de que la URL apunte a un entorno que NO sea de producción.")
        body = self._card(pad, 'Objetivo'); body.columnconfigure(1, weight=1)
        self._dast_objetivo_card = body
        def gl(text, r, c): return self._glabel(body, text, r, c)
        gl('URL del objetivo', 0, 0); self._gentry(body, self._dast_url_var, 0, 1, span=3)

        self._dast_basic_rows: list = []
        lbl_auth = self._lbl(body, 'Tipo de autenticación', anchor="e")
        lbl_auth.grid(row=1, column=0, sticky="e", padx=(0, 2), pady=1)
        ac = ttk.Combobox(body, textvariable=self._dast_auth_var,
                          values=["none","basic","bearer","cookie","header","form","selenium"],
                          state="readonly", width=12)
        ac.grid(row=1, column=1, sticky="w", pady=1)
        def _on_dast_auth_change(_evt=None): self._refresh_dast_creds(); self._refresh_dast_sel_card()
        ac.bind("<<ComboboxSelected>>", _on_dast_auth_change)
        lbl_prof = self._lbl(body, 'Perfil de escaneo', anchor="e")
        lbl_prof.grid(row=2, column=0, sticky="e", padx=(0, 2), pady=1)
        prof_row = tk.Frame(body, bg=T["panel_bg"])
        prof_row.grid(row=2, column=1, columnspan=3, sticky="w", pady=1)
        prof_refresh_btn = self._icon_square_btn(prof_row, "↻", lambda: self._refresh_scan_profiles("web"))
        prof_refresh_btn.pack(side="left", padx=(0, 1))
        pc = ttk.Combobox(prof_row, textvariable=self._dast_profile_var,
                          values=["(predeterminado)","lightning","safe","normal","full"],
                          state="readonly", width=14)
        pc.pack(side="left")
        self._dast_profile_cb = pc
        self._dast_basic_rows += [lbl_prof, prof_row]
        self._dast_advanced_var = tk.BooleanVar(value=False)
        adv_row = tk.Frame(body, bg=T["panel_bg"]); adv_row.grid(row=3, column=0, columnspan=4, sticky="w", pady=(2, 0))
        ToggleSwitch(adv_row, text="Avanzado", variable=self._dast_advanced_var,
                     command=self._refresh_dast_advanced_visibility).pack(side="left")

        self._dast_adv_wrap = tk.Frame(body, bg=T["panel_bg"])
        self._dast_adv_wrap.grid(row=4, column=0, columnspan=4, sticky="ew", pady=(1, 0))
        self._dast_cred_frame = tk.Frame(self._dast_adv_wrap, bg=T["panel_bg"])
        self._dast_cred_frame.pack(fill="x")
        self._dast_cred_frame.columnconfigure(1, weight=1)
        scope = tk.Frame(self._dast_adv_wrap, bg=T["panel_bg"]); scope.pack(fill="x", pady=(2, 0))
        ToggleSwitch(scope, text="Detectar logout y re-loguear",
                        variable=self._dast_relogin_var).pack(side="left", padx=(0, 4))
        sel_card = self._card(pad, 'Grabar login', pady=(0, _CARD_GAP)); sel_card.columnconfigure(1, weight=1)
        self._lbl(sel_card, 'Navegador').grid(row=1, column=0, sticky="e", padx=(0, 2))
        labels = self._refresh_browser_catalog()
        sel_browser_cb = ttk.Combobox(sel_card, textvariable=self._dast_browser_label_var,
                                      values=labels, state="readonly", width=18)
        sel_browser_cb.grid(row=1, column=1, sticky="w")
        def _on_browser_pick(_=None):
            key = self._browser_label_key.get(self._dast_browser_label_var.get())
            if key: self._dast_browser_var.set(key)
        sel_browser_cb.bind("<<ComboboxSelected>>", _on_browser_pick)
        sel_opts = tk.Frame(sel_card, bg=T["panel_bg"]); sel_opts.grid(row=2, column=0, columnspan=4, sticky="ew", pady=(1, 0))
        self._spin(sel_opts, 'Tiempo de espera de login (s)', self._dast_selwait_var, 1, 180, width=5, padx=(0, 4))
        macro_row = tk.Frame(sel_card, bg=T["panel_bg"]); macro_row.grid(row=3, column=0, columnspan=4, sticky="ew", pady=(2, 0))
        self._dast_macro_row = macro_row
        tk.Frame(macro_row, bg=T["border"], height=1).pack(fill="x", pady=(0, 2))
        tk.Label(macro_row, text="MACROS", font=(_FUI_TITLE, 12, "bold"),
                 bg=T["panel_bg"], fg=T["card_fg"], anchor="w").pack(anchor="w")
        macro_btns = tk.Frame(macro_row, bg=T["panel_bg"]); macro_btns.pack(fill="x", pady=(1, 0))
        self._macro_recorded = {"login": False, "logout": False}
        self._macro_check_vars = {"login": tk.StringVar(value=""), "logout": tk.StringVar(value="")}

        def _refresh_macro_ui():
            for flag, var in self._macro_check_vars.items():
                var.set("  ✔" if self._macro_recorded[flag] else "")
            lo_btn = getattr(self, "_macro_logout_btn", None)
            if lo_btn: lo_btn.config(state="normal" if self._macro_recorded["login"] else "disabled")

        def _macro_popup(flag, title, icon, desc, record_fn, save_fn, load_fn, rec_tip, save_tip, load_tip):
            popup = self._create_popup(title)
            self._popup_hdr(popup, title, icon=icon)
            body2 = tk.Frame(popup, bg=T["bg"]); body2.pack(fill="both", expand=True)
            tk.Frame(body2, bg=T["bg"]).pack(fill="both", expand=True)
            recorded_now = self._macro_recorded[flag]
            badge_var = tk.StringVar(value="✔  Recorded" if recorded_now else "⬜  Not recorded")
            badge_fg = T["ok"] if recorded_now else T["muted"]
            stat_shadow = self._shadow_wrap(body2, visible=False)
            stat_shadow.pack(fill="x", padx=15)
            stat_frame = tk.Frame(stat_shadow, bg=T["panel_bg"], highlightthickness=0, highlightbackground=T["border"])
            stat_frame.pack(fill="both", expand=True, padx=(0, 0), pady=(0, 0))
            stat_inner = tk.Frame(stat_frame, bg=T["panel_bg"], padx=7, pady=4); stat_inner.pack(fill="x")
            badge_lbl = tk.Label(stat_inner, textvariable=badge_var, font=(_FUI, 10, "bold"), bg=T["panel_bg"], fg=badge_fg)
            badge_lbl.pack(side="left")
            tk.Label(stat_inner, text=desc, font=(_FUI, 10), bg=T["panel_bg"], fg=T["muted"],
                     justify="left", wraplength=900).pack(side="left", padx=(7, 0))
            card_row = tk.Frame(body2, bg=T["bg"]); card_row.pack(padx=15, pady=7)
            tk.Frame(body2, bg=T["bg"]).pack(fill="both", expand=True)

            def _do_record():
                popup.close(); ok = record_fn()
                if ok:
                    self._macro_recorded[flag] = True; _refresh_macro_ui()

            def _do_load():
                popup.close(); load_fn()
                check_key = "selenium_login_url" if flag == "login" else "logout_url_re"
                if self._dast_cred_vars.get(check_key, tk.StringVar()).get().strip():
                    self._macro_recorded[flag] = True; _refresh_macro_ui()

            def _do_clear():
                _CLEAR_KEYS = {
                    "login":  ["selenium_login_url","selenium_user_selector","selenium_user_value",
                               "selenium_pass_selector","selenium_pass_value","selenium_submit_selector",
                               "selenium_extra_steps","selenium_macro","login_success_text"],
                    "logout": ["logout_url_re","login_success_text"],
                }
                for k in _CLEAR_KEYS.get(flag, []):
                    if k in self._dast_cred_vars: self._dast_cred_vars[k].set("")
                self._macro_recorded[flag] = True
                self._macro_recorded[flag] = False
                if flag == "login":
                    for k in _CLEAR_KEYS["logout"]:
                        if k in self._dast_cred_vars: self._dast_cred_vars[k].set("")
                    self._macro_recorded["logout"] = False
                _refresh_macro_ui(); self._refresh_dast_creds()
                badge_var.set("⬜  Not recorded"); badge_lbl.config(fg=T["muted"]); popup.close()

            _actions = [
                ("⏺", "Grabar nueva", rec_tip, _do_record, True, "accent"),
                ("💾", "Guardar…", save_tip, lambda: (popup.close(), save_fn()), recorded_now, "outline"),
                ("📂", "Cargar…", load_tip, _do_load, True, "outline"),
                ("🗑", "Limpiar", f"Restablecer la condición {flag} y limpiar todos los selectores guardados.",
                 _do_clear, recorded_now, "flat"),
            ]
            for ico, lbl, tip, cmd, enabled, _kind in _actions:
                card = self._choice_card(card_row, ico, lbl, tip, enabled=enabled, icon_size=17,
                                         desc_wrap=170, ipadx=4, ipady=3,
                                         padx=2, icon_pady=(4, 2), desc_pady=(1, 4))
                if enabled:
                    def _mk(c=cmd):
                        def _fn(e=None): c()
                        return _fn
                    fn = _mk(); card.bind("<Button-1>", fn)
                    for child in card.winfo_children(): child.bind("<Button-1>", fn)
                    card.bind("<Enter>", lambda e, c=card: c.configure(highlightbackground=T["accent"]))
                    card.bind("<Leave>", lambda e, c=card: c.configure(highlightbackground=T["border"]))
            self._popup_foot(popup, ("  Cerrar  ", popup.close, "flat"))

        login_wrap = tk.Frame(macro_btns, bg=T["panel_bg"]); login_wrap.pack(side="left", padx=(0, 1))
        login_args = ("login", "Macro de inicio de sesión", "⏺",
                      "Grabe una macro nueva, o guarde/cargue una grabada previamente.",
                      self._dast_record_macro, self._dast_save_login_condition, self._dast_load_login_condition,
                      "Abre un navegador real y registra clics de inicio de sesión y campos de formulario.",
                      "Guarda los selectores de login grabados + campos de detección de sesión.\nLas contraseñas nunca se escriben en disco.",
                      "Carga un archivo de condición de login guardado anteriormente.")
        login_btn = self._btn(login_wrap, "Grabar Login", lambda a=login_args: _macro_popup(*a), kind="accent")
        login_btn.pack(side="left")
        tk.Label(login_wrap, textvariable=self._macro_check_vars["login"], font=(_FUI, 10, "bold"),
                 bg=T["panel_bg"], fg=T["ok"]).pack(side="left")
        logout_wrap = tk.Frame(macro_btns, bg=T["panel_bg"]); logout_wrap.pack(side="left", padx=(1, 0))
        logout_args = ("logout", "Exclusión / marcadores de logout", "🚪",
                       "Grabe la acción de logout para EXCLUIRLA del rastreo (Probely no la visitará), "
                       "o configure marcadores de 'sesión cerrada' a mano.",
                       self._dast_record_logout, self._dast_save_logout_condition, self._dast_load_logout_condition,
                       "Abre un navegador, reproduce su login y registra la URL de logout para excluirla.",
                       "Guarda el regex de URL de logout + marcadores de sesión cerrada.",
                       "Carga un archivo de condición de logout guardado.")
        logout_btn = self._btn(logout_wrap, "Exclusión de Logout", lambda a=logout_args: _macro_popup(*a), kind="accent")
        logout_btn.pack(side="left"); logout_btn.config(state="disabled")
        tk.Label(logout_wrap, textvariable=self._macro_check_vars["logout"], font=(_FUI, 10, "bold"),
                 bg=T["panel_bg"], fg=T["ok"]).pack(side="left")
        self._macro_logout_btn = logout_btn
        self._dast_sel_card = sel_card
        self._dast_probely_outer = self._card_shadow_wrap(self._build_dast_probely_card(pad))
        self._dast_orch_outer = self._card_shadow_wrap(self._build_dast_orchestrator_card(pad))
        self._build_dast_2fa_card(pad)
        self._refresh_dast_creds()
        self._refresh_dast_advanced_visibility()
        self._setup_dast_field_persistence()

    def _build_dast_probely_card(self, pad):
        """All Snyk API & Web (Probely) cloud-scan options that the engine honours but the legacy local-scanner UI never…"""
        REPORTS = ["(ninguno)", "owasp", "owasp_web_2021", "owasp_web_2025",
                   "pci", "pci4", "pci_v3_2_1", "pci_v4_0_1",
                   "iso27001", "hipaa", "executive_summary"]
        c = self._card(pad, 'Probely', pady=(0, _CARD_GAP))
        c.columnconfigure(1, weight=1); c.columnconfigure(3, weight=1)

        def L(t, r, col=0): self._lbl(c, t, anchor="e").grid(
            row=r, column=col, sticky="e", padx=(0, 2), pady=1)
        L('Reutilizar target por ID', 2)
        ttk.Entry(c, textvariable=self._dast_target_id_var).grid(row=2, column=1, sticky="ew", pady=1)
        rr = tk.Frame(c, bg=T["panel_bg"]); rr.grid(row=2, column=2, columnspan=2, sticky="w", pady=1)
        ToggleSwitch(rr, text="Reutilizar por URL", variable=self._dast_reuse_url_var).pack(side="left", padx=(2, 3))
        self._spin(rr, 'Espera máx. (min)', self._dast_maxwait_var, 5, 1440, width=6)
        self._spin(rr, 'Sondeo (s)', self._dast_poll_var, 5, 120, width=5, padx=(3, 0))
        L('Alcance reducido (URLs, una por línea/coma)', 3)
        ttk.Entry(c, textvariable=self._dast_reduced_scopes_var).grid(row=3, column=1, columnspan=3, sticky="ew", pady=1)
        L('Lista negra (globs de URL a excluir)', 4)
        ttk.Entry(c, textvariable=self._dast_blacklist_var).grid(row=4, column=1, columnspan=3, sticky="ew", pady=1)
        L('Secuencia de login (archivo del Probely Recorder)', 6)
        sf = tk.Frame(c, bg=T["panel_bg"]); sf.grid(row=6, column=1, columnspan=3, sticky="ew", pady=1)
        sf.columnconfigure(0, weight=1)
        ttk.Entry(sf, textvariable=self._dast_seq_path_var).grid(row=0, column=0, sticky="ew")
        self._icon_square_btn(sf, '📄', self._dast_browse_sequence).grid(row=0, column=1, padx=(1, 0))
        tg = tk.Frame(c, bg=T["panel_bg"]); tg.grid(row=7, column=0, columnspan=4, sticky="ew", pady=(2, 0))
        ToggleSwitch(tg, text="Ignorar blackout", variable=self._dast_ignore_blackout_var).pack(side="left", padx=(0, 3))
        ToggleSwitch(tg, text="Proteger sesión (no fuzzear token)", variable=self._dast_protect_session_var).pack(side="left", padx=(0, 3))
        ToggleSwitch(tg, text="Avisar si el host no es público", variable=self._dast_agent_warn_var).pack(side="left", padx=(0, 3))
        ToggleSwitch(tg, text="Exigir dominio verificado", variable=self._dast_require_verified_var).pack(side="left", padx=(0, 3))
        tg2 = tk.Frame(c, bg=T["panel_bg"]); tg2.grid(row=8, column=0, columnspan=4, sticky="ew", pady=(1, 0))
        self._lbl(tg2, 'Reporte de cumplimiento').pack(side="left", padx=(0, 1))
        ttk.Combobox(tg2, textvariable=self._dast_report_var, values=REPORTS, state="readonly", width=18).pack(side="left", padx=(0, 4))
        self._lbl(tg2, 'Login de formulario').pack(side="left", padx=(0, 1))
        ttk.Combobox(tg2, textvariable=self._dast_form_login_var, values=["auto", "on", "off"], state="readonly", width=8).pack(side="left")
        sep = tk.Frame(c, bg=T["border"], height=1); sep.grid(row=9, column=0, columnspan=4, sticky="ew", pady=2)
        tk.Label(c, text="DETECCIÓN DE LOGOUT (PROBELY)", font=(_FUI_TITLE, 12, "bold"),
                 bg=T["panel_bg"], fg=T["card_fg"], anchor="w").grid(
            row=10, column=0, columnspan=4, sticky="w")
        ld = tk.Frame(c, bg=T["panel_bg"]); ld.grid(row=11, column=0, columnspan=4, sticky="ew", pady=(1, 0))
        self._lbl(ld, 'Condición').pack(side="left", padx=(0, 1))
        ttk.Combobox(ld, textvariable=self._dast_logout_cond_var, values=["any", "all"], state="readonly", width=6).pack(side="left", padx=(0, 3))
        ToggleSwitch(ld, text="Detector por URL de login", variable=self._dast_logout_url_det_var).pack(side="left", padx=(0, 3))
        ToggleSwitch(ld, text="Detector por código 401/403", variable=self._dast_logout_code_det_var).pack(side="left", padx=(0, 3))
        L('Selector CSS visible al estar deslogueado', 12)
        ttk.Entry(c, textvariable=self._dast_logout_selector_var).grid(row=12, column=1, columnspan=3, sticky="ew", pady=1)
        L('Marcadores en el cuerpo (body)', 13)
        ttk.Entry(c, textvariable=self._dast_logout_body_var).grid(row=13, column=1, columnspan=3, sticky="ew", pady=1)
        L('Marcadores en cabecera (Nombre: valor)', 14)
        ttk.Entry(c, textvariable=self._dast_logout_header_var).grid(row=14, column=1, columnspan=3, sticky="ew", pady=1)
        return c

    _ORCH_TREE_COLS = ("target", "type", "url", "scans", "age", "elig")

    def _build_dast_orchestrator_card(self, pad):
        """Pool orchestration."""
        c = self._card(pad, 'Orquestador', pady=(0, _CARD_GAP))

        opts = tk.Frame(c, bg=T["panel_bg"]); opts.pack(fill="x", pady=(0, 2))
        self._icon_square_btn(opts, '🔄', self._refresh_pool_status).pack(side="left", padx=(0, 4))
        ToggleSwitch(opts, text="Orquestar el pool automáticamente al escanear",
                        variable=self._dast_orch_var).pack(side="left", padx=(0, 4))
        self._spin(opts, 'Enfriamiento por slot (min)', self._dast_cooldown_var, 0, 1440, width=6)

        self._dast_orch_status_var = tk.StringVar(value="")
        tk.Label(c, textvariable=self._dast_orch_status_var, font=(_FUI, 10),
                 bg=T["panel_bg"], fg=T["muted"], anchor="w", justify="left",
                 wraplength=900).pack(fill="x", pady=(0, 2))

        tree_frame = tk.Frame(c, bg=T["panel_bg"]); tree_frame.pack(fill="both", expand=True)
        self._dast_orch_tree = _make_tree(
            tree_frame, self._ORCH_TREE_COLS,
            [("Target", 110), ("Tipo", 60), ("URL", 300), ("Escaneos", 200),
             ("Edad", 80), ("Reciclable", 150)], height=6)
        return c

    def _orch_build_client(self):
        """Return (client, orchestrator, cfg) for the current Probely settings, or (None, None, cfg) if no key is configu…"""
        cfg = self._collect_dast_cfg()
        token = (getattr(cfg, "probely_token", "") or "").strip()
        if not token:
            return None, None, cfg
        client = _Probely(token, _resolve_api_base(cfg), self._emit_log,
                          getattr(cfg, "probely_auth_scheme", "JWT"))
        orch = Orchestrator(
            client, PoolLedger(getattr(cfg, "probely_ledger_path", ".") or "."),
            pool_size=int(getattr(cfg, "probely_pool_size", 5) or 5),
            cooldown_minutes=float(getattr(cfg, "probely_slot_cooldown_minutes", 60) or 60),
            log=self._emit_log)
        return client, orch, cfg

    def _orch_status_vars(self):
        return [v for v in (getattr(self, "_dast_orch_status_var", None),
                            getattr(self, "_api_orch_status_var", None)) if v is not None]

    def _orch_trees(self):
        return [t for t in (getattr(self, "_dast_orch_tree", None),
                            getattr(self, "_api_orch_tree", None)) if t is not None]

    def _set_orch_status(self, text: str):
        for v in self._orch_status_vars():
            try: v.set(text)
            except Exception: pass

    def _refresh_pool_status(self, which: str = "web"):
        if getattr(self, "_orch_busy", False):
            return
        client, orch, _ = self._orch_build_client()
        if orch is None:
            self._show_warn_popup("Orquestador de slots",
                "No hay clave de API de Probely configurada. Péguela con el icono 🌐 "
                "de la barra superior y reintente.")
            return
        self._set_orch_status("Consultando el pool en Probely…")
        def _work():
            survey = orch.survey()
            pool = orch.pool_size
            self.after(0, lambda: self._render_pool(survey, pool))
        self._run_async(_work, label="estado del pool",
                        busy_attr="_orch_busy", done_kind="__orch_done__")

    def _render_pool(self, survey, pool_size):
        trees = self._orch_trees()
        if not trees:
            return
        for tree in trees:
            for iid in tree.get_children():
                tree.delete(iid)
            for s in survey:
                tree.insert("", "end", iid=s.target_id, values=(
                    s.target_id, ("API" if s.ttype == "api" else "Web"),
                    s.url or s.name, s.state_human, s.age_human,
                    ("✓ sí" if s.eligible else f"✗ {s.reason}")))
        live = len(survey)
        free = sum(1 for s in survey if s.free)
        elig = sum(1 for s in survey if s.eligible)
        web = sum(1 for s in survey if s.ttype != "api")
        api = sum(1 for s in survey if s.ttype == "api")
        self._set_orch_status(
            f"Pool: {live}/{pool_size} targets vivos ({web} Web · {api} API) · "
            f"{free} sin escaneo activo · {elig} reciclables ahora. "
            + ("Hay capacidad libre." if live < pool_size
               else ("Lleno, pero un slot puede reciclarse." if elig
                     else "Lleno y sin slots reciclables (escaneos activos o en enfriamiento).")))

    def _build_dast_2fa_card(self, pad):
        """TOTP-based 2FA — only relevant on top of form/sequence login."""
        outer = self._card(pad, '2FA', pady=(0, _CARD_GAP))
        outer.columnconfigure(1, weight=1); outer.columnconfigure(3, weight=1)
        self._dast_2fa_card = outer
        ToggleSwitch(outer, text="El objetivo requiere 2FA (TOTP)",
                        variable=self._dast_2fa_var).grid(row=0, column=0, columnspan=4, sticky="w", pady=(0, 1))
        def L(t, r, col=0): self._lbl(outer, t, anchor="e").grid(
            row=r, column=col, sticky="e", padx=(0, 2), pady=1)
        L('Seed / secreto', 1)
        ttk.Entry(outer, textvariable=self._dast_otp_secret_var, show="*").grid(row=1, column=1, columnspan=3, sticky="ew", pady=1)
        L('Selector CSS del campo OTP', 2)
        ttk.Entry(outer, textvariable=self._dast_otp_field_var).grid(row=2, column=1, sticky="ew", pady=1)
        L('Selector CSS de enviar', 2, 2)
        ttk.Entry(outer, textvariable=self._dast_otp_submit_var).grid(row=2, column=3, sticky="ew", pady=1)
        L('Algoritmo', 3)
        ttk.Combobox(outer, textvariable=self._dast_otp_alg_var, values=["SHA1", "SHA256", "SHA512"],
                     state="readonly", width=10).grid(row=3, column=1, sticky="w", pady=1)
        L('Dígitos', 3, 2)
        _dg = tk.Frame(outer, bg=T["panel_bg"]); _dg.grid(row=3, column=3, sticky="w", pady=1)
        self._spin(_dg, '', self._dast_otp_digits_var, 4, 10, width=4)

    def _dast_browse_sequence(self):
        p = filedialog.askopenfilename(title="Secuencia de login de Probely",
            filetypes=[("Secuencia Probely (JSON)", "*.json"), ("Todos", "*.*")])
        if p: self._dast_seq_path_var.set(p)

    def _refresh_scan_profiles(self, which: str):
        """Fetch the REAL scan profiles for this account from Probely and load them into the dropdown (DAST=web, API=api)…"""
        import types as _types
        if which == "api":
            apibase = self._api_apibase_var.get(); ttype = "api"
        else:
            apibase = self._dast_apibase_var.get(); ttype = "web"
        region = "us"
        cfg = _types.SimpleNamespace(
            probely_token=static_scanner.get_probely_key(),
            probely_auth_scheme=static_scanner.get_probely_auth_scheme(),
            probely_api_base=(apibase or "").strip(),
            probely_region=region)
        def _work():
            profs = fetch_scan_profiles(cfg, ttype, self._emit_log)
            self._event_queue.put(("scan_profiles", (which, profs)))
        self._run_async(_work, label="perfiles de escaneo")

    def _refresh_creds(self, frame, auth_var, cred_vars, *, session_fields=False):
        for w in frame.winfo_children(): w.destroy()
        frame.columnconfigure(1, weight=1)
        kind = auth_var.get()
        base = 0
        fields = [f for f in self._DAST_AUTH_FIELDS.get(kind, []) if f[0] in cred_vars]
        for i, (key, label, secret) in enumerate(fields):
            r = base + i
            self._lbl(frame, label, anchor="e").grid(row=r, column=0, sticky="e", padx=(0, 2), pady=1)
            ttk.Entry(frame, textvariable=cred_vars[key], show="*" if secret else "").grid(row=r, column=1, sticky="ew", pady=1)
        if session_fields:
            r0 = base + len(fields)
            tk.Frame(frame, bg=T["border"], height=1).grid(row=r0, column=0, columnspan=2, sticky="ew", pady=2); r0 += 1
            tk.Label(frame, text="DETECCIÓN DE LOGOUT (Probely)", font=(_FUI_TITLE, 12, "bold"),
                     bg=T["panel_bg"], fg=T["card_fg"], anchor="w").grid(row=r0, column=0, columnspan=2, sticky="w"); r0 += 1
            for key, label in self._SESSION_FIELDS:
                self._lbl(frame, label, anchor="e").grid(row=r0, column=0, sticky="e", padx=(0, 2), pady=1)
                ttk.Entry(frame, textvariable=cred_vars[key]).grid(row=r0, column=1, sticky="ew", pady=1); r0 += 1

    def _refresh_dast_creds(self):
        self._refresh_creds(self._dast_cred_frame, self._dast_auth_var, self._dast_cred_vars, session_fields=True)

    def _refresh_dast_advanced_visibility(self):
        show = bool(self._dast_advanced_var.get())
        wrap = getattr(self, "_dast_adv_wrap", None)
        if wrap is not None:
            if show: wrap.grid()
            else:    wrap.grid_remove()
        for w in getattr(self, "_dast_basic_rows", []):
            try:
                if show: w.grid()
                else:    w.grid_remove()
            except Exception:
                pass

        self._refresh_dast_sel_card()

    def _refresh_dast_sel_card(self):
        """Single layout pass for every DAST card whose visibility depends on the selected auth kind and/or the Avanzado…"""
        kind = self._dast_auth_var.get()
        show_sel = kind == "selenium"
        show_2fa = kind in ("form", "selenium")
        show_adv = bool(getattr(self, "_dast_advanced_var", tk.BooleanVar(value=False)).get())

        sel_outer   = self._card_shadow_wrap(self._dast_sel_card)
        card2fa     = getattr(self, "_dast_2fa_card", None)
        o2fa        = self._card_shadow_wrap(card2fa) if card2fa is not None else None
        probely_out = getattr(self, "_dast_probely_outer", None)
        orch_out    = getattr(self, "_dast_orch_outer", None)

        for w in (sel_outer, o2fa, probely_out, orch_out):
            if w is not None:
                w.pack_forget()
        if show_sel:
            sel_outer.pack(fill="x", pady=(0, _CARD_GAP))
        if show_adv:
            if probely_out is not None: probely_out.pack(fill="x", pady=(0, _CARD_GAP))
            if orch_out is not None:    orch_out.pack(fill="x", pady=(0, _CARD_GAP))
        if show_2fa and o2fa is not None:
            o2fa.pack(fill="x", pady=(0, _CARD_GAP))

        mrow = getattr(self, "_dast_macro_row", None)
        if mrow is not None:
            if kind == "selenium": mrow.grid()
            else:                  mrow.grid_remove()

    def _collect_dast_cfg(self) -> DastConfig:
        v = self._dast_cred_vars; g = lambda k: v[k].get()
        browser_key = self._dast_browser_var.get() or "chrome"
        browser_bin = (self._browser_catalog.get(browser_key, {}) or {}).get("binary", "")
        def _opt(s):
            s = (s or "").strip()
            return "" if s in ("(predeterminado)", "(ninguno)", "") else s
        return DastConfig(
            url=self._dast_url_var.get().strip(), auth_type=self._dast_auth_var.get(),
            username=g("username"), password=g("password"), token=g("token"),
            cookie=g("cookie"), header_name=g("header_name"), header_value=g("header_value"),
            login_url=g("login_url"), login_data=g("login_data"), profile=self._dast_profile_var.get(),
            selenium_browser=browser_key,
            selenium_binary=browser_bin, selenium_headless=bool(self._dast_headless_var.get()),
            selenium_wait_seconds=int(self._dast_selwait_var.get() or 15),
            selenium_login_url=g("selenium_login_url"), selenium_user_selector=g("selenium_user_selector"),
            selenium_user_value=g("selenium_user_value"), selenium_pass_selector=g("selenium_pass_selector"),
            selenium_pass_value=g("selenium_pass_value"), selenium_submit_selector=g("selenium_submit_selector"),
            selenium_extra_steps=g("selenium_extra_steps"), selenium_macro=g("selenium_macro"),
            selenium_logout_macro=g("selenium_logout_macro"),
            login_success_text=g("login_success_text"), logout_url_re=g("logout_url_re"),
            auto_relogin=bool(self._dast_relogin_var.get()),
            probely_token=static_scanner.get_probely_key(),
            probely_auth_scheme=static_scanner.get_probely_auth_scheme(),
            probely_region="us",
            probely_api_base=(self._dast_apibase_var.get().strip() or "https://api.probely.com"),
            probely_target_id=self._dast_target_id_var.get().strip(),
            probely_reuse_by_url=bool(self._dast_reuse_url_var.get()),
            probely_scan_profile=_opt(self._dast_profile_var.get()),
            probely_max_wait_minutes=float(self._dast_maxwait_var.get() or 180),
            probely_poll_interval=float(self._dast_poll_var.get() or 15),
            probely_require_verified=bool(self._dast_require_verified_var.get()),
            probely_reduced_scopes=self._dast_reduced_scopes_var.get(),
            probely_extra_hosts="",
            probely_blacklist=self._dast_blacklist_var.get(),
            probely_ignore_blackout=bool(self._dast_ignore_blackout_var.get()),
            probely_compliance_report=_opt(self._dast_report_var.get()),
            probely_protect_session=bool(self._dast_protect_session_var.get()),
            probely_agent_warn=bool(self._dast_agent_warn_var.get()),
            probely_login_sequence_path=self._dast_seq_path_var.get().strip(),
            probely_form_login=(self._dast_form_login_var.get() or "auto"),
            probely_logout_detection=bool(self._dast_relogin_var.get()),
            probely_check_session_url=g("probely_check_session_url").strip(),
            probely_logout_markers=g("probely_logout_markers"),
            probely_logout_condition=(self._dast_logout_cond_var.get() or "any"),
            probely_logout_url_detector=bool(self._dast_logout_url_det_var.get()),
            probely_logout_code_detector=bool(self._dast_logout_code_det_var.get()),
            probely_logout_selector=self._dast_logout_selector_var.get().strip(),
            probely_logout_body_markers=self._dast_logout_body_var.get(),
            probely_logout_header_markers=self._dast_logout_header_var.get(),
            probely_login_url=g("selenium_login_url").strip() or g("login_url").strip(),
            probely_form_login_check_pattern=g("probely_form_login_check_pattern").strip(),
            probely_form_submit_selector=g("selenium_submit_selector").strip(),
            probely_2fa_enabled=bool(self._dast_2fa_var.get()),
            probely_otp_secret=self._dast_otp_secret_var.get().strip(),
            probely_otp_field=self._dast_otp_field_var.get().strip(),
            probely_otp_submit=self._dast_otp_submit_var.get().strip(),
            probely_otp_algorithm=(self._dast_otp_alg_var.get() or "SHA1"),
            probely_otp_digits=int(self._dast_otp_digits_var.get() or 6),
            probely_orchestrate=bool(self._dast_orch_var.get()),
            probely_pool_size=5,
            probely_slot_cooldown_minutes=float(self._dast_cooldown_var.get() or 60),
            probely_ledger_path=str(getattr(self, "_reports_root", ".")))

    def _setup_dast_field_persistence(self):
        delay = [None]
        def _on_change(*_):
            if delay[0] is not None:
                try: self.after_cancel(delay[0])
                except Exception: pass
            delay[0] = self.after(800, self._save_settings)
        for v in [self._dast_url_var, self._dast_auth_var, self._dast_profile_var,
                  self._dast_relogin_var, self._dast_browser_var,
                  self._dast_headless_var, self._dast_selwait_var,
                  self._dast_apibase_var, self._dast_target_id_var,
                  self._dast_reuse_url_var, self._dast_maxwait_var, self._dast_reduced_scopes_var,
                  self._dast_poll_var, self._dast_require_verified_var,
                  self._dast_blacklist_var, self._dast_ignore_blackout_var,
                  self._dast_report_var, self._dast_protect_session_var, self._dast_agent_warn_var,
                  self._dast_seq_path_var, self._dast_form_login_var, self._dast_logout_cond_var,
                  self._dast_logout_url_det_var, self._dast_logout_code_det_var,
                  self._dast_logout_selector_var, self._dast_logout_body_var, self._dast_logout_header_var,
                  self._dast_2fa_var, self._dast_otp_field_var, self._dast_otp_submit_var,
                  self._dast_otp_alg_var, self._dast_otp_digits_var,
                  self._dast_orch_var, self._dast_cooldown_var]:
            try: v.trace_add("write", _on_change)
            except Exception: pass
        for k, v in self._dast_cred_vars.items():
            if k not in self._SECRET_KEYS:
                try: v.trace_add("write", _on_change)
                except Exception: pass

    def _restore_dast_fields(self):
        saved = getattr(self, "_saved_dast_fields", None)
        if not isinstance(saved, dict): return
        try:
            if saved.get("url"):          self._dast_url_var.set(saved["url"])
            if saved.get("auth"):         self._dast_auth_var.set("none" if saved["auth"] == "auto" else saved["auth"])
            if saved.get("profile"):
                _p = saved["profile"]
                _p = {"passive": "(predeterminado)", "active": "full"}.get(_p, _p)
                self._dast_profile_var.set(_p)
            if "relogin"  in saved:       self._dast_relogin_var.set(bool(saved["relogin"]))
            if saved.get("browser"):      self._dast_browser_var.set(saved["browser"])
            if "headless" in saved:       self._dast_headless_var.set(bool(saved["headless"]))
            if "selwait"  in saved:       self._dast_selwait_var.set(int(saved["selwait"]))
            for k, val in (saved.get("creds") or {}).items():
                if k in self._dast_cred_vars and k not in self._SECRET_KEYS:
                    self._dast_cred_vars[k].set(str(val))
            pb = saved.get("probely") or {}
            if pb:
                _m = {
                    "apibase": self._dast_apibase_var,
                    "target_id": self._dast_target_id_var, "reduced": self._dast_reduced_scopes_var,
                    "blacklist": self._dast_blacklist_var,
                    "report": self._dast_report_var, "seq_path": self._dast_seq_path_var,
                    "form_login": self._dast_form_login_var, "logout_cond": self._dast_logout_cond_var,
                    "logout_selector": self._dast_logout_selector_var, "logout_body": self._dast_logout_body_var,
                    "logout_header": self._dast_logout_header_var, "otp_field": self._dast_otp_field_var,
                    "otp_submit": self._dast_otp_submit_var, "otp_alg": self._dast_otp_alg_var,
                }
                for k, var in _m.items():
                    if k in pb: var.set(str(pb[k]))
                if "reuse_url" in pb:       self._dast_reuse_url_var.set(bool(pb["reuse_url"]))
                if "maxwait" in pb:         self._dast_maxwait_var.set(int(pb["maxwait"]))
                if "ignore_blackout" in pb: self._dast_ignore_blackout_var.set(bool(pb["ignore_blackout"]))
                if "protect" in pb:        self._dast_protect_session_var.set(bool(pb["protect"]))
                if "agent_warn" in pb:     self._dast_agent_warn_var.set(bool(pb["agent_warn"]))
                if "logout_url_det" in pb: self._dast_logout_url_det_var.set(bool(pb["logout_url_det"]))
                if "logout_code_det" in pb: self._dast_logout_code_det_var.set(bool(pb["logout_code_det"]))
                if "twofa" in pb:          self._dast_2fa_var.set(bool(pb["twofa"]))
                if "otp_digits" in pb:     self._dast_otp_digits_var.set(int(pb["otp_digits"]))
                if "orchestrate" in pb:    self._dast_orch_var.set(bool(pb["orchestrate"]))
                if "cooldown" in pb:       self._dast_cooldown_var.set(int(pb["cooldown"]))
        except Exception:
            pass

    def _dast_save_condition(self, keys, name, initialfile, note=""):
        data = {k: self._dast_cred_vars[k].get() for k in keys if k in self._dast_cred_vars}
        if data.get("selenium_macro"):
            try:
                steps = json.loads(data["selenium_macro"])
                for s in steps:
                    if isinstance(s, dict) and s.get("kind") == "field" and (
                            s.get("role") == "password" or s.get("ftype") == "password"):
                        s["value"] = ""
                data["selenium_macro"] = json.dumps(steps)
            except Exception:
                pass
        path = filedialog.asksaveasfilename(title=f"Guardar {name}", defaultextension=".json",
            initialfile=initialfile, filetypes=[(name.capitalize(),"*.json"),("All","*.*")])
        if not path: return
        Path(path).write_text(json.dumps(data, indent=2), encoding="utf-8")
        self._emit_log(f"[dast] {name} saved → {path}{note}")

    def _dast_load_condition(self, keys, name):
        path = filedialog.askopenfilename(title=f"Cargar {name}", filetypes=[(name.capitalize(),"*.json"),("All","*.*")])
        if not path: return
        try:
            data = json.loads(Path(path).read_text(encoding="utf-8"))
        except Exception as e:
            self._show_error_popup(f"Cargar {name.title()}", f"No se pudo leer el archivo:\n{e}"); return
        applied = [k for k in keys if k in data and k in self._dast_cred_vars
                   and (self._dast_cred_vars[k].set(str(data[k])) or True)]
        self._refresh_dast_creds()
        self._emit_log(f"[dast] {name} loaded ← {path}  (fields: {', '.join(applied) or 'none'})")

    def _dast_save_login_condition(self):
        self._dast_save_condition(self._LOGIN_CONDITION_KEYS, "login condition",
                                  "dast_login_condition.json", "  (password value excluded)")

    def _dast_load_login_condition(self):
        self._dast_load_condition(self._LOGIN_CONDITION_KEYS, "login condition")

    def _dast_save_logout_condition(self):
        self._dast_save_condition(self._LOGOUT_CONDITION_KEYS, "logout condition", "dast_logout_condition.json")

    def _dast_load_logout_condition(self):
        self._dast_load_condition(self._LOGOUT_CONDITION_KEYS, "logout condition")

    def _record_in_browser(self, err_title, popup_title, instructions, work, *, w_pct=0.32, h_pct=0.30):
        url = (self._dast_cred_vars["selenium_login_url"].get().strip() or self._dast_url_var.get().strip())
        if not url or url == "https://":
            self._show_error_popup(err_title, "Configure una URL objetivo o de login primero."); return None
        done = threading.Event(); result: dict = {}
        cancelled = [False]
        status_box: dict = {"msg": None, "shown": None}
        def _emit_status(msg: str): status_box["msg"] = msg
        driver_ready = threading.Event()
        nav_done = threading.Event()
        result["_nav_done"] = nav_done

        def runner():
            try:
                drv = _make_driver(self._collect_dast_cfg(), headless=False, log=self._emit_log)
                result["_driver"] = drv; driver_ready.set()
                try:
                    work(drv, url, done, result, _emit_status)
                finally:
                    try: drv.quit()
                    except Exception: pass
            except Exception as e:
                result["error"] = repr(e); driver_ready.set()
            finally:
                nav_done.set()
                done.set()

        t = threading.Thread(target=runner, daemon=True); t.start()

        watchdog_stop = threading.Event()
        def _watchdog():
            misses = 0
            if not driver_ready.wait(timeout=30):
                return
            if not nav_done.wait(timeout=60):
                return
            if done.is_set() or watchdog_stop.is_set():
                return
            while not (done.is_set() or watchdog_stop.is_set()):
                drv = result.get("_driver")
                if drv is None:
                    return
                probe_done = threading.Event(); probe_ok = {"v": False}
                def _probe(drv=drv):
                    try:
                        _ = drv.window_handles
                        if _:
                            probe_ok["v"] = True
                    except Exception:
                        probe_ok["v"] = False
                    finally:
                        probe_done.set()
                threading.Thread(target=_probe, daemon=True).start()
                if not probe_done.wait(timeout=3.0) or not probe_ok["v"]:
                    misses += 1
                else:
                    misses = 0
                if misses >= 2:
                    self._emit_log("[record] browser window was closed — cancelling operation.")
                    cancelled[0] = True
                    done.set()
                    try: drv.quit()
                    except Exception: pass
                    return
                if done.wait(timeout=1.5):
                    return

        threading.Thread(target=_watchdog, daemon=True).start()
        HUD_W, HUD_H = 360, 105
        PADDING = 14
        CORNERS = ["ne", "nw", "sw", "se"]
        hud = tk.Toplevel(self)
        hud.overrideredirect(True); hud.attributes("-topmost", True)
        hud.attributes("-alpha", 0.90); hud.resizable(False, False)
        hud._corner_idx = [0]

        def _place_hud(corner: str):
            sw = hud.winfo_screenwidth(); sh = hud.winfo_screenheight()
            if corner == "ne":   x, y = sw - HUD_W - PADDING, PADDING
            elif corner == "nw": x, y = PADDING, PADDING
            elif corner == "sw": x, y = PADDING, sh - HUD_H - PADDING
            else:                x, y = sw - HUD_W - PADDING, sh - HUD_H - PADDING
            hud.geometry(f"{HUD_W}x{HUD_H}+{x}+{y}")

        def _dodge(event=None):
            idx = (hud._corner_idx[0] + 1) % len(CORNERS)
            hud._corner_idx[0] = idx; _place_hud(CORNERS[idx])

        _place_hud(CORNERS[0])
        outer = tk.Frame(hud, bg=T["accent"], padx=1, pady=1); outer.pack(fill="both", expand=True)
        inner = tk.Frame(outer, bg=T["panel_bg"], padx=2, pady=2); inner.pack(fill="both", expand=True)
        tk.Label(inner, text=popup_title, font=(_FUI_TITLE, 14, "bold"), bg=T["panel_bg"], fg=T["accent"]).pack(anchor="w")
        status_var = tk.StringVar(value="⏳  Opening browser…")
        tk.Label(inner, textvariable=status_var, font=(_FUI, 10), bg=T["panel_bg"], fg=T["muted"],
                 wraplength=HUD_W - 24).pack(anchor="w", pady=(1, 1))
        hotkey_lbl = tk.Label(inner, text="Ctrl+Shift+F12  →  capturar     Ctrl+Shift+F11  →  cancelar",
                              font=(_FUI, 10), bg=T["panel_bg"], fg=T["muted"])
        hotkey_lbl.pack(anchor="w")
        for widget in (hud, outer, inner, hotkey_lbl): widget.bind("<Enter>", _dodge, "+")
        ready = [False]
        _hotkey_stop = threading.Event(); _hotkey_cancel = threading.Event()

        def _pynput_listener():
            try:
                from pynput import keyboard as _kb
                _pressed = set()
                def _on_press(key):
                    _pressed.add(key)
                    ctrl = any(k in _pressed for k in (_kb.Key.ctrl, _kb.Key.ctrl_l, _kb.Key.ctrl_r))
                    shift = any(k in _pressed for k in (_kb.Key.shift, _kb.Key.shift_l, _kb.Key.shift_r))
                    if ctrl and shift:
                        if key == _kb.Key.f12: _hotkey_stop.set()
                        elif key == _kb.Key.f11: _hotkey_cancel.set()
                def _on_release(key): _pressed.discard(key)
                with _kb.Listener(on_press=_on_press, on_release=_on_release) as lst:
                    while not done.is_set():
                        if done.wait(0.2): break
                    lst.stop()
            except Exception as ex:
                self._emit_log(f"[hotkey] pynput unavailable ({ex!r}) — "
                               "press Ctrl+Shift+F12 while the Scanner window is focused")

        threading.Thread(target=_pynput_listener, daemon=True).start()

        def _on_key_tk(event):
            ctrl = bool(event.state & 0x4); shift = bool(event.state & 0x1)
            if ctrl and shift and event.keysym == "F12": _hotkey_stop.set()
            elif ctrl and shift and event.keysym == "F11": _hotkey_cancel.set()

        _key_bind_id = self.bind("<KeyPress>", _on_key_tk, "+")
        hud.bind("<KeyPress>", _on_key_tk, "+")

        def _poll_hotkeys():
            if _hotkey_cancel.is_set():
                cancelled[0] = True; done.set(); return
            if _hotkey_stop.is_set() and ready[0]:
                done.set(); return
            hud.after(150, _poll_hotkeys)

        hud.after(150, _poll_hotkeys)

        def _poll_ready():
            if driver_ready.is_set():
                if "error" not in result:
                    if status_box.get("msg") is None:
                        status_var.set("✅  Browser open — interact freely")
                    ready[0] = True
                else:
                    status_var.set("❌  Browser failed")
                return
            hud.after(200, _poll_ready)

        hud.after(200, _poll_ready)

        def _poll_status():
            m = status_box.get("msg")
            if m is not None and m != status_box.get("shown"):
                status_var.set(m); status_box["shown"] = m
            if not (done.is_set() or cancelled[0]): hud.after(180, _poll_status)

        hud.after(180, _poll_status)

        def _poll_done():
            if done.is_set() or cancelled[0]:
                try: self.unbind("<KeyPress>", _key_bind_id)
                except Exception: pass
                try: hud.destroy()
                except Exception: pass
                return
            hud.after(300, _poll_done)

        hud.after(300, _poll_done)
        self.wait_window(hud)
        t.join(timeout=1.5 if (cancelled[0] or result.get("_cancelled")) else 10)
        if cancelled[0] or result.get("_cancelled") or "error" in result:
            if "error" in result:
                self._show_error_popup(err_title, f"Error del navegador:\n{result['error']}")
            return None
        result["_url"] = url
        return result

    def _dast_record_macro(self):
        work = record_macro_work(self._collect_dast_cfg(), emit_log=self._emit_log)
        result = self._record_in_browser("Grabar condición de login", "⏺ Condición de login",
                                         [], work, w_pct=0.32, h_pct=0.30)
        if result is None: return False
        url = result["_url"]
        try: macro = json.loads(result.get("macro") or "[]")
        except Exception: macro = []
        if not isinstance(macro, list): macro = []
        macro = [s for s in macro if isinstance(s, dict)]
        user_sel, user_val, pass_sel, pass_val, submit_sel = self._analyze_login_macro(macro)
        submit_extra = None
        if not submit_sel:
            sub = next((s for s in macro if s.get("kind") == "submit"), None)
            ent = next((s for s in macro if s.get("kind") == "enter"), None)
            if sub and sub.get("button"): submit_sel = sub["button"]
            elif sub and sub.get("form"): submit_extra = {"submit": sub["form"]}
            elif ent and ent.get("form"): submit_extra = {"submit": ent["form"]}
            elif ent: submit_extra = {"key": "Enter", "selector": ent.get("selector") or pass_sel}
        if user_sel: self._dast_cred_vars["selenium_user_selector"].set(user_sel)
        if user_val: self._dast_cred_vars["selenium_user_value"].set(user_val)
        if pass_sel: self._dast_cred_vars["selenium_pass_selector"].set(pass_sel)
        if pass_val: self._dast_cred_vars["selenium_pass_value"].set(pass_val)
        self._dast_cred_vars["selenium_submit_selector"].set(submit_sel or "")
        if not self._dast_cred_vars["selenium_login_url"].get():
            self._dast_cred_vars["selenium_login_url"].set(url)
        _LOGOUT_RE = _re.compile(
            r"(?i)(logout|log[\s_-]?out|sign[\s_-]?out|signoff|cerrar[\s_-]?sesi[oó]n|salir)")
        extras: list = []
        for s in macro:
            kind = s.get("kind"); sel = s.get("selector")
            if kind == "field" and sel and sel not in (user_sel, pass_sel)\
                    and s.get("role") != "password" and s.get("value"):
                extras.append({"selector": sel, "value": s["value"]})
            elif kind == "click" and sel and sel != submit_sel:
                blob = f"{sel} {s.get('text','')}"
                if _LOGOUT_RE.search(blob): continue
                extras.append({"click": sel})
        if submit_extra: extras.append(submit_extra)
        self._dast_cred_vars["selenium_extra_steps"].set(json.dumps(extras) if extras else "")
        literal: list = []
        for s in macro:
            if s.get("kind") == "click":
                blob = f"{s.get('selector','')} {s.get('text','')}"
                if _LOGOUT_RE.search(blob): continue
            literal.append(s)
        self._dast_cred_vars["selenium_macro"].set(json.dumps(literal) if literal else "")
        submit_desc = (submit_sel if submit_sel else "Enter / enviar formulario" if submit_extra else "(no detectado)")
        self._emit_log(f"[macro] captured {len(macro)} interactions — "
                       f"user={user_sel!r} pass={pass_sel!r} submit={submit_desc!r}")
        pass_note = ("✔ captured (runtime only)" if pass_val
                     else "(type it in Password value before recording Logout)")
        self._show_info_popup("Condición de login",
            f"Se capturaron {len(macro)} interacciones.\n\n"
            f"Selector de usuario:  {user_sel or '(no detectado)'}\n"
            f"Selector de contraseña: {pass_sel or '(no detectado)'}\n"
            f"Valor de contraseña:    {pass_note}\n"
            f"Enviar:                 {submit_desc}\n\n"
            "Enviar es la acción que envía el formulario de login — un clic en botón, "
            "or an Enter / form submit when there's no button.\n"
            "The password is held only in this session and is wiped when you "
            "close the program; it's never written to any saved file.")
        self._refresh_dast_creds()
        return True

    @staticmethod
    def _analyze_login_macro(macro: list) -> tuple:
        return analyze_login_macro(macro)

    def _dast_record_logout(self):
        cfg = self._collect_dast_cfg()
        pass_sel = cfg.selenium_pass_selector
        pass_val = cfg.selenium_pass_value
        password_missing = bool(pass_sel and not pass_val)
        if password_missing:
            self._show_info_popup("Condición de logout — se requiere login manual",
                "Su login fue grabado, pero la contraseña no se guardó "
                "(passwords are never written to disk).\n\n"
                "The browser will open at the login page. Log in by hand, go to "
                "the logged-OUT page, then press Ctrl+Shift+F12 to capture.\n\n"
                "Tip: type your password into the “Password value” field of the "
                "credentials section first and the login will replay itself "
                "automatically next time.")
        work = record_logout_work(cfg, emit_log=self._emit_log)
        result = self._record_in_browser("Record Logout Condition", "⏺ Logout Condition",
                                         [], work, w_pct=0.34, h_pct=0.32)
        if result is None: return False
        final_url = result.get("final_url","").strip()
        logout_macro = result.get("logout_macro", [])
        logout_hrefs = result.get("logout_href_candidates", [])
        last_click = result.get("last_logout_click", {})
        snapshot = result.get("snapshot", {})
        hints = snapshot.get("hints", [])
        page_title = snapshot.get("title","")
        if logout_macro and last_click and last_click.get("selector"):
            last_sel = last_click["selector"]
            macro_sels = [s.get("selector","") for s in logout_macro if s.get("kind") == "click"]
            if last_sel not in macro_sels:
                logout_macro = list(logout_macro) + [{
                    "kind": "click", "selector": last_click.get("selector", ""),
                    "fallback_selectors": last_click.get("fallback_selectors", []),
                    "href": last_click.get("href", ""), "text": last_click.get("text", ""),
                    "el_id": last_click.get("el_id", ""), "el_cls": last_click.get("el_cls", ""),
                    "data_action": last_click.get("data_action", ""),
                }]
                self._emit_log("[logout-rec] appended last click to macro (no kw match)")
        elif not logout_macro and last_click and last_click.get("selector"):
            logout_macro = [{
                "kind": "click", "selector": last_click.get("selector", ""),
                "fallback_selectors": last_click.get("fallback_selectors", []),
                "href": last_click.get("href", ""), "text": last_click.get("text", ""),
                "el_id": last_click.get("el_id", ""), "el_cls": last_click.get("el_cls", ""),
                "data_action": last_click.get("data_action", ""),
            }]
            self._emit_log("[logout-rec] built 1-step macro from last click (no macro recorded)")
        _LOGOUT_KW = ("logout","log-out","signout","sign-out","cerrar","salir")
        def _path_of(u):
            try:
                from urllib.parse import urlparse as _up2
                p = _up2(u if "://" in u else "https://x" + u).path.rstrip("/") or "/"
                return p if p != "/" else None
            except Exception:
                return None
        proposed_re = ""; best_path = None
        for h in logout_hrefs:
            p = _path_of(h)
            if p and any(k in p.lower() for k in _LOGOUT_KW): best_path = p; break
        if not best_path:
            for h in logout_hrefs:
                p = _path_of(h)
                if p: best_path = p; break
        if not best_path and final_url: best_path = _path_of(final_url)
        if not best_path and last_click.get("href"): best_path = _path_of(last_click["href"])
        if best_path: proposed_re = _re.escape(best_path) + r"(\?|$)"
        self._emit_log(f"[logout-rec] proposed_re={proposed_re!r} from path={best_path!r}")
        confirm = self._create_popup("Condición de logout — revisar y confirmar")
        self._popup_hdr(confirm, "Condición de logout", subtitle="revisar señales capturadas", icon="🔓")
        _cb: dict = {"apply": lambda: None}
        foot = tk.Frame(confirm, bg=T["panel_bg"], padx=7, pady=3); foot.pack(side="bottom", fill="x")
        self._btn(foot, "Aplicar", lambda: _cb["apply"](), "accent").pack(side="right", padx=(2, 0))
        self._btn(foot, "Cancelar", lambda: confirm.close(), "flat").pack(side="right", padx=(2, 0))
        tk.Frame(confirm, bg=T["border"], height=1).pack(side="bottom", fill="x")
        canvas = tk.Canvas(confirm, bg=T["bg"], highlightthickness=0, bd=0)
        vsb = ttk.Scrollbar(confirm, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y"); canvas.pack(side="left", fill="both", expand=True)
        cbody = tk.Frame(canvas, bg=T["bg"], padx=7, pady=4)
        cwin = canvas.create_window((0, 0), window=cbody, anchor="nw")
        def _sync_scroll(_e=None): canvas.configure(scrollregion=canvas.bbox("all"))
        def _sync_width(e): canvas.itemconfigure(cwin, width=e.width)
        cbody.bind("<Configure>", _sync_scroll); canvas.bind("<Configure>", _sync_width)
        def _wheel(e):
            try: canvas.yview_scroll(-1 * int(e.delta / 120), "units")
            except Exception: pass
        canvas.bind("<MouseWheel>", _wheel); cbody.bind("<MouseWheel>", _wheel)
        cbody.columnconfigure(1, weight=1)
        row_idx = [0]
        def _row(widget_or_text, *, col=0, span=1, sticky="w", advance=True, **gkw):
            w = widget_or_text
            if isinstance(w, str):
                w = self._lbl(cbody, w, size=10, fg=T["muted"], wraplength=430, anchor="w"); span = 2
            w.grid(row=row_idx[0], column=col, columnspan=span, sticky=sticky, **gkw)
            if advance: row_idx[0] += 1
            return w
        def _field(label, value_var):
            _row(self._lbl(cbody, label, anchor="e"),
                 sticky="e", advance=False, padx=(0, 2), pady=1)
            e = ttk.Entry(cbody, textvariable=value_var); _row(e, col=1, sticky="ew", pady=1); return e
        _row(self._lbl(cbody, "URL capturada", anchor="e"),
             sticky="e", advance=False, padx=(0, 2), pady=1)
        _row(self._lbl(cbody, final_url or "(none)", size=10, fg=T["text"], anchor="w", wraplength=420), col=1)
        re_var = tk.StringVar(value=proposed_re)
        _row(self._lbl(cbody, "Regex de URL de logout", anchor="e"),
             sticky="e", advance=False, padx=(0, 2), pady=1)
        _re_entry = ttk.Entry(cbody, textvariable=re_var); _row(_re_entry, col=1, sticky="ew", pady=1)
        regex_hint = (
            "URLs matching this regex are SKIPPED so the scanner never logs itself out.\n"
            + ("⚠  Captured URL was root (/). Enter the path the app redirects to after "
               "logout (e.g. /login or /signin). Leave blank if the app stays at / — "
               "use Logged-in selector/text below for session detection instead."
               if not proposed_re else
               "Regex must match a specific path (e.g. /login or /logout). "
               "Avoid patterns that match / — they are too broad and will be rejected."))
        _row(regex_hint)
        _row(tk.Frame(cbody, bg=T["border"], height=1), span=2, sticky="ew", pady=2)
        _row(tk.Label(cbody, text="DETECCIÓN DE SESIÓN", font=(_FUI_TITLE, 12, "bold"),
                      bg=T["panel_bg"], fg=T["card_fg"], anchor="w"), span=2)
        _row("Optionally tell the scanner what a LOGGED-IN page looks like "
             "so it can detect session loss mid-scan and re-authenticate.")
        txt_var = tk.StringVar(value=self._dast_cred_vars["login_success_text"].get())
        _field("Texto de sesión activa", txt_var)
        _row("Text ONLY visible when logged in (e.g. 'My Account'). Used by Probely "
             "as the login-confirmation pattern (form_login_check_pattern).")
        if logout_macro:
            _row(tk.Frame(cbody, bg=T["border"], height=1), span=2, sticky="ew", pady=(2, 1))
            _row(tk.Label(cbody, text="ACCIÓN DE LOGOUT GRABADA", font=(_FUI_TITLE, 12, "bold"),
                          bg=T["panel_bg"], fg=T["card_fg"], anchor="w"), span=2)
            click_steps = [s for s in logout_macro if s.get("kind") == "click"]
            _row(f"✓ {len(logout_macro)} step(s) recorded "
                 f"({len(click_steps)} click(s)). The last click is treated as the logout action.")
            if last_click and last_click.get("selector"):
                lc_text = (last_click.get("text") or "").strip()
                lc_sel = (last_click.get("selector") or "").strip()
                lc_id = (last_click.get("el_id") or "").strip()
                lc_href = (last_click.get("href") or "").strip()
                lc_data = (last_click.get("data_action") or "").strip()
                if lc_text: _row(f"  · Button text: “{lc_text}”")
                if lc_sel: _row(f"  · CSS selector: {lc_sel[:70]}")
                if lc_id: _row(f"  · Element id: {lc_id}")
                if lc_data: _row(f"  · data-action: {lc_data}")
                if lc_href and lc_href not in ("#", "javascript:void(0)", "javascript:;"):
                    _row(f"  · Navigates to: {lc_href[:70]}")
                else:
                    _row("  · No navigation URL (SPA button) — protection is "
                         "by element identity, not URL.")
        if hints or page_title or snapshot.get("has_password_field") or snapshot.get("has_login_form"):
            _row(tk.Frame(cbody, bg=T["border"], height=1), span=2, sticky="ew", pady=(2, 1))
            _row("Signals detected on logout page (for reference):")
            strong = []
            if snapshot.get("has_password_field"): strong.append("password field present (typical of a login page)")
            if snapshot.get("has_login_form"): strong.append("login form present")
            for s in strong: _row(f"  ✓ {s}")
            clean_hints = []
            for h in hints:
                h = _re.sub(r"\s+", " ", str(h)).strip()[:80]
                if h and h not in clean_hints: clean_hints.append(h)
            for h in ([f"Page title: {page_title}"] if page_title else []) + clean_hints[:8]:
                _row(f"  · {h}")
        elif not final_url:
            _row(tk.Frame(cbody, bg=T["border"], height=1), span=2, sticky="ew", pady=(2, 1))
            _row("⚠️  No page data was captured. Make sure you pressed "
                 "Ctrl+Shift+F12 *while on the logged-out page* (the browser "
                 "must still be open). You can type the Logout URL regex above "
                 "by hand and Apply.")
        applied: list[bool] = [False]
        def _apply():
            re_val = re_var.get().strip(); txt_val = txt_var.get().strip()
            if re_val: self._dast_cred_vars["logout_url_re"].set(re_val)
            if txt_val: self._dast_cred_vars["login_success_text"].set(txt_val)
            if logout_macro:
                self._dast_cred_vars["selenium_logout_macro"].set(json.dumps(logout_macro))
                self._emit_log(f"[logout-rec] logout macro saved ({len(logout_macro)} steps)")
            else:
                self._emit_log("[logout-rec] WARNING: 0 logout steps recorded — "
                               "open user menu and click Log Out while recorder is running")
            applied[0] = True
            self._emit_log(f"[logout-rec] applied — regex={re_val!r} text={txt_val!r}")
            self._refresh_dast_creds(); confirm.close()
        _cb["apply"] = _apply
        def _bind_wheel_rec(w):
            try: w.bind("<MouseWheel>", _wheel)
            except Exception: pass
            for child in w.winfo_children(): _bind_wheel_rec(child)
        _bind_wheel_rec(cbody)
        self.wait_window(confirm._win)
        if not applied[0]:
            self._emit_log("[logout-rec] cancelled — no changes applied"); return False
        return True

    def _refresh_browser_catalog(self) -> list[str]:
        catalog = {}
        try:
            catalog = detect_browsers() or {}
        except Exception:
            catalog = {}
        if not catalog:
            catalog = {"chrome": {"name": "Google Chrome", "binary": "", "engine": "chromium"}}
        self._browser_catalog = catalog
        self._browser_label_key = {info["name"]: key for key, info in catalog.items()}
        labels = [info["name"] for info in catalog.values()]
        cur_key = self._dast_browser_var.get()
        if cur_key not in catalog:
            cur_key = next(iter(catalog)); self._dast_browser_var.set(cur_key)
        self._dast_browser_label_var.set(catalog[cur_key]["name"])
        return labels