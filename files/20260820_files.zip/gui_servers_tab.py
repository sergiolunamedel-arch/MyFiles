from __future__ import annotations

"""gui_servers_tab.py — Server Inventory for SecOps Tenable · Banco Base.

Analogous to gui_apps_tab.py's Application Inventory in the Snyk scanner, but
keyed on infrastructure *servers* (IP / host / CIDR) instead of application
repos, and using Tenable's five-level severity model (critical/high/medium/
low/info) instead of Snyk's.

Persistence model:
    - Add a server once (name, target, scan template, scanner routing,
      ownership/classification metadata).
    - "📂 Cargar" loads that server's target + scan template + scanner into
      the Scan tab so it can be reviewed and re-launched with a single
      click of ▶ Run scan, without retyping anything.
    - Every completed scan against the currently-loaded server writes its
      severity counts back into that server's profile (risk tier + a
      rolling scan-history trend), so the inventory always reflects the
      latest posture.

Unlike gui_apps_tab.py (which is wired into the Snyk scanner's borderless
custom-popup chrome via a module-global injection trick — _apply_panel_chrome,
_popup_hdr, _popup_foot, ToggleSwitch, etc.), this module deliberately uses
Tenable_Scanner_GUI.py's own, simpler building blocks (plain tk.Toplevel
dialogs, messagebox confirmations, the existing _card/_panel/_lbl/_btn/
_scrollable helpers) so it matches that app's actual visual language instead
of importing machinery that doesn't exist there.

Only a handful of shared globals are still injected by the main app before
any UI code here runs (mirroring the Snyk scanner's pattern, just with a much
smaller surface): T (palette dict — mutated in place, so this module always
sees the live theme), _FUI, _FMONO, APP_BRAND_NAME, SCAN_TEMPLATES,
_TEMPLATE_LABELS. See _wire_servers_globals() in Tenable_Scanner_GUI.py.
"""

import json
import re
import threading
from datetime import datetime, timedelta
from pathlib import Path
from tkinter import ttk, messagebox
from typing import Optional
import tkinter as tk

# ══════════════════════════════════════════════════════════════════════════
#  Classification vocabularies (kept local — no fabricated hostname catalog;
#  unlike Snyk's _BANK_APPS dropdown, real server names/IPs aren't invented)
# ══════════════════════════════════════════════════════════════════════════
_RISK_COLORS_LIGHT = {
    "Crítico": "#c8102e",
    "Alto":     "#e26020",
    "Medio":   "#d4a017",
    "Bajo":      "#1a7a4a",
    "Ninguno":     "#5a6475",
}
_RISK_COLORS_DARK = {
    "Crítico": "#f08090",
    "Alto":     "#f4a460",
    "Medio":   "#f0d060",
    "Bajo":      "#5fe0a0",
    "Ninguno":     "#8892a4",
}

_SERVER_TYPES = [
    "Servidor Físico", "Máquina Virtual", "Instancia en la Nube (AWS)",
    "Instancia en la Nube (Azure)", "Instancia en la Nube (GCP)",
    "Servidor de Base de Datos", "Controlador de Dominio",
    "Host de Contenedores", "Balanceador de Carga",
    "Firewall / Dispositivo de Red", "Servidor de Aplicaciones",
    "Servidor Web", "Servidor de Archivos", "Estación de Trabajo", "Otro",
]

_OS_FAMILIES = [
    "Windows Server", "Linux (RHEL / CentOS)", "Linux (Ubuntu / Debian)",
    "Linux (Otro)", "Unix (AIX / Solaris)", "Sistema de Red (Cisco IOS, etc.)",
    "macOS", "Desconocido / Otro",
]

_ENVIRONMENTS = [
    "Producción", "Preproducción / Staging", "QA / Pruebas",
    "Desarrollo", "Interno / Intranet", "Nube (AWS)", "Nube (Azure)",
    "Nube (GCP)", "En sitio (On-Premise)", "Híbrido",
]

_CRITICALITY_LEVELS = [
    "Crítico para la Misión",
    "Crítico para el Negocio",
    "Importante",
    "Estándar",
    "Bajo",
]

_DATA_CLASSIFICATION = [
    "Confidencial — Financiero",
    "Confidencial — Personal",
    "Restringido",
    "Interno",
    "Público",
]

_EMPTY_SERVER: dict = {
    "id":            "",
    "name":          "",
    "description":   "",
    "owner":         "",
    "owner_email":   "",
    "created_at":    "",
    "updated_at":    "",

    "server_type":   _SERVER_TYPES[0],
    "os_family":     _OS_FAMILIES[0],
    "environment":   _ENVIRONMENTS[0],
    "criticality":   _CRITICALITY_LEVELS[1],
    "data_class":    _DATA_CLASSIFICATION[0],
    "compliance":    [],

    "target":        "",   # single IP / hostname / CIDR — the scan target
    "scan_template": "",   # key into SCAN_TEMPLATES, e.g. "basic"
    "scanner":       "",   # Tenable VM cloud scanner routing (name/uuid)
    "agent_group":   "",   # Agent Group name — when set, scan runs via
                           # linked Nessus Agents instead of a network probe
                           # (overrides target; see run_scan/agent_group_ids)

    "last_scan":     None,
    "last_template": "",
    "vuln_critical": 0,
    "vuln_high":     0,
    "vuln_medium":   0,
    "vuln_low":      0,
    "vuln_info":     0,
    "vuln_total":    0,
    "risk_tier":     "Ninguno",

    "scan_history":  [],

    "notes":         "",
}


def _slugify(name: str) -> str:
    """Convert a human name to a safe filename slug."""
    s = name.strip().lower()
    s = re.sub(r"[^\w\s-]", "", s)
    s = re.sub(r"[\s_-]+", "_", s)
    return s[:48] or "server"


def _risk_tier(critical: int, high: int, medium: int, low: int) -> str:
    if critical:  return "Crítico"
    if high:      return "Alto"
    if medium:    return "Medio"
    if low:       return "Bajo"
    return "Ninguno"


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%dT%H:%M:%S")


# ══════════════════════════════════════════════════════════════════════════
#  Persistence
# ══════════════════════════════════════════════════════════════════════════
class ServerInventoryStore:
    """Thread-safe JSON store for server profiles."""

    def __init__(self, reports_root: Path):
        self._lock   = threading.Lock()
        self.inv_dir = reports_root / "servers"
        self.inv_dir.mkdir(parents=True, exist_ok=True)
        self._index_path = self.inv_dir / "_index.json"

    def _read_index(self) -> list[str]:
        try:
            if self._index_path.exists():
                return json.loads(self._index_path.read_text("utf-8"))
        except Exception:
            pass
        ids = sorted(
            p.stem for p in self.inv_dir.glob("*.json")
            if p.name != "_index.json"
        )
        self._write_index(ids)
        return ids

    def _write_index(self, ids: list[str]) -> None:
        self._index_path.write_text(json.dumps(ids, indent=2), "utf-8")

    def _server_path(self, server_id: str) -> Path:
        return self.inv_dir / f"{server_id}.json"

    def list_servers(self) -> list[dict]:
        with self._lock:
            ids = self._read_index()
            out = []
            for sid in ids:
                p = self._server_path(sid)
                if p.exists():
                    try:
                        out.append(json.loads(p.read_text("utf-8")))
                    except Exception:
                        pass
            return out

    def get_server(self, server_id: str) -> Optional[dict]:
        with self._lock:
            p = self._server_path(server_id)
            if p.exists():
                try:
                    return json.loads(p.read_text("utf-8"))
                except Exception:
                    pass
        return None

    def save_server(self, server: dict) -> None:
        """Create or update a server profile. Generates id if missing."""
        with self._lock:
            if not server.get("id"):
                server["id"] = _slugify(server.get("name", "server"))
            existing = self._read_index()
            if server["id"] not in existing:
                base = server["id"]; n = 1
                while (self.inv_dir / f"{server['id']}.json").exists():
                    server["id"] = f"{base}_{n}"; n += 1
                existing.append(server["id"])
                self._write_index(existing)
            server["updated_at"] = _now()
            if not server.get("created_at"):
                server["created_at"] = server["updated_at"]
            self._server_path(server["id"]).write_text(
                json.dumps(server, indent=2, ensure_ascii=False), "utf-8")

    def delete_server(self, server_id: str) -> None:
        with self._lock:
            ids = self._read_index()
            if server_id in ids:
                ids.remove(server_id)
                self._write_index(ids)
            p = self._server_path(server_id)
            if p.exists():
                p.unlink()

    def record_scan(self, server_id: str, meta: dict) -> None:
        """Update vuln counts + risk tier from a completed scan's meta dict.

        `meta` = {"counts": {"critical","high","medium","low","info"},
                  "total": int, "template": scan_template_key}
        """
        server = self.get_server(server_id)
        if server is None:
            return
        counts = meta.get("counts", {})
        c    = int(counts.get("critical", 0) or 0)
        h    = int(counts.get("high", 0) or 0)
        m    = int(counts.get("medium", 0) or 0)
        lo   = int(counts.get("low", 0) or 0)
        info = int(counts.get("info", 0) or 0)
        tot  = int(meta.get("total", c + h + m + lo + info) or 0)
        server["last_scan"]     = _now()
        server["last_template"] = meta.get("template", "")
        server["vuln_critical"] = c
        server["vuln_high"]     = h
        server["vuln_medium"]   = m
        server["vuln_low"]      = lo
        server["vuln_info"]     = info
        server["vuln_total"]    = tot
        server["risk_tier"]     = _risk_tier(c, h, m, lo)
        server.setdefault("scan_history", []).append({
            "ts":       server["last_scan"],
            "template": server["last_template"],
            "critical": c, "high": h, "medium": m, "low": lo, "info": info,
            "total":    tot,
        })
        server["scan_history"] = server["scan_history"][-50:]
        self.save_server(server)


# ══════════════════════════════════════════════════════════════════════════
#  Editor dialog
# ══════════════════════════════════════════════════════════════════════════
class ServerProfileEditor(tk.Toplevel):
    """Modal dialog to create or edit a server profile."""

    def __init__(self, master, store: ServerInventoryStore, server: Optional[dict] = None):
        super().__init__(master)
        self._store  = store
        self._server = dict(_EMPTY_SERVER)
        if server:
            self._server.update(server)
        self.result: Optional[dict] = None
        self.auto_load_var = tk.BooleanVar(value=True)

        editing = bool(server)
        self.title(("Editar Servidor" if editing else "Nuevo Servidor") + f" — {APP_BRAND_NAME}")
        self.configure(bg=T["bg"])
        self.transient(master)

        master.update_idletasks()
        sw = master.winfo_screenwidth(); sh = master.winfo_screenheight()
        w, h = min(720, int(sw * 0.62)), min(760, int(sh * 0.85))
        px, py = master.winfo_rootx(), master.winfo_rooty()
        pw, ph = master.winfo_width(), master.winfo_height()
        x = px + max(0, (pw - w) // 2); y = py + max(0, (ph - h) // 2)
        self.geometry(f"{w}x{h}+{x}+{y}")
        self.minsize(560, 480)

        hdr = tk.Frame(self, bg=T["accent"], padx=14, pady=8); hdr.pack(fill="x")
        tk.Label(hdr, text=("✏  Editar Servidor" if editing else "🖥  Nuevo Servidor"),
                 font=(_FUI, 13, "bold"), bg=T["accent"], fg=T["button_fg"]).pack(side="left")
        tk.Label(hdr, text="Solo Nombre y Target son obligatorios.",
                 font=(_FUI, 9), bg=T["accent"], fg=T["button_fg"]).pack(side="right")

        body = tk.Frame(self, bg=T["bg"]); body.pack(fill="both", expand=True)
        canvas = tk.Canvas(body, bg=T["bg"], highlightthickness=0, bd=0)
        vsb    = ttk.Scrollbar(body, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        canvas.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        holder = tk.Frame(canvas, bg=T["bg"])
        win_id = canvas.create_window((0, 0), window=holder, anchor="nw")
        holder.bind("<Configure>", lambda _: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(win_id, width=e.width))

        def _wheel(e): canvas.yview_scroll(int(-e.delta / 120), "units")
        canvas.bind("<Enter>", lambda _: canvas.bind_all("<MouseWheel>", _wheel))
        canvas.bind("<Leave>", lambda _: canvas.unbind_all("<MouseWheel>"))
        pad = tk.Frame(holder, bg=T["bg"], padx=14, pady=10); pad.pack(fill="both", expand=True)

        self._vars: dict[str, tk.Variable] = {}

        def sv(key, default=""):
            v = tk.StringVar(value=self._server.get(key, default)); self._vars[key] = v; return v

        v_name   = sv("name")
        v_desc   = sv("description")
        v_owner  = sv("owner")
        v_email  = sv("owner_email")
        v_target = sv("target")
        v_scanner = sv("scanner")
        v_agent_group = sv("agent_group")
        v_stype  = sv("server_type",  _SERVER_TYPES[0])
        v_os     = sv("os_family",    _OS_FAMILIES[0])
        v_env    = sv("environment",  _ENVIRONMENTS[0])
        v_crit   = sv("criticality",  _CRITICALITY_LEVELS[1])
        v_data   = sv("data_class",   _DATA_CLASSIFICATION[0])

        _tpl_key_to_label = {k: name for k, _icon, name, _desc in SCAN_TEMPLATES}
        _tpl_label_to_key = {name: k for k, _icon, name, _desc in SCAN_TEMPLATES}
        _default_tpl_key  = SCAN_TEMPLATES[0][0]
        v_tpl_label = tk.StringVar(
            value=_tpl_key_to_label.get(self._server.get("scan_template") or _default_tpl_key,
                                        SCAN_TEMPLATES[0][2]))

        def section(title: str) -> tk.Frame:
            sh = tk.Frame(pad, bg=T["surface2"], padx=8, pady=3); sh.pack(fill="x", pady=(8, 3))
            tk.Label(sh, text=title, font=(_FUI, 11, "bold"), bg=T["surface2"], fg=T["text"]).pack(side="left")
            outer = tk.Frame(pad, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"])
            outer.pack(fill="x")
            inner = tk.Frame(outer, bg=T["panel_bg"], padx=10, pady=6); inner.pack(fill="both", expand=True)
            return inner

        def row(parent, label: str, factory) -> tk.Widget:
            r = tk.Frame(parent, bg=T["panel_bg"]); r.pack(fill="x", pady=2)
            tk.Label(r, text=label, font=(_FUI, 10), bg=T["panel_bg"], fg=T["muted"],
                     anchor="w", width=24, justify="left").pack(side="left")
            w = factory(r); w.pack(side="left", fill="x", expand=True)
            return w

        def entry(parent, var) -> ttk.Entry:
            return ttk.Entry(parent, textvariable=var)

        def combo(parent, var, values) -> ttk.Combobox:
            return ttk.Combobox(parent, textvariable=var, values=values, state="readonly")

        s1 = section("IDENTIDAD")
        row(s1, "Nombre del Servidor *",   lambda p: entry(p, v_name))
        row(s1, "Descripción",             lambda p: entry(p, v_desc))
        row(s1, "Responsable / Equipo",    lambda p: entry(p, v_owner))
        row(s1, "Correo del responsable",  lambda p: entry(p, v_email))

        s2 = section("CONFIGURACIÓN DE ESCANEO")
        row(s2, "Target (IP / host / CIDR) *", lambda p: entry(p, v_target))
        row(s2, "Plantilla de escaneo",
            lambda p: combo(p, v_tpl_label, [name for _k, _i, name, _d in SCAN_TEMPLATES]))
        row(s2, "Scanner en la nube (opcional)", lambda p: entry(p, v_scanner))
        hint = tk.Label(s2, text="El scanner en la nube enruta el escaneo a un sensor interno "
                                  "(déjalo vacío para usar el sensor predeterminado).",
                        font=(_FUI, 8), bg=T["panel_bg"], fg=T["muted"], anchor="w",
                        wraplength=560, justify="left")
        hint.pack(fill="x", pady=(2, 0))
        row(s2, "Agent Group (opcional)", lambda p: entry(p, v_agent_group))
        agent_hint = tk.Label(s2, text="Si se llena, el escaneo usa Agentes Nessus ya vinculados "
                                  "en vez del Target — para hosts internos sin scanner de red "
                                  "que los alcance (p.ej. '10.49.50.8_9').",
                        font=(_FUI, 8), bg=T["panel_bg"], fg=T["muted"], anchor="w",
                        wraplength=560, justify="left")
        agent_hint.pack(fill="x", pady=(2, 0))

        s3 = section("CLASIFICACIÓN")
        row(s3, "Tipo de Servidor",        lambda p: combo(p, v_stype, _SERVER_TYPES))
        row(s3, "Sistema Operativo",       lambda p: combo(p, v_os,    _OS_FAMILIES))
        row(s3, "Entorno",                 lambda p: combo(p, v_env,   _ENVIRONMENTS))
        row(s3, "Criticidad de Negocio",   lambda p: combo(p, v_crit,  _CRITICALITY_LEVELS))
        row(s3, "Clasificación de Datos",  lambda p: combo(p, v_data,  _DATA_CLASSIFICATION))

        s4 = section("NOTAS")
        notes_txt = tk.Text(s4, height=4, font=(_FUI, 10), bg=T["surface2"], fg=T["text"],
                            relief="flat", wrap="word", padx=6, pady=4)
        notes_txt.pack(fill="x")
        if self._server.get("notes"):
            notes_txt.insert("1.0", self._server["notes"])

        footer = tk.Frame(self, bg=T["panel_bg"], padx=12, pady=8,
                          highlightthickness=1, highlightbackground=T["border"])
        footer.pack(fill="x", side="bottom")
        self._status_lbl = tk.Label(footer, text="", font=(_FUI, 9), bg=T["panel_bg"], fg=T["err"])
        self._status_lbl.pack(side="left")

        tk.Checkbutton(footer, text="Cargar en el Scanner al guardar", variable=self.auto_load_var,
                       bg=T["panel_bg"], fg=T["text"], selectcolor=T["surface2"],
                       activebackground=T["panel_bg"], activeforeground=T["text"],
                       font=(_FUI, 9), highlightthickness=0, bd=0).pack(side="right", padx=(0, 10))

        def _close():
            self.destroy()

        def _save():
            name   = v_name.get().strip()
            target = v_target.get().strip()
            if not name:
                self._status_lbl.config(text="⚠  El Nombre del Servidor es obligatorio.")
                return
            if not target:
                self._status_lbl.config(text="⚠  El Target (IP/host/CIDR) es obligatorio.")
                return
            s = dict(self._server)
            s["name"]          = name
            s["description"]   = v_desc.get().strip()
            s["owner"]         = v_owner.get().strip()
            s["owner_email"]   = v_email.get().strip()
            s["target"]        = target
            s["scan_template"] = _tpl_label_to_key.get(v_tpl_label.get().strip(), _default_tpl_key)
            s["scanner"]       = v_scanner.get().strip()
            s["agent_group"]   = v_agent_group.get().strip()
            s["server_type"]   = v_stype.get()
            s["os_family"]     = v_os.get()
            s["environment"]   = v_env.get()
            s["criticality"]   = v_crit.get()
            s["data_class"]    = v_data.get()
            s["notes"]         = notes_txt.get("1.0", "end").strip()
            if not s.get("id"):
                s["id"] = _slugify(name)
            self._store.save_server(s)
            self.result = s
            _close()

        btn_wrap = tk.Frame(footer, bg=T["panel_bg"]); btn_wrap.pack(side="right")
        tk.Button(btn_wrap, text="  Cancelar  ", command=_close, bg=T["surface2"], fg=T["text"],
                 activebackground=T["card_hover"], activeforeground=T["text"],
                 relief="flat", bd=0, font=(_FUI, 10), cursor="hand2", padx=10, pady=5
                 ).pack(side="left", padx=(0, 6))
        tk.Button(btn_wrap, text="💾  Guardar Servidor", command=_save, bg=T["accent"], fg=T["button_fg"],
                 activebackground=T["accent_hi"], activeforeground=T["button_fg"],
                 relief="flat", bd=0, font=(_FUI, 10, "bold"), cursor="hand2", padx=12, pady=5
                 ).pack(side="left")

        self.protocol("WM_DELETE_WINDOW", _close)
        self.update_idletasks()
        try: self.grab_set()
        except tk.TclError: pass
        self.focus_force()


# ══════════════════════════════════════════════════════════════════════════
#  Dashboard / list / detail tab
# ══════════════════════════════════════════════════════════════════════════
class ServerInventoryTab:

    def __init__(self, parent: tk.Frame, master: tk.Tk,
                 store: ServerInventoryStore, on_load_server=None):
        self._parent          = parent
        self._master          = master
        self._store           = store
        self._on_load_server  = on_load_server
        self._current_server: Optional[dict] = None
        self._build()

    # ── build ────────────────────────────────────────────────────────────
    def _build(self):
        toolbar = tk.Frame(self._parent, bg=T["bg"], padx=4, pady=4)
        toolbar.pack(fill="x")

        def _vsep():
            tk.Frame(toolbar, bg=T["border"], width=1).pack(side="left", fill="y", padx=6, pady=2)

        self._master._btn(toolbar, "📂  Cargar",   self._load_into_scanner, kind="outline").pack(side="left", padx=(0, 4))
        self._master._btn(toolbar, "+  Nuevo",     self._new_server,        kind="accent").pack(side="left", padx=(0, 4))
        self._master._btn(toolbar, "✏  Editar",    self._edit_server,       kind="outline").pack(side="left", padx=(0, 4))
        self._master._btn(toolbar, "🗑  Eliminar",  self._delete_server,     kind="danger").pack(side="left")

        _vsep()
        self._build_dashboard(toolbar)
        _vsep()

        search_frame = tk.Frame(toolbar, bg=T["bg"]); search_frame.pack(side="left", fill="x", expand=True)
        self._master._lbl(search_frame, text="🔎", size=10, bg=T["bg"], fg=T["muted"]).pack(side="left")

        SEARCH_PLACEHOLDER = "filtrar por nombre, target, entorno o nivel de riesgo"
        self._search_var = tk.StringVar(value=SEARCH_PLACEHOLDER)
        self._search_showing_placeholder = True
        search_entry = ttk.Entry(search_frame, textvariable=self._search_var, foreground=T["muted"])
        search_entry.pack(side="left", fill="x", expand=True, padx=(4, 0))

        def _clear_placeholder(_e=None):
            if self._search_showing_placeholder:
                self._search_showing_placeholder = False
                self._search_var.set("")
                search_entry.configure(foreground=T["text"])

        def _restore_placeholder(_e=None):
            if not self._search_var.get():
                self._search_showing_placeholder = True
                self._search_var.set(SEARCH_PLACEHOLDER)
                search_entry.configure(foreground=T["muted"])

        search_entry.bind("<FocusIn>", _clear_placeholder)
        search_entry.bind("<FocusOut>", _restore_placeholder)
        self._search_var.trace_add("write", lambda *_: self.refresh())

        split = tk.Frame(self._parent, bg=T["bg"]); split.pack(fill="both", expand=True, padx=4, pady=(0, 4))

        right = tk.Frame(split, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"])
        right.pack(side="right", fill="y", padx=(6, 0))
        right.configure(width=320); right.pack_propagate(False)

        left = tk.Frame(split, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"])
        left.pack(side="left", fill="both", expand=True)

        tree_hdr = tk.Frame(left, bg=T["accent"], padx=10, pady=5); tree_hdr.pack(fill="x")
        tk.Label(tree_hdr, text="SERVIDORES", font=(_FUI, 10, "bold"), bg=T["accent"], fg=T["button_fg"]).pack(side="left")

        tf = tk.Frame(left, bg=T["panel_bg"]); tf.pack(fill="both", expand=True)
        cols = ("target", "type", "env", "crit", "vulns", "risk", "last_scan")
        self._tree = ttk.Treeview(tf, columns=cols, show="tree headings", height=22)
        self._tree.heading("#0", text="Servidor", anchor="w")
        self._tree.column("#0", width=170, anchor="w")
        headings = [
            ("target",    "Target",             130),
            ("type",      "Tipo",               130),
            ("env",       "Entorno",             90),
            ("crit",      "Criticidad",         110),
            ("vulns",     "🐛 C / A / M / B",   140),
            ("risk",      "Riesgo",              80),
            ("last_scan", "Último Escaneo",     130),
        ]
        for col, txt, width in headings:
            self._tree.heading(col, text=txt, command=lambda c=col: self._sort_by(c))
            self._tree.column(col, width=width, anchor="w")
        vsb = ttk.Scrollbar(tf, orient="vertical", command=self._tree.yview)
        self._tree.configure(yscrollcommand=vsb.set)
        self._tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        self._tree.bind("<<TreeviewSelect>>", self._on_select)
        self._tree.bind("<Double-1>", lambda _: self._edit_server())

        detail_hdr = tk.Frame(right, bg=T["accent"], padx=10, pady=5); detail_hdr.pack(fill="x")
        tk.Label(detail_hdr, text="DETALLES", font=(_FUI, 10, "bold"), bg=T["accent"], fg=T["button_fg"]).pack(side="left")

        self._detail_canvas = tk.Canvas(right, bg=T["panel_bg"], highlightthickness=0, bd=0)
        detail_vsb = ttk.Scrollbar(right, orient="vertical", command=self._detail_canvas.yview)
        self._detail_canvas.configure(yscrollcommand=detail_vsb.set)
        self._detail_canvas.pack(side="left", fill="both", expand=True)
        detail_vsb.pack(side="right", fill="y")
        self._detail_frame = tk.Frame(self._detail_canvas, bg=T["panel_bg"])
        self._detail_win = self._detail_canvas.create_window((0, 0), window=self._detail_frame, anchor="nw")
        self._detail_frame.bind("<Configure>",
            lambda _: self._detail_canvas.configure(scrollregion=self._detail_canvas.bbox("all")))
        self._detail_canvas.bind("<Configure>",
            lambda e: self._detail_canvas.itemconfigure(self._detail_win, width=e.width))

        self._show_detail(None)
        self.refresh()

    def _build_dashboard(self, parent):
        self._dash_tiles: dict[str, tk.Label] = {}
        specs = [
            ("servers",  "Servidores",          T["text"]),
            ("critical", "🔴 Crítico",           _RISK_COLORS_LIGHT["Crítico"]),
            ("high",     "🟠 Alto",              _RISK_COLORS_LIGHT["Alto"]),
            ("medium",   "🟡 Medio",             _RISK_COLORS_LIGHT["Medio"]),
            ("low",      "🟢 Bajo",              _RISK_COLORS_LIGHT["Bajo"]),
            ("stale",    "⏰ Sin escaneo 30d+",  T["muted"]),
        ]
        for key, label, colour in specs:
            tile = tk.Frame(parent, bg=T["panel_bg"], highlightthickness=1,
                            highlightbackground=T["border"], padx=6, pady=3)
            tile.pack(side="left", padx=(0, 4))
            top = tk.Frame(tile, bg=colour, height=2); top.pack(fill="x", pady=(0, 2))
            row = tk.Frame(tile, bg=T["panel_bg"]); row.pack(anchor="w")
            val_lbl = self._master._lbl(row, text="—", size=11, bold=True, bg=T["panel_bg"], fg=colour)
            val_lbl.pack(side="left")
            self._master._lbl(row, text=label, size=9, bg=T["panel_bg"], fg=T["muted"]).pack(side="left", padx=(3, 0))
            self._dash_tiles[key] = val_lbl

    def _refresh_dashboard(self):
        if not hasattr(self, "_dash_tiles"):
            return
        servers = self._store.list_servers()
        agg = {"servers": len(servers), "critical": 0, "high": 0, "medium": 0, "low": 0, "stale": 0}
        cutoff = datetime.now() - timedelta(days=30)
        for s in servers:
            agg["critical"] += int(s.get("vuln_critical", 0) or 0)
            agg["high"]     += int(s.get("vuln_high", 0) or 0)
            agg["medium"]   += int(s.get("vuln_medium", 0) or 0)
            agg["low"]      += int(s.get("vuln_low", 0) or 0)
            last = s.get("last_scan")
            is_stale = True
            if last:
                try:
                    ts = datetime.fromisoformat(str(last)[:19])
                    is_stale = ts < cutoff
                except Exception:
                    is_stale = False
            if is_stale:
                agg["stale"] += 1
        for key, lbl in self._dash_tiles.items():
            lbl.config(text=str(agg.get(key, 0)))

    # ── list ─────────────────────────────────────────────────────────────
    def refresh(self):
        self._refresh_dashboard()
        dark = getattr(self._master, "_dark_mode", False)
        risk_colors = _RISK_COLORS_DARK if dark else _RISK_COLORS_LIGHT
        for tier, colour in risk_colors.items():
            self._tree.tag_configure(
                tier.lower(), foreground=colour,
                font=(_FUI, 9, "bold") if tier in ("Crítico", "Alto") else (_FUI, 9))
        for iid in self._tree.get_children():
            self._tree.delete(iid)
        servers = self._store.list_servers()
        if getattr(self, "_search_showing_placeholder", False):
            needle = ""
        else:
            needle = (getattr(self, "_search_var", None) and self._search_var.get() or "").strip().lower()
        if needle:
            servers = [s for s in servers if needle in " ".join(str(s.get(k, "")) for k in
                       ("name", "target", "server_type", "environment", "risk_tier", "criticality")).lower()]
        for s in servers:
            vulns = (f"{s.get('vuln_critical',0)} / {s.get('vuln_high',0)} / "
                     f"{s.get('vuln_medium',0)} / {s.get('vuln_low',0)}")
            last = s.get("last_scan") or "—"
            tier = s.get("risk_tier", "Ninguno")
            self._tree.insert(
                "", "end", iid=s["id"], text=s.get("name", ""),
                values=(
                    s.get("target", ""), s.get("server_type", ""), s.get("environment", ""),
                    s.get("criticality", ""), vulns, tier,
                    last[:16] if last != "—" else "—",
                ),
                tags=(tier.lower(),),
            )
        if self._current_server:
            sid = self._current_server.get("id", "")
            if self._tree.exists(sid):
                self._tree.selection_set(sid)
                self._tree.see(sid)

    def _sort_by(self, col: str):
        items = [(self._tree.set(iid, col), iid) for iid in self._tree.get_children()]
        rev = getattr(self, f"_sort_rev_{col}", False)
        items.sort(reverse=rev, key=lambda x: x[0].lower() if x[0] else "")
        for idx, (_, iid) in enumerate(items):
            self._tree.move(iid, "", idx)
        setattr(self, f"_sort_rev_{col}", not rev)

    # ── detail panel ─────────────────────────────────────────────────────
    def _show_detail(self, server: Optional[dict]):
        for w in self._detail_frame.winfo_children():
            w.destroy()

        if server is None:
            self._master._lbl(self._detail_frame, text="Selecciona un servidor\nde la lista.",
                     size=11, bg=T["panel_bg"], fg=T["text"], justify="center").pack(expand=True, pady=20)
            return

        pad = tk.Frame(self._detail_frame, bg=T["panel_bg"], padx=8, pady=6); pad.pack(fill="both", expand=True)
        pad.columnconfigure(1, weight=1)

        _row = [0]; _value_lbls: list = []; _full_lbls: list = []

        def kv(label: str, value: str, bold: bool = False, color=None):
            r = _row[0]; _row[0] += 1
            self._master._lbl(pad, text=label, size=10, bold=True, bg=T["panel_bg"], fg=T["text"],
                     anchor="nw", justify="left").grid(row=r, column=0, sticky="nw", padx=(0, 6), pady=2)
            vlbl = self._master._lbl(pad, text=value or "—", size=10, bold=bold,
                     bg=T["panel_bg"], fg=color or T["text"], anchor="w", justify="left")
            vlbl.grid(row=r, column=1, sticky="ew", pady=2)
            _value_lbls.append(vlbl)

        def sep():
            r = _row[0]; _row[0] += 1
            tk.Frame(pad, bg=T["border"], height=1).grid(row=r, column=0, columnspan=2, sticky="ew", pady=4)

        def full_row():
            r = _row[0]; _row[0] += 1
            w = tk.Frame(pad, bg=T["panel_bg"])
            w.grid(row=r, column=0, columnspan=2, sticky="ew", pady=2)
            return w

        dark = getattr(self._master, "_dark_mode", False)
        tier = server.get("risk_tier", "Ninguno")
        tc = (_RISK_COLORS_DARK if dark else _RISK_COLORS_LIGHT).get(tier, T["muted"])

        kv("Nombre",          server.get("name", ""), bold=True)
        kv("Nivel de Riesgo", tier, bold=True, color=tc)
        kv("Target",          server.get("target", ""))
        kv("Plantilla",       _TEMPLATE_LABELS.get(server.get("scan_template", ""), "—"))
        kv("Scanner",         server.get("scanner", "") or "(predeterminado)")
        kv("Agent Group",     server.get("agent_group", "") or "(ninguno — usa Target)")
        kv("Tipo",            server.get("server_type", ""))
        kv("Sistema Operativo", server.get("os_family", ""))
        kv("Entorno",         server.get("environment", ""))
        kv("Criticidad",      server.get("criticality", ""))
        kv("Clasif. Datos",   server.get("data_class", ""))

        sep()

        c  = server.get("vuln_critical", 0)
        h  = server.get("vuln_high", 0)
        m  = server.get("vuln_medium", 0)
        lo = server.get("vuln_low", 0)
        tot = server.get("vuln_total", c + h + m + lo)

        badge_row = full_row()
        for count, label, bg_hex in [
            (c,  "Crítico", "#7a0c1c"),
            (h,  "Alto",     "#8b3a0a"),
            (m,  "Medio",   "#7a5e00"),
            (lo, "Bajo",      "#0c4a2b"),
        ]:
            badge = tk.Frame(badge_row, bg=bg_hex, padx=4, pady=2)
            badge.pack(side="left", padx=(0, 2))
            self._master._lbl(badge, text=str(count), size=11, bold=True, bg=bg_hex, fg="#ffffff").pack()
            self._master._lbl(badge, text=label, size=9, bg=bg_hex, fg="#cccccc").pack()

        kv("Total Hallazgos", str(tot))
        kv("Info",            str(server.get("vuln_info", 0)))
        kv("Último Escaneo",  (server.get("last_scan") or "—")[:16])

        sep()

        kv("Responsable", server.get("owner", ""))
        kv("Email",       server.get("owner_email", ""))

        notes = server.get("notes", "")
        if notes:
            sep()
            notes_wrap = full_row()
            self._master._lbl(notes_wrap, text="NOTAS", size=10, bold=True,
                     bg=T["panel_bg"], fg=T["text"], anchor="w").pack(fill="x")
            notes_lbl = self._master._lbl(notes_wrap, text=notes, size=10,
                     bg=T["panel_bg"], fg=T["text"], anchor="w", justify="left")
            notes_lbl.pack(fill="x")
            _full_lbls.append(notes_lbl)

        def _rewrap(_evt=None):
            pad.update_idletasks()
            bbox0 = pad.grid_bbox(column=0)
            label_w = bbox0[2] if bbox0 else 0
            avail = max(pad.winfo_width() - label_w - 14, 60)
            full_avail = max(pad.winfo_width() - 8, 60)
            for vlbl in _value_lbls:
                try: vlbl.configure(wraplength=avail)
                except Exception: pass
            for flbl in _full_lbls:
                try: flbl.configure(wraplength=full_avail)
                except Exception: pass

        pad.bind("<Configure>", _rewrap)
        pad.after(0, _rewrap)

        history = server.get("scan_history", [])
        if len(history) >= 2:
            trend_wrap = full_row()
            self._draw_trend(trend_wrap, history)

    def _draw_trend(self, parent, history: list):
        tk.Frame(parent, bg=T["border"], height=1).pack(fill="x", pady=3)
        self._master._lbl(parent, text="TENDENCIA (últimos escaneos)", size=10, bold=True,
                 bg=T["panel_bg"], fg=T["text"], anchor="w").pack(fill="x")

        W, H = 270, 90
        cv = tk.Canvas(parent, width=W, height=H, bg=T["surface2"], bd=0, highlightthickness=0)
        cv.pack(pady=(2, 0))

        entries = history[-10:]
        n = len(entries)
        max_v = max((e.get("total", 0) or 0) for e in entries) or 1
        xs = [int(12 + (i / max(n - 1, 1)) * (W - 24)) for i in range(n)]

        def y_for(v): return int(H - 8 - (v / max_v) * (H - 20))

        for pct in (0.25, 0.5, 0.75, 1.0):
            yy = y_for(int(max_v * pct))
            cv.create_line(4, yy, W - 4, yy, fill=T["border"], dash=(2, 4))

        for key, colour in [
            ("critical", "#c8102e"), ("high", "#e26020"),
            ("medium",   "#d4a017"), ("total",  T["muted"]),
        ]:
            pts = []
            for i, e in enumerate(entries):
                pts += [xs[i], y_for(e.get(key, e.get("total", 0) or 0))]
            if len(pts) >= 4:
                cv.create_line(pts, fill=colour, width=2, smooth=True)

        if entries:
            last = entries[-1]
            for key, colour in [("critical", "#c8102e"), ("high", "#e26020"), ("medium", "#d4a017")]:
                v = last.get(key, 0) or 0
                if v:
                    yy = y_for(v)
                    cv.create_oval(xs[-1] - 4, yy - 4, xs[-1] + 4, yy + 4, fill=colour, outline="")

        if entries:
            cv.create_text(xs[0], H - 2, text=entries[0].get("ts", "")[:10],
                           font=(_FUI, 8), fill=T["muted"], anchor="s")
            cv.create_text(xs[-1], H - 2, text=entries[-1].get("ts", "")[:10],
                           font=(_FUI, 8), fill=T["muted"], anchor="s")

    # ── selection / actions ─────────────────────────────────────────────
    def _on_select(self, _event=None):
        sel = self._tree.selection()
        if sel:
            self._show_detail(self._store.get_server(sel[0]))
        else:
            self._show_detail(None)

    def _selected_server(self) -> Optional[dict]:
        sel = self._tree.selection()
        return self._store.get_server(sel[0]) if sel else None

    def _new_server(self):
        ed = ServerProfileEditor(self._master, self._store)
        self._master.wait_window(ed)
        if ed.result:
            self.refresh()
            self._tree.selection_set(ed.result["id"])
            self._show_detail(ed.result)
            self._current_server = ed.result
            if ed.auto_load_var.get() and self._on_load_server:
                self._on_load_server(ed.result)

    def _edit_server(self):
        server = self._selected_server()
        if not server:
            return
        ed = ServerProfileEditor(self._master, self._store, server)
        self._master.wait_window(ed)
        if ed.result:
            self.refresh()
            self._show_detail(ed.result)
            self._current_server = ed.result
            if ed.auto_load_var.get() and self._on_load_server:
                self._on_load_server(ed.result)

    def _delete_server(self):
        server = self._selected_server()
        if not server:
            return
        if not messagebox.askyesno(
                f"{APP_BRAND_NAME} — Eliminar servidor",
                f"¿Eliminar '{server['name']}'?\nEsta acción no se puede deshacer.",
                parent=self._master):
            return
        self._store.delete_server(server["id"])
        if self._current_server and self._current_server.get("id") == server["id"]:
            self._current_server = None
        self.refresh()
        self._show_detail(None)

    def _load_into_scanner(self):
        server = self._selected_server()
        if not server:
            return
        self._current_server = server
        if self._on_load_server:
            self._on_load_server(server)

    def apply_theme(self) -> None:
        """Rebuild the tab UI in-place with the current palette (dark/light toggle)."""
        sel = self._tree.selection()
        selected_id = sel[0] if sel else None
        active_server = self._current_server

        for child in list(self._parent.winfo_children()):
            try: child.destroy()
            except Exception: pass

        self._build()

        if selected_id and self._tree.exists(selected_id):
            self._tree.selection_set(selected_id)
            self._tree.see(selected_id)
            self._show_detail(self._store.get_server(selected_id))

        if active_server:
            self._current_server = active_server


# ══════════════════════════════════════════════════════════════════════════
#  Mixin — wires the Servers tab into ScannerApp
# ══════════════════════════════════════════════════════════════════════════
class _ServersTabMixin:
    def _build_tab_servers(self, parent):
        self._srv_tab = ServerInventoryTab(parent=parent, master=self, store=self._srv_store,
                                           on_load_server=self._load_server_profile)

    def _load_server_profile(self, server: dict, *, silent: bool = False) -> None:
        """Loads a saved server's target/template/scanner into the Scan tab so
        it can be reviewed and re-launched with ▶ Run scan — the confirmed
        'load, then run' re-scan flow (not an instant/skip-review scan)."""
        self._active_server = server
        if server.get("target"):
            self._v_targets.set(server["target"])
        tpl = server.get("scan_template") or SCAN_TEMPLATES[0][0]
        valid_keys = {k for k, _i, _n, _d in SCAN_TEMPLATES}
        if tpl in valid_keys:
            self._selected_template = tpl
            for k, rec in getattr(self, "_stage_cards", {}).items():
                try: rec["paint"](k == tpl)
                except Exception: pass
            if hasattr(self, "_sel_tpl_lbl"):
                self._sel_tpl_lbl.config(text=_TEMPLATE_LABELS.get(tpl, tpl))
        if server.get("scanner"):
            self._v_scanner.set(server["scanner"])
        # Explicit set-or-clear (not just "if truthy") so a previously loaded
        # server's Agent Group doesn't linger and silently redirect this
        # server's scan away from its own Target.
        self._v_agent_group.set(server.get("agent_group", ""))
        self._v_scanname.set(f"{server.get('name','Server')} — {datetime.now():%Y-%m-%d}")

        self._refresh_active_server_banner()
        self._save_settings()

        srv_tab = getattr(self, "_srv_tab", None)
        if srv_tab is not None:
            try: srv_tab.refresh()
            except Exception: pass

        if silent:
            return
        self._show_tab("scan")
        self._info("Servidor cargado",
            f"Nombre: {server['name']}\n"
            f"Target: {server.get('target') or '(no configurado)'}\n"
            f"Plantilla: {_TEMPLATE_LABELS.get(server.get('scan_template',''), '(no configurada)')}\n"
            f"Entorno: {server.get('environment') or '(no configurado)'}\n"
            f"Criticidad: {server.get('criticality') or '(no configurado)'}\n\n"
            "Revisa los datos en la pestaña ▶ Scan y presiona Run scan cuando quieras re-escanear.")

    def _clear_active_server(self) -> None:
        self._active_server = None
        self._refresh_active_server_banner()
        self._save_settings()

    def _refresh_active_server_banner(self) -> None:
        lbl = getattr(self, "_active_srv_lbl", None)
        if lbl is None:
            return
        srv = getattr(self, "_active_server", None)
        clear_btn = getattr(self, "_active_srv_clear_btn", None)
        if srv:
            lbl.config(text=f"{srv.get('name','?')}  ·  {srv.get('target','')}", fg=T["ok"])
            if clear_btn is not None:
                clear_btn.pack(side="right")
        else:
            lbl.config(text="Sin servidor cargado — ir a 🖥 Servers", fg=T["muted"])
            if clear_btn is not None:
                clear_btn.pack_forget()

    def _auto_load_last_server(self) -> None:
        """Silently restore the last-loaded server profile at startup (mirrors
        the Snyk scanner's _auto_load_last_app)."""
        srv_id = getattr(self, "_last_server_id", "")
        if not srv_id:
            self._refresh_active_server_banner()
            return
        try:
            server = self._srv_store.get_server(srv_id)
        except Exception:
            server = None
        if server:
            self._load_server_profile(server, silent=True)
            self._log(f"[servers] perfil recargado automáticamente: {server.get('name')}")
        else:
            self._refresh_active_server_banner()
