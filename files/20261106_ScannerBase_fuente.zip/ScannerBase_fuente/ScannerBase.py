"""Punto de entrada del ejecutable ScannerBase.exe (PyInstaller).

- Doble clic                → abre la interfaz (INICIAR_SnykScannerGUI.main).
- ScannerBase.exe --tick    → ciclo del Programador de tareas de Windows (scheduled_runner.main), sin ventana.
- ScannerBase.exe --force   → igual que --tick, para pruebas.

Con el código fuente también funciona: python ScannerBase.py
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

_HERE = Path(__file__).resolve().parent
for _p in (_HERE / "core", _HERE):
    if _p.is_dir() and str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

FROZEN = bool(getattr(sys, "frozen", False))


def _clean_child_environment() -> None:
    """Evita que los procesos hijos (snyk, node, git, Python de Checkov…) hereden rutas internas del .exe."""
    if not FROZEN or os.name != "nt":
        return
    try:
        import ctypes
        # El cargador de PyInstaller fija SetDllDirectory(_internal); los hijos lo heredarían y podrían cargar
        # DLLs equivocadas. Los módulos del .exe ya están cargados en este punto.
        ctypes.windll.kernel32.SetDllDirectoryW(None)
    except Exception:
        pass


def main() -> int:
    if "--tick" in sys.argv or "--force" in sys.argv:
        import scheduled_runner
        _clean_child_environment()
        return int(scheduled_runner.main() or 0)
    import INICIAR_SnykScannerGUI as app
    _clean_child_environment()
    app.main()
    return 0


if __name__ == "__main__":
    sys.exit(main())
