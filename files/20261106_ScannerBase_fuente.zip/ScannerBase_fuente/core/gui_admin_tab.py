"""Sección «Administración» (solo administradores) y diálogo «Motores» (todos los usuarios)."""
from __future__ import annotations

from ui_common import *
import admin_policy
import tool_manager as tm


class _AdminTabMixin:
    # ── Diálogo «Motores» (visible para todos) ──────────────────────────────
    def _show_engines_popup(self):
        """Lista de motores para TODOS los usuarios: estado, versión instalada, versión nueva publicada y botón para
        actualizar cada uno (o todos), incluido git-secrets. Snyk se actualiza solo al arrancar."""
        popup = self._popup("Motores de escaneo", 0.64, 0.88)
        self._popup_hdr(popup, "Motores de escaneo", subtitle="Herramientas de código abierto que se descargan y "
                        "verifican automáticamente. Aquí también puede actualizarlas a su última versión.")
        body = tk.Frame(popup, bg=T["bg"], padx=px(24), pady=px(4))
        body.pack(fill="both", expand=True)
        bottom = tk.Frame(body, bg=T["bg"])
        bottom.pack(side="bottom", fill="x")
        status = autowrap(tk.Label(bottom, text="", font=(FUI, 10), bg=T["bg"], fg=T["muted"], anchor="w",
                                   justify="left"), 8, 200)
        status.pack(fill="x", pady=(px(8), 0))
        rows_box = scroll_frame(body)   # la lista se desplaza: en pantallas de 768 px no cabían los 8 motores
        st_ = {"sts": [], "ups": {}}
        refs: dict = {}

        def paint():
            if not rows_box.winfo_exists():
                return
            for w in rows_box.winfo_children():
                w.destroy()
            busy = getattr(self, "_tools_busy", False)
            for st in st_["sts"]:
                up = st_["ups"].get(st.key) or {}
                row = tk.Frame(rows_box, bg=T["panel_bg"], highlightthickness=1,
                               highlightbackground=T["accent"] if up.get("update") else T["border"])
                row.pack(fill="x", pady=(0, px(6)))
                inner = tk.Frame(row, bg=T["panel_bg"], padx=px(14), pady=px(10))
                inner.pack(fill="x")
                dot = T["warn"] if up.get("update") or st.upgrade_to else T["ok"] if st.installed else T["muted"]
                tk.Label(inner, text="●", font=(FUI, 11), bg=T["panel_bg"], fg=dot).pack(side="left", padx=(0, px(10)))
                if up.get("update"):   # el botón se empaqueta antes que el texto: nunca se recorta
                    b = PillButton(inner, f"Actualizar a {up['latest']}", lambda k=st.key: update([k]),
                                   icon="download", variant="primary", size=10)
                    b.pack(side="right", padx=(px(10), 0))
                    if busy:
                        b.configure(state="disabled")
                right = tk.Frame(inner, bg=T["panel_bg"])
                right.pack(side="right")
                col = tk.Frame(inner, bg=T["panel_bg"])
                col.pack(side="left", fill="x", expand=True)
                tk.Label(col, text=st.label, font=(FUI, 11, "bold"), bg=T["panel_bg"], fg=T["text"],
                         anchor="w").pack(fill="x")
                tk.Label(col, text=tm.PURPOSE[st.key], font=(FUI, 10), bg=T["panel_bg"], fg=T["muted"],
                         anchor="w").pack(fill="x")
                tk.Label(right, text=st.detail + (f" · {st.source}" if st.installed and st.source else ""),
                         font=(FUI, 10), bg=T["panel_bg"], fg=T["ok"] if st.installed else T["muted"],
                         anchor="e").pack(anchor="e")
                if up.get("update"):
                    tk.Label(right, text=f"Nueva versión: {up['latest']}", font=(FUI, 9, "bold"), bg=T["panel_bg"],
                             fg=T["warn"], anchor="e").pack(anchor="e")
                elif up.get("latest") and st.installed:
                    tk.Label(right, text="Última versión ✓", font=(FUI, 9), bg=T["panel_bg"], fg=T["muted"],
                             anchor="e").pack(anchor="e")
            if (ub := refs.get("upd_all")) is not None and ub.winfo_exists():
                n = sum(1 for k, u in st_["ups"].items() if u.get("update") and any(x.key == k for x in st_["sts"]))
                ub.configure(text=f"⬆  Actualizar todo ({n})" if n else "⬆  Actualizar todo",
                             state="normal" if n and not busy else "disabled")

        def refresh():
            def work():
                sts = tm.all_status()
                self._ui(lambda: (st_.update(sts=sts), paint()))
                self._ui(self._apply_engine_cache, sts)
            threading.Thread(target=work, daemon=True).start()

        def check(force):
            if force:
                status.config(text="Consultando las últimas versiones publicadas…", fg=T["muted"])

            def work():
                try:
                    ups = tm.check_updates(self._emit_log, force=force)
                except Exception as e:
                    ups = {}
                    self._emit_log(f"[motores] no se pudieron buscar actualizaciones: {e!r}")

                def done():
                    st_["ups"] = ups
                    paint()
                    self._paint_badges()
                    if not status.winfo_exists():
                        return
                    errs = [k for k, r in ups.items() if r.get("error") and not r.get("latest")]
                    n = sum(1 for r in ups.values() if r.get("update"))
                    if ups and len(errs) == len(ups):
                        status.config(text="No se pudo consultar ninguna versión publicada (sin acceso a GitHub / "
                                           "PyPI / Maven Central desde esta red).", fg=T["warn"])
                    elif force or n:
                        status.config(text=(f"{n} motor(es) con versión nueva." if n else
                                            "Todos los motores consultados están en su última versión ✓")
                                      + (f" Sin respuesta: {', '.join(tm.LABELS[k] for k in errs)}." if errs else ""),
                                      fg=T["warn"] if n else T["ok"])
                self._ui(done)
            threading.Thread(target=work, daemon=True).start()

        def update(keys):
            ups = st_["ups"]
            keys = [k for k in keys if (ups.get(k) or {}).get("update")]
            if not keys or getattr(self, "_tools_busy", False):
                return
            status.config(text="Actualizando " + ", ".join(f"{tm.LABELS[k]} → {ups[k]['latest']}" for k in keys)
                          + "… el detalle se muestra en la consola.", fg=T["muted"])

            def work():
                done, errs = [], {}
                for k in keys:
                    try:
                        tm.update(k, ups[k]["latest"], self._emit_log)
                        done.append(k)
                    except Exception as e:
                        errs[k] = str(e)
                        self._emit_log(f"[motores] {tm.LABELS[k]}: no se pudo actualizar — {e}")
                if "sonarqube" in done:
                    try:
                        import sonar_local
                        sonar_local.stop(self._emit_log)   # el siguiente escaneo de IaC arranca la versión nueva
                    except Exception:
                        pass

                def after():
                    for k in done:
                        (st_["ups"].get(k) or {}).update(installed=ups[k]["latest"], update=False)
                    if status.winfo_exists():
                        status.config(text=(("Actualizado ✓: " + ", ".join(f"{tm.LABELS[k]} {ups[k]['latest']}"
                                                                           for k in done)) if done else "")
                                      + ("\n" if done and errs else "")
                                      + "\n".join(f"✕ {tm.LABELS[k]}: {v[:180]}" for k, v in errs.items()),
                                      fg=T["warn"] if errs else T["ok"])
                    if done:
                        self._toast(f"{len(done)} motor(es) actualizado(s)", "ok")
                    refresh()
                    self._paint_badges()
                self._ui(after)
            self._run_async(work, "actualizar motores", busy_attr="_tools_busy")
            paint()

        def install_all():
            status.config(text="Preparando motores… el progreso se muestra en la consola.", fg=T["muted"])

            def work():
                errs = {}
                for k in tm.installable():
                    try:
                        tm.ensure(k, self._emit_log)
                    except Exception as e:
                        errs[k] = str(e)
                self._ui(lambda: status.winfo_exists() and status.config(
                    text=("Todos los motores están listos ✓" if not errs else
                          "Algunos motores no se pudieron preparar:\n" + "\n".join(f"· {tm.LABELS[k]}: {v[:160]}"
                                                                                 for k, v in errs.items())),
                    fg=T["ok"] if not errs else T["warn"]))
                self._ui(refresh)
            self._run_async(work, "preparar motores", busy_attr="_tools_busy")
        autowrap(tk.Label(bottom, text="No se requiere Docker ni permisos de administrador. Toda descarga se verifica "
                          "(SHA-256 u otro hash publicado; git-secrets contra el hash git del tag en GitHub) y se guarda "
                          f"en «{TOOLS_DIR.name}» dentro de la carpeta del programa. Snyk se actualiza solo al arrancar.",
                          font=(FUI, 10), bg=T["bg"], fg=T["muted"], justify="left", anchor="w"), 8, 200).pack(
            fill="x", pady=(px(6), 0))
        foot = self._popup_foot(popup, ("Cerrar", popup.close), ("🔎  Buscar actualizaciones", lambda: check(True)),
                                ("⬆  Actualizar todo", lambda: update(list(st_["ups"]))),
                                ("📥  Preparar todos ahora", install_all), primary=None)
        refs["upd_all"] = next((b for b in foot.buttons if "Actualizar todo" in b.cget("text")), None)
        st_["sts"] = [tm.ToolStatus(k, tm.LABELS[k], detail="verificando…") for k in tm.active_order()]
        paint()
        refresh()
        check(False)

    def _engines_summary(self) -> tuple[str, str]:
        sts = getattr(self, "_engine_cache", None)
        if not sts:
            return "checking", "Motores: verificando…"
        ready = sum(1 for s in sts if s.installed)
        try:
            ups = sum(1 for k, r in ((read_json(tm.UPDATES_FILE, {}) or {}).get("tools") or {}).items()
                      if r.get("update") and k in tm.active_order())
        except Exception:
            ups = 0
        return ("auth" if ready == len(sts) and not ups else "checking" if ready else "unauth"), \
            f"Motores: {ready}/{len(sts)} listos" + (f" · {ups} actualización(es) disponible(s)" if ups else "") + \
            " — clic para ver"

    def _refresh_engine_cache(self):
        def work():
            try:
                sts = tm.all_status()
            except Exception:
                sts = []
            self._ui(self._apply_engine_cache, sts)
        threading.Thread(target=work, daemon=True).start()

    def _apply_engine_cache(self, sts):
        self._engine_cache = sts
        self._paint_badges()
        for hook in ("_refresh_scan_btn", "_refresh_engine_cards"):
            if callable(fn := getattr(self, hook, None)):
                fn()

    # ── Página «Administración» ─────────────────────────────────────────────
    def _build_tab_admin(self, parent):
        pad = self._scrollable(parent)
        pol = admin_policy.load()
        self._admin_vars = v = {
            "admins": tk.StringVar(value=", ".join(pol.get("admins") or [])),
            "key": tk.StringVar(value=(pol.get("probely") or {}).get("api_key", "")),
            "fallback": tk.BooleanVar(value=bool((pol.get("probely") or {}).get("fallback_open_source", True))),
            "mirror": tk.StringVar(value=(pol.get("tools") or {}).get("mirror_base", "")),
            "db": tk.StringVar(value=(pol.get("trivy") or {}).get("db_repository", "")),
            "javadb": tk.StringVar(value=(pol.get("trivy") or {}).get("java_db_repository", "")),
            "checks": tk.StringVar(value=(pol.get("trivy") or {}).get("checks_bundle_repository", "")),
        }
        self._admin_versions = {k: tk.StringVar(value=str((pol.get("tools") or {}).get("versions", {}).get(k, "")))
                                for k in tm.PINNED}
        self._admin_apps = {str(a).lower() for a in (pol.get("probely") or {}).get("apps") or []}
        bar = tk.Frame(pad, bg=T["bg"])
        bar.pack(fill="x", pady=(0, CARD_GAP))
        PillButton(bar, "Guardar política", self._admin_save, icon="save", variant="primary").pack(side="left")
        self._btn(bar, "📂  Abrir carpeta del programa", lambda: open_path(APP_DIR)).pack(side="left", padx=(px(8), 0))
        self._admin_meta = tk.Label(bar, text=self._admin_meta_text(pol), font=(FUI, 10), bg=T["bg"], fg=T["muted"])
        self._admin_meta.pack(side="right")
        cols = tk.Frame(pad, bg=T["bg"])
        cols.pack(fill="both", expand=True)
        cols.columnconfigure(0, weight=3, uniform="adm")
        cols.columnconfigure(1, weight=2, uniform="adm")
        left, right = tk.Frame(cols, bg=T["bg"]), tk.Frame(cols, bg=T["bg"])
        left.grid(row=0, column=0, sticky="nsew", padx=(0, CARD_GAP // 2))
        right.grid(row=0, column=1, sticky="nsew", padx=(CARD_GAP // 2, 0))
        # Probely
        c = self._card(left, "Probely — asignación de licencias", collapsible=False)
        self._lbl(c, "Solo las aplicaciones marcadas escanean Web/API con Probely. El resto usa ZAP + Nuclei. La clave "
                  "nunca se muestra a los usuarios.", size=10, fg=T["muted"], anchor="w", justify="left",
                  wraplength=px(560)).pack(fill="x", pady=(0, px(10)))
        kr = tk.Frame(c, bg=T["panel_bg"])
        kr.pack(fill="x")
        self._lbl(kr, "Clave de API", size=10, bold=True, fg=T["muted"]).pack(anchor="w")
        er = tk.Frame(kr, bg=T["panel_bg"])
        er.pack(fill="x", pady=(px(2), 0))
        entry = ttk.Entry(er, textvariable=v["key"], show="•")
        entry.pack(side="left", fill="x", expand=True)
        show = tk.BooleanVar(value=False)
        ToggleSwitch(er, text="Mostrar", variable=show,
                     command=lambda: entry.config(show="" if show.get() else "•")).pack(side="left", padx=(px(10), 0))
        self._btn(er, "✓  Validar", self._admin_validate_probely).pack(side="left", padx=(px(10), 0))
        self._admin_key_status = tk.Label(c, text="", font=(FUI, 10), bg=T["panel_bg"], fg=T["muted"], anchor="w",
                                          justify="left", wraplength=px(560))
        self._admin_key_status.pack(fill="x", pady=(px(6), px(10)))
        hdr = tk.Frame(c, bg=T["panel_bg"])
        hdr.pack(fill="x")
        self._lbl(hdr, "Aplicaciones con Probely", size=10, bold=True, fg=T["muted"]).pack(side="left")
        self._admin_count = tk.Label(hdr, text="", font=(FUI, 10, "bold"), bg=T["panel_bg"], fg=T["text"])
        self._admin_count.pack(side="right")
        box = tk.Frame(c, bg=T["panel_bg"])
        box.pack(fill="both", expand=True, pady=(px(4), 0))
        self._admin_tree = make_tree(box, ("on", "name", "env", "crit"), [("", 40, "center", False),
                                                                          ("Aplicación", 220), ("Entorno", 120),
                                                                          ("Criticidad", 150)], 9)
        self._admin_tree.bind("<Double-1>", lambda _e: self._admin_toggle_app())
        self._admin_tree.bind("<space>", lambda _e: self._admin_toggle_app())
        self._lbl(c, "Doble clic o barra espaciadora para asignar / quitar.", size=9, fg=T["muted"]).pack(
            anchor="w", pady=(px(4), 0))
        tip(ToggleSwitch(c, text="Si Probely falla o no hay licencia libre, usar ZAP + Nuclei automáticamente",
                         variable=v["fallback"]), "Desactivado, el escaneo web/API de una aplicación asignada falla "
                         "si Probely no responde (útil si el resultado debe venir siempre de Probely).").pack(
            anchor="w", pady=(px(10), 0))
        self._admin_fill_apps()
        # Motores
        c = self._card(left, "Motores de código abierto", collapsible=False)
        box = tk.Frame(c, bg=T["panel_bg"])
        box.pack(fill="both", expand=True)
        self._admin_tools = make_tree(box, ("tool", "purpose", "state", "pinned"), [
            ("Motor", 140), ("Uso", 280), ("Estado", 150), ("Versión fijada", 110)], len(tm.active_order()))
        brow = tk.Frame(c, bg=T["panel_bg"])
        brow.pack(fill="x", pady=(px(8), 0))
        self._btn(brow, "📥  Instalar / actualizar", self._admin_tool_install).pack(side="left")
        self._btn(brow, "↻  Refrescar", self._admin_tools_refresh).pack(side="left", padx=(px(8), 0))
        PillButton(brow, "Eliminar", self._admin_tool_remove, icon="delete", variant="danger_ghost").pack(side="right")
        self._admin_tools_refresh()
        # ServiceNow
        c = self._card(left, "ServiceNow — tickets automáticos", collapsible=False)
        self._admin_snow_test = tk.BooleanVar(value=bool(getattr(self, "_snow_test_mode", False)))
        tip(ToggleSwitch(c, text="Modo prueba: NO crear, actualizar ni cerrar tickets (solo en este equipo)",
                         variable=self._admin_snow_test, command=self._admin_toggle_snow_test),
            "Para hacer pruebas del escáner sin generar tickets reales. Se guarda en la configuración local de este "
            "equipo (no en admin_policy.json), así que no afecta a los demás usuarios. Mientras esté activo, "
            "«Preparación» lo indica y la consola muestra qué ticket se habría creado.").pack(anchor="w")
        self._lbl(c, "Con el modo prueba apagado, cada escaneo con críticas/altas crea o actualiza el ticket de la "
                  "aplicación y le adjunta el reporte HTML consolidado (reemplazando el del escaneo anterior).",
                  size=9, fg=T["muted"], anchor="w", justify="left", wraplength=px(560)).pack(fill="x", pady=(px(6), 0))
        # Columna derecha
        c = self._card(right, "Administradores", collapsible=False)
        self._lbl(c, "Usuarios de Windows (separados por coma) que ven esta sección.", size=10, fg=T["muted"],
                  anchor="w", justify="left", wraplength=px(380)).pack(fill="x")
        ttk.Entry(c, textvariable=v["admins"]).pack(fill="x", pady=(px(6), px(4)))
        self._lbl(c, f"Usuario actual: {self._user}", size=9, fg=T["muted"]).pack(anchor="w")
        c = self._card(right, "Versiones fijadas", collapsible=False)
        self._lbl(c, "Vacío = versión probada por defecto. Las versiones comprometidas conocidas se bloquean siempre.",
                  size=10, fg=T["muted"], anchor="w", justify="left", wraplength=px(380)).pack(fill="x", pady=(0, px(6)))
        grid = tk.Frame(c, bg=T["panel_bg"])
        grid.pack(fill="x")
        grid.columnconfigure(1, weight=1)
        for i, k in enumerate(tm.PINNED):
            self._lbl(grid, tm.LABELS[k], size=10).grid(row=i, column=0, sticky="w", pady=px(3), padx=(0, px(10)))
            e = ttk.Entry(grid, textvariable=self._admin_versions[k], width=12)
            e.grid(row=i, column=1, sticky="ew", pady=px(3))
            self._lbl(grid, f"por defecto {tm.PINNED[k]}", size=9, fg=T["muted"]).grid(row=i, column=2, sticky="w",
                                                                                       padx=(px(8), 0))
        c = self._card(right, "Red corporativa", collapsible=False)
        for label, key, hint in (("Espejo interno de descargas", "mirror",
                                  "URL base con los mismos nombres de archivo que GitHub (p. ej. Artifactory)."),
                                 ("Trivy — base de vulnerabilidades", "db", "p. ej. registro.interno/aquasec/trivy-db:2"),
                                 ("Trivy — base Java", "javadb", "p. ej. registro.interno/aquasec/trivy-java-db:1"),
                                 ("Trivy — paquete de reglas IaC", "checks", "p. ej. registro.interno/aquasec/trivy-checks:1")):
            self._lbl(c, label, size=10, bold=True, fg=T["muted"]).pack(anchor="w", pady=(px(6), 0))
            ttk.Entry(c, textvariable=v[key]).pack(fill="x", pady=(px(2), 0))
            self._lbl(c, hint, size=9, fg=T["muted"], anchor="w", justify="left", wraplength=px(380)).pack(fill="x")

    @staticmethod
    def _admin_meta_text(pol) -> str:
        return f"Última modificación: {pol.get('updated_by')} · {pol.get('updated_at')}" if pol.get("updated_at") else \
            "Política aún no guardada"

    def _admin_fill_apps(self):
        tree = getattr(self, "_admin_tree", None)
        if tree is None or not tree.winfo_exists():
            return
        clear_tree(tree)
        n = 0
        for a in sorted(self._inv_store.list_apps(), key=lambda a: a.get("name", "").lower()):
            on = bool({str(a.get("id", "")).lower(), str(a.get("name", "")).lower()} & self._admin_apps)
            n += on
            tree.insert("", "end", iid=a["id"], values=("●" if on else "", a.get("name", ""), a.get("environment", ""),
                                                         a.get("criticality", "")), tags=(stripe(tree),))
        maxa = (admin_policy.load().get("probely") or {}).get("max_apps", 5)
        self._admin_count.config(text=f"{n} / {maxa} licencias", fg=T["err"] if n > maxa else T["text"])

    def _admin_toggle_app(self):
        sel = self._admin_tree.selection()
        if not sel:
            return
        app = self._inv_store.get_app(sel[0]) or {}
        keys = {str(app.get("id", "")).lower(), str(app.get("name", "")).lower()} - {""}
        if keys & self._admin_apps:
            self._admin_apps -= keys
        else:
            maxa = (admin_policy.load().get("probely") or {}).get("max_apps", 5)
            current = sum(1 for a in self._inv_store.list_apps()
                          if {str(a.get("id", "")).lower(), str(a.get("name", "")).lower()} & self._admin_apps)
            if current >= maxa:
                return self._toast(f"Límite de {maxa} licencias alcanzado — quite una aplicación primero", "warn")
            self._admin_apps.add(str(app.get("name", "")).lower())
        self._admin_fill_apps()
        self._admin_tree.selection_set(sel[0])

    def _admin_validate_probely(self):
        key = self._admin_vars["key"].get().strip()
        if not key:
            return self._admin_key_status.config(text="Ingrese una clave.", fg=T["warn"])
        self._admin_key_status.config(text="Validando…", fg=T["muted"])

        def work():
            from probely_engine import check_snyk_api_web
            from web_common import ScanConfig
            try:
                ok, msg = check_snyk_api_web(ScanConfig(probely_token=key), self._emit_log)
            except Exception as e:
                ok, msg = False, repr(e)
            self._ui(lambda: self._admin_key_status.winfo_exists() and self._admin_key_status.config(
                text=("✓  " if ok else "✕  ") + msg, fg=T["ok"] if ok else T["err"]))
            self._ui(self._set_probely_status, "auth" if ok else "unauth")
        threading.Thread(target=work, daemon=True).start()

    def _admin_save(self):
        v = self._admin_vars
        pol = admin_policy.load()
        admins = [a.strip() for a in v["admins"].get().split(",") if a.strip()]
        if self._user.lower() not in {a.lower() for a in admins} and os.environ.get("BBSCANNER_ADMIN") != "1":
            return self._show_warn_popup("Guardar política", "Su usuario no está en la lista de administradores: al "
                                         "guardar perdería el acceso a esta sección. Agréguelo antes de guardar.")
        versions = {k: var.get().strip().lstrip("v") for k, var in self._admin_versions.items() if var.get().strip()}
        for k, ver in versions.items():
            if ver in tm.BLOCKED.get(k, set()):
                return self._show_error_popup("Versión bloqueada", f"{tm.LABELS[k]} {ver} es una versión comprometida "
                                              "conocida y no se puede fijar.")
        names = {str(a.get("id", "")).lower(): a.get("name", "") for a in self._inv_store.list_apps()}
        apps = sorted({names.get(a, a) for a in self._admin_apps}, key=str.lower)
        pol = {**pol, "admins": admins,
               "probely": {**pol.get("probely", {}), "api_key": v["key"].get().strip(), "apps": apps,
                           "fallback_open_source": bool(v["fallback"].get())},
               "tools": {"versions": versions, "mirror_base": v["mirror"].get().strip()},
               "trivy": {"db_repository": v["db"].get().strip(), "java_db_repository": v["javadb"].get().strip(),
                         "checks_bundle_repository": v["checks"].get().strip()}}
        try:
            admin_policy.save(pol, actor=self._user)
        except Exception as e:
            return self._show_error_popup("Guardar política", f"No se pudo escribir {admin_policy.POLICY_FILE}:\n{e!r}")
        audit(self._reports_var.get(), "admin_policy_saved", actor=self._user, probely_apps=apps,
              versions=versions, log=self._emit_log)
        self._admin_meta.config(text=self._admin_meta_text(admin_policy.load()))
        self._toast("Política guardada — distribuya admin_policy.json con el programa", "ok")
        self._refresh_engine_badge_text()
        if hasattr(self, "_refresh_engine_cards"):
            self._refresh_engine_cards()

    def _admin_tools_refresh(self):
        tree = getattr(self, "_admin_tools", None)
        if tree is None or not tree.winfo_exists():
            return

        def work():
            sts = tm.all_status()

            def paint():
                if not tree.winfo_exists():
                    return
                clear_tree(tree)
                for st in sts:
                    tree.insert("", "end", iid=st.key, tags=(stripe(tree),), values=(
                        st.label, tm.PURPOSE[st.key], ("✓ " if st.installed else "") + st.detail, tm.PINNED[st.key]))
                self._apply_engine_cache(sts)
            self._ui(paint)
        threading.Thread(target=work, daemon=True).start()

    def _admin_tool_install(self):
        sel = self._admin_tools.selection()
        keys = list(sel) or list(tm.installable())

        def work():
            for k in keys:
                try:
                    tm.ensure(k, self._emit_log, force=bool(sel))
                except Exception as e:
                    self._emit_log(f"[motores] {tm.LABELS[k]}: {e}")
            self._ui(self._admin_tools_refresh)
        self._run_async(work, "instalar motores", busy_attr="_tools_busy")

    def _admin_tool_remove(self):
        sel = self._admin_tools.selection()
        if not sel:
            return self._toast("Seleccione un motor de la lista", "warn")
        self._show_confirm_popup("Eliminar motor", f"¿Eliminar {tm.LABELS[sel[0]]} de la carpeta de herramientas? Se "
                                 "volverá a descargar al siguiente escaneo que lo necesite.",
                                 on_yes=lambda: (tm.remove(sel[0], self._emit_log), self._admin_tools_refresh()),
                                 yes_label="🗑  Eliminar", no_label="Cancelar")

    # ── ServiceNow: modo prueba ─────────────────────────────────────────────
    def _admin_toggle_snow_test(self):
        on = bool(self._admin_snow_test.get())
        self._snow_test_mode = on
        self._save_settings()
        audit(self._reports_var.get(), "servicenow_test_mode", actor=self._user, enabled=on, log=self._emit_log)
        self._emit_log("[servicenow] MODO PRUEBA activado en este equipo — los escaneos no crearán ni actualizarán "
                       "tickets." if on else "[servicenow] modo prueba desactivado — los tickets vuelven a crearse "
                       "automáticamente.")
        self._toast("Modo prueba: no se crearán tickets" if on else "Tickets de ServiceNow reactivados",
                    "warn" if on else "ok")
        self._refresh_scan_btn()
