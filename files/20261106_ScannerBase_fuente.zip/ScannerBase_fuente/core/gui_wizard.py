"""Asistente de primer escaneo para desarrolladores (autoservicio).

Cuatro pasos con un riel vertical a la izquierda: aplicación → qué escanear (con detección automática del repositorio)
→ conexiones y motores → revisar y ejecutar. Lo que el usuario captura aquí se aplica de inmediato a las pantallas
normales y, si lo desea, se guarda en el perfil de la aplicación.
"""
from __future__ import annotations

from ui_common import *
from gui_admin_tab import admin_policy
import tool_manager as tm
from infra_scanner import detect_project, recommended_stages

STAGE_INFO = {
    "sca": ("Dependencias (SCA)", "Librerías de código abierto con vulnerabilidades conocidas", "package"),
    "code": ("Código (SAST)", "Errores de seguridad en su propio código", "code"),
    "secrets": ("Secretos", "Contraseñas, tokens y llaves dentro del repositorio", "key"),
    "container": ("Contenedores", "Paquetes vulnerables dentro de sus imágenes", "container"),
    "iac": ("Infraestructura (IaC)", "Terraform, Kubernetes, Helm, Dockerfile mal configurados", "iac"),
    "dast": ("Sitio web (DAST)", "Ataques simulados contra la aplicación en ejecución", "globe"),
    "api": ("API", "Pruebas sobre los endpoints de su especificación OpenAPI / Postman", "link"),
}
STEPS = (("app", "Tu aplicación", "Para agrupar resultados e historial"),
         ("scan", "Qué escanear", "Repositorio, sitio, API e imágenes"),
         ("connect", "Conexiones", "Snyk y motores de escaneo"),
         ("run", "Revisar y ejecutar", "Confirmar y lanzar"))
_EMPTY_URLS = ("", "https://", "http://")


class _WizardMixin:
    def open_wizard(self) -> None:
        wiz = getattr(self, "_wizard_instance", None)
        if wiz and wiz.win.winfo_exists():
            wiz.win.lift()
            return wiz.win.focus_force()
        holder = []
        popup = self._popup("Asistente de configuración", on_escape=lambda: holder and holder[0].on_close())
        self._wizard_instance = _Wizard(self, popup)
        holder.append(self._wizard_instance)


class _Wizard:
    def __init__(self, app, popup):
        self.app, self.popup, self.win = app, popup, popup._win
        self.step, self.no_app, self.save_to_app = 0, False, tk.BooleanVar(value=True)
        self.launching = False
        self.detected: Optional[dict] = None
        self.recommended: set = set()
        self.tool_status: dict = {}
        hdr = app._popup_hdr(popup, "Configurar mi escaneo", subtitle="Unos minutos y su primer reporte estará listo.",
                             on_close=self.on_close)
        self.step_lbl = tk.Label(hdr._row, font=(FUI, 10), bg=T["panel_bg"], fg=T["muted"])
        self.step_lbl.pack(side="right", padx=(0, px(8)))
        foot = tk.Frame(popup, bg=T["panel_bg"], padx=px(24), pady=px(12))
        foot.pack(fill="x", side="bottom")
        tk.Frame(popup, bg=T["border"], height=1).pack(fill="x", side="bottom")
        # Los botones se empaquetan ANTES que el mensaje de estado: en monitores pequeños el texto se ajusta y los
        # botones siempre quedan visibles (antes el mensaje con ancho fijo los empujaba fuera del panel).
        self.b_next = PillButton(foot, "Siguiente", self.do_next, variant="primary")
        self.b_next.pack(side="right")
        self.b_alt = PillButton(foot, "Finalizar sin escanear", self.finish)
        self.b_prev = PillButton(foot, "Atrás", self.do_prev, icon="back")
        self.b_prev.pack(side="right", padx=(0, px(8)))
        self.status = autowrap(tk.Label(foot, font=(FUI, 10), bg=T["panel_bg"], fg=T["muted"], anchor="w",
                                        justify="left"), 8, 80)
        self.status.pack(side="left", fill="x", expand=True, padx=(0, px(12)))
        body = tk.Frame(popup, bg=T["bg"])
        body.pack(fill="both", expand=True)
        self.rail = tk.Frame(body, bg=T["surface2"], width=px(230))
        self.rail.pack(side="left", fill="y")
        self.rail.pack_propagate(False)
        tk.Frame(body, bg=T["border"], width=1).pack(side="left", fill="y")
        self.content = tk.Frame(body, bg=T["bg"])
        self.content.pack(side="left", fill="both", expand=True)
        self._eng_box = None          # contenedor de las filas de motores del paso «Conexiones»
        self._eng_strips: dict = {}
        self._eng_sig = None
        self.app._eng_subscribe(self._on_engines)
        self.app._refresh_engine_cache()
        self.render(0)

    # ── Estructura ──────────────────────────────────────────────────────────
    def _paint_rail(self):
        for w in self.rail.winfo_children():
            w.destroy()
        bg = T["surface2"]
        tk.Frame(self.rail, bg=bg, height=px(18)).pack(fill="x")
        for i, (key, title, sub) in enumerate(STEPS):
            done, cur = i < self.step, i == self.step
            row = tk.Frame(self.rail, bg=T["panel_bg"] if cur else bg, padx=px(13), pady=px(10),
                           cursor="hand2" if i < self.step else "")
            row.pack(fill="x")
            tk.Frame(row, bg=T["accent"] if cur else row["bg"], width=px(3)).pack(side="left", fill="y",
                                                                                  padx=(0, px(10)))
            c = tk.Canvas(row, width=px(26), height=px(26), bg=row["bg"], highlightthickness=0)
            fill = T["ok"] if done else T["accent"] if cur else T["toggle_off"]
            c.create_oval(1, 1, px(25), px(25), fill=fill, outline="")
            c.create_text(px(13), px(13), text="✓" if done else str(i + 1), font=(FUI, 10, "bold"),
                          fill=T["button_fg"] if cur else "#FFFFFF")
            c.pack(side="left", anchor="n")
            col = tk.Frame(row, bg=row["bg"])
            col.pack(side="left", fill="x", expand=True, padx=(px(10), 0))
            tk.Label(col, text=title, font=(FUI, 11, "bold" if cur else "normal"), bg=row["bg"],
                     fg=T["text"] if cur or done else T["muted"], anchor="w").pack(fill="x")
            tk.Label(col, text=sub, font=(FUI, 9), bg=row["bg"], fg=T["muted"], anchor="w", justify="left",
                     wraplength=px(160)).pack(fill="x")
            if i < self.step:
                for w in (row, c, col, *col.winfo_children()):
                    w.bind("<Button-1>", lambda _e, j=i: self.render(j))

    def render(self, idx: int):
        self.step = idx
        self._paint_rail()
        self.step_lbl.config(text=f"Paso {idx + 1} de {len(STEPS)}")
        for w in self.content.winfo_children():
            w.destroy()
        page = scroll_frame(self.content, pad=(px(28), px(20)))
        key, title, _ = STEPS[idx]
        tk.Label(page, text=title, font=(FUI_TITLE, 17, "bold"), bg=T["bg"], fg=T["text"], anchor="w").pack(fill="x")
        getattr(self, f"_step_{key}")(page)
        last = idx == len(STEPS) - 1
        self.b_prev.config(state="disabled" if idx == 0 else "normal")
        self.b_next.config(text="Ejecutar escaneo" if last else "Siguiente")
        if last:
            self.b_alt.pack(side="right", padx=(0, px(8)), before=self.b_prev)
        else:
            self.b_alt.pack_forget()
        self.set_status("")

    def refresh_if_auth_step(self):
        if self.win.winfo_exists() and STEPS[self.step][0] in ("connect", "run"):
            self.render(self.step)

    def set_status(self, msg: str, error: bool = False):
        self.status.config(text=msg, fg=T["err"] if error else T["muted"])

    def _lead(self, parent, text):
        autowrap(tk.Label(parent, text=text, font=(FUI, 11), bg=T["bg"], fg=T["muted"], anchor="w", justify="left"),
                 6, 160).pack(fill="x", pady=(px(4), px(16)))

    def _card(self, parent, title=""):
        return self.app._card(parent, title, collapsible=False)

    def _check_row(self, parent, state, text, action=None):
        """state: ok | warn | err | info"""
        role, glyph = {"ok": ("ok", "check"), "warn": ("warn", "warn"), "err": ("err", "error"),
                       "info": ("muted", "info")}[state]
        row = tk.Frame(parent, bg=T["panel_bg"])
        row.pack(fill="x", pady=(0, px(6)))
        tk.Label(row, text=ico(glyph), font=icon_font(11), bg=T["panel_bg"], fg=T[role]).pack(side="left", anchor="n",
                                                                                              pady=(px(2), 0))
        if action:  # primero el botón (p. ej. «Iniciar sesión con SSO»): así nunca queda oculto a la derecha
            PillButton(row, action[0], action[1], size=10).pack(side="right", anchor="n", padx=(px(10), 0))
        autowrap(tk.Label(row, text=text, font=(FUI, 10), bg=T["panel_bg"], fg=T["text"], anchor="w", justify="left"),
                 6, 120).pack(side="left", fill="x", expand=True, padx=(px(8), 0))
        return row

    # ── Estado derivado ─────────────────────────────────────────────────────
    def _sel(self) -> set:
        return {k for k, v in self.app._scan_vars.items() if v.get()}

    def _folder(self) -> str:
        a = self.app
        return a._target_var.get().strip() or (a._static_paths[0] if a._static_paths else "")

    def _problems(self, key: str) -> list:
        a, sel = self.app, self._sel()
        out = []
        if key == "app" and not (a._active_app and a._active_app.get("name")) and not self.no_app:
            out.append("Elija o cree una aplicación, o marque «Escanear sin aplicación».")
        if key == "scan":
            if not sel:
                out.append("Active al menos un tipo de escaneo.")
            if sel & set(STATIC_STAGES) and not self._folder():
                out.append("Indique la carpeta del repositorio para SCA, SAST y Secretos.")
            if "iac" in sel and not a._iac_paths_effective():
                out.append("Indique la carpeta del repositorio (o una carpeta de IaC).")
            if "dast" in sel and a._dast_url_var.get().strip() in _EMPTY_URLS:
                out.append("Escriba la URL del sitio web para DAST.")
            if "api" in sel and not a._api_spec_var.get().strip():
                out.append("Seleccione la especificación de la API.")
            if "container" in sel and not a._container_sources_clean():
                out.append("Agregue al menos una imagen de contenedor.")
        if key == "connect" and sel & {"sca", "code"} and a._key_auth_status != "auth":
            out.append("Inicie sesión en Snyk con «Log in with SSO» (no con su correo) o desactive SCA y SAST en el "
                       "paso anterior.")
        return out

    # ── Navegación ──────────────────────────────────────────────────────────
    def do_next(self):
        key = STEPS[self.step][0]
        if key == "run":
            return self._run()
        probs = self._problems(key)
        if probs:
            return self.set_status(probs[0], error=True)
        self.render(self.step + 1)

    def do_prev(self):
        if self.step:
            self.render(self.step - 1)

    def finish(self):
        self._persist_profile()
        self.popup.close()
        self.app._wizard_seen = True
        self.app._save_settings()
        self.app._refresh_scan_btn()
        self.app._toast("Configuración guardada", "ok")

    def on_close(self):
        self.app._show_confirm_popup("¿Cerrar el asistente?", "Lo que ya configuró se conserva. Puede volver a abrir el "
                                     "asistente desde «Asistente» en la barra lateral.", on_yes=self.popup.close,
                                     yes_label="Cerrar", no_label="Seguir aquí")

    def _run(self):
        for key in ("app", "scan", "connect"):
            if probs := self._problems(key):
                return self.set_status(probs[0], error=True)
        self._persist_profile()
        self.popup.close()
        self.app._wizard_seen = True
        self.app._save_settings()
        self.app._show_tab("scan")
        self.app._run_scan_pipeline()

    def _persist_profile(self):
        a = self.app
        a._persist_scan_stages()
        if not (self.save_to_app.get() and a._active_app and a._active_app.get("id")):
            return
        app = a._active_app
        folder = self._folder()
        app.update(target_path=folder or app.get("target_path", ""), static_paths=list(a._static_paths),
                   dast_url="" if a._dast_url_var.get().strip() in _EMPTY_URLS else a._dast_url_var.get().strip(),
                   api_spec=a._api_spec_var.get().strip(), container_sources=list(a._container_sources),
                   iac_paths=list(a._iac_paths), scan_stages=sorted(self._sel()))
        try:
            a._inv_store.save_app(app)
            a._refresh_inventory()
        except Exception as e:
            a._emit_log(f"[asistente] no se pudo guardar el perfil: {e!r}")

    # ── Paso 1: aplicación ─────────────────────────────────────────────────
    def _step_app(self, p):
        a = self.app
        self._lead(p, "Cada aplicación guarda sus objetivos de escaneo, su historial y la tendencia de vulnerabilidades. "
                   "Si su aplicación ya existe en el inventario, solo selecciónela.")
        card = self._card(p, "Aplicación")
        apps = sorted(a._inv_store.list_apps(), key=lambda x: x.get("name", "").lower())
        by_name = {x["name"]: x for x in apps if x.get("name")}
        cur = (a._active_app or {}).get("name", "")
        row = tk.Frame(card, bg=T["panel_bg"])
        row.pack(fill="x")
        var = tk.StringVar(value=cur)
        cb = ttk.Combobox(row, textvariable=var, values=list(by_name), state="readonly")
        cb.pack(side="left", fill="x", expand=True)

        def picked(_e=None):
            if app := by_name.get(var.get()):
                self.no_app = False
                a._load_app_profile(app, silent=True)
                self.render(self.step)
        cb.bind("<<ComboboxSelected>>", picked)

        def saved(_x):
            if self.win.winfo_exists():
                self.no_app = False
                self.render(self.step)
        PillButton(row, "Nueva aplicación", lambda: a._edit_app_profile(None, on_saved=saved), icon="add").pack(
            side="left", padx=(px(8), 0))
        if not apps:
            tk.Label(card, text="Todavía no hay aplicaciones en el inventario — cree la suya con «Nueva aplicación».",
                     font=(FUI, 10), bg=T["panel_bg"], fg=T["muted"], anchor="w").pack(fill="x", pady=(px(8), 0))
        if a._active_app and a._active_app.get("name"):
            act = a._active_app
            info = tk.Frame(card, bg=T["surface2"], padx=px(14), pady=px(10))
            info.pack(fill="x", pady=(px(12), 0))
            tk.Label(info, text=act["name"], font=(FUI, 12, "bold"), bg=T["surface2"], fg=T["text"], anchor="w").pack(
                fill="x")
            meta = " · ".join(x for x in (act.get("app_type"), act.get("environment"), act.get("criticality")) if x)
            tk.Label(info, text=meta or "Sin clasificación", font=(FUI, 10), bg=T["surface2"], fg=T["muted"],
                     anchor="w").pack(fill="x")
            eng, label = admin_policy.engine_label(act)
            tk.Label(info, text=f"Motor web/API: {label}", font=(FUI, 9), bg=T["surface2"],
                     fg=T["accent"] if eng == "probely" else T["muted"], anchor="w").pack(fill="x", pady=(px(4), 0))
        no = tk.BooleanVar(value=self.no_app)

        def toggle_no():
            self.no_app = no.get()
            self.set_status("")
        ToggleSwitch(p, text="Escanear sin aplicación (los resultados quedan sin catalogar)", variable=no,
                     command=toggle_no).pack(anchor="w", pady=(px(4), 0))

    # ── Paso 2: qué escanear ───────────────────────────────────────────────
    def _step_scan(self, p):
        a = self.app
        self._lead(p, "Indique la carpeta de su repositorio: detectamos qué contiene y activamos los escaneos "
                   "recomendados. Puede ajustar la selección.")
        card = self._card(p, "Repositorio")
        row = tk.Frame(card, bg=T["panel_bg"])
        row.pack(fill="x")
        folder = tk.StringVar(value=self._folder())
        ttk.Entry(row, textvariable=folder).pack(side="left", fill="x", expand=True)
        det_box = tk.Frame(card, bg=T["panel_bg"])
        det_box.pack(fill="x", pady=(px(10), 0))

        def set_folder(path, apply_rec=True):
            path = (path or "").strip()
            if not path:
                return
            a._target_var.set(path)
            if path not in a._static_paths:
                a._static_paths.insert(0, path)
                a._render_static_paths()
                a._persist_static_paths()
            a._render_iac_paths()
            self._detect(path, det_box, apply_rec)

        def browse():
            with dialog_guard(self.win):
                d = filedialog.askdirectory(title="Carpeta del repositorio", parent=self.win,
                                            initialdir=folder.get() or APP_DIR)
            if d:
                folder.set(d)
                set_folder(d)
        PillButton(row, "Examinar", browse, icon="folder").pack(side="left", padx=(px(8), 0))
        folder_entry = row.winfo_children()[0]
        folder_entry.bind("<FocusOut>", lambda _e: folder.get().strip() != self._folder() and set_folder(folder.get()))
        folder_entry.bind("<Return>", lambda _e: set_folder(folder.get()))
        if self.detected is not None:
            self._paint_detection(det_box)
        elif self._folder():
            self._detect(self._folder(), det_box, apply_rec=False)
        else:
            tk.Label(det_box, text="Sin carpeta: también puede escanear solo un sitio web, una API o imágenes.",
                     font=(FUI, 10), bg=T["panel_bg"], fg=T["muted"], anchor="w").pack(fill="x")
        card = self._card(p, "Tipos de escaneo")
        self.tiles_box = tk.Frame(card, bg=T["panel_bg"])
        self.tiles_box.pack(fill="x")
        self.inputs_card = self._card(p, "Objetivos")
        self._paint_tiles()

    def _detect(self, path, box, apply_rec):
        for w in box.winfo_children():
            w.destroy()
        tk.Label(box, text="Analizando el contenido de la carpeta…", font=(FUI, 10), bg=T["panel_bg"],
                 fg=T["muted"], anchor="w").pack(fill="x")

        def work():
            det = detect_project(path) if Path(path).is_dir() else None
            self.app._ui(done, det)

        def done(det):
            if not box.winfo_exists():
                return
            self.detected = det or {}
            self.recommended = recommended_stages(det) if det else set()
            if apply_rec and det:
                for k in STATIC_STAGES + ("iac",):
                    self.app._scan_vars[k].set(k in self.recommended)
                self.app._persist_scan_stages()
                self.app._refresh_scan_btn()
            self._paint_detection(box)
            if hasattr(self, "tiles_box") and self.tiles_box.winfo_exists():
                self._paint_tiles()
        threading.Thread(target=work, daemon=True).start()

    def _paint_detection(self, box):
        for w in box.winfo_children():
            w.destroy()
        det = self.detected or {}
        if not det:
            tk.Label(box, text="La carpeta no existe o no se puede leer.", font=(FUI, 10), bg=T["panel_bg"],
                     fg=T["warn"], anchor="w").pack(fill="x")
            return
        tk.Label(box, text="Detectado:", font=(FUI, 9, "bold"), bg=T["panel_bg"], fg=T["muted"]).pack(side="left")
        chips = []
        if det.get("manifests"):
            chips.append(f"{len(det['manifests'])} manifiesto(s) de dependencias")
        if det.get("source"):
            chips.append(f"{det['source']} archivo(s) de código")
        for k, n in (det.get("iac") or {}).items():
            chips.append(f"{k} · {n}")
        if not chips:
            chips.append("sin código reconocible")
        for c in chips[:6]:
            pill_label(box, c, "text", "surface3", 9).pack(side="left", padx=(px(6), 0))
        if det.get("dockerfiles"):
            tk.Label(box, text="  ·  Hay Dockerfile: si publica una imagen, agréguela en Contenedores.", font=(FUI, 9),
                     bg=T["panel_bg"], fg=T["muted"]).pack(side="left")

    def _paint_tiles(self):
        box, a = self.tiles_box, self.app
        for w in box.winfo_children():
            w.destroy()
        box.columnconfigure(0, weight=1, uniform="t")
        box.columnconfigure(1, weight=1, uniform="t")
        for i, k in enumerate(STAGES):
            name, desc, icon = STAGE_INFO[k]
            on = a._scan_vars[k].get()
            bg = T["accent_soft"] if on else T["panel_bg"]
            tile = tk.Frame(box, bg=bg, highlightthickness=1, highlightbackground=T["accent"] if on else T["border"],
                            padx=px(12), pady=px(10), cursor="hand2")
            tile.grid(row=i // 2, column=i % 2, sticky="nsew", padx=(0 if i % 2 == 0 else px(4), 0 if i % 2 else px(4)),
                      pady=(0, px(8)))
            top = tk.Frame(tile, bg=bg)
            top.pack(fill="x")
            tk.Label(top, text=ico(icon), font=icon_font(12), bg=bg, fg=T["accent"] if on else T["muted"]).pack(
                side="left")
            tk.Label(top, text=name, font=(FUI, 11, "bold"), bg=bg, fg=T["text"]).pack(side="left", padx=(px(8), 0))
            if k in self.recommended:
                pill_label(top, "Recomendado", "ok", "ok_soft", 8).pack(side="left", padx=(px(6), 0))
            tk.Label(top, text=ico("check") if on else "", font=icon_font(11), bg=bg, fg=T["accent"]).pack(side="right")
            d = autowrap(tk.Label(tile, text=desc, font=(FUI, 9), bg=bg, fg=T["muted"], anchor="w", justify="left"),
                         4, 160)
            d.pack(fill="x", pady=(px(2), 0))
            for w in (tile, top, d, *top.winfo_children()):
                w.bind("<Button-1>", lambda _e, key=k: self._toggle_stage(key))
        self._paint_inputs()

    def _toggle_stage(self, k):
        v = self.app._scan_vars[k]
        v.set(not v.get())
        self.app._persist_scan_stages()
        self.app._refresh_scan_btn()
        self.set_status("")
        self._paint_tiles()

    def _paint_inputs(self):
        card, a, sel = self.inputs_card, self.app, self._sel()
        for w in card.winfo_children():
            w.destroy()
        p = T["panel_bg"]
        shown = False

        def label(text):
            tk.Label(card, text=text, font=(FUI, 10, "bold"), bg=p, fg=T["muted"], anchor="w").pack(fill="x",
                                                                                                   pady=(px(4), px(3)))
        if "dast" in sel:
            shown = True
            label("URL del sitio web (DAST)")
            ttk.Entry(card, textvariable=a._dast_url_var).pack(fill="x")
            tk.Label(card, text="Si requiere inicio de sesión, configúrelo después en «Web (DAST)».", font=(FUI, 9),
                     bg=p, fg=T["muted"], anchor="w").pack(fill="x", pady=(px(2), px(8)))
        if "api" in sel:
            shown = True
            label("Especificación de la API (OpenAPI, Swagger, Postman)")
            row = tk.Frame(card, bg=p)
            row.pack(fill="x", pady=(0, px(8)))
            ttk.Entry(row, textvariable=a._api_spec_var).pack(side="left", fill="x", expand=True)

            def browse():
                with dialog_guard(self.win):
                    f = filedialog.askopenfilename(title="Especificación de la API", parent=self.win, filetypes=[
                        ("OpenAPI / Postman", "*.yaml *.yml *.json"), ("Todos", "*.*")])
                if f:
                    a._api_spec_var.set(f)
            PillButton(row, "", browse, icon="folder", tooltip="Examinar…").pack(side="left", padx=(px(8), 0))
        if "container" in sel:
            shown = True
            label("Imágenes de contenedor")
            cur = ", ".join(s["value"] for s in a._container_sources if s.get("type") == "registry")
            var = tk.StringVar(value=cur)
            e = ttk.Entry(card, textvariable=var)
            e.pack(fill="x")

            def commit(_e=None):
                imgs = [x.strip() for x in re.split(r"[,\n;]+", var.get()) if x.strip()]
                others = [s for s in a._container_sources if s.get("type") != "registry"]
                a._container_sources[:] = [{"type": "registry", "value": x} for x in dict.fromkeys(imgs)] + others
                a._render_container_sources()
                a._persist_infra()
            e.bind("<FocusOut>", commit)
            var.trace_add("write", lambda *_: commit())
            n_other = sum(1 for s in a._container_sources if s.get("type") != "registry")
            tk.Label(card, text="Ej.: registro.bancobase.com/equipo/servicio:1.4.2 — separe varias con coma."
                     + (f"  (+{n_other} archivo(s) .tar/SBOM agregados en Contenedores)" if n_other else ""),
                     font=(FUI, 9), bg=p, fg=T["muted"], anchor="w").pack(fill="x", pady=(px(2), px(8)))
        if "iac" in sel:
            shown = True
            eff = a._iac_paths_effective()
            label("Infraestructura como código")
            tk.Label(card, text=f"Se analizará: {middle_ellipsis(eff[0], 70)}" if eff else
                     "Se usará la carpeta del repositorio.", font=(FUI, 10), bg=p, fg=T["text"], anchor="w").pack(fill="x")
        if not shown:
            tk.Label(card, text="Los escaneos seleccionados solo necesitan la carpeta del repositorio.", font=(FUI, 10),
                     bg=p, fg=T["muted"], anchor="w").pack(fill="x")

    # ── Paso 3: conexiones ─────────────────────────────────────────────────
    def _step_connect(self, p):
        a, sel = self.app, self._sel()
        self._lead(p, "Revisamos lo que necesitan los escaneos elegidos. Descargue ahora los motores de código abierto "
                   "para que el primer escaneo sea más rápido; verá el avance de cada uno aquí y en «Motores».")
        if sel & {"sca", "code"}:
            card = self._card(p, "Snyk (SCA y SAST)")
            st = a._key_auth_status
            if st != "auth":
                warn, _ = a._alert(card, "error", SNYK_SSO_TITLE, SNYK_SSO_WARNING)
                warn.pack(fill="x", pady=(0, px(10)))
            if st == "auth":
                self.launching = False
                self._check_row(card, "ok", "Sesión de Snyk activa.", ("Reiniciar sesión", self._sso_login))
            elif self.launching:
                self._check_row(card, "info", "Abriendo el navegador (puede tardar hasta 30 s). Haga clic en «Log in "
                                "with SSO»; ya en la pantalla de SSO escriba su correo corporativo o el dominio "
                                "bancobase.com y entre con su usuario de red. Esta pantalla se actualiza sola.", ("Reintentar", self._sso_login))
            elif st == "checking":
                self._check_row(card, "info", "Verificando la sesión de Snyk…")
            else:
                self._check_row(card, "err", "Sin sesión de Snyk. Al pulsar «Iniciar sesión con SSO» se abre su "
                                "navegador; regrese aquí al terminar.", ("Iniciar sesión con SSO", self._sso_login))
        tools = list(dict.fromkeys(t for s in sel for t in tm.stage_tools(s)))
        tools += [d for t in tools for d in tm.NEEDS.get(t, ()) if d not in tools]
        self._eng_tools = tools
        self._eng_box = None
        if tools:
            card = self._card(p, "Motores de escaneo")
            self._eng_box = tk.Frame(card, bg=T["panel_bg"])
            self._eng_box.pack(fill="x")
            self._paint_engines()
        if sel & {"dast", "api"}:
            card = self._card(p, "Escaneo web y de API")
            eng, label = admin_policy.engine_label(a._active_app)
            self._check_row(card, "ok", f"Motor: {label}.")
            self._check_row(card, "info", "Escanee solo sitios y APIs de su equipo en ambientes de desarrollo o QA. "
                            "Los perfiles «Seguro» y «Rápido» no envían ataques destructivos.")
        if not (sel & {"sca", "code"}) and not tools and not (sel & {"dast", "api"}):
            self._check_row(self._card(p), "ok", "Los escaneos elegidos no necesitan conexiones adicionales.")

    # ── Motores: filas con progreso (mismo estado que el diálogo «Motores») ─
    def _eng_signature(self):
        prog = getattr(self.app, "_eng_prog", {}) or {}
        cache = {s.key: (s.installed, s.version) for s in (getattr(self.app, "_engine_cache", None) or [])}
        return tuple((t, (prog.get(t) or {}).get("state"), cache.get(t)) for t in getattr(self, "_eng_tools", ()))

    def _paint_engines(self):
        box, a = self._eng_box, self.app
        if box is None or not box.winfo_exists():
            return
        for w in box.winfo_children():
            w.destroy()
        self._eng_strips = {}
        self._eng_sig = self._eng_signature()
        tools = self._eng_tools
        prog = getattr(a, "_eng_prog", {}) or {}
        cache = {s.key: s for s in (getattr(a, "_engine_cache", None) or [])}
        for t in tools:
            st, p = cache.get(t), prog.get(t) or {}
            state = p.get("state")
            if state in ("queued", "running"):
                self._check_row(box, "info", f"{tm.LABELS[t]} — " + ("en cola…" if state == "queued" else
                                                                     "preparando…"))
            elif state == "error":
                self._check_row(box, "err", f"{tm.LABELS[t]} — no se pudo preparar",
                                ("Reintentar", lambda t=t: a._engines_run([t], force=True)))
            elif st is None:
                self._check_row(box, "info", f"{tm.LABELS[t]} — verificando…")
            elif st.installed:
                self._check_row(box, "ok", f"{tm.LABELS[t]} {st.version} — listo")
            else:
                self._check_row(box, "warn", f"{tm.LABELS[t]} — no instalado ({tm.PURPOSE[t]})",
                                ("Descargar", lambda t=t: self._prepare([t])))
            if state:
                strip = a._eng_strip(box, t, T["panel_bg"])
                strip.pack(fill="x", padx=(px(26), 0), pady=(0, px(8)))
                self._eng_strips[t] = strip
        row = tk.Frame(box, bg=T["panel_bg"])
        row.pack(fill="x", pady=(px(6), 0))
        busy = a._eng_active(tools)
        pending = [t for t in tools if (cache.get(t) is None or not cache[t].installed)]
        b = PillButton(row, "Preparando…" if busy else "Todo listo" if not pending and cache else "Preparar ahora",
                       lambda: self._prepare(tools), icon="download")
        b.pack(side="left")
        if busy or (not pending and cache):
            b.config(state="disabled")
        tk.Label(row, text="Sin Docker ni permisos de administrador · descargas verificadas con SHA-256",
                 font=(FUI, 9), bg=T["panel_bg"], fg=T["muted"]).pack(side="left", padx=(px(10), 0))

    def _on_engines(self):
        """Llamado por la app cuando cambia el progreso o el estado de los motores (desde aquí o desde «Motores»)."""
        if not self.win.winfo_exists():
            return False
        if self._eng_box is None or not self._eng_box.winfo_exists() or STEPS[self.step][0] != "connect":
            return True
        if self._eng_signature() != self._eng_sig:
            self._paint_engines()
        else:
            for strip in self._eng_strips.values():
                strip.refresh()
        return True

    def _prepare(self, tools):
        a = self.app
        cache = {s.key: s for s in (getattr(a, "_engine_cache", None) or [])}
        keys = [t for t in tools if cache.get(t) is None or not cache[t].installed or cache[t].upgrade_to]
        if not keys:
            return self.set_status("Los motores necesarios ya están listos ✓")
        a._engines_run(keys, on_done=lambda done, errs: self.win.winfo_exists() and self.set_status(
            "Motores listos ✓" if not errs else f"{len(errs)} motor(es) no se pudieron preparar — use «Reintentar».",
            error=bool(errs)))
        self.set_status("Preparando motores — el avance se muestra en cada fila.")

    def _sso_login(self):
        self.launching = True
        self.render(self.step)
        threading.Thread(target=self.app._begin_snyk_auth, daemon=True).start()

    # ── Paso 4: revisar ────────────────────────────────────────────────────
    def _step_run(self, p):
        a, sel = self.app, self._sel()
        self._lead(p, "Confirme la configuración. Al terminar se genera un reporte HTML con lo que hay que corregir "
                   "primero.")
        card = self._card(p, "Resumen")
        act = a._active_app
        self._check_row(card, "ok" if act else "warn", f"Aplicación: {act['name']}" if act else
                        "Sin aplicación — el reporte quedará en «_unscoped» y no tendrá historial.")
        self._check_row(card, "ok" if sel else "err", "Escaneos: " + (", ".join(STAGE_INFO[k][0] for k in STAGES
                                                                                if k in sel) or "ninguno"))
        if sel & set(STATIC_STAGES):
            self._check_row(card, "ok", f"Repositorio: {middle_ellipsis(self._folder(), 70)}")
        if "dast" in sel:
            self._check_row(card, "ok", f"Sitio web: {a._dast_url_var.get().strip()}")
        if "api" in sel:
            self._check_row(card, "ok", f"API: {middle_ellipsis(a._api_spec_var.get().strip(), 70)}")
        if "container" in sel:
            self._check_row(card, "ok", f"Imágenes: {len(a._container_sources_clean())}")
        if "iac" in sel and (eff := a._iac_paths_effective()):
            self._check_row(card, "ok", f"IaC: {middle_ellipsis(eff[0], 70)}")
        for key in ("app", "scan", "connect"):
            for prob in self._problems(key):
                self._check_row(card, "err", prob)
        if act:
            ToggleSwitch(p, text=f"Guardar estos objetivos en el perfil de «{act['name']}»",
                         variable=self.save_to_app).pack(anchor="w", pady=(px(4), 0))
        mins = 2 + (8 if sel & {"dast", "api"} else 0) + (3 if sel & set(INFRA_STAGES) else 0)
        tk.Label(p, text=f"Duración estimada: {mins}–{mins * 3} min. Puede seguir trabajando; le avisaremos al terminar.",
                 font=(FUI, 10), bg=T["bg"], fg=T["muted"], anchor="w").pack(fill="x", pady=(px(8), 0))
