"""Política de administración (Ciberseguridad).

Archivo: admin_policy.json junto al programa. Lo edita un administrador desde la sección «Administración» (visible
solo para los usuarios de Windows listados en «admins») y se distribuye con el programa.

Controla:
  · Qué aplicaciones usan Probely (5 licencias) y la clave de API. El usuario final nunca ve ni captura la clave:
    las demás aplicaciones escanean con ZAP + Nuclei automáticamente.
  · Versiones fijadas de los motores y un espejo interno de descargas (para redes que bloquean GitHub).
  · Espejos de las bases de datos de Trivy.

Nota de seguridad: es un control de gobierno de la interfaz, no un control de acceso fuerte — la clave de Probely viaja
en el archivo para que las aplicaciones asignadas puedan escanear desde la máquina del desarrollador. Use una clave de
Probely con el rol mínimo necesario.
"""
from __future__ import annotations

from ui_common import *

POLICY_FILE = APP_DIR / "admin_policy.json"
DEFAULT_ADMINS = [SUPPORT_EMAIL.split("@")[0]]
_DEFAULT = {"version": 1, "admins": DEFAULT_ADMINS,
            "probely": {"api_key": "", "apps": [], "fallback_open_source": True, "max_apps": 5},
            "tools": {"versions": {}, "mirror_base": ""},
            "trivy": {"db_repository": "", "java_db_repository": "", "checks_bundle_repository": ""},
            "updated_by": "", "updated_at": ""}
_cache: dict = {"mtime": None, "data": None}
_lock = threading.Lock()


def _merge(base: dict, over: dict) -> dict:
    out = dict(base)
    for k, v in (over or {}).items():
        out[k] = _merge(base[k], v) if isinstance(v, dict) and isinstance(base.get(k), dict) else v
    return out


def load() -> dict:
    with _lock:
        try:
            mt = POLICY_FILE.stat().st_mtime
        except OSError:
            mt = None
        if _cache["data"] is not None and _cache["mtime"] == mt:
            return _cache["data"]
        data = _merge(_DEFAULT, read_json(POLICY_FILE, {}) or {}) if mt else _merge(_DEFAULT, {})
        _cache.update(mtime=mt, data=data)
        return data


def save(data: dict, actor: str = "") -> None:
    data = _merge(_DEFAULT, data)
    data.update(updated_by=actor or detect_user(), updated_at=now_human())
    write_json(POLICY_FILE, data)
    with _lock:
        _cache.update(mtime=None, data=None)


def is_admin(user: str = "") -> bool:
    if os.environ.get("BBSCANNER_ADMIN", "").strip() == "1":
        return True
    u = (user or detect_user()).lower()
    return u in {a.strip().lower() for a in load().get("admins") or [] if a.strip()}


def probely_key() -> str:
    return (load().get("probely") or {}).get("api_key", "").strip()


def _app_keys(app: Optional[dict]) -> set:
    if not app:
        return set()
    return {str(app.get("id", "")).lower(), str(app.get("name", "")).lower()} - {""}


def probely_enabled_for(app: Optional[dict]) -> bool:
    p = load().get("probely") or {}
    allowed = {str(a).lower() for a in p.get("apps") or []}
    return bool(p.get("api_key", "").strip()) and bool(_app_keys(app) & allowed)


def probely_fallback() -> bool:
    return bool((load().get("probely") or {}).get("fallback_open_source", True))


def engine_label(app: Optional[dict]) -> tuple[str, str]:
    """(clave, texto) del motor web/API que usará la aplicación activa."""
    if probely_enabled_for(app):
        return "probely", "Probely · asignado por Ciberseguridad"
    return "oss", "ZAP + Nuclei · código abierto"

