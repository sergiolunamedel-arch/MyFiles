from __future__ import annotations

import hashlib
import html
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Optional

import tkinter as tk

from ui_common import FMONO, FUI, FUI_TITLE, T, px, sev_norm

NOWIN = {"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}
SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}
_GIT_SECRETS_STATUS: dict = {}


def _log(cb, msg: str) -> None:
    if cb:
        try:
            cb(msg)
        except Exception:
            pass


def download_file(url: str, dest: Path, log, timeout: int = 120, *, sha256_url: str = "",
                  allow_insecure: bool = True) -> bool:
    """Descarga a disco. Con sha256_url exige que el contenido coincida con el hash publicado. allow_insecure=False
    impide el reintento sin verificar TLS (obligatorio para ejecutables: un proxy/atacante podría sustituirlos)."""
    import hashlib
    import ssl
    import urllib.error
    import urllib.request

    def ctx():
        c = ssl.create_default_context()
        for ca in (os.environ.get("NODE_EXTRA_CA_CERTS"), os.environ.get("REQUESTS_CA_BUNDLE"),
                   os.environ.get("SSL_CERT_FILE")):
            if ca and Path(ca).is_file():
                try:
                    c.load_verify_locations(ca)
                except Exception:
                    pass
        return c

    def get(u):
        req = urllib.request.Request(u, headers={"User-Agent": "vuln-scanner/1.0"})
        try:
            with urllib.request.urlopen(req, timeout=timeout, context=ctx()) as r:
                return r.read()
        except urllib.error.URLError as e:
            if not isinstance(e.reason, ssl.SSLCertVerificationError):
                raise
            if not allow_insecure:
                raise RuntimeError(f"no se pudo verificar el certificado TLS de {u} ({e.reason}). Por seguridad no "
                                   "se descarga un ejecutable sin TLS verificado: instale la CA corporativa en Windows "
                                   "o defina NODE_EXTRA_CA_CERTS con la ruta del .pem.")
            log(f"[descarga] falló la verificación TLS ({e.reason}); reintentando sin verificar (solo host fijo)…")
            with urllib.request.urlopen(req, timeout=timeout, context=ssl._create_unverified_context()) as r:
                return r.read()
    try:
        log(f"[descarga] {url}")
        data = get(url)
        if not data:
            log("[descarga] respuesta vacía")
            return False
        if sha256_url:
            try:
                want = (get(sha256_url) or b"").decode("utf-8", "replace").split()[0].lower()
            except Exception as e:
                want = ""
                log(f"[descarga] no se pudo obtener el SHA-256 publicado ({e!r})")
            got = hashlib.sha256(data).hexdigest()
            if not re.fullmatch(r"[0-9a-f]{64}", want or ""):
                log("[descarga] sin SHA-256 publicado válido — descarga rechazada por seguridad")
                return False
            if got != want:
                log(f"[descarga] SHA-256 no coincide (esperado {want[:12]}…, obtenido {got[:12]}…) — descarga rechazada")
                return False
            log("[descarga] SHA-256 verificado ✓")
        dest.parent.mkdir(parents=True, exist_ok=True)
        tmp = dest.with_name(dest.name + ".part")
        tmp.write_bytes(data)
        os.replace(tmp, dest)
        log(f"[descarga] {len(data) // 1024} KB guardados → {dest}")
        return True
    except Exception as e:
        log(f"[descarga] falló: {e!r}")
        return False


def get_git_secrets_status() -> dict:
    """Estado sin descargar nada: si aún no se llamó a ensure_git_secrets, se consulta el gestor de motores."""
    if not _GIT_SECRETS_STATUS:
        try:
            import tool_manager as tm
            st = tm.status("gitsecrets")
            if st.installed:
                return {"available": True, "method": "git-secrets", "path": st.path, "has_git": bool(shutil.which("git")),
                        "has_bash": bool(tm.git_bash()), "note": st.detail}
        except Exception:
            pass
    return _GIT_SECRETS_STATUS


def _cache_dir() -> Path:
    d = Path(os.environ.get("LOCALAPPDATA") or Path.home() / ".cache") / "vuln-scanner" / "git-secrets"
    try:
        d.mkdir(parents=True, exist_ok=True)
    except Exception:
        d = Path(tempfile.gettempdir()) / "vuln-scanner-git-secrets"
        d.mkdir(parents=True, exist_ok=True)
    return d


def ensure_git_secrets(log=None) -> dict:
    """Instala/verifica git-secrets con el gestor de motores (versión fijada + SHA-256, espejo interno si existe)."""
    global _GIT_SECRETS_STATUS
    import tool_manager as tm
    status: dict[str, Any] = {"available": False, "method": "builtin", "path": None,
                              "has_git": bool(shutil.which("git")), "has_bash": bool(tm.git_bash()), "note": ""}
    try:
        path = tm.ensure("gitsecrets", log or (lambda _: None))
        status.update(available=True, method="git-secrets", path=path, note="listo")
        if not status["has_bash"]:
            _log(log, "[secretos] git-secrets está descargado pero falta Git para Windows (Git Bash) para ejecutarlo — "
                      "se usa solo el motor integrado. Instale Git para Windows para activar esa capa.")
    except Exception as e:
        status["note"] = f"no disponible — se usa el motor integrado ({e})"
        _log(log, f"[secretos] git-secrets no disponible: {e} — se usará solo el motor integrado.")
    _GIT_SECRETS_STATUS = status
    return status


_GIT_SECRETS_CUSTOM_PATTERNS = [
    r"-----BEGIN (RSA |EC |DSA |OPENSSH |PGP |ENCRYPTED )?PRIVATE KEY-----",
    r"AIza[0-9A-Za-z_-]{35}",
    r"gh[pousr]_[0-9A-Za-z]{36,255}",
    r"github_pat_[0-9A-Za-z_]{22,255}",
    r"glpat-[0-9A-Za-z_-]{20}",
    r"xox[baoprs]-[0-9A-Za-z-]{10,48}",
    r"(sk|rk)_(live|prod)_[0-9a-zA-Z]{20,}",
    r"AKIA[0-9A-Z]{16}",
    r"sk-ant-(api03|admin01)-[A-Za-z0-9_-]{93}AA",
    r"sk-[A-Za-z0-9_-]{20,74}T3BlbkFJ[A-Za-z0-9_-]{20,74}",
    r"hf_[A-Za-z]{34}",
    r"AGE-SECRET-KEY-1[0-9A-Za-z]{58}",
]


def _run_git_secrets(script: Path, target: Path, log=None) -> list[dict]:
    import tool_manager as tm
    git = shutil.which("git")
    if not git:
        _log(log, "[secretos] git no está instalado — se omite la capa git-secrets.")
        return []
    try:
        inside = subprocess.run([git, "-C", str(target), "rev-parse", "--is-inside-work-tree"], capture_output=True,
                                text=True, timeout=20, **NOWIN).stdout.strip() == "true"
    except Exception:
        inside = False
    if not inside:
        _log(log, "[secretos] la carpeta no es un repositorio git — git-secrets se omite (el motor integrado sí la "
                  "revisa completa).")
        return []
    bash = tm.git_bash()
    if not bash:
        _log(log, "[secretos] git-secrets requiere Git Bash (Git para Windows) — no se encontró; se omite esa capa.")
        return []
    findings: list[dict] = []
    gcfg = _cache_dir() / "gs_global.gitconfig"
    gcfg.unlink(missing_ok=True)  # se regenera en cada escaneo: evita que los patrones se dupliquen indefinidamente
    env = dict(os.environ, GIT_CONFIG_GLOBAL=str(gcfg), GIT_CONFIG_NOSYSTEM="1")

    def gs(*args, timeout=60):
        return subprocess.run([bash, Path(script).as_posix(), *args], cwd=str(target), env=env, timeout=timeout,
                              capture_output=True, text=True, encoding="utf-8", errors="replace", **NOWIN)

    def parse(out: str, history: bool) -> None:
        rx = r"^([0-9a-fA-F]{7,40}):(.*?):(\d+):(.*)$" if history else r"^(.*?):(\d+):(.*)$"
        for line in out.splitlines():
            m = re.match(rx, line)
            if not m:
                continue
            commit, fp, ln, txt = m.groups() if history else (None, *m.groups())
            fp = (fp[2:] if fp.startswith("./") else fp).replace("\\", "/")
            if "Possible mistakes" in txt or not txt.strip():
                continue
            entry = {"file": fp, "line": int(ln), "severity": "low" if _looks_like_example(txt) else "critical",
                     "rule": "git-secrets/history" if history else "git-secrets/registered",
                     "title": "Secreto en el historial de commits (git-secrets)" if history
                     else "Credencial detectada por git-secrets",
                     "secret_type": "Credencial histórica" if history else "Coincidencia de git-secrets",
                     "match": redact(txt.strip()), "engine": "git-secrets/history" if history else "git-secrets"}
            if commit:
                entry["commit"] = commit
            findings.append(entry)

    try:
        gs("--register-aws", "--global")
        for pat in _GIT_SECRETS_CUSTOM_PATTERNS:
            try:
                gs("--add", pat, timeout=30)
            except Exception:
                pass
        p = gs("--scan", "-r", ".", timeout=300)
        parse(f"{p.stderr or ''}\n{p.stdout or ''}", False)
        try:
            p = gs("--scan-history", timeout=240)
            parse(f"{p.stderr or ''}\n{p.stdout or ''}", True)
        except subprocess.TimeoutExpired:
            _log(log, "[secretos] git-secrets --scan-history excedió el tiempo en un repositorio grande — los "
                      "resultados del árbol de trabajo siguen completos.")
        except Exception as e:
            _log(log, f"[secretos] git-secrets --scan-history omitido: {e!r}")
    except Exception as e:
        _log(log, f"[secretos] ejecución de git-secrets omitida: {e!r}")
        return []
    if findings:
        hist = sum(1 for f in findings if f["engine"] == "git-secrets/history")
        _log(log, f"[secretos] git-secrets reportó {len(findings) - hist} coincidencia(s) en el árbol de trabajo"
                  + (f" y {hist} en el historial de commits" if hist else "") + ".")
    return findings


_p = re.compile

_PROVIDERS_CLOUD = [
    ("aws-access-key-id", "AWS Access Key ID", "critical",
     _p(r"(?<![A-Z0-9])(?:AKIA|ASIA|AGPA|AIDA|AROA|AIPA|ANPA|ANVA|ABIA|ACCA)[A-Z0-9]{16}(?![A-Z0-9])")),
    ("aws-secret-access-key", "AWS Secret Access Key", "critical",
     _p(r"(?i)aws.{0,24}?(?:secret|private).{0,24}?['\"`]([0-9a-zA-Z/+]{40})['\"`]")),
    ("aws-session-token", "AWS Session Token", "high",
     _p(r"(?i)aws.{0,24}?session.{0,24}?token.{0,4}?['\"`]([0-9a-zA-Z/+=]{100,})['\"`]")),
    ("aws-mws-key", "Amazon MWS Auth Token", "high",
     _p(r"amzn\.mws\.[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}")),
    ("gcp-api-key", "Google API key", "high",
     _p(r"\bAIza[0-9A-Za-z\-_]{35}\b")),
    ("gcp-oauth", "Google OAuth client id", "medium",
     _p(r"\b[0-9]+-[0-9A-Za-z_]{32}\.apps\.googleusercontent\.com\b")),
    ("gcp-service-account", "GCP service-account private key (JSON)", "critical",
     _p(r'"private_key"\s*:\s*"-----BEGIN PRIVATE KEY')),
    ("firebase-server-key", "Firebase Cloud Messaging server key", "high",
     _p(r"\bAAAA[A-Za-z0-9_-]{7}:[A-Za-z0-9_-]{140}\b")),
    ("azure-storage-key", "Azure Storage account key", "critical",
     _p(r"(?i)AccountKey=[A-Za-z0-9+/]{86}==")),
    ("azure-sas-token", "Azure SAS token", "high",
     _p(r"(?i)[?&]sig=[A-Za-z0-9%]{20,}.{0,40}se=\d")),
    ("azure-devops-pat", "Azure DevOps personal access token", "high",
     _p(r"(?i)azure.{0,20}(?:devops|pat).{0,20}['\"`]([a-z0-9]{52})['\"`]")),
    ("azure-client-secret", "Azure AD app client secret", "high",
     _p(r"(?i)(?:azure|aad|client).{0,15}secret.{0,4}['\"`]([a-zA-Z0-9_~.\-]{34,40})['\"`]")),
    ("digitalocean-pat", "DigitalOcean personal access token", "high",
     _p(r"\bdop_v1_[a-f0-9]{64}\b")),
    ("digitalocean-oauth", "DigitalOcean OAuth token", "high",
     _p(r"\bdoo_v1_[a-f0-9]{64}\b")),
    ("alibaba-access-key", "Alibaba Cloud AccessKey ID", "high",
     _p(r"\bLTAI[0-9A-Za-z]{12,20}\b")),
    ("oracle-ocid", "Oracle Cloud OCID (resource identifier)", "low",
     _p(r"\bocid1\.[a-z0-9]+\.oc[0-9]\.[a-z0-9-]*\.[a-z0-9]{20,}\b")),
    ("cloudflare-api-key", "Cloudflare Global API key", "high",
     _p(r"(?i)cloudflare.{0,20}api.{0,10}key.{0,4}['\"`]([a-f0-9]{37})['\"`]")),
    ("cloudflare-api-token", "Cloudflare API token", "high",
     _p(r"(?i)cloudflare.{0,20}token.{0,4}['\"`]([A-Za-z0-9_-]{40})['\"`]")),
    ("heroku-api-key", "Heroku API key", "medium",
     _p(r"(?i)heroku.{0,20}['\"`]([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})['\"`]")),
    ("linode-pat", "Linode personal access token", "high",
     _p(r"(?i)linode.{0,20}token.{0,4}['\"`]([a-f0-9]{64})['\"`]")),
    ("ibm-cloud-api-key", "IBM Cloud API key", "high",
     _p(r"(?i)ibm.{0,10}cloud.{0,10}api.{0,10}key.{0,4}['\"`]([A-Za-z0-9_-]{44})['\"`]")),
]

_PROVIDERS_KEYS = [
    ("private-key", "Bloque de llave privada", "critical",
     _p(r"-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP |ENCRYPTED )?PRIVATE KEY-----")),
    ("putty-private-key", "Llave privada de PuTTY (.ppk)", "critical",
     _p(r"PuTTY-User-Key-File-\d")),
    ("ansible-vault", "Contenido cifrado con Ansible Vault", "medium",
     _p(r"\$ANSIBLE_VAULT;\d\.\d;AES256")),
    ("age-secret-key", "Llave secreta de cifrado age", "critical",
     _p(r"\bAGE-SECRET-KEY-1[QPZRY9X8GF2TVDW0S3JN54KHCE6MUA7L]{58}\b")),
]

_PROVIDERS_AI = [
    ("anthropic-api-key", "Anthropic API key", "critical",
     _p(r"\bsk-ant-api03-[A-Za-z0-9_-]{93}AA\b")),
    ("anthropic-admin-key", "Anthropic Admin API key", "critical",
     _p(r"\bsk-ant-admin01-[A-Za-z0-9_-]{93}AA\b")),
    ("openai-api-key", "OpenAI API key", "critical",
     _p(r"\bsk-(?:proj-|svcacct-|admin-)?[A-Za-z0-9_-]{20,74}T3BlbkFJ[A-Za-z0-9_-]{20,74}\b")),
    ("azure-openai-key", "Azure OpenAI resource key", "critical",
     _p(r"(?i)azure.{0,15}openai.{0,20}key.{0,4}['\"`]([a-f0-9]{32})['\"`]")),
    ("google-ai-gemini-key", "Google AI (Gemini/PaLM) API key", "high",
     _p(r"(?i)(?:gemini|google.?ai|palm).{0,20}key.{0,4}['\"`](AIza[0-9A-Za-z\-_]{35})['\"`]")),
    ("cohere-api-key", "Cohere API key", "high",
     _p(r"(?i)(?:cohere|CO_API_KEY).{0,20}[\s'\"`]{0,3}[:=][\x60'\"\s=]{0,5}([A-Za-z0-9]{40})(?:[\x60'\"\s;]|$)")),
    ("huggingface-token", "Hugging Face access token", "high",
     _p(r"\bhf_[A-Za-z]{34}\b")),
    ("huggingface-org-token", "Hugging Face organization API token", "high",
     _p(r"\bapi_org_[A-Za-z]{34}\b")),
    ("perplexity-api-key", "Perplexity API key", "high",
     _p(r"\bpplx-[a-zA-Z0-9]{48}\b")),
    ("replicate-api-token", "Replicate API token", "high",
     _p(r"\br8_[A-Za-z0-9]{37}\b")),
    ("groq-api-key", "Groq API key", "high",
     _p(r"\bgsk_[A-Za-z0-9]{52}\b")),
    ("mistral-api-key", "Mistral AI API key", "high",
     _p(r"(?i)mistral.{0,20}key.{0,4}['\"`]([A-Za-z0-9]{32})['\"`]")),
    ("elevenlabs-api-key", "ElevenLabs API key", "medium",
     _p(r"(?i)elevenlabs.{0,20}key.{0,4}['\"`]([a-f0-9]{32})['\"`]")),
    ("pinecone-api-key", "Pinecone vector-DB API key", "high",
     _p(r"(?i)pinecone.{0,20}key.{0,4}['\"`]([a-f0-9-]{36})['\"`]")),
    ("langsmith-api-key", "LangSmith/LangChain API key", "medium",
     _p(r"\bls(?:v2|__)[A-Za-z0-9_-]{20,64}\b")),
]

_PROVIDERS_VCS_CI = [
    ("github-token", "GitHub token", "high",
     _p(r"\bgh[pousr]_[0-9A-Za-z]{36,255}\b")),
    ("github-fine-pat", "GitHub fine-grained personal access token", "high",
     _p(r"\bgithub_pat_[0-9A-Za-z_]{22,255}\b")),
    ("gitlab-pat", "GitLab personal access token", "high",
     _p(r"\bglpat-[0-9A-Za-z_-]{20}\b")),
    ("bitbucket-app-password", "Bitbucket app password", "high",
     _p(r"(?i)bitbucket.{0,20}(?:app.?password|token).{0,4}['\"`]([A-Za-z0-9]{20,32})['\"`]")),
    ("circleci-token", "CircleCI personal API token", "high",
     _p(r"(?i)circleci.{0,20}token.{0,4}['\"`]([a-f0-9]{40})['\"`]")),
    ("travis-token", "Travis CI token", "medium",
     _p(r"(?i)travis.{0,20}token.{0,4}['\"`]([A-Za-z0-9]{22})['\"`]")),
    ("npm-token", "npm access token", "high",
     _p(r"\bnpm_[A-Za-z0-9]{36}\b")),
    ("npmrc-legacy-token", ".npmrc legacy auth token", "high",
     _p(r"//registry\.npmjs\.org/:_authToken=([A-Za-z0-9_-]{20,})")),
    ("pypi-token", "PyPI upload token", "high",
     _p(r"\bpypi-AgEIcHlwaS5vcmc[A-Za-z0-9_-]{40,}\b")),
    ("nuget-api-key", "NuGet API key", "medium",
     _p(r"(?i)nuget.{0,20}api.?key.{0,4}['\"`]([a-z0-9]{46})['\"`]")),
    ("docker-hub-pat", "Docker Hub personal access token", "high",
     _p(r"\bdckr_pat_[A-Za-z0-9_-]{27}\b")),
    ("docker-config-auth", "Docker config.json base64 auth", "medium",
     _p(r'"auth"\s*:\s*"[A-Za-z0-9+/]{20,}={0,2}"')),
    ("terraform-cloud-token", "Terraform Cloud API token", "high",
     _p(r"\b[A-Za-z0-9]{14}\.atlasv1\.[A-Za-z0-9_-]{60,}\b")),
    ("jfrog-artifactory-token", "JFrog/Artifactory API key or token", "high",
     _p(r"(?i)artifactory.{0,20}(?:api.?key|token).{0,4}['\"`]([A-Za-z0-9]{20,})['\"`]")),
    ("jfrog-artifactory-akcp", "JFrog/Artifactory reference token (AKCp)", "high",
     _p(r"\bAKCp[A-Za-z0-9]{69}\b")),
    ("sonar-token", "SonarQube/SonarCloud token", "medium",
     _p(r"\b(?:squ?_|sqp_|sqa_)[a-z0-9]{40}\b")),
    ("snyk-api-token", "Snyk API/OAuth token", "high",
     _p(r"(?i)snyk[_.-]?(?:api|oauth)?[_.-]?(?:key|token).{0,20}['\"`]([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})['\"`]")),
    ("gitlab-deploy-token", "GitLab deploy token", "high",
     _p(r"\bgldt-[0-9a-zA-Z_-]{20}\b")),
    ("gitlab-runner-token", "GitLab Runner authentication token", "high",
     _p(r"\bglrt-[0-9a-zA-Z_-]{20}\b")),
    ("gitlab-cicd-job-token", "GitLab CI/CD job token", "medium",
     _p(r"\bglcbt-[0-9a-zA-Z]{1,5}_[0-9a-zA-Z_-]{20}\b")),
    ("gitlab-pat-routable", "GitLab personal access token (routable format)", "high",
     _p(r"\bglpat-[0-9a-zA-Z_-]{27,300}\.[0-9a-z]{9}\b")),
    ("bitbucket-client-secret", "Bitbucket OAuth client secret", "high",
     _p(r"(?i)bitbucket.{0,20}client.?secret.{0,4}['\"`]([A-Za-z0-9]{32,64})['\"`]")),
    ("codecov-token", "Codecov upload token", "medium",
     _p(r"(?i)codecov.{0,20}token.{0,4}['\"`]([a-z0-9-]{32,36})['\"`]")),
    ("clojars-token", "Clojars deploy token", "medium",
     _p(r"(?i)CLOJARS_[a-z0-9]{60}")),
    ("droneci-token", "Drone CI access token", "medium",
     _p(r"(?i)drone.{0,15}token.{0,4}['\"`]([a-z0-9]{32})['\"`]")),
    ("doppler-token", "Doppler secrets-manager service token", "critical",
     _p(r"\bdp\.pt\.[a-zA-Z0-9]{43}\b")),
    ("hashicorp-vault-token", "HashiCorp Vault service/batch token", "critical",
     _p(r"\bhv[bs]\.[A-Za-z0-9_-]{90,300}\b")),
    ("pulumi-token", "Pulumi access token", "high",
     _p(r"\bpul-[a-f0-9]{40}\b")),
    ("prefect-token", "Prefect API token", "high",
     _p(r"\bpnu_[a-zA-Z0-9]{36}\b")),
    ("octopus-deploy-key", "Octopus Deploy API key", "high",
     _p(r"\bAPI-[A-Z0-9]{26}\b")),
    ("harness-api-key", "Harness API key", "high",
     _p(r"\b(?:pat|sat)\.[a-zA-Z0-9_-]{22}\.[a-zA-Z0-9]{24}\.[a-zA-Z0-9]{20}\b")),
    ("infracost-token", "Infracost API token", "low",
     _p(r"\bico-[a-zA-Z0-9]{32}\b")),
    ("sourcegraph-token", "Sourcegraph access token", "medium",
     _p(r"\bsgp_(?:[a-fA-F0-9]{16}|local)_[a-fA-F0-9]{40}\b")),
    ("rubygems-token", "RubyGems API token", "high",
     _p(r"\brubygems_[a-f0-9]{48}\b")),
    ("postman-token", "Postman API token", "medium",
     _p(r"\bPMAK-[a-f0-9]{24}-[a-f0-9]{34}\b")),
    ("readme-token", "ReadMe.io API token", "low",
     _p(r"\brdme_[a-z0-9]{70}\b")),
    ("databricks-token", "Databricks personal access token", "high",
     _p(r"\bdapi[a-f0-9]{32}(?:-\d)?\b")),
    ("planetscale-token", "PlanetScale database token", "critical",
     _p(r"\bpscale_tkn_[\w=.-]{32,64}\b")),
    ("planetscale-oauth", "PlanetScale OAuth token", "critical",
     _p(r"\bpscale_oauth_[\w=.-]{32,64}\b")),
    ("notion-token", "Notion integration token", "medium",
     _p(r"\bntn_[0-9]{11}[A-Za-z0-9]{30,40}\b")),
    ("linear-api-key", "Linear API key", "medium",
     _p(r"\blin_api_[a-zA-Z0-9]{40}\b")),
    ("asana-secret", "Asana client secret", "high",
     _p(r"(?i)asana.{0,20}(?:client.?)?secret.{0,4}['\"`]([a-z0-9]{32})['\"`]")),
    ("atlassian-api-token", "Atlassian (Jira/Confluence) API token", "high",
     _p(r"\bATATT3[A-Za-z0-9_-]{100,200}\b")),
    ("airtable-token", "Airtable API key / PAT", "high",
     _p(r"\bpat[A-Za-z0-9]{14}\.[a-f0-9]{64}\b")),
    ("launchdarkly-token", "LaunchDarkly access token", "high",
     _p(r"(?i)launchdarkly.{0,20}token.{0,4}['\"`]([a-z0-9=_-]{40})['\"`]")),
]

_PROVIDERS_PAYMENTS = [
    ("stripe-secret-live", "Stripe live secret/restricted key", "critical",
     _p(r"\b(?:sk|rk)_live_[0-9a-zA-Z]{20,}\b")),
    ("stripe-secret-test", "Stripe test secret key", "low",
     _p(r"\b(?:sk|rk)_test_[0-9a-zA-Z]{20,}\b")),
    ("stripe-webhook-secret", "Stripe webhook signing secret", "high",
     _p(r"\bwhsec_[A-Za-z0-9]{32,}\b")),
    ("paypal-braintree-token", "PayPal/Braintree access token", "high",
     _p(r"\baccess_token\$production\$[a-z0-9]{16}\$[a-f0-9]{32}\b")),
    ("square-token", "Square access token", "high",
     _p(r"\bsq0(?:atp|csp)-[0-9A-Za-z_-]{22,43}\b")),
    ("razorpay-key", "Razorpay live key", "high",
     _p(r"\brzp_live_[A-Za-z0-9]{14,}\b")),
    ("plaid-secret", "Plaid secret", "high",
     _p(r"(?i)plaid.{0,20}secret.{0,4}['\"`]([a-f0-9]{30})['\"`]")),
    ("stripe-secret-prod", "Stripe production secret/restricted key", "critical",
     _p(r"\b(?:sk|rk)_prod_[0-9a-zA-Z]{10,99}\b")),
    ("square-access-token-v2", "Square access token (current format)", "high",
     _p(r"\b(?:EAAA[\w-]{22,60}|sq0atp-[\w-]{22,43})\b")),
    ("flutterwave-key", "Flutterwave public/secret key", "critical",
     _p(r"\bFLW(?:PUBK|SECK)(?:_TEST)?-[A-Za-z0-9]{32}-?X?\b")),
    ("gocardless-token", "GoCardless live API token", "critical",
     _p(r"(?i)gocardless.{0,20}token.{0,4}['\"`](live_[A-Za-z0-9_-]{40})['\"`]")),
    ("kraken-api-key", "Kraken exchange API key", "critical",
     _p(r"(?i)kraken.{0,20}(?:key|secret).{0,4}['\"`]([A-Za-z0-9/=+_-]{80,90})['\"`]")),
    ("kucoin-key", "KuCoin exchange API key/secret", "critical",
     _p(r"(?i)kucoin.{0,20}(?:key|secret).{0,4}['\"`]([a-f0-9]{24}|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})['\"`]")),
    ("bittrex-key", "Bittrex exchange access/secret key", "critical",
     _p(r"(?i)bittrex.{0,20}(?:key|secret).{0,4}['\"`]([a-z0-9]{32})['\"`]")),
    ("coinbase-token", "Coinbase access token", "critical",
     _p(r"(?i)coinbase.{0,20}token.{0,4}['\"`]([a-z0-9_-]{64})['\"`]")),
    ("lob-api-key", "Lob API key", "medium",
     _p(r"(?i)lob.{0,15}key.{0,4}['\"`]((?:live|test)_[a-f0-9]{35})['\"`]")),
    ("shippo-token", "Shippo API token", "medium",
     _p(r"\bshippo_(?:live|test)_[a-fA-F0-9]{40}\b")),
]

_PROVIDERS_MESSAGING = [

    ("slack-token", "Slack token", "high",
     _p(r"\bxox[baoprs]-[0-9A-Za-z-]{10,48}\b")),
    ("slack-webhook", "Slack webhook URL", "medium",
     _p(r"https://hooks\.slack\.com/(?:services|workflows|triggers)/[A-Za-z0-9/_-]{30,}")),
    ("discord-bot-token", "Discord bot token", "high",
     _p(r"\b[MN][A-Za-z\d]{23}\.[\w-]{6}\.[\w-]{27}\b")),
    ("discord-webhook", "Discord webhook URL", "medium",
     _p(r"https://discord(?:app)?\.com/api/webhooks/\d{17,20}/[A-Za-z0-9_-]{60,}")),
    ("telegram-bot-token", "Telegram bot token", "high",
     _p(r"\b\d{8,10}:[A-Za-z0-9_-]{35}\b")),
    ("twilio-sid", "Twilio account/API SID", "high",
     _p(r"\b(?:AC|SK)[0-9a-fA-F]{32}\b")),
    ("twilio-auth-token", "Twilio Auth Token", "high",
     _p(r"(?i)twilio.{0,20}(?:auth.?token).{0,4}['\"`]([0-9a-f]{32})['\"`]")),
    ("sendgrid-key", "SendGrid API key", "high",
     _p(r"\bSG\.[0-9A-Za-z\-_]{22}\.[0-9A-Za-z\-_]{43}\b")),
    ("mailgun-key", "Mailgun API key", "high",
     _p(r"\bkey-[0-9a-f]{32}\b")),
    ("mailchimp-key", "Mailchimp API key", "high",
     _p(r"\b[0-9a-f]{32}-us\d{1,2}\b")),
    ("twitter-bearer", "Twitter/X bearer token", "high",
     _p(r"\bAAAAAAAAAAAAAAAAAAAAA[A-Za-z0-9%]{35,}\b")),
    ("twitter-secret", "Twitter/X API secret", "medium",
     _p(r"(?i)twitter.{0,20}secret.{0,4}['\"`]([A-Za-z0-9]{45})['\"`]")),
    ("facebook-access-token", "Facebook/Meta access token", "high",
     _p(r"\bEAA[A-Za-z0-9]{60,}\b")),
    ("discord-client-secret", "Discord OAuth client secret", "high",
     _p(r"(?i)discord.{0,20}(?:client.?)?secret.{0,4}['\"`]([a-zA-Z0-9_-]{32})['\"`]")),
    ("shopify-token", "Shopify access/private-app/custom-app token", "critical",
     _p(r"\bsh(?:pat|pca|ppa)_[a-fA-F0-9]{32}\b")),
    ("zendesk-token", "Zendesk API secret key", "high",
     _p(r"(?i)zendesk.{0,20}(?:key|token).{0,4}['\"`]([a-z0-9]{40})['\"`]")),
    ("linkedin-client-secret", "LinkedIn OAuth client secret", "high",
     _p(r"(?i)linked[_-]?in.{0,20}secret.{0,4}['\"`]([a-zA-Z0-9]{16})['\"`]")),
    ("twitch-token", "Twitch API token", "medium",
     _p(r"(?i)twitch.{0,20}token.{0,4}['\"`]([a-z0-9]{30})['\"`]")),
    ("sendinblue-brevo-key", "Sendinblue/Brevo API key", "high",
     _p(r"\bxkeysib-[a-f0-9]{64}-[a-zA-Z0-9]{16}\b")),
    ("squarespace-token", "Squarespace access token", "high",
     _p(r"(?i)squarespace.{0,20}token.{0,4}['\"`]([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})['\"`]")),
    ("etsy-token", "Etsy access token", "medium",
     _p(r"(?i)etsy.{0,20}token.{0,4}['\"`]([a-z0-9]{24})['\"`]")),
    ("messagebird-token", "MessageBird API token", "medium",
     _p(r"(?i)message[_-]?bird.{0,20}['\"`]([a-z0-9]{25})['\"`]")),
    ("intercom-token", "Intercom API key", "high",
     _p(r"(?i)intercom.{0,20}key.{0,4}['\"`]([a-z0-9=_-]{60})['\"`]")),
    ("typeform-token", "Typeform personal access token", "medium",
     _p(r"\btfp_[a-zA-Z0-9_.=-]{40,59}\b")),
    ("microsoft-teams-webhook", "Microsoft Teams incoming webhook URL", "medium",
     _p(r"https://[a-z0-9.-]+\.webhook\.office\.com/webhookb2/[A-Za-z0-9@/-]{20,}")),
]

_PROVIDERS_AUTH = [
    ("jwt", "JSON Web Token", "medium",
     _p(r"\beyJ[A-Za-z0-9_-]{8,}\.eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b")),
    ("auth0-client-secret", "Auth0 client secret", "high",
     _p(r"(?i)auth0.{0,20}(?:client.?)?secret.{0,4}['\"`]([A-Za-z0-9_-]{48,64})['\"`]")),
    ("okta-api-token", "Okta API token", "high",
     _p(r"(?i)okta.{0,20}token.{0,4}['\"`]([A-Za-z0-9_-]{40})['\"`]")),
    ("basic-auth-url", "Credenciales embebidas en URL", "high",
     _p(r"\b[a-zA-Z][a-zA-Z0-9+.\-]*://[^/\s:@]{1,64}:([^/\s:@]{3,64})@")),
    ("bearer-header", "Encabezado Bearer/Authorization embebido", "medium",
     _p(r"(?i)authorization['\"`]?\s*[:=]\s*['\"`]?bearer\s+([A-Za-z0-9._-]{20,})")),
    ("1password-service-token", "1Password service account token (secrets manager)", "critical",
     _p(r"\bops_eyJ[A-Za-z0-9+/]{100,}={0,3}\b")),
    ("openshift-user-token", "OpenShift/Kubernetes bearer user token", "high",
     _p(r"\bsha256~[\w-]{43}\b")),
    ("adobe-client-secret", "Adobe client secret", "high",
     _p(r"\bp8e-[a-zA-Z0-9]{32}\b")),
]

_PROVIDERS_OBSERVABILITY = [
    ("datadog-api-key", "Datadog API key", "medium",
     _p(r"(?i)datadog.{0,20}api.?key.{0,4}['\"`]([a-f0-9]{32})['\"`]")),
    ("datadog-app-key", "Datadog application key", "medium",
     _p(r"(?i)datadog.{0,20}app.?key.{0,4}['\"`]([a-f0-9]{40})['\"`]")),
    ("newrelic-license-key", "New Relic license key", "medium",
     _p(r"\b[A-Za-z0-9]{40}NRAL\b")),
    ("newrelic-insert-key", "New Relic insert key (write telemetry)", "medium",
     _p(r"\bNRII-[a-z0-9-]{32}\b")),
    ("newrelic-user-api-key", "New Relic user API key (full account access)", "high",
     _p(r"\bNRAK-[A-Z0-9]{27}\b")),
    ("newrelic-browser-token", "New Relic browser API token", "low",
     _p(r"\bNRJS-[a-f0-9]{19}\b")),
    ("pagerduty-api-key", "PagerDuty API key", "medium",
     _p(r"(?i)pagerduty.{0,20}(?:api.?key|token).{0,4}['\"`]([A-Za-z0-9+_-]{20})['\"`]")),
    ("sentry-auth-token", "Sentry auth token", "medium",
     _p(r"\bsntrys_[A-Za-z0-9_]{40,}\b")),
    ("sentry-user-token", "Sentry user auth token", "high",
     _p(r"\bsntryu_[a-f0-9]{64}\b")),
    ("algolia-admin-key", "Algolia Admin API key", "high",
     _p(r"(?i)algolia.{0,20}admin.{0,10}key.{0,4}['\"`]([a-f0-9]{32})['\"`]")),
    ("segment-write-key", "Segment write key", "medium",
     _p(r"(?i)segment.{0,20}write.?key.{0,4}['\"`]([A-Za-z0-9]{32})['\"`]")),
    ("grafana-api-key", "Grafana API key", "high",
     _p(r"(?i)\beyJrIjoi[A-Za-z0-9]{70,400}={0,3}\b")),
    ("grafana-cloud-token", "Grafana Cloud API token", "high",
     _p(r"\bglc_[A-Za-z0-9+/]{32,400}={0,3}\b")),
    ("grafana-service-account", "Grafana service-account token", "high",
     _p(r"\bglsa_[A-Za-z0-9]{32}_[A-Fa-f0-9]{8}\b")),
    ("dynatrace-token", "Dynatrace API token", "high",
     _p(r"\bdt0c01\.[a-zA-Z0-9]{24}\.[a-zA-Z0-9]{64}\b")),
    ("sumologic-token", "Sumo Logic access token", "medium",
     _p(r"(?i)sumo(?:logic)?.{0,20}token.{0,4}['\"`]([a-z0-9]{64})['\"`]")),
    ("confluent-key", "Confluent (Kafka) API key/secret", "high",
     _p(r"(?i)confluent.{0,20}(?:key|secret).{0,4}['\"`]([a-z0-9]{16}|[a-z0-9]{64})['\"`]")),
    ("clickhouse-cloud-key", "ClickHouse Cloud API secret key", "critical",
     _p(r"\b4b1d[A-Za-z0-9]{38}\b")),
    ("honeycomb-api-key", "Honeycomb API key", "medium",
     _p(r"(?i)honeycomb.{0,20}key.{0,4}['\"`]([a-zA-Z0-9]{22,32})['\"`]")),
    ("rollbar-token", "Rollbar access token", "medium",
     _p(r"(?i)rollbar.{0,20}(?:token|key).{0,4}['\"`]([a-f0-9]{32})['\"`]")),
    ("bugsnag-key", "Bugsnag API/project key", "medium",
     _p(r"(?i)bugsnag.{0,20}key.{0,4}['\"`]([a-f0-9]{32})['\"`]")),
]

_PROVIDERS_DEVTOOLS = [
    ("maxmind-license-key", "MaxMind GeoIP license key", "low",
     _p(r"\b[A-Za-z0-9]{6}_[A-Za-z0-9]{29}_mmk\b")),
    ("rapidapi-token", "RapidAPI access token", "medium",
     _p(r"(?i)rapidapi.{0,20}['\"`]([a-z0-9_-]{50})['\"`]")),
    ("mapbox-secret-token", "Mapbox secret token (sk.)", "high",
     _p(r"\bsk\.eyJ[A-Za-z0-9_-]{40,}\.[A-Za-z0-9_-]{20,}\b")),
    ("contentful-token", "Contentful delivery/management API token", "medium",
     _p(r"(?i)contentful.{0,20}['\"`]([a-z0-9=_-]{43})['\"`]")),
    ("cisco-meraki-key", "Cisco Meraki dashboard API key", "high",
     _p(r"(?i)meraki.{0,20}['\"`]([0-9a-f]{40})['\"`]")),
    ("looker-client-secret", "Looker client secret", "high",
     _p(r"(?i)looker.{0,20}secret.{0,4}['\"`]([a-z0-9]{24})['\"`]")),
    ("mattermost-token", "Mattermost access token", "medium",
     _p(r"(?i)mattermost.{0,20}token.{0,4}['\"`]([a-z0-9]{26})['\"`]")),
    ("gitter-token", "Gitter access token", "low",
     _p(r"(?i)gitter.{0,20}token.{0,4}['\"`]([a-z0-9_-]{40})['\"`]")),
    ("frameio-token", "Frame.io API token", "medium",
     _p(r"\bfio-u-[a-zA-Z0-9_=-]{64}\b")),
    ("freshbooks-token", "FreshBooks access token", "medium",
     _p(r"(?i)freshbooks.{0,20}token.{0,4}['\"`]([a-z0-9]{64})['\"`]")),
    ("finicity-token", "Finicity (financial data) API token/secret", "high",
     _p(r"(?i)finicity.{0,20}(?:token|secret).{0,4}['\"`]([a-f0-9]{32})['\"`]")),
    ("finnhub-token", "Finnhub market-data API token", "low",
     _p(r"(?i)finnhub.{0,20}['\"`]([a-z0-9]{20})['\"`]")),
    ("flickr-token", "Flickr access token", "low",
     _p(r"(?i)flickr.{0,20}['\"`]([a-z0-9]{32})['\"`]")),
    ("nytimes-token", "New York Times API key", "low",
     _p(r"(?i)nytimes.{0,20}['\"`]([a-z0-9=_-]{32})['\"`]")),
    ("beamer-token", "Beamer API token", "low",
     _p(r"\bb_[a-zA-Z0-9=_-]{44}\b")),
]

_PROVIDERS_SHELL = [
    ("curl-auth-header", "Credencial en curl -H/--header Authorization/API-Key", "high",
     _p(r"(?i)curl\b.*(?:-H|--header)\s+['\"](?:Authorization:\s*(?:Bearer|Token)\s+([A-Za-z0-9._~+/=-]{8,})|(?:[A-Za-z-]*Api-?Key):\s*([A-Za-z0-9._~+/=-]{8,}))")),
    ("curl-auth-user", "Credencial en curl -u/--user", "high",
     _p(r"(?i)curl\b.*(?:-u|--user)\s+['\"]?([^:'\"\s]{2,}:[^'\"\s]{3,})")),
    ("wget-auth", "Credencial en wget --http-password/--ftp-password", "high",
     _p(r"(?i)wget\b.*--(?:http|ftp)-password[= ]([^\s'\"]{3,})")),
]

_CRED_KEYWORD = (r"(?:api[_-]?key|apikey|access[_-]?key|private[_-]?key|"
                 r"client[_-]?secret|auth[_-]?token|secret(?:[_-]?key)?|"
                 r"token|passwd|password|pwd|credential)")
_CRED_IDENTIFIER = rf"[A-Za-z0-9_]{{0,40}}{_CRED_KEYWORD}[A-Za-z0-9_]{{0,40}}"

_PROVIDERS_GENERIC = [
    ("generic-secret", "Secreto genérico embebido en código", "medium",
     _p(rf"(?i){_CRED_IDENTIFIER}\s*[:=]\s*['\"`]([^'\"`\s]{{12,128}})['\"`]")),

    ("connstring-password", "Contraseña en cadena de conexión", "high",
     _p(r"(?i)\b(?:password|pwd)\s*=\s*([^;'\"\s][^;'\"<]{2,128})(?:;|['\"]|\s*/?>)")),
    ("connstring-user", "Usuario en cadena de conexión", "low",
     _p(r"(?i)\b(?:user\s*id|uid)\s*=\s*([^;'\"\s][^;'\"<]{1,64})(?:;|['\"]|\s*/?>)")),

    ("config-password", "Contraseña en archivo de configuración", "high",
     _p(r"(?i)(?:password|passwd|pwd)\s*[:=]\s*[\"']([^\"'<>\s]{4,128})[\"']")),

    ("db-url-credential", "URL de base de datos con credenciales embebidas", "high",
     _p(r"(?i)\b(?:jdbc:)?(?:postgres(?:ql)?|mysql|mongodb(?:\+srv)?|redis|mssql|oracle):(?://)?[^/\s:@]{0,64}:([^/\s:@]{3,64})@")),

    ("dotenv-unquoted-secret", "Secreto sin comillas en .env/.properties/.yml", "medium",
     _p(r"(?im)^\s*(?:export\s+)?[A-Za-z_][A-Za-z0-9_]*(?:API[_-]?KEY|SECRET|TOKEN|PASSWORD|PASSWD|PWD|PRIVATE[_-]?KEY|ACCESS[_-]?KEY)\w*\s*[:=]\s*(?!['\"]?\$\{)([^\s'\"][^\s#]{7,127})\s*$")),
    ("django-secret-key", "Django SECRET_KEY", "critical",
     _p(r"SECRET_KEY\s*=\s*['\"]([^'\"]{20,})['\"]")),
    ("flask-secret-key", "Flask SECRET_KEY", "high",
     _p(r"(?i)app\.config\[['\"]SECRET_KEY['\"]\]\s*=\s*['\"]([^'\"]{8,})['\"]")),
    ("rails-secret-key-base", "Rails secret_key_base", "critical",
     _p(r"secret_key_base\s*:\s*([0-9a-f]{64,})")),
    ("laravel-app-key", "Laravel APP_KEY", "critical",
     _p(r"APP_KEY\s*=\s*base64:([A-Za-z0-9+/=]{32,})")),
    ("spring-datasource-password", "Spring Boot datasource password", "high",
     _p(r"spring\.datasource\.password\s*=\s*(\S+)")),
    ("wordpress-auth-key", "WordPress AUTH_KEY/salts", "medium",
     _p(r"define\(\s*['\"](?:AUTH|SECURE_AUTH|LOGGED_IN|NONCE)_KEY['\"]\s*,\s*['\"]([^'\"]{16,})['\"]")),
    ("maven-server-password", "Maven settings.xml server password", "high",
     _p(r"<password>([^<>\s]{4,128})</password>")),
    ("generic-high-entropy-hex", "Cadena hexadecimal larga asignada a un nombre de credencial", "medium",
     _p(rf"(?i){_CRED_IDENTIFIER}\s*[:=]\s*['\"`]?([0-9a-f]{{32,64}})['\"`]?\b")),
]

_PROVIDERS = (
    _PROVIDERS_CLOUD + _PROVIDERS_KEYS + _PROVIDERS_AI + _PROVIDERS_VCS_CI
    + _PROVIDERS_PAYMENTS + _PROVIDERS_MESSAGING + _PROVIDERS_AUTH
    + _PROVIDERS_OBSERVABILITY + _PROVIDERS_DEVTOOLS + _PROVIDERS_SHELL
    + _PROVIDERS_GENERIC
)

_GENERIC_CATCHALL_RULES = {
    "generic-secret", "generic-high-entropy-hex", "bearer-header",
    "basic-auth-url", "config-password",
}

_SENSITIVE_FILENAME_PATTERNS = [
    ("private-key-file", "Archivo de llave privada / certificado con clave", "high",
     _p(r"\.(pem|key|ppk|pfx|p12|jks|keystore|asc|gpg)$", re.I)),
    ("ssh-keypair-file", "Llave SSH privada sin cifrar (por nombre de archivo)", "high",
     _p(r"(?:^|[\\/])id_(rsa|dsa|ecdsa|ed25519)$", re.I)),
    ("env-file-committed", "Archivo .env versionado en el repositorio", "medium",
     _p(r"(?:^|[\\/])\.env(?:\.[a-zA-Z0-9_-]+)?$", re.I)),
    ("aws-credentials-file", "Archivo de credenciales de AWS CLI", "high",
     _p(r"(?:^|[\\/])\.aws[\\/]credentials$", re.I)),
    ("kube-config-file", "kubeconfig — puede traer tokens/certs embebidos", "medium",
     _p(r"(?:^|[\\/])(?:\.kube[\\/]config|kubeconfig(?:\.ya?ml)?)$", re.I)),
    ("netrc-file", "Archivo .netrc con credenciales de texto plano", "medium",
     _p(r"(?:^|[\\/])\.netrc$", re.I)),
    ("npmrc-file", "Archivo .npmrc — revisar _authToken", "low",
     _p(r"(?:^|[\\/])\.npmrc$", re.I)),
    ("pypirc-file", "Archivo .pypirc con credenciales de PyPI", "medium",
     _p(r"(?:^|[\\/])\.pypirc$", re.I)),
    ("terraform-state", "Terraform state — puede contener secretos en claro", "medium",
     _p(r"\.tfstate(?:\.backup)?$", re.I)),
    ("docker-config-file", "Docker config.json con auth embebido", "medium",
     _p(r"(?:^|[\\/])\.docker[\\/]config\.json$", re.I)),
    ("git-credentials-file", "Archivo .git-credentials con credenciales en texto plano", "high",
     _p(r"(?:^|[\\/])\.git-credentials$", re.I)),
    ("rails-master-key", "Rails master.key — descifra credentials.yml.enc", "critical",
     _p(r"(?:^|[\\/])config[\\/]master\.key$", re.I)),
    ("rails-encrypted-credentials", "Rails credentials.yml.enc versionado", "medium",
     _p(r"credentials\.yml\.enc$", re.I)),
    ("pgpass-file", "Archivo .pgpass con credenciales de PostgreSQL", "high",
     _p(r"(?:^|[\\/])\.pgpass$", re.I)),
    ("mysql-cnf-file", "Archivo .my.cnf — puede traer password= en claro", "medium",
     _p(r"(?:^|[\\/])\.my\.cnf$", re.I)),
    ("htpasswd-file", "Archivo .htpasswd con hashes de contraseñas", "medium",
     _p(r"(?:^|[\\/])\.htpasswd$", re.I)),
    ("unix-shadow-file", "Archivo shadow de contraseñas de sistema", "critical",
     _p(r"(?:^|[\\/])shadow$", re.I)),
    ("gcp-service-account-json", "Posible JSON de service account de GCP (por nombre)", "high",
     _p(r"(?:service[_-]?account|application[_-]?default[_-]?credentials).*\.json$", re.I)),
]

_EXAMPLE_MARKERS = (
    "EXAMPLE", "your-api-key", "your_api_key", "changeme", "change-me",
    "placeholder", "dummy", "redacted", "xxxxxxxx", "test-key", "testkey",
    "notreal", "fakekey", "sample", "0000000000", "1111111111",
)

_SKIP_DIRS = {
    ".git", ".hg", ".svn", "node_modules", "bower_components", "vendor",
    "venv", ".venv", "env", ".env.d", "__pycache__", ".mypy_cache",
    ".pytest_cache", "dist", "build", ".idea", ".vscode", ".gradle",
    "site-packages", "target", ".next", ".nuxt", "coverage", ".tox",
    "Reports", "reports", "_secrets_out", ".snyk-venv", ".snyk-wheels",
    ".cache", ".terraform", ".serverless", ".parcel-cache", ".turbo",
}
_SKIP_EXT = {
    ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico", ".webp", ".svg",
    ".pdf", ".zip", ".gz", ".tar", ".tgz", ".bz2", ".7z", ".rar",
    ".mp3", ".mp4", ".avi", ".mov", ".mkv", ".wav", ".ogg", ".flac",
    ".woff", ".woff2", ".ttf", ".otf", ".eot",
    ".class", ".jar", ".war", ".so", ".dll", ".dylib", ".exe", ".bin",
    ".pyc", ".pyo", ".o", ".a", ".lib", ".obj", ".wasm", ".lock",
}
_MAX_BYTES = 1_500_000
_SNIFF = 4096
_EXAMPLE_UP = tuple(m.upper() for m in _EXAMPLE_MARKERS)
_SUPPRESS_RE = _p(r"(?:nosecret|secrets?[:=]\s*ignore|pragma:\s*allowlist\s*secret|gitleaks:allow)", re.I)
_ENTROPY_ASSIGN_RE = _p(rf"""(?i){_CRED_IDENTIFIER}\s*[:=]\s*['"`]?([A-Za-z0-9+/_.=-]{{20,120}})['"`]?""")
_LOW_VALUE_TOKEN = _p(r"^(.)\1{6,}$|^(?:0123456789|abcdefgh|password|changeme)$", re.I)
_BOMS = ((b"\xef\xbb\xbf", "utf-8-sig"), (b"\xff\xfe\x00\x00", "utf-32-le"), (b"\x00\x00\xfe\xff", "utf-32-be"),
         (b"\xff\xfe", "utf-16-le"), (b"\xfe\xff", "utf-16-be"))
_K8S_KIND_RE = _p(r"(?im)^\s*kind:\s*[\"']?Secret[\"']?\s*$")
_K8S_DATA_RE = _p(r"(?im)^\s*(?:data|stringData)\s*:\s*$")
_K8S_KEY_RE = _p(r"(?im)^\s{2,}([\w.-]+):\s*(\S.*)$")
BASELINE_FILENAME = ".secrets-baseline.json"
SEV_ES = {"critical": "crítica", "high": "alta", "medium": "media", "low": "baja"}


def redact(secret: str, keep_head: int = 4, keep_tail: int = 2) -> str:
    s = secret.strip()
    # Valores cortos (contraseñas) revelan muy poco; los tokens largos conservan su prefijo (AKIA…, ghp_…) para
    # poder identificarlos.
    if len(s) < 12:
        keep_head, keep_tail = min(keep_head, 1), 0
    elif len(s) < 20:
        keep_head, keep_tail = min(keep_head, 2), min(keep_tail, 1)
    if len(s) <= keep_head + keep_tail:
        return "•" * max(4, len(s))
    return f"{s[:keep_head]}{'•' * max(4, len(s) - keep_head - keep_tail)}{s[len(s) - keep_tail:] if keep_tail else ''}"


def _redact_v1(secret: str) -> str:
    """Ocultamiento de versiones anteriores: solo para reconocer huellas de líneas base ya guardadas."""
    s = secret.strip()
    if len(s) <= 6:
        return "•" * len(s)
    return f"{s[:4]}{'•' * max(4, len(s) - 6)}{s[-2:]}"


def _looks_like_example(text: str) -> bool:
    up = text.upper()
    return any(m in up for m in _EXAMPLE_UP)


def redact_line(line: str, secret: str, others=()) -> str:
    """Fragmento de la línea con el secreto oculto. «others»: los demás valores detectados en la MISMA línea, que
    también se ocultan (p. ej. usuario y contraseña de una cadena de conexión)."""
    snip, sec = line.strip(), secret.strip()
    if len(snip) > 160:
        i = snip.find(sec) if sec else -1
        if i >= 0:
            start = max(0, i - 40)
            snip = ("…" if start else "") + snip[start:i + len(sec) + 40] + "…"
        else:
            snip = snip[:160] + "…"
    for v in sorted({x.strip() for x in (sec, *others) if x and x.strip()}, key=len, reverse=True):
        snip = snip.replace(v, redact(v))
    return snip


def _looks_high_entropy(tok: str) -> bool:
    if not 20 <= len(tok) <= 120 or _LOW_VALUE_TOKEN.match(tok) or re.search(r"\s", tok) \
            or tok.count("/") > 3 or tok.count(".") > 4:
        return False
    n = len(tok)
    return -sum(c / n * math.log2(c / n) for c in Counter(tok).values()) >= 3.4


def _read_text(path: Path) -> Optional[str]:
    try:
        with open(path, "rb") as fh:
            head = fh.read(_SNIFF)
        enc = next((e for bom, e in _BOMS if head.startswith(bom)), None)
        if enc is None:
            if b"\x00" not in head:
                enc = "utf-8"
            else:
                even, odd, half = head[0::2].count(0), head[1::2].count(0), max(1, len(head) // 2)
                if odd > half * 0.30 and odd >= even:
                    enc = "utf-16-le"
                elif even > half * 0.30 and even > odd:
                    enc = "utf-16-be"
                else:
                    return None
        return path.read_text(encoding=enc, errors="ignore")
    except Exception:
        return None


def _iter_files(root: Path):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in _SKIP_DIRS]
        for name in filenames:
            yield Path(dirpath) / name


def _scan_k8s(rel: str, text: str) -> list[dict]:
    m = _K8S_DATA_RE.search(text)
    if not m or not _K8S_KIND_RE.search(text):
        return []
    tail = text[m.end():]
    if end := re.search(r"(?m)^\S", tail):
        tail = tail[:end.start()]
    keys = [k.group(1) for k in _K8S_KEY_RE.finditer(tail)][:8]
    if not keys:
        return []
    return [{"file": rel, "line": text[:m.start()].count("\n") + 1, "severity": "medium",
             "rule": "kubernetes-secret-manifest", "title": "Manifiesto de Kubernetes tipo Secret con datos embebidos",
             "secret_type": f"Manifiesto Secret — claves: {', '.join(keys)}",
             "match": "(valores en base64 bajo data:/stringData:)",
             "context": f"kind: Secret · claves de datos: {', '.join(keys)}", "engine": "builtin/k8s-manifest"}]


def _scan_filename(rel: str) -> list[dict]:
    return [{"file": rel, "line": "—", "severity": sev, "rule": rule, "title": stype, "secret_type": stype,
             "match": "(por nombre de archivo)", "context": rel, "engine": "builtin/filename"}
            for rule, stype, sev, rx in _SENSITIVE_FILENAME_PATTERNS if rx.search(rel)]


def _sha(s: str, n: int = 64) -> str:
    return hashlib.sha256(s.encode("utf-8", "ignore")).hexdigest()[:n]


def _scan_line(rel: str, ln: int, line: str, seen: set, st: dict, findings: list) -> None:
    suppressed = bool(_SUPPRESS_RE.search(line))
    cands: dict[str, dict] = {}
    for rule, stype, sev, rx in _PROVIDERS:
        m = rx.search(line)
        if not m:
            continue
        raw = m.group(m.lastindex) if m.lastindex else m.group(0)
        eff = "low" if _looks_like_example(raw) else sev
        pkey = hashlib.sha1(raw.encode("utf-8", "ignore")).hexdigest()[:20]
        rank = (0 if rule in _GENERIC_CATCHALL_RULES else 1, -SEVERITY_ORDER.get(eff, 99))
        if pkey in cands and cands[pkey]["_rank"] >= rank:
            continue
        cands[pkey] = {"file": rel, "line": ln, "severity": eff, "rule": rule, "title": stype,
                       "secret_type": stype, "match": redact(raw), "_raw": raw, "_legacy_match": _redact_v1(raw),
                       "engine": "builtin", "_rank": rank, "_raw_hash": _sha(raw)}
    # El contexto oculta TODOS los valores detectados en la línea (no solo el propio): si no, el hallazgo del
    # usuario de una cadena de conexión mostraba la contraseña en claro.
    raws = [c["_raw"] for c in cands.values()]
    for c in cands.values():
        c["context"] = redact_line(line, c.pop("_raw"), raws)
    for pkey, f in cands.items():
        if (rel, ln, pkey) in seen:
            continue
        seen.add((rel, ln, pkey))
        f.pop("_rank")
        if suppressed:
            st["suppressed"] += 1
        else:
            findings.append(f)
    if cands:
        return
    em = _ENTROPY_ASSIGN_RE.search(line)
    if not em:
        return
    raw = em.group(1)
    key = (rel, ln, "entropy:" + raw[:24])
    if not _looks_high_entropy(raw) or _looks_like_example(raw) or key in seen:
        return
    seen.add(key)
    if suppressed:
        st["suppressed"] += 1
        return
    st["entropy"] += 1
    findings.append({"file": rel, "line": ln, "severity": "low", "rule": "high-entropy-secret",
                     "title": "Posible secreto de alta entropía",
                     "secret_type": "Cadena de alta entropía (heurística)", "match": redact(raw),
                     "context": redact_line(line, raw), "engine": "builtin/entropy", "_raw_hash": _sha(raw),
                     "_legacy_match": _redact_v1(raw)})


def _scan_builtin(target: Path, log=None, cancel=None, progress=None, total_files: int = 0):
    findings: list[dict] = []
    seen: set = set()
    st = dict.fromkeys(("seen", "skip_ext", "skip_size", "skip_binary", "skip_error", "entropy", "filename",
                        "suppressed"), 0)
    scanned = 0
    for fp in _iter_files(target):
        st["seen"] += 1
        if cancel is not None and cancel.is_set():
            _log(log, "[secretos] escaneo cancelado.")
            break
        try:
            rel = fp.relative_to(target).as_posix()   # mismo formato que git-secrets → deduplicación entre motores
        except ValueError:
            rel = fp.as_posix()
        hits = _scan_filename(rel)
        st["filename"] += len(hits)
        findings += hits
        ext = fp.suffix.lower()
        if ext in _SKIP_EXT:
            st["skip_ext"] += 1
            continue
        try:
            if fp.stat().st_size > _MAX_BYTES:
                st["skip_size"] += 1
                continue
        except Exception:
            st["skip_error"] += 1
            continue
        text = _read_text(fp)
        if text is None:
            st["skip_binary"] += 1
            continue
        if ext in (".yaml", ".yml"):
            hits = _scan_k8s(rel, text)
            st["filename"] += len(hits)
            findings += hits
        scanned += 1
        if progress and total_files:
            progress(scanned, total_files)
        for ln, full_line in enumerate(text.splitlines(), 1):
            # Líneas largas (JS minificado, JSON en una línea): se revisan por ventanas solapadas en lugar de
            # omitirse — es justo donde suelen quedar llaves de API embebidas en bundles.
            windows = [full_line] if len(full_line) <= 4000 else \
                [full_line[i:i + 4000] for i in range(0, len(full_line), 3500)]
            for line in windows:
                _scan_line(rel, ln, line, seen, st, findings)
    _log(log, f"[secretos] motor integrado: {st['seen']} archivo(s) vistos · {scanned} escaneados · omitidos "
              f"{st['skip_ext']} por tipo, {st['skip_size']} demasiado grandes, {st['skip_binary']} binarios, "
              f"{st['skip_error']} ilegibles · {st['filename']} por nombre de archivo · {st['entropy']} por entropía"
              + (f" · {st['suppressed']} suprimidos por marcador en línea" if st["suppressed"] else ""))
    return findings, scanned


def _merge(dupes: list[dict]) -> dict:
    dupes = sorted(dupes, key=lambda f: (SEVERITY_ORDER.get(f["severity"], 99), f.get("engine") != "builtin"))
    merged = dict(dupes[0])
    engines = sorted({f.get("engine", "") for f in dupes})
    if len(engines) > 1:
        merged.update(engine=" + ".join(engines), cross_validated=True)
    return merged


def _dedupe(findings: list[dict]) -> list[dict]:
    by_loc: dict = {}
    for f in findings:
        by_loc.setdefault((f["file"], f["line"]), []).append(f)
    out: list[dict] = []
    for group in by_loc.values():
        if len(group) == 1:
            out += group
            continue
        out += [f for f in group if f.get("engine") == "git-secrets/history"]
        exact: dict = {}
        for f in group:
            if f.get("engine") != "git-secrets/history":
                exact.setdefault((f.get("rule", ""), f.get("match", "")), []).append(f)
        collapsed = [_merge(v) if len(v) > 1 else v[0] for v in exact.values()]
        gs = [f for f in collapsed if f.get("engine") == "git-secrets"]
        others = [f for f in collapsed if f.get("engine") != "git-secrets"]
        out += [_merge(gs + others)] if len(gs) == 1 and len(others) == 1 else collapsed
    return out


def _fingerprint(f: dict) -> str:
    return _sha(f"{f.get('file', '')}|{f.get('rule', '')}|{f.get('match', '')}", 24)


def _fingerprints(f: dict) -> list[str]:
    """Huella actual y equivalentes de líneas base anteriores (rutas con «\\» en Windows, ocultamiento antiguo)."""
    fp = str(f.get("file", ""))
    out = [_fingerprint(f), _fingerprint({**f, "file": fp.replace("/", "\\")})]
    if f.get("_legacy_match"):
        out += [_fingerprint({**f, "match": f["_legacy_match"]}),
                _fingerprint({**f, "file": fp.replace("/", "\\"), "match": f["_legacy_match"]})]
    return list(dict.fromkeys(out))


def _baseline_data(target) -> dict:
    p = Path(target) / BASELINE_FILENAME
    try:
        d = json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
    except Exception:
        d = {}
    if not isinstance(d, dict) or not isinstance(d.get("accepted"), dict):
        d = {"accepted": {}} if not isinstance(d, dict) else {**d, "accepted": {}}
    return d


def load_baseline(target) -> dict:
    return _baseline_data(target)["accepted"]


def save_baseline_entry(target, finding: dict, note: str = "") -> str:
    data = _baseline_data(target)
    fp = _fingerprint(finding)
    data["accepted"][fp] = {"file": finding.get("file", ""), "rule": finding.get("rule", ""),
                            "secret_type": finding.get("secret_type", finding.get("title", "")), "note": note,
                            "added_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
    (Path(target) / BASELINE_FILENAME).write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    return fp


def remove_baseline_entry(target, fingerprint: str) -> bool:
    data = _baseline_data(target)
    if data["accepted"].pop(fingerprint, None) is None:
        return False
    (Path(target) / BASELINE_FILENAME).write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    return True


def scan_path(target, log=None, *, cancel=None, git_secrets_status: Optional[dict] = None, progress=None) -> dict:
    target = Path(target).resolve()
    _log(log, f"[secretos] escaneando {target}")
    t0 = time.time()
    findings: list[dict] = []
    script = (git_secrets_status or {}).get("path")
    gs_active = bool(script and Path(script).exists())
    if gs_active:
        _log(log, f"[secretos] capa git-secrets activa ({script})")
        try:
            findings += _run_git_secrets(Path(script), target, log)
        except Exception as e:
            _log(log, f"[secretos] error en la capa git-secrets: {e!r}")
    else:
        _log(log, "[secretos] git-secrets NO está disponible en este equipo — solo se usa el motor de patrones "
                  "integrado (si el proxy corporativo bloquea la descarga, los hallazgos dependen solo de las reglas "
                  "integradas).")
    total = sum(1 for _ in _iter_files(target)) if progress else 0
    builtin, scanned = _scan_builtin(target, log, cancel=cancel, progress=progress, total_files=total)
    findings = _dedupe(findings + builtin)
    counts_by_hash = Counter(f["_raw_hash"] for f in findings if f.get("_raw_hash"))
    for f in findings:
        h = f.pop("_raw_hash", None)
        if h and counts_by_hash[h] > 1:
            f["reused_elsewhere"] = counts_by_hash[h] - 1
    baseline = load_baseline(target)
    suppressed = []
    if baseline:
        kept = []
        for f in findings:
            if entry := next((baseline[k] for k in _fingerprints(f) if k in baseline), None):
                suppressed.append({**f, "baseline_note": entry.get("note", "")})
            else:
                kept.append(f)
        findings = kept
    for f in (*findings, *suppressed):
        f.pop("_legacy_match", None)
    findings.sort(key=lambda x: (SEVERITY_ORDER.get(x["severity"], 99), str(x["file"]),
                                 x["line"] if isinstance(x["line"], int) else -1))
    counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}
    for f in findings:
        counts[f["severity"]] = counts.get(f["severity"], 0) + 1
    dt = time.time() - t0
    if not findings and scanned and not suppressed:
        _log(log, "[secretos] 0 hallazgos en un árbol no vacío. Si esperaba coincidencias, confirme que el objetivo "
                  "es la raíz del código fuente (no bin/obj); el motor integrado detecta credenciales en "
                  "configuración/cadenas de conexión, llaves y tokens — no cualquier cadena con forma de contraseña.")
    _log(log, f"[secretos] listo — {len(findings)} hallazgo(s) en {scanned} archivo(s) en {dt:.1f}s"
              + (f" ({len(suppressed)} aceptados en la línea base, ocultos)" if suppressed else ""))
    return {"generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "target": str(target),
            "engine": "git-secrets + integrado" if gs_active else "integrado", "scanned_files": scanned,
            "elapsed": round(dt, 2), "counts": counts, "total": len(findings), "findings": findings,
            "baseline_suppressed": suppressed, "baseline_suppressed_count": len(suppressed)}


_SECRETS_HTML = r"""<!doctype html><html lang="es"><head><meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Reporte de secretos — {generated_at}</title><style>
:root{{--bg:#0d1b2a;--panel:#13243a;--bd:#21364f;--tx:#e8eef7;--mu:#90a4bd;
--ac:#F5A800;--crit:#ff5d6c;--high:#ff944d;--med:#ffd23f;--low:#5fe0a0}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--tx);
font:14px/1.55 -apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif}}
.shell{{max-width:1280px;margin:0 auto;padding:30px clamp(16px,4vw,48px) 80px}}
.top{{display:flex;align-items:center;gap:14px;margin-bottom:22px;flex-wrap:wrap}}
.logo{{width:42px;height:42px;border-radius:11px;background:var(--ac);color:#111;
display:grid;place-items:center;font-weight:800;font-size:20px}}
h1{{margin:0;font-size:22px}}.sub{{color:var(--mu);font-size:12px}}
.pill{{margin-left:auto;display:flex;gap:8px;flex-wrap:wrap}}
.tag{{background:var(--panel);border:1px solid var(--bd);border-radius:999px;
padding:6px 12px;font-size:12px;color:var(--mu)}}.tag b{{color:var(--tx)}}
.kpis{{display:grid;grid-template-columns:repeat(6,1fr);gap:12px;margin:8px 0 26px}}
@media(max-width:760px){{.kpis{{grid-template-columns:repeat(3,1fr)}}}}
.kpi{{background:var(--panel);border:1px solid var(--bd);border-left:4px solid var(--ac);
border-radius:12px;padding:16px}}.kpi .l{{color:var(--mu);font-size:11px;
text-transform:uppercase;letter-spacing:.1em}}.kpi .v{{font-size:30px;font-weight:800;margin-top:6px}}
.kpi.critical{{border-left-color:var(--crit)}}.kpi.high{{border-left-color:var(--high)}}
.kpi.medium{{border-left-color:var(--med)}}.kpi.low{{border-left-color:var(--low)}}
.kpi.accepted{{border-left-color:var(--mu)}}
.badge-reuse{{display:inline-block;margin-left:6px;padding:1px 7px;border-radius:999px;
font-size:10px;font-weight:700;background:#F5A80022;color:var(--ac)}}
table{{width:100%;border-collapse:collapse;background:var(--panel);
border:1px solid var(--bd);border-radius:12px;overflow:hidden;font-size:13px}}
th{{text-align:left;color:var(--mu);font-size:11px;text-transform:uppercase;
letter-spacing:.07em;padding:12px 14px;border-bottom:1px solid var(--bd)}}
td{{padding:11px 14px;border-bottom:1px solid var(--bd);vertical-align:top}}
tr:last-child td{{border-bottom:0}}tr:hover td{{background:#16294250}}
code{{font-family:ui-monospace,Menlo,Consolas,monospace;background:#0b1626;
border:1px solid var(--bd);border-radius:6px;padding:1px 6px;font-size:12px}}
.sev{{display:inline-block;padding:3px 10px;border-radius:999px;font-size:11px;
font-weight:800;text-transform:uppercase}}
.sev.critical{{background:#ff5d6c22;color:var(--crit)}}.sev.high{{background:#ff944d22;color:var(--high)}}
.sev.medium{{background:#ffd23f22;color:var(--med)}}.sev.low{{background:#5fe0a022;color:var(--low)}}
.empty{{text-align:center;padding:48px;color:var(--mu);background:var(--panel);
border:1px dashed var(--bd);border-radius:12px}}
.note{{margin:18px 0;color:var(--mu);font-size:12px}}
footer{{text-align:center;color:var(--mu);font-size:12px;padding:34px 0 0}}
</style></head><body><div class="shell">
<div class="top"><div class="logo">🔑</div>
<div><h1>Reporte de secretos</h1><div class="sub">git-secrets · detección de credenciales embebidas</div></div>
<div class="pill"><span class="tag">Motor <b>{engine}</b></span>
<span class="tag">Objetivo <b>{target}</b></span>
<span class="tag">Archivos <b>{scanned_files}</b></span>
<span class="tag">Generado <b>{generated_at}</b></span></div></div>
<div class="kpis">
<div class="kpi"><div class="l">Total</div><div class="v">{total}</div></div>
<div class="kpi critical"><div class="l">Crítica</div><div class="v">{c_critical}</div></div>
<div class="kpi high"><div class="l">Alta</div><div class="v">{c_high}</div></div>
<div class="kpi medium"><div class="l">Media</div><div class="v">{c_medium}</div></div>
<div class="kpi low"><div class="l">Baja</div><div class="v">{c_low}</div></div>
<div class="kpi accepted"><div class="l">Aceptados</div><div class="v">{c_accepted}</div></div>
</div>
{body}
<p class="note">Los secretos detectados se muestran ocultos. Trate cualquier credencial señalada como
comprometida: rótela y elimínela del historial de control de versiones.</p>
<footer>Escáner de vulnerabilidades · Módulo de secretos · {generated_at}</footer>
</div></body></html>"""


def render_secrets_html(result: dict) -> str:
    esc = html.escape
    rows = []
    for f in result.get("findings", []):
        eng = str(f.get("engine", "")) + (" ✓" if f.get("cross_validated") else "")
        reuse = (f"<span class='badge-reuse'>🔁 en {f['reused_elsewhere']} lugar(es) más</span>"
                 if f.get("reused_elsewhere") else "")
        rows.append(f"<tr><td><span class='sev {f['severity']}'>{SEV_ES.get(f['severity'], f['severity'])}</span></td>"
                    f"<td>{esc(f.get('secret_type', f.get('rule', '')))}{reuse}</td>"
                    f"<td><code>{esc(str(f['file']))}</code></td><td>{f.get('line', '?')}</td>"
                    f"<td><code>{esc(str(f.get('match', '')))}</code></td><td><code>{esc(eng)}</code></td></tr>")
    body = ("<table><thead><tr><th>Severidad</th><th>Tipo</th><th>Archivo</th><th>Línea</th>"
            "<th>Secreto (oculto)</th><th>Motor</th></tr></thead><tbody>" + "".join(rows) + "</tbody></table>"
            if rows else "<div class='empty'>No se detectaron secretos embebidos. Nada que rotar.</div>")
    c = result.get("counts", {})
    return _SECRETS_HTML.format(generated_at=result.get("generated_at", ""), engine=result.get("engine", ""),
                                target=esc(str(result.get("target", ""))), scanned_files=result.get("scanned_files", 0),
                                total=result.get("total", 0), c_critical=c.get("critical", 0), c_high=c.get("high", 0),
                                c_medium=c.get("medium", 0), c_low=c.get("low", 0),
                                c_accepted=result.get("baseline_suppressed_count", 0), body=body)


def write_secrets_report(result: dict, out_dir) -> Path:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "secrets.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    path = out_dir / "secrets.html"
    path.write_text(render_secrets_html(result), encoding="utf-8")
    return path


class _SecretsPanelMixin:
    def _secret_card(self, parent, f: dict, accepted: bool = False):
        p = T["panel_bg"]
        stype = f.get("secret_type", f.get("rule", "Secreto")) or "Secreto"
        if f.get("reused_elsewhere"):
            stype += f"  🔁 en {f['reused_elsewhere']} lugar(es) más"
        card = tk.Frame(parent, bg=p)
        card.pack(fill="x", pady=(0, 2))
        tk.Frame(card, bg=T["muted"] if accepted else T["border"], width=4).pack(side="left", fill="y")
        body = tk.Frame(card, bg=p, padx=3, pady=2)
        body.pack(side="left", fill="both", expand=True)
        top = tk.Frame(body, bg=p)
        top.pack(fill="x")
        tk.Label(top, text="🔑", font=(FUI, 10), bg=p, fg=T["muted"]).pack(side="left", padx=(0, 2))
        tk.Label(top, text=stype, font=(FUI_TITLE, 13, "bold"), bg=p, fg=T["card_fg"]).pack(side="left")
        sev = sev_norm(f.get("severity"))
        tk.Label(top, text=SEV_ES.get(sev, sev).upper(), font=(FUI, 12, "bold"), bg=p,
                 fg=self._sev_color(sev)).pack(side="right")
        act = tk.Label(top, text="↩ Deshacer" if accepted else "✓ Aceptar", font=(FUI, 10, "bold"), bg=p,
                       fg=T["accent"], cursor="hand2")
        act.pack(side="right", padx=(0, 2))
        act.bind("<Button-1>", lambda _e: self._toggle_secret_accept(f, accepted))
        self._lbl(body, f"📄 {f.get('file', '—')}   :   {f.get('line', '?')}", anchor="w").pack(fill="x", pady=(1, 0))
        if accepted and f.get("baseline_note"):
            self._lbl(body, f"📝 {f['baseline_note']}", anchor="w").pack(fill="x", pady=(1, 0))
        if f.get("match"):
            tk.Label(body, text=f["match"], font=(FMONO, 12), bg=T["surface2"], fg=T["card_fg"], anchor="w",
                     padx=2, pady=1).pack(fill="x", pady=(1, 0))

    def _toggle_secret_accept(self, f: dict, accepted: bool):
        target = self._secrets_target
        # Escaneo de varias carpetas: cada hallazgo recuerda su carpeta («_root») y su ruta original («_rel»), así la
        # decisión se guarda en la línea base de ESA carpeta con la misma huella que usará el próximo escaneo.
        base_f = {**f, "file": f["_rel"]} if f.get("_root") and "_rel" in f else f
        target = f.get("_root") or target
        if not target:
            return self._show_info_popup("Aceptar hallazgo", "Ejecute un escaneo de Secretos primero — no hay una "
                                         "carpeta objetivo activa a la cual asociar esta decisión.")
        try:
            if accepted:
                remove_baseline_entry(target, _fingerprint(base_f))
                self._secrets_baseline = [x for x in self._secrets_baseline if x is not f]
                self._secrets_active.append({k: v for k, v in f.items() if k != "baseline_note"})
            else:
                from tkinter import simpledialog
                note = simpledialog.askstring("Aceptar hallazgo", "Nota opcional (por qué se acepta este hallazgo):",
                                              parent=self) or ""
                save_baseline_entry(target, base_f, note)
                self._secrets_active = [x for x in self._secrets_active if x is not f]
                self._secrets_baseline.append({**f, "baseline_note": note})
        except Exception as e:
            return self._show_error_popup("Aceptar hallazgo", f"No se pudo guardar la decisión: {e!r}")
        self._render_secrets(self._secrets_active, self._secrets_target, self._secrets_baseline)

    def _render_secrets(self, findings, target=None, baseline=None):
        box = self._secrets_box
        for w in box.winfo_children():
            w.destroy()
        self._secrets_target = target
        self._secrets_active, self._secrets_baseline = list(findings or []), list(baseline or [])
        if not self._secrets_active and not self._secrets_baseline:
            self._lbl(box, "Sin secretos — ejecute un escaneo.", anchor="w").pack(fill="x")
        else:
            if not self._secrets_active:
                self._lbl(box, "Sin hallazgos activos — todo lo detectado fue aceptado.",
                          anchor="w").pack(fill="x", pady=(0, 2))
            self._secret_cards_paged(box, self._secrets_active)
            if self._secrets_baseline:
                st = {"open": False}
                link = tk.Label(box, font=(FUI, 12, "bold"), bg=T["panel_bg"], fg=T["card_fg"], cursor="hand2",
                                anchor="w")
                link.pack(fill="x", pady=(2, 0))
                body = tk.Frame(box, bg=T["panel_bg"])

                def toggle(_e=None):
                    st["open"] = not st["open"]
                    draw()

                def draw():
                    link.config(text=f"{'▾' if st['open'] else '▸'} {len(self._secrets_baseline)} aceptado(s) — "
                                     "ver / deshacer")
                    for w in body.winfo_children():
                        w.destroy()
                    if st["open"]:
                        self._secret_cards_paged(body, self._secrets_baseline, accepted=True)
                        body.pack(fill="x", pady=(1, 0))
                    else:
                        body.pack_forget()
                link.bind("<Button-1>", toggle)
                draw()
        n = len(self._secrets_active)
        self._secrets_summary.config(text="sin hallazgos" if not n else f"{n} hallazgo{'' if n == 1 else 's'}")

    _SECRETS_PAGE = 150

    def _secret_cards_paged(self, box, items, accepted: bool = False, start: int = 0) -> None:
        """Dibuja las tarjetas por páginas: miles de tarjetas a la vez congelaban la interfaz durante segundos."""
        end = min(len(items), start + self._SECRETS_PAGE)
        for f in items[start:end]:
            if accepted:
                self._secret_card(box, f, accepted=True)
            else:
                self._secret_card(box, f)
        rest = len(items) - end
        if rest > 0:
            more = tk.Label(box, text=f"Mostrar {min(rest, self._SECRETS_PAGE)} más  ·  quedan {rest}",
                            font=(FUI, 11, "bold"), bg=T["panel_bg"], fg=T["accent"], cursor="hand2", anchor="w")
            more.pack(fill="x", pady=(px(4), px(2)))

            def load(_e=None):
                more.destroy()
                self._secret_cards_paged(box, items, accepted, end)
            more.bind("<Button-1>", load)

    def _build_secrets_panel(self, parent):
        wrap = tk.Frame(parent, bg=T["bg"])
        inner = self._card(wrap, "Secretos", pady=(0, 0))
        self._secrets_summary = tk.Label(inner.right, text="sin hallazgos", font=(FUI, 12, "bold"), bg=T["panel_bg"],
                                         fg=T["muted"])
        self._secrets_summary.pack(side="right")
        self._secrets_box = tk.Frame(inner, bg=T["panel_bg"])
        self._secrets_box.pack(fill="both", expand=True)
        self._render_secrets(getattr(self, "_secrets_active", []), getattr(self, "_secrets_target", None),
                             getattr(self, "_secrets_baseline", []))
        return wrap


if __name__ == "__main__":
    tgt = sys.argv[1] if len(sys.argv) > 1 else "."
    res = scan_path(tgt, print, git_secrets_status=ensure_git_secrets(print))
    print("reporte de secretos:", write_secrets_report(res, Path(tgt) / "_secrets_out"))
    print(f"patrones cargados: {len(_PROVIDERS)} + entropía + {len(_SENSITIVE_FILENAME_PATTERNS)} heurísticas de nombre")
