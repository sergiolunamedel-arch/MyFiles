"""Modelo unificado de hallazgos.

Por qué no basta con agrupar por CWE: dos XSS distintos comparten CWE-79, así que el CWE sirve para CLASIFICAR, no
para DEDUPLICAR. El modelo usa dos niveles:

  1) Huella por tipo (identidad del hallazgo) — fusiona el MISMO problema reportado por varias herramientas:
       · web/API (ZAP, Nuclei, Probely): ruta normalizada + parámetro + CWE
       · IaC (Checkov, Trivy, SonarQube): archivo + línea + CWE (o regla)
       · dependencias/contenedores: paquete + versión + CVE
     Al fusionar se conserva la severidad más alta y se ENRIQUECE: descripción y remediación de cada herramienta
     quedan disponibles («Detectado por: ZAP, Nuclei»).
  2) CWE → OWASP Top 10 (clasificación) — vista transversal en el reporte y correlación código↔ejecución: si la misma
     debilidad aparece en SAST y en DAST/API se marca «confirmada en ejecución» (prioridad alta para el desarrollador).

Exportación estándar: SARIF 2.1.0 (un run por herramienta) + JSON unificado.
"""
from __future__ import annotations

import html as _html
from urllib.parse import urlparse

from ui_common import *

SEV_ORDER_DESC = ("critical", "high", "medium", "low", "info")
_SEV_RANK = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}

CWE_NAMES = {
    "CWE-20": "Validación de entrada incorrecta", "CWE-22": "Path traversal", "CWE-77": "Inyección de comandos",
    "CWE-78": "Inyección de comandos del SO", "CWE-79": "Cross-site scripting (XSS)", "CWE-89": "Inyección SQL",
    "CWE-94": "Inyección de código", "CWE-116": "Codificación de salida incorrecta", "CWE-200": "Exposición de información",
    "CWE-209": "Información sensible en mensajes de error", "CWE-250": "Ejecución con privilegios innecesarios",
    "CWE-259": "Contraseña embebida", "CWE-269": "Gestión de privilegios incorrecta", "CWE-284": "Control de acceso incorrecto",
    "CWE-285": "Autorización incorrecta", "CWE-287": "Autenticación incorrecta", "CWE-295": "Validación de certificados",
    "CWE-311": "Datos sensibles sin cifrar", "CWE-312": "Almacenamiento en texto claro", "CWE-319": "Transmisión en texto claro",
    "CWE-326": "Cifrado débil", "CWE-327": "Algoritmo criptográfico inseguro", "CWE-330": "Aleatoriedad insuficiente",
    "CWE-345": "Verificación de autenticidad insuficiente", "CWE-352": "CSRF", "CWE-359": "Exposición de datos personales",
    "CWE-400": "Consumo de recursos sin control", "CWE-434": "Carga de archivos peligrosos",
    "CWE-489": "Código de depuración activo", "CWE-497": "Exposición de información del sistema",
    "CWE-502": "Deserialización insegura", "CWE-522": "Credenciales mal protegidas", "CWE-525": "Caché con datos sensibles",
    "CWE-532": "Datos sensibles en logs", "CWE-548": "Listado de directorios", "CWE-601": "Redirección abierta",
    "CWE-611": "XXE", "CWE-614": "Cookie sin atributo Secure", "CWE-639": "IDOR / BOLA",
    "CWE-668": "Recurso expuesto a esfera incorrecta", "CWE-693": "Falla de mecanismo de protección",
    "CWE-732": "Permisos incorrectos", "CWE-770": "Asignación de recursos sin límites", "CWE-778": "Registro insuficiente",
    "CWE-798": "Credenciales embebidas", "CWE-862": "Falta de autorización", "CWE-863": "Autorización incorrecta",
    "CWE-915": "Asignación masiva", "CWE-918": "SSRF", "CWE-937": "Componente con vulnerabilidades conocidas",
    "CWE-1004": "Cookie sin HttpOnly", "CWE-1021": "Clickjacking", "CWE-1104": "Componente sin mantenimiento",
    "CWE-1275": "Cookie con SameSite incorrecto", "CWE-1395": "Dependencia vulnerable de terceros",
}

OWASP = {
    "A01 Control de acceso roto": {"CWE-22", "CWE-23", "CWE-35", "CWE-59", "CWE-200", "CWE-201", "CWE-219", "CWE-264",
                                    "CWE-275", "CWE-276", "CWE-284", "CWE-285", "CWE-352", "CWE-359", "CWE-377",
                                    "CWE-402", "CWE-425", "CWE-441", "CWE-497", "CWE-538", "CWE-540", "CWE-548",
                                    "CWE-552", "CWE-566", "CWE-601", "CWE-639", "CWE-651", "CWE-668", "CWE-706",
                                    "CWE-862", "CWE-863", "CWE-913", "CWE-922", "CWE-1275"},
    "A02 Fallas criptográficas": {"CWE-261", "CWE-296", "CWE-310", "CWE-319", "CWE-321", "CWE-322", "CWE-323",
                                   "CWE-324", "CWE-325", "CWE-326", "CWE-327", "CWE-328", "CWE-329", "CWE-330",
                                   "CWE-331", "CWE-335", "CWE-336", "CWE-337", "CWE-338", "CWE-340", "CWE-347",
                                   "CWE-523", "CWE-720", "CWE-757", "CWE-759", "CWE-760", "CWE-780", "CWE-818",
                                   "CWE-916", "CWE-311", "CWE-312", "CWE-614"},
    "A03 Inyección": {"CWE-20", "CWE-74", "CWE-75", "CWE-77", "CWE-78", "CWE-79", "CWE-80", "CWE-83", "CWE-87",
                      "CWE-88", "CWE-89", "CWE-90", "CWE-91", "CWE-93", "CWE-94", "CWE-95", "CWE-96", "CWE-97",
                      "CWE-98", "CWE-99", "CWE-113", "CWE-116", "CWE-138", "CWE-184", "CWE-470", "CWE-471",
                      "CWE-564", "CWE-610", "CWE-643", "CWE-644", "CWE-652", "CWE-917"},
    "A04 Diseño inseguro": {"CWE-73", "CWE-183", "CWE-209", "CWE-213", "CWE-235", "CWE-256", "CWE-257", "CWE-266",
                            "CWE-269", "CWE-280", "CWE-311", "CWE-313", "CWE-316", "CWE-419", "CWE-430", "CWE-434",
                            "CWE-444", "CWE-451", "CWE-472", "CWE-501", "CWE-522", "CWE-525", "CWE-539", "CWE-579",
                            "CWE-598", "CWE-602", "CWE-642", "CWE-646", "CWE-650", "CWE-653", "CWE-656", "CWE-657",
                            "CWE-799", "CWE-807", "CWE-840", "CWE-841", "CWE-927", "CWE-1021", "CWE-1173"},
    "A05 Configuración insegura": {"CWE-2", "CWE-11", "CWE-13", "CWE-15", "CWE-16", "CWE-260", "CWE-315", "CWE-520",
                                   "CWE-526", "CWE-537", "CWE-541", "CWE-547", "CWE-611", "CWE-614", "CWE-756",
                                   "CWE-776", "CWE-942", "CWE-1004", "CWE-1032", "CWE-1174", "CWE-693", "CWE-250",
                                   "CWE-732", "CWE-489"},
    "A06 Componentes vulnerables": {"CWE-937", "CWE-1035", "CWE-1104", "CWE-1395"},
    "A07 Fallas de identificación y autenticación": {"CWE-255", "CWE-259", "CWE-287", "CWE-288", "CWE-290", "CWE-294",
                                                      "CWE-295", "CWE-297", "CWE-300", "CWE-302", "CWE-304", "CWE-306",
                                                      "CWE-307", "CWE-346", "CWE-384", "CWE-521", "CWE-613", "CWE-620",
                                                      "CWE-640", "CWE-798", "CWE-940", "CWE-1216"},
    "A08 Fallas de integridad de software y datos": {"CWE-345", "CWE-353", "CWE-426", "CWE-494", "CWE-502", "CWE-565",
                                                      "CWE-784", "CWE-829", "CWE-830", "CWE-915"},
    "A09 Fallas de registro y monitoreo": {"CWE-117", "CWE-223", "CWE-532", "CWE-778"},
    "A10 SSRF": {"CWE-918"},
}
_CWE_TO_OWASP = {c: k for k, cs in OWASP.items() for c in cs}

_CATEGORY_BY_CWE = {"CWE-79": "xss", "CWE-80": "xss", "CWE-89": "sqli", "CWE-77": "injection", "CWE-78": "injection",
                    "CWE-94": "injection", "CWE-917": "injection", "CWE-352": "csrf", "CWE-601": "redirect",
                    "CWE-918": "ssrf", "CWE-319": "ssl", "CWE-326": "ssl", "CWE-327": "ssl", "CWE-295": "ssl",
                    "CWE-693": "headers", "CWE-1021": "headers", "CWE-614": "headers", "CWE-1004": "headers",
                    "CWE-942": "cors", "CWE-200": "info", "CWE-209": "info", "CWE-497": "info", "CWE-548": "info",
                    "CWE-287": "auth", "CWE-306": "auth", "CWE-862": "auth", "CWE-863": "auth", "CWE-639": "bola"}

REMEDIATION_BY_CWE = {
    "CWE-79": "Codifique la salida según el contexto (HTML/atributo/JS) y aplique una Content-Security-Policy estricta.",
    "CWE-89": "Use consultas parametrizadas u ORM; nunca concatene datos del usuario en SQL.",
    "CWE-78": "Evite invocar el shell; use APIs con argumentos separados y lista blanca de valores.",
    "CWE-22": "Normalice la ruta y verifique que permanece dentro del directorio permitido.",
    "CWE-352": "Use tokens anti-CSRF y cookies SameSite=Lax/Strict; valide Origin/Referer.",
    "CWE-601": "Permita solo destinos de una lista blanca; no redirija a URLs recibidas del usuario.",
    "CWE-918": "Valide y restrinja destinos salientes (lista blanca); bloquee rangos internos y metadatos de nube.",
    "CWE-319": "Exija HTTPS (TLS 1.2+) y HSTS; redirija todo HTTP a HTTPS.",
    "CWE-614": "Marque las cookies de sesión con Secure.", "CWE-1004": "Marque las cookies de sesión con HttpOnly.",
    "CWE-693": "Agregue cabeceras de seguridad: CSP, X-Content-Type-Options, X-Frame-Options/frame-ancestors, HSTS.",
    "CWE-1021": "Defina frame-ancestors en la CSP (o X-Frame-Options: DENY).",
    "CWE-200": "Elimine información interna de respuestas (versiones, rutas, trazas).",
    "CWE-209": "Muestre errores genéricos al usuario y registre el detalle solo en el servidor.",
    "CWE-798": "Mueva el secreto a un gestor de secretos, ROTE la credencial y elimínela del historial de git.",
    "CWE-311": "Cifre los datos en reposo y en tránsito (habilite cifrado del recurso / KMS).",
    "CWE-250": "Ejecute con el mínimo privilegio (usuario no root, sin privileged, capabilities mínimas).",
    "CWE-284": "Restrinja el acceso (sin 0.0.0.0/0, sin acceso público), aplique mínimo privilegio.",
    "CWE-732": "Ajuste permisos/políticas al mínimo necesario; evite comodines (*).",
    "CWE-778": "Habilite registros de auditoría y retención adecuada.",
    "CWE-1395": "Actualice la dependencia a una versión corregida.",
}

# Heurística de CWE para reglas de IaC (Checkov y SonarQube no publican CWE; Trivy solo a veces).
_IAC_CWE_RULES = [
    (("secret", "password", "credential", "hardcoded", "access key", "api key", "token"), "CWE-798"),
    (("encrypt", "kms", "cmk", "sse", "at rest", "cifra"), "CWE-311"),
    (("https", "tls", "ssl", "in transit", "insecure protocol", "http "), "CWE-319"),
    (("public", "0.0.0.0", "::/0", "ingress", "internet", "world", "anonymous", "open to"), "CWE-284"),
    (("root", "privileged", "privilege", "capabilit", "runasnonroot", "allowprivilegeescalation", "hostpid",
      "hostnetwork", "hostipc", "sudo", "admin"), "CWE-250"),
    (("wildcard", "*:*", "iam", "policy", "permission", "rbac", "role"), "CWE-732"),
    (("log", "audit", "trail", "monitor", "flow log"), "CWE-778"),
    (("version", "latest tag", "pinned", "image tag", "digest"), "CWE-1104"),
    (("healthcheck", "resource limit", "memory limit", "cpu limit", "limits"), "CWE-770"),
]
_IAC_DEFAULT_SEV = {"CWE-798": "high", "CWE-284": "high", "CWE-250": "high", "CWE-311": "medium", "CWE-319": "medium",
                    "CWE-732": "medium", "CWE-778": "low", "CWE-1104": "low", "CWE-770": "low"}


# ── Normalización ────────────────────────────────────────────────────────────
def sev(s) -> str:
    s = str(s or "").strip().lower()
    return {"crit": "critical", "moderate": "medium", "med": "medium", "informational": "info", "unknown": "low",
            "negligible": "low", "none": "info"}.get(s, s if s in _SEV_RANK else "low")


def worst(*sevs) -> str:
    return max((sev(s) for s in sevs if s), key=_SEV_RANK.get, default="low")


def norm_cwes(value) -> list[str]:
    """'cwe-79', 79, ['CWE-79','CWE-80'], 'CWE-79: …' → ['CWE-79', …] sin duplicados."""
    if value in (None, "", 0, "0", -1, "-1"):
        return []
    items = value if isinstance(value, (list, tuple, set)) else re.split(r"[,;\s]+", str(value))
    out = []
    for it in items:
        m = re.search(r"(\d+)", str(it))
        if m and m.group(1) not in ("0",):
            out.append(f"CWE-{int(m.group(1))}")
    return list(dict.fromkeys(out))


def owasp_for(cwes) -> str:
    return next((_CWE_TO_OWASP[c] for c in norm_cwes(cwes) if c in _CWE_TO_OWASP), "")


def category_for(cwes, title: str = "") -> str:
    for c in norm_cwes(cwes):
        if c in _CATEGORY_BY_CWE:
            return _CATEGORY_BY_CWE[c]
    t = (title or "").lower()
    for kw, cat in (("sql", "sqli"), ("xss", "xss"), ("cross site scripting", "xss"), ("header", "headers"),
                    ("csp", "headers"), ("cookie", "headers"), ("cors", "cors"), ("tls", "ssl"), ("ssl", "ssl"),
                    ("redirect", "redirect"), ("auth", "auth"), ("disclos", "info"), ("version", "info")):
        if kw in t:
            return cat
    return "misc"


def cwe_name(c: str) -> str:
    return CWE_NAMES.get(c, "")


def strip_html(s: str) -> str:
    s = re.sub(r"<\s*(br|/p|/li)\s*/?>", "\n", s or "", flags=re.I)
    s = re.sub(r"<[^>]+>", "", s)
    return re.sub(r"\n{3,}", "\n\n", _html.unescape(s)).strip()


def iac_cwe(text: str) -> str:
    t = (text or "").lower()
    return next((cwe for kws, cwe in _IAC_CWE_RULES if any(k in t for k in kws)), "")


def iac_default_sev(cwe: str) -> str:
    return _IAC_DEFAULT_SEV.get(cwe, "medium")


def _path_key(url: str) -> str:
    try:
        p = urlparse(url or "")
        path = re.sub(r"/\d+(?=/|$)", "/{id}", (p.path or "/").rstrip("/") or "/")
        path = re.sub(r"/[0-9a-f]{8}-[0-9a-f-]{27,}(?=/|$)", "/{uuid}", path, flags=re.I)
        return f"{(p.hostname or '').lower()}{path.lower()}"
    except Exception:
        return (url or "").lower()


def _title_key(t: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", (t or "").lower()).strip()[:60]


# ── Fusión entre herramientas ────────────────────────────────────────────────
def source(tool: str, f: dict) -> dict:
    return {"tool": tool, "title": f.get("title", ""), "description": f.get("description", ""),
            "remediation": f.get("remediation", ""), "references": list(f.get("references") or [])[:8],
            "rule": f.get("rule_id", ""), "severity": sev(f.get("severity"))}


def merge(findings: list[dict], key_fn) -> list[dict]:
    """Fusiona hallazgos equivalentes de distintas herramientas y enriquece descripción/remediación."""
    groups: dict = {}
    for f in findings:
        groups.setdefault(key_fn(f), []).append(f)
    out = []
    for items in groups.values():
        items.sort(key=lambda x: -_SEV_RANK.get(sev(x.get("severity")), 0))
        base = dict(items[0])
        srcs, tools = [], []
        for it in items:
            for s in it.get("sources") or []:
                if (s["tool"], s["title"]) not in {(x["tool"], x["title"]) for x in srcs}:
                    srcs.append(s)
            for t in it.get("detected_by") or []:
                if t not in tools:
                    tools.append(t)
        base.update(severity=worst(*(i.get("severity") for i in items)), sources=srcs, detected_by=tools,
                    cwe=", ".join(dict.fromkeys(c for i in items for c in norm_cwes(i.get("cwe")))),
                    cross_validated=len(tools) > 1)
        base["description"] = next((s["description"] for s in srcs if s.get("description")), base.get("description", ""))
        base["remediation"] = next((s["remediation"] for s in srcs if s.get("remediation")), base.get("remediation", "")) \
            or REMEDIATION_BY_CWE.get((norm_cwes(base["cwe"]) or [""])[0], "")
        base["references"] = list(dict.fromkeys(r for s in srcs for r in s.get("references") or []))[:10]
        base["owasp"] = owasp_for(base["cwe"])
        base["category"] = base.get("category") or category_for(base["cwe"], base.get("title", ""))
        out.append(base)
    out.sort(key=lambda x: (-_SEV_RANK.get(x["severity"], 0), -len(x.get("detected_by") or [])))
    return out


def web_key(f: dict):
    c = (norm_cwes(f.get("cwe")) or [""])[0]
    return ("web", _path_key(f.get("url", "")), (f.get("param") or "").lower(), c or _title_key(f.get("title", "")))


def iac_key(f: dict):
    """Mismo archivo + mismo recurso (o línea si no hay recurso) + misma debilidad (CWE o, sin CWE, el título)."""
    c = (norm_cwes(f.get("cwe")) or [""])[0]
    file = str(f.get("file", "")).replace("\\", "/").lstrip("./").lower()
    where = (f.get("resource") or "").lower() or str(int(f.get("line") or 0))
    return ("iac", file, where, c or _title_key(f.get("title", "")))


def vuln_key(f: dict):
    return ("pkg", (f.get("target") or "").lower(), (f.get("package") or "").lower(), f.get("installed") or "",
            (f.get("vuln_id") or f.get("title") or "").upper())


# ── Vista unificada para el reporte y la UI ──────────────────────────────────
def unify(ctx: dict) -> list[dict]:
    """Aplana el contexto del reporte en una lista homogénea para «Qué corregir primero» y la vista por CWE."""
    out = []

    def add(kind, f, title, location, fix, fix_ok, tools, desc=""):
        cwes = norm_cwes(f.get("cwe"))
        out.append({"kind": kind, "severity": sev(f.get("severity")), "title": title or "Hallazgo", "location": location,
                    "cwe": cwes, "owasp": owasp_for(cwes), "fix": fix or REMEDIATION_BY_CWE.get((cwes or [""])[0], ""),
                    "fix_available": bool(fix_ok), "detected_by": tools, "description": desc})

    for p in ctx.get("projects") or []:
        for i in p.get("issues") or []:
            add("sca", i, f"{i.get('packageName', '?')}@{i.get('version', '?')} — {i.get('title', '')}",
                p.get("project", ""), i.get("recommendation"), i.get("fix_available"), ["Snyk"], i.get("description", ""))
    for fl in ctx.get("files") or []:
        for i in fl.get("issues") or []:
            add("code", i, i.get("title") or i.get("rule"), f"{fl.get('file')}:{i.get('line', '?')}", i.get("recommendation"),
                i.get("fix_available"), ["Snyk Code"], i.get("message", ""))
    for s in (ctx.get("secrets") or {}).get("findings") or []:
        add("secrets", {**s, "cwe": s.get("cwe") or "CWE-798"}, s.get("secret_type") or s.get("rule"),
            f"{s.get('file')}:{s.get('line', '?')}", REMEDIATION_BY_CWE["CWE-798"], True, [s.get("engine") or "integrado"])
    for kind in ("dast", "api"):
        for d in (ctx.get(kind) or {}).get("findings") or []:
            add(kind, d, d.get("title"), d.get("url", ""), d.get("remediation"), bool(d.get("remediation")),
                d.get("detected_by") or [((ctx.get(kind) or {}).get("engine") or "DAST")], d.get("description", ""))
    for v in (ctx.get("container") or {}).get("findings") or []:
        add("container", v, f"{v.get('package')}@{v.get('installed')} — {v.get('vuln_id')}", v.get("target", ""),
            f"Actualizar a {v['fixed']}" if v.get("fixed") else "", bool(v.get("fixed")), v.get("detected_by") or ["Trivy"],
            v.get("description", ""))
    for m in (ctx.get("iac") or {}).get("findings") or []:
        add("iac", m, m.get("title"), f"{m.get('file')}:{m.get('line') or '?'}", m.get("remediation"), True,
            m.get("detected_by") or ["Checkov"], m.get("description", ""))
    return out


def correlate(unified: list[dict]) -> set:
    """CWE presentes tanto en código (SAST/secretos/IaC) como en ejecución (DAST/API): debilidad confirmada."""
    static = {c for u in unified if u["kind"] in ("code", "secrets", "iac") for c in u["cwe"]}
    dynamic = {c for u in unified if u["kind"] in ("dast", "api") for c in u["cwe"]}
    return static & dynamic


def priorities(ctx: dict, n: int = 8) -> list[dict]:
    uni = unify(ctx)
    confirmed = correlate(uni)
    for u in uni:
        u["confirmed"] = bool(set(u["cwe"]) & confirmed)
    uni = [u for u in uni if u["severity"] in ("critical", "high", "medium")]
    uni.sort(key=lambda u: (-_SEV_RANK[u["severity"]], not u["confirmed"], u["kind"] != "secrets",
                            not u["fix_available"], -len(u["detected_by"])))
    return uni[:n]


def group_by_cwe(ctx: dict) -> list[dict]:
    uni = unify(ctx)
    confirmed = correlate(uni)
    groups: dict = {}
    for u in uni:
        for c in u["cwe"] or ["(sin CWE)"]:
            g = groups.setdefault(c, {"cwe": c, "name": cwe_name(c), "owasp": owasp_for([c]), "count": 0,
                                      "worst": "info", "kinds": set(), "tools": set(), "confirmed": c in confirmed,
                                      "fix": REMEDIATION_BY_CWE.get(c, "")})
            g["count"] += 1
            g["worst"] = worst(g["worst"], u["severity"])
            g["kinds"].add(u["kind"])
            g["tools"].update(u["detected_by"])
    out = []
    for g in groups.values():
        out.append({**g, "kinds": sorted(g["kinds"], key=lambda k: STAGES.index(k) if k in STAGES else 99),
                    "tools": sorted(g["tools"])})
    out.sort(key=lambda g: (g["cwe"] == "(sin CWE)", not g["confirmed"], -_SEV_RANK.get(g["worst"], 0), -g["count"]))
    return out


def owasp_summary(ctx: dict) -> list[tuple[str, int, str]]:
    counts: dict = {}
    for u in unify(ctx):
        k = u["owasp"] or "Sin categoría OWASP"
        c, w = counts.get(k, (0, "info"))
        counts[k] = (c + 1, worst(w, u["severity"]))
    return sorted(((k, c, w) for k, (c, w) in counts.items()), key=lambda x: (x[0].startswith("Sin"), x[0]))


# ── Exportación ──────────────────────────────────────────────────────────────
_SARIF_LEVEL = {"critical": "error", "high": "error", "medium": "warning", "low": "note", "info": "note"}


def export_sarif(out_dir: Path, ctx: dict) -> Optional[Path]:
    uni = unify(ctx)
    if not uni:
        return None
    runs: dict = {}
    for u in uni:
        tool = (u["detected_by"] or [u["kind"]])[0]
        run_ = runs.setdefault(tool, {"tool": {"driver": {"name": tool, "rules": {}}}, "results": []})
        rid = (u["cwe"] or [u["kind"]])[0] + ":" + _title_key(u["title"])[:40]
        run_["tool"]["driver"]["rules"].setdefault(rid, {
            "id": rid, "name": u["title"][:120], "shortDescription": {"text": u["title"][:200]},
            "help": {"text": u["fix"] or ""}, "properties": {"cwe": u["cwe"], "owasp": u["owasp"], "kind": u["kind"]}})
        res = {"ruleId": rid, "level": _SARIF_LEVEL.get(u["severity"], "note"),
               "message": {"text": (u["title"] + ("\n" + u["description"][:800] if u["description"] else "")).strip()},
               "properties": {"severity": u["severity"], "detected_by": u["detected_by"], "kind": u["kind"]}}
        if u["location"]:
            loc = str(u["location"])
            m = re.match(r"(.+):(\d+)$", loc)
            phys = {"artifactLocation": {"uri": m.group(1) if m else loc}}
            if m:
                phys["region"] = {"startLine": int(m.group(2))}
            res["locations"] = [{"physicalLocation": phys}]
        run_["results"].append(res)
    for r in runs.values():
        r["tool"]["driver"]["rules"] = list(r["tool"]["driver"]["rules"].values())
    path = Path(out_dir) / "findings.sarif"
    write_json(path, {"$schema": "https://json.schemastore.org/sarif-2.1.0.json", "version": "2.1.0",
                      "runs": list(runs.values())})
    return path


def export_unified_json(out_dir: Path, ctx: dict) -> Optional[Path]:
    uni = unify(ctx)
    if not uni:
        return None
    confirmed = correlate(uni)
    for u in uni:
        u["confirmed_at_runtime"] = bool(set(u["cwe"]) & confirmed)
    uni.sort(key=lambda u: -_SEV_RANK.get(u["severity"], 0))
    path = Path(out_dir) / "findings_unified.json"
    write_json(path, uni)
    return path
