from __future__ import annotations

import queue
import time
from concurrent.futures import ThreadPoolExecutor

from ui_common import *

AUTH_EXIT_GRACE = 20  # s que se espera a que `snyk auth` termine solo tras guardar el token
import admin_policy
import findings as fz
import infra_scanner
import static_scanner as ss
import tool_manager as tm
from secrets_scanner import ensure_git_secrets, scan_path, write_secrets_report

STAGE_CARDS = [("sca", "Dependencias (SCA)"), ("code", "Código (SAST)"), ("secrets", "Secretos"),
               ("container", "Contenedores"), ("iac", "Infraestructura (IaC)"), ("dast", "Web (DAST)"), ("api", "API")]
STAGE_NAMES = dict(STAGE_CARDS)
# Título de la tarjeta en dos renglones (nombre arriba, categoría técnica abajo) para que el switch no lo tape.
STAGE_TITLES = {"sca": ("Dependencias", "SCA"), "code": ("Código", "SAST"), "secrets": ("Secretos", "Secret scanning"),
                "container": ("Contenedores", "Container scanning"), "iac": ("Infraestructura", "IaC"),
                "dast": ("Web", "DAST"), "api": ("API", "API security")}
STAGE_META = {"sca": ("package", "Librerías de terceros con vulnerabilidades conocidas."),
              "code": ("code", "Fallas de seguridad en su propio código."),
              "secrets": ("key", "Contraseñas, llaves y tokens dentro del repositorio."),
              "container": ("container", "CVE y secretos en imágenes (registro, .tar o SBOM)."),
              "iac": ("iac", "Terraform, Kubernetes, Helm, Dockerfile, CloudFormation."),
              "dast": ("globe", "Ataques simulados contra la app web en ejecución."),
              "api": ("link", "Pruebas al API desde su especificación OpenAPI/Postman/GraphQL.")}
STAGE_GROUPS = (("Código fuente · repositorio", ("sca", "code", "secrets")),
                ("Infraestructura", ("container", "iac")),
                ("Aplicación en ejecución", ("dast", "api")))
STAGE_TIPS = {
    "sca": "Revisa las librerías que declara su proyecto (package.json, pom.xml, *.csproj, requirements.txt…) contra "
           "la base de vulnerabilidades de Snyk.\nNecesita: carpeta del repositorio y sesión de Snyk.",
    "code": "Analiza su código fuente en busca de inyecciones, XSS, criptografía débil, etc. (Snyk Code).\n"
            "Necesita: carpeta del repositorio y sesión de Snyk.",
    "secrets": "Busca contraseñas, llaves y tokens escritos en el código o en el historial de git. Corre en su PC, "
               "no envía el código a ningún lado.",
    "container": "Lista los paquetes del sistema operativo y librerías dentro de la imagen y los compara con CVE "
                 "conocidos. Configure las imágenes en «Contenedores».",
    "iac": "Revisa archivos de infraestructura (Terraform, Kubernetes, Helm, Dockerfile…) en busca de "
           "configuraciones inseguras: buckets públicos, contenedores como root, puertos abiertos…",
    "dast": "Navega su sitio como lo haría un atacante y prueba ataques reales. Úselo solo contra ambientes de "
            "desarrollo o QA. Configure la URL y el inicio de sesión en «Web (DAST)».",
    "api": "Llama cada endpoint de su especificación OpenAPI/Postman con datos maliciosos. Úselo solo contra "
           "ambientes de desarrollo o QA.",
}
ENGINE_TIPS = {
    "ZAP + NUCLEI": "Dos motores de código abierto en paralelo: ZAP rastrea el sitio y prueba ataques; Nuclei "
                    "busca miles de vulnerabilidades conocidas. Si ambos encuentran lo mismo, se muestra una sola vez.",
    "PROBELY": "Ciberseguridad asignó una licencia de Probely a esta aplicación. Si no está disponible, se usa "
               "ZAP + Nuclei automáticamente.",
    "TRIVY": "Trivy descarga la imagen directamente del registro (no requiere Docker instalado) y revisa sus paquetes.",
    "CHECKOV + TRIVY": "Dos motores revisan las mismas carpetas. Si ambos marcan el mismo recurso, aparece una vez "
                       "con las descripciones de los dos.",
    "CHECKOV + TRIVY + SONAR": "Checkov, Trivy y SonarQube (local, en este equipo) revisan las mismas carpetas. Si "
                               "varios marcan el mismo recurso, aparece una sola vez con las descripciones de todos.",
}
_TARGET_TAB = {"container": "container", "iac": "iac", "dast": "dast", "api": "api"}
# Errores de Snyk que solo significan «en esta carpeta no hay nada que analizar» (no invalidan el escaneo del lote).
_BENIGN_SNYK = ("could not detect supported target files", "no supported files", "no files to scan",
                "no supported target files")


def _snyk_dirs(targets: list) -> list:
    """Snyk corre con la carpeta como directorio de trabajo: un archivo suelto se analiza desde su carpeta."""
    out = []
    for t in targets:
        d = t if t.is_dir() else t.parent
        if d not in out:
            out.append(d)
    return out


def _label_for(t: Path, targets: list) -> str:
    """Nombre corto de la carpeta para prefijar hallazgos; si dos carpetas se llaman igual, se agrega la de arriba."""
    same = [x for x in targets if x.name == t.name]
    return f"{t.parent.name}/{t.name}" if len(same) > 1 else (t.name or str(t))


def _merge_sca(parts: list, targets: list):
    if len(parts) == 1 and len(targets) == 1:
        return parts[0][1]
    out = []
    for t, data in parts:
        for proj in (data if isinstance(data, list) else [data]):
            if not isinstance(proj, dict):
                continue
            proj = dict(proj)
            name = proj.get("projectName") or proj.get("displayTargetFile") or proj.get("path") or "(proyecto)"
            proj["projectName"] = f"{_label_for(t, targets)} › {name}"
            out.append(proj)
    return out


def _merge_sarif(parts: list, targets: list):
    if len(parts) == 1 and len(targets) == 1:
        return parts[0][1]
    runs = []
    for t, data in parts:
        lbl = _label_for(t, targets)
        for doc in (data if isinstance(data, list) else [data]):
            for run_ in (doc or {}).get("runs") or [] if isinstance(doc, dict) else []:
                run_ = json.loads(json.dumps(run_))
                for res in run_.get("results") or []:
                    for loc in res.get("locations") or []:
                        art = ((loc or {}).get("physicalLocation") or {}).get("artifactLocation")
                        if isinstance(art, dict) and art.get("uri"):
                            art["uri"] = f"{lbl}/{art['uri'].lstrip('/')}"
                runs.append(run_)
    return {"$schema": "https://json.schemastore.org/sarif-2.1.0.json", "version": "2.1.0", "runs": runs}


def _merge_secrets(parts: list, targets: list) -> dict:
    if len(parts) == 1 and len(targets) == 1:
        return parts[0][1]
    merged = {"generated_at": now_human(), "target": "; ".join(str(t) for t, _ in parts), "engine": "",
              "scanned_files": 0, "elapsed": 0.0, "counts": {"critical": 0, "high": 0, "medium": 0, "low": 0},
              "total": 0, "findings": [], "baseline_suppressed": [], "baseline_suppressed_count": 0,
              "targets": [str(t) for t, _ in parts]}
    for t, r in parts:
        lbl = _label_for(t, targets)
        root = str(t if t.is_dir() else t.parent)
        merged["engine"] = merged["engine"] or r.get("engine", "")
        merged["scanned_files"] += int(r.get("scanned_files") or 0)
        merged["elapsed"] = round(merged["elapsed"] + float(r.get("elapsed") or 0), 2)
        for key in ("findings", "baseline_suppressed"):
            for f in r.get(key) or []:
                # «_root» y «_rel» permiten aceptar el hallazgo en la línea base de SU carpeta (la UI muestra «file»).
                merged[key].append({**f, "file": f"{lbl}/{f.get('file', '')}", "_root": root,
                                    "_rel": f.get("file", "")})
    for f in merged["findings"]:
        merged["counts"][f.get("severity", "low")] = merged["counts"].get(f.get("severity", "low"), 0) + 1
    merged["total"] = len(merged["findings"])
    merged["baseline_suppressed_count"] = len(merged["baseline_suppressed"])
    merged["findings"].sort(key=lambda x: (SEV_ORDER.get(x.get("severity"), 9), str(x.get("file"))))
    return merged


def _finish_batch(label: str, parts: list, errors: list, total: int, log) -> None:
    """Decide qué hacer con las carpetas que fallaron. Un solo objetivo conserva el comportamiento de siempre (se
    relanza el error original para el diagnóstico); en un lote, «nada que analizar aquí» no cuenta como falla."""
    if not errors:
        return
    if total == 1 or not parts:
        real = [e for _, e in errors if not any(b in str(e).lower() for b in _BENIGN_SNYK)]
        raise (real or [e for _, e in errors])[0]
    benign = [(t, e) for t, e in errors if any(b in str(e).lower() for b in _BENIGN_SNYK)]
    for t, _ in benign:
        log(f"[{label.lower()}] ℹ {t}: no contiene archivos que {label} pueda analizar — se omite esa carpeta.")
    real = [(t, e) for t, e in errors if (t, e) not in benign]
    if real:
        detail = "; ".join(f"{t.name}: {str(e)[:220]}" for t, e in real)
        err = ss.SnykScanError(f"{label}: {len(real)} de {total} carpeta(s) no se pudieron analizar — {detail}",
                               is_auth=any(getattr(e, "is_auth", False) for _, e in real))
        raise err

STAGE_STATUS = {"running": ("●  Ejecutando…", "warn"), "done": ("✓  Completado", "ok"),
                "failed": ("✕  Falló", "err"), "skipped": ("—  Omitido", "muted")}


class _ScanTabMixin:
    # ── Pantalla «Escanear» ──────────────────────────────────────────────────
    def _build_tab_scan(self, parent):
        pad = tk.Frame(parent, bg=T["bg"])
        pad.pack(fill="both", expand=True)
        self._auth_banner, _ = self._alert(pad, "error", "Snyk no está conectado",
                                           "SCA y SAST requieren una sesión SSO de la organización. " + SNYK_SSO_SHORT,
                                           "Iniciar sesión", self._show_auth_status_popup)
        self._cards_row = tk.Frame(pad, bg=T["bg"])
        # Pantallas angostas (1024–1280 px o escalas altas): 2 tarjetas por fila y columna derecha más estrecha;
        # con 3 por fila los títulos se cortaban y el switch quedaba encima del texto.
        narrow = self.winfo_screenwidth() < px(1300)
        cols = 2 if narrow else 3
        right = tk.Frame(self._cards_row, bg=T["bg"], width=px(280) if narrow else px(340))
        right.pack(side="right", fill="y", padx=(px(12) if narrow else px(20), 0))
        right.pack_propagate(False)
        left_host = tk.Frame(self._cards_row, bg=T["bg"])
        left_host.pack(side="left", fill="both", expand=True)
        left = scroll_frame(left_host)
        self._stage_bar_update, self._stage_status_lbl, self._engine_chips = {}, {}, {}
        for gi, (gtitle, keys) in enumerate(STAGE_GROUPS):
            tk.Label(left, text=gtitle.upper(), font=(FUI, 9, "bold"), bg=T["bg"], fg=T["muted"]).pack(
                anchor="w", pady=(px(14) if gi else 0, px(6)))
            grid = tk.Frame(left, bg=T["bg"])
            grid.pack(fill="x")
            for c in range(cols):
                grid.columnconfigure(c, weight=1, uniform="stage")
            for i, k in enumerate(keys):
                self._make_stage_card(grid, k, STAGE_NAMES[k], i // cols, i % cols)
        prio = self._card(left, "Qué corregir primero", collapsible=False, pady=(px(14), px(6)))
        tip(prio.header, "Los hallazgos de todas las herramientas, unificados y ordenados: severidad, confirmados en "
                         "ejecución, secretos expuestos y los que ya tienen corrección disponible.")
        self._prio_box = tk.Frame(prio, bg=T["panel_bg"])
        self._prio_box.pack(fill="x")
        PillButton(prio.right, "Ver reporte completo", lambda: self._last_report and open_path(self._last_report),
                   icon="open", variant="ghost", size=10).pack(side="right")
        ready = self._card(right, "Preparación", collapsible=False)
        self._ready_box = tk.Frame(ready, bg=T["panel_bg"])
        self._ready_box.pack(fill="x")
        summary = self._card(right, "Último resultado", collapsible=False)
        self._build_summary(summary)
        self._cards_row.pack(fill="both", expand=True)
        for k, state in self._pipe_stage_states.items():
            self._paint_stage_status(k, state)
        self._refresh_engine_cards()

    def _make_stage_card(self, grid, key, name, row, col):
        icon, desc = STAGE_META[key]
        var = self._scan_vars[key]
        p = T["panel_bg"]
        tile = tk.Frame(grid, bg=p, highlightthickness=1, highlightbackground=T["border"], cursor="hand2")
        tile.grid(row=row, column=col, padx=(0, px(10)), pady=(0, px(10)), sticky="nsew")
        inner = tk.Frame(tile, bg=p, padx=px(14), pady=px(12))
        inner.pack(fill="both", expand=True)
        top = tk.Frame(inner, bg=p)
        top.pack(fill="x")
        ic = tk.Label(top, text=ico(icon), font=icon_font(16), bg=p, fg=T["muted"])
        ic.pack(side="left")

        def toggled():
            self._refresh_scan_btn()
            self._persist_scan_stages()

        sw = ToggleSwitch(top, variable=var, command=toggled, bg=p)
        sw.pack(side="right")
        title, sub = STAGE_TITLES.get(key, (name, ""))
        head = tk.Frame(top, bg=p)
        head.pack(side="left", fill="x", expand=True, padx=(px(10), px(6)))
        nm = tk.Label(head, text=title, font=(FUI_TITLE, 12, "bold"), bg=p, fg=T["text"], anchor="w")
        nm.pack(fill="x")
        sb = tk.Label(head, text=sub, font=(FUI, 9, "bold"), bg=p, fg=T["muted"], anchor="w")
        sb.pack(fill="x")
        tip(nm, STAGE_TIPS.get(key))
        tip(sb, STAGE_TIPS.get(key))

        def fit(_e=None):
            # Si la tarjeta es angosta, reduce la letra hasta que el texto quepa sin meterse bajo el switch.
            w = head.winfo_width()
            if w <= 1:
                return
            from tkinter import font as tkfont
            for lbl, txt, fam, sizes in ((nm, title, FUI_TITLE, (12, 11, 10, 9)), (sb, sub, FUI, (9, 8))):
                for size in sizes:
                    if tkfont.Font(family=fam, size=size, weight="bold").measure(txt) <= w:
                        break
                if lbl.cget("font") != str((fam, size, "bold")):
                    lbl.configure(font=(fam, size, "bold"))
        head.bind("<Configure>", fit, add="+")
        ds = autowrap(tk.Label(inner, text=desc, font=(FUI, 10), bg=p, fg=T["muted"], anchor="w", justify="left"),
                      4, 100)
        ds.pack(fill="x")
        ds.pack_configure(pady=(px(8), 0))
        foot = tk.Frame(inner, bg=p)
        foot.pack(fill="x", pady=(px(8), px(4)))
        st = tk.Label(foot, text="", font=(FUI, 9, "bold"), bg=p, fg=T["muted"], anchor="w")
        st.pack(side="left")
        chip = tk.Label(foot, text="", font=(FUI, 8, "bold"), bg=T["surface3"], fg=T["muted"], padx=px(6), pady=px(1))
        if key in ("dast", "api", "container", "iac"):
            chip.pack(side="right")
            self._engine_chips[key] = chip
            tip(chip, lambda c=chip: ENGINE_TIPS.get(c.cget("text"), ""))
        bar = tk.Canvas(inner, height=px(4), highlightthickness=0, bd=0, bg=p)
        bar.pack(fill="x")
        self._stage_bar_update[key] = progress_strip(bar, px(4))
        self._stage_status_lbl[key] = st
        parts = [tile, inner, top, ic, head, nm, sb, ds, foot, st, bar]
        hover = {"on": False}

        def restyle(*_):
            if not tile.winfo_exists():
                return
            on = bool(var.get())
            bg = T["accent_soft"] if on else T["panel_bg"]
            tile.configure(highlightbackground=T["accent"] if on else T["border_strong"] if hover["on"] else T["border"])
            for w in parts:
                w.configure(bg=bg)
            ic.configure(fg=T["accent"] if on else T["muted"])
            sw.set_bg(bg)

        def click(_e=None):
            var.set(not var.get())
            toggled()

        def set_hover(on):
            hover["on"] = on
            restyle()

        tid = var.trace_add("write", restyle)
        tile.bind("<Destroy>", lambda e: e.widget is tile and var.trace_remove("write", tid), add="+")
        for w in parts:
            w.bind("<Button-1>", click)
            w.bind("<Enter>", lambda _e: set_hover(True))
            w.bind("<Leave>", lambda _e: set_hover(False))
        restyle()

    def _paint_stage_status(self, key, state):
        lbl = getattr(self, "_stage_status_lbl", {}).get(key)
        if lbl is None or not lbl.winfo_exists():
            return
        text, role = STAGE_STATUS.get(state, ("", "muted"))
        lbl.configure(text=text, fg=T[role])

    def _build_summary(self, parent):
        grid = tk.Frame(parent, bg=T["panel_bg"])
        grid.pack(fill="x")
        self._sum_vals = {}
        for i, (k, label) in enumerate((("critical", "Críticas"), ("high", "Altas"), ("medium", "Medias"),
                                         ("low", "Bajas"))):
            grid.columnconfigure(i, weight=1, uniform="sum")
            cell = tk.Frame(grid, bg=T["surface2"])
            cell.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else px(6), 0))
            v = tk.Label(cell, text="—", font=(FUI_TITLE, 17, "bold"), bg=T["surface2"], fg=T[f"sev_{k}"])
            v.pack(pady=(px(8), 0))
            tk.Label(cell, text=label, font=(FUI, 9), bg=T["surface2"], fg=T["muted"]).pack(pady=(0, px(8)))
            self._sum_vals[k] = v
        self._sum_meta = tk.Label(parent, text="", font=(FUI, 10), bg=T["panel_bg"], fg=T["muted"], anchor="w",
                                  justify="left", wraplength=px(290))
        self._sum_meta.pack(fill="x", pady=(px(12), 0))
        self._sum_open = self._btn(parent, "Abrir último reporte", lambda: self._last_report and open_path(
            self._last_report), icon="document")
        self._sum_open.pack(anchor="w", pady=(px(12), 0))

    def _refresh_summary(self):
        vals = getattr(self, "_sum_vals", None)
        if not vals or not next(iter(vals.values())).winfo_exists():
            return
        ctx, app = self._last_context, self._active_app
        counts, meta = None, "Aún no hay resultados en esta sesión."
        if ctx:
            counts = ctx.get("counts") or {}
            meta = (f"{ctx.get('generated_at', '')}  ·  {(ctx.get('scan_mode') or '').upper()}  ·  "
                    f"{ctx.get('total', 0)} hallazgo(s)" + ("  ·  INCOMPLETO" if ctx.get("incomplete") else ""))
        elif app and app.get("last_scan"):
            counts = {k: app.get(f"vuln_{k}", 0) for k in vals}
            meta = f"{app.get('name')}  ·  {str(app.get('last_scan'))[:16].replace('T', ' ')}  ·  " \
                   f"{(app.get('last_mode') or '').upper()}"
        for k, lbl in vals.items():
            lbl.configure(text=str(counts.get(k, 0)) if counts is not None else "—")
        self._sum_meta.configure(text=meta)
        self._sum_open.configure(state="normal" if self._last_report else "disabled")
        self._render_priorities()

    def _render_priorities(self):
        box = getattr(self, "_prio_box", None)
        if box is None or not box.winfo_exists():
            return
        for w in box.winfo_children():
            w.destroy()
        p = T["panel_bg"]
        items = fz.priorities(self._last_context, 6) if self._last_context else []
        if not items:
            msg = ("Sin hallazgos críticos, altos ni medios en el último escaneo. ✓" if self._last_context else
                   "Ejecute un escaneo: aquí verá lo más importante que corregir, sin importar qué herramienta lo "
                   "encontró.")
            tk.Label(box, text=msg, font=(FUI, 10), bg=p, fg=T["muted"], anchor="w", justify="left").pack(fill="x")
            return
        kind_es = {"sca": "Dependencia", "code": "Código", "secrets": "Secreto", "container": "Contenedor",
                   "iac": "IaC", "dast": "Web", "api": "API"}
        for i, u in enumerate(items):
            row = tk.Frame(box, bg=p)
            row.pack(fill="x", pady=(0 if not i else px(8), 0))
            if i:
                tk.Frame(box, bg=T["border"], height=1).pack(fill="x", before=row, pady=(px(8), 0))
            fg, bg = SEV_ROLES.get(u["severity"], SEV_ROLES["low"])
            left = tk.Frame(row, bg=p, width=px(84))
            left.pack(side="left", fill="y")
            left.pack_propagate(False)
            pill_label(left, SEV_ES.get(u["severity"], u["severity"]), fg, bg).pack(anchor="w")
            tk.Label(left, text=kind_es.get(u["kind"], u["kind"]).upper(), font=(FUI, 8, "bold"), bg=p,
                     fg=T["muted"]).pack(anchor="w", pady=(px(4), 0))
            col = tk.Frame(row, bg=p)
            col.pack(side="left", fill="x", expand=True)
            autowrap(tk.Label(col, text=u["title"], font=(FUI, 10, "bold"), bg=p, fg=T["text"], anchor="w",
                              justify="left"), 8, 160).pack(fill="x")
            tk.Label(col, text=middle_ellipsis(u["location"], 80), font=(FMONO, 9), bg=p, fg=T["muted"],
                     anchor="w").pack(fill="x")
            if u["fix"]:
                autowrap(tk.Label(col, text="→ " + u["fix"][:220], font=(FUI, 9), bg=p, fg=T["ok"], anchor="w",
                                  justify="left"), 8, 160).pack(fill="x", pady=(px(2), 0))
            tags = tk.Frame(row, bg=p)
            tags.pack(side="right", anchor="n")
            if u.get("confirmed"):
                tip(pill_label(tags, "Confirmado en ejecución", "select_fg", "select", 8),
                    "El mismo tipo de falla (CWE) apareció en el código y también en la aplicación en ejecución: "
                    "es explotable. Corríjalo primero.").pack(anchor="e", pady=(0, px(3)))
            tk.Label(tags, text=" · ".join(u["detected_by"][:3]), font=(FUI, 8), bg=p, fg=T["muted"]).pack(anchor="e")

    def _readiness(self) -> list:
        sel = {k for k, v in self._scan_vars.items() if v.get()}
        out = [("ok" if sel else "fail", "Al menos una etapa seleccionada", None)]
        if {"sca", "code"} & sel:
            ok = self._snyk_auth_ok()
            out.append(("ok" if ok else "fail", "Sesión SSO de Snyk activa" if ok else "Inicie sesión en Snyk (SSO)",
                        self._show_auth_status_popup, "Iniciar sesión",
                        "SCA y SAST usan la organización de Snyk del banco. " + SNYK_SSO_WARNING))
        if set(STATIC_STAGES) & sel:
            ok = self._has_static_target()
            out.append(("ok" if ok else "fail", "Carpeta del repositorio" if ok else
                        "Agregue la carpeta del repositorio", lambda: self._show_tab("static"), "Agregar",
                        "La carpeta raíz de su proyecto (donde está el package.json, pom.xml o .sln)."))
        if "container" in sel:
            n = len(self._container_sources_clean())
            out.append(("ok" if n else "fail", f"{n} imagen(es) a analizar" if n else "Agregue una imagen, .tar o SBOM",
                        lambda: self._show_tab("container"), "Agregar"))
        if "iac" in sel:
            paths = self._iac_paths_effective()
            out.append(("ok" if paths else "fail", "Carpeta de IaC" + (" (la del repositorio)" if paths and not
                                                                      self._iac_paths else "") if paths else
                        "Agregue la carpeta de IaC", lambda: self._show_tab("iac"), "Agregar"))
        if "dast" in sel:
            url = getattr(self, "_dast_url_var", None)
            ok = bool(url and url.get().strip() not in ("", "https://", "http://"))
            out.append(("ok" if ok else "fail", "URL de la aplicación web" if ok else "Indique la URL de la aplicación web",
                        lambda: self._show_tab("dast"), "Configurar"))
        if "api" in sel:
            spec, base = getattr(self, "_api_spec_var", None), getattr(self, "_api_base_var", None)
            ok = bool((spec and spec.get().strip()) or (base and base.get().strip()))
            out.append(("ok" if ok else "fail", "Especificación o URL del API" if ok else
                        "Indique la especificación o URL del API", lambda: self._show_tab("api"), "Configurar"))
        if {"dast", "api", "container", "iac", "secrets"} & sel:
            engine, _ = admin_policy.engine_label(self._active_app)
            if {"dast", "api"} & sel and engine == "probely":
                out.append(("ok", "Web y API con Probely (asignado por Ciberseguridad)", None, None,
                            "Si Probely no está disponible se usa ZAP + Nuclei automáticamente."))
            cache_list = getattr(self, "_engine_cache", None)
            cache = {st.key: st for st in cache_list or []}
            need = {t for k in sel for t in tm.stage_tools(k) if not (engine == "probely" and k in ("dast", "api"))}
            need |= {d for t in list(need) for d in tm.NEEDS.get(t, ())}
            missing = [tm.LABELS[t] for t in sorted(need) if t in cache and not cache[t].installed]
            names = ", ".join(tm.LABELS[t] for t in sorted(need) if t != "jre")
            if need and cache_list is None:
                out.append(("info", "Verificando motores de escaneo…", None))
            elif missing:
                out.append(("info", "Se descargará al iniciar: " + ", ".join(missing), self._show_engines_popup,
                            "Preparar", "La primera vez se descargan (verificados con SHA-256) y tardan unos minutos. "
                            "Pulse «Preparar» para hacerlo ahora y que el escaneo empiece de inmediato."))
            elif need:
                out.append(("ok", f"Motores listos: {names}", None))
            if engine == "probely" and self._is_admin and self._probely_auth_status != "auth":
                out.append(("warn", "Clave de Probely sin validar", lambda: self._show_tab("admin")))
            if "iac" in sel and self._sonar_on():
                out.append(("ok", "IaC también con SonarQube (local, sin cuenta)", lambda: self._show_tab("iac"),
                            "Cambiar", "SonarQube corre en este equipo (127.0.0.1): la primera vez se descarga y tarda "
                            "2–4 min en arrancar; después queda listo mientras el programa esté abierto. Se puede "
                            "desactivar en IaC → Opciones."))
        static_n = len(self._static_targets()) if set(STATIC_STAGES) & sel else 0
        if static_n > 1:
            out.append(("ok", f"{static_n} carpetas — un solo reporte consolidado", lambda: self._show_tab("static"),
                        "Ver", "SCA, SAST y Secretos se ejecutan en cada carpeta de la lista de «Código» y los "
                        "resultados se unen en un reporte y un ticket."))
        snow = getattr(self, "_snow_state", "none")
        snow_help = ("Cada hallazgo alto o crítico crea o actualiza un ticket en ServiceNow de forma automática. "
                     "El programa usa la cuenta de integración de Ciberseguridad y el ticket queda a su nombre "
                     "(solicitante: su usuario de Windows). No necesita capturar credenciales.")
        level, text, action = {
            "ok": ("ok", "Tickets de ServiceNow automáticos", None),
            "checking": ("info", "Verificando la conexión con ServiceNow…", None),
            "invalid": ("warn", "ServiceNow rechazó la cuenta de integración — avise a Ciberseguridad", "Detalle"),
            "unverified": ("warn", "No se pudo conectar con ServiceNow — los tickets pueden fallar", "Reintentar"),
        }.get(snow, ("warn", "Cuenta de integración de ServiceNow no disponible — avise a Ciberseguridad", "Detalle"))
        detail = getattr(self, "_snow_detail", "")
        if getattr(self, "_snow_test_mode", False):
            level, text, action = "warn", "ServiceNow en MODO PRUEBA — no se crearán tickets", "Cambiar"
            detail = "Activado en Administración → ServiceNow (solo en este equipo)."
        out.append((level, text, (lambda: self._show_tab("admin")) if getattr(self, "_snow_test_mode", False) and
                    self._is_admin else self._show_servicenow_setup if action else None, action,
                    f"{detail}\n\n{snow_help}" if detail and (snow in ("invalid", "unverified", "ok") or
                                                             getattr(self, "_snow_test_mode", False)) else snow_help))
        app_ok = bool(self._active_app and self._active_app.get("name"))
        out.append(("ok" if app_ok else "info", f"Aplicación: {self._active_app['name']}" if app_ok else
                    "Sin aplicación — los resultados no se catalogan", lambda: self._show_tab("apps"), "Elegir",
                    "La aplicación agrupa los reportes, el historial y la tendencia. Sin ella, el reporte queda en "
                    "la carpeta «_unscoped»."))
        return out

    def _refresh_engine_cards(self):
        chips = getattr(self, "_engine_chips", {})
        engine, _ = admin_policy.engine_label(self._active_app)
        names = {"dast": "PROBELY" if engine == "probely" else "ZAP + NUCLEI",
                 "api": "PROBELY" if engine == "probely" else "ZAP + NUCLEI", "container": "TRIVY",
                 "iac": "CHECKOV + TRIVY + SONAR" if self._sonar_on() else "CHECKOV + TRIVY"}
        for k, chip in chips.items():
            if chip.winfo_exists():
                chip.configure(text=names[k], fg=T["border2"] if engine == "probely" and k in ("dast", "api") else T["muted"])
        if hasattr(self, "_refresh_engine_badge_text"):
            self._refresh_engine_badge_text()

    def _render_readiness(self, items) -> None:
        box = getattr(self, "_ready_box", None)
        if box is None or not box.winfo_exists():
            return
        for w in box.winfo_children():
            w.destroy()
        p = T["panel_bg"]
        glyphs = {"ok": ("check", "ok"), "fail": ("close", "err"), "warn": ("warn", "warn"), "info": ("info", "muted")}
        for item in items:
            level, text, fix, action, help_ = (tuple(item) + (None, None))[:5]
            row = tk.Frame(box, bg=p)
            row.pack(fill="x", pady=px(4))
            g, role = glyphs[level]
            tk.Label(row, text=ico(g), font=icon_font(10), bg=p, fg=T[role], width=2).pack(side="left", anchor="n",
                                                                                         pady=(px(2), 0))
            # El enlace se empaqueta ANTES que el texto: así conserva su ancho y el texto se ajusta (antes, en
            # pantallas angostas, «Iniciar sesión», «Agregar»… quedaban cortados).
            if fix and (level != "ok" or action == "Cambiar"):
                link = tk.Label(row, text=action or "Resolver", font=(FUI, 10, "bold"), bg=p, fg=T["border2"],
                                cursor="hand2")
                link.pack(side="right", anchor="n", padx=(px(6), 0))
                link.bind("<Button-1>", lambda _e, f=fix: f())
            narrow = self.winfo_screenwidth() < px(1300)
            lbl = tk.Label(row, text=text, font=(FUI, 10), bg=p, fg=T["muted"] if level in ("ok", "info") else T["text"],
                           anchor="w", justify="left", wraplength=px(150) if narrow else px(200))
            lbl.pack(side="left", fill="x", expand=True)
            tip(lbl, help_)

    # ── Progreso ─────────────────────────────────────────────────────────────
    def _paint_card(self, key, pct, color=None):
        if fn := getattr(self, "_stage_bar_update", {}).get(key):
            fn(pct, color or (T["err"] if self._pipe_stage_states.get(key) == "failed" else progress_color()))

    def _pipeline_reset(self):
        self._pipe_stage_states, self._pipe_card_pcts = {}, {}
        self._pipe_progress_pct = 0.0
        self._static_route = (0, 1)
        for k in self.PROGRESS_TABS:
            self._set_ribbon_tab_progress(k, 0.0)
        for fn in self._stage_bar_update.values():
            fn(0.0, T["border"])
        for k in getattr(self, "_stage_status_lbl", {}):
            self._paint_stage_status(k, None)

    def _static_route_start(self, idx, total, keys):
        self._static_route = (idx, total)
        for k in keys:
            self._pipe_card_pcts[k] = 0.0
        self._recompute_progress()

    def _on_stage(self, key: str, state: str):
        self._pipe_stage_states[key] = state
        self._paint_stage_status(key, state)
        if state == "running":
            if key in ("sca", "code"):
                self._pulse(key)
        else:
            self._pipe_card_pcts[key] = 1.0 if state in ("done", "failed") else 0.0
            self._paint_card(key, self._pipe_card_pcts[key])
        self._recompute_progress()

    def _pulse(self, key):
        def tick():
            if self._pipe_stage_states.get(key) != "running":
                return
            self._pipe_card_pcts[key] = min(self._pipe_card_pcts.get(key, 0.0) + 0.015, 0.90)
            self._paint_card(key, self._pipe_card_pcts[key])
            self._recompute_progress()
            self.after(400, tick)
        self.after(400, tick)

    def _update_card_progress(self, key: str, done: int, total: int):
        if total > 0:
            self._pipe_card_pcts[key] = min(done / total, 0.99)
            self._paint_card(key, self._pipe_card_pcts[key])
            self._recompute_progress()

    def _update_play_ring(self, pct: float) -> None:
        self._play_ring_pct = max(0.0, min(1.0, pct))
        self._paint_cta()

    def _recompute_progress(self):
        sel = {k for k, v in self._scan_vars.items() if v.get()}
        active = [k for k in self._pipe_stage_states if k in sel]

        def lane(keys):
            ks = [k for k in active if k in keys]
            return sum(self._pipe_card_pcts.get(k, 0.0) for k in ks) / len(ks) if ks else 0.0

        general = lane(STAGES)
        self._pipe_progress_pct = general
        self._update_play_ring(general)
        idx, total = self._static_route
        st = lane(STATIC_STAGES)
        self._set_ribbon_tab_progress("scan", general)
        self._set_ribbon_tab_progress("static", (idx + st) / total if total > 1 else st)
        self._set_ribbon_tab_progress("dast", lane({"dast"}))
        self._set_ribbon_tab_progress("api", lane({"api"}))
        self._set_ribbon_tab_progress("container", lane({"container"}))
        self._set_ribbon_tab_progress("iac", lane({"iac"}))

    def _sonar_on(self) -> bool:
        var = getattr(self, "_iac_sonar_var", None)
        return bool(var is not None and var.get())

    def _has_static_target(self) -> bool:
        return bool(self._static_paths) or bool(self._target_var.get().strip())

    def _static_targets(self) -> list:
        """TODAS las rutas de la lista «Código» que existen en disco (antes el pipeline solo tomaba la primera)."""
        raw = [p for p in self._static_paths if p.strip()] or (
            [self._target_var.get().strip()] if self._target_var.get().strip() else [])
        out = []
        for p in raw:
            try:
                rp = Path(p).resolve()
            except Exception:
                continue
            if rp.exists() and rp not in out:
                out.append(rp)
        return out

    def _snyk_auth_ok(self) -> bool:
        a = self._checks.get("auth")
        return bool(a and a.ok)

    def _refresh_scan_btn(self):
        items = self._readiness()
        self._play_ready = not any(it[0] == "fail" for it in items)
        busy = self._any_busy()
        self._render_readiness(items)
        self._refresh_summary()
        self._update_play_ring(self._play_ring_pct)
        auth_ok = self._snyk_auth_ok()
        for b in getattr(self, "_static_run_btns", []):
            if b.winfo_exists():
                self._set_icon_btn_enabled(b, self._has_static_target() and auth_ok and not busy)

    def _refresh_auth_banner(self, auth_ok: bool) -> None:
        b = getattr(self, "_auth_banner", None)
        if b is None or not b.winfo_exists():
            return
        if auth_ok:
            b.pack_forget()
        elif not b.winfo_ismapped():
            b.pack(fill="x", pady=(0, px(12)), before=self._cards_row)

    # ── Autenticación Snyk ───────────────────────────────────────────────────
    def _recheck(self):
        self._ui(self._apply_checks, {"auth": ss.check_auth()})

    def _apply_checks(self, results: dict):
        self._checks = results
        res = results.get("auth")
        ok = bool(res and res.ok)
        if ok and not any(k in (res.detail or "").lower() for k in ("sso", "oauth")):
            ok = False
            self._log_line("[auth] ⚠ Se detectó un token de API pero NO una sesión SSO/OAuth. Haga clic en «Snyk» "
                           "(arriba a la derecha) → Re-iniciar sesión y, en la ventana de Snyk, elija 'Iniciar sesión "
                           "con SSO'. Un token simple no basta para escanear en la organización.")
            self._checks = {"auth": ss.CheckResult("Snyk auth", False, "⚠ Token detectado — se requiere SSO", True)}
        self._set_key_status("auth" if ok else "unauth")
        self._refresh_auth_banner(ok)
        self._refresh_scan_btn()

    def _prompt_relogin(self):
        if self._relogin_prompted:
            return
        self._relogin_prompted = True
        self._set_status("Sesión de Snyk expirada — haga clic en «Snyk» → Re-iniciar sesión")
        self._log_line("[auth] ⚠ Snyk rechazó la credencial guardada (expirada o inválida). Haga clic en «Snyk» "
                       "(arriba a la derecha) → vuelva a iniciar sesión con el SSO de su organización y repita el escaneo.")
        self._set_key_status("unauth")

    def _clean_reinstall_snyk(self):
        if self._any_busy():
            return self._emit_log("[ocupado] se ignora la reinstalación limpia — otra operación en curso")
        self._show_confirm_popup(
            "¿Reinstalar Snyk desde cero?",
            "Esto desinstala la CLI de Snyk actual, borra su configuración local (incluida la sesión guardada) y "
            "descarga la versión más reciente. Tendrá que volver a iniciar sesión SSO antes de escanear.\n\nNo borra "
            "sus reportes ni las aplicaciones configuradas.",
            on_yes=lambda: self._run_async(self._do_clean_reinstall_snyk, "reinstalación limpia de Snyk"),
            yes_label="🧹  Reinstalar", no_label="Cancelar")

    def _do_clean_reinstall_snyk(self):
        ok = ss.reinstall_snyk_clean(self._emit_log)
        self._relogin_prompted = False
        self._ui(self._set_key_status, "unauth")
        self._emit_log("[snyk] reinstalación limpia completa — inicie sesión antes de escanear." if ok else
                       "[snyk] la reinstalación limpia no terminó bien — revise el registro anterior.")
        self._recheck()

    def _do_login(self):
        # Ya NO se mata un `snyk auth` en curso: la pestaña que el usuario tiene abierta en el navegador pertenece a ese
        # proceso; si se mata, al terminar el SSO el navegador regresa a 127.0.0.1 y no hay nadie escuchando → error.
        self._relogin_prompted = False
        self._ui(self._show_snyk_login_popup)

    def _show_snyk_login_popup(self):
        popup = self._popup("Iniciar sesión en Snyk (SSO)")
        raw_close = popup.close
        st = {"closed": False, "ready": False, "launched": False, "spin": None, "i": 0}

        def close(success=False):
            if st["closed"]:
                return
            st["closed"] = True
            self._login_popup_close = None
            raw_close()
            if not success:
                self._run_async(self._recheck, "verificación tras inicio de sesión")

        popup.close = close
        self._login_popup_close = lambda: close(True)
        popup._win.bind("<Escape>", lambda _e: close())
        self._popup_hdr(popup, "Iniciar sesión en Snyk", subtitle="Autenticación con el SSO de su organización",
                        icon_image=self._load_status_icon("snyk"))
        bg = T["bg"]
        body = tk.Frame(popup, bg=bg, padx=px(24), pady=px(4))
        body.pack(fill="both", expand=True)
        warn, _ = self._alert(body, "error", SNYK_SSO_TITLE, SNYK_SSO_WARNING)
        warn.pack(fill="x", pady=(0, px(12)))
        self._limit_wrap(warn, px(560))
        steps = (("Se abrirá su navegador en unos segundos.", None),
                 ("Haga clic en «Log in with SSO».", "NO use el formulario de correo y contraseña, ni Google, GitHub o "
                                                     "Microsoft."),
                 ("Ya dentro de la pantalla de SSO, escriba su correo corporativo o el dominio bancobase.com.",
                  "Lo enviará al inicio de sesión del banco; entre ahí con su usuario de red."),
                 ("Si el navegador muestra «Grant app access», revise el correo que aparece.",
                  "Si es su correo @bancobase.com, pulse «Grant app access»: ya entró con SSO. Si es otra cuenta, "
                  "abra app.snyk.io, cierre sesión ahí (Log out) y pulse «Abrir navegador de nuevo»."),
                 ("Complete la autenticación y regrese aquí.", "Esta ventana se cierra sola al terminar."))
        for i, (title, note) in enumerate(steps, 1):
            row = tk.Frame(body, bg=bg)
            row.pack(fill="x", pady=px(6))
            d = px(26)
            c = tk.Canvas(row, width=d, height=d, bg=bg, highlightthickness=0, bd=0)
            c.create_oval(0, 0, d - 1, d - 1, fill=T["accent_soft"], outline="")
            c.create_text(d // 2, d // 2, text=str(i), font=(FUI, 10, "bold"), fill=T["text"])
            c.pack(side="left", anchor="n", padx=(0, px(12)))
            col = tk.Frame(row, bg=bg)
            col.pack(side="left", fill="x", expand=True)
            tk.Label(col, text=title, font=(FUI, 11, "bold" if i == 2 else "normal"), bg=bg, fg=T["text"],
                     anchor="w").pack(fill="x")
            if note:
                tk.Label(col, text=note, font=(FUI, 10), bg=bg, fg=T["muted"], anchor="w").pack(fill="x")

        def spin():
            if st["closed"] or st["launched"]:
                return
            st["i"] += 1
            status.config(text=f"{'◐◓◑◒'[st['i'] % 4]}  Preparando la sesión SSO, por favor espere…", fg=T["muted"])
            st["spin"] = popup._win.after(160, spin)

        def launch():
            st["launched"] = True
            status.config(text="Navegador abierto — esperando que complete el inicio de sesión…", fg=T["muted"])
            self._spawn_snyk_auth()

        def prepare():
            try:
                self._prepare_snyk_cli()
            finally:
                st["ready"] = True
                self._ui(lambda: not st["closed"] and not st["launched"] and launch())

        def reopen():
            if st["ready"]:
                st["launched"] = True
                status.config(text="Navegador abierto — esperando que complete el inicio de sesión…", fg=T["muted"])
                self._reopen_or_spawn_auth()

        _, status = self._popup_foot(popup, ("Cerrar", close), ("🌐  Abrir navegador de nuevo", reopen),
                                     with_status=True)
        spin()
        threading.Thread(target=prepare, daemon=True).start()

    def _prepare_snyk_cli(self):
        try:
            ss.setup_proxy_tls_env(self._emit_log)
            if not which("snyk") or not ss.ensure_snyk_ready(self._emit_log):
                self._emit_log("[auth] la CLI de Snyk aún no se puede ejecutar y no se pudo reparar automáticamente. "
                               "Si su red usa un proxy con inspección TLS, configure NODE_EXTRA_CA_CERTS con el "
                               "certificado raíz (.pem) de su empresa e intente de nuevo.")
            else:
                ss.clear_snyk_credentials(self._emit_log)
                self._ui(self._set_status, "Abriendo navegador para Snyk SSO…")
        except Exception as e:
            self._emit_log(f"[auth] error al preparar la CLI: {e!r}")

    def _auth_alive(self) -> bool:
        p = self._auth_proc
        return p is not None and p.poll() is None

    def _spawn_snyk_auth(self):
        # Si ya hay un `snyk auth` vivo se reutiliza (no se mata): su servidor local en 127.0.0.1 es el único que puede
        # recibir el regreso del SSO de la pestaña que el usuario ya tiene abierta.
        if self._auth_alive():
            return self._reopen_or_spawn_auth()
        try:
            self._auth_lines = queue.Queue()
            self._auth_url = None
            self._auth_grace_until = 0.0
            self._auth_ok_logged = False
            self._auth_proc = proc = ss.start_snyk_auth(self._emit_log)
            self._auth_deadline = time.time() + AUTH_POLL_TIMEOUT
        except Exception as e:
            return self._emit_log(f"[auth] no se pudo iniciar snyk auth: {e!r}")

        def reader():
            try:
                for line in iter(proc.stdout.readline, ""):
                    if m := re.search(r"https://\S+/oauth2/authorize\S+|https://\S+/login\?token=\S+", line):
                        self._auth_url = m.group(0)
                    self._auth_lines.put(line)
            except Exception:
                pass
        threading.Thread(target=reader, daemon=True).start()

    def _reopen_or_spawn_auth(self):
        """«Abrir navegador de nuevo»: si el `snyk auth` sigue vivo, reabre EXACTAMENTE la URL que imprimió la propia CLI
        (misma sesión, mismo servidor local); solo si ya terminó se lanza un `snyk auth` nuevo (que abre el navegador
        por sí mismo, como siempre)."""
        if not self._auth_alive():
            return self._spawn_snyk_auth()
        url = getattr(self, "_auth_url", None)
        if not url:
            return self._emit_log("[auth] snyk auth sigue iniciándose — el navegador se abrirá en unos segundos.")
        self._emit_log("[auth] reabriendo la página de inicio de sesión de la sesión en curso de snyk auth…")
        try:
            if os.name == "nt":
                os.startfile(url)
            else:
                import webbrowser
                webbrowser.open(url)
        except Exception as e:
            self._emit_log(f"[auth] no se pudo abrir el navegador ({e!r}); copie esta URL en su navegador: {url}")

    def _begin_snyk_auth(self):
        self._relogin_prompted = False
        self._prepare_snyk_cli()
        self._spawn_snyk_auth()

    def _show_auth_status_popup(self):
        res = self._checks.get("auth")
        ok = bool(res and res.ok)
        if ok:
            icon, title, detail = "✓", "Autenticado", res.detail or "Sesión SSO activa."
        else:
            icon, title = "✕", "Sin autenticación"
            detail = (res.detail if res else None) or "No se detectó una sesión de Snyk."
        popup = self._popup("Autenticación Snyk")
        self._popup_hdr(popup, "Autenticación Snyk", subtitle="Estado de la sesión SSO",
                        icon_image=self._load_status_icon("snyk"))
        self._centered_msg(popup, icon, T["ok"] if ok else T["err"], title, detail, T["text"])
        note = tk.Frame(popup, bg=T["bg"], padx=px(24), pady=px(4))
        note.pack(fill="x")
        warn, _ = self._alert(note, "warn" if ok else "error", SNYK_SSO_TITLE, SNYK_SSO_WARNING + (
            "\n\nSi un escaneo dice que no tiene acceso a la organización, probablemente entró con su correo: pulse "
            "«Re-iniciar sesión» y use SSO." if ok else ""))
        warn.pack(fill="x", pady=(0, px(8)))
        self._limit_wrap(warn, px(560))

        def go(fn, label):
            popup.close()
            self._set_key_status("checking")
            self._run_async(fn, label)
        self._popup_foot(popup,
                         ("🧹  Reinstalar (limpio)", lambda: (popup.close(), self._clean_reinstall_snyk())),
                         ("🔄  Verificar", lambda: go(self._recheck, "verificación de entorno")),
                         ("🔁  Re-iniciar sesión" if ok else "🔑  Iniciar sesión SSO",
                          lambda: go(self._do_login, "snyk auth")),
                         ("Cerrar", popup.close),
                         primary=None if ok else "🔑  Iniciar sesión SSO")

    def _kick_auth_check(self):
        if self._auth_check_inflight:
            return
        self._auth_check_inflight = True

        def bg():
            try:
                res = ss.check_auth()
            except Exception:
                res = None
            self._ui(self._on_auth_check, res)
        threading.Thread(target=bg, daemon=True).start()

    def _on_auth_check(self, res):
        self._auth_check_inflight = False
        if res is None:
            self._set_key_status("unauth")
        else:
            if res.ok and not getattr(self, "_auth_ok_logged", False):
                self._log_line("[auth] autenticado.")
                if self._auth_alive():
                    # NO se mata `snyk auth` aquí. La CLI guarda el token ANTES de contestarle al navegador en
                    # 127.0.0.1; leer el archivo de configuración es casi instantáneo, así que matarla en este punto
                    # dejaba al navegador sin respuesta (página de error 127.0.0.1). Se le da tiempo de terminar sola.
                    self._auth_ok_logged = True
                    self._auth_grace_until = time.time() + AUTH_EXIT_GRACE
                ss.reset_org_cache()
                if callable(self._login_popup_close):
                    self._login_popup_close()
            self._apply_checks({"auth": res})
        self._set_idle_status()

    def _tick_auth_poll(self):
        proc = self._auth_proc
        while True:
            try:
                self._log_line(self._auth_lines.get_nowait().rstrip())
            except queue.Empty:
                break
        now = time.time()
        grace = getattr(self, "_auth_grace_until", 0.0)
        if now >= self._next_auth_check and not grace:
            self._next_auth_check = now + AUTH_POLL_INTERVAL
            self._kick_auth_check()
        if proc.poll() is not None:
            self._log_line(f"[auth] snyk auth terminó ({proc.returncode})")
            if proc.returncode and not grace:
                self._log_line("[auth] el intento de inicio de sesión no se completó (tiempo agotado o cancelado). Si el "
                               "navegador quedó en una página de 127.0.0.1, ciérrela y pulse «Abrir navegador de "
                               "nuevo» para empezar un intento nuevo.")
            self._auth_proc = None
            self._auth_grace_until = 0.0
            self._auth_check_inflight = False
            self._kick_auth_check()
        elif grace and now > grace:
            self._log_line("[auth] snyk auth no terminó por sí solo tras autenticarse — se cierra.")
            kill_process_tree(proc)
            self._auth_proc = None
            self._auth_grace_until = 0.0
        elif now > self._auth_deadline:
            self._log_line("[auth] tiempo de espera agotado — cancelando.")
            kill_process_tree(proc)
            self._auth_proc = None

    # ── Ejecución del pipeline ───────────────────────────────────────────────
    def _start_scan(self):
        sel = {k for k, v in self._scan_vars.items() if v.get()}
        if not (self._active_app and self._active_app.get("name")) and sel & set(STATIC_STAGES) and sel & {"dast", "api"} \
                and not self._has_static_target():
            dropped = [k for k in STATIC_STAGES if k in sel]
            for k in dropped:
                self._scan_vars[k].set(False)
            self._persist_scan_stages()
            self._refresh_scan_btn()
            names = ", ".join(STAGE_NAMES[k] for k in dropped)
            self._emit_log(f"[escaneo] {names} deseleccionado(s) — necesitan una aplicación cargada (ruta de objetivo) "
                           "y no hay ninguna activa. Se continúa solo con las etapas web/API seleccionadas.")
            self._show_info_popup("Etapas estáticas omitidas",
                f"{names} necesitan una aplicación cargada (ruta de objetivo) y no hay ninguna activa, así que se "
                "deseleccionaron.\n\nSe continúa solo con las etapas web/API seleccionadas, si cumplen sus propios "
                "requisitos.")
            return self._run_scan_pipeline()
        self._confirm_scan_without_app(self._run_scan_pipeline)

    def _run_scan_pipeline(self):
        self._run_async(self._do_scan, "escaneo completo de pipeline")

    def _request_cancel(self):
        if not self._any_busy():
            return self._emit_log("[escaneo] nada que cancelar.")
        self._show_confirm_popup("¿Detener escaneo?",
                                 "Hay un escaneo en ejecución. Detenerlo descartará los resultados que aún no se "
                                 "hayan guardado.",
                                 on_yes=self._do_cancel, yes_label="■  Detener escaneo", no_label="Continuar")

    def _do_cancel(self):
        if not self._any_busy():
            return
        if self._busy:
            self._cancel_evt.set()
        if self._static_busy:
            self._static_cancel_evt.set()
        self._emit_log("[escaneo] cancelación solicitada…")
        self._set_status("Cancelando…")
        audit(self._reports_var.get(), "scan_cancel_requested", actor=self._user, log=self._emit_log)

    def _web_runner(self, kind: str, cfg):
        """Elige el motor web/API: Probely solo si Ciberseguridad asignó la aplicación; si no, ZAP + Nuclei."""
        from oss_web_scanner import run_oss_api, run_oss_dast
        oss = run_oss_dast if kind == "dast" else run_oss_api
        engine, _ = admin_policy.engine_label(self._active_app)
        if engine != "probely":
            return oss

        def probely_then_fallback(c, out_dir, log, cancel=None, progress=None):
            from probely_engine import check_snyk_api_web, run_probely_api, run_probely_dast
            c.probely_token = admin_policy.probely_key()
            ok, msg = check_snyk_api_web(c, log)
            self._ui(self._set_probely_status, "auth" if ok else "unauth")
            if ok:
                log(f"[{kind}] motor asignado por Ciberseguridad: Probely ({msg})")
                res, path = (run_probely_dast if kind == "dast" else run_probely_api)(c, out_dir, log, cancel=cancel,
                                                                                        progress=progress)
                failed = any(str(f.get("title", "")).startswith("Falló el escaneo de Snyk API") for f in
                             res.get("findings") or [])
                if not failed:
                    return res, path
                msg = next((f.get("evidence", "") for f in res.get("findings") or []), "")[:200]
            if not admin_policy.probely_fallback():
                raise RuntimeError(f"Probely no está disponible y la política no permite usar otro motor: {msg}")
            log(f"[{kind}] Probely no disponible ({msg}) — se usa ZAP + Nuclei automáticamente.")
            return oss(c, out_dir, log, cancel=cancel, progress=progress)
        return probely_then_fallback

    def _app_state_root(self, reports_root: Optional[Path] = None) -> Path:
        """Carpeta de la aplicación activa (o «_unscoped»): ahí viven sus reportes, su estado acumulado y su historial
        de remediación. Antes eran globales y una aplicación heredaba los hallazgos de otra."""
        root = Path(reports_root or self._reports_var.get()).resolve()
        s = slug(self._active_app["name"]) if self._active_app and self._active_app.get("name") else ""
        return root / (s or "_unscoped")

    def _app_scan_state(self):
        from report_engine import ScanStateStore
        return ScanStateStore(self._app_state_root())

    def _scoped_report_paths(self, reports_root: Path):
        s = slug(self._active_app["name"]) if self._active_app and self._active_app.get("name") else ""
        root = reports_root / (s or "_unscoped")
        root.mkdir(parents=True, exist_ok=True)
        return (f"{self._user}+{s}" if s else self._user), root

    def _do_scan(self):
        sel = {k for k, v in self._scan_vars.items() if v.get()}
        if not sel:
            return self._emit_log("[escaneo] nada seleccionado")
        self._cancel_evt.clear()
        needs_folder = bool(set(STATIC_STAGES) & sel)
        targets: list = []
        if needs_folder:
            for p in [p for p in self._static_paths if p.strip()] or [self._target_var.get().strip()]:
                if p and not Path(p).exists():
                    self._emit_log(f"[escaneo] ⚠ ruta no encontrada, se omite: {p}")
            for t in self._static_targets():
                if t.is_dir() and not dir_has_files(t):
                    self._emit_log(f"[escaneo] ⚠ carpeta vacía (sin archivos), se omite: {t}")
                else:
                    targets.append(t)
            if not targets:
                return self._emit_log("[escaneo] sin carpeta objetivo con archivos — agregue la carpeta del "
                                      "repositorio en «Código» (SCA/SAST/Secretos la necesitan)")
            if len(targets) > 1:
                self._emit_log(f"[escaneo] {len(targets)} carpetas en la lista — SCA/SAST/Secretos se ejecutan en todas "
                               "y se genera UN reporte consolidado:")
                for i, t in enumerate(targets, 1):
                    self._emit_log(f"[escaneo]    {i}. {t}")
        raw = str(targets[0]) if targets else self._target_var.get().strip()
        if not raw and "iac" in sel and self._iac_paths_effective():
            raw = self._iac_paths_effective()[0]
        target = Path(raw).resolve() if raw else Path(".").resolve()
        self._ui(self._pipeline_reset)
        self._execute_scan(lane="pipeline", target=target, sel=sel, cancel=self._cancel_evt,
                           batch=targets or [target], targets=targets or None)

    def _execute_scan(self, *, lane: str, target: Path, sel: set, cancel: threading.Event,
                      batch: list, route: tuple = (0, 1), targets: Optional[list] = None) -> dict:
        reports_root = Path(self._reports_var.get()).resolve()
        reports_root.mkdir(parents=True, exist_ok=True)
        app = self._active_app
        app_name = app.get("name", "") if app else ""
        label, app_root = self._scoped_report_paths(reports_root)
        mode = "+".join(sorted(sel))
        out_dir = app_root / f"report_{ts()}_{mode}"
        out_dir.mkdir(parents=True, exist_ok=True)
        tag = "estático" if lane == "static" else "escaneo"
        self._session_begin(lane, sel)
        audit(reports_root, "scan_start", actor=self._user, app=app_name, mode=mode, target=str(target),
              out_dir=str(out_dir), lane=lane, log=self._emit_log)
        self._emit_log(f"[{tag}] pipeline: {mode.upper()}")
        self._emit_log(f"[{tag}] salida → {out_dir}")
        try:
            snyk_ok = True
            if {"sca", "code"} & sel:
                try:
                    if not ss.ensure_snyk_ready(self._emit_log):
                        snyk_ok = False
                        self._emit_log(f"[{tag}] la CLI de Snyk no se puede ejecutar — se omiten SCA/SAST. "
                                       "Use «Snyk» → Reinstalar (limpio) para repararla.")
                except Exception as e:
                    self._emit_log(f"[{tag}] error al verificar Snyk: {e!r}")
            try:
                version = run([which("snyk") or "snyk", "--version"]).stdout.strip()
            except Exception:
                version = "?"
            results = dict.fromkeys(STAGES)
            failed: dict[str, str] = {}
            if lane == "static":
                self._ui(self._static_route_start, *route, [k for k in STATIC_STAGES if k in sel])
            for k in (STATIC_STAGES if lane == "static" else INFRA_STAGES if lane == "infra" else STAGES):
                self._ui(self._on_stage, k, "running" if k in sel and (snyk_ok or k not in ("sca", "code")) else "skipped")
            jobs = self._build_jobs(sel, snyk_ok, target, out_dir, results, cancel, targets or [target])
            self._run_jobs(jobs, failed, tag)
            self._diagnose_failures(failed)
            for k in ("dast", "api"):
                self._report_dynamic(k, results.get(k))
            ctx = self._finalize_report(target=target, sel=sel, mode=mode, version=version, results=results,
                                        failed=failed, reports_root=reports_root, out_dir=out_dir, label=label,
                                        batch=batch)
            report = ctx["_report_path"]
            audit(reports_root, "scan_end", actor=self._user, app=app_name, mode=mode, total=ctx["total"],
                  counts=ctx["counts"], gate=ctx["_gate"], report=str(report), lane=lane,
                  failed_stages=sorted(failed), incomplete=bool(failed), cancelled=cancel.is_set(), log=self._emit_log)
            self._ui(self._on_static_results, ctx)
            self._ui(self._on_report, report, route[1] == 1)
            tickets = ctx.get("servicenow_tickets") or []
            return {"path": str(target), "scanned": True, "report_path": str(report), "counts": dict(ctx["counts"]),
                    "total": ctx["total"], "ticket": tickets[0].get("number") if tickets else None}
        except Exception as e:
            self._emit_log(f"[{tag}] el escaneo falló: {e!r}")
            audit(reports_root, "scan_failed", actor=self._user, app=app_name, mode=mode, lane=lane, error=repr(e),
                  log=self._emit_log)
            self._ui(self._on_static_results, None)
            return {"path": str(target), "scanned": False, "reason": f"error: {e}"}
        finally:
            self._session_end(lane)

    def _build_jobs(self, sel, snyk_ok, target, out_dir, results, cancel, targets=None):
        jobs = []
        prog = lambda key: (lambda n, t: self._ui(self._update_card_progress, key, n, t))
        targets = [Path(t) for t in (targets or [target])]
        multi = len(targets) > 1
        log = self._emit_log

        def sub_dir(t: Path, i: int) -> Path:
            """Cada carpeta escribe sus JSON crudos en su propia subcarpeta del reporte (no se pisan entre sí)."""
            if not multi:
                return out_dir
            d = out_dir / f"{i + 1:02d}_{slug(t.name) or 'carpeta'}"
            d.mkdir(parents=True, exist_ok=True)
            return d

        def snyk_batch(key, label, runner):
            dirs = _snyk_dirs(targets)
            parts, errors = [], []
            for i, d in enumerate(dirs):
                if cancel.is_set():
                    log(f"[{key}] cancelado — se omiten las carpetas restantes")
                    break
                if len(dirs) > 1:
                    log(f"[{key}] carpeta {i + 1}/{len(dirs)}: {d}")
                try:
                    parts.append((d, runner(d, sub_dir(d, i), log)[0]))
                except Exception as e:  # noqa: BLE001 — una carpeta que falla no debe tirar las demás del lote
                    if getattr(e, "is_auth", False):
                        raise
                    errors.append((d, e))
                    if len(dirs) > 1:
                        log(f"[{key}] ⚠ {d.name}: {str(e)[:300]}")
                if len(dirs) > 1:
                    self._ui(self._update_card_progress, key, i + 1, len(dirs))
            merge = _merge_sca if key == "sca" else _merge_sarif
            results[key] = merge(parts, dirs) if parts else None
            _finish_batch(label, parts, errors, len(dirs), log)

        if snyk_ok and "sca" in sel:
            jobs.append(("sca", lambda: snyk_batch("sca", "SCA", ss.run_snyk_test)))
        if snyk_ok and "code" in sel:
            jobs.append(("code", lambda: snyk_batch("code", "SAST", ss.run_snyk_code)))
        if "secrets" in sel:
            def secrets():
                log("[secretos] ejecutando escaneo de secretos…")
                gs = ensure_git_secrets(log)  # se descarga aquí si falta, igual que Trivy o Checkov
                parts = []
                for i, t in enumerate(targets):
                    if cancel.is_set():
                        break

                    def p(n, tot, i=i):
                        if tot:
                            self._ui(self._update_card_progress, "secrets", int(1000 * (i + n / tot) / len(targets)),
                                     1000)
                    r = scan_path(t, log, cancel=cancel, git_secrets_status=gs, progress=p)
                    if multi:
                        write_secrets_report(r, sub_dir(t, i) / "secrets")
                    parts.append((t, r))
                r = _merge_secrets(parts, targets) if parts else {"findings": [], "total": 0, "scanned_files": 0}
                write_secrets_report(r, out_dir / "secrets")
                log(f"[secretos] {r['total']} hallazgo(s) en {r['scanned_files']} archivo(s)"
                    + (f" de {len(parts)} carpeta(s)" if multi else ""))
                results["secrets"] = r
            jobs.append(("secrets", secrets))
        if "container" in sel:
            ccfg = self._collect_container_cfg()
            jobs.append(("container", lambda: results.__setitem__("container", infra_scanner.run_container_scan(
                ccfg, out_dir, self._emit_log, cancel=cancel, progress=prog("container"))[0])))
        if "iac" in sel:
            icfg = self._collect_iac_cfg()
            if not icfg.iac_paths:
                self._emit_log("[iac] sin carpeta de IaC — se omite")
                self._ui(self._on_stage, "iac", "skipped")
            else:
                jobs.append(("iac", lambda: results.__setitem__("iac", infra_scanner.run_iac_scan(
                    icfg, out_dir, self._emit_log, cancel=cancel, progress=prog("iac"))[0])))
        for key, collect, missing in (("dast", self._collect_dast_cfg, lambda c: not c.url or c.url == "https://"),
                                      ("api", self._collect_api_cfg, lambda c: not c.spec_source and not c.base_url)):
            if key not in sel:
                continue
            cfg = collect()
            if missing(cfg):
                self._emit_log(f"[{key}] sin {'URL' if key == 'dast' else 'especificación ni URL base'} "
                               f"configurada — se omite {key.upper()}")
                self._ui(self._on_stage, key, "skipped")
                continue
            runner = self._web_runner(key, cfg)
            jobs.append((key, lambda k=key, r=runner, c=cfg: results.__setitem__(
                k, r(c, out_dir, self._emit_log, cancel=cancel, progress=prog(k))[0])))
        return jobs

    def _run_jobs(self, jobs, failed, tag):
        def run_one(job):
            key, fn = job
            try:
                fn()
                self._ui(self._on_stage, key, "done")
            except Exception as e:
                self._ui(self._on_stage, key, "failed")
                failed[key] = str(e)
                self._emit_log(f"[{tag}] {key} falló: {e!r}")
                if getattr(e, "is_auth", False) and key in ("sca", "code"):
                    self._ui(self._prompt_relogin)

        if len(jobs) > 1:
            self._emit_log(f"[{tag}] ejecutando {len(jobs)} etapas en paralelo")
            with ThreadPoolExecutor(max_workers=len(jobs)) as ex:
                list(ex.map(run_one, jobs))
        else:
            for j in jobs:
                run_one(j)
        if failed:
            self._emit_log(f"[{tag}] ⚠ {'/'.join(sorted(failed)).upper()} no se completó — el resultado es INCOMPLETO, "
                           "no lo interprete como un escaneo limpio.")

    def _diagnose_failures(self, failed: dict):
        def matching(text):
            return sorted(k for k, r in failed.items() if text in r.lower())

        if rej := matching("the request cannot be processed"):
            names = "/".join(rej).upper()
            if not getattr(self, "_snyk_auto_reinstall_done", False):
                self._snyk_auto_reinstall_done = True
                self._emit_log(f"[snyk] ⚠ Snyk rechazó la solicitud a nivel de servidor para {names} aunque la CLI local "
                               "corre sin problemas — normalmente el backend ya no acepta esta versión/instalación de "
                               "la CLI. Reinstalando automáticamente la versión más reciente (misma acción que "
                               "'Reinstalar (limpio)')…")
                try:
                    ss.reinstall_snyk_clean(self._emit_log)
                    self._emit_log("[snyk] reinstalación automática completa — inicie sesión de nuevo («Snyk», arriba "
                                   "a la derecha) antes de volver a escanear.")
                except Exception as e:
                    self._emit_log(f"[snyk] la reinstalación automática falló: {e!r}")
            else:
                self._emit_log(f"[snyk] ⚠ Snyk sigue rechazando la solicitud para {names} incluso tras la reinstalación "
                               "automática de esta sesión — puede requerir revisión manual (versión de CLI, "
                               "organización, proxy).")
        if mv := matching("cannot build maven dependency tree"):
            self._emit_log(f"[snyk] ℹ️ {'/'.join(mv).upper()}: Snyk no pudo construir el árbol de dependencias de Maven "
                           "— es un problema del proyecto/Maven, NO de Snyk ni de este programa (el mismo error ocurre "
                           "con 'snyk test' en terminal/IDE). Para diagnosticar, corra en esa carpeta: "
                           'mvn dependency:tree -DoutputType=dot --file="pom.xml" — si TAMBIÉN falla, el problema está '
                           "en Maven/el proyecto (mvn fuera del PATH, repositorio interno inalcanzable, plugin Maven "
                           "Dependency <2.2, versión de JDK, settings.xml); si funciona pero Snyk sigue fallando, es caso "
                           "para soporte de Snyk.")
        if off := sorted(k for k, r in failed.items() if ss.CODE_DISABLED_MARK in r):
            self._emit_log(f"[snyk] ℹ️ {'/'.join(off).upper()}: NO es un problema de inicio de sesión — la cuenta sí "
                           "entró con SSO a una organización de la empresa (por eso SCA funcionó), pero esa organización "
                           "no tiene Snyk Code (SAST) activado. Un admin de Snyk debe activarlo en esa organización "
                           "(Settings → Snyk Code → Enable Snyk Code) o agregar la cuenta a una organización que ya lo "
                           "tenga (p. ej. banco-base-default). Reiniciar sesión no lo resuelve.")
        if org := sorted(k for k, r in failed.items() if ss.is_org_error(r) and ss.CODE_DISABLED_MARK not in r):
            self._emit_log(f"[snyk] ℹ️ {'/'.join(org).upper()}: ninguna organización de Snyk de la empresa aceptó esta "
                           "sesión (se probaron todas a las que la cuenta tiene acceso y la org por defecto de la "
                           "cuenta). Causa más común: se inició sesión con correo y contraseña en vez de SSO — eso "
                           "entra a una cuenta PERSONAL de Snyk. SOLUCIÓN: clic en «Snyk» (arriba a la derecha) → "
                           "'Re-iniciar sesión' → en el navegador elija 'Log in with SSO'. Si ya usó SSO y persiste, la "
                           "cuenta no es miembro de ninguna organización de la empresa con Snyk Code — pida a un admin "
                           "de Snyk que la agregue a una (Settings → Members, a nivel Organización).")

    def _report_dynamic(self, k: str, r):
        if not isinstance(r, dict):
            return
        if r.get("auth_error"):
            self._emit_log(f"[{k}] error de autenticación en Snyk API & Web — clave de Probely inválida o expirada "
                           "(Ciberseguridad debe revisarla en Administración).")
            self._ui(self._set_probely_status, "unauth")
        for name, e in (r.get("engines") or {}).items():
            if e.get("status") == "error":
                self._emit_log(f"[{k}] ⚠ {name.upper()} no se ejecutó: {e.get('detail', '')[:200]} — el resultado "
                               "de esta etapa es PARCIAL.")
        if r.get("scan_url"):
            self._emit_log(f"[{k}] ver el escaneo en Probely: {r['scan_url']}")
        if r.get("report_path"):
            self._emit_log(f"[{k}] reporte de cumplimiento: {r['report_path']}")
        for f in r.get("findings") or []:
            ev = (f.get("evidence") or "").lower()
            if ("not verified" in ev or "verification token" in ev) and self._is_admin:
                self._ui(self._show_probely_verify_popup, k, f.get("evidence") or "")
                break

    def _finalize_report(self, *, target, sel, mode, version, results, failed, reports_root, out_dir, label,
                         batch) -> dict:
        from report_engine import build_cumulative_context, export_csv, render_html, update_history_after_scan
        app = self._active_app
        app_name = app.get("name", "") if app else ""
        multi = len(batch or []) > 1
        static_label = "; ".join(str(t) for t in batch) if multi else str(target)
        targets = {"dast": self._dast_url_var.get().strip(), "api": self._api_spec_var.get().strip(),
                   "container": ", ".join(s["value"] for s in self._container_sources_clean()),
                   "iac": ", ".join(self._iac_paths_effective()), "sca": static_label, "code": static_label,
                   "secrets": static_label}
        from report_engine import ScanStateStore
        state = ScanStateStore(out_dir.parent)   # por aplicación (misma carpeta que sus reportes)
        for kind in STAGES:
            if results.get(kind) is not None:
                try:
                    state.save_kind(kind, results[kind], target=targets.get(kind) or str(target),
                                    snyk_version=version, mode=mode)
                    self._emit_log(f"[estado] resultado {kind} guardado en el histórico acumulado")
                except Exception as e:
                    self._emit_log(f"[estado] no se pudo guardar {kind}: {e!r}")
        ctx = build_cumulative_context(state, target_hint=static_label if multi else target,
                                       snyk_version_hint=version, current_results=results)
        ctx.update(scan_mode=mode, failed_stages=sorted(failed), incomplete=bool(failed),
                   batch_targets=[str(Path(t).resolve()) for t in batch])
        ctx["servicenow_tickets"], ticket_rec = self._sync_tickets(sel, failed, results, target, version, reports_root,
                                                                   app_name, batch=batch)
        c = ctx["counts"]
        sec_ch = sum(1 for s in (ctx.get("secrets") or {}).get("findings", []) if s.get("severity") in ("critical", "high"))
        raw_gate = "FAIL" if (c.get("critical") or c.get("high") or sec_ch) else "PASS"
        gate = "INCOMPLETE" if failed else raw_gate
        self._emit_log(f"[gate] {gate}  (critical={c.get('critical', 0)} high={c.get('high', 0)} "
                       f"medium={c.get('medium', 0)} low={c.get('low', 0)} secrets_crit_high={sec_ch})"
                       + (f"  — {'/'.join(sorted(failed)).upper()} no se completó; vuelva a ejecutar antes de "
                          f"tomarlo como {raw_gate}" if failed else ""))
        base = report_basename(self._user, mode)
        report = render_html(ctx, out_dir, filename=f"{base}.html")
        self._emit_log(f"[reporte] HTML → {report}")
        if ticket_rec is not None:
            self._attach_report_to_ticket(ticket_rec, report, reports_root)
        for what, fn in (("CSV (ZIP)", lambda: export_csv(ctx, out_dir / f"{base}.csv", report_label=label)),
                         ("Secretos HTML", lambda: (out_dir / "secrets" / "secrets.html").exists() and shutil.copyfile(
                             out_dir / "secrets" / "secrets.html", out_dir / f"{base}_secrets.html")),
                         ("SARIF unificado", lambda: ss.export_sarif(out_dir, ctx)),
                         ("JSON unificado", lambda: ss.export_merged_json(out_dir, ctx))):
            try:
                if p := fn():
                    self._emit_log(f"[reporte] {what} → {p}")
            except Exception as e:
                self._emit_log(f"[reporte] {what} omitido: {e!r}")
        meta = {k: ctx.get(k, 0) for k in ("sca_total", "code_total", "dast_total", "api_total", "secrets_total",
                                           "container_total", "iac_total")}
        meta.update(generated_at=ctx["generated_at"], target=ctx["target"], mode=mode, counts=c, total=ctx["total"],
                    snyk_version=ctx.get("snyk_version", ""), failed_stages=sorted(failed), incomplete=bool(failed),
                    servicenow_tickets=ctx["servicenow_tickets"])
        write_json(out_dir / "meta.json", meta)
        try:
            rec = update_history_after_scan(out_dir.parent, ctx, meta, actor=self._user, report_dir=out_dir)
            self._emit_log(f"[historial] registrado — remediadas {rec.get('remediated_count', 0)}, "
                           f"nuevas {rec.get('introduced_count', 0)} desde el último {mode.upper()}")
        except Exception as e:
            self._emit_log(f"[historial] no se pudo actualizar: {e!r}")
        if app and app.get("id"):
            try:
                self._inv_store.record_scan(app["id"], meta)
                if (fresh := self._inv_store.get_app(app["id"])) and self._active_app is app:
                    app.update(fresh)
                self._ui(self._refresh_inventory)
                self._ui(lambda: self._show_app_detail(self._selected_app()))
            except Exception as e:
                self._emit_log(f"[inventario] no se pudo actualizar: {e!r}")
        self._last_context = ctx
        self._last_static_report = Path(report)
        ctx["_report_path"], ctx["_gate"] = Path(report), gate
        return ctx

    # Argumento de build_context() que recibe el resultado crudo de cada etapa.
    _KIND_ARG = {"sca": "test_data", "code": "code_data", "secrets": "secrets_data", "container": "container_data",
                 "iac": "iac_data", "dast": "dast_data", "api": "api_data"}

    def _sync_tickets(self, sel, failed, results, target, version, reports_root, app_name, batch=None) -> tuple:
        """Un ticket por aplicación, levantado con la cuenta de integración (embebida y cifrada en
        test_servicenow_ticket.py) y asignado al usuario de Windows que escanea. El usuario no captura credenciales.
        Devuelve (vistas públicas para el reporte, registro del ticket tocado en ESTE escaneo o None)."""
        try:
            import test_servicenow_ticket as snow
            from report_engine import build_context
        except ImportError as e:
            self._emit_log(f"[servicenow] no se pudo importar test_servicenow_ticket.py ({e!r}) — debe estar en la "
                           "MISMA carpeta que el escáner. Se omite la sincronización.")
            return [], None
        test_mode = bool(getattr(self, "_snow_test_mode", False))
        state = getattr(self, "_snow_state", "none")
        if state in ("none", "invalid") and not test_mode:
            self._emit_log("[servicenow] " + ("la cuenta de integración no está disponible en esta copia del programa"
                           if state == "none" else "ServiceNow rechazó la cuenta de integración") +
                           " — se omite el ticket. Avise a Ciberseguridad.")
            return [], None
        scanned = [k for k in self._KIND_ARG if k in sel and k not in failed and results.get(k) is not None]
        if not scanned:
            return [], None
        repo = "; ".join(Path(t).name for t in batch) if batch and len(batch) > 1 else getattr(target, "name", "")
        name = (app_name or repo or str(target or "")).strip()
        app = self._active_app or {}
        services = {}
        for k in scanned:
            try:
                kw = {"test_data": None, "code_data": None, "target": target, "snyk_version": version}
                kw[self._KIND_ARG[k]] = results[k]   # antes test_data/code_data iban por posición Y por nombre → TypeError
                ctx = build_context(**kw)
                services[k] = {s: int(ctx["counts"].get(s, 0) or 0) for s in ("critical", "high", "medium", "low")}
            except Exception as e:
                self._emit_log(f"[servicenow] no se pudo resumir la etapa {k}: {e!r}")
        if not services:
            return [], None
        if test_mode:
            detail = " · ".join(f"{snow.KIND_LABEL.get(k, k)} C{c['critical']}/A{c['high']}/M{c['medium']}/B{c['low']}"
                                for k, c in services.items())
            hot = any(c["critical"] or c["high"] for c in services.values())
            self._emit_log(f"[servicenow] MODO PRUEBA activo (Administración) — NO se crea, actualiza ni cierra ningún "
                           f"ticket para «{name}». " + (f"En modo normal se habría creado/actualizado el ticket: {detail}"
                           if hot else f"Sin críticas/altas: {detail}"))
            return [], None
        targets = {"dast": self._dast_url_var.get().strip(), "api": self._api_spec_var.get().strip(),
                   "repo": repo or name}
        recs, touched = [], None
        started = snow._snow_now()
        try:
            rec = snow.sync_app_ticket(reports_root, name=name, services=services, scanned=list(services),
                                       environment=app.get("environment", ""), targets=targets,
                                       snyk_org=ss.last_used_org(),
                                       actor=self._user, allow_close=not (set(failed) & set(sel)),
                                       log=self._emit_log)
            if rec:
                recs.append(snow.public_view(rec))
                # Solo se adjunta el reporte a un ticket creado, actualizado o cerrado en ESTE escaneo.
                if rec.get("status") in ("open", "closed") and str(rec.get("updated_at") or "") >= started:
                    touched = rec
        except Exception as e:
            self._emit_log(f"[servicenow] no se pudo sincronizar el ticket: {e!r}")
        if not recs:
            self._ui(self._refresh_servicenow_state)  # p. ej. un 401: la «Preparación» deja de mostrar la palomita
        return recs, touched

    def _attach_report_to_ticket(self, rec: dict, report: Path, reports_root: Path) -> None:
        """Adjunta el reporte HTML consolidado (todos los servicios) al ticket y reemplaza el de escaneos anteriores."""
        try:
            import test_servicenow_ticket as snow
            snow.attach_report(reports_root, rec, Path(report), log=self._emit_log)
        except Exception as e:
            self._emit_log(f"[servicenow] no se pudo adjuntar el reporte al ticket: {e!r}")

    def _on_report(self, path, primary: bool = True):
        self._last_report = Path(path)
        self._refresh_rep_tree()
        self._refresh_active_app_banner()
        self._refresh_summary()
        self._on_infra_results(self._last_context)
        self._refresh_engine_cache()
        if self._active_tab != "reports":
            self._set_reportes_notification(True)
        self._toast("Escaneo terminado — reporte generado", "ok")
        if self._auto_open and primary:
            open_path(self._last_report)
