from __future__ import annotations

import json
import os
import subprocess
import sys
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable, Optional

TASK_ID = "SecDevOpsBancoBase_ScanScheduler"
RUNNER_FILE = "scheduled_runner.py"
MANIFEST_NAME = ".scheduler_manifest.json"
DEFAULT_INTERVAL_MIN = 5
LABEL = "Programador de tareas de Windows"
_NOWIN = {"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}
_DENIED = ("access is denied", "acceso denegado", "denied", "denegado", "not allowed", "no está permitido",
           "no permitido", "permission", "operation not permitted", "requires elevation", "eleva")


@dataclass
class SchedulerStatus:
    backend: str = "schtasks"
    installed: bool = False
    healthy: bool = False
    permission_denied: bool = False
    detail: str = ""
    command: list[str] = field(default_factory=list)


def platform_label() -> str:
    return LABEL


def build_command(script_dir: Path, python_exe: str) -> list[str]:
    if getattr(sys, "frozen", False):
        return [sys.executable, "--tick"]
    pyw = Path(python_exe).with_name("pythonw.exe")
    return [str(pyw if pyw.exists() else python_exe), str(Path(script_dir) / RUNNER_FILE), "--tick"]


def task_run_line(cmd: list[str]) -> str:
    return " ".join(f'"{c}"' if not c.startswith("--") else c for c in cmd)


def _schtasks(*args, timeout=20) -> subprocess.CompletedProcess:
    return subprocess.run(["schtasks", *args], capture_output=True, text=True, timeout=timeout, encoding="utf-8",
                          errors="replace", **_NOWIN)


def _denied(out) -> bool:
    low = (out.stderr or out.stdout or "").lower()
    return any(m in low for m in _DENIED)


def _write_manifest(data_dir: Path, st: SchedulerStatus, interval: int) -> None:
    try:
        (Path(data_dir) / MANIFEST_NAME).write_text(json.dumps({
            "task_id": TASK_ID, "backend": st.backend, "installed": st.installed, "healthy": st.healthy,
            "command": st.command, "interval_minutes": interval,
            "updated_at": datetime.now().isoformat(timespec="seconds")}, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass


def get_status(script_dir: Path, python_exe: str, data_dir: Path, interval_minutes: int = DEFAULT_INTERVAL_MIN) -> SchedulerStatus:
    cmd = build_command(script_dir, python_exe)
    try:
        out = _schtasks("/Query", "/TN", TASK_ID, "/XML", timeout=15)
    except Exception as e:
        return SchedulerStatus(command=cmd, detail=f"No se pudo consultar el Programador de tareas: {e!r}")
    if out.returncode:
        return SchedulerStatus(command=cmd, detail="Sin tarea registrada en el Programador de tareas de Windows.")
    try:
        ns = {"t": "http://schemas.microsoft.com/windows/2004/02/mit/task"}
        root = ET.fromstring(out.stdout)
        exe = (root.findtext(".//t:Actions/t:Exec/t:Command", "", ns) or "").strip('"')
        args = root.findtext(".//t:Actions/t:Exec/t:Arguments", "", ns) or ""
        ok = exe == cmd[0] and cmd[1] in args and "--tick" in args
        return SchedulerStatus(installed=True, healthy=ok, command=cmd, detail=(
            "Tarea registrada y apuntando a la ubicación actual del programa." if ok else
            "Tarea registrada pero apunta a una ubicación anterior — se reparará."))
    except Exception as e:
        return SchedulerStatus(installed=True, command=cmd,
                               detail=f"Tarea registrada pero no se pudo verificar su ruta ({e!r}) — se reparará.")


def install_or_repair(script_dir: Path, python_exe: str, data_dir: Path, interval_minutes: int = DEFAULT_INTERVAL_MIN,
                      log: Optional[Callable[[str], None]] = None) -> SchedulerStatus:
    log = log or (lambda _: None)
    st = get_status(script_dir, python_exe, data_dir, interval_minutes)
    if st.healthy:
        log(f"[scheduler-os] {LABEL}: tarea ya registrada y actualizada.")
    else:
        log(f"[scheduler-os] {LABEL}: {'reparando ruta de la tarea existente' if st.installed else 'registrando tarea nueva'}…")
        cmd = build_command(script_dir, python_exe)
        try:
            out = _schtasks("/Create", "/TN", TASK_ID, "/TR", task_run_line(cmd), "/SC", "MINUTE", "/MO",
                            str(max(1, interval_minutes)), "/RL", "LIMITED", "/F")
            if not out.returncode:
                st = SchedulerStatus(installed=True, healthy=True, command=cmd, detail=(
                    f"Tarea registrada en el Programador de tareas de Windows (cada {interval_minutes} min, solo con "
                    "la sesión iniciada)."))
            else:
                st = SchedulerStatus(permission_denied=_denied(out), command=cmd, detail=(
                    "Sin permisos para crear tareas en el Programador de tareas de Windows." if _denied(out) else
                    f"No se pudo crear la tarea de Windows: {(out.stderr or out.stdout).strip()}"))
        except Exception as e:
            st = SchedulerStatus(permission_denied=True, detail=f"No se pudo registrar la tarea del sistema: {e!r}")
        log(f"[scheduler-os] {st.detail}")
    _write_manifest(data_dir, st, interval_minutes)
    return st


def remove(data_dir: Path, log: Optional[Callable[[str], None]] = None) -> SchedulerStatus:
    try:
        out = _schtasks("/Delete", "/TN", TASK_ID, "/F", timeout=15)
        err = (out.stderr or "").lower()
        st = SchedulerStatus(detail="Tarea de Windows eliminada (o ya no existía).") \
            if not out.returncode or "cannot find" in err or "no se encuentra" in err else \
            SchedulerStatus(permission_denied=_denied(out),
                            detail=f"No se pudo eliminar la tarea de Windows: {(out.stderr or out.stdout).strip()}")
    except Exception as e:
        st = SchedulerStatus(permission_denied=True, detail=f"No se pudo quitar la tarea del sistema: {e!r}")
    if log:
        log(f"[scheduler-os] {st.detail}")
    (Path(data_dir) / MANIFEST_NAME).unlink(missing_ok=True)
    return st
