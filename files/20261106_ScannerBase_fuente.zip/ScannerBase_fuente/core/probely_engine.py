"""Motor Snyk API & Web (Probely) — uso exclusivo de administración.

Ciberseguridad decide qué aplicaciones usan Probely (admin_policy.json); la clave de API vive en esa política y
nunca la captura el usuario final. Cualquier aplicación fuera de la lista usa los motores de código abierto.
"""
from __future__ import annotations

import base64
import mimetypes
import ssl
import time
import uuid
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qsl, urlencode, urljoin, urlparse
from urllib.request import HTTPSHandler, Request, build_opener

from ui_common import *
import static_scanner as ss
from web_common import (_api_base_url, _api_load_spec, _host_looks_non_public, _LOGOUT_PATH_RE, _COMMON_LOGOUT_PATHS,
                        _make_opener, _split, DEFAULT_LOGOUT_MARKERS, USER_AGENT)

PROBELY_API = "https://api.us.probely.com"


PROBELY_APP = "https://plus.us.probely.app"


PROBELY_PROFILES = ["(predeterminado)", "lightning", "safe", "normal", "full"]


REPORTS = ["(ninguno)", "owasp", "owasp_web_2021", "owasp_web_2025", "pci", "pci4", "pci_v3_2_1", "pci_v4_0_1",
           "iso27001", "hipaa", "executive_summary"]


_TERMINAL = {"completed", "completed_with_errors", "under_review", "canceled", "cancelled", "failed", "over"}


def _norm_severity(sev, cvss) -> str:
    try:
        s = int(sev)
    except (TypeError, ValueError):
        s = 0
    try:
        c = float(cvss)
    except (TypeError, ValueError):
        c = 0.0
    return ("critical" if c >= 9.0 else "high") if s >= 30 else "medium" if s >= 20 else "low"


_CATEGORY_KW = (("sql", "sqli"), ("cross-site scripting", "xss"), ("xss", "xss"), ("authentication", "auth"),
                ("authorization", "auth"), ("bola", "auth"), ("object level", "auth"), ("redirect", "redirect"),
                ("ssrf", "ssrf"), ("header", "headers"), ("csp", "headers"), ("hsts", "headers"), ("cors", "headers"),
                ("tls", "transport"), ("unencrypted", "transport"), ("csrf", "csrf"), ("injection", "injection"),
                ("information", "info"), ("disclosure", "info"))


def _normalise_finding(f: dict, default_category: str) -> dict:
    d = f.get("definition") or {}
    name = d.get("name") or "Hallazgo"
    reqs = f.get("requests") or []
    parts = [(f.get("evidence") or "").strip(),
             (reqs[0].get("request") or "").strip() if reqs and isinstance(reqs[0], dict) else "",
             f"CVSS: {f['cvss_vector']}" if f.get("cvss_vector") else ""]
    return {"severity": _norm_severity(f.get("severity"), f.get("cvss_score")),
            "title": f"{name} en '{f['parameter']}'" if f.get("parameter") else name,
            "url": f.get("url") or f.get("path") or "", "evidence": "\n".join(p for p in parts if p)[:600],
            "cwe": d.get("cwe") or "",
            "category": next((c for kw, c in _CATEGORY_KW if kw in name.lower()), default_category)}


class ProbelyError(Exception):
    def __init__(self, message: str, *, status: int = 0, is_auth: bool = False):
        super().__init__(message)
        self.status, self.is_auth = status, is_auth


def _ssl_context(log) -> ssl.SSLContext:
    ca = next((p for v in ("PROBELY_CA_BUNDLE", "SNYK_CA_BUNDLE", "REQUESTS_CA_BUNDLE", "SSL_CERT_FILE",
                           "CURL_CA_BUNDLE", "NODE_EXTRA_CA_CERTS")
               if (p := os.environ.get(v)) and Path(p).is_file() and Path(p).stat().st_size), None)
    ca = ca or ss.export_windows_ca_bundle(log)
    try:
        ctx = ssl.create_default_context(cafile=ca) if ca else ssl.create_default_context()
        ctx.verify_flags &= ~getattr(ssl, "VERIFY_X509_STRICT", 0)  # Python ≥3.13 vs CA de proxy corporativo
        if ca:
            log(f"[snyk-aw] usando el CA corporativo para TLS: {ca}")
    except Exception as e:
        log(f"[snyk-aw] no se pudo cargar el CA {ca!r} ({e!r}); se usa el almacén del sistema")
        ctx = ssl.create_default_context()
        ctx.verify_flags &= ~getattr(ssl, "VERIFY_X509_STRICT", 0)  # Python ≥3.13 vs CA de proxy corporativo
    strict = getattr(ssl, "VERIFY_X509_STRICT", 0)
    if strict and ctx.verify_flags & strict:
        ctx.verify_flags &= ~strict
    if os.environ.get("PROBELY_INSECURE_TLS", "").strip().lower() in ("1", "true", "yes", "on"):
        log("[snyk-aw] ADVERTENCIA: PROBELY_INSECURE_TLS=1 — la verificación TLS está DESACTIVADA para las llamadas a "
            "Probely. Úselo solo temporalmente en una red de confianza.")
        ctx.check_hostname, ctx.verify_mode = False, ssl.CERT_NONE
    return ctx


def _tls_help(exc, base) -> str:
    return (f"No se pudo verificar el certificado TLS de {base}. Su red corporativa intercepta el tráfico HTTPS y "
            "presenta un certificado emitido por una CA interna. Soluciones, en orden:\n"
            "  1) Exporte la CA raíz de su empresa a un archivo .pem, apunte la variable de entorno PROBELY_CA_BUNDLE a "
            "ese archivo y reinicie la app.\n"
            "  2) Si el detalle menciona «Basic Constraints of CA cert not marked critical», la app ya relaja esa "
            "comprobación automáticamente; reinicie para tomar el cambio.\n"
            "  3) Último recurso temporal, solo en una red de confianza: defina PROBELY_INSECURE_TLS=1 antes de abrir la "
            f"app.\nDetalle técnico: {exc!r}")


def _cloudflare_help(body: str) -> str:
    return ("Bloqueo de Cloudflare (Error 1010, «Access denied»). NO es un problema del token ni de su rol: la petición "
            "se rechazó por la «firma» del cliente HTTP (User-Agent / huella) ANTES de llegar a Probely.\nQué hacer:\n"
            "  1) La app envía un User-Agent propio; si su WAF exige un navegador real, defina la variable de entorno "
            "PROBELY_USER_AGENT con un User-Agent de Chrome/Edge.\n"
            "  2) Si persiste, casi siempre es el proxy/WAF corporativo o la IP de salida: pida a Ciberseguridad "
            f"({SUPPORT_EMAIL}) que permita el tráfico hacia api.us.probely.com sin «Browser Integrity Check».\n"
            f"Detalle de Cloudflare: {body[:300]}")


class _Probely:
    def __init__(self, token: str, log):
        if not token:
            raise ProbelyError("No hay clave de API de Snyk API & Web (Probely). Ciberseguridad debe configurarla en Administración.",
                               is_auth=True)
        self._token, self._log = token, log
        self._ua = os.environ.get("PROBELY_USER_AGENT", "").strip() or USER_AGENT
        self._opener = build_opener(HTTPSHandler(context=_ssl_context(log)))

    def req(self, method: str, path: str, *, data=None, params=None, ctype="application/json",
            expect=(200, 201), retries: int = 4, raw: bool = False):
        url = PROBELY_API + "/" + path.lstrip("/") + ("?" + urlencode(params) if params else "")
        body = data if isinstance(data, bytes) or data is None else json.dumps(data).encode()
        hdrs = {"Authorization": f"JWT {self._token}", "Accept": "application/pdf" if raw else "application/json",
                "User-Agent": self._ua, "Accept-Language": "en-US,en;q=0.9"}
        if body is not None:
            hdrs["Content-Type"] = ctype
        last = None
        for attempt in range(retries):
            try:
                with self._opener.open(Request(url, data=body, method=method, headers=hdrs), timeout=120 if raw else 60) as r:
                    content = r.read()
                    if r.status not in expect:
                        raise ProbelyError(f"{method} {path} → HTTP {r.status}", status=r.status)
                    return content if raw else (json.loads(content) if content else {})
            except HTTPError as e:
                try:
                    detail = e.read(8000).decode("utf-8", "replace")
                except Exception:
                    detail = ""
                low = detail.lower().replace(" ", "")
                if e.code == 403 and ('"error_code":1010' in low or "error1010" in low or "browsersignature" in low
                                      or "browser'ssignature" in low or ("cloudflare" in low and "accessdenied" in low)):
                    raise ProbelyError(_cloudflare_help(detail), status=e.code)
                if e.code in (401, 403):
                    raise ProbelyError(f"Error de autenticación/permisos (HTTP {e.code}). Revise la clave de API y su "
                                       f"rol. {detail[:300]}", status=e.code, is_auth=True)
                if e.code == 429 or 500 <= e.code < 600:
                    try:
                        wait = float(e.headers.get("Retry-After") or 0)
                    except Exception:
                        wait = 0
                    wait = wait or 2 ** attempt
                    self._log(f"[snyk-aw] HTTP {e.code} en {method} {path}; reintento en {wait:.0f}s")
                    last = ProbelyError(f"HTTP {e.code}: {detail[:200]}", status=e.code)
                    time.sleep(min(wait, 30))
                    continue
                raise ProbelyError(f"{method} {path} → HTTP {e.code}: {detail[:300]}", status=e.code)
            except (URLError, TimeoutError) as e:
                if isinstance(getattr(e, "reason", e), ssl.SSLCertVerificationError) or "CERTIFICATE_VERIFY_FAILED" in repr(e):
                    raise ProbelyError(_tls_help(e, PROBELY_API))
                last = e
                self._log(f"[snyk-aw] error de red en {method} {path}: {e!r} (intento {attempt + 1}/{retries})")
                time.sleep(min(2 ** attempt, 30))
            except json.JSONDecodeError as e:
                raise ProbelyError(f"JSON inválido de {method} {path}: {e!r}")
        raise ProbelyError(f"{method} {path} falló tras {retries} intentos: {last!r}")

    def site(self, tid: str, site: dict):
        return self.req("PATCH", f"/targets/{tid}/", data={"site": site})

    def pages(self, path: str, params=None, limit: int = 50):
        for page in range(1, limit + 1):
            data = self.req("GET", path, params={**(params or {}), "page": page})
            yield from data.get("results") or []
            if not data.get("results") or not data.get("page_total") or page >= data["page_total"]:
                return

    def whoami(self) -> dict:
        return self.req("GET", "/profile/")

    def find_target_by_url(self, url: str, ttype: Optional[str]):
        want = url.rstrip("/")
        return next((t for t in self.pages("/targets/") if ((t.get("site") or {}).get("url") or "").rstrip("/") == want
                     and (ttype is None or (t.get("type") or "single") == ttype)), None)


def macro_to_probely_sequence(macro: list) -> str:
    css = lambda s: s if s.startswith(("css=", "id=", "name=", "xpath=")) else f"css={s}"
    cmds: list = []
    add = lambda c, t, v="": cmds.append({"command": c, "target": t, "value": v})
    events = [e for e in macro or [] if isinstance(e, dict)]
    if start := next((e["url"].strip() for e in events if (e.get("url") or "").strip()), ""):
        add("open", start)
    for ev in events:
        kind, sel, url = ev.get("kind") or ev.get("type"), ev.get("selector") or ev.get("sel") or "", ev.get("url") or ""
        last = cmds[-1] if cmds else {}
        if kind in ("navigate", "open") and url and last.get("target") != url:
            add("open", url)
        elif kind in ("field", "input", "change") and sel:
            v = "" if ev.get("value") is None else str(ev["value"])
            if last.get("command") == "type" and last.get("target") == css(sel):
                last["value"] = v
            else:
                add("type", css(sel), v)
        elif kind == "click" and sel:
            add("click", css(sel))
        elif kind == "submit":
            if btn := ev.get("button") or sel:
                if not (last.get("command") == "click" and last.get("target") == css(btn)):
                    add("click", css(btn))
            elif form := ev.get("form"):
                add("submit", css(form))
        elif kind in ("enter", "keydown") and (t := sel or ev.get("form")) and last.get("command") not in (
                "click", "submit", "sendKeys"):
            add("sendKeys", css(t), "${KEY_ENTER}")
    return json.dumps({"version": "selenium-ide-compatible", "commands": cmds})


def _login_method(cfg, url: str, log):
    seq = None
    if path := cfg.probely_login_sequence_path:
        if Path(path).exists():
            log(f"[snyk-aw] usando el archivo de secuencia de login de Probely: {Path(path).name}")
            seq = (Path(path).stem or "login sequence", Path(path).read_text(encoding="utf-8"))
        else:
            log(f"[snyk-aw] archivo de secuencia de login no encontrado: {path}")
    if not seq and cfg.selenium_macro:
        try:
            macro = json.loads(cfg.selenium_macro)
        except Exception:
            macro = None
        if macro:
            log("[snyk-aw] convirtiendo la macro grabada → secuencia de Probely (mejor esfuerzo).")
            seq = ("converted login sequence", macro_to_probely_sequence(macro))
    form = None
    mode, auth = (cfg.probely_form_login or "auto").lower(), (cfg.auth_type or "none").lower()
    if mode != "off":
        if cfg.login_data.strip():
            fields = [{"name": k, "value": v} for k, v in parse_qsl(cfg.login_data.strip(), keep_blank_values=True) if k]
        else:
            fields = [{"name": s, "value": v} for s, v in (
                (cfg.selenium_user_selector.strip(), cfg.selenium_user_value or cfg.username),
                (cfg.selenium_pass_selector.strip(), cfg.selenium_pass_value or cfg.password)) if s and v]
        if fields:
            if submit := (cfg.probely_form_submit_selector or cfg.selenium_submit_selector).strip():
                fields.append({"name": "submit_button", "value": submit})
            form = ((cfg.login_url or cfg.selenium_login_url or url).strip(), fields,
                    (cfg.probely_form_login_check_pattern or cfg.login_success_text).strip()[:255])
        elif mode == "on" or auth == "form":
            log("[snyk-aw] se pidió login por formulario pero no hay pares usuario/contraseña (configure login_data o "
                "los selectores y valores). Se omite el login por formulario.")
    forced = form is not None and (mode == "on" or auth == "form")
    if seq and cfg.probely_login_sequence_path.strip():
        return "sequence", seq, form
    if forced:
        return "form", seq, form
    return ("sequence" if seq else "form" if form else None), seq, form


def logout_blacklist(cfg, base_url: str, log) -> list[str]:
    out, coincided = [], False
    b = urlparse(base_url)

    def add(u: str, need_logout_path: bool):
        nonlocal coincided
        u = (u or "").strip()
        if not u:
            return
        if not u.startswith(("http://", "https://")):
            u = urljoin(base_url.rstrip("/") + "/", u.lstrip("/"))
        p = urlparse(u)
        path = (p.path or "").rstrip("/")
        if path in ("", "/") or (p.netloc == b.netloc and path == (b.path or "").rstrip("/")):
            coincided = True
            return
        if need_logout_path and not _LOGOUT_PATH_RE.search(u):
            return
        u = u if "*" in u else u.rstrip("/") + "*"
        if u not in out:
            out.append(u)

    try:
        macro = json.loads(cfg.selenium_logout_macro) if cfg.selenium_logout_macro else []
    except Exception:
        macro = []
    for ev in macro or []:
        if isinstance(ev, dict) and ev.get("url"):
            add(ev["url"], True)
    for chunk in _split(cfg.probely_blacklist):
        add(chunk, False)
    for path in _COMMON_LOGOUT_PATHS:
        add(f"{b.scheme or 'https'}://{b.netloc}{path}", False)
    if coincided:
        log("[snyk-aw] ADVERTENCIA: una URL de logout coincide con la raíz del sitio / la URL inicial, no puede excluirse "
            "sin excluir todo el sitio. Se omitió. Para mayor robustez configure un detector de logout de Probely.")
    if out:
        log(f"[snyk-aw] lista negra de logout/exclusión ({len(out)} globs): " + ", ".join(out[:8]) +
            (" …" if len(out) > 8 else ""))
    return out


def _schema_type(cfg) -> str:
    forced = (cfg.probely_api_schema_type or "").strip().lower()
    if forced in ("openapi", "postman", "graphql"):
        return forced
    src = (cfg.spec_source or "").strip()
    if not src or src.startswith(("http://", "https://")):
        return "graphql" if src.lower().endswith((".graphql", ".gql", ".graphqls")) else "openapi"
    if src.lower().endswith((".graphql", ".gql", ".graphqls")):
        return "graphql"
    try:
        txt = Path(src).read_text(encoding="utf-8", errors="replace")
    except Exception:
        return "openapi"
    try:
        data = json.loads(txt)
        if isinstance(data, dict) and "item" in data and "paths" not in data:
            return "postman"
    except Exception:
        pass
    tl = txt.lower()
    if ("__schema" in txt and '"data"' in tl) or "type query" in tl or ("schema {" in tl and "query:" in tl):
        return "graphql"
    return "openapi"


def _ensure_target(client: _Probely, cfg, *, url: str, is_api: bool, log) -> dict:
    target = None
    if tid := cfg.probely_target_id:
        target = client.req("GET", f"/targets/{tid}")
        log(f"[snyk-aw] reutilizando el target configurado {tid}")
    if target is None and cfg.probely_reuse_by_url:
        if target := client.find_target_by_url(url, "api" if is_api else None):
            log(f"[snyk-aw] reutilizando el target existente {target.get('id')} (coincide la URL)")
    if target is None:
        name = f"{'API' if is_api else 'Web'}: {urlparse(url).hostname or url}"
        if is_api:
            src = cfg.spec_source.strip()
            st = _schema_type(cfg)
            settings = {"api_schema_type": st, **({"api_schema_url": src} if src.startswith(("http://", "https://")) else {})}
            target = client.req("POST", "/targets/", data={"site": {"name": name, "url": url,
                                                                    "api_scan_settings": settings}, "type": "api"})
            log(f"[snyk-aw] target de API creado {target['id']} (schema_type={st})")
            if src and "api_schema_url" not in settings:
                p = Path(src)
                boundary = "----snykaw" + uuid.uuid4().hex
                body = (f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="{p.name}"\r\n'
                        f"Content-Type: {mimetypes.guess_type(p.name)[0] or 'application/octet-stream'}\r\n\r\n").encode() \
                    + p.read_bytes() + f"\r\n--{boundary}--\r\n".encode()
                client.req("POST", f"/targets/{target['id']}/upload_api_schema_file/", data=body,
                           ctype=f"multipart/form-data; boundary={boundary}")
                log(f"[snyk-aw] archivo de esquema de API cargado: {p.name}")
        else:
            target = client.req("POST", "/targets/", data={"site": {"name": name, "url": url}})
            log(f"[snyk-aw] target web creado {target['id']}")
    tid, site = target["id"], target.get("site") or {}
    if not site.get("verified", False):
        token = site.get("verification_token", "")
        if cfg.probely_require_verified:
            raise ProbelyError("El dominio del objetivo NO está verificado en Snyk API & Web. Probely no lo escaneará "
                               f"(los escaneos no verificados se tratan como ataques). Verification token: {token}")
        log("[snyk-aw] ADVERTENCIA: el dominio NO está verificado. Probely limita los objetivos no verificados a "
            f"escaneos LIGHTNING — se fuerza ese perfil. Verifique el dominio (verification token: {token}).")
        target["_force_lightning"] = True
    if not is_api and cfg.probely_agent_warn and _host_looks_non_public(url):
        log("[snyk-aw] ADVERTENCIA: el host parece no público (privado/loopback/no resoluble). El escáner en la nube de "
            "Probely no puede alcanzarlo sin un Scanning Agent en su red. Si ya configuró uno, ignore esto.")
    method, seq, form = _login_method(cfg, url, log)
    has_login = False
    try:
        if method == "sequence":
            client.req("POST", f"/targets/{tid}/sequences/", data={"name": seq[0], "content": seq[1], "type": "login",
                                                                   "enabled": True})
            client.site(tid, {"has_sequence_login": True, "has_form_login": False, "auth_enabled": True})
            has_login = True
            log("[snyk-aw] secuencia de login adjunta y autenticación habilitada.")
        elif method == "form":
            client.site(tid, {"has_form_login": True, "has_sequence_login": False, "auth_enabled": True,
                              "form_login_url": form[0], "form_login": form[1], "form_login_check_pattern": form[2]})
            has_login = True
            log(f"[snyk-aw] login por formulario configurado en {form[0] or '(URL del objetivo)'} "
                f"({len([f for f in form[1] if f['name'] != 'submit_button'])} campo(s); patrón de verificación="
                f"{'sí' if form[2] else 'no'}).")
    except ProbelyError as e:
        log(f"[snyk-aw] no se pudo configurar el login ({method}): {e} (el escaneo correrá sin autenticar).")
    if is_api and not has_login and cfg.probely_api_login_url.strip():
        try:
            client.site(tid, {"api_login_url": cfg.probely_api_login_url.strip(), "api_login_payload": cfg.probely_api_login_payload,
                              "api_login_media_type": cfg.probely_api_login_media_type or "application/json",
                              "api_login_token_field": cfg.probely_api_login_token_field,
                              "api_login_token_param": cfg.probely_api_login_token_param or "Authorization",
                              "api_login_token_prefix": cfg.probely_api_login_token_prefix,
                              "api_login_token_place": cfg.probely_api_login_place or "header", "auth_enabled": True})
            has_login = True
            log("[snyk-aw] endpoint de login de API configurado (obtención de token).")
        except ProbelyError as e:
            log(f"[snyk-aw] no se pudo configurar el endpoint de login de API: {e}")
    if not has_login and cfg.probely_protect_session:
        has_login = _protect_session(client, cfg, target, log)
    if cfg.probely_2fa_enabled and cfg.probely_otp_secret:
        if not has_login:
            log("[snyk-aw] se pidió 2FA pero no hay método de login configurado — se omite.")
        else:
            try:
                client.site(tid, {"has_otp": True, "otp_secret": cfg.probely_otp_secret,
                                  **{k: v for k, v in (("otp_field", cfg.probely_otp_field),
                                                       ("otp_submit", cfg.probely_otp_submit),
                                                       ("otp_algorithm", cfg.probely_otp_algorithm),
                                                       ("otp_digits", int(cfg.probely_otp_digits or 6))) if v}})
                log("[snyk-aw] 2FA (TOTP) configurado en el target.")
            except ProbelyError as e:
                log(f"[snyk-aw] no se pudo configurar 2FA: {e}")
    if is_api and has_login and cfg.probely_check_login:
        try:
            client.req("POST", f"/targets/{tid}/check_api_login/", data={}, expect=(200, 201, 202))
            log("[snyk-aw] prueba de la configuración de login de API solicitada.")
        except ProbelyError as e:
            log(f"[snyk-aw] prueba de login de API no disponible/falló: {e}")
    if not is_api:
        if bl := logout_blacklist(cfg, url, log):
            merged = list(dict.fromkeys(list(site.get("blacklist") or []) + bl))
            try:
                client.site(tid, {"blacklist": merged})
                log(f"[snyk-aw] lista negra aplicada ({len(merged)} entradas).")
            except ProbelyError as e:
                log(f"[snyk-aw] no se pudo aplicar la lista negra: {e}")
        if cfg.probely_logout_detection:
            if has_login:
                _setup_logout_detection(client, cfg, tid, url, log)
            else:
                log("[snyk-aw] se pidió detección de logout pero no hay login configurado — se omite.")
    return target


def _setup_logout_detection(client: _Probely, cfg, tid: str, url: str, log) -> None:
    check_url = cfg.probely_check_session_url.strip() or url
    cond = cfg.probely_logout_condition if cfg.probely_logout_condition in ("any", "all") else "any"
    dets = [("text", m) for m in (_split(cfg.probely_logout_markers) or DEFAULT_LOGOUT_MARKERS)]
    if cfg.probely_logout_url_detector and (lu := (cfg.probely_login_url or cfg.selenium_login_url or cfg.login_url).strip()):
        dets.append(("url", lu))
    if cfg.probely_logout_code_detector:
        dets += [("code", "401"), ("code", "403")]
    if cfg.probely_logout_selector.strip():
        dets.append(("sel", cfg.probely_logout_selector.strip()))
    dets += [("body", m) for m in _split(cfg.probely_logout_body_markers)]
    dets += [("header", m) for m in _split(cfg.probely_logout_header_markers)]
    try:
        existing = {(d.get("type"), d.get("value")) for d in client.req("GET", f"/targets/{tid}/logout/").get("results") or []}
    except ProbelyError:
        existing = set()
    added: dict = {}
    for typ, val in dets:
        if (typ, val) in existing:
            continue
        try:
            created = client.req("POST", f"/targets/{tid}/logout/", data={"type": typ if typ in ("text", "url", "sel")
                                                                          else "text", "value": val})
            if typ not in ("text", "url", "sel"):
                if not created.get("id"):
                    raise ProbelyError("la creación no devolvió id de detector")
                client.req("PATCH", f"/targets/{tid}/logout/{created['id']}/", data={"type": typ, "value": val})
            added[typ] = added.get(typ, 0) + 1
        except ProbelyError as e:
            log(f"[snyk-aw] no se pudo agregar el detector de logout {typ} {val!r}: {e}")
    try:
        client.site(tid, {"check_session_url": check_url, "logout_detection_enabled": True, "logout_condition": cond})
        log(f"[snyk-aw] detección de logout ACTIVA (condición={cond}; agregados "
            f"{', '.join(f'{n} {t}' for t, n in added.items()) or '0 nuevos'}; check_session_url={check_url}). Si se "
            "pierde la sesión, vuelve a iniciarla automáticamente en lugar de escanear como anónimo.")
    except ProbelyError as e:
        log(f"[snyk-aw] no se pudo activar la detección de logout: {e} (requiere método de login + check_session_url).")


def _protect_session(client: _Probely, cfg, target: dict, log) -> bool:
    auth = (cfg.auth_type or "none").lower()
    cookies, headers = [], []
    entry = lambda n, v: {"name": n, "value": v, "authentication": True, "allow_testing": False}
    if auth == "basic" and cfg.username:
        try:
            client.site(target["id"], {"has_basic_auth": True, "auth_enabled": True,
                                       "basic_auth": {"username": cfg.username, "password": cfg.password}})
            log("[snyk-aw] autenticación HTTP Basic nativa configurada en el target.")
            return True
        except ProbelyError as e:
            log(f"[snyk-aw] no se pudo configurar Basic nativo ({e}); se usa un encabezado Authorization.")
            headers.append(entry("Authorization", "Basic " + base64.b64encode(
                f"{cfg.username}:{cfg.password}".encode()).decode()))
    if auth == "cookie" and cfg.cookie:
        cookies = [entry(n.strip(), v.strip()) for n, _, v in (p.partition("=") for p in cfg.cookie.split(";") if "=" in p)
                   if n.strip()]
    elif auth == "header" and cfg.header_name:
        headers.append(entry(cfg.header_name.strip(), cfg.header_value))
    elif auth == "bearer" and cfg.token:
        headers.append(entry("Authorization", f"Bearer {cfg.token}"))
    if not cookies and not headers:
        return False
    site = target.get("site") or {}
    merge = lambda old, new: [e for e in old or [] if e.get("name") not in {n["name"] for n in new}] + new
    payload = {"auth_enabled": True, **({"cookies": merge(site.get("cookies"), cookies)} if cookies else {}),
               **({"headers": merge(site.get("headers"), headers)} if headers else {})}
    try:
        client.site(target["id"], payload)
        log(f"[snyk-aw] autenticación estática registrada ({len(cookies)} cookie(s), {len(headers)} encabezado(s)) como "
            "autenticación no fuzzeable — el escáner no puede cerrar su propia sesión así.")
        return True
    except ProbelyError as e:
        log(f"[snyk-aw] no se pudieron registrar las credenciales estáticas: {e}")
        return False


def _drive_scan(client: _Probely, cfg, target: dict, *, category: str, log, cancel, progress, out_dir) -> dict:
    tid = target["id"]
    profile = cfg.probely_scan_profile or ("full" if (cfg.profile or "").lower() == "active" else "")
    if target.get("_force_lightning"):
        if profile and profile != "lightning":
            log(f"[snyk-aw] se cambia el perfil '{profile}' → 'lightning' (dominio no verificado).")
        profile = "lightning"
    reduced = [{"url": u, "enabled": True} for u in _split(cfg.probely_reduced_scopes)]
    payload = {k: v for k, v in (("scan_profile", profile), ("reduced_scopes", reduced),
                                 ("ignore_blackout", cfg.probely_ignore_blackout)) if v}
    sid = client.req("POST", f"/targets/{tid}/scan_now/", data=payload)["id"]
    log(f"[snyk-aw] escaneo {sid} en cola en el target {tid} (perfil={profile or 'predeterminado del target'}"
        f"{', alcance reducido' if reduced else ''}{', ignora blackout' if cfg.probely_ignore_blackout else ''})")
    poll = max(5.0, float(cfg.probely_poll_interval or 15))
    deadline = time.monotonic() + float(cfg.probely_max_wait_minutes or 180) * 60
    status, cancelled = "queued", False
    def cancel_cloud(reason):
        log(f"[snyk-aw] {reason} → cancelando el escaneo en la nube")
        try:
            client.req("POST", f"/targets/{tid}/scans/{sid}/cancel/", data={}, expect=(200, 201, 202))
        except ProbelyError as e:
            log(f"[snyk-aw] la cancelación falló: {e}")

    while True:
        if cancel.is_set() and not cancelled:
            cancel_cloud("cancelación solicitada")
            cancelled = True
        if time.monotonic() > deadline:
            cancel_cloud("se excedió la espera máxima")
            cancelled = True
            break
        time.sleep(poll)
        try:
            sc = client.req("GET", f"/targets/{tid}/scans/{sid}")
        except ProbelyError as e:
            log(f"[snyk-aw] error al consultar: {e}")
            continue
        status = sc.get("status", status)
        if progress:
            st = (sc.get("scanner") or {}).get("status") or []
            if isinstance(st, list) and len(st) >= 2 and st[1]:
                progress(min(int(st[0]), int(st[1])), max(int(st[1]), 1))
            else:
                progress({"queued": 5, "started": 50, "finishing_up": 90}.get(status, 100 if status in _TERMINAL else 25), 100)
        log(f"[snyk-aw] escaneo {sid} estado={status} (L{sc.get('lows', '?')}/M{sc.get('mediums', '?')}/H{sc.get('highs', '?')})")
        if status in _TERMINAL:
            break
    findings = []
    try:
        findings = [_normalise_finding(f, category) for f in client.pages(f"/targets/{tid}/findings/",
                                                                           {"state": "notfixed"}, 200)]
    except ProbelyError as e:
        log(f"[snyk-aw] no se pudieron listar los hallazgos: {e}")
    findings.sort(key=lambda x: -SEV_RANK.get(x["severity"], 0))
    report_path = ""
    if tpl := cfg.probely_compliance_report:
        try:
            rp = out_dir / f"probely_report_{tpl}.pdf"
            rp.write_bytes(client.req("GET", f"/targets/{tid}/scans/{sid}/report/", params={"report_type": tpl}, raw=True))
            report_path = str(rp)
            log(f"[snyk-aw] reporte de cumplimiento ({tpl}) guardado → {rp}")
        except (ProbelyError, OSError) as e:
            log(f"[snyk-aw] no se pudo descargar el reporte {tpl}: {e}")
    return {"status": status, "cancelled": cancelled or cancel.is_set(), "findings": findings, "target_id": tid,
            "scan_id": sid, "scan_url": f"{PROBELY_APP}/targets/{tid}/scans/{sid}", "report_path": report_path}


def _run_probely_scan(cfg, out_dir: Path, log, cancel, progress, *, out_name, is_api, category, error_category,
                      target_url, summary, skip_log=None):
    out = out_dir / out_name

    def write(s):
        write_json(out, s)
        return s, out
    if skip_log is not None:
        if skip_log:
            log(skip_log)
        return write(summary)
    try:
        client = _Probely(cfg.probely_token, log)
        who = client.whoami()
        log(f"[snyk-aw] autenticado como {who.get('name') or who.get('email') or '?'}")
        target = _ensure_target(client, cfg, url=target_url, is_api=is_api, log=log)
        res = _drive_scan(client, cfg, target, category=category, log=log, cancel=cancel, progress=progress,
                          out_dir=out_dir)
    except ProbelyError as e:
        log(f"[snyk-aw] el escaneo {category.upper()} falló: {e}")
        return write({**summary, "findings": [{"severity": "high", "title": "Falló el escaneo de Snyk API & Web",
                                               "url": target_url, "evidence": str(e), "cwe": "",
                                               "category": error_category}], **({"auth_error": True} if e.is_auth else {})})
    log(f"[snyk-aw] escaneo {category.upper()} completo: {len(res['findings'])} hallazgos ({res['status']}) → {out}")
    return write({**summary, **{k: res[k] for k in ("cancelled", "findings", "target_id", "scan_id", "scan_url",
                                                    "report_path")}, "engine": "snyk-api-web"})


def run_probely_api(cfg, out_dir: Path, log, cancel=None, progress=None):
    cancel = cancel or threading.Event()
    src, url = cfg.spec_source.strip(), cfg.base_url.strip()
    if not url and src:
        try:
            spec = _api_load_spec(*_make_opener(cfg), cfg, log)
            if isinstance(spec, dict):
                url = _api_base_url(spec, cfg, src)
        except Exception as e:
            log(f"[snyk-aw] no se pudo derivar la URL base del API desde la especificación: {e!r}")
    summary = {"target": url, "spec_source": src, "profile": cfg.profile, "endpoints_total": 0, "endpoints_tested": 0,
               "cancelled": cancel.is_set(), "findings": []}
    skip = None
    if not src and not cfg.base_url.strip():
        skip = "[snyk-aw] no hay especificación/URL de API configurada — se omite el escaneo de API"
    elif not url:
        summary["findings"] = [{"severity": "high", "title": "Sin URL base de API", "url": src, "cwe": "",
                                "evidence": "No se pudo determinar la URL del servidor del API para registrarla como "
                                            "target de Probely.", "category": "spec"}]
        skip = ""
    return _run_probely_scan(cfg, out_dir, log, cancel, progress, out_name="api.json", is_api=True, category="api",
                             error_category="spec", target_url=url, summary=summary, skip_log=skip)


def run_probely_dast(cfg, out_dir: Path, log, cancel=None, progress=None):
    cancel = cancel or threading.Event()
    url = cfg.url.strip()
    if url and not url.startswith(("http://", "https://")):
        url = "https://" + url
    summary = {"target": url, "final_url": url, "profile": cfg.profile, "auth_type": cfg.auth_type, "pages_visited": 0,
               "forms_discovered": 0, "relogins": 0, "cancelled": cancel.is_set(), "findings": []}
    skip = "[snyk-aw] no hay URL de DAST configurada — se omite el escaneo DAST" if not url or url == "https://" else None
    return _run_probely_scan(cfg, out_dir, log, cancel, progress, out_name="dast.json", is_api=False, category="dast",
                             error_category="dast", target_url=url, summary=summary, skip_log=skip)


def check_snyk_api_web(cfg, log=lambda *_: None) -> tuple[bool, str]:
    if not cfg.probely_token:
        return False, "No hay clave de API de Probely — Ciberseguridad debe configurarla en Administración."
    try:
        who = _Probely(cfg.probely_token, log).whoami()
        return True, f"Autenticado como {who.get('name') or who.get('email') or '?'}"
    except ProbelyError as e:
        return False, str(e)


def fetch_scan_profiles(token: str, target_type: str, log=lambda *_: None) -> list[tuple[str, str]]:
    if not token:
        return []
    try:
        return [(p["id"].strip(), (p.get("name") or p["id"]).strip())
                for p in _Probely(token, log).pages("/scan-profiles/", {"type": target_type}, 20) if (p.get("id") or "").strip()]
    except ProbelyError as e:
        log(f"[snyk-aw] no se pudieron listar los perfiles de escaneo: {e}")
        return []
