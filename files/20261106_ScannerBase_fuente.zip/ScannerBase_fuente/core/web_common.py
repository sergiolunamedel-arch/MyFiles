"""Capa común de escaneo web/API, independiente del motor (ZAP/Nuclei de código abierto o Probely).

Contiene la configuración de escaneo, el parseo de especificaciones (OpenAPI/Swagger/Postman), el control del
navegador (Selenium) para grabar y reproducir el login, y utilidades de red. La interfaz vive en gui_dast_api_tab.py;
los motores en oss_web_scanner.py y probely_engine.py.
"""
from __future__ import annotations

import base64
import ssl
import time
from dataclasses import dataclass
from http.cookiejar import CookieJar
from urllib.error import HTTPError
from urllib.parse import parse_qsl, urlencode, urljoin, urlparse
from urllib.request import HTTPCookieProcessor, HTTPSHandler, ProxyHandler, Request, build_opener

from ui_common import *

MACRO_JS = r"""
(function(){
  if (window.__macro_installed) return;
  window.__macro_installed = true;
  var KEY = '__vulnscan_macro__';

  function _readStore(store){
    try { return JSON.parse(store.getItem(KEY) || '[]'); } catch(e){ return []; }
  }
  function load(){
    var a = _readStore(sessionStorage);
    var b = _readStore(localStorage);
    if (!b.length) return a;
    if (!a.length) return b;
    var seen = {}, out = [];
    a.concat(b).forEach(function(e){
      var k = e && e.i;
      if (k == null || !seen[k]) { if (k != null) seen[k] = 1; out.push(e); }
    });
    out.sort(function(x, y){ return (x.i || 0) - (y.i || 0); });
    return out;
  }
  function save(a){
    var s = JSON.stringify(a);
    try { sessionStorage.setItem(KEY, s); } catch(e){}
    try { localStorage.setItem(KEY, s); } catch(e){}
  }
  function push(entry){
    var a = load();
    entry.i   = (a.length ? a[a.length-1].i : 0) + 1;
    entry.url = location.href;
    a.push(entry); save(a);
  }

  function esc(s){
    return (window.CSS && CSS.escape) ? CSS.escape(s)
      : String(s).replace(/[^a-zA-Z0-9_-]/g, function(c){ return '\\' + c; });
  }
  function attr(el, name){ try { return el.getAttribute(name); } catch(e){ return null; } }

  function _isDynId(id){
    if (!id) return false;
    if (/\d{6,}/.test(id)) return true;
    if (/^:r[0-9a-z]+:$/i.test(id)) return true;
    if (/^ember\d+$/i.test(id)) return true;
    if (/^__BVID__\d+/.test(id)) return true;
    if (/^yui_/.test(id)) return true;
    if (/^mat-(input|select|checkbox|radio|slide-toggle)-\d+$/.test(id)) return true;
    return false;
  }

  function sel(el){
    if (!el || el.nodeType !== 1) return null;
    var tag = el.tagName.toLowerCase();
    if (el.id && !_isDynId(el.id)) return '#' + esc(el.id);
    var dt = attr(el,'data-testid')||attr(el,'data-test')||attr(el,'data-cy')||attr(el,'data-qa');
    if (dt) return tag + '[data-testid="' + String(dt).replace(/"/g,'\\"') + '"]';
    if (el.name) return tag + '[name="' + esc(el.name) + '"]';
    var ac = attr(el,'autocomplete');
    if (ac && ac !== 'on' && ac !== 'off'){
      var t2 = attr(el,'type');
      return tag + (t2 ? '[autocomplete="'+ac+'"][type="'+t2+'"]'
                       : '[autocomplete="'+ac+'"]');
    }
    var al = attr(el,'aria-label');
    if (al) return tag + '[aria-label="' + String(al).replace(/"/g,'\\"').slice(0,60) + '"]';
    var parts = [], p = el, depth = 0;
    while (p && p.nodeType === 1 && depth < 6){
      if (p.id && !_isDynId(p.id)){ parts.unshift('#' + esc(p.id)); break; }
      var n = p.tagName.toLowerCase();
      if (p.classList && p.classList.length)
        n += '.' + Array.from(p.classList).slice(0,2).map(esc).join('.');
      var par = p.parentNode;
      if (par){ var idx = Array.from(par.children).indexOf(p)+1; if(idx) n+=':nth-child('+idx+')'; }
      parts.unshift(n); p = p.parentElement; depth++;
    }
    return parts.join(' > ');
  }

  function fallbackSels(el){
    if (!el || el.nodeType !== 1) return [];
    var tag = el.tagName.toLowerCase(), fb = [];
    if (el.id) fb.push('#' + esc(el.id));
    var t = attr(el,'type'); if (t) fb.push(tag+'[type="'+t+'"]');
    var ph = attr(el,'placeholder');
    if (ph) fb.push(tag+'[placeholder="'+String(ph).replace(/"/g,'\\"').slice(0,60)+'"]');
    var parts2=[], p2=el, d2=0;
    while(p2 && p2.nodeType===1 && d2<6){
      if(p2.id){ parts2.unshift('#'+esc(p2.id)); break; }
      var n2=p2.tagName.toLowerCase();
      if(p2.classList && p2.classList.length) n2+='.'+Array.from(p2.classList).slice(0,2).map(esc).join('.');
      var par2=p2.parentNode;
      if(par2){ var idx2=Array.from(par2.children).indexOf(p2)+1; if(idx2) n2+=':nth-child('+idx2+')'; }
      parts2.unshift(n2); p2=p2.parentElement; d2++;
    }
    var fp=parts2.join(' > '); if(fp && fp!==fb[0]) fb.push(fp);
    return fb;
  }

  function role(el){
    var type = (el.type || '').toLowerCase();
    var ac   = (attr(el,'autocomplete') || '').toLowerCase();
    if (type === 'password' || ac === 'current-password' || ac === 'new-password') return 'password';
    if (ac === 'username' || ac === 'email' || type === 'email') return 'username';
    var hay = ((el.name||'')+' '+(el.id||'')+' '+(el.placeholder||'')+' '+(attr(el,'aria-label')||'')).toLowerCase();
    if (/(user|email|e-?mail|login|logon|correo|usuario|account|cuenta|phone|tel|m[oó]vil|dni|nif|rfc|curp)/.test(hay)) return 'username';
    return 'other';
  }

  function recordField(el){
    if (!el || !('value' in el) || el.type === 'hidden') return;
    var r = role(el);
    push({ kind:'field', selector: sel(el), fallback_selectors: fallbackSels(el),
           value: el.value, ftype: (el.type || 'text').toLowerCase(), role: r });
  }

  document.addEventListener('input',  function(e){ recordField(e.target); }, true);
  document.addEventListener('change', function(e){ recordField(e.target); }, true);
  document.addEventListener('click',  function(e){
    if (!e.isTrusted) return;
    var t = e.target;
    var b = (t && t.closest) ? t.closest('button,a,input[type=submit],input[type=button],[role=button]') : null;
    var tgt = b || t;
    var href = '';
    if (tgt.tagName === 'A') {
      href = tgt.getAttribute('href') || '';
    } else {
      var anc = tgt.closest ? tgt.closest('a') : null;
      if (anc) href = anc.getAttribute('href') || '';
    }
    var rawText = (tgt.innerText || tgt.value || tgt.getAttribute('aria-label') || '').trim();
    var rawId   = (tgt.id || '');
    var rawCls  = (tgt.className && typeof tgt.className === 'string') ? tgt.className : '';
    var anc2 = tgt.parentElement;
    for (var d = 0; d < 3 && anc2 && anc2.nodeType === 1; d++, anc2 = anc2.parentElement) {
      if (!rawId  && anc2.id)       rawId  = anc2.id;
      if (!rawCls && anc2.className && typeof anc2.className === 'string') rawCls = anc2.className;
      if (!rawText && anc2.innerText) rawText = anc2.innerText.trim().slice(0, 80);
    }
    var dataAction = attr(tgt,'data-action')||attr(tgt,'data-event')||
                     attr(tgt,'data-cy')||attr(tgt,'data-testid')||'';
    push({ kind:'click', selector: sel(tgt),
           fallback_selectors: fallbackSels(tgt),
           href: href,
           text: rawText.slice(0, 80),
           el_id: rawId.slice(0, 80),
           el_cls: rawCls.slice(0, 120),
           data_action: dataAction.slice(0, 80) });
  }, true);
  document.addEventListener('submit', function(e){
    var f = e.target;
    var b = (f && f.querySelector)
      ? f.querySelector('button[type=submit],input[type=submit],button:not([type])') : null;
    push({ kind:'submit', form: sel(f), button: b ? sel(b) : null });
  }, true);
  document.addEventListener('keydown', function(e){
    if (!e.isTrusted || e.key !== 'Enter') return;
    var t = e.target;
    if (t && 'value' in t) recordField(t);
    var f = (t && t.form) ? t.form : (t && t.closest ? t.closest('form') : null);
    push({ kind:'enter', selector: sel(t), form: f ? sel(f) : null });
  }, true);
})();
"""


MACRO_DRAIN_JS = r"""
return (function(){
  try {
    var KEY = '__vulnscan_macro__';
    function rd(store){ try { return JSON.parse(store.getItem(KEY) || '[]'); } catch(e){ return []; } }
    var a = rd(sessionStorage), b = rd(localStorage);
    var seen = {}, out = [];
    a.concat(b).forEach(function(e){
      var k = e && e.i;
      if (k == null || !seen[k]) { if (k != null) seen[k] = 1; out.push(e); }
    });
    out.sort(function(x, y){ return (x.i || 0) - (y.i || 0); });
    try { sessionStorage.setItem(KEY, '[]'); } catch(e){}
    try { localStorage.setItem(KEY, '[]'); } catch(e){}
    return JSON.stringify(out);
  } catch(e){ return '[]'; }
})();
"""


LOGOUT_CAPTURE_JS = r"""
return (function(){
    var url   = window.location.href;
    var title = document.title || '';
    var hints = [];
    var seen  = {};
    var nodes = document.querySelectorAll(
        'h1,h2,input[type=email],input[type=text],input[type=password],' +
        'input[name*=user],input[name*=login],a[href*=login],a[href*=signin],' +
        'button,input[type=submit]');
    nodes.forEach(function(el){
        if (el.offsetParent === null && el.tagName !== 'INPUT') return;
        var t = (el.innerText||el.value||el.placeholder||'')+'';
        t = t.replace(/\s+/g,' ').trim().slice(0,80);
        if(!t || seen[t.toLowerCase()]) return;
        seen[t.toLowerCase()] = 1;
        hints.push(t);
    });
    var hasPassword  = !!document.querySelector('input[type=password]');
    var hasLoginForm = !!document.querySelector(
        'form[action*=login],form[action*=signin],form[id*=login],' +
        'form[class*=login],form[id*=signin],form[class*=signin]');
    return JSON.stringify({
        url: url,
        title: title,
        hints: hints.slice(0, 12),
        has_password_field: hasPassword,
        has_login_form: hasLoginForm
    });
})();
"""


USER_AGENT = "BBScanner/1.0 (Snyk API & Web / Probely API client)"


LOGOUT_KW = ("logout", "log-out", "signout", "sign-out", "cerrar sesión", "cerrar sesion", "cerrar", "salir",
             "log out", "sign out", "desconectar", "logoff", "log-off")


_LOGOUT_RE = re.compile(r"(?i)(logout|log[\s_-]?out|sign[\s_-]?out|signoff|cerrar[\s_-]?sesi[oó]n|salir)")


_LOGOUT_PATH_RE = re.compile(r"(?i)(log-?out|log-?off|sign-?out|signout|cerrar[-_]?sesi|salir|desconect|deslog|/exit\b|"
                             r"/api/logout)")


_COMMON_LOGOUT_PATHS = ("/logout", "/logoff", "/log-off", "/signout", "/sign-out", "/cerrar-sesion", "/cerrarsesion",
                        "/cerrar_sesion", "/salir", "/desconectar", "/desconexion", "/api/logout")


DEFAULT_LOGOUT_MARKERS = ("Iniciar sesión", "Iniciar sesion", "Su sesión ha expirado", "Su sesión ha caducado",
                          "Sesión expirada", "Sesión caducada", "Vuelva a iniciar sesión", "Usuario y contraseña",
                          "Acceso denegado", "Sign in", "Log in", "Your session has expired", "Session expired",
                          "Please log in again")


@dataclass
class ScanConfig:
    url: str = ""
    spec_source: str = ""
    base_url: str = ""
    auth_type: str = "none"
    username: str = ""
    password: str = ""
    token: str = ""
    cookie: str = ""
    header_name: str = ""
    header_value: str = ""
    login_url: str = ""
    login_data: str = ""
    profile: str = ""
    timeout: int = 12
    verify_tls: bool = True
    proxy: str = ""
    selenium_browser: str = "chrome"
    selenium_binary: str = ""
    selenium_wait_seconds: int = 15
    selenium_login_url: str = ""
    selenium_user_selector: str = ""
    selenium_user_value: str = ""
    selenium_pass_selector: str = ""
    selenium_pass_value: str = ""
    selenium_submit_selector: str = ""
    selenium_extra_steps: str = ""
    selenium_macro: str = ""
    selenium_logout_macro: str = ""
    login_success_text: str = ""
    logout_url_re: str = ""
    # ── Motores de código abierto (ZAP + Nuclei) ──
    scan_minutes: int = 30
    ajax_spider: bool = False
    exclude_paths: str = ""
    rate_limit: int = 50
    engine: str = "oss"
    # ── Probely (solo administración) ──
    probely_token: str = ""
    probely_target_id: str = ""
    probely_scan_profile: str = ""
    probely_login_sequence_path: str = ""
    probely_poll_interval: float = 15.0
    probely_max_wait_minutes: float = 180.0
    probely_reuse_by_url: bool = True
    probely_blacklist: str = ""
    probely_logout_detection: bool = True
    probely_check_session_url: str = ""
    probely_logout_markers: str = ""
    probely_logout_condition: str = "any"
    probely_logout_url_detector: bool = True
    probely_logout_code_detector: bool = True
    probely_logout_selector: str = ""
    probely_logout_body_markers: str = ""
    probely_logout_header_markers: str = ""
    probely_login_url: str = ""
    probely_protect_session: bool = True
    probely_form_login: str = "auto"
    probely_form_login_check_pattern: str = ""
    probely_form_submit_selector: str = ""
    probely_2fa_enabled: bool = False
    probely_otp_secret: str = ""
    probely_otp_field: str = ""
    probely_otp_submit: str = ""
    probely_otp_algorithm: str = "SHA1"
    probely_otp_digits: int = 6
    probely_reduced_scopes: str = ""
    probely_ignore_blackout: bool = False
    probely_compliance_report: str = ""
    probely_agent_warn: bool = True
    probely_require_verified: bool = False
    probely_check_login: bool = True
    probely_api_schema_type: str = ""
    probely_api_login_url: str = ""
    probely_api_login_payload: str = ""
    probely_api_login_media_type: str = "application/json"
    probely_api_login_token_field: str = ""
    probely_api_login_token_param: str = "Authorization"
    probely_api_login_token_prefix: str = ""
    probely_api_login_place: str = "header"


DastConfig = ApiConfig = ScanConfig

# Perfiles de escaneo unificados: los mismos nombres que usa Probely, así la configuración sirve para ambos motores.
SCAN_PROFILES = {
    "lightning": ("Rápido", "Rastreo breve y revisión pasiva. Minutos. Ideal para validar que todo funciona."),
    "safe": ("Seguro", "Rastreo completo y pruebas no intrusivas (sin ataques). Apto para entornos compartidos."),
    "normal": ("Estándar", "Rastreo + escaneo activo con límite de tiempo. Recomendado para QA/desarrollo."),
    "full": ("Completo", "Máxima cobertura: rastreo JavaScript, escaneo activo extenso y fuzzing. Puede tardar horas."),
}
PROFILE_ALIASES = {"(predeterminado)": "normal", "passive": "safe", "active": "full", "": "normal"}


def norm_profile(p: str) -> str:
    p = (p or "").strip()
    p = PROFILE_ALIASES.get(p, p)
    return p if p in SCAN_PROFILES else "normal"


def _make_opener(cfg):
    ctx = ssl.create_default_context()
    ctx.verify_flags &= ~getattr(ssl, "VERIFY_X509_STRICT", 0)  # Python ≥3.13 vs CA de proxy corporativo
    if not cfg.verify_tls:
        ctx.check_hostname, ctx.verify_mode = False, ssl.CERT_NONE
    handlers = [HTTPCookieProcessor(CookieJar()), HTTPSHandler(context=ctx)]
    if cfg.proxy:
        handlers.append(ProxyHandler({"http": cfg.proxy, "https": cfg.proxy}))
    hdrs = {"User-Agent": USER_AGENT, "Accept": "*/*"}
    if cfg.auth_type == "basic" and cfg.username:
        hdrs["Authorization"] = "Basic " + base64.b64encode(f"{cfg.username}:{cfg.password}".encode()).decode()
    elif cfg.auth_type == "bearer" and cfg.token:
        hdrs["Authorization"] = f"Bearer {cfg.token}"
    elif cfg.auth_type == "cookie" and cfg.cookie:
        hdrs["Cookie"] = cfg.cookie
    elif cfg.auth_type == "header" and cfg.header_name:
        hdrs[cfg.header_name] = cfg.header_value
    return build_opener(*handlers), hdrs


def _fetch(opener, hdrs, url, timeout=12):
    try:
        with opener.open(Request(url, headers=hdrs), timeout=timeout) as r:
            return r.status, r.read(1_500_000)
    except HTTPError as e:
        return e.code, b""
    except Exception:
        return 0, b""


_BROWSER_ENGINE = {"chrome": "chromium", "chromium": "chromium", "brave": "chromium", "opera": "chromium",
                   "opera_gx": "chromium", "vivaldi": "chromium", "edge": "edge", "firefox": "firefox"}


_BROWSER_CATALOG = [
    ("chrome", "Google Chrome", [r"%ProgramFiles%\Google\Chrome\Application\chrome.exe",
                                 r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe",
                                 r"%LocalAppData%\Google\Chrome\Application\chrome.exe"]),
    ("edge", "Microsoft Edge", [r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe",
                                r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"]),
    ("firefox", "Mozilla Firefox", [r"%ProgramFiles%\Mozilla Firefox\firefox.exe",
                                    r"%ProgramFiles(x86)%\Mozilla Firefox\firefox.exe"]),
    ("brave", "Brave", [r"%ProgramFiles%\BraveSoftware\Brave-Browser\Application\brave.exe",
                        r"%ProgramFiles(x86)%\BraveSoftware\Brave-Browser\Application\brave.exe",
                        r"%LocalAppData%\BraveSoftware\Brave-Browser\Application\brave.exe"]),
    ("opera", "Opera", [r"%LocalAppData%\Programs\Opera\opera.exe", r"%ProgramFiles%\Opera\opera.exe",
                        r"%ProgramFiles(x86)%\Opera\opera.exe"]),
    ("opera_gx", "Opera GX", [r"%LocalAppData%\Programs\Opera GX\opera.exe", r"%ProgramFiles%\Opera GX\opera.exe"]),
    ("vivaldi", "Vivaldi", [r"%LocalAppData%\Vivaldi\Application\vivaldi.exe",
                            r"%ProgramFiles%\Vivaldi\Application\vivaldi.exe"]),
    ("chromium", "Chromium", [r"%LocalAppData%\Chromium\Application\chrome.exe",
                              r"%ProgramFiles%\Chromium\Application\chrome.exe"]),
]


def detect_browsers() -> dict:
    found = {}
    for key, name, paths in _BROWSER_CATALOG:
        if p := next((q for q in map(os.path.expandvars, paths) if os.path.exists(q)), None):
            found[key] = {"name": name, "binary": p, "engine": _BROWSER_ENGINE[key]}
    return found


_DRIVER_CACHE = Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "vuln-scanner" / "driver_paths.json"


def _driver_cache() -> dict:
    return read_json(_DRIVER_CACHE) or {}


def _remember_driver(engine: str, path) -> None:
    if path and Path(path).exists() and _driver_cache().get(engine) != str(path):
        try:
            write_json(_DRIVER_CACHE, {**_driver_cache(), engine: str(path)})
        except Exception:
            pass


def _set_command_timeout(drv, seconds: float = 60.0) -> None:
    ce = getattr(drv, "command_executor", None)
    for fn in (lambda: setattr(ce._client_config, "timeout", seconds), lambda: setattr(ce, "_timeout", seconds)):
        try:
            fn()
            return
        except Exception:
            pass


_BROWSER_GONE = ("no such window", "target window already closed", "web view not found",
                 "browsing context has been discarded", "disconnected", "invalid session id", "session deleted",
                 "session not found", "chrome not reachable", "unable to connect to renderer", "connection refused",
                 "connection reset", "connection aborted", "remote end closed connection", "read timed out",
                 "newconnectionerror", "max retries exceeded")


def _browser_is_gone(exc: BaseException) -> bool:
    msg = f"{exc!r} {exc}".lower()
    return any(m in msg for m in _BROWSER_GONE)


_CHROMIUM_FAST = ("--no-first-run", "--no-default-browser-check", "--no-service-autorun", "--disable-extensions",
                  "--disable-background-networking", "--disable-component-update", "--disable-default-apps",
                  "--disable-sync", "--disable-translate", "--disable-background-timer-throttling",
                  "--disable-backgrounding-occluded-windows", "--disable-renderer-backgrounding",
                  "--metrics-recording-only", "--mute-audio", "--password-store=basic", "--use-mock-keychain",
                  "--disable-features=Translate,OptimizationHints,MediaRouter,CalculateNativeWinOcclusion",
                  "--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu")


def _make_driver(cfg, *, headless: bool, log=lambda _: None):
    from selenium import webdriver
    browser = (cfg.selenium_browser or "chrome").lower()
    engine = _BROWSER_ENGINE.get(browser, "chromium")
    binary = cfg.selenium_binary or ("" if browser in ("chrome", "edge", "firefox")
                                     else detect_browsers().get(browser, {}).get("binary", ""))
    log(f"[dast] iniciando {browser} (motor={engine}, headless={headless}, binario={binary or 'auto'})")
    if engine == "firefox":
        from selenium.webdriver.firefox.service import Service
        opts = webdriver.FirefoxOptions()
        if headless:
            opts.add_argument("-headless")
        if cfg.proxy:
            host, _, port = cfg.proxy.replace("http://", "").replace("https://", "").partition(":")
            opts.set_preference("network.proxy.type", 1)
            for s in ("http", "ssl"):
                opts.set_preference(f"network.proxy.{s}", host)
                opts.set_preference(f"network.proxy.{s}_port", int(port or 8080))
        cls, fallback = webdriver.Firefox, lambda: __import__(
            "webdriver_manager.firefox", fromlist=["x"]).GeckoDriverManager().install()
    else:
        if engine == "edge":
            from selenium.webdriver.edge.options import Options
            from selenium.webdriver.edge.service import Service
            opts, cls = Options(), webdriver.Edge
            fallback = lambda: __import__("webdriver_manager.microsoft", fromlist=["x"]).EdgeChromiumDriverManager().install()
        else:
            from selenium.webdriver.chrome.service import Service
            opts, cls = webdriver.ChromeOptions(), webdriver.Chrome

            def fallback():
                from webdriver_manager.chrome import ChromeDriverManager
                try:
                    from webdriver_manager.core.os_manager import ChromeType
                    ct = {"brave": ChromeType.BRAVE, "chromium": ChromeType.CHROMIUM}.get(browser, ChromeType.GOOGLE)
                    return ChromeDriverManager(chrome_type=ct).install()
                except Exception:
                    return ChromeDriverManager().install()
        if headless:
            opts.add_argument("--headless=new")
        for a in _CHROMIUM_FAST:
            opts.add_argument(a)
        if not cfg.verify_tls:
            opts.add_argument("--ignore-certificate-errors")
        if cfg.proxy:
            opts.add_argument(f"--proxy-server={cfg.proxy}")
    try:
        opts.page_load_strategy = "eager"
    except Exception:
        pass
    if binary:
        opts.binary_location = binary
    if not cfg.verify_tls:
        opts.set_capability("acceptInsecureCerts", True)
    try:
        cached = _driver_cache().get(engine)
        drv = cls(service=Service(executable_path=cached), options=opts) if cached and Path(cached).exists() \
            else cls(options=opts)
        _remember_driver(engine, getattr(getattr(drv, "service", None), "path", None))
    except Exception as e:
        log(f"[dast] Selenium Manager ({engine}) falló ({e!r}); usando webdriver-manager")
        p = fallback()
        _remember_driver(engine, p)
        drv = cls(service=Service(p), options=opts)
    _set_command_timeout(drv)
    return drv


def prewarm_driver(cfg=None, log=lambda _: None) -> None:
    try:
        cfg = cfg or ScanConfig(url="https://")
        cached = _driver_cache().get(_BROWSER_ENGINE.get((cfg.selenium_browser or "chrome").lower(), "chromium"))
        if cached and Path(cached).exists():
            return
        log("[dast] precalentando webdriver (una sola vez, en segundo plano)…")
        _make_driver(cfg, headless=True, log=log).quit()
        log("[dast] webdriver listo — el navegador abrirá al instante a partir de ahora.")
    except Exception as e:
        log(f"[dast] precalentamiento del driver omitido: {e!r}")


_VIS_JS = ("var r=arguments[0].getBoundingClientRect(),s=window.getComputedStyle(arguments[0]);"
           "return r.width>0&&r.height>0&&s.visibility!='hidden'&&s.display!='none'&&s.opacity!='0';")


_CLICK_JS = "arguments[0].dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:window}));"


_SCROLL_JS = "arguments[0].scrollIntoView({block:'nearest'});"


_HREF_JS = ("var e=arguments[0];if(e.tagName==='A')return e.getAttribute('href')||'';"
            "var a=e.closest?e.closest('a'):null;return a?(a.getAttribute('href')||''):'';")


_ROLE_SEL = {"password": ["input[type=password]"],
             "username": ["input[type=email]", "input[autocomplete=username]", "input[autocomplete=email]",
                          "input[type=text][name*=user]", "input[type=text][name*=email]",
                          "input[type=text][name*=login]", "input[type=text]"]}


def _is_pass(step) -> bool:
    return step.get("role") == "password" or step.get("ftype") == "password"


def _is_logout_step(step) -> bool:
    blob = " ".join(str(step.get(k) or "") for k in ("href", "text", "el_id", "el_cls", "data_action")).lower()
    return any(k in blob for k in LOGOUT_KW)


def _replay_login_macro(driver, macro, *, pass_value=None, wait_seconds=15, log=lambda *_: None) -> bool:
    from selenium.webdriver.common.by import By
    from selenium.webdriver.common.keys import Keys
    if not isinstance(macro, list) or not macro:
        return False

    def visible(css, timeout):
        deadline = time.time() + max(timeout, 0.5)
        while time.time() < deadline:
            try:
                driver.switch_to.default_content()
                for el in driver.find_elements(By.CSS_SELECTOR, css):
                    try:
                        if driver.execute_script(_VIS_JS, el):
                            return el
                    except Exception:
                        if el.is_displayed():
                            return el
                for fr in driver.find_elements(By.TAG_NAME, "iframe"):
                    try:
                        driver.switch_to.default_content()
                        driver.switch_to.frame(fr)
                        if el := next((e for e in driver.find_elements(By.CSS_SELECTOR, css) if e.is_displayed()), None):
                            return el
                    except Exception:
                        pass
                driver.switch_to.default_content()
            except Exception:
                pass
            time.sleep(0.15)
        try:
            driver.switch_to.default_content()
        except Exception:
            pass
        return None

    def find_field(step, timeout):
        cands = [step.get("selector")] + [f for f in step.get("fallback_selectors") or [] if f != step.get("selector")]
        for i, css in enumerate(c for c in cands if c):
            if el := visible(css, timeout):
                if i:
                    log(f"[replay] coincidió alternativo: {css}")
                return el
            log(f"[replay] no visible: {css}")
        role = "password" if _is_pass(step) else "username" if step.get("role") == "username" else None
        for css in _ROLE_SEL.get(role, []):
            if el := visible(css, max(timeout * 0.4, 1.5)):
                log(f"[replay] alternativo por rol ({role}): {css}")
                return el
        return None

    def type_into(el, val):
        for fn in (el.click, el.clear, lambda: el.send_keys(val)):
            try:
                fn()
            except Exception:
                pass
        try:
            if (el.get_attribute("value") or "") == str(val):
                return True
            driver.execute_script("arguments[0].value=arguments[1];"
                                  "arguments[0].dispatchEvent(new Event('input',{bubbles:true}));"
                                  "arguments[0].dispatchEvent(new Event('change',{bubbles:true}));", el, str(val))
            return bool(el.get_attribute("value"))
        except Exception:
            return False

    def click(el):
        try:
            driver.execute_script(_SCROLL_JS, el)
            time.sleep(0.1)
        except Exception:
            pass
        try:
            el.click()
        except Exception:
            try:
                driver.execute_script(_CLICK_JS, el)
            except Exception:
                pass

    typed = False
    per_wait = max(3, min(int(wait_seconds or 15), 15))
    for step in (s for s in macro if isinstance(s, dict)):
        kind, sel = step.get("kind"), step.get("selector")
        try:
            if kind == "field":
                val = step.get("value")
                if _is_pass(step) and not val and pass_value:
                    val = pass_value
                if not val or not (sel or step.get("fallback_selectors")):
                    continue
                el = find_field(step, per_wait)
                if not el:
                    log(f"[replay] campo no encontrado: {sel}")
                elif type_into(el, val):
                    typed = typed or _is_pass(step)
                    log("[replay] contraseña escrita ✓" if _is_pass(step) else f"[replay] escrito en {sel[:60]}")
            elif kind == "click" and sel:
                el = visible(sel, per_wait)
                if el and _is_logout_step(step):
                    href = ""
                    try:
                        href = driver.execute_script(_HREF_JS, el)
                    except Exception:
                        pass
                    if href and href not in ("#", "javascript:void(0)", "javascript:;"):
                        full = urljoin(driver.current_url, href)
                        log(f"[replay] logout → navegando: {full}")
                        try:
                            driver.get(full)
                        except Exception as ex:
                            log(f"[replay] navegación de logout falló ({ex!r}), se hace clic")
                            click(el)
                        time.sleep(1.5)
                    else:
                        click(el)
                        time.sleep(1.0)
                    log("[replay] logout hecho")
                elif el:
                    click(el)
                    log(f"[replay] clic en {sel[:60]}")
                    time.sleep(0.8)
                else:
                    try:
                        driver.execute_script("var e=document.querySelector(arguments[0]);if(e)e.dispatchEvent(new "
                                              "MouseEvent('click',{bubbles:true,cancelable:true,view:window}));", sel)
                        log(f"[replay] clic por JS (no visible): {sel[:60]}")
                        time.sleep(0.8)
                    except Exception:
                        log(f"[replay] objetivo de clic no encontrado: {sel[:60]}")
            elif kind == "enter":
                if el := visible(sel, 2) if sel else None:
                    el.send_keys(Keys.ENTER)
                    log("[replay] Enter presionado")
                elif step.get("form"):
                    driver.switch_to.default_content()
                    driver.execute_script("var f=document.querySelector(arguments[0]);"
                                          "if(f){if(f.requestSubmit)f.requestSubmit();else f.submit();}", step["form"])
                    log("[replay] formulario enviado (enter→form)")
                time.sleep(0.6)
            elif kind == "submit":
                if step.get("button") and (el := visible(step["button"], 2)):
                    click(el)
                    log("[replay] clic en botón de envío")
                elif step.get("form"):
                    driver.switch_to.default_content()
                    driver.execute_script("var fs=document.querySelectorAll(arguments[0]);for(var i=0;i<fs.length;i++)"
                                          "{if(fs[i].offsetParent!==null){if(fs[i].requestSubmit)fs[i].requestSubmit();"
                                          "else fs[i].submit();return;}}", step["form"])
                    log("[replay] formulario enviado")
                time.sleep(0.8)
        except Exception as e:
            log(f"[replay] paso {step!r} falló: {e!r}")
    try:
        driver.switch_to.default_content()
    except Exception:
        pass
    return typed


def _api_load_spec(opener, hdrs, cfg, log) -> Optional[dict]:
    src = (cfg.spec_source or "").strip()
    if not src:
        return None
    if src.startswith(("http://", "https://")):
        log(f"[api] descargando especificación: {src}")
        st, body = _fetch(opener, hdrs, src, timeout=cfg.timeout)
        if not (st and body):
            log(f"[api] no se pudo descargar la especificación (HTTP {st})")
            return None
        raw = body.decode("utf-8", errors="replace")
    elif Path(src).exists():
        raw = Path(src).read_text(encoding="utf-8", errors="replace")
    else:
        log(f"[api] especificación no encontrada: {src}")
        return None
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        pass
    try:
        import yaml
    except ModuleNotFoundError:
        log("[api] la especificación no es JSON y PyYAML no está instalado (pip install pyyaml).")
        return None
    try:
        return yaml.safe_load(raw)
    except Exception as e:
        log(f"[api] la especificación no es JSON ni YAML válido: {e!r}")
        return None


def _deref(spec, node, seen=None):
    seen = seen or set()
    while isinstance(node, dict) and isinstance(node.get("$ref"), str):
        ref = node["$ref"]
        if not ref.startswith("#/") or ref in seen:
            return node
        seen.add(ref)
        cur = spec
        for part in ref[2:].split("/"):
            part = part.replace("~1", "/").replace("~0", "~")
            if not (isinstance(cur, dict) and part in cur):
                return node
            cur = cur[part]
        node = cur
    return node


def _sample(spec, schema, depth=0):
    schema = _deref(spec, schema) or {}
    if not isinstance(schema, dict) or depth > 4:
        return "test"
    for k in ("example", "default"):
        if k in schema:
            return schema[k]
    if schema.get("enum"):
        return schema["enum"][0]
    t = schema.get("type")
    if t == "object" or "properties" in schema:
        props, req = schema.get("properties") or {}, set(schema.get("required") or [])
        return {k: _sample(spec, props[k], depth + 1) for k in ([k for k in props if not req or k in req] or list(props)[:3])}
    if t == "array":
        return [_sample(spec, schema.get("items") or {}, depth + 1)]
    if t in ("integer", "number"):
        return 1
    if t == "boolean":
        return True
    return {"date-time": "2020-01-01T00:00:00Z", "date": "2020-01-01", "email": "test@example.com",
            "uuid": "00000000-0000-0000-0000-000000000000"}.get(schema.get("format"), "test")


def _subst_server_vars(url: str, server: dict) -> str:
    variables = server.get("variables") if isinstance(server.get("variables"), dict) else {}

    def repl(m):
        v = variables.get(m.group(1))
        if isinstance(v, dict):
            if v.get("default") not in (None, ""):
                return str(v["default"])
            if isinstance(v.get("enum"), list) and v["enum"]:
                return str(v["enum"][0])
        return "1"
    return re.sub(r"\{([^/{}]+)\}", repl, url)


def _api_base_url(spec: dict, cfg, src: str) -> str:
    base = cfg.base_url.strip()
    if not base and isinstance(spec.get("servers"), list) and spec["servers"]:
        srv = spec["servers"][0] if isinstance(spec["servers"][0], dict) else {}
        base = _subst_server_vars(srv.get("url", "") or "", srv)
    elif not base and spec.get("host"):
        base = f"{(spec.get('schemes') or ['https'])[0]}://{spec['host']}{spec.get('basePath', '')}"
    if (base.startswith("/") or not base) and src.startswith(("http://", "https://")):
        base = urljoin(src, base or "/")
    if base and not base.startswith(("http://", "https://")):
        base = "https://" + base.lstrip("/")
    return base.rstrip("/")


def _postman_ops(coll: dict, base: str) -> list[dict]:
    cvars = {str(v["key"]): "" if v.get("value") is None else str(v["value"])
             for v in coll.get("variable") or [] if isinstance(v, dict) and v.get("key") is not None}
    blanks = ("baseurl", "base_url", "url", "host", "server", "endpoint", "apiurl", "api_url", "domain")
    resolve = lambda t: re.sub(r"\{\{\s*([^}]+?)\s*\}\}", lambda m: cvars.get(
        m.group(1), "" if m.group(1).lower() in blanks else "test"), t)
    ops = []

    def walk(items):
        for it in items or []:
            if not isinstance(it, dict):
                continue
            if "item" in it:
                walk(it["item"])
                continue
            req = it.get("request")
            if not isinstance(req, dict):
                continue
            u = req.get("url")
            url = (u.get("raw") or "") if isinstance(u, dict) else u if isinstance(u, str) else ""
            query = [(q["key"], q.get("value") or "test") for q in (u.get("query") or [])
                     if isinstance(q, dict) and q.get("key")] if isinstance(u, dict) else []
            url = re.sub(r"\{[^/{}]+\}", "1", re.sub(r"/:(\w+)", "/test", resolve(url).split("#", 1)[0]))
            if url and not url.startswith(("http://", "https://")) and base:
                url = base + "/" + url.lstrip("/")
            body = ctype = jb = None
            b = req.get("body") or {}
            if isinstance(b, dict) and b.get("mode") == "raw" and b.get("raw"):
                try:
                    jb, body, ctype = json.loads(b["raw"]), b["raw"].encode(), "application/json"
                except Exception:
                    pass
            if url.startswith(("http://", "https://")):
                ops.append({"method": (req.get("method") or "GET").upper(), "url": url, "query": query,
                            "secured": bool(req.get("auth")) or any(
                                isinstance(h, dict) and (h.get("key") or "").lower() == "authorization"
                                for h in req.get("header") or []),
                            "body": body, "ctype": ctype, "json_body": jb})
    walk(coll.get("item"))
    return ops


def _api_operations(spec: dict, base: str) -> list[dict]:
    if "item" in spec and "paths" not in spec:
        return _postman_ops(spec, base)
    ops, gsec = [], spec.get("security")
    for path, item in (spec.get("paths") or {}).items() if isinstance(spec.get("paths"), dict) else []:
        item = _deref(spec, item)
        if not isinstance(path, str) or not isinstance(item, dict):
            continue
        common = [_deref(spec, p) for p in item.get("parameters") or []]
        for method in ("get", "post", "put", "patch", "delete", "options", "head"):
            op = item.get(method)
            if not isinstance(op, dict):
                continue
            sec = op.get("security", gsec)
            filled, query = path, []
            for p in common + [_deref(spec, p) for p in op.get("parameters") or []]:
                if not isinstance(p, dict) or not p.get("name"):
                    continue
                val = _sample(spec, p.get("schema") or {k: p[k] for k in ("type", "enum", "format") if k in p})
                val = val if isinstance(val, (str, int, float, bool)) else "test"
                if p.get("in") == "path":
                    filled = filled.replace("{" + p["name"] + "}", str(val))
                elif p.get("in") == "query":
                    query.append((p["name"], str(val)))
            filled = re.sub(r"\{[^/{}]+\}", "1", filled)
            body = ctype = jb = None
            rb = _deref(spec, op["requestBody"]) if op.get("requestBody") else None
            content = rb.get("content") or {} if isinstance(rb, dict) else {}
            if "application/json" in content:
                jb = _sample(spec, (content["application/json"] or {}).get("schema") or {})
                body, ctype = json.dumps(jb).encode(), "application/json"
            else:
                for ct in ("application/x-www-form-urlencoded", "multipart/form-data"):
                    if ct in content and isinstance(s := _sample(spec, (content[ct] or {}).get("schema") or {}), dict):
                        body, ctype = urlencode(s).encode(), "application/x-www-form-urlencoded"
                        break
            url = base + (filled if filled.startswith("/") else "/" + filled)
            if query:
                url += ("&" if "?" in url else "?") + urlencode(query)
            ops.append({"method": method.upper(), "url": url, "secured": bool(sec) and sec != [{}], "query": query,
                        "body": body, "ctype": ctype, "json_body": jb})
    return ops


def analyze_login_macro(macro: list) -> tuple:
    pass_entry = next((s for s in reversed(macro) if s.get("kind") == "field" and s.get("selector") and _is_pass(s)), None)
    pos = macro.index(pass_entry) if pass_entry else len(macro)
    before = [s for s in macro[:pos] if s.get("kind") == "field" and s.get("selector")]
    user = next((s for s in reversed(before) if s.get("role") == "username"), None) or \
        next((s for s in reversed(before) if not _is_pass(s)), None)
    submit = next((s["selector"] for s in macro[pos + 1:] if s.get("kind") == "click" and s.get("selector")), None) or \
        next((s["button"] for s in macro if s.get("kind") == "submit" and s.get("button")), None)
    return (user and user["selector"], user and user.get("value"), pass_entry and pass_entry["selector"],
            pass_entry and pass_entry.get("value"), submit)


def _drain(driver) -> list:
    return json.loads(driver.execute_script(MACRO_DRAIN_JS) or "[]")


def _record_loop(driver, done, result, acc: list, interval: float, log, tag: str, on_chunk=None) -> bool:
    try:
        driver.execute_script(MACRO_JS)
    except Exception:
        pass
    while not done.is_set():
        gone = False
        try:
            driver.execute_script("if(!window.__macro_installed){" + MACRO_JS + "}")
        except Exception as e:
            gone = _browser_is_gone(e)
        try:
            if chunk := _drain(driver):
                acc.extend(chunk)
                if on_chunk:
                    on_chunk()
        except Exception as e:
            gone = gone or _browser_is_gone(e)
        if gone:
            log(f"[{tag}] la ventana del navegador se cerró — se detiene la grabación.")
            result["_cancelled"] = True
            return False
        if done.wait(interval):
            break
    try:
        acc.extend(_drain(driver))
    except Exception:
        pass
    return True


def record_macro_work(cfg, emit_log=lambda _: None):
    def work(driver, url, done, result, set_status=lambda _: None):
        emit_log(f"[macro] abriendo {url} — inicie sesión y luego presione Ctrl+Shift+F12 para capturar")
        driver.get(url)
        result["_nav_done"].set()
        set_status("✅  Inicie sesión normalmente y luego presione Ctrl+Shift+F12")
        acc: list = []
        if _record_loop(driver, done, result, acc, 0.4, emit_log, "macro"):
            result["macro"] = json.dumps(acc)
    return work


def _replay_saved_login(driver, cfg, log, per_wait):
    from selenium.webdriver.common.by import By
    from selenium.webdriver.common.keys import Keys
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.support.ui import WebDriverWait
    try:
        macro = json.loads(cfg.selenium_macro) if cfg.selenium_macro.strip() else []
    except Exception as e:
        macro = []
        log(f"[logout-rec] JSON de macro inválido: {e!r}")
    pw = cfg.selenium_pass_value.strip()
    if macro:
        return _replay_login_macro(driver, macro, pass_value=pw or None, wait_seconds=cfg.selenium_wait_seconds, log=log)

    def find(sel):
        try:
            return WebDriverWait(driver, per_wait).until(EC.presence_of_element_located((By.CSS_SELECTOR, sel)))
        except Exception:
            log(f"[logout-rec] selector no encontrado: {sel}")
    for sel, val in ((cfg.selenium_user_selector, cfg.selenium_user_value), (cfg.selenium_pass_selector, pw)):
        if sel and val and (el := find(sel)):
            try:
                el.clear()
                el.send_keys(val)
            except Exception:
                pass
    if cfg.selenium_submit_selector and (el := find(cfg.selenium_submit_selector)):
        try:
            el.click()
        except Exception:
            pass
    elif cfg.selenium_pass_selector and pw:
        try:
            driver.find_element(By.CSS_SELECTOR, cfg.selenium_pass_selector).send_keys(Keys.ENTER)
        except Exception:
            pass


_PW_VISIBLE_JS = ("var ps=document.querySelectorAll('input[type=password]');for(var i=0;i<ps.length;i++){"
                  "var r=ps[i].getBoundingClientRect(),s=window.getComputedStyle(ps[i]);if(r.width>0&&r.height>0&&"
                  "s.visibility!=='hidden'&&s.display!=='none'&&s.opacity!=='0')return true;}return false;")


def record_logout_work(cfg, emit_log=lambda _: None):
    def work(driver, url, done, result, set_status=lambda _: None):
        from selenium.webdriver.support.ui import WebDriverWait
        login_url = (cfg.selenium_login_url or url).strip()
        can_replay = bool(cfg.selenium_macro.strip() or cfg.selenium_user_selector or cfg.selenium_submit_selector
                          or cfg.selenium_extra_steps or (cfg.selenium_pass_selector and cfg.selenium_pass_value)) \
            and not (cfg.selenium_pass_selector and not cfg.selenium_pass_value.strip())
        per_wait = max(2, min(int(cfg.selenium_wait_seconds or 15), 8))
        emit_log(f"[logout-rec] navegando a la página de login: {login_url}")
        set_status("⏳  Abriendo la página de login…")
        try:
            driver.get(login_url)
        except Exception as e:
            emit_log(f"[logout-rec] error de navegación: {e!r}")
        result["_nav_done"].set()
        time.sleep(1.0)
        if not can_replay:
            emit_log("[logout-rec] no hay login reproducible — esperando login MANUAL")
            set_status("👤  Inicie sesión a mano, vaya a la página sin sesión → Ctrl+Shift+F12")
        else:
            emit_log("[logout-rec] reproduciendo el login guardado…")
            set_status("🔁  Reproduciendo el login guardado…")
            _replay_saved_login(driver, cfg, emit_log, per_wait)
            try:
                driver.switch_to.default_content()
            except Exception:
                pass
            set_status("⏳  Esperando que termine el login…")
            if not done.is_set():
                try:
                    if cfg.login_success_text.strip():
                        WebDriverWait(driver, per_wait).until(lambda d: cfg.login_success_text in d.page_source)
                        emit_log("[logout-rec] login confirmado (texto presente)")
                    else:
                        time.sleep(2.5)
                        emit_log(f"[logout-rec] login reproducido (heurística sesión={not driver.execute_script(_PW_VISIBLE_JS)})")
                except Exception:
                    emit_log("[logout-rec] no se confirmó el login a tiempo — se continúa")
        set_status("✅  Con sesión — abra el menú de usuario, haga clic en Cerrar sesión y luego Ctrl+Shift+F12")
        emit_log("[logout-rec] grabación iniciada — haga clic en Cerrar sesión ahora")
        acc: list = []
        if not _record_loop(driver, done, result, acc, 0.15, emit_log, "logout-rec",
                            lambda: emit_log(f"[logout-rec] {len(acc)} pasos: {[s.get('kind') for s in acc]}")):
            return
        clicks = [s for s in acc if s.get("kind") == "click"]
        hrefs = list(dict.fromkeys(s["href"] for s in clicks if s.get("href") and _is_logout_step(s)))
        keys = ("selector", "fallback_selectors", "href", "text", "el_id", "el_cls", "data_action")
        result["last_logout_click"] = {k: clicks[-1].get(k, [] if k == "fallback_selectors" else "") for k in keys} \
            if clicks else {}
        set_status("📸  Capturando el estado sin sesión…")
        snap = {}
        try:
            snap = json.loads(driver.execute_script(LOGOUT_CAPTURE_JS) or "{}")
        except Exception as e:
            emit_log(f"[logout-rec] error de captura JS: {e!r}")
        result.update(snapshot=snap if isinstance(snap, dict) else {}, logout_macro=acc, logout_href_candidates=hrefs)
        try:
            result["final_url"] = driver.current_url
        except Exception:
            result["final_url"] = result["snapshot"].get("url", "")
        emit_log(f"[logout-rec] listo. final_url={result['final_url']!r} pasos={len(acc)} hrefs={hrefs!r}")
    return work


def _host_looks_non_public(url: str) -> bool:
    import ipaddress
    import socket
    host = (urlparse(url).hostname or "").strip().lower()
    if not host:
        return False
    if host == "localhost" or host.endswith((".local", ".internal", ".lan", ".test", ".localhost")):
        return True
    private = lambda ip: ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved
    try:
        return private(ipaddress.ip_address(host))
    except ValueError:
        pass
    try:
        addrs = {i[4][0] for i in socket.getaddrinfo(host, None)}
        return not addrs or all(private(ipaddress.ip_address(a)) for a in addrs)
    except Exception:
        return True


def _split(s: str) -> list[str]:
    return [p.strip() for p in re.split(r"[\n,]+", s or "") if p.strip()]


def session_headers(cfg, log=lambda *_: None) -> dict:
    """Obtiene las cabeceras de una sesión autenticada para entregarlas a cualquier motor.

    basic/bearer/cookie/header se traducen directo; «form» inicia sesión con un POST y conserva las cookies;
    «selenium» reproduce el login grabado en un navegador sin ventana y extrae sus cookies.
    """
    auth = (cfg.auth_type or "none").lower()
    if auth == "basic" and cfg.username:
        return {"Authorization": "Basic " + base64.b64encode(f"{cfg.username}:{cfg.password}".encode()).decode()}
    if auth == "bearer" and cfg.token:
        return {"Authorization": f"Bearer {cfg.token}"}
    if auth == "cookie" and cfg.cookie:
        return {"Cookie": cfg.cookie}
    if auth == "header" and cfg.header_name:
        return {cfg.header_name.strip(): cfg.header_value}
    if auth == "form" and cfg.login_url and cfg.login_data:
        jar = CookieJar()
        ctx = ssl.create_default_context()
        ctx.verify_flags &= ~getattr(ssl, "VERIFY_X509_STRICT", 0)  # Python ≥3.13 vs CA de proxy corporativo
        if not cfg.verify_tls:
            ctx.check_hostname, ctx.verify_mode = False, ssl.CERT_NONE
        opener = build_opener(HTTPCookieProcessor(jar), HTTPSHandler(context=ctx))
        try:
            opener.open(Request(cfg.login_url, headers={"User-Agent": USER_AGENT}), timeout=cfg.timeout or 15).read(1)
            body = urlencode(parse_qsl(cfg.login_data.strip(), keep_blank_values=True)).encode()
            opener.open(Request(cfg.login_url, data=body, headers={
                "User-Agent": USER_AGENT, "Content-Type": "application/x-www-form-urlencoded"}),
                timeout=cfg.timeout or 15).read(1)
        except Exception as e:
            log(f"[sesión] el login por formulario falló: {e!r}")
        cookies = "; ".join(f"{c.name}={c.value}" for c in jar)
        log(f"[sesión] login por formulario: {len(list(jar))} cookie(s) obtenidas")
        return {"Cookie": cookies} if cookies else {}
    if auth == "selenium" and (cfg.selenium_macro.strip() or cfg.selenium_user_selector):
        driver = None
        try:
            driver = _make_driver(cfg, headless=True, log=log)
            driver.get((cfg.selenium_login_url or cfg.url).strip())
            time.sleep(1.0)
            _replay_saved_login(driver, cfg, log, max(3, min(int(cfg.selenium_wait_seconds or 15), 15)))
            time.sleep(2.5)
            cookies = "; ".join(f"{c['name']}={c['value']}" for c in driver.get_cookies() if c.get("name"))
            log(f"[sesión] login grabado reproducido: {len(driver.get_cookies())} cookie(s) capturadas")
            return {"Cookie": cookies} if cookies else {}
        except Exception as e:
            log(f"[sesión] no se pudo reproducir el login grabado: {e!r} — se escaneará sin autenticar")
        finally:
            if driver is not None:
                try:
                    driver.quit()
                except Exception:
                    pass
    return {}


def logout_excludes(cfg) -> list[str]:
    """Regex de URLs que el escáner NO debe visitar (logout) — evita que cierre su propia sesión."""
    out = [r for r in _split(cfg.exclude_paths) if r]
    if (cfg.logout_url_re or "").strip():
        out.append(cfg.logout_url_re.strip())
    out.append(r".*(log-?out|log-?off|sign-?out|cerrar[-_]?sesi|salir).*")
    return list(dict.fromkeys(out))
