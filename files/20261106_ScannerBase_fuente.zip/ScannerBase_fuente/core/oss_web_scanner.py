"""Escaneo web (DAST) y de API con motores de código abierto: OWASP ZAP + Nuclei, en paralelo.

· ZAP corre en modo comando con el Automation Framework (sin Docker, sin interfaz, con Java portátil):
  rastreo (spider / AJAX spider), escaneo pasivo y activo, importación de OpenAPI/GraphQL/Postman.
· Nuclei aporta miles de plantillas de vulnerabilidades conocidas y, en perfiles altos, fuzzing DAST.
· La sesión autenticada (login grabado, formulario, token, cookie…) se obtiene una vez y se inyecta en ambos
  motores como cabeceras; las URLs de logout se excluyen para que el escáner no cierre su propia sesión.
· Los resultados se normalizan y fusionan (findings.merge): un mismo problema visto por ZAP y por Nuclei queda como
  UN hallazgo con «Detectado por: ZAP, Nuclei» y las descripciones/remediaciones de ambos.

El formato de salida (dast.json / api.json) es compatible con el reporte y la sincronización de ServiceNow.
"""
from __future__ import annotations

import queue as _queue
import time
from urllib.parse import urlparse

from ui_common import *
import findings as fz
import tool_manager as tm
from web_common import (_api_base_url, _api_load_spec, _api_operations, _fetch, _make_opener, logout_excludes,
                        norm_profile, session_headers)

ZAP_PROFILE = {  # (minutos spider, ajax, pasivo, activo)
    "lightning": (2, False, 2, False), "safe": (8, False, 5, False),
    "normal": (8, False, 5, True), "full": (15, True, 10, True)}
NUCLEI_EXCLUDE = "dos,fuzz,intrusive,bruteforce,brute-force,fuzzing,dast,osint,local"
_ZAP_RISK = {3: "high", 2: "medium", 1: "low", 0: "info"}


class EngineError(RuntimeError):
    pass


# ── Ejecución de procesos con progreso y cancelación ────────────────────────
def _stream(cmd, *, log, cancel, timeout_s, on_line=None, cwd=None, env=None, tag="motor") -> int:
    log(f"[{tag}] $ {' '.join(str(c) for c in cmd[:6])}{' …' if len(cmd) > 6 else ''}")
    proc = subprocess.Popen([str(c) for c in cmd], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                            encoding="utf-8", errors="replace", cwd=str(cwd) if cwd else None, env=env, **NOWIN)
    q: _queue.Queue = _queue.Queue()

    def reader():
        try:
            for line in iter(proc.stdout.readline, ""):
                q.put(line.rstrip())
        except Exception:
            pass
    threading.Thread(target=reader, daemon=True).start()
    deadline = time.monotonic() + timeout_s
    while True:
        try:
            while True:
                line = q.get(timeout=0.5)
                if line and on_line:
                    on_line(line)
        except _queue.Empty:
            pass
        if proc.poll() is not None:
            while not q.empty():
                if (line := q.get()) and on_line:
                    on_line(line)
            return proc.returncode
        if cancel is not None and cancel.is_set():
            log(f"[{tag}] cancelado por el usuario — deteniendo el motor…")
            kill_process_tree(proc)
            return -1
        if time.monotonic() > deadline:
            log(f"[{tag}] se alcanzó el tiempo máximo ({timeout_s // 60} min) — se detiene y se usan los resultados parciales")
            kill_process_tree(proc)
            return -2


# ── ZAP ──────────────────────────────────────────────────────────────────────
def _zap_home(kind: str) -> Path:
    return TOOLS_DIR / "zap-home" / kind


def _zap_prepare(java: str, jar: str, home: Path, log) -> None:
    marker = home / ".addons_ok"
    if marker.exists():
        return
    home.mkdir(parents=True, exist_ok=True)
    log("[zap] primera ejecución: preparando add-ons (OpenAPI, GraphQL, Postman, AJAX spider)…")
    r = run([java, "-Xmx1g", "-jar", jar, "-cmd", "-dir", str(home), "-addonupdate", "-addoninstall", "openapi",
             "-addoninstall", "graphql", "-addoninstall", "postman", "-addoninstall", "spiderAjax"], timeout=900)
    if r.returncode:
        log("[zap] no se pudieron actualizar todos los add-ons (¿sin acceso al marketplace?) — se usan los incluidos: "
            + ((r.stdout or "") + (r.stderr or "")).strip()[-300:])
    marker.write_text(now_human(), encoding="utf-8")


def _zap_plan(cfg, *, kind, target, headers, profile, spec_file, spec_url, schema_type, out_dir) -> dict:
    spider_min, ajax, passive_min, active = ZAP_PROFILE[profile]
    budget = max(5, int(cfg.scan_minutes or 30))
    p = urlparse(target)
    origin = f"{p.scheme}://{p.netloc}"
    ctx = {"name": "bbscanner", "urls": [target], "includePaths": [re.escape(origin) + ".*"],
           "excludePaths": logout_excludes(cfg)}
    jobs = []
    if headers:
        jobs.append({"type": "replacer", "rules": [
            {"description": f"bbscanner-{n}", "matchType": "req_header", "matchString": n, "matchRegex": False,
             "replacementString": v, "tokenProcessing": False} for n, v in headers.items()]})
    if kind == "api":
        st = schema_type or "openapi"
        if st == "graphql":
            jobs.append({"type": "graphql", "parameters": {"endpoint": target, **(
                {"schemaFile": spec_file} if spec_file else {"schemaUrl": spec_url} if spec_url else {})}})
        elif st == "postman" and spec_file:
            jobs.append({"type": "postman", "parameters": {"collectionFile": spec_file}})
        elif spec_file or spec_url:
            jobs.append({"type": "openapi", "parameters": {"context": "bbscanner", "targetUrl": target, **(
                {"apiFile": spec_file} if spec_file else {"apiUrl": spec_url})}})
    else:
        jobs.append({"type": "spider", "parameters": {"context": "bbscanner", "url": target,
                                                      "maxDuration": min(spider_min, budget), "maxDepth": 8}})
        if ajax or cfg.ajax_spider:
            jobs.append({"type": "spiderAjax", "parameters": {"context": "bbscanner", "url": target,
                                                              "maxDuration": min(10, budget),
                                                              "browserId": "chrome-headless"}})
    jobs.append({"type": "passiveScan-wait", "parameters": {"maxDuration": passive_min}})
    if active:
        jobs.append({"type": "activeScan", "parameters": {"context": "bbscanner", "maxScanDurationInMins": budget,
                                                          "maxRuleDurationInMins": max(2, budget // 6)}})
    jobs.append({"type": "report", "parameters": {"template": "traditional-json", "reportDir": str(out_dir),
                                                  "reportFile": f"zap_{kind}"}})
    return {"env": {"contexts": [ctx], "parameters": {"failOnError": False, "failOnWarning": False,
                                                      "progressToStdout": True}}, "jobs": jobs}


def _parse_zap(path: Path, kind: str) -> tuple[list, int]:
    data = read_json(path) or {}
    data = data if isinstance(data, dict) else {}
    out, info = [], 0
    sites = data.get("site") if isinstance(data.get("site"), list) else [data.get("site")]
    for site in [x for x in sites if isinstance(x, dict)]:
        for a in [x for x in (site.get("alerts") if isinstance(site.get("alerts"), list) else []) if isinstance(x, dict)]:
            try:
                try:
                    risk = _ZAP_RISK.get(int(a.get("riskcode", 0)), "low")
                except (TypeError, ValueError):
                    risk = "low"
                if risk == "info":
                    info += 1
                    continue
                inst = a.get("instances") or [{}]
                first = inst[0]
                cwe = fz.norm_cwes(a.get("cweid"))
                title = a.get("name") or a.get("alert") or "Alerta de ZAP"
                ev = (first.get("evidence") or first.get("attack") or "").strip()
                f = {"severity": risk, "title": title, "url": first.get("uri") or site.get("@name", ""),
                     "method": first.get("method", ""), "param": first.get("param", ""),
                     "evidence": (ev + (f"\n(+{len(inst) - 1} URL(s) más)" if len(inst) > 1 else ""))[:600],
                     "cwe": ", ".join(cwe), "description": fz.strip_html(a.get("desc", ""))[:1500],
                     "remediation": fz.strip_html(a.get("solution", ""))[:1200],
                     "references": [r for r in re.split(r"\s+", fz.strip_html(a.get("reference", ""))) if r.startswith("http")],
                     "rule_id": f"zap-{a.get('pluginid', '')}", "instances": [i.get("uri", "") for i in inst[:25]],
                     "category": fz.category_for(cwe, title), "detected_by": ["ZAP"]}
                f["sources"] = [fz.source("ZAP", f)]
                out.append(f)
            except Exception:
                continue   # alerta mal formada: se omite sin perder el resto
    return out, info


def run_zap(cfg, *, kind, target, headers, profile, spec_file, spec_url, schema_type, out_dir, log, cancel, progress):
    java = tm.ensure("jre", log)
    jar = tm.ensure("zap", log)
    home = _zap_home(kind)
    _zap_prepare(java, jar, home, log)
    plan = _zap_plan(cfg, kind=kind, target=target, headers=headers, profile=profile, spec_file=spec_file,
                     spec_url=spec_url, schema_type=schema_type, out_dir=out_dir)
    import yaml
    plan_path = Path(out_dir) / f"zap_plan_{kind}.yaml"
    plan_path.write_text(yaml.safe_dump(plan, sort_keys=False, allow_unicode=True), encoding="utf-8")
    total = len(plan["jobs"])
    done = {"n": 0}

    def on_line(line):
        low = line.lower()
        if re.search(r"job \S+ (finished|ended)", low):
            done["n"] += 1
            progress and progress(min(done["n"], total), total)
        if any(k in low for k in ("job ", "error", "exception", "warn")) and "debug" not in low:
            log(f"[zap] {line[:220]}")
    budget = max(5, int(cfg.scan_minutes or 30))
    rc = _stream([java, "-Xmx2g", "-jar", jar, "-cmd", "-dir", str(home), "-autorun", str(plan_path)],
                 log=log, cancel=cancel, timeout_s=(budget + 25) * 60, on_line=on_line, cwd=Path(jar).parent, tag="zap")
    report = Path(out_dir) / f"zap_{kind}.json"
    if not report.exists():
        raise EngineError(f"ZAP terminó (código {rc}) sin generar reporte")
    res, info = _parse_zap(report, kind)
    log(f"[zap] {len(res)} alerta(s) relevantes, {info} informativa(s)")
    return res, info, str(report)


# ── Nuclei ───────────────────────────────────────────────────────────────────
def _nuclei_templates(exe: str, log, cancel) -> None:
    if time.time() - tm.stamp("nuclei", "templates_at") < 24 * 3600:
        return
    log("[nuclei] actualizando plantillas (una vez al día)…")
    rc = _stream([exe, "-ut", "-duc", "-nc"], log=log, cancel=cancel, timeout_s=900, tag="nuclei",
                 on_line=lambda l: ("error" in l.lower() or "templates" in l.lower()) and log(f"[nuclei] {l[:200]}"))
    if rc == 0:
        tm.touch("nuclei", "templates_at")
    else:
        log("[nuclei] no se pudieron actualizar las plantillas — se usan las ya descargadas si existen")


def _parse_nuclei(path: Path) -> tuple[list, int]:
    out, info, seen = [], 0, set()
    if not path.exists():
        return out, 0
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            j = json.loads(line)
        except Exception:
            continue
        if not isinstance(j, dict):
            continue
        try:
            f = _nuclei_finding(j, seen)
        except Exception:
            continue   # entrada mal formada: se omite sin perder el resto
        if f == "info":
            info += 1
        elif f:
            out.append(f)
    return out, info


def _nuclei_finding(j: dict, seen: set):
    inf = j.get("info") if isinstance(j.get("info"), dict) else {}
    s = fz.sev(inf.get("severity"))
    if s == "info":
        return "info"
    cl = inf.get("classification") if isinstance(inf.get("classification"), dict) else {}
    url = str(j.get("matched-at") or j.get("url") or j.get("host") or "")
    key = (str(j.get("template-id")), url, str(j.get("matcher-name")))
    if key in seen:
        return None
    seen.add(key)
    cwe = fz.norm_cwes(cl.get("cwe-id"))
    refs = inf.get("reference") or []
    ex = j.get("extracted-results")
    ev = (", ".join(map(str, ex)) if isinstance(ex, list) else str(ex or "")) or j.get("matcher-name") or ""
    cves = ", ".join(map(str, cl.get("cve-id") or [])) if isinstance(cl.get("cve-id"), list) else str(cl.get("cve-id") or "")
    f = {"severity": s, "title": str(inf.get("name") or j.get("template-id") or "Hallazgo de Nuclei"),
         "url": url, "method": "", "param": j.get("fuzzing_parameter") or "", "evidence": str(ev)[:600],
         "cwe": ", ".join(cwe), "cve": cves, "description": str(inf.get("description") or "").strip()[:1500],
         "remediation": str(inf.get("remediation") or "").strip()[:1200],
         "references": [r for r in (refs if isinstance(refs, list) else [refs]) if isinstance(r, str) and r],
         "rule_id": j.get("template-id", ""),
         "category": fz.category_for(cwe, str(inf.get("name") or "")), "detected_by": ["Nuclei"]}
    f["sources"] = [fz.source("Nuclei", f)]
    return f


def run_nuclei(cfg, *, kind, target, headers, profile, spec_file, schema_type, out_dir, log, cancel, progress):
    exe = tm.ensure("nuclei", log)
    _nuclei_templates(exe, log, cancel)
    out = Path(out_dir) / f"nuclei_{kind}.jsonl"
    extra = Path(out_dir) / f"nuclei_{kind}_dast.jsonl"
    for f in (out, extra):
        f.unlink(missing_ok=True)

    def common(dest: Path) -> list:
        args = ["-jsonl", "-o", str(dest), "-nc", "-duc", "-ni", "-or", "-silent", "-stats", "-sj", "-si", "10",
                "-rl", str(max(5, int(cfg.rate_limit or 50))), "-timeout", "10", "-retries", "1",
                "-severity", "low,medium,high,critical"]
        for n, v in (headers or {}).items():
            args += ["-H", f"{n}: {v}"]
        return args
    budget = max(5, int(cfg.scan_minutes or 30))

    def on_line(line):
        if line.startswith("{") and '"percent"' in line:
            try:
                progress and progress(int(float(json.loads(line).get("percent") or 0)), 100)
            except Exception:
                pass
        elif "[err" in line.lower() or "fatal" in line.lower():
            log(f"[nuclei] {line[:220]}")
    excl = {"lightning": ["-as", "-etags", NUCLEI_EXCLUDE], "safe": ["-etags", NUCLEI_EXCLUDE],
            "normal": ["-etags", NUCLEI_EXCLUDE], "full": ["-etags", "dos,bruteforce,brute-force"]}[profile]
    runs = [[exe, "-u", target, *common(out), *excl]]
    if kind == "api" and spec_file and schema_type in ("openapi", "swagger") and profile in ("normal", "full"):
        txt = Path(spec_file).read_text(encoding="utf-8", errors="replace")[:4000]
        mode = "swagger" if re.search(r'["\']?swagger["\']?\s*:', txt) else "openapi"
        runs.append([exe, "-l", spec_file, "-im", mode, "-dast", "-sfv", *common(extra)])
    elif kind == "dast" and profile == "full":
        runs.append([exe, "-u", target, "-dast", *common(extra)])
    for cmd in runs:
        if cancel is not None and cancel.is_set():
            break
        _stream(cmd, log=log, cancel=cancel, timeout_s=(budget + 10) * 60, on_line=on_line, tag="nuclei")
    res, info = _parse_nuclei(out)
    if extra.exists():
        r2, i2 = _parse_nuclei(extra)
        res, info = res + r2, info + i2
    log(f"[nuclei] {len(res)} hallazgo(s) relevantes, {info} informativo(s)")
    return res, info, str(out)


# ── Orquestación ─────────────────────────────────────────────────────────────
def _materialize_spec(cfg, out_dir: Path, log) -> tuple[str, str, str]:
    """Devuelve (archivo_local, url_original, tipo). Descarga la especificación si es una URL."""
    src = (cfg.spec_source or "").strip()
    st = (cfg.probely_api_schema_type or "").strip().lower()
    if not src:
        return "", "", st or "openapi"
    if not st:
        low = src.lower()
        st = "graphql" if low.endswith((".graphql", ".gql", ".graphqls")) else "openapi"
        if not src.startswith(("http://", "https://")) and Path(src).exists():
            try:
                d = json.loads(Path(src).read_text(encoding="utf-8", errors="replace"))
                if isinstance(d, dict) and "item" in d and "paths" not in d:
                    st = "postman"
            except Exception:
                pass
    if src.startswith(("http://", "https://")):
        opener, hdrs = _make_opener(cfg)
        code, body = _fetch(opener, hdrs, src, timeout=cfg.timeout or 15)
        if code and body:
            ext = ".json" if body.lstrip()[:1] in (b"{", b"[") else ".yaml"
            p = out_dir / f"api_spec{ext}"
            p.write_bytes(body)
            return str(p), src, st
        log(f"[api] no se pudo descargar la especificación (HTTP {code}) — ZAP la intentará leer por URL")
        return "", src, st
    return (src if Path(src).exists() else ""), "", st


def _scan(kind: str, cfg, out_dir: Path, log, cancel=None, progress=None):
    cancel = cancel or threading.Event()
    out_dir = Path(out_dir)
    profile = norm_profile(cfg.profile)
    if kind == "dast":
        target = (cfg.url or "").strip()
        if target and not target.startswith(("http://", "https://")):
            target = "https://" + target
        spec_file = spec_url = ""
        schema_type = ""
        summary = {"target": target, "final_url": target, "profile": profile, "auth_type": cfg.auth_type,
                   "pages_visited": 0, "forms_discovered": 0}
    else:
        spec_file, spec_url, schema_type = _materialize_spec(cfg, out_dir, log)
        target = (cfg.base_url or "").strip()
        ops = []
        if cfg.spec_source:
            try:
                spec = _api_load_spec(*_make_opener(cfg), cfg, log)
                if isinstance(spec, dict):
                    target = target or _api_base_url(spec, cfg, cfg.spec_source)
                    ops = _api_operations(spec, target or "https://example.com")
            except Exception as e:
                log(f"[api] no se pudo interpretar la especificación para contar endpoints: {e!r}")
        summary = {"target": target, "spec_source": cfg.spec_source, "profile": profile,
                   "endpoints_total": len(ops), "endpoints_tested": len(ops)}
    summary.update(engine="zap+nuclei", cancelled=False, findings=[], engines={}, informational=0)
    if not target:
        raise EngineError("No hay URL objetivo — configure la URL (Web) o la URL base / especificación (API).")
    log(f"[{kind}] motores de código abierto · perfil «{profile}» · objetivo {target}")
    headers = session_headers(cfg, log) if (cfg.auth_type or "none") != "none" else {}
    if headers:
        log(f"[{kind}] sesión autenticada inyectada en ZAP y Nuclei ({', '.join(headers)})")
    pct = {"zap": 0.0, "nuclei": 0.0}

    def prog(name):
        def f(done, total):
            pct[name] = done / max(total, 1)
            progress and progress(int((pct["zap"] + pct["nuclei"]) * 50), 100)
        return f
    results: dict = {}

    def runner(name, fn, **kw):
        try:
            res, info, path = fn(cfg, kind=kind, target=target, headers=headers, profile=profile, spec_file=spec_file,
                                 schema_type=schema_type, out_dir=out_dir, log=log, cancel=cancel, progress=prog(name),
                                 **kw)
            results[name] = (res, info, path)
            summary["engines"][name] = {"status": "ok", "findings": len(res), "report": path}
        except Exception as e:
            log(f"[{kind}] {name.upper()} no pudo completarse: {e}")
            summary["engines"][name] = {"status": "error", "detail": str(e)[:400]}
        finally:
            pct[name] = 1.0
    threads = [threading.Thread(target=runner, args=("zap", run_zap), kwargs={"spec_url": spec_url}, daemon=True),
               threading.Thread(target=runner, args=("nuclei", run_nuclei), daemon=True)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    if not results:
        detail = "; ".join(f"{k}: {v.get('detail', '')}" for k, v in summary["engines"].items())
        raise EngineError(f"Ningún motor de {kind.upper()} pudo ejecutarse — {detail}")
    allf = [f for res, _, _ in results.values() for f in res]
    summary["findings"] = fz.merge(allf, fz.web_key)
    summary["informational"] = sum(i for _, i, _ in results.values())
    summary["cancelled"] = cancel.is_set()
    summary["engine"] = "+".join(k for k in ("zap", "nuclei") if k in results)
    if len(results) < 2:
        summary["partial"] = True
    merged = len(allf) - len(summary["findings"])
    log(f"[{kind}] {len(summary['findings'])} hallazgo(s) tras unificar"
        + (f" ({merged} duplicado(s) entre ZAP y Nuclei fusionados)" if merged else ""))
    out = out_dir / ("dast.json" if kind == "dast" else "api.json")
    write_json(out, summary)
    return summary, out


def run_oss_dast(cfg, out_dir: Path, log, cancel=None, progress=None):
    return _scan("dast", cfg, out_dir, log, cancel, progress)


def run_oss_api(cfg, out_dir: Path, log, cancel=None, progress=None):
    return _scan("api", cfg, out_dir, log, cancel, progress)
