"""SonarQube LOCAL para la etapa IaC — plug and play, sin servidor, cuenta ni configuración.

El programa descarga SonarQube Community Build (gestor de motores, verificado), lo levanta escuchando solo en
127.0.0.1 con su base de datos embebida, crea en el primer arranque una contraseña de administrador aleatoria y un
token, y lo deja corriendo mientras la aplicación esté abierta para que los escaneos siguientes sean rápidos. Se apaga
al cerrar el programa.

Es una instancia desechable por usuario: si sus datos se dañan o cambia de versión, se recrea desde cero (los
hallazgos de cada escaneo ya quedan en el reporte de ScannerBase).
"""
from __future__ import annotations

import atexit
import secrets
import socket
import time

from ui_common import *
import tool_manager as tm

HOME = TOOLS_DIR / "sonarqube-home"           # datos, logs, temporales y estado (fuera de la carpeta del programa)
STATE = HOME / "state.json"
PREFERRED_PORT = 9876
START_TIMEOUT = 420                            # el primer arranque (índices de Elasticsearch) puede tardar ~2–4 min
_lock = threading.Lock()
_proc: dict = {"p": None}


class SonarLocalError(RuntimeError):
    pass


def _state() -> dict:
    return read_json(STATE, {}) or {}


def _save_state(**kw) -> None:
    HOME.mkdir(parents=True, exist_ok=True)
    write_json(STATE, {**_state(), **kw})


def _free(port: int) -> bool:
    with socket.socket() as s:
        try:
            s.bind(("127.0.0.1", port))
            return True
        except OSError:
            return False


def _pick_port() -> int:
    for p in (_state().get("port"), PREFERRED_PORT):
        if p and _free(int(p)):
            return int(p)
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _req(method: str, url: str, auth, log=lambda *_: None, **kw):
    import requests
    try:
        return requests.request(method, url, auth=auth, timeout=kw.pop("timeout", 20), **kw)
    except requests.RequestException:
        return None


def _status(url: str) -> str:
    r = _req("GET", f"{url}/api/system/status", None, timeout=5)
    try:
        return (r.json() or {}).get("status", "") if r is not None and r.ok else ""
    except ValueError:
        return ""


def _token_ok(url: str, token: str) -> bool:
    r = _req("GET", f"{url}/api/authentication/validate", (token, ""), timeout=10)
    try:
        return bool(r is not None and r.ok and r.json().get("valid"))
    except ValueError:
        return False


def _write_properties(home: Path, port: int) -> None:
    """conf/sonar.properties: solo localhost, rutas de datos fuera del programa y memoria acotada (~1.5 GB)."""
    conf = home / "conf" / "sonar.properties"
    data = {
        "sonar.web.host": "127.0.0.1", "sonar.web.port": str(port), "sonar.search.port": "0",
        "sonar.path.data": str(HOME / "data"), "sonar.path.temp": str(HOME / "temp"),
        "sonar.path.logs": str(HOME / "logs"), "sonar.telemetry.enable": "false",
        "sonar.web.javaOpts": "-Xmx512m -Xms128m -XX:+HeapDumpOnOutOfMemoryError",
        "sonar.ce.javaOpts": "-Xmx512m -Xms128m -XX:+HeapDumpOnOutOfMemoryError",
        "sonar.search.javaOpts": "-Xmx512m -Xms512m -XX:MaxDirectMemorySize=256m -XX:+HeapDumpOnOutOfMemoryError",
        "sonar.updatecenter.activate": "false",
    }
    keep = []
    if conf.exists():
        keep = [ln for ln in conf.read_text(encoding="utf-8", errors="replace").splitlines()
                if not any(ln.strip().startswith(k + "=") for k in data)]
    conf.write_text("\n".join(keep + [f"{k}={v}" for k, v in data.items()]) + "\n", encoding="utf-8")


def _launch_cmd(home: Path) -> list:
    if os.name == "nt":
        bat = next(iter(sorted(home.glob("bin/windows-x86-64/StartSonar.bat"))), None)
        if not bat:
            raise SonarLocalError("la instalación de SonarQube no contiene bin/windows-x86-64/StartSonar.bat")
        return ["cmd", "/c", str(bat)]
    sh = next(iter(sorted(home.glob("bin/linux-x86-64/sonar.sh"))), None)
    if not sh:
        raise SonarLocalError("la instalación de SonarQube no contiene bin/linux-x86-64/sonar.sh")
    return [str(sh), "console"]


def _first_setup(url: str, log) -> str:
    """Primer arranque: cambia la contraseña por defecto (admin/admin) por una aleatoria y crea un token propio."""
    st = _state()
    pw = st.get("admin_password")
    if not pw:
        pw = secrets.token_urlsafe(18) + "aA1!"
        r = _req("POST", f"{url}/api/users/change_password", ("admin", "admin"),
                 data={"login": "admin", "previousPassword": "admin", "password": pw})
        if r is None or r.status_code not in (200, 204):
            raise SonarLocalError("no se pudo inicializar el administrador del SonarQube local "
                                  f"(HTTP {getattr(r, 'status_code', '—')})")
        _save_state(admin_password=pw)
    r = _req("POST", f"{url}/api/user_tokens/generate", ("admin", pw),
             data={"name": f"scannerbase-{int(time.time())}"})
    try:
        token = (r.json() or {}).get("token", "") if r is not None and r.ok else ""
    except ValueError:
        token = ""
    if not token:
        raise SonarLocalError(f"no se pudo generar el token del SonarQube local (HTTP {getattr(r, 'status_code', '—')})")
    _save_state(token=token)
    log("[sonarqube] SonarQube local inicializado (contraseña y token propios, solo accesible desde este equipo)")
    return token


def _reset_data(log, why: str) -> None:
    log(f"[sonarqube] {why} — se recrea la instancia local desde cero")
    for sub in ("data", "temp"):
        shutil.rmtree(HOME / sub, ignore_errors=True)
    st = {k: v for k, v in _state().items() if k not in ("admin_password", "token")}
    HOME.mkdir(parents=True, exist_ok=True)
    write_json(STATE, st)


class _Retry(Exception):
    pass


def ensure_running(log=print, cancel=None) -> dict:
    """Devuelve {"url", "token"} de un SonarQube local listo (lo instala y arranca si hace falta)."""
    with _lock:
        for attempt in range(2):
            try:
                return _ensure_once(log, cancel)
            except _Retry:
                if attempt:
                    raise SonarLocalError("no se pudo recrear la instancia local de SonarQube")
    raise SonarLocalError("estado inesperado")


def _ensure_once(log, cancel) -> dict:
    home = Path(tm.ensure("sonarqube", log))
    version = (tm._manifest().get("sonarqube") or {}).get("version", "")
    st = _state()
    url = f"http://127.0.0.1:{st['port']}" if st.get("port") else ""
    if url and _status(url) == "UP":                      # reutiliza la instancia ya levantada (incluso de antes)
        if st.get("token") and _token_ok(url, st["token"]):
            return {"url": url, "token": st["token"]}
        if st.get("admin_password"):
            try:
                return {"url": url, "token": _first_setup(url, log)}
            except SonarLocalError:
                pass
        stop(log)
        _reset_data(log, "credenciales locales inválidas")
        raise _Retry()
    if st.get("version") and st.get("version") != version:
        _reset_data(log, f"SonarQube cambió de versión ({st.get('version')} → {version})")
    port = _pick_port()
    _write_properties(home, port)
    java = (tm._manifest().get("sonarqube") or {}).get("java") or tm.sonarqube_java(log)
    if not Path(java).is_file():
        java = tm.sonarqube_java(log)
    env = dict(os.environ, SONAR_JAVA_PATH=java, JAVA_HOME=str(Path(java).parent.parent))
    (HOME / "logs").mkdir(parents=True, exist_ok=True)
    out = open(HOME / "logs" / "scannerbase_launcher.log", "a", encoding="utf-8", errors="replace")
    log(f"[sonarqube] iniciando SonarQube local en 127.0.0.1:{port} (el primer arranque tarda 2–4 min)…")
    p = subprocess.Popen(_launch_cmd(home), cwd=str(home), env=env, stdout=out, stderr=subprocess.STDOUT, **NOWIN)
    _proc["p"] = p
    _save_state(port=port, pid=p.pid, version=version, started_at=now_human())
    atexit.register(stop)
    url = f"http://127.0.0.1:{port}"
    deadline, last = time.monotonic() + START_TIMEOUT, ""
    while True:
        if cancel is not None and cancel.is_set():
            stop(log)
            raise SonarLocalError("cancelado")
        if p.poll() is not None:
            try:
                tail = (HOME / "logs" / "sonar.log").read_text(encoding="utf-8", errors="replace")[-300:]
            except OSError:
                tail = ""
            raise SonarLocalError(f"SonarQube local se detuvo al arrancar (código {p.returncode}). {tail}")
        status = _status(url)
        if status and status != last:
            log(f"[sonarqube] estado del servidor local: {status}")
            last = status
        if status == "UP":
            break
        if status in ("DB_MIGRATION_NEEDED", "DB_MIGRATION_RUNNING"):
            stop(log)
            _reset_data(log, "la base local necesita migración")
            raise _Retry()
        if time.monotonic() > deadline:
            stop(log)
            raise SonarLocalError(f"SonarQube local no arrancó en {START_TIMEOUT // 60} min (¿poca memoria libre? "
                                  "necesita ~1.5 GB)")
        time.sleep(3)
    token = _state().get("token")
    if not (token and _token_ok(url, token)):
        try:
            token = _first_setup(url, log)
        except SonarLocalError:
            stop(log)
            _reset_data(log, "credenciales locales inválidas")
            raise _Retry()
    log("[sonarqube] SonarQube local listo ✓")
    return {"url": url, "token": token}


def stop(log=lambda *_: None) -> None:
    """Apaga la instancia local (al cerrar el programa o al reinstalar/eliminar SonarQube)."""
    p = _proc.get("p")
    pid = p.pid if p is not None else _state().get("pid")
    if p is not None and p.poll() is None:
        kill_process_tree(p)
    elif pid and pid_alive(pid):
        if os.name == "nt":
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)], capture_output=True, **NOWIN)
        else:
            try:
                os.kill(int(pid), 15)
            except OSError:
                pass
    _proc["p"] = None
    if pid:
        log("[sonarqube] SonarQube local detenido")
