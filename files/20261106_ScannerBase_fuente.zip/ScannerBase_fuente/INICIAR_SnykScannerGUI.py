from __future__ import annotations

import ctypes
import gc
import importlib.util
import json
import os
import queue
import shutil
import site
import subprocess
import sys
import threading
import webbrowser
from datetime import datetime
from pathlib import Path

_BASE = Path(__file__).resolve().parent
if (_BASE / "core").is_dir() and str(_BASE / "core") not in sys.path:
    sys.path.insert(0, str(_BASE / "core"))

try:
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("BancoBase.SecDevOps.SnykScannerGUI")
except Exception:
    pass


def _msgbox(title: str, text: str) -> None:
    try:
        ctypes.windll.user32.MessageBoxW(0, text, title, 0x30)
    except Exception:
        print(f"\n=== {title} ===\n{text}\n")


def _run_elevated_and_wait(exe: str, params: str, timeout_ms: int = 900_000) -> bool:
    from ctypes import wintypes

    class SEI(ctypes.Structure):
        _fields_ = [("cbSize", wintypes.DWORD), ("fMask", ctypes.c_ulong), ("hwnd", wintypes.HWND),
                    ("lpVerb", wintypes.LPCWSTR), ("lpFile", wintypes.LPCWSTR),
                    ("lpParameters", wintypes.LPCWSTR), ("lpDirectory", wintypes.LPCWSTR),
                    ("nShow", ctypes.c_int), ("hInstApp", wintypes.HINSTANCE), ("lpIDList", ctypes.c_void_p),
                    ("lpClass", wintypes.LPCWSTR), ("hkeyClass", ctypes.c_void_p), ("dwHotKey", wintypes.DWORD),
                    ("hIconOrMonitor", wintypes.HANDLE), ("hProcess", wintypes.HANDLE)]

    sei = SEI(cbSize=ctypes.sizeof(SEI), fMask=0x140, lpVerb="runas", lpFile=exe, lpParameters=params, nShow=0)
    if not ctypes.windll.shell32.ShellExecuteExW(ctypes.byref(sei)):
        return False
    if not sei.hProcess:
        return True
    res = ctypes.windll.kernel32.WaitForSingleObject(sei.hProcess, timeout_ms)
    ctypes.windll.kernel32.CloseHandle(sei.hProcess)
    return res == 0


def _repair_tkinter() -> bool:
    import platform
    import tempfile
    import urllib.request
    ver = "{}.{}.{}".format(*sys.version_info[:3])
    arch = "amd64" if platform.architecture()[0] == "64bit" else "win32"
    all_users = sys.prefix.lower().startswith((os.environ.get("ProgramFiles", r"C:\Program Files").lower(),
                                               os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)").lower()))
    cache = Path(os.environ.get("LOCALAPPDATA", "")) / "Package Cache"
    installer = next(cache.glob(f"**/python-{ver}*{arch}.exe"), None) if cache.exists() else None
    tmp = None
    if installer is None:
        try:
            tmp = Path(tempfile.mkdtemp(prefix="tkfix_"))
            installer = tmp / "python_installer.exe"
            urllib.request.urlretrieve(f"https://www.python.org/ftp/python/{ver}/python-{ver}-{arch}.exe", installer)
        except Exception:
            return False
    args = ["/quiet", f"InstallAllUsers={int(all_users)}", "Include_tcltk=1", "Include_test=0", f"TargetDir={sys.prefix}"]
    try:
        if all_users:
            return _run_elevated_and_wait(str(installer), " ".join(f'"{a}"' if " " in a else a for a in args))
        return subprocess.run([str(installer)] + args, timeout=900).returncode == 0
    except Exception:
        return False
    finally:
        if tmp:
            shutil.rmtree(tmp, ignore_errors=True)


def _ensure_tkinter() -> None:
    try:
        import tkinter
        return
    except ImportError:
        pass
    _msgbox("SecDevOps Banco Base — reparando Python",
            "Falta el componente 'tcl/tk' de Python (necesario para la interfaz gráfica). Se intentará "
            "repararlo automáticamente ahora.\n\nPuede tardar uno o dos minutos y pedir permisos de "
            "administrador. No cierre esta ventana.")
    if _repair_tkinter():
        try:
            import tkinter
            return
        except ImportError:
            pass
    _msgbox("SecDevOps Banco Base — reparación manual necesaria",
            "No fue posible instalar tcl/tk automáticamente.\n\nSolución manual:\n"
            "1) Panel de control → Programas y características\n"
            "2) Seleccione su versión de Python → 'Modificar'\n"
            "3) Marque la casilla 'tcl/tk and IDLE'\n"
            "4) Finalice la instalación y vuelva a abrir este programa.")
    sys.exit(1)


_ensure_tkinter()

from ui_common import *
import static_scanner as ss
import secrets_scanner
from gui_apps_tab import _AppsTabMixin, AppInventoryStore
import admin_policy
from gui_admin_tab import _AdminTabMixin
from gui_dast_api_tab import _ApiTabMixin, _DastTabMixin
from gui_infra_tab import _InfraTabMixin
from gui_schedule_tab import _ScheduleTabMixin
from gui_wizard import _WizardMixin
from report_engine import _ReportsTabMixin, ScanStateStore
from scan_pipeline import _ScanTabMixin
from static_scanner import _StaticTabMixin
from web_common import prewarm_driver

BOOT_DEPS = [
    ("jinja2", "Jinja2", "Motor de plantillas de reporte"),
    ("selenium", "selenium", "Automatización de navegador (DAST)"),
    ("webdriver_manager", "webdriver-manager", "Descargador de WebDriver"),
    ("pynput", "pynput", "Escucha de atajos globales (grabador)"),
    ("yaml", "PyYAML", "Parseo de especificaciones YAML (OpenAPI/Swagger)"),
    ("requests", "requests", "Cliente HTTP"),
    ("send2trash", "Send2Trash", "Papelera del sistema (eliminar reportes)"),
]
BOOT_CACHE = DATA_DIR / ".boot_cache.json"
RUNTIME_READY = False


def _pip(args: list[str], log) -> None:
    if getattr(sys, "frozen", False):
        # En el .exe todas las librerías vienen empaquetadas; sys.executable es el propio programa, no Python.
        raise ImportError(f"paquete no incluido en el ejecutable: {' '.join(args)}")
    cmd = [sys.executable, "-m", "pip", "install", "--user", "--disable-pip-version-check", *args]

    def stream(command, env=None):
        proc = subprocess.Popen(command, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                encoding="utf-8", errors="replace", bufsize=1, **NOWIN)
        for line in proc.stdout:
            if line.strip():
                log(line.rstrip())
        return proc.wait()

    if stream(cmd):
        log("pip: reintentando con trusted-host (¿proxy TLS corporativo?)")
        hosts = ("pypi.org", "files.pythonhosted.org", "pypi.python.org")
        env = dict(os.environ, PIP_TRUSTED_HOST=" ".join(hosts))
        if stream(cmd + [a for h in hosts for a in ("--trusted-host", h)], env=env):
            raise subprocess.CalledProcessError(1, cmd)
    if (us := site.getusersitepackages()) not in sys.path:
        sys.path.insert(0, us)


def _ensure(mod: str, pkg: str, log) -> None:
    if mod != "jinja2" and importlib.util.find_spec(mod):
        log(f"{mod}: ya instalado")
        return
    for attempt in range(2):
        try:
            __import__(mod)
            log(f"{mod}: ya instalado")
            return
        except ImportError as e:
            log(f"{mod}: no encontrado — instalando {pkg}…")
            if mod == "jinja2" and ("soft_unicode" in str(e).lower() or "markupsafe" in str(e).lower()):
                _pip(["--upgrade", "--force-reinstall", "Jinja2>=3.1", "MarkupSafe>=2.1"], log)
            else:
                _pip(["--upgrade", *(["--force-reinstall"] if attempt else []), pkg], log)
            for m in [m for m in sys.modules if m.split(".")[0] in (mod, "markupsafe")]:
                sys.modules.pop(m, None)
    __import__(mod)


def _fast_boot(log) -> bool:
    try:
        for mod, _, _ in BOOT_DEPS:
            if not importlib.util.find_spec(mod):
                log(f"[caché] {mod}: ya no está instalado")
                return False
        if not (which("node") and which("npm")):
            log("[caché] Node.js/npm ya no se encuentran en PATH")
            return False
        if not which("snyk"):
            log("[caché] Snyk CLI ya no se encuentra en PATH")
            return False
        current, detail = ss.check_snyk_version_current(log)
        if not current:
            log(f"[caché] Snyk CLI desactualizado ({detail}) — verificación completa")
            return False
        return True
    except Exception as e:
        log(f"[caché] verificación rápida falló ({e!r})")
        return False


def load_runtime(progress=None) -> list[tuple[str, str]]:
    global RUNTIME_READY
    lines: list[str] = []
    warnings: list[tuple[str, str]] = []
    started = now_human()
    boot_log = DATA_DIR / "boot_dependencies.log"
    prog = progress or (lambda *_: None)

    def log(text):
        lines.append(f"[{datetime.now():%H:%M:%S}] {text}")
        prog("log", text)

    def warn(label, detail):
        log(f"⚠ {label}: {detail}")
        warnings.append((label, detail))

    def flush(status="en progreso"):
        try:
            boot_log.write_text(f"{APP_BRAND_NAME} — registro de dependencias\nInicio : {started}\n"
                                f"Estado : {status}\n{'-' * 60}\n" + "\n".join(lines) + "\n", encoding="utf-8")
        except Exception:
            pass

    def cache(ok):
        write_json(BOOT_CACHE, {"app_version": APP_VERSION, "ok": ok,
                                "verified_at": datetime.now().isoformat(timespec="seconds")})

    try:
        c = read_json(BOOT_CACHE) or {}
        if c.get("ok") and c.get("app_version") == APP_VERSION:
            prog("step", (1, 1, "Verificando requisitos (caché de arranque)…"))
            log("Caché de arranque válido — verificación rápida…")
            if _fast_boot(log):
                RUNTIME_READY = True
                log("✔ Todo verificado por caché — arranque rápido.")
                flush("completado (ruta rápida)")
                prog("done", None)
                return []
            log("La verificación rápida no pasó — revisando todo desde cero…")

        def node():
            if ss.check_node().ok and ss.check_npm().ok:
                log("node/npm: ya instalado")
            elif not (ss.install_node(log) and ss.check_node().ok):
                warn("Node.js / npm", "no se pudo verificar la instalación — revise el registro")

        def snyk():
            if ss.check_snyk().ok:
                current, detail = ss.check_snyk_version_current(log)
                if current:
                    log(f"snyk-cli: ya instalado ({detail})")
                    return
                log(f"[snyk] versión desactualizada ({detail}) — reinstalación limpia automática…")
                ss.reinstall_snyk_clean(log)
            else:
                ss.install_snyk(log)
            if not ss.check_snyk().ok:
                warn("Snyk CLI", "no se pudo verificar la instalación — revise el registro")

        def prewarm():
            try:
                run([which("snyk") or "snyk", "--version"], timeout=15)
                log("snyk: CLI precargada en caché del SO")
            except Exception as e:
                log(f"snyk: precarga omitida ({e!r})")

        steps = [(f"{label} ({mod})", lambda m=mod, p=pkg: _ensure(m, p, log), f"{label} ({mod})")
                 for mod, pkg, label in BOOT_DEPS]
        steps += [("Node.js + npm (entorno JavaScript)", node, "Node.js / npm"),
                  ("git-secrets (escáner de secretos)", lambda: secrets_scanner.ensure_git_secrets(log), "git-secrets"),
                  ("Snyk CLI (escáner de vulnerabilidades)", snyk, "Snyk CLI"),
                  ("Pre-calentando Snyk CLI…", prewarm, "Snyk CLI")]
        for i, (title, fn, label) in enumerate(steps, 1):
            prog("step", (i, len(steps), title))
            try:
                fn()
            except Exception as e:
                warn(label, repr(e))
            flush()
        RUNTIME_READY = True
        log("Motor listo.")
        flush("completado" if not warnings else f"completado con {len(warnings)} advertencia(s)")
        if warnings:
            prog("warn_summary", list(warnings))
        cache(not warnings)
        prog("done", None)
        return warnings
    except Exception as e:
        log(f"FATAL: {e!r}")
        flush("falló")
        cache(False)
        raise


# ── Metadatos de la interfaz ─────────────────────────────────────────────────
NAV_ICONS = {"scan": "play", "static": "code", "container": "container", "iac": "iac", "dast": "globe", "api": "link",
             "reports": "document", "apps": "apps", "schedule": "clock", "admin": "shield"}
NAV_GROUPS = (("Escaneo", ("scan", "static", "dast", "api")), ("Infraestructura", ("container", "iac")),
              ("Gestión", ("reports", "apps", "schedule")), ("Ciberseguridad", ("admin",)))
PAGE_META = {
    "scan": ("Escanear", "Elija las etapas y ejecute el pipeline de seguridad."),
    "static": ("Análisis estático", "SCA, SAST y secretos sobre carpetas y archivos locales."),
    "container": ("Contenedores", "Vulnerabilidades en imágenes de contenedor con Trivy — sin Docker."),
    "iac": ("Infraestructura como código", "Terraform, Kubernetes, Helm y Dockerfile con Checkov, Trivy y SonarQube (local)."),
    "dast": ("Escaneo web (DAST)", "Pruebas dinámicas contra su sitio en ejecución."),
    "api": ("Seguridad de API", "OpenAPI, Postman o GraphQL contra el endpoint objetivo."),
    "reports": ("Reportes", "Historial de escaneos, exportaciones y remediación."),
    "apps": ("Aplicaciones", "Inventario, nivel de riesgo y tendencia por aplicación."),
    "schedule": ("Automatizar", "Escaneos programados y tarea del Programador de Windows."),
    "admin": ("Administración", "Licencias de Probely, motores y políticas — solo Ciberseguridad."),
}
SHORTCUTS = [("F5", "Ejecutar escaneo"), ("Ctrl + 1 … 9", "Ir a una sección"),
             ("F12", "Mostrar u ocultar la consola"), ("Esc", "Cerrar el diálogo activo")]
# (ancho %, alto %, ancho mínimo en px lógicos — evita que el contenido se corte en monitores pequeños)
LARGE_POPUPS = {"Asistente de configuración": (0.66, 0.82, 1040), "Historial de reportes": (0.80, 0.74),
                "Perfil de aplicación": (0.56, 0.86)}
ICON_TIPS = {"📂": "Abrir / cargar", "🗑": "Eliminar", "▶": "Ejecutar", "🔄": "Reinstalar / reparar",
             "📄": "Examinar archivo…", "↻": "Actualizar perfiles de escaneo"}
_DISMISS = {"cancelar", "cerrar", "no", "ahora no", "mantener abierto", "continuar", "no iniciar limpio"}
_DANGER_HINTS = ("eliminar", "quitar", "detener", "reinstalar", "🗑", "🧹", "■")
_PRIMARY_HINTS = ("siguiente", "finalizar", "🚀")
_KIND_COLOR = {"info": ("border2", "info_soft", "info"), "warn": ("warn", "warn_soft", "warn"),
               "error": ("err", "err_soft", "error"), "ok": ("ok", "ok_soft", "check")}


def _norm_label(s: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^\w ]", " ", (s or "").lower())).strip()


class ScannerApp(_WizardMixin, _ScanTabMixin, _DastTabMixin, _ApiTabMixin, _StaticTabMixin, _InfraTabMixin,
                 _ReportsTabMixin, _AppsTabMixin, _ScheduleTabMixin, _AdminTabMixin, tk.Tk):
    TABS = [("scan", "Escanear"), ("static", "Código"), ("dast", "Web (DAST)"), ("api", "API"),
            ("container", "Contenedores"), ("iac", "IaC"), ("reports", "Reportes"), ("apps", "Aplicaciones"),
            ("schedule", "Automatizar"), ("admin", "Administración")]
    PROGRESS_TABS = ("scan", "static", "container", "iac", "dast", "api")

    def __init__(self, boot_warnings=None, headless: bool = False):
        super().__init__()
        init_root(self)
        self._headless = headless
        if headless:
            self.withdraw()
        self.title(APP_BRAND_NAME)
        self.protocol("WM_DELETE_WINDOW", self._on_app_close)
        self._user = detect_user()
        self._is_admin = admin_policy.is_admin(self._user)
        if not self._is_admin:
            self.TABS = [t for t in type(self).TABS if t[0] != "admin"]
        self._tools_busy = False
        self._engine_cache = None
        self._queue: queue.Queue = queue.Queue()
        self._busy = self._static_busy = False
        self._cancel_evt, self._static_cancel_evt = threading.Event(), threading.Event()
        self._auth_proc = None
        self._auth_deadline = 0.0
        self._auth_url = None
        self._auth_grace_until = 0.0
        self._auth_ok_logged = False
        self._auth_lines: queue.Queue = queue.Queue()
        self._auth_check_inflight = False
        self._next_auth_check = 0.0
        self._login_popup_close = None
        self._relogin_prompted = False
        self._checks: dict = {}
        self._key_auth_status = "checking"
        self._probely_auth_status = "unauth"
        self._active_app = None
        self._last_app_id = None
        self._open_app_tabs: list[str] = []
        self._saved_open_app_ids: list[str] = []
        self._last_context = None
        self._last_report = self._last_static_report = None
        self._static_ctx = None
        self._static_paths: list[str] = []
        self._api_preview = None
        self._active_tab = "scan"
        self._console_visible = False
        self._unread_log = 0
        self._console_text = ""
        self._reportes_unread = False
        self._ribbon_pct = {k: 0.0 for k in self.PROGRESS_TABS}
        self._pipe_stage_states: dict[str, str] = {}
        self._pipe_card_pcts: dict[str, float] = {}
        self._pipe_progress_pct = 0.0
        self._static_route = (0, 1)
        self._play_ring_pct = 0.0
        self._play_ready = False
        self._dark_mode = False
        self._nav_collapsed = False
        self._nav_state: dict = {}
        self._nav_items: dict = {}
        self._auto_open = True
        self._reports_root = DEFAULT_REPORTS
        self._wizard_seen = False
        self._snow_ok = False
        self._snow_state = "checking"   # none | checking | ok | invalid | unverified
        self._snow_detail = ""
        self._snow_test_mode = False    # Administración → «Modo prueba»: no crea/actualiza tickets (solo este equipo)
        self._os_sched_enabled = False
        self._saved_scan_stages = None
        self._saved: dict = {}
        self._flash_after = None
        self._status_icons: dict = {}
        self._toast_win = None
        self._boot_warnings = list(boot_warnings or [])
        self._load_settings()
        try:
            logs = sorted(DATA_DIR.glob("console_session_*.txt"))
            for old in logs[:-19]:
                old.unlink(missing_ok=True)
            self._session_log = open(DATA_DIR / f"console_session_{ts()}_pid{os.getpid()}.txt", "a",
                                     encoding="utf-8", buffering=1)
        except Exception:
            self._session_log = None
        if not headless:
            x, y = last_window_anchor()
            # Solo se restaura la posición si cae dentro del escritorio actual (p. ej. se desconectó un monitor).
            vx, vy = self.winfo_vrootx(), self.winfo_vrooty()
            vw, vh = self.winfo_vrootwidth() or self.winfo_screenwidth(), self.winfo_vrootheight() or self.winfo_screenheight()
            if x is not None and vx - 50 <= x < vx + vw - 100 and vy - 50 <= y < vy + vh - 100:
                self.geometry(f"+{x}+{y}")
                self.update_idletasks()
            # El mínimo nunca supera la pantalla (1024×768 o escalas altas): si no, la ventana queda cortada.
            self.minsize(min(px(1100), self.winfo_screenwidth() - 16), min(px(680), self.winfo_screenheight() - 80))
            self.state("zoomed")
            GUI_PID_FILE.write_text(str(os.getpid()), encoding="utf-8")
        self._inv_store = AppInventoryStore(self._reports_root)
        self._scan_state = ScanStateStore(self._reports_root)
        self._init_vars()
        self._init_schedule()
        self._build_all()
        self._bind_shortcuts()
        for label, detail in self._boot_warnings:
            self._log_line(f"[arranque] ⚠ {label}: {detail} — la etapa correspondiente puede no estar disponible "
                           "(detalle en data/boot_dependencies.log)")
        self.after(150, self._drain)
        self.after(200, self._auto_load_last_app)
        self.after(300, self._kick_auth_check)
        self.after(400, self._refresh_engine_cache)
        self.after(450, self._refresh_servicenow_state)
        if self._is_admin and self._probely_configured():
            self.after(900, self._validate_probely_key)
        if not headless:
            self.after(1200, lambda: RUNTIME_READY and threading.Thread(
                target=prewarm_driver, args=(self._collect_dast_cfg(), self._emit_log), daemon=True).start())
            self.after(700, self._check_unclean_shutdown)
            self.after(1800, self._maybe_open_wizard_on_first_launch)
            self.after(1500, self._ossched_selfheal)
            self.after(8000, self._bg_check_tool_updates)

    # ── Configuración persistente ────────────────────────────────────────────
    def _load_settings(self):
        data = read_json(SETTINGS_FILE, {}) or {}
        self._saved = data
        self._dark_mode = bool(data.get("dark_mode", False))
        self._nav_collapsed = bool(data.get("nav_collapsed", False))
        apply_palette(self._dark_mode)
        if data.get("reports_root"):
            cand = Path(data["reports_root"])
            try:
                cand.mkdir(parents=True, exist_ok=True)
                self._reports_root = cand
            except OSError as e:
                self._boot_warnings.append(("Carpeta de reportes",
                    f"La ruta guardada '{cand}' no está disponible en esta PC ({e!r}). Se usará {DEFAULT_REPORTS}"))
        self._auto_open = bool(data.get("auto_open", True))
        self._last_app_id = data.get("last_app_id") or None
        self._saved_open_app_ids = [str(x) for x in data.get("open_app_ids") or []]
        self._wizard_seen = bool(data.get("wizard_seen"))
        self._os_sched_enabled = bool(data.get("os_scheduler_enabled"))
        self._snow_test_mode = bool(data.get("servicenow_test_mode"))
        if isinstance(data.get("scan_stages"), dict):
            self._saved_scan_stages = {k: bool(v) for k, v in data["scan_stages"].items() if k in STAGES}
        self._static_paths = [p for p in data.get("static_paths") or [] if isinstance(p, str) and p.strip()]

    def _save_settings(self):
        data = {"dark_mode": self._dark_mode, "nav_collapsed": self._nav_collapsed,
                "reports_root": str(self._reports_root),
                "auto_open": self._auto_open, "last_app_id": self._last_app_id,
                "open_app_ids": list(self._open_app_tabs), "wizard_seen": self._wizard_seen,
                "os_scheduler_enabled": self._os_sched_enabled,
                "servicenow_test_mode": self._snow_test_mode,
                "dast_fields": self._dump_fields("dast"), "api_fields": self._dump_fields("api"),
                "infra": self._dump_infra()}
        if not self._headless:
            data["window_x"], data["window_y"] = self.winfo_rootx(), self.winfo_rooty()
        if self._active_app:
            data["scan_stages"] = self._saved.get("scan_stages")
            data["static_paths"] = self._saved.get("static_paths", [])
            prev = self._saved.get("infra") or {}
            data["infra"].update(container_sources=prev.get("container_sources", []), iac_paths=prev.get("iac_paths", []))
        else:
            data["scan_stages"] = {k: bool(v.get()) for k, v in self._scan_vars.items()}
            data["static_paths"] = list(self._static_paths)
        try:
            write_json(SETTINGS_FILE, data)
            self._saved = data
        except Exception as e:
            self._emit_log(f"[configuración] no se pudo guardar: {e!r}")
        self._flash_saved()

    def _persist(self, field: str, value) -> None:
        if self._active_app is not None:
            self._active_app[field] = value
            try:
                # Se guarda sobre la versión en disco: el dict en memoria puede ser anterior a un escaneo
                # (programado o del runner de Windows) y revertiría sus conteos e historial.
                fresh = self._inv_store.get_app(self._active_app.get("id", "")) if self._active_app.get("id") else None
                if fresh is not None:
                    fresh[field] = value
                    self._active_app.update(fresh)
                self._inv_store.save_app(self._active_app)
            except Exception as e:
                self._emit_log(f"[apps] no se pudo guardar {field} en el perfil: {e!r}")
        else:
            self._save_settings()

    def _persist_static_paths(self) -> None:
        self._persist("static_paths", list(self._static_paths))
        self._refresh_scan_btn()

    def _persist_scan_stages(self) -> None:
        self._persist("scan_stages", [k for k, v in self._scan_vars.items() if v.get()])

    def _init_vars(self):
        saved = self._saved_scan_stages
        self._scan_vars = {k: tk.BooleanVar(value=saved.get(k, k in NO_APP_STAGES) if saved else k in NO_APP_STAGES)
                           for k in STAGES}
        self._target_var = tk.StringVar(value=self._static_paths[-1] if self._static_paths else "")
        self._reports_var = tk.StringVar(value=str(self._reports_root))
        self._status_text = "Verificando la sesión de Snyk…"
        self._status_var = tk.StringVar(value=self._status_text)
        self._init_dast_vars()
        self._init_api_vars()
        self._init_infra_vars()
        self._load_fields("dast", self._saved.get("dast_fields"))
        self._load_fields("api", self._saved.get("api_fields"))
        self._init_macro_flags()
        self._setup_field_persistence()

    def _apply_no_app_default_stages(self) -> None:
        for k, var in self._scan_vars.items():
            var.set(k in NO_APP_STAGES)

    # ── Sesiones / recuperación tras cierre inesperado ───────────────────────
    def _session_snapshot(self, kind: str, selected: set) -> dict:
        sel = sorted(selected)
        return {"kind": kind, "selected": sel,
                "needs_password": any(k in sel and getattr(self, f"_{k}_auth_var").get() != "none"
                                      for k in ("dast", "api")),
                "target": self._target_var.get(), "reports_root": self._reports_var.get(),
                "static_paths": list(self._static_paths), "dast": self._dump_fields("dast"),
                "api": self._dump_fields("api"), "infra": self._dump_infra(), "app_id": self._last_app_id,
                "started": ts()}

    def _sessions(self) -> dict:
        raw = read_json(SESSION_FILE, {}) or {}
        if isinstance(raw.get("sessions"), dict):
            return raw["sessions"]
        return {raw["kind"]: raw} if "kind" in raw else {}

    def _session_begin(self, kind: str, selected: set):
        sessions = self._sessions()
        sessions[kind] = self._session_snapshot(kind, selected)
        write_json(SESSION_FILE, {"sessions": sessions})

    def _session_end(self, kind: str):
        sessions = self._sessions()
        sessions.pop(kind, None)
        if sessions:
            write_json(SESSION_FILE, {"sessions": sessions})
        else:
            SESSION_FILE.unlink(missing_ok=True)

    def _check_unclean_shutdown(self):
        sessions = self._sessions()
        SESSION_FILE.unlink(missing_ok=True)
        for kind, info in sessions.items():
            self._prompt_resume_session(kind, info)

    def _prompt_resume_session(self, kind: str, info: dict):
        sel = info.get("selected") or []
        needs_pw = bool(info.get("needs_password"))
        note = ""
        if needs_pw:
            which_ = [k.upper() for k in ("dast", "api") if k in sel and (info.get(k) or {}).get("auth", "none") != "none"]
            note = (f"\n\nNota: ese escaneo incluía {' y '.join(which_)} con credenciales. Las contraseñas y tokens "
                    "nunca se guardan en disco, así que deberá volver a capturarlos antes de ejecutarlo. "
                    "Todo lo demás se restaurará.")
        self._show_confirm_popup(
            "Cierre inesperado",
            f"El programa se cerró inesperadamente mientras corría un escaneo "
            f"{ {'static': 'de análisis estático', 'infra': 'de infraestructura'}.get(kind, 'del pipeline completo')}.\n\n"
            f"Etapas:  {' + '.join(s.upper() for s in sel) or '—'}\n"
            f"Objetivo:  {info.get('target', '—')}\nInicio:  {info.get('started', '')}\n\n"
            "¿Desea ejecutar ese escaneo de nuevo con la misma configuración?" + note,
            on_yes=lambda: self._resume_from_session(info),
            yes_label="Restaurar configuración" if needs_pw else "Restaurar y ejecutar",
            no_label="No, iniciar limpio")

    def _resume_from_session(self, info: dict):
        sel = set(info.get("selected") or [])
        for k, var in self._scan_vars.items():
            var.set(k in sel)
        if info.get("target"):
            self._target_var.set(info["target"])
        if info.get("reports_root"):
            self._reports_var.set(info["reports_root"])
        self._static_paths[:] = list(info.get("static_paths") or [])
        self._render_static_paths()
        self._load_fields("dast", info.get("dast"))
        self._load_fields("api", info.get("api"))
        infra = info.get("infra") or {}
        self._container_sources[:] = [x for x in infra.get("container_sources") or [] if isinstance(x, dict)]
        self._iac_paths[:] = [x for x in infra.get("iac_paths") or [] if isinstance(x, str)]
        self._render_container_sources()
        self._render_iac_paths()
        self._refresh_scan_btn()
        self._save_settings()
        if info.get("needs_password"):
            tab = "dast" if "dast" in sel and (info.get("dast") or {}).get("auth", "none") != "none" else "api"
            self._show_tab(tab)
            self._show_info_popup("Restaurado — se requiere contraseña",
                f"Se restauró la configuración del escaneo anterior.\n\nComo incluye {tab.upper()} con autenticación, "
                "vuelva a capturar la contraseña o token y pulse «Ejecutar escaneo».")
            return
        self._emit_log("[sesión] reanudando el escaneo anterior con la configuración restaurada…")
        if info.get("kind") == "static":
            self._show_tab("static")
            self._run_static_scan_now((sel & set(STATIC_STAGES)) or set(STATIC_STAGES))
        else:
            self._show_tab("scan")
            self._run_scan_pipeline()

    # ── Cola de UI / trabajos en segundo plano ───────────────────────────────
    def _ui(self, fn, *args) -> None:
        self._queue.put((fn, args))

    def _emit_log(self, s: str) -> None:
        self._queue.put((self._log_line, (s,)))

    def _drain(self):
        try:
            while True:
                fn, args = self._queue.get_nowait()
                try:
                    fn(*args)
                except Exception as e:
                    self._log_line(f"[error] {e!r}")
        except queue.Empty:
            pass
        if self._auth_proc is not None:
            self._tick_auth_poll()
        self._gc_ticks = getattr(self, "_gc_ticks", 0) + 1
        if self._gc_ticks % 20 == 0:
            # La recolección automática está desactivada (ver main): se hace aquí, en el hilo de Tk, para que
            # ningún objeto de Tk (imágenes, variables, el propio intérprete) se libere desde un hilo de escaneo.
            gc.collect(2 if self._gc_ticks % 200 == 0 else 1)
        self.after(150, self._drain)

    def _any_busy(self) -> bool:
        return self._busy or self._static_busy

    def _run_async(self, fn, label: str = "", *, busy_attr: str = "_busy"):
        if getattr(self, busy_attr):
            self._log_line(f"[ocupado] se ignora '{label}' — otra operación en progreso")
            return
        setattr(self, busy_attr, True)
        self._update_stop_btn_style()
        self._set_status(f"Ejecutando: {label}…")

        def wrap():
            try:
                fn()
            except Exception as e:
                self._emit_log(f"[error] {e!r}")
            finally:
                self._ui(self._job_done, busy_attr)
        threading.Thread(target=wrap, daemon=True).start()

    def _job_done(self, busy_attr: str):
        setattr(self, busy_attr, False)
        self._update_stop_btn_style()
        self._set_idle_status()

    def _set_status(self, s: str):
        self._status_text = s
        if not self._flash_after:
            self._status_var.set(s)
        lbl = getattr(self, "_status_lbl", None)
        if lbl is not None and lbl.winfo_exists() and not self._flash_after:
            lbl.config(fg=T["warn"] if s.startswith("⚠") else T["muted"])

    def _set_idle_status(self) -> None:
        """Mensaje de la barra de estado cuando no hay nada ejecutándose: dice qué falta, no «Inicializando»."""
        if self._any_busy():
            return
        st = self._key_auth_status
        if st == "auth":
            self._set_status("✔  Listo")
        elif st == "checking":
            self._set_status("Verificando la sesión de Snyk…")
        else:
            self._set_status("⚠  Sin sesión de Snyk: SCA y SAST no correrán. Clic aquí para iniciar sesión — use "
                             "«Log in with SSO», no su correo. Lo demás funciona normalmente.")

    def _flash_saved(self) -> None:
        lbl = getattr(self, "_status_lbl", None)
        if not lbl or not lbl.winfo_exists():
            return
        if self._flash_after:
            self.after_cancel(self._flash_after)
        self._status_var.set("✔  Configuración guardada")
        lbl.config(fg=T["ok"])

        def restore():
            self._flash_after = None
            self._set_status(self._status_text)
        self._flash_after = self.after(2200, restore)

    def _toast(self, text: str, kind: str = "info", ms: int = 2800) -> None:
        if self._headless or not self.winfo_viewable():
            return
        if self._toast_win is not None:
            try:
                self._toast_win.destroy()
            except Exception:
                pass
        t = self._toast_win = tk.Toplevel(self)
        t.overrideredirect(True)
        t.transient(self)
        f = tk.Frame(t, bg="#1F2937", padx=px(16), pady=px(11))
        f.pack()
        color = {"ok": "#4ADE80", "warn": "#FBBF24", "error": "#F87171"}.get(kind, "#93C5FD")
        tk.Label(f, text=ico(_KIND_COLOR.get(kind, _KIND_COLOR["info"])[2]), font=icon_font(11), bg="#1F2937",
                 fg=color).pack(side="left", padx=(0, px(10)))
        tk.Label(f, text=text, font=(FUI, 11), bg="#1F2937", fg="#F9FAFB").pack(side="left")
        t.update_idletasks()
        x = self.winfo_rootx() + self.winfo_width() - t.winfo_reqwidth() - px(28)
        y = self.winfo_rooty() + self.winfo_height() - t.winfo_reqheight() - px(52)
        t.geometry(f"+{x}+{y}")
        round_corners(t)
        t.after(ms, lambda: t.winfo_exists() and t.destroy())

    # ── Consola ──────────────────────────────────────────────────────────────
    def _log_line(self, s: str):
        s = s.rstrip()
        if self._session_log:
            try:
                self._session_log.write(f"[{now_human()}] {s}\n")
            except Exception:
                pass
        low = s.lower()
        tag = ("error" if any(k in low for k in ("[error]", "falló", "fallo", "failed", "error", "✕")) else
               "warn" if any(k in s for k in ("⚠", "omit", "cancel", "no se pudo")) else
               "ok" if any(k in low for k in ("✓", "✔", "autenticado", "completad", "listo", "guardad", "registrad")) else
               "scan" if any(k in low for k in ("snyk", "escane", "[estático]", "[secretos]")) else "")
        w = self._log_widget
        w.configure(state="normal")
        w.insert("end", s + "\n", (tag,) if tag else ())
        lines = int(w.index("end-1c").split(".")[0])
        if lines > 20000:
            w.delete("1.0", f"{lines - 20000}.0")
        w.see("end")
        w.configure(state="disabled")
        if not self._console_visible:
            self._unread_log += 1
            # rojo solo con errores reales («[error]», «✕», «falló»), no por cualquier palabra «error» en el texto
            self._unread_err = getattr(self, "_unread_err", False) or "[error]" in low or "✕" in s or "falló" in low
            self._paint_console_btn()

    def _paint_console_btn(self) -> None:
        """Con entradas nuevas sin leer, el botón «Consola» se rellena (naranja; rojo si hay errores) y muestra el
        conteo — el texto «Consola · N» solo pasaba desapercibido. Al abrir la consola vuelve a su estilo normal."""
        b = getattr(self, "_console_btn", None)
        if b is None or not b.winfo_exists():
            return
        n = 0 if getattr(self, "_console_visible", False) else getattr(self, "_unread_log", 0)
        err = bool(n and getattr(self, "_unread_err", False))
        variant = ("danger" if err else "primary") if n else "ghost"
        text = (f"Consola · {n if n < 1000 else '999+'} nueva{'s' if n != 1 else ''}") if n else "Consola"
        if (variant, text) != getattr(b, "_look", None):   # en el botón: al cambiar de tema se reconstruye
            b._look = (variant, text)
            b.set(text=text, variant=variant)

    def _toggle_console(self):
        if self._console_visible:
            self._console_frame.pack_forget()
        else:
            self._console_frame.pack(side="bottom", fill="x", before=self._stack)
            self._unread_log = 0
            self._unread_err = False
        self._console_visible = not self._console_visible
        self._paint_console_btn()

    def _copy_log(self):
        self.clipboard_clear()
        self.clipboard_append(self._log_widget.get("1.0", "end-1c"))
        self._toast("Registro copiado al portapapeles", "ok")

    # ── Estilos ttk ──────────────────────────────────────────────────────────
    def _setup_styles(self):
        s = ttk.Style(self)
        s.theme_use("clam")
        f = (FUI, 11)
        s.configure(".", background=T["bg"], foreground=T["text"], font=f, bordercolor=T["border_strong"],
                    lightcolor=T["panel_bg"], darkcolor=T["panel_bg"], troughcolor=T["surface3"],
                    focuscolor=T["accent"], selectbackground=T["select"], selectforeground=T["select_fg"])
        for name in ("TButton", "Accent.TButton"):
            s.configure(name, background=T["accent"], foreground=T["button_fg"], bordercolor=T["accent"],
                        padding=(px(14), px(7)), relief="flat", font=(FUI, 11, "bold"))
            s.map(name, background=[("active", T["accent_hi"]), ("disabled", T["surface3"])],
                  foreground=[("disabled", T["muted"])])
        field = dict(fieldbackground=T["panel_bg"], foreground=T["text"], bordercolor=T["border_strong"],
                     lightcolor=T["panel_bg"], darkcolor=T["panel_bg"], insertcolor=T["text"])
        focus = dict(bordercolor=[("focus", T["accent"])], lightcolor=[("focus", T["accent"])],
                     fieldbackground=[("disabled", T["surface3"]), ("readonly", T["panel_bg"])])
        s.configure("TEntry", padding=(px(8), px(5)), **field)
        s.map("TEntry", **focus)
        s.configure("TCombobox", padding=(px(8), px(4)), arrowcolor=T["muted"], background=T["panel_bg"],
                    arrowsize=px(12), **field)
        s.map("TCombobox", **focus, selectbackground=[("readonly", T["panel_bg"])],
              selectforeground=[("readonly", T["text"])], background=[("active", T["hover"])])
        for k, v in (("background", T["panel_bg"]), ("foreground", T["text"]), ("font", f"{{{FUI}}} 10"),
                     ("selectBackground", T["select"]), ("selectForeground", T["select_fg"])):
            self.option_add(f"*TCombobox*Listbox.{k}", v)
        s.configure("TSpinbox", padding=(px(6), px(4)), arrowcolor=T["muted"], background=T["panel_bg"],
                    arrowsize=px(10), **field)
        s.map("TSpinbox", **focus)
        s.configure("TRadiobutton", background=T["panel_bg"], foreground=T["card_fg"], indicatorbackground=T["panel_bg"],
                    indicatorforeground=T["accent"], padding=(px(2), px(2)))
        s.map("TRadiobutton", indicatorbackground=[("selected", T["accent"])], background=[("active", T["panel_bg"])])
        s.configure("Treeview", background=T["panel_bg"], foreground=T["text"], fieldbackground=T["panel_bg"],
                    rowheight=px(30), bordercolor=T["panel_bg"], lightcolor=T["panel_bg"], darkcolor=T["panel_bg"],
                    borderwidth=0, font=(FUI, 10))
        s.map("Treeview", background=[("selected", T["select"])], foreground=[("selected", T["select_fg"])])
        s.configure("Treeview.Heading", background=T["surface2"], foreground=T["muted"], font=(FUI, 10, "bold"),
                    relief="flat", borderwidth=0, padding=(px(8), px(6)), bordercolor=T["border"],
                    lightcolor=T["surface2"], darkcolor=T["border"])
        s.map("Treeview.Heading", background=[("active", T["hover"]), ("pressed", T["hover"])])
        for orient in ("Vertical", "Horizontal"):
            s.configure(f"{orient}.TScrollbar", background=T["border_strong"], troughcolor=T["bg"],
                        bordercolor=T["bg"], lightcolor=T["border_strong"], darkcolor=T["border_strong"],
                        arrowcolor=T["muted"], gripcount=0, arrowsize=px(12))
            s.map(f"{orient}.TScrollbar", background=[("active", T["muted"])])
        s.configure("Thin.Horizontal.TProgressbar", troughcolor=T["surface3"], background=T["accent"],
                    bordercolor=T["surface3"], lightcolor=T["accent"], darkcolor=T["accent"], thickness=px(5))

    # ── Construcción de la ventana ───────────────────────────────────────────
    def _build_all(self):
        self.configure(bg=T["bg"])
        self._setup_styles()
        set_window_icon(self, self._dark_mode)
        set_titlebar_theme(self, self._dark_mode)
        self._build_status_bar()
        self._build_sidebar()
        self._main = tk.Frame(self, bg=T["bg"])
        self._main.pack(side="left", fill="both", expand=True)
        self._build_header(self._main)
        self._build_body(self._main)
        self._show_tab(self._active_tab)
        self._rebuild_app_tabs()
        self._paint_badges()
        self._set_reportes_notification(self._reportes_unread)
        for k, pct in self._ribbon_pct.items():
            self._set_ribbon_tab_progress(k, pct)
        for k, pct in self._pipe_card_pcts.items():
            self._paint_card(k, pct)
        self._refresh_auth_banner(self._key_auth_status == "auth")
        self._refresh_scan_btn()
        self._update_stop_btn_style()

    def _bind_shortcuts(self):
        self.bind("<F5>", lambda _e: None if self._any_busy() else self._cta_click())
        for i, (key, _) in enumerate(self.TABS[:9], 1):
            self.bind(f"<Control-Key-{i}>", lambda _e, k=key: self._show_tab(k))
        self.bind("<F12>", lambda _e: self._toggle_console())

    def _toggle_theme(self):
        self._dark_mode = not self._dark_mode
        apply_palette(self._dark_mode)
        self._save_settings()
        self._console_text = self._log_widget.get("1.0", "end-1c")
        console = self._console_visible
        for w in self.winfo_children():
            if not isinstance(w, tk.Toplevel):
                w.destroy()
        self._console_visible = False
        self._build_all()
        if self._static_ctx is not None:
            self._on_static_results(self._static_ctx, rerender=True)
        if console:
            self._toggle_console()

    # Barra lateral ----------------------------------------------------------
    def _build_sidebar(self):
        col = self._nav_collapsed
        sb = tk.Frame(self, bg=T["sb_bg"], width=px(64) if col else px(232))
        main = getattr(self, "_main", None)
        sb.pack(side="left", fill="y", **({"before": main} if main is not None and main.winfo_exists() else {}))
        sb.pack_propagate(False)
        self._sidebar = sb
        self._nav_items = {}
        top = tk.Frame(sb, bg=T["sb_bg"])
        top.pack(fill="x", pady=(px(12), px(10)))
        burger = tk.Label(top, text=ico("menu"), font=icon_font(12), bg=T["sb_bg"], fg=T["sb_fg"], cursor="hand2",
                          padx=px(8), pady=px(6))
        burger.pack(side="left", padx=(px(14), 0))
        burger.bind("<Button-1>", lambda _e: self._toggle_sidebar())
        burger.bind("<Enter>", lambda _e: burger.config(bg=T["sb_hover"]))
        burger.bind("<Leave>", lambda _e: burger.config(bg=T["sb_bg"]))
        Tooltip(burger, "Expandir menú" if col else "Contraer menú")
        if not col:
            brand = tk.Frame(top, bg=T["sb_bg"])
            brand.pack(side="left", padx=(px(6), 0))
            img = load_image(icon_dir(True) / "apple-touch-icon.png", px(28))
            if img:
                lbl = tk.Label(brand, image=img, bg=T["sb_bg"])
                lbl.image = img
                lbl.pack(side="left", padx=(0, px(8)))
            txt = tk.Frame(brand, bg=T["sb_bg"])
            txt.pack(side="left")
            tk.Label(txt, text="SecDevOps", font=(FUI_TITLE, 12, "bold"), bg=T["sb_bg"], fg="#FFFFFF").pack(anchor="w")
            tk.Label(txt, text="Banco Base", font=(FUI, 9), bg=T["sb_bg"], fg=T["sb_muted"]).pack(anchor="w")
        # Pantallas bajas (1366×768, 1280×720 o 150 % en 1080p): menú compacto para que «Tema» y «Ayuda» no se corten.
        compact = self.winfo_screenheight() < px(860)
        self._nav_h = px(32) if compact else px(40)
        grp_pad = px(8) if compact else px(16)
        bottom = tk.Frame(sb, bg=T["sb_bg"])
        bottom.pack(side="bottom", fill="x", pady=(0, px(6) if compact else px(12)))
        nav = tk.Frame(sb, bg=T["sb_bg"])
        nav.pack(fill="x")
        labels, order = dict(self.TABS), [k for k, _ in self.TABS]
        groups = [(g, tuple(k for k in keys if k in labels)) for g, keys in NAV_GROUPS]
        for gi, (gname, keys) in enumerate([g for g in groups if g[1]]):
            if col:
                if gi:
                    tk.Frame(nav, bg=T["sb_hover"], height=1).pack(fill="x", padx=px(16), pady=px(8))
            else:
                tk.Label(nav, text=gname.upper(), font=(FUI, 8, "bold"), bg=T["sb_bg"], fg=T["sb_muted"],
                         anchor="w").pack(fill="x", padx=px(24), pady=(grp_pad if gi else px(4), px(2) if compact else px(4)))
            for k in keys:
                n = order.index(k) + 1
                self._nav_item(nav, k, NAV_ICONS[k], labels[k], lambda kk=k: self._show_tab(kk),
                               tip=f"{labels[k]}   Ctrl+{n}" if n <= 9 else labels[k])
        self._ribbon_tabs = {k: self._nav_items[k] for k in order}
        tk.Frame(bottom, bg=T["sb_hover"], height=1).pack(fill="x", padx=px(16), pady=(0, px(8)))
        self._nav_item(bottom, "_wizard", "settings", "Asistente", self.open_wizard)
        self._nav_item(bottom, "_theme", "sun" if self._dark_mode else "moon",
                       "Tema claro" if self._dark_mode else "Tema oscuro", self._toggle_theme)
        self._nav_item(bottom, "_help", "help", "Ayuda y atajos", self._show_help)

    def _nav_item(self, parent, key, icon, label, cmd, tip=None):
        w = px(64) if self._nav_collapsed else px(232)
        c = tk.Canvas(parent, width=w, height=getattr(self, "_nav_h", px(40)), bg=T["sb_bg"], highlightthickness=0, bd=0, cursor="hand2")
        c.pack(fill="x")
        c._meta = (icon, label)
        st = self._nav_state.setdefault(key, {"pct": 0.0, "dot": False})
        st["hover"] = False

        def hover(on):
            st["hover"] = on
            self._draw_nav(key)
        c.bind("<Enter>", lambda _e: hover(True))
        c.bind("<Leave>", lambda _e: hover(False))
        c.bind("<Button-1>", lambda _e: cmd())
        if self._nav_collapsed:
            Tooltip(c, tip or label)
        self._nav_items[key] = c
        self._draw_nav(key)

    def _draw_nav(self, key):
        c = self._nav_items.get(key)
        if c is None or not c.winfo_exists():
            return
        st, (icon, label) = self._nav_state[key], c._meta
        w, h = int(c.cget("width")), int(c.cget("height"))
        active = key == self._active_tab
        c.delete("all")
        if active or st.get("hover"):
            rounded_rect(c, px(8), px(2), w - px(8), h - px(2), px(7), fill=T["sb_active"] if active else T["sb_hover"],
                         outline="")
        if active:
            c.create_rectangle(px(8), px(12), px(11), h - px(12), fill=T["accent"], outline="")
        fg = "#FFFFFF" if active else T["sb_fg"]
        ix = w // 2 if self._nav_collapsed else px(32)
        c.create_text(ix, h // 2, text=ico(icon), font=icon_font(12), fill=T["accent"] if active else fg)
        if not self._nav_collapsed:
            c.create_text(px(56), h // 2, text=label, anchor="w", font=(FUI, 11, "bold" if active else "normal"),
                          fill=fg)
        if st.get("pct", 0) > 0:
            x0 = px(16)
            c.create_rectangle(x0, h - px(5), x0 + int((w - 2 * x0) * st["pct"]), h - px(3), fill=T["accent"],
                               outline="")
        if st.get("dot"):
            r, cx, cy = px(4), ix + px(10), h // 2 - px(8)
            c.create_oval(cx - r, cy - r, cx + r, cy + r, fill=T["err"], outline=T["sb_bg"], width=max(1, px(2)))

    def _toggle_sidebar(self):
        self._nav_collapsed = not self._nav_collapsed
        self._sidebar.destroy()
        self._build_sidebar()
        self._save_settings()

    def _show_tab(self, key: str):
        self._active_tab = key
        for k in getattr(self, "_ribbon_tabs", {}):
            self._draw_nav(k)
        if not self._any_busy() and key in self._ribbon_pct:
            self._set_ribbon_tab_progress(key, 0.0)
        if key == "reports":
            self._set_reportes_notification(False)
        self._tab_frames[key].tkraise()

    def _set_ribbon_tab_progress(self, key: str, pct: float):
        if key not in self._ribbon_pct:
            return
        self._ribbon_pct[key] = pct = max(0.0, min(pct, 1.0))
        self._nav_state.setdefault(key, {"pct": 0.0, "dot": False})["pct"] = pct
        self._draw_nav(key)

    def _set_reportes_notification(self, show: bool) -> None:
        self._reportes_unread = show
        self._nav_state.setdefault("reports", {"pct": 0.0, "dot": False})["dot"] = show
        self._draw_nav("reports")

    # Encabezado: aplicación activa + conexiones + acción principal ----------
    def _build_header(self, parent):
        bar = tk.Frame(parent, bg=T["bg"])
        bar.pack(side="top", fill="x", padx=px(24), pady=(px(12), px(10)))
        self._app_tabs_container = tk.Frame(bar, bg=T["bg"])
        self._app_tabs_container.pack(side="left")
        right = tk.Frame(bar, bg=T["bg"])
        right.pack(side="right")
        self._badges = {}
        pills = [("snyk", "Snyk", self._show_auth_status_popup), ("engines", "Motores", self._show_engines_popup)]
        if self._is_admin:
            pills.append(("probely", "Probely", self._show_probely_key_popup))
        for key, label, cmd in pills:
            pill = self._status_pill(right, label, cmd)
            pill.pack(side="left", padx=(0, px(8)))
            self._badges[key] = pill
        tk.Frame(right, bg=T["border"], width=1).pack(side="left", fill="y", padx=(px(6), px(14)), pady=px(4))
        self._cta = PillButton(right, "Ejecutar escaneo", self._cta_click, icon="play", variant="primary", size=11,
                               soft_disabled=True,
                               tooltip=lambda: "Detener el escaneo en curso" if self._any_busy() else
                               "Ejecutar el pipeline (F5)" if self._play_ready else
                               "Faltan requisitos — vea «Preparación» en Escanear")
        self._cta.pack(side="left")
        tk.Frame(parent, bg=T["border"], height=1).pack(side="top", fill="x")

    def _status_pill(self, parent, label, cmd):
        f = tk.Frame(parent, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"], cursor="hand2")
        d = px(9)
        dot = tk.Canvas(f, width=d, height=d, bg=T["panel_bg"], highlightthickness=0, bd=0)
        dot.pack(side="left", padx=(px(11), px(7)), pady=px(9))
        dot.create_oval(0, 0, d - 1, d - 1, fill=T["muted"], outline="", tags="o")
        lbl = tk.Label(f, text=label, font=(FUI, 11), bg=T["panel_bg"], fg=T["text"])
        lbl.pack(side="left", padx=(0, px(12)))
        parts = (f, dot, lbl)

        def paint(on):
            bg = T["hover"] if on else T["panel_bg"]
            for w in parts:
                w.configure(bg=bg)
        for w in parts:
            w.bind("<Button-1>", lambda _e: cmd())
            w.bind("<Enter>", lambda _e: paint(True))
            w.bind("<Leave>", lambda _e: paint(False))
        f.dot, f.tip_text = dot, label
        Tooltip(f, lambda: f.tip_text)
        return f

    def _cta_click(self):
        if self._any_busy():
            return self._request_cancel()
        if self._play_ready:
            return self._start_scan()
        self._show_tab("scan")
        self._toast("Complete los requisitos marcados en «Preparación»", "warn")

    def _paint_cta(self):
        cta = getattr(self, "_cta", None)
        if cta is None or not cta.winfo_exists():
            return
        busy, pct = self._any_busy(), self._play_ring_pct
        if busy:
            cta.set(text=f"Detener  ·  {round(pct * 100)}%", icon="stop", variant="danger", enabled=True)
        else:
            cta.set(text="Ejecutar escaneo", icon="play", variant="primary", enabled=self._play_ready)
        pb = getattr(self, "_status_pb", None)
        if pb is not None and pb.winfo_exists():
            if busy:
                if not pb.winfo_ismapped():
                    pb.pack(side="left", padx=(px(12), 0))
                pb.configure(value=pct * 100)
            elif pb.winfo_ismapped():
                pb.pack_forget()

    def _rebuild_app_tabs(self) -> None:
        box = getattr(self, "_app_tabs_container", None)
        if box is None or not box.winfo_exists():
            return
        for w in box.winfo_children():
            w.destroy()
        self._open_app_tabs[:] = [a for a in self._open_app_tabs if self._inv_store.get_app(a)]
        app = self._active_app
        name = app.get("name") if app else None
        self.title(f"{APP_BRAND_NAME} — {name}" if name else APP_BRAND_NAME)
        chip = tk.Frame(box, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"], cursor="hand2")
        chip.pack(side="left")
        parts = [chip]
        ic = tk.Label(chip, text=ico("apps"), font=icon_font(13), bg=T["panel_bg"],
                      fg=T["accent"] if name else T["muted"])
        ic.pack(side="left", padx=(px(12), px(10)), pady=px(6))
        col = tk.Frame(chip, bg=T["panel_bg"])
        col.pack(side="left", pady=px(4))
        parts += [ic, col,
                  tk.Label(col, text="APLICACIÓN", font=(FUI, 8, "bold"), bg=T["panel_bg"], fg=T["muted"]),
                  tk.Label(col, text=name or "Ninguna — clic para elegir", font=(FUI, 11, "bold"), bg=T["panel_bg"],
                           fg=T["text"] if name else T["muted"])]
        for w in parts[-2:]:
            w.pack(anchor="w")
        if name:
            ctx = self._last_context
            cnt = [(ctx or {}).get("counts", {}).get(k, app.get(f"vuln_{k}", 0)) for k in ("critical", "high",
                                                                                        "medium", "low")]
            sev = tk.Frame(chip, bg=T["panel_bg"])
            sev.pack(side="left", padx=(px(16), 0))
            parts.append(sev)
            styles = (("C", "err", "err_soft"), ("A", "warn", "warn_soft"), ("M", "sev_medium", "surface3"),
                      ("B", "muted", "surface3"))
            if any(cnt):
                for n, (letter, fg, bg) in zip(cnt, styles):
                    if n:
                        b = tk.Label(sev, text=f"{letter} {n}", font=(FUI, 9, "bold"), bg=T[bg], fg=T[fg], padx=px(7),
                                     pady=px(2))
                        b.pack(side="left", padx=(0, px(4)))
                        parts.append(b)
            elif ctx or app.get("last_scan"):
                b = tk.Label(sev, text=f"{ico('check')}", font=icon_font(9), bg=T["ok_soft"], fg=T["ok"], padx=px(7),
                             pady=px(3))
                b.pack(side="left")
                parts.append(b)
            if len(self._open_app_tabs) > 1:
                more = tk.Label(chip, text=f"+{len(self._open_app_tabs) - 1}", font=(FUI, 9, "bold"),
                                bg=T["surface3"], fg=T["muted"], padx=px(6), pady=px(2))
                more.pack(side="left", padx=(px(8), 0))
                parts.append(more)
        chev = tk.Label(chip, text=ico("chev_down"), font=icon_font(9), bg=T["panel_bg"], fg=T["muted"])
        chev.pack(side="left", padx=(px(14), px(12)))
        parts.append(chev)

        def paint(on):
            for w in parts:
                if w.cget("bg") in (T["panel_bg"], T["hover"]):
                    w.configure(bg=T["hover"] if on else T["panel_bg"])
        for w in parts:
            w.bind("<Button-1>", lambda _e: self._app_menu(chip))
            w.bind("<Enter>", lambda _e: paint(True))
            w.bind("<Leave>", lambda _e: paint(False))
        Tooltip(chip, "Cambiar de aplicación, abrir otra o cerrarla")
        if hasattr(self, "_refresh_summary"):
            self._refresh_summary()

    def _app_menu(self, anchor):
        m = tk.Menu(self, tearoff=0, font=(FUI, 10), bg=T["panel_bg"], fg=T["text"], activebackground=T["select"],
                    activeforeground=T["select_fg"], bd=0)
        active_id = self._active_app.get("id") if self._active_app else None
        for aid in self._open_app_tabs:
            if app := self._inv_store.get_app(aid):
                m.add_command(label=("●   " if aid == active_id else "      ") + app.get("name", "?"),
                              command=lambda a=aid: self._switch_app_tab(a))
        if self._open_app_tabs:
            m.add_separator()
        m.add_command(label="Abrir otra aplicación…", command=lambda: self._show_tab("apps"))
        m.add_command(label="Nueva aplicación…", command=lambda: self._edit_app_profile(None))
        if active_id:
            m.add_separator()
            m.add_command(label=f"Cerrar «{self._active_app.get('name', '')}»",
                          command=lambda: self._close_app_tab(active_id))
        try:
            m.tk_popup(anchor.winfo_rootx(), anchor.winfo_rooty() + anchor.winfo_height() + px(4))
        finally:
            m.grab_release()

    def _update_app_tab_progress(self, pct: float) -> None:
        pass

    # Cuerpo y barra de estado -----------------------------------------------
    def _build_body(self, parent):
        cf = self._console_frame = tk.Frame(parent, bg=T["panel_bg"], height=px(250))
        cf.pack_propagate(False)
        tk.Frame(cf, bg=T["border"], height=1).pack(fill="x", side="top")
        hdr = tk.Frame(cf, bg=T["panel_bg"], padx=px(16), pady=px(6))
        hdr.pack(fill="x")
        tk.Label(hdr, text=ico("console"), font=icon_font(11), bg=T["panel_bg"], fg=T["muted"]).pack(side="left")
        tk.Label(hdr, text="Registro de actividad", font=(FUI, 11, "bold"), bg=T["panel_bg"],
                 fg=T["text"]).pack(side="left", padx=(px(8), 0))
        self._icon_btn(hdr, "✕", self._toggle_console, tooltip="Cerrar consola (F12)").pack(side="right")
        PillButton(hdr, "Copiar", self._copy_log, icon="copy", variant="ghost").pack(side="right", padx=(0, px(6)))
        box = tk.Frame(cf, bg=T["surface2"])
        box.pack(fill="both", expand=True)
        self._log_widget = tk.Text(box, wrap="word", font=(FMONO, 10), bg=T["surface2"], fg=T["text"],
                                   insertbackground=T["text"], relief="flat", padx=px(16), pady=px(8), height=10,
                                   selectbackground=T["select"], selectforeground=T["select_fg"], bd=0)
        sb = ttk.Scrollbar(box, command=self._log_widget.yview)
        sb.pack(side="right", fill="y")
        self._log_widget.pack(side="left", fill="both", expand=True)
        self._log_widget.configure(yscrollcommand=sb.set)
        for tag, role in (("error", "err"), ("warn", "warn"), ("ok", "ok"), ("scan", "border2")):
            self._log_widget.tag_configure(tag, foreground=T[role])
        if self._console_text:
            self._log_widget.insert("end", self._console_text + "\n")
            self._log_widget.see("end")
        self._log_widget.configure(state="disabled")
        stack = self._stack = tk.Frame(parent, bg=T["bg"])
        stack.pack(side="top", fill="both", expand=True)
        self._tab_frames = {}
        builders = {"scan": self._build_tab_scan, "static": self._build_tab_static, "dast": self._build_tab_dast,
                    "api": self._build_tab_api, "container": self._build_tab_container, "iac": self._build_tab_iac,
                    "reports": self._build_tab_reports, "apps": self._build_tab_apps,
                    "schedule": self._build_tab_schedule, "admin": self._build_tab_admin}
        for key, _label in self.TABS:
            builder = builders[key]
            f = tk.Frame(stack, bg=T["bg"])
            f.place(x=0, y=0, relwidth=1, relheight=1)
            title, sub = PAGE_META[key]
            ph = tk.Frame(f, bg=T["bg"])
            ph.pack(fill="x", padx=px(28), pady=(px(20), px(12)))
            tk.Label(ph, text=title, font=(FUI_TITLE, 19, "bold"), bg=T["bg"], fg=T["text"]).pack(anchor="w")
            tk.Label(ph, text=sub, font=(FUI, 11), bg=T["bg"], fg=T["muted"]).pack(anchor="w", pady=(px(2), 0))
            body = tk.Frame(f, bg=T["bg"])
            body.pack(fill="both", expand=True)
            if key == "scan":
                inner = tk.Frame(body, bg=T["bg"])
                inner.pack(fill="both", expand=True, padx=px(28), pady=(0, px(18)))
                builder(inner)
            else:
                builder(body)
            self._tab_frames[key] = f

    def _build_status_bar(self):
        bar = tk.Frame(self, bg=T["panel_bg"])
        bar.pack(side="bottom", fill="x")
        tk.Frame(bar, bg=T["border"], height=1).pack(side="top", fill="x")
        inner = tk.Frame(bar, bg=T["panel_bg"])
        inner.pack(fill="x", padx=px(14), pady=px(3))
        # Lo de la derecha se empaqueta primero: en pantallas angostas el mensaje largo de estado se recorta en vez
        # de aplastar el botón «Consola».
        tk.Label(inner, text=f"{self._user}   ·   v{APP_VERSION}", font=(FUI, 10), bg=T["panel_bg"],
                 fg=T["muted"]).pack(side="right")
        self._console_btn = self._btn(inner, "Consola", self._toggle_console, variant="ghost", icon="console",
                                      tooltip="Mostrar el registro detallado de lo que hace el escáner (F12). Útil para enviar a soporte.")
        self._console_btn.pack(side="right", padx=(0, px(10)))
        self._status_lbl = tk.Label(inner, textvariable=self._status_var, font=(FUI, 10), bg=T["panel_bg"],
                                    fg=T["muted"], anchor="w")
        self._status_lbl.pack(side="left", fill="x", expand=True)
        self._status_lbl.bind("<Button-1>", lambda _e: self._key_auth_status != "auth" and not self._any_busy()
                              and self._show_auth_status_popup())
        tip(self._status_lbl, lambda: self._status_var.get())
        self._status_pb = ttk.Progressbar(inner, style="Thin.Horizontal.TProgressbar", length=px(180), maximum=100)
        self._paint_console_btn()   # conserva el distintivo de entradas sin leer tras reconstruir (p. ej. cambio de tema)

    # ── Componentes reutilizables ────────────────────────────────────────────
    def _scrollable(self, parent) -> tk.Frame:
        return scroll_frame(parent, pad=(px(28), px(4)))

    def _card(self, parent, title="", *, pady=(0, CARD_GAP), collapsible=True, start_collapsed=False,
              pack=True) -> tk.Frame:
        p = T["panel_bg"]
        outer = tk.Frame(parent, bg=p, highlightthickness=1, highlightbackground=T["border"])
        if pack:
            outer.pack(fill="x", pady=pady)
        hdr = right = chev = None
        if title:
            hdr = tk.Frame(outer, bg=p, padx=px(18), pady=px(12))
            hdr.pack(fill="x")
            if collapsible:
                chev = tk.Label(hdr, text=ico("chev_down"), font=icon_font(9), bg=p, fg=T["muted"], cursor="hand2")
                chev.pack(side="left", padx=(0, px(8)))
            ttl = tk.Label(hdr, text=title, font=(FUI_TITLE, 13, "bold"), bg=p, fg=T["card_fg"],
                           cursor="hand2" if collapsible else "")
            ttl.pack(side="left")
            right = tk.Frame(hdr, bg=p)
            right.pack(side="right")
        inner = tk.Frame(outer, bg=p, padx=px(18))
        ipad = (0 if title else px(14), px(16))
        inner.pack(fill="both", expand=True, pady=ipad)
        items = tk.Frame(inner, bg=p)
        items.pack(fill="both", expand=True)
        if title and collapsible:
            state = {"open": True}

            def toggle(_e=None):
                state["open"] = not state["open"]
                if state["open"]:
                    inner.pack(fill="both", expand=True, pady=ipad)
                else:
                    inner.pack_forget()
                chev.configure(text=ico("chev_down") if state["open"] else ico("chev_right"))
            for w in (hdr, chev, ttl):
                w.bind("<Button-1>", toggle)
            if start_collapsed:
                toggle()
        items.outer, items.right, items.header = outer, right, hdr
        return items

    def _alert(self, parent, kind, title, body="", action=None, cmd=None):
        fg_role, soft, glyph = _KIND_COLOR.get(kind, _KIND_COLOR["info"])
        bg = T[soft]
        f = tk.Frame(parent, bg=bg)
        tk.Frame(f, bg=T[fg_role], width=px(3)).pack(side="left", fill="y")
        row = tk.Frame(f, bg=bg, padx=px(14), pady=px(10))
        row.pack(side="left", fill="both", expand=True)
        tk.Label(row, text=ico(glyph), font=icon_font(12), bg=bg, fg=T[fg_role]).pack(side="left", anchor="n",
                                                                                      pady=(px(2), 0))
        if action and cmd:  # el botón se empaqueta antes que el texto: en pantallas angostas el texto se ajusta, no el botón
            PillButton(row, action, cmd, variant="secondary").pack(side="right", padx=(px(12), 0))
        col = tk.Frame(row, bg=bg)
        col.pack(side="left", fill="x", expand=True, padx=(px(12), 0))
        t = autowrap(tk.Label(col, text=title, font=(FUI, 11, "bold"), bg=bg, fg=T["text"], anchor="w", justify="left"))
        t.pack(fill="x")
        if body:
            autowrap(tk.Label(col, text=body, font=(FUI, 10), bg=bg, fg=T["muted"], anchor="w",
                              justify="left")).pack(fill="x")
        return f, t

    @staticmethod
    def _limit_wrap(widget, width: int) -> None:
        """Fija un ancho de ajuste inicial para que un diálogo autoajustable no se estire a todo lo ancho."""
        for w in widget.winfo_children():
            if isinstance(w, tk.Label) and w.cget("text"):
                w.configure(wraplength=width)
            ScannerApp._limit_wrap(w, width)

    def _safety_banner(self, parent, text: str) -> tk.Frame:
        f, _ = self._alert(parent, "warn", text)
        f.pack(fill="x", pady=(0, px(12)))
        return f

    def _lbl(self, parent, text="", size=12, bold=False, bg=None, fg=None, **kw) -> tk.Label:
        return tk.Label(parent, text=text, font=(FUI, size, "bold" if bold else "normal"),
                        bg=bg or T["panel_bg"], fg=fg or T["card_fg"], **kw)

    def _btn(self, parent, text, cmd, *, variant=None, icon=None, tooltip=None, **legacy):
        if variant is None:
            low = (text or "").lower()
            variant = "primary" if any(h in low for h in _PRIMARY_HINTS) else "secondary"
        b = PillButton(parent, text, cmd, icon=icon, variant=variant, tooltip=tooltip)
        if legacy.get("state") == "disabled":
            b.configure(state="disabled")
        return b

    def _icon_btn(self, parent, text: str, cmd, *, danger: bool = False, tooltip=None):
        t = (text or "").strip()
        variant = "danger_outline" if danger else ("primary" if t == "▶" else "secondary")
        b = PillButton(parent, text, cmd, variant=variant, square=True, tooltip=tooltip or ICON_TIPS.get(t))
        b.wrap, b.role = b, variant
        return b

    def _set_icon_btn_enabled(self, btn, enabled: bool):
        btn.configure(state="normal" if enabled else "disabled")

    def _spin(self, parent, label, var, frm, to, *, width=6, padx=(0, 0)):
        if label:
            self._lbl(parent, label).pack(side="left", padx=(0, px(6)))
        sp = ttk.Spinbox(parent, from_=frm, to=to, textvariable=var, width=width)
        sp.pack(side="left", padx=padx)
        return sp

    def _hdiv(self, parent, **pk) -> tk.Frame:
        f = tk.Frame(parent, bg=T["border"], height=1)
        f.pack(fill="x", **pk)
        return f

    def _kind_badge(self, parent, kind: str, size: int = 40) -> tk.Canvas:
        fg_role, soft, glyph = _KIND_COLOR.get(kind, _KIND_COLOR["info"])
        d = px(size)
        c = tk.Canvas(parent, width=d, height=d, bg=_bg_of_widget(parent), highlightthickness=0, bd=0)
        c.create_oval(0, 0, d - 1, d - 1, fill=T[soft], outline="")
        c.create_text(d // 2, d // 2, text=ico(glyph), font=icon_font(max(9, size // 3)), fill=T[fg_role])
        return c

    # ── Diálogos ─────────────────────────────────────────────────────────────
    def _popup(self, title: str, w_pct=None, h_pct=None, on_escape=None) -> tk.Frame:
        min_w = 0
        if w_pct is None and title in LARGE_POPUPS:
            spec = LARGE_POPUPS[title]
            w_pct, h_pct = spec[:2]
            min_w = px(spec[2]) if len(spec) > 2 else 0
        win = tk.Toplevel(self)
        win.title(title)
        return make_modal(win, self, w_pct, h_pct, on_escape, min_w=min_w)

    def _popup_hdr(self, popup, title, subtitle="", icon="", on_close=None, icon_image=None) -> tk.Frame:
        bg = T["panel_bg"]
        hdr = tk.Frame(popup, bg=bg, padx=px(24), pady=px(18))
        hdr.pack(fill="x")
        row = tk.Frame(hdr, bg=bg)
        row.pack(fill="x")
        if icon_image is not None:
            lbl = tk.Label(row, image=icon_image, bg=bg)
            lbl.image = icon_image
            lbl.pack(side="left", padx=(0, px(10)))
        elif icon:
            name, _ = split_icon(icon)
            if name:
                tk.Label(row, text=ico(name), font=icon_font(14), bg=bg, fg=T["muted"]).pack(side="left",
                                                                                           padx=(0, px(10)))
        tk.Label(row, text=title, font=(FUI_TITLE, 15, "bold"), bg=bg, fg=T["text"]).pack(side="left")
        close = on_close or getattr(popup, "close", None)
        if close:
            x = tk.Label(row, text=ico("close"), font=icon_font(10), bg=bg, fg=T["muted"], cursor="hand2",
                         padx=px(6), pady=px(4))
            x.pack(side="right")
            x.bind("<Button-1>", lambda _e: close())
            x.bind("<Enter>", lambda _e: x.config(fg=T["err"], bg=T["err_soft"]))
            x.bind("<Leave>", lambda _e: x.config(fg=T["muted"], bg=bg))
        if subtitle:
            tk.Label(hdr, text=subtitle, font=(FUI, 11), bg=bg, fg=T["muted"], anchor="w", justify="left",
                     wraplength=px(640)).pack(fill="x", pady=(px(4), 0))
        hdr._row = row
        popup._hdr_title = title
        return hdr

    def _popup_foot(self, popup, *items, with_status=False, primary="auto"):
        bg = T["panel_bg"]
        first = popup.pack_slaves()[0] if popup.pack_slaves() else None
        bar = tk.Frame(popup, bg=bg, padx=px(24), pady=px(14))
        bar.pack(fill="x", side="bottom", **({"before": first} if first is not None else {}))
        tk.Frame(popup, bg=T["border"], height=1).pack(fill="x", side="bottom",
                                                       **({"before": first} if first is not None else {}))
        row = tk.Frame(bar, bg=bg)
        row.pack(fill="x")
        dismiss = [it for it in items if _norm_label(it[0]) in _DISMISS]
        acts = [it for it in items if it not in dismiss]
        if primary == "auto":
            prim = acts[-1] if 1 <= len(acts) <= 2 else (dismiss[-1] if not acts and dismiss else None)
        else:
            prim = next((it for it in items if primary and _norm_label(it[0]) == _norm_label(primary)), None)
        ordered = [it for it in acts if it is not prim] + ([prim] if prim else []) + [d for d in dismiss if d is not prim]
        bar.buttons = []
        for text, cmd in reversed(ordered):
            danger = any(h in text.lower() or h in text for h in _DANGER_HINTS)
            variant = ("danger" if danger else "primary") if (text, cmd) == prim else \
                ("danger_outline" if danger else "secondary")
            b = PillButton(row, text, cmd, variant=variant)
            b.pack(side="right", padx=(px(8), 0))
            bar.buttons.append(b)
        if not with_status:
            return bar
        status = autowrap(tk.Label(bar, text="", font=(FUI, 10), bg=bg, fg=T["warn"], anchor="w", justify="left"))
        status.pack(fill="x", pady=(px(6), 0))
        return bar, status

    def _message_body(self, popup, kind, title, message, msg_fg=None):
        bg = T["bg"]
        body = tk.Frame(popup, bg=bg, padx=px(26), pady=px(24))
        body.pack(fill="both", expand=True)
        self._kind_badge(body, kind).pack(side="left", anchor="n", padx=(0, px(16)))
        col = tk.Frame(body, bg=bg)
        col.pack(side="left", fill="both", expand=True)
        if title:
            tk.Label(col, text=title, font=(FUI_TITLE, 15, "bold"), bg=bg, fg=T["text"], anchor="w",
                     justify="left").pack(fill="x")
        tk.Label(col, text=message, font=(FUI, 11), bg=bg, fg=msg_fg or T["text"], anchor="w", justify="left",
                 wraplength=px(520)).pack(fill="x", pady=(px(6) if title else 0, 0))

    def _centered_msg(self, popup, icon, icon_color, title, message, msg_fg):
        kind = {"⚠": "warn", "!": "warn", "✕": "error", "ℹ": "info", "✓": "ok"}.get(icon, "info")
        if getattr(popup, "_hdr_title", None) == title:
            title = ""
        self._message_body(popup, kind, title, message, T["text"] if msg_fg in (T["text"], T["err"]) else msg_fg)

    def _choice_card(self, parent, icon, title, desc, *, enabled=True, icon_size=20, desc_wrap=None,
                     on_click=None, selected=None) -> tk.Frame:
        p = T["panel_bg"]
        fg = T["text"] if enabled else T["muted"]
        card = tk.Frame(parent, bg=p, highlightthickness=1, highlightbackground=T["border"],
                        cursor="hand2" if enabled else "arrow")
        card.pack(side="left", padx=px(6), ipadx=px(12), ipady=px(10), fill="both", expand=True)
        name, _ = split_icon(icon)
        tk.Label(card, text=ico(name) if name else icon, font=icon_font(icon_size) if name else (FUI, icon_size),
                 bg=p, fg=T["accent"] if enabled else T["muted"]).pack(pady=(px(10), px(6)))
        tk.Label(card, text=title, font=(FUI, 12, "bold"), bg=p, fg=fg).pack()
        tk.Label(card, text=desc, font=(FUI, 10), bg=p, fg=T["muted"] if enabled else T["border_strong"],
                 justify="center", wraplength=desc_wrap or px(200)).pack(pady=(px(4), px(8)))
        if enabled and on_click:
            for w in (card, *card.winfo_children()):
                w.bind("<Button-1>", lambda _e: on_click())
            hl = lambda on: card.configure(highlightbackground=T["accent"] if on or (selected and selected())
                                           else T["border"])
            card.bind("<Enter>", lambda _e: hl(True))
            card.bind("<Leave>", lambda _e: hl(False))
            card.refresh = lambda: hl(False)
        return card

    def _show_popup(self, title: str, message: str, kind: str = "info"):
        popup = self._popup(title)
        self._message_body(popup, kind, title, message)
        self._popup_foot(popup, ("Aceptar", popup.close))

    def _show_info_popup(self, title, message):
        self._show_popup(title, message, "info")

    def _show_warn_popup(self, title, message):
        self._show_popup(title, message, "warn")

    def _show_error_popup(self, title, message):
        self._show_popup(title, message, "error")

    def _show_confirm_popup(self, title, message, *, on_yes, yes_label="Sí", no_label="No", extra=None):
        popup = self._popup(title)
        danger = any(h in yes_label.lower() or h in yes_label for h in _DANGER_HINTS)
        self._message_body(popup, "error" if danger else "warn", title, message)

        def yes():
            popup.close()
            on_yes()
        items = [(no_label, popup.close)]
        if extra:
            label, fn = extra
            items.append((label, lambda: (popup.close(), fn())))
        self._popup_foot(popup, *items, (yes_label, yes))

    def _confirm_scan_without_app(self, on_proceed) -> None:
        if self._active_app and self._active_app.get("name"):
            on_proceed()
            return
        self._show_confirm_popup(
            "Sin aplicación cargada",
            "Los resultados se guardarán sin catalogar (carpeta '_unscoped') y no aparecerán en el historial ni en "
            "las tendencias de ninguna aplicación del Inventario.\n\nPara catalogarlos, cargue o cree una aplicación "
            "antes de escanear.",
            on_yes=on_proceed, yes_label="Continuar de todos modos", no_label="Cancelar",
            extra=("📂  Elegir aplicación", lambda: self._show_tab("apps")))

    def _show_probely_verify_popup(self, stage: str, evidence: str):
        m = re.search(r"verification token:\s*([^\s).]+)", evidence or "", re.I)
        token = m.group(1) if m else ""
        self._show_info_popup("Verificación de dominio requerida (Probely)",
            f"El dominio del objetivo {stage.upper()} NO está verificado en Snyk API & Web.\n"
            "Probely solo permite escaneos 'lightning' hasta verificar el dominio.\n\n"
            + (f"Token de verificación:\n{token}\n\n" if token else "")
            + "Métodos de verificación disponibles:\n  · dns_txt — registro TXT en el DNS del dominio\n"
            "  · dns_cname — registro CNAME en el DNS\n  · meta_tag — etiqueta <meta> en la página índice\n"
            "  · file — archivo de texto en la raíz del sitio\n"
            "  · email / aws_route53 / cloudflare — verificación automática\n\n"
            "Verifique el dominio en el panel de Probely (plus.us.probely.app) y reintente el escaneo.")

    def _show_help(self) -> None:
        popup = self._popup("Ayuda")
        self._popup_hdr(popup, "Ayuda y atajos", subtitle=f"{APP_BRAND_NAME}  ·  versión {APP_VERSION}")
        bg = T["bg"]
        body = tk.Frame(popup, bg=bg, padx=px(24), pady=px(4))
        body.pack(fill="both", expand=True)
        card = self._card(body, "Atajos de teclado", collapsible=False)
        for i, (keys, desc) in enumerate(SHORTCUTS):
            tk.Label(card, text=keys, font=(FMONO, 10), bg=T["surface3"], fg=T["text"], padx=px(8), pady=px(2)).grid(
                row=i, column=0, sticky="w", pady=px(3))
            tk.Label(card, text=desc, font=(FUI, 11), bg=T["panel_bg"], fg=T["text"]).grid(
                row=i, column=1, sticky="w", padx=(px(14), 0))
        snyk = self._card(body, "Inicio de sesión en Snyk", collapsible=False)
        tk.Label(snyk, text=SNYK_SSO_WARNING, font=(FUI, 10), bg=T["panel_bg"], fg=T["text"], justify="left",
                 anchor="w", wraplength=px(560)).pack(fill="x")
        eng = self._card(body, "Motores de escaneo", collapsible=False)
        iac_eng = "Checkov + Trivy + SonarQube (local)" if self._sonar_on() else "Checkov + Trivy"
        tk.Label(eng, text=f"Web y API: OWASP ZAP + Nuclei · Contenedores: Trivy · IaC: {iac_eng}. Se descargan y "
                 "verifican solos la primera vez que se usan (sin Docker ni permisos de administrador).", font=(FUI, 10),
                 bg=T["panel_bg"], fg=T["text"], justify="left", anchor="w", wraplength=px(560)).pack(fill="x")
        PillButton(eng, "Ver estado de los motores", lambda: (popup.close(), self._show_engines_popup()),
                   icon="engine").pack(anchor="w", pady=(px(10), 0))
        sup = self._card(body, "Soporte de software", collapsible=False)
        tk.Label(sup, text=f"¿Algo no funciona? Escríbanos e incluya el archivo data/boot_dependencies.log y la "
                           f"consola (botón Copiar).\n{SUPPORT_EMAIL}", font=(FUI, 11), bg=T["panel_bg"],
                 fg=T["text"], justify="left", anchor="w").pack(fill="x")
        self._btn(sup, "✉  Contactar soporte", lambda: webbrowser.open(
            f"mailto:{SUPPORT_EMAIL}?subject=Soporte%20Snyk%20Scanner%20GUI")).pack(anchor="w", pady=(px(10), 0))
        self._popup_foot(popup, ("Cerrar", popup.close))

    def _on_app_close(self, force: bool = False):
        if not force and not self._headless and self._any_busy():
            # Cerrar a mitad de un escaneo lo pierde sin aviso: se confirma primero.
            return self._show_confirm_popup(
                "Escaneo en curso", "Hay un escaneo en ejecución. Si cierra ahora se perderá y el reporte no se "
                "generará.\n\n¿Cerrar de todos modos?", on_yes=lambda: self._on_app_close(force=True),
                yes_label="Cerrar y detener", no_label="Seguir escaneando")
        try:
            self._save_settings()
        except Exception:
            pass
        try:
            import sonar_local          # apaga el SonarQube local si se levantó en esta sesión
            sonar_local.stop()
        except Exception:
            pass
        GUI_PID_FILE.unlink(missing_ok=True)
        try:
            release_owner()
        except Exception:
            pass
        try:
            if self._session_log:
                self._session_log.close()
        except Exception:
            pass
        try:
            self.destroy()
        except Exception:
            pass
        subprocess.run(["taskkill", "/F", "/T", "/PID", str(os.getpid())], capture_output=True, **NOWIN)
        os._exit(0)

    def _bg_check_tool_updates(self) -> None:
        """Consulta (máx. cada 12 h, en segundo plano) si hay versiones nuevas de los motores: la píldora «Motores»
        lo indica y desde su ventana cualquier usuario puede actualizarlos."""
        def work():
            try:
                import tool_manager as tm
                tm.check_updates(lambda *_: None, force=False)
            except Exception:
                pass
            self._ui(self._paint_badges)
        threading.Thread(target=work, daemon=True).start()

    def _maybe_open_wizard_on_first_launch(self) -> None:
        if not self._wizard_seen and not SESSION_FILE.exists():
            self._wizard_seen = True
            self._save_settings()
            self.open_wizard()

    def _servicenow_configured(self) -> bool:
        """True si la cuenta de integración (embebida y cifrada en el programa) y el catalog item están disponibles."""
        try:
            import test_servicenow_ticket as snow
            env = snow.scanner_environment()
            return bool(env.base_url and env.sys_id and snow.scanner_auth(env))
        except Exception:
            return False

    @staticmethod
    def _servicenow_probe() -> tuple[str, str]:
        """Comprueba la cuenta de integración contra ServiceNow (GET de solo lectura de 1 registro).
        Devuelve (estado, detalle): none | ok | invalid | unverified."""
        try:
            import test_servicenow_ticket as snow
            env = snow.scanner_environment()
            pair = snow.scanner_auth(env)
        except Exception as e:
            return "none", f"no se pudo leer la configuración de ServiceNow ({e!r})"
        if not pair:
            return "none", "la cuenta de integración no está disponible en esta copia del programa"
        if not (env.base_url and env.sys_id):
            return "none", f"falta la URL o el catalog item de ServiceNow ({env.label})"
        import requests
        auth, hdrs = pair
        user = auth[0] if auth else "token"
        base = env.base_url.rstrip("/")
        url = f"{base}/api/now/table/sys_user"
        kw = {"params": {"sysparm_limit": 1, "sysparm_fields": "sys_id"}, "timeout": 20,
              "headers": {"Accept": "application/json", **(hdrs or {})}}
        if auth:
            kw["auth"] = auth
        try:
            try:
                r = requests.get(url, **kw)
            except requests.exceptions.SSLError:
                ca = ss._ca(lambda _m: None)
                r = requests.get(url, verify=ca or False, **kw)
        except Exception as e:
            return "unverified", f"no se pudo conectar con {base} ({type(e).__name__})"
        if r.status_code in (401, 403):
            return "invalid", (f"ServiceNow ({env.label}) rechazó la cuenta de integración «{user}» "
                               f"(HTTP {r.status_code}). Ciberseguridad debe rotar la contraseña embebida.")
        if r.status_code >= 400:
            return "unverified", f"ServiceNow respondió HTTP {r.status_code}"
        return "ok", f"conectado a {env.label} con la cuenta de integración"

    def _refresh_servicenow_state(self, on_done=None) -> None:
        """Verifica en segundo plano; la palomita de «Preparación» solo aparece si ServiceNow aceptó el inicio de sesión."""
        if not self._servicenow_configured():
            return self._apply_servicenow_state("none", "la cuenta de integración de ServiceNow no está disponible en esta copia del programa", on_done)
        self._snow_state, self._snow_ok = "checking", False
        if hasattr(self, "_refresh_scan_btn"):
            self._refresh_scan_btn()

        def work():
            try:
                st, detail = self._servicenow_probe()
            except Exception as e:
                st, detail = "unverified", repr(e)
            self._ui(self._apply_servicenow_state, st, detail, on_done)
        threading.Thread(target=work, daemon=True).start()

    def _apply_servicenow_state(self, st: str, detail: str, on_done=None) -> None:
        prev = getattr(self, "_snow_state", None)
        self._snow_state, self._snow_detail, self._snow_ok = st, detail, st == "ok"
        if st != prev and st in ("invalid", "unverified"):
            self._emit_log(f"[servicenow] ⚠ {detail} — no se crearán tickets hasta corregirlo (Escanear → Preparación).")
        if hasattr(self, "_refresh_scan_btn"):
            self._refresh_scan_btn()
        if on_done:
            on_done(st, detail)

    def _show_servicenow_setup(self) -> None:
        """Ya no se piden credenciales: muestra el estado de la cuenta de integración y permite volver a verificar."""
        popup = self._popup("ServiceNow")
        self._popup_hdr(popup, "Creación automática de tickets", subtitle="ServiceNow")
        bg = T["bg"]
        body = tk.Frame(popup, bg=bg, padx=px(24), pady=px(4))
        body.pack(fill="both", expand=True)
        tk.Label(body, text="El escáner crea, actualiza y cierra tickets automáticamente cuando encuentra "
                 "vulnerabilidades altas o críticas. Usa la cuenta de integración de Ciberseguridad incluida en el "
                 "programa; el ticket queda a su nombre (solicitante: su usuario de Windows).\n\nNo necesita "
                 "capturar usuario ni contraseña.",
                 font=(FUI, 11), bg=bg, fg=T["text"], justify="left", wraplength=px(500)).pack(anchor="w",
                                                                                            pady=(0, px(10)))
        state_lbl = tk.Label(body, text=getattr(self, "_snow_detail", "") or "Sin verificar", font=(FUI, 10),
                             bg=bg, fg=T["muted"], justify="left", wraplength=px(500))
        state_lbl.pack(anchor="w", pady=(0, px(10)))

        def recheck():
            status.config(text="Verificando…")

            def done(st, detail):
                try:
                    state_lbl.config(text=detail)
                    status.config(text={"ok": "Conectado ✓", "invalid": "Rechazada — avise a Ciberseguridad",
                                        "none": "No disponible — avise a Ciberseguridad"}.get(st, "Sin conexión"))
                except tk.TclError:
                    pass
                if st == "ok":
                    self._toast("ServiceNow conectado ✓", "ok")
            self._refresh_servicenow_state(on_done=done)
        _, status = self._popup_foot(popup, ("Cerrar", popup.close), ("Verificar conexión", recheck), with_status=True)

    # ── Estado de conexiones ─────────────────────────────────────────────────
    def _load_status_icon(self, name: str):
        if name not in self._status_icons:
            self._status_icons[name] = load_image(ICON_DIR / "interface" / f"{name}.png")
        return self._status_icons[name]

    def _paint_badges(self):
        if not hasattr(self, "_badges"):
            return
        colors = {"unauth": T["err"], "checking": T["warn"], "auth": T["ok"]}
        eng_status, eng_tip = self._engines_summary()
        tips = {"snyk": {"auth": "Snyk: sesión SSO activa", "checking": "Snyk: verificando sesión…",
                         "unauth": "Snyk: sin sesión — clic para iniciar. " + SNYK_SSO_SHORT},
                "engines": {s: eng_tip for s in ("auth", "checking", "unauth")},
                "probely": {"auth": "Probely: clave de la política validada", "checking": "Probely: validando clave…",
                            "unauth": "Probely: clave sin validar — clic para administrar"}}
        if eng_status == "unauth":
            eng_status = "checking"   # sin descargar no es un error: se instalan al escanear
        for key, status in (("snyk", self._key_auth_status), ("engines", eng_status),
                            ("probely", self._probely_auth_status)):
            pill = self._badges.get(key)
            if pill is None or not pill.winfo_exists():
                continue
            pill.dot.itemconfigure("o", fill=colors.get(status, T["err"]))
            pill.tip_text = tips[key].get(status, tips[key]["unauth"])

    def _set_key_status(self, status: str):
        self._key_auth_status = status
        self._paint_badges()
        self._set_idle_status()
        if (wiz := getattr(self, "_wizard_instance", None)) is not None:
            wiz.refresh_if_auth_step()

    def _set_probely_status(self, status: str):
        self._probely_auth_status = status
        if hasattr(self, "_badges"):
            self._paint_badges()
            self._refresh_scan_btn()

    def _probely_configured(self) -> bool:
        return bool(admin_policy.probely_key())

    def _validate_probely_key(self, on_done=None):
        """Solo administradores: valida la clave de Probely guardada en la política."""
        key = admin_policy.probely_key()
        if not self._is_admin or not key:
            self._set_probely_status("unauth")
            if on_done:
                on_done(False, "No hay clave de Probely en la política.")
            return
        self._set_probely_status("checking")
        cfg = self._collect_dast_cfg()
        cfg.probely_token = key

        def work():
            from probely_engine import check_snyk_api_web
            try:
                ok, msg = check_snyk_api_web(cfg, self._emit_log)
            except Exception as e:
                ok, msg = False, f"Error de validación: {e!r}"

            def done():
                self._set_probely_status("auth" if ok else "unauth")
                self._log_line(f"[probely] {'✓' if ok else '✕'} {msg}")
                if on_done:
                    on_done(ok, msg)
            self._ui(done)
        threading.Thread(target=work, daemon=True).start()

    def _show_probely_key_popup(self):
        """Probely es exclusivo de Ciberseguridad: la clave y las aplicaciones asignadas se administran en su página."""
        if self._is_admin:
            return self._show_tab("admin")
        _, label = admin_policy.engine_label(self._active_app)
        self._show_info_popup("Motor de escaneo web", f"Esta aplicación usa: {label}.\n\nLas licencias de Probely las "
                              "asigna Ciberseguridad por aplicación; no necesita configurar nada.")

    def _update_stop_btn_style(self):
        self._refresh_scan_btn()


def _bg_of_widget(w) -> str:
    try:
        return w.cget("bg")
    except Exception:
        return T["bg"]


class BootSplash(tk.Toplevel):
    def __init__(self, master: tk.Misc, modal: bool = True):
        super().__init__(master)
        self.overrideredirect(True)
        self.attributes("-topmost", True)
        if modal:
            self.transient(master)
        dark = bool((read_json(SETTINGS_FILE, {}) or {}).get("dark_mode"))
        apply_palette(dark)
        x, y = last_window_anchor()
        if x is not None:
            self.geometry(f"+{x}+{y}")
            self.update_idletasks()
        W, H = px(580), px(470)
        mx, my, mw, mh = monitor_rect(self)
        self.geometry(f"{W}x{H}+{mx + (mw - W) // 2}+{my + (mh - H) // 2}")
        c = panel_chrome(self)
        p = T["panel_bg"]
        c.configure(bg=p)
        round_corners(self)
        top = tk.Frame(c, bg=p)
        top.pack(fill="x", padx=px(10), pady=(px(8), 0))
        mn = tk.Label(top, text="–", font=(FUI, 12, "bold"), bg=p, fg=T["muted"], cursor="hand2", padx=px(8))
        mn.pack(side="right")
        mn.bind("<Button-1>", lambda _e: self._minimize())
        Tooltip(mn, "Minimizar")
        body = tk.Frame(c, bg=p)
        body.pack(fill="both", expand=True, padx=px(32), pady=(0, px(22)))
        self._logo = load_image(DARK_LOGO_PATH if dark and DARK_LOGO_PATH.exists() else LOGO_PATH, px(200))
        if self._logo:
            tk.Label(body, image=self._logo, bg=p).pack(pady=(0, px(10)))
        tk.Label(body, text=APP_BRAND_NAME, font=(FUI_TITLE, 17, "bold"), bg=p, fg=T["text"]).pack()
        tk.Label(body, text="Preparando el motor de escaneo de seguridad", font=(FUI, 11), bg=p,
                 fg=T["muted"]).pack(pady=(px(2), px(18)))
        self._step = tk.StringVar(value="Preparando…")
        tk.Label(body, textvariable=self._step, font=(FUI, 11, "bold"), bg=p, fg=T["text"], anchor="w").pack(fill="x")
        st = ttk.Style(self)
        st.theme_use("clam")
        st.configure("Splash.Horizontal.TProgressbar", troughcolor=T["surface3"], background=T["accent"],
                     bordercolor=T["surface3"], lightcolor=T["accent"], darkcolor=T["accent"], thickness=px(6))
        self._pb = ttk.Progressbar(body, style="Splash.Horizontal.TProgressbar", maximum=100)
        self._pb.pack(fill="x", pady=(px(8), px(12)))
        wrap = tk.Frame(body, bg=T["surface2"])
        wrap.pack(fill="both", expand=True)
        self._log = tk.Text(wrap, bg=T["surface2"], fg=T["muted"], relief="flat", font=(FMONO, 9), padx=px(10),
                            pady=px(8), height=7, state="disabled", wrap="none", bd=0)
        self._log.tag_configure("warn", foreground=T["warn"])
        self._log.tag_configure("err", foreground=T["err"])
        self._log.pack(fill="both", expand=True)
        tk.Label(body, text=f"Windows  ·  {detect_user()}  ·  v{APP_VERSION}", font=(FUI, 9), bg=p,
                 fg=T["muted"]).pack(anchor="w", pady=(px(10), 0))
        self._q: queue.Queue = queue.Queue()
        self._done = self._failed = False
        self._warnings: list = []
        set_window_icon(self, dark, ("apple-touch-icon-boot.png", "apple-touch-icon.png"))
        make_draggable(self)   # sin barra de título: se mueve arrastrando cualquier zona (excepto «–» y el registro)
        self.configure(cursor="fleur")
        self.after(60, self._pump)

    def progress(self, kind, payload):
        self._q.put((kind, payload))

    def _minimize(self):
        self.overrideredirect(False)
        self.state("iconic")
        self._bid = self.bind("<Map>", self._restore, add="+")

    def _restore(self, _e=None):
        if self.state() == "normal":
            self.overrideredirect(True)
            self.attributes("-topmost", True)
            self.unbind("<Map>", self._bid)

    def _pump(self):
        try:
            while True:
                kind, payload = self._q.get_nowait()
                if kind == "step":
                    i, total, label = payload
                    self._step.set(f"{label}   ({i}/{total})")
                    self._pb.configure(value=int(i / max(total, 1) * 100))
                elif kind == "log":
                    text = str(payload)
                    self._log.configure(state="normal")
                    self._log.insert("end", text.rstrip() + "\n",
                                     ("err",) if text.startswith(("FATAL", "ERROR")) else
                                     ("warn",) if text.startswith("⚠") else ())
                    self._log.see("end")
                    self._log.configure(state="disabled")
                elif kind == "warn_summary":
                    self._warnings = list(payload)
                elif kind == "error":
                    self._failed = True
                elif kind == "done":
                    self._step.set(f"Listo con {len(self._warnings)} advertencia(s) — revise el registro"
                                   if self._warnings else "Listo — iniciando…")
                    self._pb.configure(value=100)
                    self._done = True
        except queue.Empty:
            pass
        if self._done or self._failed:
            self.after(1800 if self._warnings else 280, self.destroy)
        else:
            self.after(60, self._pump)


def run_boot() -> tuple:
    root = tk.Tk()
    init_root(root)
    root.withdraw()
    splash = BootSplash(root, modal=False)
    res: dict = {"error": None, "warnings": []}
    progress = splash.progress   # el hilo no debe depender de «splash», que se libera abajo con del

    def worker():
        try:
            res["warnings"] = load_runtime(progress)
        except Exception as e:
            import traceback
            res["error"] = f"{e!r}\n\n{traceback.format_exc()}"
            progress("log", f"ERROR: {e!r}")
            progress("error", str(e))

    t = threading.Thread(target=worker, daemon=True)
    t.start()
    root.wait_window(splash)
    t.join(timeout=10)
    _release_tk_refs(splash, root)
    gc.collect()
    root.destroy()
    del splash, root, worker, t
    # El intérprete Tk del splash debe liberarse AQUÍ (hilo principal). Si queda en un ciclo de referencias, el
    # recolector lo libera más tarde desde un hilo de escaneo y Tcl aborta el proceso con
    # «Tcl_AsyncDelete: async handler deleted by the wrong thread».
    gc.collect()
    return res["error"], res["warnings"]


def _release_tk_refs(*widgets) -> None:
    """Suelta imágenes y variables de Tk guardadas como atributos para que se destruyan en el hilo principal."""
    for w in widgets:
        for k, v in list(vars(w).items()):
            if isinstance(v, (tk.Image, tk.Variable)) or (
                    isinstance(v, (list, tuple)) and any(isinstance(x, (tk.Image, tk.Variable)) for x in v)):
                setattr(w, k, None)


def _fatal(msg: str):
    try:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(f"{APP_BRAND_NAME} — error al inicio", msg)
    except Exception:
        print(msg, file=sys.stderr)


def main():
    err, warnings = run_boot()
    if err:
        return _fatal(f"El escáner no pudo cargar sus dependencias:\n\n{err}\n\n"
                      "Normalmente se debe a un paquete faltante o a un proxy TLS corporativo.")
    gc.collect()
    gc.disable()  # se recolecta periódicamente desde el hilo de Tk (ScannerApp._drain)
    try:
        app = ScannerApp(boot_warnings=warnings)
    except Exception as e:
        import traceback
        _fatal(f"El escáner no pudo iniciar:\n\n{e!r}\n\n{traceback.format_exc()}")
        raise
    app.mainloop()


if __name__ == "__main__":
    main()
