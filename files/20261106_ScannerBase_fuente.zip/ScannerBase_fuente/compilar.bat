@echo off
setlocal
REM Compila ScannerBase.exe (carpeta dist\ScannerBase). Requiere Python 3.12 o superior solo en la PC que compila.
REM Detecta solo la version instalada: prefiere 3.12 (la probada) y si no existe usa 3.13, 3.14 o el Python 3 disponible.
cd /d "%~dp0"

set "PY="
for %%V in (3.12 3.13 3.14) do (
    if not defined PY (
        py -%%V -c "import sys" >nul 2>&1 && set "PY=py -%%V"
    )
)
if not defined PY (
    py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 12) else 1)" >nul 2>&1 && set "PY=py -3"
)
if not defined PY (
    python -c "import sys; sys.exit(0 if sys.version_info >= (3, 12) else 1)" >nul 2>&1 && set "PY=python"
)
if not defined PY (
    echo No se encontro Python 3.12 o superior.
    echo Instalelo desde python.org marcando "py launcher", "Add python.exe to PATH" y "tcl/tk and IDLE".
    goto :err
)

for /f "delims=" %%I in ('%PY% -c "import sys; print(sys.version.split()[0])"') do set "PYVER=%%I"
echo Usando Python %PYVER%  (%PY%)
echo.

%PY% -c "import tkinter" >nul 2>&1 || (
    echo Esta instalacion de Python no incluye tcl/tk ^(tkinter^), necesario para la interfaz.
    echo Panel de control ^> Programas ^> Python %PYVER% ^> Modificar ^> marque "tcl/tk and IDLE".
    goto :err
)

%PY% -m pip install --upgrade pyinstaller jinja2 selenium webdriver-manager pynput pyyaml requests send2trash || goto :err
%PY% -m PyInstaller --noconfirm --clean ScannerBase.spec || goto :err
REM Firma opcional con el certificado de firma de codigo de Banco Base (evita avisos de SmartScreen/antivirus):
REM signtool sign /fd SHA256 /tr http://timestamp.digicert.com /td SHA256 /n "Banco Base" dist\ScannerBase\ScannerBase.exe
echo.
echo Listo: dist\ScannerBase\ScannerBase.exe  (compilado con Python %PYVER%)
pause
exit /b 0

:err
echo Fallo la compilacion.
pause
exit /b 1