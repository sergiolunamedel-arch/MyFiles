# -*- mode: python ; coding: utf-8 -*-
# Compilar en Windows:  py -m PyInstaller --noconfirm --clean ScannerBase.spec
import glob, os
from PyInstaller.utils.hooks import collect_submodules

CORE = [os.path.splitext(os.path.basename(p))[0] for p in glob.glob(os.path.join("core", "*.py"))]
hidden = CORE + ["INICIAR_SnykScannerGUI"] + collect_submodules("pynput") + collect_submodules("webdriver_manager") + collect_submodules("selenium")

a = Analysis(
    ["ScannerBase.py"],
    pathex=["core", "."],
    datas=[("images", "images")],
    hiddenimports=hidden,
    excludes=["matplotlib", "numpy", "pandas", "PIL", "IPython", "pytest", "unittest", "pydoc_data", "lib2to3",
              "test", "tkinter.test", "idlelib"],
    noarchive=False,
    optimize=0,
)
# Solo Windows: quita los binarios de selenium-manager para Linux/macOS (~25 MB menos).
a.datas = [d for d in a.datas if not any(x in d[0].replace("\\", "/") for x in
           ("selenium/webdriver/common/linux", "selenium/webdriver/common/macos"))]
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, [],
    exclude_binaries=True,           # onedir: arranca rápido (no se descomprime nada en cada inicio)
    name="ScannerBase",
    icon="images/icon/light/favicon.ico",
    version="build_cfg/version_info.txt",
    console=False,                   # sin ventana negra de consola
    upx=False,                       # UPX dispara falsos positivos de antivirus y hace más lento el arranque
    uac_admin=False,
)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name="ScannerBase")
