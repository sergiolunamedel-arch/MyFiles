from __future__ import annotations

import csv
import hashlib
import io
import threading
import zipfile
from urllib.parse import urlparse

from ui_common import *

SEVERITY_ORDER = SEV_ORDER
SEV_ES_LOWER = {"critical": "crítica", "high": "alta", "medium": "media", "low": "baja", "info": "info"}
STATUS_ES = {"remediated": "remediada", "manual": "manual", "regression": "regresión"}
_env = None


def _jinja():
    global _env
    if _env is None:
        try:
            from jinja2 import Environment
        except ImportError:
            raise RuntimeError("Jinja2 no está instalado, así que no se puede generar el reporte HTML. Reinicie el "
                               "programa con conexión a internet para que el arranque lo instale automáticamente, o "
                               "instálelo a mano: pip install --user Jinja2")
        _env = Environment(autoescape=True)
    return _env


def _render(template: str, out: Path, **ctx) -> Path:
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(_jinja().from_string(template).render(sev_es=SEV_ES_LOWER, **ctx), encoding="utf-8")
    return out


def _trunc(text: str, limit: int = 2000) -> str:
    text = (text or "").strip()
    if len(text) <= limit:
        return text
    return (text[:limit].rsplit(" ", 1)[0].rstrip(" .,;:—-") or text[:limit]) + "…"


_REMEDIATION_MARKERS = ("## remediation", "### remediation", "remediation:", "how to fix", "## how to fix", "## fix",
                        "recommended fix:", "mitigation:")
_STRONG_KW = ("sanitiz", "parameteri", "escap", "to prevent", "to fix", "to avoid", "instead of", "should be", "use a ",
              "use parameter", "allowlist", "whitelist", "encode output", "validate input", "validate user")
_WEAK_KW = ("fix", "mitigat", "remediat", "prevent", "avoid", "should", "recommend", "sanitiz", "validat", "escap", "use ")
_FIX_KW = ("fix", "mitigat", "remediat", "prevent", "avoid", "instead", "should", "recommend", "solution", "resolve")


def _extract_remediation(help_text: str) -> str:
    low = (help_text or "").lower()
    for marker in _REMEDIATION_MARKERS:
        idx = low.find(marker)
        if idx < 0:
            continue
        seg = help_text[idx + len(marker):]
        if nxt := re.search(r"\n#{1,4}\s", seg):
            seg = seg[:nxt.start()]
        if seg := seg.strip(" :\n-*"):
            return _trunc(seg)
    best, score = "", 0
    for s in re.split(r"(?<=[.!?])\s+", re.sub(r"[#*`_]", "", help_text or "").strip()):
        ls = s.lower()
        sc = 3 * sum(k in ls for k in _STRONG_KW) + sum(k in ls for k in _WEAK_KW)
        if sc and sc >= score:
            best, score = s.strip(), sc
    return _trunc(best)


def _norm_test(data) -> list[dict]:
    out = []
    for p in (data if isinstance(data, list) else [data]) if data is not None else []:
        if not isinstance(p, dict):
            continue
        if p.get("error"):
            out.append({"project": p.get("path") or "(desconocido)", "error": p["error"], "issues": []})
            continue
        issues = []
        for v in p.get("vulnerabilities") or []:
            ids, fixed, up = v.get("identifiers", {}) or {}, v.get("fixedIn") or [], v.get("upgradePath") or []
            patch, upg = bool(v.get("isPatchable")), bool(v.get("isUpgradable") or v.get("isUpgradeable"))
            fixed_s = ", ".join(map(str, fixed))
            if upg and up:
                rec = f"Actualizar a {fixed_s or up[0]}"
            elif patch:
                rec = "Aplicar el parche disponible de Snyk (snyk protect)"
            elif fixed:
                rec = f"Actualizar el paquete — corregido en: {fixed_s}"
            else:
                rec = _trunc(v.get("description") or "", 260) or "Sin corrección automática — revisar manualmente"
            issues.append({
                "severity": (v.get("severity") or "low").lower(), "title": v.get("title") or v.get("id") or "Vulnerabilidad",
                "package": f"{v.get('packageName', '?')}@{v.get('version', '?')}",
                "packageName": v.get("packageName") or "?", "version": v.get("version") or "?", "id": v.get("id"),
                "cve": ", ".join(ids.get("CVE", []) or []), "cwe": ", ".join(ids.get("CWE", []) or []),
                "fixedIn": fixed_s or "—", "fix_available": bool(fixed or upg or patch or up), "recommendation": rec,
                "is_upgradeable": upg, "is_patchable": patch, "path": " > ".join((v.get("from") or [])[1:]) or "(direct)",
                "url": v.get("url") or "", "description": (v.get("description") or "")[:1200],
                "cvss_score": v.get("cvssScore") or "", "cvss_v3": v.get("cvssV3") or "",
                "exploit_maturity": v.get("exploit") or v.get("exploitMaturity") or "",
                "disclosed_at": v.get("disclosureTime") or "", "published_at": v.get("publicationTime") or "",
                "language": v.get("language") or "", "package_manager": v.get("packageManager") or ""})
        issues.sort(key=lambda x: SEVERITY_ORDER.get(x["severity"], 99))
        out.append({"project": p.get("projectName") or p.get("displayTargetFile") or p.get("path") or "(proyecto)",
                    "summary": p.get("summary") or "", "uniqueCount": p.get("uniqueCount") or len(issues),
                    "issues": issues, "package_manager": p.get("packageManager") or ""})
    return out


def _code_sev(result) -> str:
    sev = {"error": "high", "warning": "medium", "note": "low"}.get((result.get("level") or "warning").lower(), "medium")
    props = result.get("properties") or {}
    sp = str(props.get("issueSeverity") or props.get("security-severity") or "").lower()
    if sp in SEVERITY_ORDER:
        return sp
    try:
        s = float(sp)
        return "critical" if s >= 9 else "high" if s >= 7 else "medium" if s >= 4 else "low"
    except ValueError:
        return sev


def _norm_code(data) -> list[dict]:
    runs = []
    for d in (data if isinstance(data, list) else [data]) if data is not None else []:
        if isinstance(d, dict):
            runs += d.get("runs") or []
    by_file: dict[str, list] = {}
    for blk in runs:
        rules = {r.get("id"): r for r in ((blk.get("tool") or {}).get("driver") or {}).get("rules") or []}
        for res in blk.get("results") or []:
            rid = res.get("ruleId") or "rule"
            rule = rules.get(rid, {})
            rp = rule.get("properties") or {}
            help_text = ((rule.get("help") or {}).get("text") or (rule.get("help") or {}).get("markdown")
                         or (rule.get("fullDescription") or {}).get("text") or "").strip()
            fixes = res.get("fixes") or []
            rec = _trunc(((fixes[0].get("description") or {}).get("text") or "")) if fixes else ""
            rec = rec or (help_text and _extract_remediation(help_text)) or _trunc(rp.get("recommendation", ""))
            cwe = ", ".join(sorted({t.upper() for t in rp.get("tags", []) or []
                                    if isinstance(t, str) and t.lower().startswith("cwe")}))
            base = {"severity": _code_sev(res), "rule": rid,
                    "title": rule.get("name") or rule.get("shortDescription", {}).get("text") or rid,
                    "message": (res.get("message") or {}).get("text") or rule.get("shortDescription", {}).get("text") or rid,
                    "cwe": cwe, "fix_available": bool(fixes or any(k in help_text.lower() for k in _FIX_KW)),
                    "recommendation": rec, "confidence": rp.get("precision") or res.get("rank") or "",
                    "impact": rp.get("impact") or "", "likelihood": rp.get("likelihood") or "",
                    "category": rp.get("category") or "", "rule_url": rule.get("helpUri") or rp.get("url") or "",
                    "cvss_score": rp.get("cvssScore") or rp.get("security-severity") or ""}
            for loc in res.get("locations") or [{}]:
                phys = (loc or {}).get("physicalLocation") or {}
                region = phys.get("region") or {}
                snippet = ((phys.get("contextRegion") or {}).get("snippet") or region.get("snippet") or {}).get("text") or ""
                fp = (phys.get("artifactLocation") or {}).get("uri") or "(archivo desconocido)"
                by_file.setdefault(fp, []).append({**base, "line": region.get("startLine") or "?",
                                                   "col_start": region.get("startColumn") or "",
                                                   "col_end": region.get("endColumn") or "", "snippet": snippet})
    return [{"file": f, "issues": sorted(i, key=lambda x: SEVERITY_ORDER.get(x["severity"], 99))}
            for f, i in sorted(by_file.items())]


_DYN_KEYS = {"dast": ("target", "profile", "pages_visited", "forms_discovered", "engine", "scan_url", "target_id",
                      "scan_id", "report_path", "engines", "informational", "partial"),
             "api": ("target", "spec_source", "profile", "endpoints_tested", "endpoints_total", "engine", "scan_url",
                     "target_id", "scan_id", "report_path", "engines", "informational", "partial")}


def build_context(test_data, code_data, target, snyk_version, dast_data=None, api_data=None, secrets_data=None,
                  container_data=None, iac_data=None) -> dict:
    projects, files = _norm_test(test_data), _norm_code(code_data)
    counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}

    def tally(items, default="low"):
        for i in items:
            s = i.get("severity", default)
            counts[s] = counts.get(s, 0) + 1
        return len(items)

    sca = tally([i for p in projects for i in p["issues"]])
    code = tally([i for f in files for i in f["issues"]])
    dyn = {}
    for k, d in (("dast", dast_data), ("api", api_data)):
        d = d or {}
        dyn[k] = {key: d.get(key, 0 if key in ("pages_visited", "forms_discovered", "endpoints_tested",
                                               "endpoints_total") else "") for key in _DYN_KEYS[k]}
        dyn[k]["findings"] = d.get("findings", [])
    dast, api = tally(dyn["dast"]["findings"]), tally(dyn["api"]["findings"])
    sd = secrets_data if isinstance(secrets_data, dict) else {}
    sec = [{"severity": s.get("severity", "high"), "secret_type": s.get("secret_type") or s.get("title") or s.get("rule", ""),
            "rule": s.get("rule", ""), "file": s.get("file", ""), "line": s.get("line", "?"), "match": s.get("match", ""),
            "engine": s.get("engine", ""), "context": s.get("context", ""), "cwe": s.get("cwe", "CWE-798")}
           for s in sd.get("findings", [])]
    secrets = tally(sec, "high")
    cd = container_data if isinstance(container_data, dict) else {}
    idd = iac_data if isinstance(iac_data, dict) else {}
    cont_f, iac_f = list(cd.get("findings") or []), list(idd.get("findings") or [])
    container, iac = tally(cont_f), tally(iac_f)
    return {"generated_at": now_human(), "target": str(target), "snyk_version": snyk_version, "counts": counts,
            "total": sca + code + dast + api + secrets + container + iac, "sca_total": sca, "code_total": code,
            "dast_total": dast, "api_total": api, "secrets_total": secrets, "container_total": container,
            "iac_total": iac, "projects": projects, "files": files, **dyn,
            "secrets": {"engine": sd.get("engine", ""), "scanned_files": sd.get("scanned_files", 0),
                        "elapsed": sd.get("elapsed", 0), "findings": sec},
            "container": {"engine": cd.get("engine", ""), "images": cd.get("images") or [],
                          "targets": cd.get("targets") or [], "findings": cont_f},
            "iac": {"engine": idd.get("engine", ""), "targets": idd.get("targets") or [],
                    "frameworks": idd.get("frameworks") or {}, "findings": iac_f}}


_SAST_OWASP = {
    "CWE-79": "A03 Injection", "CWE-89": "A03 Injection", "CWE-94": "A03 Injection", "CWE-78": "A03 Injection",
    "CWE-77": "A03 Injection", "CWE-918": "A10 SSRF", "CWE-611": "A05 Security Misconfiguration",
    "CWE-22": "A01 Broken Access Control", "CWE-23": "A01 Broken Access Control",
    "CWE-352": "A01 Broken Access Control", "CWE-862": "A01 Broken Access Control",
    "CWE-863": "A01 Broken Access Control", "CWE-502": "A08 Insecure Deserialization",
    "CWE-327": "A02 Cryptographic Failures", "CWE-326": "A02 Cryptographic Failures",
    "CWE-330": "A02 Cryptographic Failures", "CWE-798": "A07 Identification & Authentication",
    "CWE-259": "A07 Identification & Authentication", "CWE-287": "A07 Identification & Authentication",
    "CWE-200": "A02 Cryptographic Failures", "CWE-532": "A09 Security Logging Failures"}
_DAST_OWASP = {"auth": "API2 Broken Authentication", "injection": "API8 Injection", "csrf": "API6 Mass Assignment",
               "headers": "API7 Security Misconfiguration", "ssl": "API7 Security Misconfiguration",
               "redirect": "API3 Excessive Data Exposure", "xss": "API8 Injection", "sqli": "API8 Injection",
               "cors": "API7 Security Misconfiguration", "info": "API9 Improper Assets Management"}
DAST_SOLUTION = {
    "auth": "Exigir autenticación robusta; implementar MFA.",
    "injection": "Usar consultas parametrizadas / validación estricta de entradas.",
    "csrf": "Agregar tokens CSRF; validar los encabezados Origin/Referer.",
    "headers": "Configurar encabezados de seguridad (CSP, HSTS, X-Frame-Options).",
    "ssl": "Exigir TLS 1.2+; deshabilitar cifrados y protocolos débiles.",
    "redirect": "Usar lista blanca de destinos de redirección; rechazar URLs arbitrarias.",
    "xss": "Codificar la salida; implementar una CSP estricta.",
    "sqli": "Usar consultas parametrizadas / ORM; nunca concatenar entradas del usuario.",
    "cors": "Restringir CORS a orígenes confiables; evitar el comodín (*) en peticiones con credenciales.",
    "info": "Eliminar mensajes de error detallados; ocultar encabezados de versión del servidor."}
SECRET_CWE = {"bloque de llave privada": "CWE-321", "aws access key id": "CWE-798", "aws secret access key": "CWE-798",
              "aws session token": "CWE-798", "secreto genérico embebido en código": "CWE-259",
              "credenciales embebidas en url": "CWE-522", "json web token": "CWE-522"}

SCA_HEADER = ["scan_type", "report_label", "project", "package_manager", "language", "severity", "cvss_score",
              "cvss_v3_vector", "exploit_maturity", "vulnerable_package", "package_name", "installed_version",
              "fixed_version", "fix_available", "snyk_recommendation", "is_upgradeable", "is_patchable",
              "vulnerability_id", "cve", "cwe", "dependency_path", "transitive", "disclosed_at", "published_at",
              "description_preview", "advisory_url"]
SAST_HEADER = ["scan_type", "report_label", "file_path", "line_start", "col_start", "col_end", "severity",
               "cvss_score", "rule_id", "rule_name", "category", "cwe", "owasp_category", "fix_available",
               "snyk_recommendation", "confidence", "impact", "likelihood", "message", "code_snippet_preview",
               "rule_url"]
DAST_HEADER = ["scan_type", "report_label", "severity", "owasp_api_top10", "category", "title", "url", "http_method",
               "parameter", "cwe", "fix_available", "snyk_recommendation", "status_code", "response_time_ms",
               "evidence_preview", "solution_hint", "dast_target", "dast_profile", "pages_visited",
               "forms_discovered", "engine", "probely_scan_url"]
API_HEADER = ["scan_type", "report_label", "severity", "owasp_api_top10", "category", "title", "endpoint_url",
              "http_method", "parameter", "cwe", "authentication_required", "fix_available", "snyk_recommendation",
              "status_code", "response_time_ms", "evidence_preview", "solution_hint", "api_spec_source",
              "api_profile", "endpoints_tested", "endpoints_total", "engine", "probely_scan_url"]
SECRETS_HEADER = ["scan_type", "report_label", "severity", "secret_type", "cwe", "owasp_top10", "file_path",
                  "line_number", "commit_scope", "secret_match_redacted", "context_snippet", "engine",
                  "fix_available", "snyk_recommendation"]
CONTAINER_HEADER = ["scan_type", "report_label", "severity", "vulnerability_id", "package", "installed_version",
                    "fixed_version", "cwe", "owasp_top10", "image_target", "detected_by", "title", "advisory_url",
                    "description_preview"]
IAC_HEADER = ["scan_type", "report_label", "severity", "severity_estimated", "rule_id", "title", "file_path", "line_start",
              "line_end", "resource", "framework", "cwe", "owasp_top10", "detected_by", "remediation", "guideline"]
SCAN_TAIL = ["scan_total", "scan_critical", "scan_high", "scan_medium", "scan_low", "scan_target", "scan_generated_at"]
SUMMARY_HEADER = ["scan_type", "report_label", "severity", "title", "location", "cwe", "cve_or_id", "fix_available",
                  "snyk_recommendation", "advisory_url", "total_findings", "total_critical", "total_high",
                  "total_medium", "total_low", "sca_count", "sast_count", "dast_count", "api_count", "secrets_count",
                  "scan_target", "scan_mode", "snyk_version", "scan_generated_at"]


def _b(v) -> str:
    if isinstance(v, str):
        low = v.lower()
        return "True" if low in ("true", "yes", "1") else "False" if low in ("false", "no", "0", "") else v
    return str(bool(v))


def export_csv(ctx: dict, path: Path, *, report_label: str = "") -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    c = ctx.get("counts") or {}
    tail = [ctx.get("total", 0), c.get("critical", 0), c.get("high", 0), c.get("medium", 0), c.get("low", 0),
            ctx.get("target", ""), ctx.get("generated_at", "")]
    lbl = report_label
    sca, sast, dast, api, secrets, summary = [], [], [], [], [], []
    for p in ctx.get("projects", []):
        for i in p["issues"]:
            raw = i.get("package", "")
            name = i.get("packageName") or raw.split("@")[0]
            ver = i.get("version") or (raw.split("@")[1] if "@" in raw else "")
            dep = i.get("path", "(direct)")
            sca.append(["SCA", lbl, p.get("project", ""), p.get("package_manager") or i.get("package_manager") or "",
                        i.get("language") or "", i.get("severity", "").upper(), i.get("cvss_score", ""),
                        i.get("cvss_v3", ""), i.get("exploit_maturity", ""), raw, name, ver, i.get("fixedIn", "—"),
                        _b(i.get("fix_available")), i.get("recommendation", ""), _b(i.get("is_upgradeable")),
                        _b(i.get("is_patchable")), i.get("id", ""), i.get("cve", ""), i.get("cwe", ""), dep,
                        "No" if dep in ("(direct)", "") else "Yes", i.get("disclosed_at", ""),
                        i.get("published_at", ""), (i.get("description", "") or "")[:300], i.get("url", "")] + tail)
            r = sca[-1]
            summary.append([r[0], lbl, r[5], r[17] or r[10], f"{r[2]} · {r[9]}", r[19], r[18], r[13], r[14], r[25]])
    for f in ctx.get("files", []):
        for i in f["issues"]:
            cwe = i.get("cwe", "")
            sast.append(["SAST", lbl, f.get("file", ""), str(i.get("line", "")), str(i.get("col_start", "")),
                         str(i.get("col_end", "")), i.get("severity", "").upper(), i.get("cvss_score", ""),
                         i.get("rule", ""), i.get("title", ""), i.get("category", ""), cwe,
                         _SAST_OWASP.get(cwe.split(",")[0].strip().upper(), ""), _b(i.get("fix_available")),
                         i.get("recommendation", ""), i.get("confidence", ""), i.get("impact", ""),
                         i.get("likelihood", ""), (i.get("message", "") or "")[:400],
                         (i.get("snippet", "") or "").replace("\n", " ").strip()[:300], i.get("rule_url", "")] + tail)
            r = sast[-1]
            summary.append([r[0], lbl, r[6], r[9], f"{r[2]}:{r[3]}", r[11], r[8], r[13], r[14], r[20]])
    for kind, rows in (("dast", dast), ("api", api)):
        m = ctx.get(kind) or {}
        for d in m.get("findings", []):
            cat = (d.get("category") or "").lower()
            hint = DAST_SOLUTION.get(cat, "")
            row = [kind.upper(), lbl, d.get("severity", "").upper(), _DAST_OWASP.get(cat, ""), d.get("category", ""),
                   d.get("title", ""), d.get("url", ""), d.get("method", ""), d.get("param", ""), d.get("cwe", "")]
            if kind == "api":
                row.append(d.get("auth_required", ""))
            row += [_b(bool(hint)), hint, d.get("status_code", ""), d.get("response_time_ms", ""),
                    (d.get("evidence", "") or "")[:400], hint]
            row += ([m.get("target", ""), m.get("profile", ""), m.get("pages_visited", ""), m.get("forms_discovered", "")]
                    if kind == "dast" else
                    [m.get("spec_source", ""), m.get("profile", ""), m.get("endpoints_tested", ""),
                     m.get("endpoints_total", "")])
            rows.append(row + [m.get("engine", ""), m.get("scan_url", "")] + tail)
            o = 1 if kind == "api" else 0
            summary.append([row[0], lbl, row[2], row[5], row[6], row[9], "", row[10 + o], row[11 + o], ""])
    for s in (ctx.get("secrets") or {}).get("findings", []):
        stype = s.get("secret_type") or s.get("rule", "")
        secrets.append(["Secrets", lbl, s.get("severity", "HIGH").upper(), stype,
                        s.get("cwe") or SECRET_CWE.get(stype.strip().lower(), "CWE-798"),
                        "A07 Identification & Authentication Failures", s.get("file", ""), s.get("line", "?"), "",
                        s.get("match", ""), (s.get("context", "") or "").replace("\n", " ").strip()[:400],
                        s.get("engine", ""), _b(True),
                        "ROTAR la credencial de inmediato; eliminarla del historial de git (git-filter-repo / BFG)"] + tail)
        r = secrets[-1]
        summary.append([r[0], lbl, r[2], r[3], f"{r[6]}:{r[7]}", r[4], "", r[12], r[13], ""])
    container_rows, iac_rows = [], []
    from findings import owasp_for
    for v in (ctx.get("container") or {}).get("findings", []):
        container_rows.append(["Container", lbl, v.get("severity", "").upper(), v.get("vuln_id", ""), v.get("package", ""),
                               v.get("installed", ""), v.get("fixed", ""), v.get("cwe", ""), owasp_for(v.get("cwe")),
                               v.get("target", ""), ", ".join(v.get("detected_by") or []), v.get("title", ""),
                               v.get("url", ""), (v.get("description") or "")[:300]] + tail)
        r = container_rows[-1]
        summary.append([r[0], lbl, r[2], r[11] or r[3], f"{r[9]} · {r[4]}@{r[5]}", r[7], r[3], _b(bool(r[6])),
                        f"Actualizar a {r[6]}" if r[6] else "", r[12]])
    for m in (ctx.get("iac") or {}).get("findings", []):
        iac_rows.append(["IaC", lbl, m.get("severity", "").upper(), _b(m.get("severity_estimated")), m.get("rule_id", ""),
                         m.get("title", ""), m.get("file", ""), m.get("line", ""), m.get("end_line", ""),
                         m.get("resource", ""), m.get("framework", ""), m.get("cwe", ""), owasp_for(m.get("cwe")),
                         ", ".join(m.get("detected_by") or []), m.get("remediation", ""),
                         " ".join(m.get("references") or [])[:300]] + tail)
        r = iac_rows[-1]
        summary.append([r[0], lbl, r[2], r[5], f"{r[6]}:{r[7]}", r[11], r[4], _b(True), r[14], r[15]])
    totals = tail[:5] + [ctx.get(k, 0) for k in ("sca_total", "code_total", "dast_total", "api_total", "secrets_total")] \
        + [ctx.get("target", ""), ctx.get("scan_mode", ""), ctx.get("snyk_version", ""), ctx.get("generated_at", "")]
    summary = [r + totals for r in summary]

    def write(fh, header, rows):
        w = csv.writer(fh)
        w.writerow(header)
        w.writerows(rows)

    bundle = path.stem or "scan"
    zip_path = path.with_suffix(".zip")
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, header, rows in (("summary", SUMMARY_HEADER, summary), ("sca", SCA_HEADER + SCAN_TAIL, sca),
                                   ("sast", SAST_HEADER + SCAN_TAIL, sast), ("dast", DAST_HEADER + SCAN_TAIL, dast),
                                   ("api", API_HEADER + SCAN_TAIL, api), ("secrets", SECRETS_HEADER + SCAN_TAIL, secrets),
                                   ("container", CONTAINER_HEADER + SCAN_TAIL, container_rows),
                                   ("iac", IAC_HEADER + SCAN_TAIL, iac_rows)):
            buf = io.StringIO()
            write(buf, header, rows)
            zf.writestr(f"{bundle}/{name}.csv", buf.getvalue())
    with open(path, "w", newline="", encoding="utf-8") as fh:
        write(fh, SUMMARY_HEADER, summary)
    return zip_path


_STATE_KINDS = ("sca", "code", "secrets", "container", "iac", "dast", "api")


class ScanStateStore:
    def __init__(self, reports_root: Path):
        self._root = Path(reports_root)
        self._lock = threading.Lock()
        self._root.mkdir(parents=True, exist_ok=True)

    def _idx(self) -> dict:
        return read_json(self._root / "scan_state.json") or dict.fromkeys(_STATE_KINDS)

    def _kind(self, kind: str) -> Path:
        return self._root / f"scan_state_{kind}.json"

    def save_kind(self, kind: str, raw, *, target: str = "", snyk_version: str = "", mode: str = "") -> None:
        if kind not in _STATE_KINDS:
            return
        with self._lock:
            idx = self._idx()
            idx[kind] = {"ts": datetime.now().strftime("%Y-%m-%dT%H:%M:%S"), "target": target,
                         "snyk_version": snyk_version, "mode": mode}
            self._kind(kind).write_text(json.dumps(raw if raw is not None else {"_empty": True}, indent=2,
                                                   default=str), "utf-8")
            write_json(self._root / "scan_state.json", idx)

    def load_kind(self, kind: str):
        with self._lock:
            data = read_json(self._kind(kind))
            return (None if isinstance(data, dict) and data.get("_empty") else data), self._idx().get(kind) or {}

    def get_index(self) -> dict:
        with self._lock:
            return self._idx()

    def clear_kinds(self, kinds=None) -> None:
        with self._lock:
            idx = self._idx()
            for k in kinds or _STATE_KINDS:
                if k in _STATE_KINDS:
                    idx[k] = None
                    self._kind(k).unlink(missing_ok=True)
            write_json(self._root / "scan_state.json", idx)


def build_cumulative_context(store: ScanStateStore, target_hint, snyk_version_hint: str = "?", *,
                             current_results: dict | None = None) -> dict:
    cr = current_results or {}
    idx = store.get_index()
    raw = {k: cr[k] if cr.get(k) is not None else store.load_kind(k)[0] for k in _STATE_KINDS}
    sv = snyk_version_hint
    if sv in ("?", "", None):
        sv = (idx.get("sca") or idx.get("code") or {}).get("snyk_version") or "?"
    target = str(target_hint or "")
    if not target or target.endswith("Vulnerable"):
        target = next((t for k in _STATE_KINDS if (t := (idx.get(k) or {}).get("target"))), target)
    ctx = build_context(raw["sca"], raw["code"], target, sv, raw["dast"], raw["api"], raw["secrets"],
                        container_data=raw["container"], iac_data=raw["iac"])
    ctx["state_timestamps"] = {k: (idx.get(k) or {}).get("ts") for k in _STATE_KINDS}
    ctx["state_targets"] = {k: (idx.get(k) or {}).get("target") for k in _STATE_KINDS}
    return ctx


REPORT_TEMPLATE = r"""<!doctype html>
<html lang="es"><head><meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Reporte de vulnerabilidades — {{ generated_at }}</title>
<style>
:root{
  --paper:#FBFAF7;--panel:#FFFFFF;--panel-2:#F3F1EA;
  --line:#E1DDD1;--line-2:#CBC4B2;
  --ink:#14243D;--ink-2:#28456B;--mu:#78715F;
  --gold:#F5A800;
  --crit:#B3261E;--high:#B8560B;--med:#8E6B10;--low:#2E6B4F;
  --r:4px;--rt:2px;
}
*{box-sizing:border-box}
body{margin:0;background:var(--paper);color:var(--ink);font:14px/1.6 'Segoe UI',-apple-system,Roboto,Arial,sans-serif;-webkit-font-smoothing:antialiased}
code,pre,.mono{font-family:ui-monospace,Consolas,'SFMono-Regular',monospace}
a{color:var(--ink-2);text-decoration:none;border-bottom:1px solid var(--line-2)}
a:hover{border-bottom-color:var(--ink-2)}
.shell{max-width:1440px;margin:0 auto;padding:0 clamp(16px,4vw,48px) 80px}
svg.ic{display:inline-block;vertical-align:-2px}

/* ── Masthead ─────────────────────────────────────────────────────── */
.masthead{border-bottom:3px solid var(--ink);padding:26px 0 16px;margin-bottom:22px;
  display:flex;align-items:flex-end;justify-content:space-between;gap:20px;flex-wrap:wrap}
.brand-mark{display:flex;align-items:center;gap:12px}
.brand-mark .bar{width:5px;align-self:stretch;background:var(--gold);flex:0 0 auto;min-height:34px}
h1{margin:0;font:600 22px/1.25 Georgia,'Iowan Old Style','Palatino Linotype','Book Antiqua',serif;letter-spacing:.005em;color:var(--ink)}
.sub{color:var(--mu);font-size:10.5px;text-transform:uppercase;letter-spacing:.12em;margin-top:4px}
.meta-list{display:flex;gap:16px;flex-wrap:wrap;font-size:11px;color:var(--mu)}
.meta-item{border-left:1px solid var(--line-2);padding-left:16px}
.meta-item:first-child{border-left:0;padding-left:0}
.meta-item b{color:var(--ink);font-weight:600}

/* ── Scan configuration (collapsible: services run + scanned folders) ── */
details.scan-config{background:var(--panel-2);border:1px solid var(--line);border-left:3px solid var(--gold);
  margin-bottom:22px;font-size:12px}
details.scan-config>summary{cursor:pointer;list-style:none;padding:11px 16px;
  display:flex;align-items:center;gap:14px;flex-wrap:wrap}
details.scan-config>summary::-webkit-details-marker{display:none}
details.scan-config[open]>summary{border-bottom:1px solid var(--line)}
.sc-title{font-weight:700;color:var(--ink);text-transform:uppercase;font-size:10px;letter-spacing:.08em;
  display:flex;align-items:center;gap:6px}
.sc-badge{color:var(--mu);font-size:11px}
.sc-chev{margin-left:auto;font-size:10px;color:var(--mu);transition:transform .15s ease}
details.scan-config[open] .sc-chev{transform:rotate(180deg)}
.scan-config-body{padding:2px 16px 16px}
.sc-status{display:inline-flex;align-items:center;gap:5px;font-size:11px;font-weight:600;white-space:nowrap}
.sc-status.ran{color:var(--low)}
.sc-status.not-ran{color:var(--mu)}
.sc-status .dot{width:7px;height:7px;border-radius:50%;background:currentColor;display:inline-block;flex:0 0 auto}
.sc-path{word-break:break-all}
.sc-batch{margin-top:14px;padding-top:14px;border-top:1px solid var(--line)}
.sc-batch-title{font-weight:700;color:var(--ink);text-transform:uppercase;font-size:10px;letter-spacing:.08em;
  display:flex;align-items:center;gap:6px;margin-bottom:8px}
.sc-batch-list{margin:0;padding:0;list-style:none;display:flex;flex-direction:column;gap:5px}
.sc-batch-list li{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.sc-batch-list .sc-badge{color:var(--ink-2);font-weight:600}

/* ── Hero: severity bar + stat strip ─────────────────────────────── */
.hero{margin-bottom:26px;border:1px solid var(--line)}
.panel{background:var(--panel);padding:20px 22px}
.panel + .panel{border-top:1px solid var(--line)}
.panel h2{margin:0 0 16px;font-size:10px;text-transform:uppercase;letter-spacing:.14em;color:var(--mu);font-weight:700}

.sevbar{height:24px;display:flex;width:100%;border:1px solid var(--line-2)}
.sevbar span{display:block;height:100%}
.sevbar .seg-critical{background:var(--crit)}.sevbar .seg-high{background:var(--high)}
.sevbar .seg-medium{background:var(--med)}.sevbar .seg-low{background:var(--low)}
.sevbar .seg-empty{background:var(--panel-2)}
.sevlegend{display:flex;gap:24px;flex-wrap:wrap;margin-top:14px;font-size:12px}
.sevlegend .item{display:flex;align-items:center;gap:7px;color:var(--mu)}
.sevlegend .sw{width:9px;height:9px;flex:0 0 auto}
.sevlegend .name{color:var(--ink);font-weight:600}

.statstrip{display:flex;flex-wrap:wrap;gap:0}
.stat{flex:1 1 130px;padding:2px 20px 2px 0;margin-right:20px;border-right:1px solid var(--line);min-width:110px}
.stat:last-child{border-right:0;margin-right:0}
.stat .l{color:var(--mu);font-size:10px;text-transform:uppercase;letter-spacing:.09em;font-weight:700}
.stat .v{font:600 27px/1.15 Georgia,'Iowan Old Style',serif;margin-top:5px;color:var(--ink)}
.stat .v.critical{color:var(--crit)}.stat .v.high{color:var(--high)}
.stat .v.medium{color:var(--med)}.stat .v.low{color:var(--low)}
.stat .s{color:var(--mu);font-size:10.5px;margin-top:2px}

/* ── Toolbar ──────────────────────────────────────────────────────── */
.toolbar{position:sticky;top:0;z-index:5;background:var(--paper);
  margin:0 0 4px;padding:14px 0;border-bottom:2px solid var(--ink);display:flex;gap:12px;flex-wrap:wrap;align-items:center}
.toolbar input{flex:1;min-width:240px;padding:9px 12px;border:1px solid var(--line-2);border-radius:var(--r);
  font-size:13px;outline:none;background:var(--panel);font-family:inherit;color:var(--ink)}
.toolbar input:focus{border-color:var(--ink)}
.chips{display:flex;gap:0;flex-wrap:wrap;border:1px solid var(--line-2)}
.chip{cursor:pointer;user-select:none;padding:8px 14px;border-right:1px solid var(--line-2);color:var(--mu);
  font-size:12px;font-weight:600;background:var(--panel)}
.chip:last-child{border-right:0}
.chip.active{background:var(--ink);color:#fff}

/* ── Index nav ────────────────────────────────────────────────────── */
.idx{position:sticky;top:53px;z-index:4;background:var(--paper);
  border-bottom:1px solid var(--line);padding:10px 0;margin:0 0 8px;display:flex;flex-wrap:wrap;align-items:center;font-size:11.5px}
.idx-label{font-weight:700;color:var(--mu);text-transform:uppercase;letter-spacing:.08em;margin-right:14px}
.idx a{color:var(--ink);padding:2px 0;text-decoration:none;white-space:nowrap;border-bottom:1px solid transparent;
  display:inline-flex;align-items:center;gap:5px}
.idx a:hover{border-bottom-color:var(--gold)}
.idx .idx-sep{color:var(--line-2);margin:0 12px}

/* ── Section headers ──────────────────────────────────────────────── */
.section-head{display:flex;align-items:baseline;gap:10px;margin:34px 0 14px;scroll-margin-top:112px;
  cursor:pointer;user-select:none;border-bottom:2px solid var(--ink);padding-bottom:8px}
.section-head:hover h3{color:var(--ink-2)}
.section-head h3{margin:0;font:600 17px Georgia,'Iowan Old Style',serif;transition:color .12s;display:flex;align-items:center;gap:9px;color:var(--ink)}
.section-head h3 svg{color:var(--gold)}
.section-head .chev{display:inline-block;font-size:10px;color:var(--mu);transition:transform .15s ease}
.section-head.collapsed .chev{transform:rotate(-90deg)}
.sec-body.collapsed{display:none}
.count{color:var(--mu);font-size:12px;font-family:ui-monospace,Consolas,monospace}
.hint{color:var(--mu);font-size:11px;margin-left:auto}

/* ── Groups (per-project / per-file) ─────────────────────────────── */
details.group{background:var(--panel);border:1px solid var(--line);margin-bottom:10px}
details.group>summary{cursor:pointer;padding:12px 16px;display:flex;align-items:center;gap:12px;list-style:none}
details.group>summary::-webkit-details-marker{display:none}
details.group[open]>summary{border-bottom:1px solid var(--line)}
.gt{font-weight:600;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:flex;align-items:center;gap:8px}
.gt svg{color:var(--mu);flex:0 0 auto}
.gm{display:flex;gap:10px;font-size:11px;font-family:ui-monospace,Consolas,monospace;font-weight:700}
.gm .critical{color:var(--crit)}.gm .high{color:var(--high)}.gm .medium{color:var(--med)}.gm .low{color:var(--low)}

/* ── Tags (severity / mini) ──────────────────────────────────────── */
.sev{display:inline-block;padding:2px 8px;border-radius:var(--rt);font-size:10px;font-weight:700;
  text-transform:uppercase;letter-spacing:.03em;color:#fff}
.sev.critical{background:var(--crit)}.sev.high{background:var(--high)}
.sev.medium{background:var(--med)}.sev.low{background:var(--low)}
.mini{font-size:10px;padding:1px 6px;border-radius:var(--rt);font-weight:700;text-transform:uppercase;border:1px solid currentColor}
.mini.critical{color:var(--crit)}.mini.high{color:var(--high)}.mini.medium{color:var(--med)}.mini.low{color:var(--low)}

/* ── Tables ───────────────────────────────────────────────────────── */
.table-wrap{overflow-x:auto}
table{width:100%;border-collapse:collapse;font-size:12.5px}
th{text-align:left;color:var(--mu);font-size:10px;text-transform:uppercase;letter-spacing:.07em;
  font-weight:700;padding:9px 14px;border-bottom:1px solid var(--line-2)}
td{padding:11px 14px;vertical-align:top;border-bottom:1px solid var(--line)}
tr:last-child td{border-bottom:0}tr:hover td{background:var(--panel-2)}
td code{background:var(--panel-2);border:1px solid var(--line);padding:1px 6px;border-radius:var(--rt);font-size:11px;white-space:nowrap}
.desc{color:var(--mu);font-size:11.5px;margin-top:4px;max-width:720px}
.fix{color:var(--ink);background:var(--panel-2);border-left:3px solid var(--low);font-size:12px;
  margin-top:6px;padding:7px 10px;max-width:720px;line-height:1.5}
.fix b{color:var(--low);text-transform:uppercase;font-size:10px;letter-spacing:.05em}
pre.snippet{background:var(--ink);color:#DCE3EC;border-radius:var(--r);padding:10px;overflow:auto;font-size:11.5px;max-height:200px;margin:8px 0 0}
.empty{text-align:center;padding:34px;color:var(--mu);border:1px dashed var(--line-2)}
footer{text-align:center;color:var(--mu);font-size:11px;padding:34px 0 0;border-top:1px solid var(--line);margin-top:20px}
.hide{display:none!important}
/* ── Back to top ──────────────────────────────────────────────────── */
#btt{position:fixed;bottom:26px;right:26px;z-index:99;background:var(--ink);color:#fff;border:none;
  width:38px;height:38px;font-size:16px;cursor:pointer;display:none;line-height:38px;text-align:center}
#btt.vis{display:block}
#btt:hover{background:var(--ink-2)}
/* ── Expandable fix ──────────────────────────────────────────────── */
.fix-short{display:block}.fix-full{display:none}
.fix-expand{cursor:pointer;font-size:10px;color:var(--ink-2);margin-left:4px;text-decoration:underline;user-select:none}
/* ── Filter: hide whole group when empty ─────────────────────────── */
details.group.grp-hidden{display:none!important}
/* ── Detectado por / fuentes / prioridades ───────────────────────── */
.by{display:inline-block;margin:4px 4px 0 0;padding:1px 7px;border:1px solid var(--line-2);border-radius:var(--rt);
  font-size:10px;font-weight:700;color:var(--ink-2);background:var(--panel-2)}
.by.multi{border-color:var(--low);color:var(--low)}
.conf{display:inline-block;padding:1px 7px;border-radius:var(--rt);font-size:10px;font-weight:700;color:#fff;background:var(--ink)}
details.src{margin-top:6px;font-size:11.5px}
details.src>summary{cursor:pointer;color:var(--ink-2);list-style:none}
details.src>summary::-webkit-details-marker{display:none}
.src-item{border-left:3px solid var(--line-2);padding:4px 10px;margin:6px 0;color:var(--mu)}
.src-item b{color:var(--ink)}
.prio{display:grid;grid-template-columns:28px 92px 1fr auto;gap:12px;align-items:start;padding:12px 16px;
  border-bottom:1px solid var(--line);background:var(--panel)}
.prio:last-child{border-bottom:0}
.prio .n{font:600 18px Georgia,serif;color:var(--mu)}
.prio .t{font-weight:600}
.prio .w{color:var(--mu);font-size:11.5px;word-break:break-all}
.prio .k{font-size:10px;text-transform:uppercase;letter-spacing:.06em;color:var(--mu);font-weight:700}
.owasp-bar{display:flex;align-items:center;gap:10px;margin:5px 0;font-size:12px}
.owasp-bar .lbl{flex:0 0 300px}
.owasp-bar .track{flex:1;height:10px;background:var(--panel-2);border:1px solid var(--line)}
.owasp-bar .fill{height:100%;background:var(--ink-2)}
@media(max-width:760px){.prio{grid-template-columns:24px 1fr}.owasp-bar .lbl{flex-basis:160px}}
</style></head><body><div class="shell">
{% macro icon(name) -%}
{%- if name=='sca' %}<svg class="ic" width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><circle cx="7" cy="7" r="4.5"/><line x1="10.3" y1="10.3" x2="14" y2="14"/></svg>
{%- elif name=='sast' %}<svg class="ic" width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><polyline points="5.5,3.5 1.5,8 5.5,12.5"/><polyline points="10.5,3.5 14.5,8 10.5,12.5"/></svg>
{%- elif name=='dast' %}<svg class="ic" width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><circle cx="8" cy="8" r="6.2"/><ellipse cx="8" cy="8" rx="2.6" ry="6.2"/><line x1="1.9" y1="8" x2="14.1" y2="8"/></svg>
{%- elif name=='api' %}<svg class="ic" width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><circle cx="3" cy="3.5" r="1.5"/><circle cx="13" cy="3.5" r="1.5"/><circle cx="8" cy="12.5" r="1.5"/><line x1="4.2" y1="4.5" x2="7" y2="11.2"/><line x1="11.8" y1="4.5" x2="9" y2="11.2"/></svg>
{%- elif name=='secrets' %}<svg class="ic" width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="5" cy="5" r="3"/><line x1="7.2" y1="7.2" x2="14" y2="14"/><line x1="10.7" y1="10.7" x2="12.6" y2="8.8"/></svg>
{%- elif name=='file' %}<svg class="ic" width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M4 1.5h5.2L12 4.3V14.5H4z"/><line x1="6" y1="8" x2="10" y2="8"/><line x1="6" y1="10.5" x2="10" y2="10.5"/></svg>
{%- elif name=='link' %}<svg class="ic" width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M6.5 3H3v10h10V9.5"/><path d="M9 3h4v4"/><line x1="7" y1="9" x2="13" y2="3"/></svg>
{%- elif name=='chart' %}<svg class="ic" width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><line x1="3" y1="13" x2="3" y2="7"/><line x1="8" y1="13" x2="8" y2="3"/><line x1="13" y1="13" x2="13" y2="9.5"/></svg>
{%- elif name=='wrench' %}<svg class="ic" width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M10.5 2.2a3.2 3.2 0 0 0-4.2 3.9L2 10.4l1.6 1.6 4.3-4.3a3.2 3.2 0 0 0 3.9-4.2l-2 2-1.4-1.4z"/></svg>
{%- elif name=='container' %}<svg class="ic" width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"><path d="M8 1.8 14 5v6l-6 3.2L2 11V5z"/><path d="M2 5l6 3.2L14 5M8 8.2V14"/></svg>
{%- elif name=='iac' %}<svg class="ic" width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"><path d="M8 2 14.5 5.3 8 8.6 1.5 5.3z"/><path d="M1.5 8.2 8 11.5l6.5-3.3M1.5 11 8 14.3l6.5-3.3"/></svg>
{%- elif name=='warn' %}<svg class="ic" width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M8 2.2 14.5 13.5h-13z"/><line x1="8" y1="6.3" x2="8" y2="9.6"/></svg>
{%- endif -%}
{%- endmacro -%}
{% set c=counts.critical or 0 %}{% set h=counts.high or 0 %}
{% set m=counts.medium or 0 %}{% set l=counts.low or 0 %}
{% set sum=(c+h+m+l) if (c+h+m+l)>0 else 1 %}
<header class="masthead">
  <div class="brand-mark"><span class="bar"></span>
    <div><h1>Reporte de vulnerabilidades</h1><div class="sub">{{ subtitle_stages }} — Vista acumulada</div></div></div>
  <div class="meta-list">
    <span class="meta-item">Generado <b>{{ generated_at }}</b></span>
    <span class="meta-item">Snyk <b>{{ snyk_version or '?' }}</b></span>
    {% if scan_mode %}<span class="meta-item">Sesión <b>{{ scan_mode|upper }}</b></span>{% endif %}
    {% for t in (servicenow_tickets or []) %}
    <span class="meta-item">Ticket ServiceNow ({{ t.kind }})
      <b>{% if t.link %}<a href="{{ t.link }}">{{ t.number or '—' }}</a>{% else %}{{ t.number or '—' }}{% endif %}</b>
      {% if t.status %}<span class="sc-badge">{{ t.status }}</span>{% endif %}
    </span>
    {% endfor %}
  </div>
</header>
{% if state_timestamps %}
{% set ts=state_timestamps %}{% set tg=state_targets %}
{% set labels=[('sca','SCA','sca'),('code','SAST','sast'),('secrets','Secretos','secrets'),('container','Contenedores','container'),('iac','IaC','iac'),('dast','DAST','dast'),('api','API','api')] %}
{% set n_ran = ts.values()|select|list|length %}
<details class="scan-config">
  <summary>
    <span class="sc-title">{{ icon('chart') }} Configuración del escaneo</span>
    <span class="sc-badge">{{ n_ran }} servicio{{ '' if n_ran == 1 else 's' }} ejecutado{{ '' if n_ran == 1 else 's' }}</span>
    <span class="sc-chev">▾</span>
  </summary>
  <div class="scan-config-body">
    <div class="table-wrap">
      <table>
        <thead><tr>
          <th>Servicio</th><th>Estado</th><th>Última ejecución</th><th>Carpeta / objetivo configurado (ruta completa)</th>
        </tr></thead>
        <tbody>
          {% for kind,name,ikey in labels if ts[kind] %}
          <tr>
            <td>{{ icon(ikey) }} <b>{{ name }}</b></td>
            <td><span class="sc-status ran"><span class="dot"></span>Ejecutado</span></td>
            <td>{{ ts[kind][:16] }}</td>
            <td>{% if tg[kind] %}<code class="sc-path">{{ tg[kind] }}</code>{% else %}—{% endif %}</td>
          </tr>
          {% endfor %}
        </tbody>
      </table>
    </div>
    {% if batch_targets and batch_targets|length > 1 %}
    <div class="sc-batch">
      <div class="sc-batch-title">{{ icon('file') }} Carpetas configuradas en este batch de escaneo ({{ batch_targets|length }})</div>
      <ul class="sc-batch-list">
        {% for p in batch_targets %}
        <li><code class="sc-path">{{ p }}</code>{% if p == target %}<span class="sc-badge">— este reporte</span>{% endif %}</li>
        {% endfor %}
      </ul>
    </div>
    {% endif %}
  </div>
</details>
{% endif %}
<section class="hero">
  <div class="panel"><h2>Distribución por severidad</h2>
    <div class="sevbar">
      {% for cls,vv in [('critical',c),('high',h),('medium',m),('low',l)] %}
      {% if vv %}<span class="seg-{{ cls }}" style="width:{{ (vv*100/sum)|round(2) }}%" title="{{ cls }}: {{ vv }}"></span>{% endif %}
      {% endfor %}
      {% if sum==1 and c+h+m+l==0 %}<span class="seg-empty" style="width:100%"></span>{% endif %}
    </div>
    <div class="sevlegend">
      {% for nm,cl,vv in [('Crítica','var(--crit)',c),('Alta','var(--high)',h),('Media','var(--med)',m),('Baja','var(--low)',l)] %}
      <div class="item"><span class="sw" style="background:{{ cl }}"></span>
        <span class="name">{{ nm }}</span><span class="val">{{ vv }}</span></div>{% endfor %}
      <div class="item" style="margin-left:auto"><span class="name">Total</span><span class="val">{{ total or 0 }}</span></div>
    </div>
  </div>
  <div class="panel"><h2>Desglose</h2><div class="statstrip">
    {% for cls,lbl,vv,sub in [('critical','Crítica',c,'Atención inmediata'),('high','Alta',h,'Corregir pronto'),('medium','Media',m,'Planear corrección'),('low','Baja',l,'Dar seguimiento')] %}
    <div class="stat"><div class="l">{{ lbl }}</div><div class="v {{ cls }}">{{ vv }}</div><div class="s">{{ sub }}</div></div>{% endfor %}
  </div><div class="statstrip" style="margin-top:18px;padding-top:16px;border-top:1px solid var(--line)">
    {# Solo los servicios que se ejecutaron: un 0 aquí significa «se escaneó y no hubo hallazgos», no «no se corrió». #}
    {% set ran = state_timestamps or {} %}{% set modes = (scan_mode or '').split('+') %}
    {% for key,lbl,vv,sub,cls in [('sca','SCA',sca_total,'Dependencias',''),('code','SAST',code_total,'Código fuente',''),
        ('dast','DAST',dast_total,'Escaneo dinámico',''),('api','API',api_total,'Escaneo de endpoints',''),
        ('secrets','Secretos',secrets_total,'Credenciales embebidas','critical'),
        ('container','Contenedores',container_total,'Imágenes',''),('iac','IaC',iac_total,'Infraestructura como código','')] %}
    {% if ran.get(key) or key in modes or vv %}
    <div class="stat"><div class="l">{{ lbl }}</div><div class="v {{ cls }}">{{ vv or 0 }}</div><div class="s">{{ sub }}</div></div>
    {% endif %}{% endfor %}
  </div></div>
</section>
<div class="toolbar">
  <input id="search" type="search" placeholder="Filtrar por paquete, archivo, regla, CVE/CWE…" autocomplete="off"/>
  <div class="chips" id="chips">
    <span class="chip active" data-sev="all">Todas <b>{{ total or 0 }}</b></span>
    {% for s,v,lb in [('critical',c,'Crítica'),('high',h,'Alta'),('medium',m,'Media'),('low',l,'Baja')] %}
    <span class="chip" data-sev="{{ s }}">{{ lb }} <b>{{ v }}</b></span>{% endfor %}
  </div>
</div>
{% macro mini(items) %}{% for s,a in [('critical','C'),('high','A'),('medium','M'),('low','B')] %}
{% set n=items|selectattr('severity','equalto',s)|list|length %}
{% if n %}<span class="mini {{ s }}">{{ n }} {{ a }}</span>{% endif %}{% endfor %}{% endmacro %}

{% macro fix_cell(txt) %}{% if txt %}
  {% set tlen = txt | length %}
  {% if tlen > 240 %}
  <div class="fix"><b>{{ icon('wrench') }} Corrección:</b>
    <span class="fix-short">{{ txt[:240] }}<span class="fix-expand" onclick="var p=this.parentNode,f=p.nextElementSibling;p.style.display='none';f.style.display='inline'" title="Ver recomendación completa">… <b style="font-size:10px">▼ ver más</b></span></span>
    <span class="fix-full" style="display:none">{{ txt }}<span class="fix-expand" onclick="var f=this.parentNode,p=f.previousElementSibling;f.style.display='none';p.style.display='inline'" title="Contraer"> <b style="font-size:10px">▲ contraer</b></span></span>
  </div>
  {% else %}<div class="fix"><b>{{ icon('wrench') }} Corrección:</b> {{ txt }}</div>{% endif %}
{% endif %}{% endmacro %}

{% macro sources_cell(d) %}
  {% if d.detected_by %}<div>{% for t in d.detected_by %}<span class="by{{ ' multi' if d.detected_by|length > 1 }}">{{ t }}</span>{% endfor %}</div>{% endif %}
  {% if d.sources and (d.sources|length > 1 or d.sources[0].description) %}
  <details class="src"><summary>▸ {{ 'Descripciones de ' ~ d.sources|length ~ ' herramientas' if d.sources|length > 1 else 'Descripción' }}</summary>
    {% for src in d.sources %}<div class="src-item"><b>{{ src.tool }}</b>{% if src.title and src.title != d.title %} — {{ src.title }}{% endif %}
      {% if src.description %}<div>{{ src.description[:700] }}</div>{% endif %}
      {% if src.remediation %}<div><b>Remediación:</b> {{ src.remediation[:500] }}</div>{% endif %}
      {% if src.references %}<div>{% for r in src.references[:3] %}<a href="{{ r }}" target="_blank">{{ r[:70] }}</a> {% endfor %}</div>{% endif %}
    </div>{% endfor %}
  </details>{% endif %}
{% endmacro %}

<button id="btt" onclick="window.scrollTo({top:0,behavior:'smooth'})" title="Volver arriba">↑</button>
<div class="idx">
  <span class="idx-label">Ir a</span>
  {% if priorities %}<a href="#sec-prio">{{ icon('warn') }} Qué corregir primero</a><span class="idx-sep">·</span>{% endif %}
  {% if cwe_groups %}<a href="#sec-cwe">{{ icon('chart') }} Por CWE / OWASP</a><span class="idx-sep">·</span>{% endif %}
  {% if sca_total %}<a href="#sec-sca">{{ icon('sca') }} SCA <b>{{ sca_total }}</b></a>{% endif %}
  {% if code_total %}<span class="idx-sep">·</span><a href="#sec-sast">{{ icon('sast') }} SAST <b>{{ code_total }}</b></a>{% endif %}
  {% if dast_total %}<span class="idx-sep">·</span><a href="#sec-dast">{{ icon('dast') }} DAST <b>{{ dast_total }}</b></a>{% endif %}
  {% if api_total %}<span class="idx-sep">·</span><a href="#sec-api">{{ icon('api') }} API <b>{{ api_total }}</b></a>{% endif %}
  {% if secrets_total %}<span class="idx-sep">·</span><a href="#sec-secrets">{{ icon('secrets') }} Secretos <b>{{ secrets_total }}</b></a>{% endif %}
  {% if container_total %}<span class="idx-sep">·</span><a href="#sec-container">{{ icon('container') }} Contenedores <b>{{ container_total }}</b></a>{% endif %}
  {% if iac_total %}<span class="idx-sep">·</span><a href="#sec-iac">{{ icon('iac') }} IaC <b>{{ iac_total }}</b></a>{% endif %}
</div>

{% if priorities %}
<div class="section-head" id="sec-prio"><span class="chev">▾</span><h3>{{ icon('warn') }} Qué corregir primero</h3>
  <span class="count">{{ priorities|length }}</span>
  <span class="hint">Ordenado por severidad · confirmado en ejecución · secretos · corrección disponible</span></div>
<div class="sec-body"><div style="border:1px solid var(--line)">
{% for u in priorities %}
  <div class="prio">
    <div class="n">{{ loop.index }}</div>
    <div><span class="sev {{ u.severity }}">{{ sev_es.get(u.severity, u.severity) }}</span>
      <div class="k" style="margin-top:6px">{{ kind_es.get(u.kind, u.kind) }}</div></div>
    <div><div class="t">{{ u.title }}</div>
      <div class="w">{{ u.location }}</div>
      {% if u.fix %}{{ fix_cell(u.fix) }}{% endif %}</div>
    <div style="text-align:right">
      {% if u.confirmed %}<span class="conf" title="La misma debilidad (CWE) aparece en el código y en la aplicación en ejecución">Confirmado en ejecución</span><br>{% endif %}
      {% for c in u.cwe[:2] %}<code>{{ c }}</code> {% endfor %}
      <div>{% for t in u.detected_by %}<span class="by{{ ' multi' if u.detected_by|length > 1 }}">{{ t }}</span>{% endfor %}</div>
    </div>
  </div>
{% endfor %}
</div></div>
{% endif %}

<div class="section-head" id="sec-sca"><span class="chev">▾</span><h3>{{ icon('sca') }} Código abierto (SCA)</h3><span class="count">{{ sca_total }}</span>
  <span class="hint">{{ projects|selectattr('issues')|list|length }} proyecto(s) con hallazgos{% if state_timestamps and state_timestamps.sca %}  ·  último escaneo {{ state_timestamps.sca[:16] }}{% endif %}</span></div>
<div class="sec-body">
{% if not projects %}<div class="empty">No se detectaron manifiestos o no hay vulnerabilidades.</div>{% endif %}
{% for p in projects %}{% if p.issues or p.error %}<details class="group sca-group" open>
  <summary>
    <span class="gt mono" title="{{ p.project }}">
      {{ icon('file') }} {{ p.project.split('/')[-1] if '/' in p.project else (p.project.split('\\')[-1] if '\\' in p.project else p.project) }}
      <span style="font-weight:400;font-size:10px;opacity:.7;margin-left:6px">{{ p.project }}</span>
    </span>
    <span class="gm">{{ mini(p.issues) }}</span>
  </summary>
  {% if p.error %}<div style="padding:16px;color:var(--mu)">Error: {{ p.error }}</div>
  {% elif p.issues %}<div class="table-wrap"><table>
    <thead><tr><th>Severidad</th><th>Paquete vulnerable</th><th>Versión instalada</th><th>Cadena de dependencias</th><th>Corregido en</th><th>Título / Aviso</th><th>CVE</th><th>CWE</th><th>¿Transitiva?</th></tr></thead><tbody>
    {% for i in p.issues %}
      {% set pkg_name = i.package.split('@')[0] if '@' in i.package else i.package %}
      {% set pkg_ver  = i.package.split('@')[1] if '@' in i.package else '' %}
      {% set dep_path = i.path or '(direct)' %}
      {% set is_trans = dep_path not in ('(direct)', '') %}
    <tr class="row" data-sev="{{ i.severity }}"
      data-text="{{ (i.package~' '~i.title~' '~i.cve~' '~i.cwe~' '~dep_path~' '~p.project~' '~(i.recommendation or ''))|lower }}">
      <td><span class="sev {{ i.severity }}">{{ sev_es.get(i.severity, i.severity) }}</span></td>
      <td>
        <code style="font-size:12px">{{ pkg_name }}</code>
        <div class="desc" style="font-size:10px;margin-top:2px;color:var(--mu)" title="{{ p.project }}">
          {{ icon('file') }} {{ p.project.split('/')[-1] if '/' in p.project else (p.project.split('\\')[-1] if '\\' in p.project else p.project) }}
        </div>
      </td>
      <td><code>{{ pkg_ver or '—' }}</code></td>
      <td class="mono" style="font-size:10px;color:var(--mu);max-width:220px;word-break:break-all" title="{{ dep_path }}">
        {% if is_trans %}{{ dep_path }}{% else %}<span style="color:var(--low)">(directa)</span>{% endif %}
      </td>
      <td>{% if i.fixedIn and i.fixedIn != '—' %}<span style="color:var(--low);font-weight:600">{{ i.fixedIn }}</span>{% else %}<span style="color:var(--mu)">—</span>{% endif %}</td>
      <td>{% if i.url %}<a href="{{ i.url }}" target="_blank">{{ i.title }}</a>{% else %}{{ i.title }}{% endif %}
        {% if i.description %}<div class="desc">{{ i.description[:300] }}</div>{% endif %}
        {{ fix_cell(i.recommendation) }}</td>
      <td>{% if i.cve %}<code style="color:var(--crit)">{{ i.cve }}</code>{% else %}<span style="color:var(--mu)">—</span>{% endif %}</td>
      <td><code>{{ i.cwe or '—' }}</code></td>
      <td style="text-align:center">{% if is_trans %}<span class="mini medium">indirecta</span>{% else %}<span class="mini low">directa</span>{% endif %}</td>
    </tr>{% endfor %}
    </tbody></table></div>
  {% endif %}
</details>{% endif %}{% endfor %}
</div>

<div class="section-head" id="sec-sast"><span class="chev">▾</span><h3>{{ icon('sast') }} Código estático (SAST)</h3><span class="count">{{ code_total }}</span>
  <span class="hint">{{ files|length }} archivo(s){% if state_timestamps and state_timestamps.code %}  ·  último escaneo {{ state_timestamps.code[:16] }}{% endif %}</span></div>
<div class="sec-body">
{% if not files %}<div class="empty">No se encontraron hallazgos SAST.</div>{% endif %}
{% for f in files %}<details class="group sast-group" open>
  <summary>
    <span class="gt mono" title="{{ f.file }}">
      {{ icon('file') }} {{ f.file.split('/')[-1] if '/' in f.file else (f.file.split('\\')[-1] if '\\' in f.file else f.file) }}
      <span style="font-weight:400;font-size:10px;opacity:.7;margin-left:6px">{{ f.file }}</span>
    </span>
    <span class="gm">{{ mini(f.issues) }}</span>
  </summary>
  <div class="table-wrap"><table>
    <thead><tr><th>Severidad</th><th>ID de regla</th><th>Nombre de regla</th><th>Archivo · Línea</th><th>CWE</th><th>OWASP</th><th>Mensaje / Corrección</th><th>Fragmento</th></tr></thead><tbody>
    {% set _SAST_OWASP = {'CWE-79':'A03 Injection','CWE-89':'A03 Injection','CWE-94':'A03 Injection','CWE-78':'A03 Injection','CWE-918':'A10 SSRF','CWE-611':'A05 Misconfiguration','CWE-22':'A01 Broken Access Control','CWE-352':'A01 Broken Access Control','CWE-862':'A01 Broken Access Control','CWE-502':'A08 Insecure Deserialization','CWE-327':'A02 Crypto Failures','CWE-326':'A02 Crypto Failures','CWE-798':'A07 Auth Failures','CWE-259':'A07 Auth Failures','CWE-287':'A07 Auth Failures','CWE-532':'A09 Logging Failures'} %}
    {% for i in f.issues %}
      {% set cwe_key = i.cwe.split(',')[0].strip().upper() %}
      {% set owasp_cat = _SAST_OWASP.get(cwe_key, '') %}
      {% set fname_short = f.file.split('/')[-1] if '/' in f.file else (f.file.split('\\')[-1] if '\\' in f.file else f.file) %}
    <tr class="row" data-sev="{{ i.severity }}"
      data-text="{{ (i.rule~' '~i.title~' '~i.message~' '~i.cwe~' '~f.file~' '~(i.recommendation or ''))|lower }}">
      <td><span class="sev {{ i.severity }}">{{ sev_es.get(i.severity, i.severity) }}</span></td>
      <td><code>{{ i.rule }}</code></td>
      <td style="font-weight:600">{{ i.title or i.rule }}</td>
      <td class="mono" style="font-size:10px;white-space:nowrap">
        <span style="color:var(--mu)" title="{{ f.file }}">{{ fname_short }}</span><br>
        <code style="color:var(--ink-2)">:{{ i.line }}</code>
        {% if i.col_start %}<span style="color:var(--mu);font-size:9px"> col {{ i.col_start }}{% if i.col_end and i.col_end != i.col_start %}–{{ i.col_end }}{% endif %}</span>{% endif %}
      </td>
      <td><code>{{ i.cwe or '—' }}</code></td>
      <td style="font-size:11px;color:var(--mu)">{{ owasp_cat or '—' }}</td>
      <td>{{ i.message }}
        {{ fix_cell(i.recommendation) }}</td>
      <td>{% if i.snippet %}<pre class="snippet">{{ i.snippet[:500] }}</pre>{% else %}<span style="color:var(--mu)">—</span>{% endif %}</td>
    </tr>{% endfor %}
    </tbody></table></div>
</details>{% endfor %}
</div>

{% if dast.findings or dast.pages_visited or dast.scan_url or dast.engine %}
<div class="section-head" id="sec-dast"><span class="chev">▾</span><h3>{{ icon('dast') }} Dinámico (DAST) — {{ dast.target }}</h3>
  <span class="count">{{ dast_total }}</span>
  <span class="hint">{% if dast.engine == 'snyk-api-web' %}Snyk API &amp; Web (nube) · perfil {{ dast.profile or 'target' }}{% else %}{{ (dast.engine or '')|replace('+', ' + ')|upper }} · perfil {{ dast.profile }}{% if dast.partial %} · PARCIAL{% endif %}{% endif %}{% if state_timestamps and state_timestamps.dast %}  ·  último escaneo {{ state_timestamps.dast[:16] }}{% endif %}</span></div>
<div class="sec-body">
{% if dast.scan_url or dast.report_path %}<div class="hint" style="margin:0 0 8px">
  {% if dast.scan_url %}<a href="{{ dast.scan_url }}" target="_blank">{{ icon('link') }} Abrir escaneo en Probely</a>{% endif %}
  {% if dast.report_path %}{% if dast.scan_url %} · {% endif %}<span class="mono">{{ icon('file') }} PDF: {{ dast.report_path }}</span>{% endif %}
</div>{% endif %}
{% if not dast.findings %}<div class="empty">No se encontraron hallazgos DAST.</div>{% endif %}
{% if dast.findings %}<details class="group" open>
  <summary><span class="gt">Hallazgos DAST</span><span class="gm">{{ mini(dast.findings) }}</span></summary>
  {% set _DAST_OWASP = {'auth':'API2 Broken Auth','injection':'API8 Injection','csrf':'API6 Mass Assignment','headers':'API7 Misconfiguration','ssl':'API7 Misconfiguration','redirect':'API3 Excessive Data Exposure','xss':'API8 Injection','sqli':'API8 Injection','cors':'API7 Misconfiguration','info':'API9 Improper Assets'} %}
  <div class="table-wrap"><table>
    <thead><tr><th>Severidad</th><th>OWASP API</th><th>Categoría</th><th>Título</th><th>URL</th><th>Método</th><th>Parámetro</th><th>CWE</th><th>Evidencia</th><th>Corrección recomendada</th></tr></thead><tbody>
    {% for d in dast.findings %}
      {% set cat_key = (d.category or '')|lower %}
    <tr class="row" data-sev="{{ d.severity }}"
      data-text="{{ (d.title~' '~d.url~' '~(d.cwe or '')~' '~(d.category or ''))|lower }}">
      <td><span class="sev {{ d.severity }}">{{ sev_es.get(d.severity, d.severity) }}</span></td>
      <td style="font-size:11px;white-space:nowrap">{{ _DAST_OWASP.get(cat_key, '—') }}</td>
      <td>{{ d.category or '—' }}</td>
      <td style="font-weight:600">{{ d.title }}{{ sources_cell(d) }}</td>
      <td class="mono"><a href="{{ d.url }}" target="_blank" style="font-size:11px">{{ d.url[:70] }}</a></td>
      <td><code>{{ d.method or '—' }}</code></td>
      <td><code>{{ d.param or '—' }}</code></td>
      <td><code>{{ d.cwe or '—' }}</code></td>
      <td class="mono" style="font-size:11px">{{ (d.evidence or '')[:150] }}</td>
      <td style="font-size:11px;color:var(--mu)">{{ (d.remediation or solution.get(cat_key, '—'))[:400] }}</td>
    </tr>{% endfor %}
    </tbody></table></div>
</details>{% endif %}
</div>
{% endif %}

{% if api.findings or api.endpoints_tested or api.scan_url or api.engine %}
<div class="section-head" id="sec-api"><span class="chev">▾</span><h3>{{ icon('api') }} Seguridad de API</h3>
  <span class="count">{{ api_total }}</span>
  <span class="hint">{% if api.engine == 'snyk-api-web' %}Snyk API &amp; Web (nube) · perfil {{ api.profile or 'target' }}{% else %}{{ (api.engine or '')|replace('+', ' + ')|upper }} · {{ api.endpoints_total }} endpoints · perfil {{ api.profile }}{% if api.partial %} · PARCIAL{% endif %}{% endif %}{% if state_timestamps and state_timestamps.api %}  ·  último escaneo {{ state_timestamps.api[:16] }}{% endif %}</span></div>
<div class="sec-body">
{% if api.scan_url or api.report_path %}<div class="hint" style="margin:0 0 8px">
  {% if api.scan_url %}<a href="{{ api.scan_url }}" target="_blank">{{ icon('link') }} Abrir escaneo en Probely</a>{% endif %}
  {% if api.report_path %}{% if api.scan_url %} · {% endif %}<span class="mono">{{ icon('file') }} PDF: {{ api.report_path }}</span>{% endif %}
</div>{% endif %}
{% if not api.findings %}<div class="empty">No se encontraron hallazgos de seguridad de API.</div>{% endif %}
{% if api.findings %}<details class="group" open>
  <summary><span class="gt">Hallazgos de API</span><span class="gm">{{ mini(api.findings) }}</span></summary>
  {% set _API_OWASP = {'auth':'API2 Broken Auth','injection':'API8 Injection','csrf':'API6 Mass Assignment','headers':'API7 Misconfiguration','ssl':'API7 Misconfiguration','redirect':'API3 Excessive Data Exposure','xss':'API8 Injection','sqli':'API8 Injection','cors':'API7 Misconfiguration','info':'API9 Improper Assets','no-auth':'API1 Broken Object Level Auth','bola':'API1 Broken Object Level Auth','rate-limit':'API4 Unrestricted Resource Consumption'} %}
  <div class="table-wrap"><table>
    <thead><tr><th>Severidad</th><th>OWASP API Top-10</th><th>Categoría</th><th>Título</th><th>URL del endpoint</th><th>Método HTTP</th><th>Parámetro</th><th>CWE</th><th>¿Requiere autenticación?</th><th>Evidencia</th><th>Corrección recomendada</th></tr></thead><tbody>
    {% for d in api.findings %}
      {% set cat_key = (d.category or '')|lower %}
    <tr class="row" data-sev="{{ d.severity }}"
      data-text="{{ (d.title~' '~d.url~' '~(d.cwe or '')~' '~(d.category or ''))|lower }}">
      <td><span class="sev {{ d.severity }}">{{ sev_es.get(d.severity, d.severity) }}</span></td>
      <td style="font-size:11px;white-space:nowrap">{{ _API_OWASP.get(cat_key, '—') }}</td>
      <td>{{ d.category or '—' }}</td>
      <td style="font-weight:600">{{ d.title }}{{ sources_cell(d) }}</td>
      <td class="mono"><a href="{{ d.url }}" target="_blank" style="font-size:11px">{{ d.url[:70] }}</a></td>
      <td><code>{{ d.method or '—' }}</code></td>
      <td><code>{{ d.param or '—' }}</code></td>
      <td><code>{{ d.cwe or '—' }}</code></td>
      <td style="text-align:center">{% if d.auth_required is not none %}{% if d.auth_required %}<span class="mini low">Sí</span>{% else %}<span class="mini high">No</span>{% endif %}{% else %}<span style="color:var(--mu)">—</span>{% endif %}</td>
      <td class="mono" style="font-size:11px">{{ (d.evidence or '')[:150] }}</td>
      <td style="font-size:11px;color:var(--mu)">{{ (d.remediation or solution.get(cat_key, '—'))[:400] }}</td>
    </tr>{% endfor %}
    </tbody></table></div>
</details>{% endif %}
</div>
{% endif %}

{% if secrets.findings or secrets.scanned_files %}
<div class="section-head" id="sec-secrets"><span class="chev">▾</span><h3>{{ icon('secrets') }} Secretos / Credenciales embebidas</h3>
  <span class="count">{{ secrets_total }}</span>
  <span class="hint">{{ secrets.scanned_files }} archivos escaneados · motor: {{ secrets.engine or 'integrado' }}{% if state_timestamps and state_timestamps.secrets %}  ·  último escaneo {{ state_timestamps.secrets[:16] }}{% endif %}</span></div>
<div class="sec-body">
<p style="font-size:12px;color:var(--mu);margin:0 0 12px">
  Los hallazgos siguen <b>CWE-798</b> (uso de credenciales embebidas) y
  <b>CWE-259</b> (uso de contraseña embebida). Todos los valores detectados se
  muestran ocultos. Trate cualquier credencial señalada como comprometida: <b>rótela</b>
  y elimínela del historial de control de versiones (git-filter-repo / BFG).
</p>
{% if not secrets.findings %}<div class="empty">No se detectaron secretos embebidos.</div>{% endif %}
{% if secrets.findings %}<details class="group" open>
  <summary><span class="gt">Hallazgos de secretos</span><span class="gm">{{ mini(secrets.findings) }}</span></summary>
  <div class="table-wrap"><table>
    <thead>
      <tr>
        <th>Severidad</th><th>Tipo de secreto</th><th>CWE</th><th>OWASP Top 10</th>
        <th>Ruta del archivo</th><th>Línea</th>
        <th>Secreto (oculto)</th><th>Fragmento de contexto</th>
        <th>Motor</th><th>Acción de remediación</th>
      </tr>
    </thead><tbody>
    {% for s in secrets.findings %}
      {% set stype_key = (s.secret_type or s.rule or '')|lower %}
      {% set eff_cwe   = s.cwe if s.cwe else secret_cwe.get(stype_key, 'CWE-798') %}
    <tr class="row" data-sev="{{ s.severity }}"
      data-text="{{ (s.secret_type~' '~s.file~' '~s.rule~' '~s.cwe)|lower }}">
      <td><span class="sev {{ s.severity }}">{{ sev_es.get(s.severity, s.severity) }}</span></td>
      <td style="font-weight:600;white-space:nowrap">{{ s.secret_type or s.rule }}</td>
      <td><code>{{ eff_cwe }}</code></td>
      <td style="font-size:11px;color:var(--mu);white-space:nowrap">A07 Auth Failures</td>
      <td class="mono"><code>{{ s.file }}</code></td>
      <td style="text-align:center"><code>{{ s.line }}</code></td>
      <td><code style="color:var(--crit)">{{ s.match }}</code>
        {% if s.context %}<div class="desc mono">{{ s.context }}</div>{% endif %}</td>
      <td style="font-size:11px">{% if s.context %}<pre class="snippet" style="max-height:80px">{{ s.context[:300] }}</pre>{% else %}—{% endif %}</td>
      <td style="font-size:11px">{{ s.engine or 'integrado' }}</td>
      <td style="font-size:11px;color:var(--crit);font-weight:600">{{ icon('warn') }} ROTAR de inmediato y eliminar del historial de git</td>
    </tr>{% endfor %}
    </tbody></table></div>
</details>{% endif %}
</div>
{% endif %}

{% if container.findings or container.images %}
<div class="section-head" id="sec-container"><span class="chev">▾</span><h3>{{ icon('container') }} Contenedores</h3>
  <span class="count">{{ container_total }}</span>
  <span class="hint">{{ container.images|length }} imagen(es) · motor {{ container.engine or 'trivy' }}{% if state_timestamps and state_timestamps.container %}  ·  último escaneo {{ state_timestamps.container[:16] }}{% endif %}</span></div>
<div class="sec-body">
{% if container.images %}<div class="hint" style="margin:0 0 8px">{% for im in container.images %}
  {% if im is string %}<span class="by multi">{{ im }}</span>{% else %}<span class="by{{ ' multi' if im.status == 'ok' }}">{{ im.artifact or im.value }}{% if im.os %} · {{ im.os }}{% endif %}{% if im.status != 'ok' %} · NO ANALIZADA{% endif %}{% if im.eosl %} · SO SIN SOPORTE{% endif %}</span>{% endif %}{% endfor %}</div>{% endif %}
{% if not container.findings %}<div class="empty">No se encontraron vulnerabilidades en las imágenes analizadas.</div>{% else %}
<details class="group" open><summary><span class="gt">Hallazgos en imágenes</span><span class="gm">{{ mini(container.findings) }}</span></summary>
  <div class="table-wrap"><table>
    <thead><tr><th>Severidad</th><th>ID</th><th>Paquete</th><th>Instalada</th><th>Corregida en</th><th>Imagen / capa</th><th>CWE</th><th>Título</th></tr></thead><tbody>
    {% for v in container.findings %}
    <tr class="row" data-sev="{{ v.severity }}" data-text="{{ (v.vuln_id~' '~v.package~' '~v.target~' '~(v.cwe or '')~' '~(v.title or ''))|lower }}">
      <td><span class="sev {{ v.severity }}">{{ sev_es.get(v.severity, v.severity) }}</span></td>
      <td>{% if v.url %}<a href="{{ v.url }}" target="_blank"><code>{{ v.vuln_id }}</code></a>{% else %}<code>{{ v.vuln_id }}</code>{% endif %}</td>
      <td><code>{{ v.package }}</code>{% if v.kind_detail %}<div class="desc">{{ 'configuración' if v.kind_detail == 'config' else 'secreto' }}</div>{% endif %}</td>
      <td><code>{{ v.installed or '—' }}</code></td>
      <td>{% if v.fixed %}<span style="color:var(--low);font-weight:600">{{ v.fixed }}</span>{% else %}<span style="color:var(--mu)">—</span>{% endif %}</td>
      <td class="mono" style="font-size:10px;max-width:260px;word-break:break-all">{{ v.target }}</td>
      <td><code>{{ v.cwe or '—' }}</code></td>
      <td>{{ v.title }}{% if v.description %}<div class="desc">{{ v.description[:260] }}</div>{% endif %}{{ fix_cell(v.remediation) }}</td>
    </tr>{% endfor %}
    </tbody></table></div>
</details>{% endif %}
</div>
{% endif %}

{% if iac.findings or iac.targets %}
<div class="section-head" id="sec-iac"><span class="chev">▾</span><h3>{{ icon('iac') }} Infraestructura como código</h3>
  <span class="count">{{ iac_total }}</span>
  <span class="hint">{% for k, n in iac.frameworks.items() %}{{ k }} ({{ n }}){{ ', ' if not loop.last }}{% endfor %} · motores {{ (iac.engine or '')|replace('+', ' + ') }}{% if state_timestamps and state_timestamps.iac %}  ·  último escaneo {{ state_timestamps.iac[:16] }}{% endif %}</span></div>
<div class="sec-body">
{% if not iac.findings %}<div class="empty">No se encontraron configuraciones inseguras.</div>{% else %}
{% for f in iac.findings|groupby('file') %}
<details class="group" open><summary><span class="gt mono">{{ icon('file') }} {{ f.grouper }}</span><span class="gm">{{ mini(f.list) }}</span></summary>
  <div class="table-wrap"><table>
    <thead><tr><th>Severidad</th><th>Regla</th><th>Hallazgo</th><th>Recurso</th><th>Líneas</th><th>CWE</th></tr></thead><tbody>
    {% for m in f.list %}
    <tr class="row" data-sev="{{ m.severity }}" data-text="{{ (m.rule_id~' '~m.title~' '~f.grouper~' '~(m.resource or '')~' '~(m.cwe or ''))|lower }}">
      <td><span class="sev {{ m.severity }}">{{ sev_es.get(m.severity, m.severity) }}</span>{% if m.severity_estimated %}<div class="desc" title="Checkov no publica severidad sin licencia comercial; se estima por el tipo de debilidad">estimada</div>{% endif %}</td>
      <td><code>{{ m.rule_id }}</code></td>
      <td style="font-weight:600">{{ m.title }}{{ sources_cell(m) }}{{ fix_cell(m.remediation) }}</td>
      <td class="mono" style="font-size:11px">{{ m.resource or '—' }}</td>
      <td><code>{{ m.line or '—' }}{% if m.end_line and m.end_line != m.line %}–{{ m.end_line }}{% endif %}</code></td>
      <td><code>{{ m.cwe or '—' }}</code></td>
    </tr>{% endfor %}
    </tbody></table></div>
</details>{% endfor %}{% endif %}
</div>
{% endif %}

{% if cwe_groups %}
<div class="section-head" id="sec-cwe"><span class="chev">▾</span><h3>{{ icon('chart') }} Vista unificada por CWE y OWASP Top 10</h3>
  <span class="count">{{ cwe_groups|length }}</span>
  <span class="hint">Todas las herramientas y etapas, agrupadas por tipo de debilidad</span></div>
<div class="sec-body">
{% if owasp_rows %}{% set mx = owasp_rows|map(attribute=1)|max %}
<div class="panel" style="border:1px solid var(--line);margin-bottom:12px"><h2>OWASP Top 10 (2021)</h2>
{% for name, n, w in owasp_rows %}<div class="owasp-bar"><span class="lbl">{{ name }}</span>
  <span class="track"><span class="fill" style="display:block;width:{{ (n*100/(mx or 1))|round(1) }}%;background:var(--{{ {'critical':'crit','high':'high','medium':'med','low':'low'}.get(w,'ink-2') }})"></span></span>
  <b>{{ n }}</b></div>{% endfor %}
</div>{% endif %}
<details class="group" open><summary><span class="gt">Debilidades (CWE)</span></summary>
  <div class="table-wrap"><table>
    <thead><tr><th>Peor severidad</th><th>CWE</th><th>Debilidad</th><th>OWASP</th><th>Hallazgos</th><th>Dónde</th><th>Herramientas</th><th>Cómo se corrige</th></tr></thead><tbody>
    {% for g in cwe_groups %}
    <tr class="row" data-sev="{{ g.worst }}" data-text="{{ (g.cwe~' '~g.name~' '~g.owasp~' '~g.tools|join(' '))|lower }}">
      <td><span class="sev {{ g.worst }}">{{ sev_es.get(g.worst, g.worst) }}</span></td>
      <td><code>{{ g.cwe }}</code>{% if g.confirmed %}<div style="margin-top:4px"><span class="conf" title="Aparece en el código y en la aplicación en ejecución">Confirmado</span></div>{% endif %}</td>
      <td style="font-weight:600">{{ g.name or '—' }}</td>
      <td style="font-size:11px;color:var(--mu)">{{ g.owasp or '—' }}</td>
      <td style="text-align:center"><b>{{ g.count }}</b></td>
      <td style="font-size:11px">{% for k in g.kinds %}{{ kind_es.get(k, k) }}{{ ', ' if not loop.last }}{% endfor %}</td>
      <td>{% for t in g.tools %}<span class="by">{{ t }}</span>{% endfor %}</td>
      <td style="font-size:11px;color:var(--mu)">{{ g.fix or '—' }}</td>
    </tr>{% endfor %}
    </tbody></table></div>
</details>
</div>
{% endif %}

<footer>Generado por el escáner de vulnerabilidades · Snyk {{ snyk_version or '?' }} · {{ generated_at }}</footer>
</div>
<script>
(function(){
  var rows=document.querySelectorAll('.row'),
      chips=document.querySelectorAll('.chip'),
      search=document.getElementById('search'),
      btt=document.getElementById('btt');
  var curSev='all',curQ='';

  function filter(){
    rows.forEach(function(r){
      var sev=r.dataset.sev,txt=r.dataset.text||'';
      var ok=(curSev==='all'||sev===curSev)&&(!curQ||txt.includes(curQ));
      r.classList.toggle('hide',!ok);
    });
    document.querySelectorAll('details.group').forEach(function(g){
      var allRows=g.querySelectorAll('.row');
      if(allRows.length===0){g.classList.remove('grp-hidden');return;}
      var anyVis=false;
      allRows.forEach(function(r){if(!r.classList.contains('hide'))anyVis=true;});
      g.classList.toggle('grp-hidden',!anyVis);
    });
  }

  chips.forEach(function(c){
    c.onclick=function(){
      chips.forEach(function(x){x.classList.remove('active');});
      c.classList.add('active');curSev=c.dataset.sev;filter();
    };
  });
  if(search){
    search.oninput=function(){curQ=search.value.toLowerCase();filter();};
    document.addEventListener('keydown',function(e){
      if(e.key==='/'&&document.activeElement!==search){e.preventDefault();search.focus();}
    });
  }
  if(btt){
    window.addEventListener('scroll',function(){
      btt.classList.toggle('vis',window.scrollY>400);
    });
  }
  function expandSection(head){
    head.classList.remove('collapsed');
    var body=head.nextElementSibling;
    if(body&&body.classList.contains('sec-body'))body.classList.remove('collapsed');
  }
  document.querySelectorAll('.section-head').forEach(function(head){
    head.addEventListener('click',function(){
      var body=head.nextElementSibling;
      if(!body||!body.classList.contains('sec-body'))return;
      head.classList.toggle('collapsed');
      body.classList.toggle('collapsed');
    });
  });
  document.querySelectorAll('.idx a[href^="#"]').forEach(function(a){
    a.addEventListener('click',function(){
      var head=document.getElementById(a.getAttribute('href').slice(1));
      if(head)expandSection(head);
    });
  });
  function expandFromHash(){
    if(!location.hash)return;
    var head=document.getElementById(location.hash.slice(1));
    if(head&&head.classList.contains('section-head'))expandSection(head);
  }
  window.addEventListener('hashchange',expandFromHash);
  expandFromHash();
})();
</script>
</body></html>
"""

_STAGE_LABELS = [("sca", "SCA"), ("code", "SAST"), ("secrets", "Secretos"), ("container", "Contenedores"),
                 ("iac", "IaC"), ("dast", "DAST"), ("api", "API")]


def render_html(ctx: dict, out_dir: Path, filename: str = "report.html") -> Path:
    keys = {k for k in (ctx.get("scan_mode") or "").split("+") if k}
    stages = " · ".join(lbl for k, lbl in _STAGE_LABELS if k in keys) if keys else " · ".join(l for _, l in _STAGE_LABELS)
    import findings as fz
    try:
        prio, groups, owasp = fz.priorities(ctx, 10), fz.group_by_cwe(ctx), fz.owasp_summary(ctx)
    except Exception:
        prio, groups, owasp = [], [], []
    return _render(REPORT_TEMPLATE, Path(out_dir) / filename, **{**ctx, "subtitle_stages": stages},
                   solution=DAST_SOLUTION, secret_cwe=SECRET_CWE, priorities=prio, cwe_groups=groups,
                   owasp_rows=owasp, kind_es=KIND_ES)


KIND_ES = {"sca": "Dependencias", "code": "Código", "secrets": "Secretos", "container": "Contenedor", "iac": "IaC",
           "dast": "Web", "api": "API"}


STATIC_BATCH_INDEX_TEMPLATE = r"""<!doctype html>
<html lang="es"><head><meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Índice de análisis estático — {{ generated_at }}</title>
<style>
:root{
  --paper:#FBFAF7;--panel:#FFFFFF;--panel-2:#F3F1EA;
  --line:#E1DDD1;--line-2:#CBC4B2;
  --ink:#14243D;--ink-2:#28456B;--mu:#78715F;--gold:#F5A800;
  --crit:#B3261E;--high:#B8560B;--med:#8E6B10;--low:#2E6B4F;
}
*{box-sizing:border-box}
body{margin:0;background:var(--paper);color:var(--ink);font:14px/1.6 'Segoe UI',-apple-system,Roboto,Arial,sans-serif}
a{color:var(--ink-2);text-decoration:none;border-bottom:1px solid var(--line-2)}
a:hover{border-bottom-color:var(--ink-2)}
.shell{max-width:1100px;margin:0 auto;padding:0 24px 60px}
header{border-bottom:3px solid var(--ink);padding:26px 0 16px;margin-bottom:22px}
h1{margin:0;font:600 22px/1.25 Georgia,'Iowan Old Style',serif;color:var(--ink)}
.sub{color:var(--mu);font-size:10.5px;text-transform:uppercase;letter-spacing:.12em;margin-top:4px}
.statstrip{display:flex;gap:0;margin:0 0 28px;flex-wrap:wrap}
.stat{flex:1 1 130px;padding:2px 20px 2px 0;margin-right:20px;border-right:1px solid var(--line);min-width:110px}
.stat:last-child{border-right:0;margin-right:0}
.stat .l{color:var(--mu);font-size:10px;text-transform:uppercase;letter-spacing:.09em;font-weight:700}
.stat .v{font:600 27px/1.15 Georgia,'Iowan Old Style',serif;margin-top:5px;color:var(--ink)}
.stat .v.critical{color:var(--crit)}.stat .v.high{color:var(--high)}
.stat .v.medium{color:var(--med)}.stat .v.low{color:var(--low)}
table{width:100%;border-collapse:collapse;font-size:12.5px;margin-top:8px}
th{text-align:left;color:var(--mu);font-size:10px;text-transform:uppercase;letter-spacing:.07em;
  font-weight:700;padding:9px 14px;border-bottom:1px solid var(--line-2)}
td{padding:11px 14px;vertical-align:top;border-bottom:1px solid var(--line)}
tr:hover td{background:var(--panel-2)}
.pill{display:inline-block;padding:2px 8px;border-radius:2px;font-size:10px;font-weight:700;
  text-transform:uppercase;letter-spacing:.03em;color:#fff}
.pill.ok{background:var(--low)}.pill.skip{background:var(--mu)}
.counts{font-family:ui-monospace,Consolas,monospace;font-size:11px}
.counts .critical{color:var(--crit)}.counts .high{color:var(--high)}
.counts .medium{color:var(--med)}.counts .low{color:var(--low)}
footer{text-align:center;color:var(--mu);font-size:11px;padding:34px 0 0;border-top:1px solid var(--line);margin-top:20px}
</style></head><body><div class="shell">
<header>
  <h1>Índice de análisis estático</h1>
  <div class="sub">{{ scanned_count }} de {{ folder_count }} carpeta(s) escaneada(s) — vista agregada del lote</div>
</header>
<div class="statstrip">
  <div class="stat"><div class="l">Carpetas</div><div class="v">{{ folder_count }}</div></div>
  <div class="stat"><div class="l">🔴 Crítico</div><div class="v critical">{{ agg.critical }}</div></div>
  <div class="stat"><div class="l">🟠 Alto</div><div class="v high">{{ agg.high }}</div></div>
  <div class="stat"><div class="l">🟡 Medio</div><div class="v medium">{{ agg.medium }}</div></div>
  <div class="stat"><div class="l">🟢 Bajo</div><div class="v low">{{ agg.low }}</div></div>
</div>
<table>
<thead><tr><th>Carpeta</th><th>Estado</th><th>Hallazgos (C/A/M/B)</th><th>Ticket</th><th>Reporte</th></tr></thead>
<tbody>
{% for r in rows %}
<tr>
  <td><code>{{ r.path }}</code></td>
  <td>{% if r.scanned %}<span class="pill ok">Escaneada</span>{% else %}<span class="pill skip">Omitida{{ (' — ' + r.reason) if r.reason else '' }}</span>{% endif %}</td>
  <td class="counts">{% if r.scanned %}<span class="critical">{{ r.counts.critical or 0 }}</span> / <span class="high">{{ r.counts.high or 0 }}</span> / <span class="medium">{{ r.counts.medium or 0 }}</span> / <span class="low">{{ r.counts.low or 0 }}</span>{% else %}—{% endif %}</td>
  <td>{{ r.ticket or '—' }}</td>
  <td>{% if r.rel_report %}<a href="{{ r.rel_report }}">Ver reporte →</a>{% else %}—{% endif %}</td>
</tr>
{% endfor %}
</tbody>
</table>
<footer>Generado {{ generated_at }} · SecDevOps Banco Base</footer>
</div></body></html>
"""


def render_static_batch_index(batch: list[dict], out_dir: Path, filename: str = "index.html") -> Path:
    agg = {"critical": 0, "high": 0, "medium": 0, "low": 0}
    rows = []
    for e in batch:
        counts = e.get("counts") or {}
        for s in agg:
            agg[s] += int(counts.get(s, 0) or 0)
        rel = None
        if rp := e.get("report_path"):
            try:
                rel = os.path.relpath(rp, out_dir)
            except Exception:
                rel = str(rp)
        rows.append({"path": e.get("path", ""), "scanned": bool(e.get("scanned")), "reason": e.get("reason", ""),
                     "rel_report": rel, "counts": counts, "total": e.get("total", 0), "ticket": e.get("ticket") or ""})
    return _render(STATIC_BATCH_INDEX_TEMPLATE, Path(out_dir) / filename, generated_at=now_human(), rows=rows, agg=agg,
                   folder_count=len(rows), scanned_count=sum(r["scanned"] for r in rows))


HISTORY_FILENAME = "remediation_history.json"


def _sig(*parts) -> str:
    return hashlib.sha1("|".join("" if p is None else str(p) for p in parts).lower().encode("utf-8", "ignore")).hexdigest()[:16]


def collect_signatures(ctx: dict) -> dict[str, dict]:
    sigs = {}
    base = lambda n: Path(str(n)).name or str(n)
    for p in ctx.get("projects", []):
        proj = base(p.get("project", ""))
        for i in p.get("issues", []):
            sigs[_sig("sca", proj, i.get("package"), i.get("id") or i.get("title"))] = {
                "kind": "sca", "severity": i.get("severity", "low"), "title": i.get("title", ""),
                "where": f"{proj} · {i.get('package', '')}"}
    for f in ctx.get("files", []):
        fl = base(f.get("file", ""))
        for i in f.get("issues", []):
            sigs[_sig("sast", fl, i.get("rule"), i.get("title") or i.get("message"))] = {
                "kind": "sast", "severity": i.get("severity", "low"), "title": i.get("title") or i.get("message", ""),
                "where": f"{fl}:{i.get('line', '?')}"}
    for kind in ("dast", "api"):
        for d in (ctx.get(kind) or {}).get("findings", []):
            path = urlparse(d.get("url", "")).path or d.get("url", "")
            sigs[_sig(kind, d.get("category"), path, d.get("title"))] = {
                "kind": kind, "severity": d.get("severity", "low"), "title": d.get("title", ""), "where": path}
    for v in (ctx.get("container") or {}).get("findings", []):
        sigs[_sig("container", v.get("target"), v.get("package"), v.get("vuln_id"))] = {
            "kind": "container", "severity": v.get("severity", "low"), "title": v.get("vuln_id") or v.get("title", ""),
            "where": f"{v.get('target', '')} · {v.get('package', '')}"}
    for m in (ctx.get("iac") or {}).get("findings", []):
        sigs[_sig("iac", m.get("file"), m.get("resource") or m.get("line"), m.get("rule_id") or m.get("title"))] = {
            "kind": "iac", "severity": m.get("severity", "low"), "title": m.get("title", ""),
            "where": f"{m.get('file', '')}:{m.get('line', '?')}"}
    for s in (ctx.get("secrets") or {}).get("findings", []):
        sigs[_sig("secrets", s.get("rule"), s.get("file"), s.get("line"))] = {
            "kind": "secrets", "severity": s.get("severity", "high"), "title": s.get("secret_type") or s.get("rule", ""),
            "where": f"{s.get('file', '')}:{s.get('line', '?')}"}
    return sigs


def load_history(reports_root) -> dict:
    data = read_json(Path(reports_root) / HISTORY_FILENAME)
    if not isinstance(data, dict):
        return {"version": 1, "scans": [], "actions": []}
    data.setdefault("scans", [])
    data.setdefault("actions", [])
    return data


def save_history(reports_root, data: dict) -> Path:
    write_json(p := Path(reports_root) / HISTORY_FILENAME, data)
    return p


def update_history_after_scan(reports_root, ctx: dict, meta: dict, *, actor=None, report_dir=None) -> dict:
    hist = load_history(reports_root)
    sigs = collect_signatures(ctx)
    cur = set(sigs)
    mode = meta.get("mode") or ctx.get("scan_mode") or "?"
    prev = next((r for r in reversed(hist["scans"]) if r.get("mode") == mode), hist["scans"][-1] if hist["scans"] else None)
    prev_sigs = set((prev or {}).get("signatures", []))
    remediated = sorted(prev_sigs - cur) if prev else []
    rec = {"ts": ctx.get("generated_at") or ts(), "mode": mode, "target": meta.get("target") or ctx.get("target", ""),
           "total": ctx.get("total", 0), "counts": dict(ctx.get("counts", {})), "actor": actor or "",
           "report_dir": str(report_dir or ""), "signatures": sorted(cur), "remediated_count": len(remediated),
           "introduced_count": len(cur - prev_sigs), "persisting_count": len(cur & prev_sigs) if prev else 0,
           "remediated": [{"sig": s, **prev.get("sig_index", {}).get(s, {})} for s in remediated],
           "sig_index": {s: {k: v[k] for k in ("title", "severity", "where", "kind")} for s, v in sigs.items()}}
    hist["scans"].append(rec)
    hist["actions"] += [{"ts": rec["ts"], "actor": actor or "auto", "status": "remediated", "source": "auto",
                         "sig": i.get("sig", ""), "title": i.get("title", ""), "severity": i.get("severity", ""),
                         "where": i.get("where", ""), "note": f"Ya no se detecta en el escaneo {mode.upper()}"}
                        for i in rec["remediated"]]
    save_history(reports_root, hist)
    return rec


def _fmt_ts(value) -> str:
    s = str(value or "").strip()
    if not s:
        return "—"
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y%m%d_%H%M%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return datetime.strptime(s, fmt).strftime("%Y-%m-%d %H:%M")
        except ValueError:
            pass
    return s


_HISTORY_TEMPLATE = r"""<!doctype html><html lang="es"><head><meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Historial de remediación — {{ now }}</title><style>
:root{
  --paper:#FBFAF7;--panel:#FFFFFF;--panel-2:#F3F1EA;
  --line:#E1DDD1;--line-2:#CBC4B2;
  --ink:#14243D;--ink-2:#28456B;--mu:#78715F;
  --gold:#F5A800;--crit:#B3261E;--high:#B8560B;--med:#8E6B10;--low:#2E6B4F;
  --r:4px;--rt:2px;
}
*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);
font:14px/1.6 'Segoe UI',-apple-system,Roboto,Arial,sans-serif}
code{font-family:ui-monospace,Menlo,Consolas,monospace;background:var(--panel-2);border:1px solid var(--line);border-radius:var(--rt);padding:1px 6px;font-size:12px}
.shell{max-width:1240px;margin:0 auto;padding:0 clamp(16px,4vw,48px) 80px}
.masthead{border-bottom:3px solid var(--ink);padding:26px 0 16px;margin-bottom:22px;
  display:flex;align-items:flex-end;justify-content:space-between;gap:20px;flex-wrap:wrap}
.brand-mark{display:flex;align-items:center;gap:12px}
.brand-mark .bar{width:5px;align-self:stretch;background:var(--gold);flex:0 0 auto;min-height:34px}
h1{margin:0;font:600 22px/1.25 Georgia,'Iowan Old Style','Palatino Linotype',serif;color:var(--ink)}
.sub{color:var(--mu);font-size:10.5px;text-transform:uppercase;letter-spacing:.12em;margin-top:4px}
.meta-list{display:flex;gap:16px;flex-wrap:wrap;font-size:11px;color:var(--mu)}
.meta-item{border-left:1px solid var(--line-2);padding-left:16px}
.meta-item:first-child{border-left:0;padding-left:0}
.meta-item b{color:var(--ink);font-weight:600}
.statstrip{display:flex;flex-wrap:wrap;border:1px solid var(--line);background:var(--panel);padding:18px 22px;margin-bottom:24px}
.stat{flex:1 1 150px;padding:2px 20px 2px 0;margin-right:20px;border-right:1px solid var(--line);min-width:130px}
.stat:last-child{border-right:0;margin-right:0}
.stat .l{color:var(--mu);font-size:10px;text-transform:uppercase;letter-spacing:.09em;font-weight:700}
.stat .v{font:600 28px/1.15 Georgia,'Iowan Old Style',serif;margin-top:5px;color:var(--ink)}
.stat .v.good{color:var(--low)}.stat .v.bad{color:var(--crit)}
.panel{background:var(--panel);border:1px solid var(--line);padding:20px 22px;margin-bottom:22px}
h2{font-size:10px;text-transform:uppercase;letter-spacing:.14em;color:var(--mu);margin:0 0 16px;font-weight:700}
.chart{width:100%;height:240px}
table{width:100%;border-collapse:collapse;font-size:12.5px}
th{text-align:left;color:var(--mu);font-size:10px;text-transform:uppercase;letter-spacing:.07em;font-weight:700;padding:9px 12px;border-bottom:1px solid var(--line-2)}
td{padding:10px 12px;border-bottom:1px solid var(--line);vertical-align:top}
tr:last-child td{border-bottom:0}
.sev{display:inline-block;padding:2px 8px;border-radius:var(--rt);font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.03em;color:#fff}
.sev.critical{background:var(--crit)}.sev.high{background:var(--high)}
.sev.medium{background:var(--med)}.sev.low{background:var(--low)}
.delta-pos{color:var(--low);font-weight:700}.delta-neg{color:var(--crit);font-weight:700}
.badge{display:inline-block;padding:2px 8px;border-radius:var(--rt);font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.03em;color:#fff}
.badge.remediated{background:var(--low)}.badge.manual{background:var(--gold);color:var(--ink)}
.badge.regression{background:var(--crit)}
.empty{text-align:center;padding:40px;color:var(--mu);border:1px dashed var(--line-2)}
footer{text-align:center;color:var(--mu);font-size:11px;padding:34px 0 0;border-top:1px solid var(--line);margin-top:20px}
</style></head><body><div class="shell">
<header class="masthead">
  <div class="brand-mark"><span class="bar"></span>
    <div><h1>Historial de remediación</h1><div class="sub">Vista longitudinal de hallazgos corregidos en el tiempo</div></div></div>
  <div class="meta-list">
    <span class="meta-item">Escaneos <b>{{ scans|length }}</b></span>
    <span class="meta-item">Acciones <b>{{ actions|length }}</b></span>
    <span class="meta-item">Generado <b>{{ now }}</b></span>
  </div>
</header>

<div class="statstrip">
<div class="stat"><div class="l">Total remediadas</div><div class="v good">{{ total_remediated }}</div></div>
<div class="stat"><div class="l">Total introducidas</div><div class="v bad">{{ total_introduced }}</div></div>
<div class="stat"><div class="l">Abiertas en el último escaneo</div><div class="v">{{ latest_total }}</div></div>
<div class="stat"><div class="l">Acciones manuales</div><div class="v">{{ manual_actions }}</div></div>
</div>

{% if points|length > 1 %}
<div class="panel"><h2>Hallazgos abiertos en el tiempo</h2>
<svg class="chart" viewBox="0 0 {{ vw }} {{ vh }}" preserveAspectRatio="none">
  <line x1="40" y1="{{ vh-26 }}" x2="{{ vw-10 }}" y2="{{ vh-26 }}" style="stroke:var(--line-2)"/>
  <polyline fill="none" style="stroke:var(--gold)" stroke-width="2.5"
    points="{{ polyline }}"/>
  {% for px,py,val,dt in dots %}
  <circle cx="{{ px }}" cy="{{ py }}" r="3.5" style="fill:var(--gold)"/>
  <text x="{{ px }}" y="{{ py-9 }}" font-size="11" style="fill:var(--ink)" text-anchor="middle">{{ val }}</text>
  <text x="{{ px }}" y="{{ vh-9 }}" font-size="10" style="fill:var(--mu)" text-anchor="middle">{{ dt }}</text>
  {% endfor %}
</svg></div>
{% endif %}

<div class="panel"><h2>Cronología de escaneos</h2>
{% if not scans %}<div class="empty">Aún no hay escaneos registrados.</div>{% else %}
<table><thead><tr><th>Cuándo</th><th>Modo</th><th>Abiertas</th><th>Críticas</th><th>Altas</th>
<th>Remediadas</th><th>Nuevas</th><th>Por</th></tr></thead><tbody>
{% for s in scans|reverse %}
<tr><td>{{ s.ts_fmt }}</td><td><code>{{ s.mode|upper }}</code></td>
<td><b>{{ s.total }}</b></td>
<td>{{ s.counts.critical or 0 }}</td><td>{{ s.counts.high or 0 }}</td>
<td>{% if s.remediated_count %}<span class="delta-pos">−{{ s.remediated_count }}</span>{% else %}0{% endif %}</td>
<td>{% if s.introduced_count %}<span class="delta-neg">+{{ s.introduced_count }}</span>{% else %}0{% endif %}</td>
<td>{{ s.actor or '—' }}</td></tr>
{% endfor %}
</tbody></table>{% endif %}</div>

<div class="panel"><h2>Bitácora de remediación</h2>
{% if not actions %}<div class="empty">Aún no hay acciones de remediación registradas.</div>{% else %}
<table><thead><tr><th>Cuándo</th><th>Estado</th><th>Severidad</th><th>Hallazgo</th><th>Ubicación</th><th>Por</th><th>Nota</th></tr></thead><tbody>
{% for a in actions|reverse %}
<tr><td>{{ a.ts_fmt }}</td>
<td><span class="badge {{ 'manual' if a.source=='manual' else 'remediated' }}">{{ status_es.get(a.status, a.status) }}</span></td>
<td>{% if a.severity %}<span class="sev {{ a.severity }}">{{ sev_es.get(a.severity, a.severity) }}</span>{% else %}—{% endif %}</td>
<td>{{ a.title or '—' }}</td><td class="mono"><code>{{ a.where or '—' }}</code></td>
<td>{{ a.actor or '—' }}</td><td>{{ a.note or '' }}</td></tr>
{% endfor %}
</tbody></table>{% endif %}</div>

<footer>Escáner de vulnerabilidades · Historial de remediación · {{ now }}</footer>
</div></body></html>"""


def render_remediation_history(reports_root, out_path=None) -> Path:
    hist = load_history(reports_root)
    scans, actions = hist["scans"], hist["actions"]
    for x in scans + actions:
        x["ts_fmt"] = _fmt_ts(x.get("ts"))
    vw, vh = 900, 240
    pts = [s.get("total", 0) for s in scans]
    dots = []
    if len(pts) > 1:
        lo, span = min(pts), (max(pts) - min(pts)) or 1
        n = len(pts) - 1
        dots = [(round(40 + (vw - 50) * i / n, 1), round(vh - 26 - (vh - 50) * (v - lo) / span, 1), v,
                 _short_date(scans[i].get("ts"))) for i, v in enumerate(pts)]
    return _render(_HISTORY_TEMPLATE, out_path or Path(reports_root) / "remediation_history.html", now=now_human(),
                   scans=scans, actions=actions, status_es=STATUS_ES,
                   total_remediated=sum(s.get("remediated_count", 0) for s in scans),
                   total_introduced=sum(s.get("introduced_count", 0) for s in scans),
                   latest_total=pts[-1] if pts else 0,
                   manual_actions=sum(a.get("source") == "manual" for a in actions), points=pts,
                   polyline=" ".join(f"{x},{y}" for x, y, _, _ in dots), dots=dots, vw=vw, vh=vh)


def _short_date(value) -> str:
    s = _fmt_ts(value)
    return s[5:10] if len(s) >= 10 else s


def _read_meta(d: Path) -> dict:
    return read_json(d / "meta.json") or {}


def _tickets(meta) -> str:
    return ", ".join(t["number"] for t in meta.get("servicenow_tickets") or [] if isinstance(t, dict) and t.get("number")) or "—"


def _report_dirs(root: Path) -> list[Path]:
    try:
        return sorted((p for p in root.iterdir() if p.is_dir() and p.name.startswith("report_")),
                      key=lambda p: p.stat().st_mtime, reverse=True)
    except OSError:
        return []


def _matches(vals, text: str) -> bool:
    return not text.strip() or text.lower().strip() in " ".join(map(str, vals)).lower()


class _ReportsTabMixin:
    def _build_tab_reports(self, parent):
        pad = self._scrollable(parent)
        bar = tk.Frame(pad, bg=T["bg"])
        bar.pack(fill="x", pady=(0, CARD_GAP))
        self._btn(bar, "📋 Reportes", self._open_reports_viewer).pack(side="left")
        self._btn(bar, "🌐 Abrir HTML", self._open_selected_html_report).pack(side="left", padx=(2, 0))
        self._btn(bar, "🩹 Remediación", self._open_remediation_history).pack(side="left", padx=(2, 0))
        auto = tk.BooleanVar(value=self._auto_open)
        ToggleSwitch(bar, text="Abrir reporte automáticamente", variable=auto, bg=T["bg"],
                     command=lambda: (setattr(self, "_auto_open", auto.get()), self._save_settings())
                     ).pack(side="left", padx=(4, 0))
        fr = tk.Frame(self._card(pad, "Carpeta"), bg=T["panel_bg"])
        fr.pack(fill="x")
        self._icon_btn(fr, "📂", self._browse_reports).pack(side="left", padx=(0, 2))
        ttk.Entry(fr, textvariable=self._reports_var).pack(side="left", fill="x", expand=True)
        card = self._card(pad, "Escaneos", pady=(0, 0))
        row = tk.Frame(card, bg=T["panel_bg"])
        row.pack(fill="x", pady=(0, 2))
        tk.Label(row, text="🔎", font=(FUI, 12), bg=T["panel_bg"], fg=T["card_fg"]).pack(side="left")
        self._rep_filter_var = tk.StringVar()
        ttk.Entry(row, textvariable=self._rep_filter_var, width=36).pack(side="left", padx=(2, 0))
        self._rep_filter_var.trace_add("write", lambda *_: self._refresh_rep_tree())
        box = tk.Frame(card, bg=T["panel_bg"])
        box.pack(fill="both", expand=True)
        self._rep_tree = make_tree(box, ("del", "folder", "when", "mode", "altas", "target", "ticket"),
                                   [("", 24, "center", False), ("", 24, "center", False), ("Generado", 150),
                                    ("Modo", 80), ("Altas/Críticas", 110), ("Objetivo", 300),
                                    ("Ticket ServiceNow", 140)], 6)
        self._rep_tree.tag_configure("altas_si", foreground=T["err"])
        self._rep_tree.bind("<Double-1>", lambda _e: self._open_selected_html_report(quiet=True))
        self._rep_tree.bind("<Button-1>", self._on_rep_tree_click)
        self._refresh_rep_tree()

    def _browse_reports(self):
        with dialog_guard(self):
            d = filedialog.askdirectory(title="Seleccionar carpeta de reportes", initialdir=self._reports_var.get() or APP_DIR)
        if d:
            self._reports_var.set(d)
            self._reports_root = Path(d)
            self._save_settings()

    def _refresh_rep_tree(self):
        tree = getattr(self, "_rep_tree", None)
        if tree is None or not tree.winfo_exists():
            return
        clear_tree(tree)
        app = self._active_app
        root = Path(self._reports_var.get()) / (slug(app["name"]) if app and app.get("name") else "_unscoped")
        for d in _report_dirs(root)[:50]:
            meta = _read_meta(d)
            c = meta.get("counts") or {}
            alta = bool(c.get("critical") or c.get("high"))
            tgt = (app.get("target_path") if app else "") or meta.get("target", "")
            vals = ("🗑", "📁", meta.get("generated_at") or d.name[7:], meta.get("mode", "?"), "Sí" if alta else "No",
                    Path(tgt).name if tgt else "", _tickets(meta))
            if _matches(vals, self._rep_filter_var.get()):
                tree.insert("", "end", iid=str(d), values=vals, tags=(stripe(tree),) + (("altas_si",) if alta else ()))

    def _restore_last_report(self) -> None:
        """Al cargar/cambiar de aplicación, apunta «Abrir último reporte» al HTML más reciente de esa aplicación
        (o de «_unscoped» si no hay aplicación activa)."""
        try:
            app = self._active_app
            root = Path(self._reports_var.get()) / (slug(app["name"]) if app and app.get("name") else "_unscoped")
            html = next((h for d in _report_dirs(root) if (h := find_report_html(d))), None)
        except Exception as e:
            html = None
            if callable(log := getattr(self, "_emit_log", None)):
                log(f"[reporte] no se pudo localizar el último reporte: {e!r}")
        self._last_report = self._last_static_report = Path(html) if html else None
        if callable(fn := getattr(self, "_refresh_summary", None)):
            try:
                fn()
            except Exception:
                pass

    def _open_selected_html_report(self, quiet: bool = False):
        sel = self._rep_tree.selection()
        if not sel:
            return quiet or self._show_warn_popup("Abrir HTML", "Seleccione un reporte en la lista primero.")
        if html := find_report_html(sel[0]):
            open_path(html)
        elif not quiet:
            self._show_warn_popup("Abrir HTML", f"Sin archivo HTML en:\n{sel[0]}")

    def _trash_report(self, path, *after):
        try:
            trash_path(Path(path), self._emit_log)
        except Exception as e:
            return self._show_error_popup("Eliminar", f"No se pudo eliminar:\n{e}")
        for fn in after:
            fn()

    def _on_rep_tree_click(self, e) -> None:
        t = self._rep_tree
        row = t.identify_row(e.y)
        if t.identify_region(e.x, e.y) != "cell" or not row:
            return
        col = t.identify_column(e.x)
        if col == "#1":
            self._trash_report(row, self._refresh_rep_tree)
        elif col == "#2":
            open_path(row)

    def _open_remediation_history(self):
        root = Path(self._reports_var.get()).resolve()
        try:
            h = load_history(root)
            if not h["scans"] and not h["actions"]:
                return self._show_info_popup("Historial de remediación", "Sin historial aún, ejecute un escaneo primero.")
            out = render_remediation_history(root)
            self._log_line(f"[historial] {out}")
            open_path(out)
        except Exception as e:
            self._show_error_popup("Historial de remediación", f"No se pudo generar:\n{e!r}")

    def _open_reports_viewer(self):
        root = Path(self._reports_var.get()).resolve()
        popup = self._popup("Historial de reportes")
        hdr = self._popup_hdr(popup, "Historial de reportes", subtitle=str(root), icon="📋")
        row = tk.Frame(hdr, bg=T["panel_bg"])
        row.pack(fill="x", pady=(2, 0))
        tk.Label(row, text="🔎", font=(FUI, 10), bg=T["panel_bg"], fg=T["muted"]).pack(side="left")
        filt = tk.StringVar()
        ttk.Entry(row, textvariable=filt, width=40).pack(side="left", padx=(2, 0))
        tk.Label(row, text="filtrar por aplicación, modo u objetivo", font=(FUI, 10), bg=T["panel_bg"],
                 fg=T["muted"]).pack(side="left", padx=(2, 0))
        wrap = tk.Frame(popup, bg=T["bg"])
        wrap.pack(fill="both", expand=True, padx=4, pady=(4, 2))
        tree = make_tree(wrap, ("app", "when", "mode", "total", "critical", "high", "medium", "low", "target", "ticket"),
                         [("Aplicación", 130), ("Generado", 150), ("Modo", 80), ("Total", 55), ("Crít", 45),
                          ("Alta", 45), ("Media", 45), ("Baja", 45), ("Objetivo", 300), ("Ticket ServiceNow", 140)], 12)

        def scan_dirs():
            found = []
            try:
                entries = sorted(root.iterdir())
            except OSError:
                entries = []
            for entry in entries:
                if not entry.is_dir():
                    continue
                if entry.name.startswith("report_"):
                    found.append((entry, "—"))
                else:
                    found += [(d, "(ninguna)" if entry.name == "_unscoped" else entry.name) for d in _report_dirs(entry)]
            return sorted(found, key=lambda t: t[0].stat().st_mtime, reverse=True)

        def refresh(*_):
            clear_tree(tree)
            for d, app in scan_dirs():
                m = _read_meta(d)
                c = m.get("counts") or {}
                vals = (app, m.get("generated_at") or d.name[7:], m.get("mode", "?"), m.get("total", "?"),
                        *(c.get(k, "?") for k in ("critical", "high", "medium", "low")), m.get("target", ""), _tickets(m))
                if _matches(vals, filt.get()):
                    tree.insert("", "end", iid=str(d), values=vals, tags=(stripe(tree),))

        def sel():
            s = tree.selection()
            return Path(s[0]) if s else None

        def open_html():
            if d := sel():
                if html := find_report_html(d):
                    open_path(html)
                else:
                    self._show_warn_popup("Abrir HTML", f"No hay reporte HTML en:\n{d}")

        def export_csv_():
            if not (d := sel()):
                return
            src = next(iter(sorted(d.glob("*.zip"))), None) or next(iter(sorted(d.glob("*.csv"))), None)
            if not src:
                return self._show_warn_popup("Exportar CSV", f"No hay exportación CSV/ZIP en:\n{d}")
            with dialog_guard(popup._win):
                path = filedialog.asksaveasfilename(title="Exportar CSV", defaultextension=src.suffix, initialdir=str(d),
                                                    initialfile=src.name, filetypes=[("Paquete ZIP", "*.zip"),
                                                                                     ("CSV", "*.csv"), ("Todos", "*.*")])
            if path:
                shutil.copyfile(src, path)
                self._show_info_popup("Exportar CSV", f"Guardado en {path}")

        def export_sarif_():
            from static_scanner import export_merged_json, export_sarif
            if not (d := sel()):
                return
            if not any((d / n).exists() for n in ("snyk_test.json", "snyk_code.json", "dast.json", "api.json")):
                return self._show_warn_popup("Exportar SARIF", f"No hay resultados crudos del escaneo en:\n{d}")
            try:
                sarif = export_sarif(d)
                export_merged_json(d)
            except Exception as e:
                return self._show_error_popup("Exportar SARIF", f"Falló:\n{e}")
            if not sarif:
                return self._show_warn_popup("Exportar SARIF", "Nada que exportar — no se reunieron hallazgos.")
            with dialog_guard(popup._win):
                path = filedialog.asksaveasfilename(title="Exportar SARIF", defaultextension=".sarif", initialdir=str(d),
                                                    initialfile="findings.sarif",
                                                    filetypes=[("SARIF", "*.sarif *.json"), ("Todos", "*.*")])
            if not path:
                return self._show_info_popup("Exportar SARIF", f"SARIF guardado en la carpeta del reporte:\n{sarif}")
            try:
                shutil.copyfile(sarif, path)
                self._show_info_popup("Exportar SARIF", f"Guardado en {path}")
            except Exception as e:
                self._show_error_popup("Exportar SARIF", f"No se pudo copiar:\n{e}")

        def open_folder():
            if d := sel():
                open_path(d)
            else:
                self._show_info_popup("Abrir carpeta", "Seleccione un reporte primero.")

        filt.trace_add("write", refresh)
        tree.bind("<Double-1>", lambda _e: open_html())
        self._popup_foot(popup, ("✕  Cerrar", popup.close), ("▶ Abrir HTML", open_html),
                         ("📁 Abrir carpeta", open_folder), ("💾 Exportar CSV…", export_csv_),
                         ("🧬 Exportar SARIF…", export_sarif_),
                         ("🗑 Eliminar", lambda: (d := sel()) and self._trash_report(d, refresh, self._refresh_rep_tree)))
        refresh()
