#!/usr/bin/env python3
from __future__ import annotations

import argparse
import base64
import copy
import csv
import ctypes
import getpass
import json
import os
import sys
from datetime import datetime
from typing import Optional

import requests

IS_WIN = os.name == "nt"
BASE_URL = os.environ.get("SNOW_BASE_URL", "https://bancobasedev.service-now.com")
SYS_ID = os.environ.get("SNOW_CATALOG_SYS_ID", "799044769396c750af38b6ea6aba1080")
ORDER_URL = f"{BASE_URL}/api/sn_sc/servicecatalog/items/{SYS_ID}/order_now"
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_FILE = os.environ.get("SNOW_TEST_LOG") or os.path.join(SCRIPT_DIR, "servicenow_test_log.csv")
APP_DATA_DIR = os.environ.get("SNOW_APP_DATA_DIR") or os.path.join(os.path.expanduser("~"), ".servicenow_ticket_tester")
try:
    os.makedirs(APP_DATA_DIR, exist_ok=True)
except OSError:
    pass
CANCEL_TABLE = os.environ.get("SNOW_CANCEL_TABLE", "sc_request")
CANCEL_STATE_FIELD = os.environ.get("SNOW_CANCEL_STATE_FIELD", "state")
CANCEL_STATE_VALUE = os.environ.get("SNOW_CANCEL_STATE", "Closed Cancelled")
RITM_TABLE = os.environ.get("SNOW_RITM_TABLE", "sc_req_item")
RESOLVE_STATE_FIELD = os.environ.get("SNOW_RESOLVE_STATE_FIELD", "state")
RESOLVE_STATE_VALUE = os.environ.get("SNOW_RESOLVE_STATE_VALUE", "Closed Complete")
COMMENT_FIELD = os.environ.get("SNOW_COMMENT_FIELD", "work_notes")
CREDENTIALS_FILE = os.environ.get("SNOW_CREDENTIALS_FILE") or os.path.join(APP_DATA_DIR, "credentials.json")
DEFAULT_APP_NAME = os.environ.get("SNOW_APP_NAME", "Portal-Clientes")
DEFAULT_DESCRIPTION = os.environ.get("SNOW_DESCRIPCION",
                                     "Solicitud de escaneo de seguridad conforme al calendario de revisiones periódicas.")
BASE_FIELDS = {
    "id_del_solicitante": "ysantos",
    "nombre_del_solicitante": "Yessica de los Angeles Santos Sifuentes",
    "correo_del_solicitante": "ysantos@bancobase.com",
    "objetivo_de_la_solicitud": "Obtener solicitudes de escaneo y limpieza de falsos positivos",
    "nombre_de_la_aplicaci_n": DEFAULT_APP_NAME,
    "ambiente": "Desarrollo",
    "modo_ejecucion": "Baseline",
    "clasificaci_n_de_la_aplicaci_n": "MDP",
    "prioridad_": "Media",
    "owner_de_la_aplicaci_n2": "URL de la API",
    "descripci_n_de_la_solicitud_justificaci_n": DEFAULT_DESCRIPTION,
    "cuentas_con_url": "URL de la API",
}
SERVICES = {
    "sast_sca": {"field": "sast_sca", "extra": {"organizaci_n_en_snyk": "TEST-ORG"}},
    "dast": {"field": "dast", "extra": {"organizaci_n_en_snyk": "TEST-ORG", "requiere_triage": "No",
                                        "url_objetivo": "https://test.bancobase.com", "urls_a_excluir": "[]",
                                        "usar_cuenta_de_servicio_del_equipo": "Si"}},
    "api": {"field": "api", "extra": {"organizaci_n_en_snyk": "TEST-ORG", "tecnologia_api": "REST",
                                      "usar_cuenta_de_servicio_del_equipo": "Si",
                                      "url_de_la_api": "https://test.bancobase.com/api"}},
    "secretos": {"field": "escaneo_de_secretos", "extra": {"repositorio_s": "[{\"name\": \"test-repo\"}]",
                                                           "ruta_monorepo": "/",
                                                           "usar_cuenta_de_servicio_del_equipo": "Si"}},
    "triage": {"field": "triage", "extra": {}},
}
CRYPTPROTECT_UI_FORBIDDEN = 0x1


def build_payload(selected_services: list[str], ambiente: Optional[str] = None, app_name: Optional[str] = None,
                  descripcion: Optional[str] = None, overrides: Optional[dict] = None) -> dict:
    if not selected_services:
        raise ValueError("Debes seleccionar al menos un servicio")
    if unknown := [s for s in selected_services if s not in SERVICES]:
        raise ValueError(f"Servicio(s) desconocido(s): {', '.join(unknown)}")
    fields = copy.deepcopy(BASE_FIELDS)
    for key, val in (("nombre_de_la_aplicaci_n", app_name), ("descripci_n_de_la_solicitud_justificaci_n", descripcion),
                     ("ambiente", ambiente)):
        if val:
            fields[key] = val
    for name, spec in SERVICES.items():
        fields[spec["field"]] = "true" if name in selected_services else "false"
    for name in selected_services:
        fields.update(SERVICES[name]["extra"])
    fields.update(overrides or {})
    return {"sysparm_quantity": "1", "variables": fields}


class _DATA_BLOB(ctypes.Structure):
    _fields_ = [("cbData", ctypes.c_uint32), ("pbData", ctypes.POINTER(ctypes.c_char))]


def _dpapi(fn_name: str, data: bytes) -> Optional[bytes]:
    if not IS_WIN:
        return None
    try:
        buf = ctypes.create_string_buffer(data, len(data))
        blob_in, blob_out = _DATA_BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char))), _DATA_BLOB()
        if not getattr(ctypes.windll.crypt32, fn_name)(ctypes.byref(blob_in), None, None, None, None,
                                                       CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(blob_out)):
            return None
        try:
            return ctypes.string_at(blob_out.pbData, blob_out.cbData)
        finally:
            ctypes.windll.kernel32.LocalFree(blob_out.pbData)
    except Exception:
        return None


def _dpapi_protect(data: bytes) -> Optional[bytes]:
    return _dpapi("CryptProtectData", data)


def _dpapi_unprotect(data: bytes) -> Optional[bytes]:
    return _dpapi("CryptUnprotectData", data)


def _encrypt_secret(plain: str) -> Optional[str]:
    enc = _dpapi_protect(plain.encode("utf-8")) if plain else None
    return base64.b64encode(enc).decode("ascii") if enc is not None else None


def _decrypt_secret(blob_b64: str) -> str:
    try:
        dec = _dpapi_unprotect(base64.b64decode(blob_b64)) if blob_b64 else None
        return dec.decode("utf-8") if dec is not None else ""
    except Exception:
        return ""


def load_saved_credentials() -> dict:
    try:
        with open(CREDENTIALS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return {}
    if data.get("encrypted"):
        return {"user": data.get("user", ""), "password": _decrypt_secret(data.get("password_enc", "")),
                "token": _decrypt_secret(data.get("token_enc", ""))}
    creds = {k: data.get(k, "") for k in ("user", "password", "token")}
    if creds["password"] or creds["token"]:
        try:
            save_credentials(**creds)
        except Exception:
            pass
    return creds


def save_credentials(user: str = "", password: str = "", token: str = "") -> None:
    payload: dict = {"user": user or "", "encrypted": True}
    for key, val in (("password", password), ("token", token)):
        if val:
            if (enc := _encrypt_secret(val)) is not None:
                payload[f"{key}_enc"] = enc
            else:
                payload[key], payload["encrypted"] = val, False
    if not payload["encrypted"]:
        print(f"[servicenow] el cifrado no está disponible en esta plataforma — {CREDENTIALS_FILE} se guardó en TEXTO PLANO.")
    with open(CREDENTIALS_FILE, "w", encoding="utf-8") as f:
        json.dump(payload, f)
    try:
        os.chmod(CREDENTIALS_FILE, 0o600)
    except OSError:
        pass


def clear_saved_credentials() -> None:
    try:
        os.remove(CREDENTIALS_FILE)
    except FileNotFoundError:
        pass


def _resolve_auth(interactive: bool):
    token = os.environ.get("SNOW_TOKEN")
    saved = load_saved_credentials()
    token = token or saved.get("token")
    if token:
        return None, {"Authorization": f"Bearer {token}"}
    user = os.environ.get("SNOW_USER") or saved.get("user")
    password = os.environ.get("SNOW_PASS") or saved.get("password")
    if interactive:
        user = user or input("Usuario ServiceNow: ")
        password = password or getpass.getpass("Password ServiceNow: ")
    return ((user, password), {}) if user and password else None


def get_auth():
    return _resolve_auth(True)


def get_auth_silent() -> Optional[tuple]:
    return _resolve_auth(False)


def remember_auth(auth, extra_headers: dict) -> None:
    hdr = extra_headers.get("Authorization", "")
    user, password = auth if auth else ("", "")
    save_credentials(user=user or "", password=password or "", token=hdr[7:] if hdr.startswith("Bearer ") else "")


def _headers(extra_headers: dict, json_body: bool = True) -> dict:
    return {"Accept": "application/json", **({"Content-Type": "application/json"} if json_body else {}), **extra_headers}


def _get_rows(url: str, auth, extra_headers: dict, what: str, log) -> Optional[list]:
    try:
        resp = requests.get(url, auth=auth, headers=_headers(extra_headers, False), timeout=30)
    except requests.RequestException as exc:
        log(f"ERROR de red al {what}: {exc}")
        return None
    if resp.status_code != 200:
        log(f"No se pudo {what} ({resp.status_code}): {resp.text[:1000]}")
        return None
    try:
        return resp.json().get("result", [])
    except ValueError:
        log(f"Respuesta no es JSON válido al {what}.")
        return None


def _raw(field):
    return field.get("value", "") if isinstance(field, dict) else (field or "")


def _readable(field):
    return field.get("display_value", "") if isinstance(field, dict) else (field or "")


def send_request(scenario_name: str, payload: dict, auth, extra_headers: dict, dry_run: bool, log=print) -> dict:
    row = {"scenario": scenario_name, "status": "dry-run", "sys_id": "", "request_number": "", "error": ""}
    if dry_run:
        log(f"--- [DRY RUN] {scenario_name} ---")
        log(json.dumps(payload, indent=2, ensure_ascii=False))
        return row
    try:
        resp = requests.post(ORDER_URL, auth=auth, headers=_headers(extra_headers), json=payload, timeout=30)
    except requests.RequestException as exc:
        log(f"[{scenario_name}] ERROR de red: {exc}")
        return {**row, "status": "network_error", "error": str(exc)}
    row["status"] = resp.status_code
    if resp.status_code in (200, 201):
        try:
            result = resp.json().get("result", {})
            row["request_number"] = result.get("request_number", "")
            row["sys_id"] = result.get("sys_id", "") or result.get("request_id", "")
            log(f"[{scenario_name}] OK ({resp.status_code}) -> request_number: {row['request_number']}")
        except (ValueError, KeyError, AttributeError) as exc:
            row["error"] = f"Respuesta OK pero no se pudo interpretar: {exc}"
            log(f"[{scenario_name}] OK ({resp.status_code}) pero respuesta inesperada:\n{resp.text[:500]}")
    else:
        row["error"] = resp.text[:1000]
        log(f"[{scenario_name}] FALLÓ ({resp.status_code}):\n{resp.text[:1000]}")
        if "mandatory" in resp.text.lower():
            log(f"[{scenario_name}] Diagnosticando variables obligatorias faltantes...")
            if missing := diagnose_missing_variables(payload, auth, extra_headers, log=log):
                row["error"] += f" | Variables obligatorias faltantes: {', '.join(missing)}"
    return row


def cancel_request(sys_id: str, auth, extra_headers: dict, log=print) -> dict:
    if not sys_id:
        return {"cancelled": False, "cleanup_error": "sin sys_id (no se puede cancelar)"}
    try:
        resp = requests.patch(f"{BASE_URL}/api/now/table/{CANCEL_TABLE}/{sys_id}", auth=auth,
                              headers=_headers(extra_headers), timeout=30,
                              json={CANCEL_STATE_FIELD: CANCEL_STATE_VALUE, "close_notes":
                                    "Cancelado automáticamente por test_servicenow_ticket.py (ticket de prueba)"})
    except requests.RequestException as exc:
        log(f"  cleanup {sys_id}: ERROR de red: {exc}")
        return {"cancelled": False, "cleanup_error": str(exc)}
    if resp.status_code in (200, 201):
        log(f"  cleanup {sys_id}: cancelado OK")
        return {"cancelled": True, "cleanup_error": ""}
    log(f"  cleanup {sys_id}: FALLÓ ({resp.status_code}): {resp.text[:300]}")
    return {"cancelled": False, "cleanup_error": f"{resp.status_code}: {resp.text[:300]}"}


def update_record(table: str, sys_id: str, fields: dict, auth, extra_headers: dict, log=print) -> bool:
    if not sys_id:
        log("  update_record: sin sys_id, se omite")
        return False
    try:
        resp = requests.patch(f"{BASE_URL}/api/now/table/{table}/{sys_id}", auth=auth, headers=_headers(extra_headers),
                              json=fields, timeout=30)
    except requests.RequestException as exc:
        log(f"  update_record {table}/{sys_id}: ERROR de red: {exc}")
        return False
    if resp.status_code in (200, 201):
        return True
    log(f"  update_record {table}/{sys_id}: FALLÓ ({resp.status_code}): {resp.text[:300]}")
    return False


def find_ritm_for_request(request_sys_id: str, auth, extra_headers: dict, log=print) -> dict:
    if not request_sys_id:
        return {}
    rows = _get_rows(f"{BASE_URL}/api/now/table/sc_req_item?sysparm_query=request={request_sys_id}"
                     "&sysparm_fields=sys_id,number,state&sysparm_display_value=all&sysparm_limit=5",
                     auth, extra_headers, "buscar el RITM", lambda m: log(f"  {m}"))
    return {"ritm_sys_id": _raw(rows[0].get("sys_id")), "ritm_number": _raw(rows[0].get("number"))} if rows else {}


def ritm_url(ritm_sys_id: str) -> str:
    return f"{BASE_URL}/nav_to.do?uri=sc_req_item.do?sys_id={ritm_sys_id}" if ritm_sys_id else ""


def list_variables(auth, extra_headers: dict, mandatory_only: bool = True, log=print) -> list[dict]:
    query = f"cat_item={SYS_ID}" + ("^mandatory=true" if mandatory_only else "")
    rows = _get_rows(f"{BASE_URL}/api/now/table/item_option_new?sysparm_query={query}^ORDERBYorder"
                     "&sysparm_fields=name,question_text,mandatory,active,order,type&sysparm_display_value=true"
                     "&sysparm_limit=200", auth, extra_headers, "listar variables", log)
    if rows is None:
        return []
    if not rows:
        log("(sin resultados — revisa que SNOW_CATALOG_SYS_ID sea correcto, o que tu usuario tenga permiso de lectura "
            "sobre item_option_new)")
        return rows
    log(f"Variables {'obligatorias' if mandatory_only else 'todas las'} del catalog item ({len(rows)}):")
    for r in rows:
        flag = "OBLIGATORIA" if str(r.get("mandatory")).lower() == "true" else "opcional"
        active = "" if str(r.get("active", "true")).lower() == "true" else " [INACTIVA]"
        log(f"  [{flag}]{active} {r.get('name')}  (tipo: {r.get('type', '')})  —  {r.get('question_text')}")
    return rows


def diagnose_missing_variables(payload: dict, auth, extra_headers: dict, log=print) -> list[str]:
    mandatory = list_variables(auth, extra_headers, mandatory_only=True, log=lambda *_: None)
    sent = set(payload.get("variables", {}))
    missing = [v.get("name") for v in mandatory if v.get("name") not in sent]
    if missing:
        log("  >>> Variables obligatorias que FALTAN en el payload enviado:")
        for v in (v for v in mandatory if v.get("name") in missing):
            log(f"       - {v.get('name')}  (tipo: {v.get('type', '')})  —  {v.get('question_text', '')}")
    elif mandatory:
        refs = [v for v in mandatory if v.get("name") in sent and any(
            kw in str(v.get("type", "")).lower() for kw in ("reference", "lookup", "list collector"))]
        if refs:
            log("  >>> Todas las variables obligatorias se enviaron, pero estas son de tipo referencia/lookup: si el valor "
                "no existe como registro real en tu instancia, ServiceNow lo trata como vacío y por eso sigue marcando "
                "'mandatory':")
            for v in refs:
                log(f"       - {v.get('name')} = '{payload['variables'].get(v.get('name'))}'  (tipo: {v.get('type')})")
        else:
            log("  >>> Todas las variables marcadas 'obligatorias' sí se enviaron; el rechazo probablemente es por un "
                "VALOR inválido (ej. una opción de choice que no existe en tu instancia), no por un campo faltante.")
    else:
        log("  >>> No se pudo obtener la lista de variables obligatorias para comparar (revisa el mensaje anterior).")
    return missing


def get_variable_detail(auth, extra_headers: dict, name: str, log=print) -> dict:
    rows = _get_rows(f"{BASE_URL}/api/now/table/item_option_new?sysparm_query=cat_item={SYS_ID}^name={name}"
                     "&sysparm_fields=name,question_text,type,mandatory,active,order,help_text,default_value,tooltip"
                     "&sysparm_display_value=true&sysparm_limit=5", auth, extra_headers, f"consultar '{name}'", log)
    if not rows:
        if rows is not None:
            log(f"(no se encontró la variable '{name}' en este catalog item)")
        return {}
    log(f"--- Detalle de '{name}' ---")
    for key in ("name", "question_text", "type", "mandatory", "active", "order", "help_text", "tooltip", "default_value"):
        if val := rows[0].get(key, ""):
            log(f"  {key}: {val}")
    return rows[0]


def list_recent_tickets(auth, extra_headers: dict, limit: int = 25, log=print) -> list[dict]:
    rows = _get_rows(f"{BASE_URL}/api/now/table/sc_req_item?sysparm_query=cat_item={SYS_ID}^ORDERBYDESCsys_created_on"
                     "&sysparm_fields=sys_id,number,state,short_description,sys_created_on,request"
                     f"&sysparm_display_value=all&sysparm_limit={limit}", auth, extra_headers, "listar tickets", log)
    tickets = [{"ritm_sys_id": _raw(r.get("sys_id")), "ritm_number": _raw(r.get("number")),
                "request_sys_id": _raw(r.get("request")), "state": _readable(r.get("state")),
                "short_description": _readable(r.get("short_description"))[:80], "created": _raw(r.get("sys_created_on"))}
               for r in rows or []]
    if rows is not None and not tickets:
        log("(sin tickets encontrados para este catalog item)")
    return tickets


def cleanup_results(results: list[dict], auth, extra_headers: dict, log=print) -> None:
    for row in results:
        if row.get("status") in (200, 201) and row.get("sys_id"):
            c = cancel_request(row["sys_id"], auth, extra_headers, log=log)
            row["cleanup_status"], row["cleanup_error"] = ("cancelado" if c["cancelled"] else "error"), c["cleanup_error"]
        else:
            row["cleanup_status"], row["cleanup_error"] = "n/a", ""


def log_results(rows: list[dict], log_file: str = LOG_FILE) -> None:
    fields = ["timestamp", "scenario", "status", "sys_id", "request_number", "error", "cleanup_status", "cleanup_error"]
    exists = os.path.isfile(log_file)
    with open(log_file, "a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        if not exists:
            w.writeheader()
        for row in rows:
            w.writerow({"timestamp": datetime.now().isoformat(timespec="seconds"), **{k: row.get(k, "") for k in fields[1:]}})
    print(f"\nResultados agregados a {log_file}")


def main():
    p = argparse.ArgumentParser(description="Prueba el template de ticket de ServiceNow.")
    p.add_argument("--service", action="append", metavar="NAME", choices=list(SERVICES),
                   help="Servicio a incluir en el ticket (repetible: --service dast --service api). Si no se especifica, "
                        "se incluyen todos en un solo ticket.")
    p.add_argument("--ambiente", help="Sobrescribe el ambiente (ej. 'Producción' para probar la nota de validación).")
    p.add_argument("--app-name", help=f"Nombre de la aplicación a usar en el ticket (default: '{DEFAULT_APP_NAME}').")
    p.add_argument("--descripcion", help="Descripción/justificación de la solicitud (default: texto genérico de revisión "
                                         "periódica).")
    p.add_argument("--var", action="append", metavar="NAME=VALUE",
                   help="Sobrescribe o agrega una variable del payload (repetible). Úsalo para dar valores REALES de "
                        "organización/repositorio, ej: --var organizaci_n_en_snyk=MiOrgReal")
    p.add_argument("--dry-run", action="store_true", help="Solo imprime el payload, no llama a la API.")
    p.add_argument("--no-cleanup", action="store_true", help="No cancela los tickets de prueba al terminar.")
    p.add_argument("--list", action="store_true", help="Lista las ramas disponibles y sale.")
    p.add_argument("--inspect", action="store_true", help="Consulta a ServiceNow cuáles variables son realmente "
                                                          "obligatorias en el catalog item y sale (no crea tickets).")
    p.add_argument("--inspect-all", action="store_true", help="Como --inspect pero muestra todas las variables, no sólo "
                                                              "las obligatorias.")
    p.add_argument("--inspect-field", metavar="NAME", help="Consulta el detalle completo (tipo, texto de ayuda, valor por "
                                                           "defecto) de una variable específica y sale.")
    p.add_argument("--list-tickets", nargs="?", const=25, type=int, metavar="N",
                   help="Lista los últimos N tickets (RITM) de este catalog item y sale (default 25).")
    p.add_argument("--cancel", nargs="+", metavar="REQ_SYS_ID", help="Cancela el/los REQ indicados por su sys_id (ver "
                                                                     "--list-tickets) y sale.")
    p.add_argument("--remember", action="store_true", help="Guarda las credenciales usadas en este comando (cifradas con "
                                                           "DPAPI para esta cuenta de Windows).")
    p.add_argument("--forget-credentials", action="store_true", help="Borra las credenciales guardadas y sale.")
    p.add_argument("--gui", action="store_true", help="Lanza la interfaz gráfica en vez del CLI.")
    args = p.parse_args()
    if args.forget_credentials:
        clear_saved_credentials()
        return print("Credenciales guardadas eliminadas.")
    if args.gui:
        import gui_servicenow_tester
        return gui_servicenow_tester.launch()
    if args.list:
        return print("Servicios disponibles:", ", ".join(SERVICES))
    needs_auth = args.inspect or args.inspect_all or args.inspect_field or args.list_tickets is not None or args.cancel \
        or not args.dry_run
    auth, extra = get_auth() if needs_auth else (None, {})
    if args.remember and needs_auth:
        remember_auth(auth, extra)
    if args.inspect or args.inspect_all:
        return list_variables(auth, extra, mandatory_only=not args.inspect_all) and None
    if args.inspect_field:
        return get_variable_detail(auth, extra, args.inspect_field) and None
    if args.list_tickets is not None:
        for t in list_recent_tickets(auth, extra, limit=args.list_tickets):
            print(f"{t['ritm_number']:<14} {t['state']:<22} {t['created']:<20} {t['short_description']:<40} "
                  f"REQ sys_id: {t['request_sys_id']}")
        return
    if args.cancel:
        for sys_id in args.cancel:
            cancel_request(sys_id, auth, extra)
        return
    services = args.service or list(SERVICES)
    overrides = {}
    for kv in args.var or []:
        if "=" not in kv:
            print(f"Ignorando --var mal formado (usa NAME=VALUE): {kv}")
            continue
        k, v = kv.split("=", 1)
        overrides[k] = v
    payload = build_payload(services, ambiente=args.ambiente, app_name=args.app_name, descripcion=args.descripcion,
                            overrides=overrides)
    results = [send_request("+".join(services), payload, auth, extra, args.dry_run)]
    if args.dry_run:
        return print("\n(dry-run: nada se envió ni se guardó en el log)")
    if args.no_cleanup:
        for row in results:
            row["cleanup_status"], row["cleanup_error"] = "omitido", ""
    else:
        print("\nLimpiando tickets de prueba...")
        cleanup_results(results, auth, extra)
    log_results(results)


if __name__ == "__main__":
    sys.exit(main())
