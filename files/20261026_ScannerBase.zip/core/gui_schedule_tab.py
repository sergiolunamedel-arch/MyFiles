from __future__ import annotations

import sys
import uuid
from datetime import timedelta

from ui_common import *
import scheduler_os

WEEKDAYS = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]
POLL_MS = 30_000
OS_INTERVAL_MIN = 5


def _hhmm(s: str) -> tuple[int, int]:
    try:
        hh, mm = (s or "00:00").split(":")
        return max(0, min(23, int(hh))), max(0, min(59, int(mm)))
    except Exception:
        return 0, 0


def _fmt(iso) -> str:
    try:
        return datetime.fromisoformat(iso).strftime("%Y-%m-%d %H:%M") if iso else "—"
    except Exception:
        return iso


def next_run(s: dict, base: datetime) -> datetime:
    rec = s.get("recurrence", "daily")
    if rec == "interval":
        return base + timedelta(minutes=max(5, int(s.get("interval_minutes") or 60)))
    hh, mm = _hhmm(s.get("time_of_day"))
    cand = base.replace(hour=hh, minute=mm, second=0, microsecond=0)
    if rec == "weekly":
        cand += timedelta(days=(int(s.get("weekday", 0)) % 7 - cand.weekday()) % 7)
    while cand <= base:
        cand += timedelta(days=7 if rec == "weekly" else 1)
    return cand


def is_due(s: dict) -> bool:
    try:
        return bool(s.get("next_run_at")) and datetime.fromisoformat(s["next_run_at"]) <= datetime.now()
    except Exception:
        return True


def mark_run(store, s: dict, ok: bool) -> None:
    now = datetime.now()
    s.update(last_run_at=now.isoformat(timespec="seconds"), last_run_status="ok" if ok else "error",
             next_run_at=next_run(s, now).isoformat(timespec="seconds"))
    store.save_schedule(s)


def describe(s: dict) -> str:
    if s.get("recurrence") == "interval":
        m = int(s.get("interval_minutes") or 60)
        return f"cada {m // 1440} día(s)" if m % 1440 == 0 else f"cada {m // 60} hora(s)" if m % 60 == 0 else f"cada {m} min"
    hh, mm = _hhmm(s.get("time_of_day"))
    return (f"{WEEKDAYS[int(s.get('weekday', 0)) % 7]} " if s.get("recurrence") == "weekly" else "diario ") + f"{hh:02d}:{mm:02d}"


class ScheduleStore:
    def __init__(self, reports_root: Path):
        self._lock = threading.Lock()
        self.dir = Path(reports_root) / "schedules"
        self.dir.mkdir(parents=True, exist_ok=True)
        self._index = self.dir / "_index.json"
        self._prefs = self.dir / "_stage_prefs.json"

    def _ids(self) -> list[str]:
        ids = read_json(self._index)
        if not isinstance(ids, list):
            ids = sorted(p.stem for p in self.dir.glob("*.json") if not p.name.startswith("_"))
            write_json(self._index, ids)
        return ids

    def list_schedules(self) -> list[dict]:
        with self._lock:
            return [s for s in (read_json(self.dir / f"{i}.json") for i in self._ids()) if isinstance(s, dict)]

    def get_schedule(self, sid: str) -> Optional[dict]:
        with self._lock:
            s = read_json(self.dir / f"{sid}.json")
            return s if isinstance(s, dict) else None

    def save_schedule(self, s: dict) -> None:
        with self._lock:
            s["id"] = s.get("id") or f"sched_{uuid.uuid4().hex[:10]}"
            if s["id"] not in (ids := self._ids()):
                write_json(self._index, ids + [s["id"]])
            s["updated_at"] = datetime.now().isoformat(timespec="seconds")
            s["created_at"] = s.get("created_at") or s["updated_at"]
            write_json(self.dir / f"{s['id']}.json", s)

    def delete_schedule(self, sid: str) -> None:
        with self._lock:
            write_json(self._index, [i for i in self._ids() if i != sid])
            (self.dir / f"{sid}.json").unlink(missing_ok=True)

    def get_stage_prefs(self, app_id: str):
        with self._lock:
            return (read_json(self._prefs) or {}).get(app_id) if app_id else None

    def save_stage_prefs(self, app_id: str, stages: list[str]) -> None:
        if app_id:
            with self._lock:
                write_json(self._prefs, {**(read_json(self._prefs) or {}), app_id: list(stages)})


class _ScheduleTabMixin:
    def _init_schedule(self):
        self._sched_store = ScheduleStore(Path(self._reports_var.get()).resolve())
        self._sched_pending: set[str] = set()
        if not self._headless:
            self.after(POLL_MS, self._schedule_tick)

    def _build_tab_schedule(self, parent):
        pad = self._scrollable(parent)
        bar = tk.Frame(pad, bg=T["bg"])
        bar.pack(fill="x", pady=(0, CARD_GAP))
        PillButton(bar, "Nuevo horario", lambda: self._sched_editor(None), icon="add", variant="primary").pack(side="left")
        tk.Frame(bar, bg=T["border"], width=1).pack(side="left", fill="y", padx=px(12), pady=px(4))
        for text, icon, cmd in (("Ejecutar ahora", "play", self._sched_run_now),
                                ("Editar", "edit", lambda: (s := self._sched_selected()) and self._sched_editor(s)),
                                ("Activar / pausar", "power", self._sched_toggle)):
            PillButton(bar, text, cmd, icon=icon).pack(side="left", padx=(0, px(6)))
        PillButton(bar, "", self._sched_delete, icon="delete", variant="danger_ghost", tooltip="Eliminar horario").pack(
            side="left")
        self._sched_engine_lbl = self._lbl(bar, "", size=10, fg=T["muted"], bg=T["bg"])
        self._sched_engine_lbl.pack(side="right")
        card = self._card(pad, "Horarios", collapsible=False)
        self._sched_tree = make_tree(card, ("app", "stages", "recur", "next", "last", "status", "enabled"), [
            ("Aplicación", 200, "w", True), ("Etapas", 200, "w", True), ("Recurrencia", 130, "w", False),
            ("Próxima ejecución", 140, "w", False), ("Última ejecución", 140, "w", False), ("Resultado", 90, "w", False),
            ("Activo", 70, "center", False)], 12)
        self._sched_tree.bind("<Double-1>", lambda _e: (s := self._sched_selected()) and self._sched_editor(s))
        self._sched_tree.bind("<Delete>", lambda _e: self._sched_delete())
        card = self._card(pad, "Con la aplicación cerrada", collapsible=False)
        row = tk.Frame(card, bg=T["panel_bg"])
        row.pack(fill="x")
        col = tk.Frame(row, bg=T["panel_bg"])
        col.pack(side="left", fill="both", expand=True)
        self._os_sched_var = tk.BooleanVar(value=self._os_sched_enabled)
        tip(ToggleSwitch(col, text="Usar el Programador de tareas de Windows para correr los horarios aunque la "
                         "aplicación esté cerrada", variable=self._os_sched_var, command=self._ossched_on_toggle),
            f"Registra una tarea de Windows que revisa cada {OS_INTERVAL_MIN} min si hay un horario pendiente y lo "
            "ejecuta en segundo plano. No requiere permisos de administrador.").pack(anchor="w")
        self._ossched_lbl = autowrap(tk.Label(col, text=getattr(self, "_ossched_text", ("Verificando…", T["muted"]))[0],
                                              font=(FUI, 10), bg=T["panel_bg"], fg=T["muted"], anchor="w",
                                              justify="left"))
        self._ossched_lbl.pack(anchor="w", fill="x", pady=(px(6), 0))
        self._lbl(col, "Los escaneos web con inicio de sesión necesitan la contraseña en memoria, así que solo corren "
                  "programados si no requieren credenciales.", size=9, fg=T["muted"], anchor="w", justify="left",
                  wraplength=px(720)).pack(anchor="w", fill="x", pady=(px(4), 0))
        acts = tk.Frame(row, bg=T["panel_bg"])
        acts.pack(side="right", anchor="n")
        PillButton(acts, "Reparar", self._ossched_reinstall, icon="refresh", size=10).pack(side="left", padx=(0, px(6)))
        PillButton(acts, "Quitar tarea", self._ossched_remove, icon="delete", variant="danger_ghost", size=10).pack(
            side="left")
        self._sched_refresh()

    def _sched_refresh(self) -> None:
        tree = getattr(self, "_sched_tree", None)
        if tree is None or not tree.winfo_exists():
            return
        clear_tree(tree)
        scheds = sorted(self._sched_store.list_schedules(), key=lambda s: s.get("next_run_at") or "")
        for s in scheds:
            tree.insert("", "end", iid=s["id"], tags=(stripe(tree),), values=(
                s.get("app_name", "?"), " · ".join(STAGE_LABELS.get(k, k) for k in s.get("stages", [])), describe(s),
                _fmt(s.get("next_run_at")) if s.get("enabled") else "(pausado)", _fmt(s.get("last_run_at")),
                {"ok": "✓ OK", "error": "✕ Error"}.get(s.get("last_run_status"), "—"), "✓" if s.get("enabled") else "—"))
        on = [s for s in scheds if s.get("enabled")]
        self._sched_engine_lbl.config(text=f"Motor activo · {len(on)} horario(s) · próxima: "
                                           f"{_fmt(min(s.get('next_run_at') or '' for s in on))}" if on else
                                      "Motor activo · sin horarios habilitados")

    def _sched_selected(self) -> Optional[dict]:
        sel = self._sched_tree.selection()
        return self._sched_store.get_schedule(sel[0]) if sel else None

    def _sched_editor(self, sched: Optional[dict]):
        apps = self._inv_store.list_apps()
        if sched is None and not apps:
            return self._show_warn_popup("Sin aplicaciones", "Cree al menos una aplicación en Aplicaciones antes de "
                                         "programar un escaneo.")
        s = dict(sched or {"id": "", "app_id": "", "app_name": "", "stages": [], "recurrence": "daily",
                           "time_of_day": "02:00", "weekday": 0, "interval_minutes": 360, "enabled": True,
                           "last_run_at": None, "last_run_status": None, "auto_open_on_finish": False})
        by_name = {a["name"]: a for a in apps}
        popup = self._popup("Horario de escaneo")
        self._popup_hdr(popup, "Editar horario" if sched else "Nuevo horario",
                        subtitle="Elija la aplicación, las etapas y cuándo debe ejecutarse.")
        pad = tk.Frame(popup, bg=T["bg"], padx=px(24), pady=px(8))
        pad.pack(fill="both", expand=True)
        cur = next((a["name"] for a in apps if a.get("id") == s.get("app_id")), next(iter(by_name), ""))
        app_var = tk.StringVar(value=cur)

        def section(title):
            return self._card(pad, title, collapsible=False)
        body = section("Aplicación")
        ttk.Combobox(body, textvariable=app_var, values=list(by_name), state="readonly").pack(fill="x")
        if not apps:
            self._lbl(body, "No hay aplicaciones registradas — cree una en Aplicaciones primero.", size=10,
                      fg=T["err"]).pack(anchor="w", pady=(px(6), 0))

        def defaults(name):
            if sched:
                return set(s.get("stages") or [])
            a = by_name.get(name, {})
            prefs = self._sched_store.get_stage_prefs(a.get("id", ""))
            return set(prefs if prefs is not None else a.get("scan_stages") or NO_APP_STAGES)
        body = section("Etapas")
        init = defaults(cur)
        stage_vars = {k: tk.BooleanVar(value=k in init) for k in STAGES}
        grid = tk.Frame(body, bg=T["panel_bg"])
        grid.pack(fill="x")
        for i, (k, v) in enumerate(stage_vars.items()):
            ToggleSwitch(grid, text=STAGE_LABELS[k], variable=v).grid(row=i // 4, column=i % 4, sticky="w",
                                                                      padx=(0, px(18)), pady=px(2))
        self._lbl(body, "Usa los objetivos guardados en el perfil de la aplicación (carpeta, URL, imágenes, IaC).",
                  size=9, fg=T["muted"]).pack(anchor="w", pady=(px(6), 0))
        if not sched:
            app_var.trace_add("write", lambda *_: [v.set(k in defaults(app_var.get())) for k, v in stage_vars.items()])
        body = section("Cuándo")
        rec = tk.StringVar(value=s.get("recurrence", "daily"))
        rr = tk.Frame(body, bg=T["panel_bg"])
        rr.pack(fill="x", pady=(0, px(8)))
        hh, mm = _hhmm(s.get("time_of_day") or "02:00")
        hh_v, mm_v = tk.StringVar(value=f"{hh:02d}"), tk.StringVar(value=f"{mm:02d}")
        wd_v = tk.StringVar(value=WEEKDAYS[int(s.get("weekday", 0)) % 7])
        iv_v = tk.StringVar(value=str(s.get("interval_minutes") or 360))
        rows = {}
        for key, build in (
                ("time", lambda f: (self._lbl(f, "Hora", size=10).pack(side="left"),
                                    ttk.Spinbox(f, textvariable=hh_v, from_=0, to=23, width=3).pack(side="left",
                                                                                                    padx=(px(6), px(2))),
                                    self._lbl(f, ":", size=10).pack(side="left"),
                                    ttk.Spinbox(f, textvariable=mm_v, from_=0, to=59, width=3).pack(side="left",
                                                                                                    padx=px(2)),
                                    self._lbl(f, "(24 h)", size=10, fg=T["muted"]).pack(side="left", padx=(px(4), 0)))),
                ("wd", lambda f: (self._lbl(f, "Día", size=10).pack(side="left"),
                                  ttk.Combobox(f, textvariable=wd_v, values=WEEKDAYS, state="readonly", width=12).pack(
                                      side="left", padx=(px(6), 0)))),
                ("iv", lambda f: (self._lbl(f, "Cada", size=10).pack(side="left"),
                                  ttk.Spinbox(f, textvariable=iv_v, from_=5, to=10080, width=6).pack(side="left",
                                                                                                     padx=px(6)),
                                  self._lbl(f, "minutos  (360 = cada 6 h · 1440 = diario)", size=10,
                                            fg=T["muted"]).pack(side="left")))):
            rows[key] = tk.Frame(body, bg=T["panel_bg"])
            build(rows[key])

        def sync():
            for f in rows.values():
                f.pack_forget()
            for k in (("iv",) if rec.get() == "interval" else ("wd", "time") if rec.get() == "weekly" else ("time",)):
                rows[k].pack(fill="x", pady=(0, px(6)))
        for val, lbl in (("daily", "Diario"), ("weekly", "Semanal"), ("interval", "Cada intervalo")):
            ttk.Radiobutton(rr, text=lbl, value=val, variable=rec, command=sync).pack(side="left", padx=(0, px(14)))
        sync()
        enabled, auto = tk.BooleanVar(value=s.get("enabled", True)), tk.BooleanVar(value=s.get("auto_open_on_finish", False))
        opts = tk.Frame(pad, bg=T["bg"])
        opts.pack(fill="x")
        ToggleSwitch(opts, text="Horario activo", variable=enabled).pack(side="left", padx=(0, px(18)))
        ToggleSwitch(opts, text="Abrir el reporte al terminar", variable=auto).pack(side="left")

        def save():
            app = by_name.get(app_var.get())
            stages = [k for k, v in stage_vars.items() if v.get()]
            if not app or not stages:
                return status.config(text="Seleccione una aplicación." if not app else "Seleccione al menos una etapa.")
            try:
                h, m = int(hh_v.get()), int(mm_v.get())
            except ValueError:
                h, m = 2, 0
            try:
                iv = max(5, int(iv_v.get()))
            except ValueError:
                iv = 360
            new = {**s, "app_id": app["id"], "app_name": app["name"], "stages": stages, "recurrence": rec.get(),
                   "time_of_day": f"{max(0, min(23, h)):02d}:{max(0, min(59, m)):02d}",
                   "weekday": WEEKDAYS.index(wd_v.get()), "interval_minutes": iv, "enabled": enabled.get(),
                   "auto_open_on_finish": auto.get()}
            if new["enabled"] and new["recurrence"] != "interval":
                clash = next((o.get("app_name", "?") for o in self._sched_store.list_schedules()
                              if o.get("id") != new.get("id") and o.get("enabled", True)
                              and o.get("recurrence") in ("daily", "weekly") and o.get("time_of_day") == new["time_of_day"]
                              and not (new["recurrence"] == o["recurrence"] == "weekly"
                                       and int(o.get("weekday", 0)) != new["weekday"])), None)
                if clash:
                    return status.config(text=f"Ya hay un horario de '{clash}' a las {new['time_of_day']} — elija otra "
                                              "hora o desactive uno de los dos.")
            new["next_run_at"] = next_run(new, datetime.now()).isoformat(timespec="seconds")
            self._sched_store.save_schedule(new)
            self._sched_store.save_stage_prefs(app["id"], stages)
            popup.close()
            self._sched_refresh()
            self._ossched_selfheal()
        _, status = self._popup_foot(popup, ("Cancelar", popup.close), ("Guardar", save), with_status=True)

    def _sched_delete(self) -> None:
        if not (s := self._sched_selected()):
            return

        def delete():
            self._sched_store.delete_schedule(s["id"])
            self._sched_pending.discard(s["id"])
            self._sched_refresh()
            if not self._sched_store.list_schedules():
                self._ossched_selfheal()
        self._show_confirm_popup("Eliminar horario", f"¿Eliminar el horario de '{s.get('app_name', '?')}'?\nEsta acción "
                                 "no se puede deshacer.", on_yes=delete, yes_label="Eliminar",
                                 no_label="Cancelar")

    def _sched_toggle(self) -> None:
        if not (s := self._sched_selected()):
            return
        s["enabled"] = not s.get("enabled", True)
        if s["enabled"]:
            s["next_run_at"] = next_run(s, datetime.now()).isoformat(timespec="seconds")
        else:
            self._sched_pending.discard(s["id"])
        self._sched_store.save_schedule(s)
        self._sched_refresh()

    def _sched_run_now(self) -> None:
        if not (s := self._sched_selected()):
            return
        if s["id"] in self._sched_pending:
            return self._emit_log(f"[horario] '{s.get('app_name')}' ya está en cola.")
        self._sched_pending.add(s["id"])
        self._emit_log(f"[horario] '{s.get('app_name')}' — ejecución manual solicitada, en cola.")
        self._sched_refresh()
        self._schedule_process()

    def _ossched_status(self, st) -> None:
        if not self._os_sched_enabled:
            text, fg = st.detail, T["muted"]
        elif st.healthy:
            text, fg = f"✓  {st.detail}", T["muted"]
        else:
            text, fg = "⚠  " + (st.detail or "No se pudo verificar el estado."), T["accent"]
        self._ossched_text = (text, fg)
        lbl = getattr(self, "_ossched_lbl", None)
        if lbl is not None and lbl.winfo_exists():
            lbl.config(text=text, fg=fg)

    def _ossched_bg(self, fn):
        threading.Thread(target=lambda: self._ui(self._ossched_status, fn()), daemon=True).start()

    def _ossched_args(self):
        return APP_DIR, sys.executable, DATA_DIR

    def _ossched_selfheal(self) -> None:
        if self._headless:
            return
        if not self._sched_store.list_schedules():
            def cleanup():
                st = scheduler_os.get_status(*self._ossched_args(), OS_INTERVAL_MIN)
                return scheduler_os.remove(DATA_DIR, self._emit_log) if st.installed else scheduler_os.SchedulerStatus(
                    detail="Sin horarios configurados — no hay tarea registrada.")
            return self._ossched_bg(cleanup)
        if not self._os_sched_enabled:
            return self._ossched_status(scheduler_os.SchedulerStatus(
                detail="Desactivado — los horarios solo corren con la aplicación abierta."))
        self._ossched_status(scheduler_os.SchedulerStatus(detail=f"Verificando {scheduler_os.LABEL}…"))
        self._ossched_bg(lambda: scheduler_os.install_or_repair(*self._ossched_args(), OS_INTERVAL_MIN, self._emit_log))

    def _ossched_set(self, on: bool):
        self._os_sched_enabled = on
        if getattr(self, "_os_sched_var", None) is not None:
            self._os_sched_var.set(on)
        self._save_settings()
        if on:
            return self._ossched_selfheal()
        self._ossched_status(scheduler_os.SchedulerStatus(detail="Quitando tarea del sistema…"))
        self._ossched_bg(lambda: scheduler_os.remove(DATA_DIR, self._emit_log))

    def _ossched_on_toggle(self) -> None:
        self._ossched_set(self._os_sched_var.get())

    def _ossched_remove(self) -> None:
        self._show_confirm_popup(
            "Quitar tarea del sistema",
            f"Se eliminará por completo la tarea del {scheduler_os.LABEL} que permite correr horarios con la aplicación "
            "cerrada.\n\nLos horarios configurados dentro de la app no se borran, pero dejarán de dispararse mientras la "
            "aplicación esté cerrada, hasta que vuelva a activar la opción.",
            on_yes=lambda: self._ossched_set(False), yes_label="Quitar", no_label="Cancelar")

    def _ossched_reinstall(self) -> None:
        if self._os_sched_enabled:
            return self._ossched_selfheal()
        self._ossched_bg(lambda: scheduler_os.get_status(*self._ossched_args(), OS_INTERVAL_MIN))

    def _schedule_tick(self) -> None:
        try:
            due = [s for s in self._sched_store.list_schedules()
                   if s.get("enabled") and is_due(s) and s["id"] not in self._sched_pending]
            for s in due:
                self._sched_pending.add(s["id"])
                self._emit_log(f"[horario] '{s.get('app_name', '?')}' vencido — en cola")
            if due:
                self._sched_refresh()
            self._schedule_process()
        except Exception as e:
            self._emit_log(f"[horario] error en el ciclo: {e!r}")
        finally:
            self.after(POLL_MS, self._schedule_tick)

    def _schedule_process(self) -> None:
        if not self._sched_pending or self._any_busy():
            return
        sid = min(self._sched_pending, key=lambda i: (self._sched_store.get_schedule(i) or {}).get("next_run_at") or "")
        if not claim_owner():
            return
        self._sched_pending.discard(sid)
        s = self._sched_store.get_schedule(sid)
        if not s:
            return release_owner()
        app = self._inv_store.get_app(s.get("app_id", ""))
        if not app:
            self._emit_log(f"[horario] la aplicación '{s.get('app_name', '?')}' ya no existe en el inventario — se omite "
                           "esta ejecución")
            mark_run(self._sched_store, s, False)
            self._sched_refresh()
            return release_owner()
        prev = {"app": self._active_app, "target": self._target_var.get(), "dast": self._dast_url_var.get(),
                "api": self._api_spec_var.get(), "stages": {k: v.get() for k, v in self._scan_vars.items()},
                "auto_open": self._auto_open, "static_paths": list(self._static_paths),
                "container": [dict(x) for x in getattr(self, "_container_sources", [])],
                "iac": list(getattr(self, "_iac_paths", []))}
        self._apply_schedule_target(app, s)
        self._refresh_scan_btn()
        self._refresh_active_app_banner()
        self._emit_log(f"[horario] disparando escaneo programado para '{app.get('name')}' ({'+'.join(s.get('stages', []))})")
        audit(self._reports_var.get(), "schedule_fire", actor=self._user, app=app.get("name", ""),
              schedule_id=s.get("id"), stages=s.get("stages"), log=self._emit_log)

        def run():
            ok = True
            try:
                self._do_scan()
            except Exception as e:
                ok = False
                self._emit_log(f"[horario] error inesperado durante el escaneo programado: {e!r}")
            self._ui(self._finish_scheduled_run, sid, prev, ok)
        self._run_async(run, f"escaneo programado: {app.get('name')}")

    def _apply_schedule_target(self, app: dict, s: dict) -> None:
        self._active_app = app
        self._target_var.set(app.get("target_path", ""))
        self._dast_url_var.set(app.get("dast_url", ""))
        self._api_spec_var.set(app.get("api_spec", ""))
        self._static_paths[:] = app.get("static_paths") or ([app["target_path"]] if app.get("target_path") else [])
        if hasattr(self, "_container_sources"):
            self._container_sources[:] = [x for x in app.get("container_sources") or [] if isinstance(x, dict)]
            self._iac_paths[:] = [x for x in app.get("iac_paths") or [] if isinstance(x, str)]
        for k, v in self._scan_vars.items():
            v.set(k in (s.get("stages") or []))
        self._auto_open = bool(s.get("auto_open_on_finish", False))

    def _finish_scheduled_run(self, sid: str, prev: dict, ok: bool) -> None:
        self._active_app = prev["app"]
        self._target_var.set(prev["target"])
        self._dast_url_var.set(prev["dast"])
        self._api_spec_var.set(prev["api"])
        self._static_paths[:] = prev.get("static_paths", [])
        if hasattr(self, "_container_sources"):
            self._container_sources[:] = prev.get("container", [])
            self._iac_paths[:] = prev.get("iac", [])
        for k, v in self._scan_vars.items():
            v.set(prev["stages"].get(k, False))
        self._auto_open = prev["auto_open"]
        self._refresh_scan_btn()
        self._refresh_active_app_banner()
        if s := self._sched_store.get_schedule(sid):
            mark_run(self._sched_store, s, ok)
        self._emit_log(f"[horario] ejecución programada finalizada ({'ok' if ok else 'error'})")
        self._sched_refresh()
        release_owner()
