from __future__ import annotations

import webbrowser
from datetime import timedelta

from ui_common import *

RISK_LABELS = ("Crítico", "Alto", "Medio", "Bajo", "Ninguno")
TECH_STACKS = ["Python", "Node.js / JavaScript", "Java / Spring", "C# / .NET", "Go", "Ruby on Rails", "PHP", "Rust",
               "C / C++", "Kotlin / Android", "Swift / iOS", "React / Vue / Angular (SPA)", "Mobile (React Native)",
               "Microservicios", "Serverless / Lambda", "Otro"]
ENVIRONMENTS = ["Producción", "Preproducción / Staging", "QA / Pruebas", "Desarrollo", "Interno / Intranet",
                "Nube (AWS)", "Nube (Azure)", "Nube (GCP)", "En sitio (On-Premise)", "Híbrido"]
APP_TYPES = ["Aplicación Web", "API REST", "API GraphQL", "App Móvil (iOS)", "App Móvil (Android)",
             "Aplicación de Escritorio", "Herramienta CLI / Script", "Microservicio", "Pipeline de Datos",
             "Proceso por Lotes / Trabajo en Segundo Plano", "IoT / Embebido", "Librería / SDK", "Otro"]
CRITICALITY = ["Crítico para la Misión", "Crítico para el Negocio", "Importante", "Estándar", "Bajo"]
DATA_CLASSES = ["Confidencial — Financiero", "Confidencial — Personal", "Restringido", "Interno", "Público"]
EMPTY_APP = {"id": "", "name": "", "description": "", "owner": "", "owner_email": "", "created_at": "",
             "updated_at": "", "app_type": APP_TYPES[0], "tech_stack": TECH_STACKS[0], "environment": ENVIRONMENTS[0],
             "criticality": CRITICALITY[1], "data_class": DATA_CLASSES[0], "compliance": [], "repo_url": "",
             "ci_pipeline": "", "target_path": "", "dast_url": "", "api_spec": "", "scan_stages": list(NO_APP_STAGES),
             "last_scan": None, "last_mode": "", "vuln_critical": 0, "vuln_high": 0, "vuln_medium": 0, "vuln_low": 0,
             "vuln_total": 0, "secrets_total": 0, "risk_tier": "Ninguno", "scan_history": [], "notes": "",
             "static_paths": [], "container_sources": [], "iac_paths": []}
BANK_APPS = [
    "ACL Analytics", "Activación", "AllianceWarehouse", "ALPINEDEVSECOPSNODE2",
    "API Manager", "auth-service", "Avaya Acra Report", "axiscom",
    "B2B_Loans", "B3", "Backoffice - AML", "BackOffice - Captacion",
    "Backoffice - Catalogs", "Backoffice - Client as a Service",
    "Backoffice - Digital Business", "Backoffice - Framework",
    "Backoffice - Middle Office", "Backoffice - Operations",
    "Backoffice - Security", "BackOffice - Solutions", "Bajaware",
    "Base Fix API", "Baseinet", "Baseinet - Automation", "BaseLake",
    "BaseMX", "Bastian", "BaseWEB - Refresh", "Bayu", "BI",
    "Binnacle App", "Biometrics", "Blacklist Api", "bloom", "BPM",
    "Calculator", "ChannelPayments", "CI/CD", "CIS BenchMark", "Citrix",
    "Clients API", "Cloud", "Cognos", "Collectpayments",
    "CommonLibraries-dso", "commons-dev", "Communicator", "ConnectDirect",
    "Constancias - Retenciones", "Contabilidad", "ContPaq",
    "ContratoDigitalExp", "Core Batch", "Core FX", "Core Withholding",
    "coreaxis", "Corems", "Credit Bureau", "Crypto API", "Customers",
    "Darwin", "DataHub", "Datascience", "DealTracker", "DevelopTools",
    "devsecops-alpine-python-1", "devsecops-ex-py-1",
    "devsecops-workshop-sample-1", "DEVSECOPSALPINEJAVA1",
    "Digital infrastructure", "Digital Transformation", "DirectDebit",
    "Easycredit", "ESB", "ESBs", "Fiel Services", "FinantialOCI",
    "FixReader", "FoundDispersion", "generic",
    "gfb-devsecops-infra-onprem-cloud", "gfb-externalpayments", "GWDB",
    "H2H", "Historical Databases", "Hopex", "Image check", "Imperva",
    "indeval", "Infrastructure Requests POC", "Infrastrucutre Requests",
    "Instrumental", "Intelexion", "Interfaz BBASE Creditos",
    "Interfaz Reuters", "InvoiceAssignment", "ISILoans", "IT Architecture",
    "ITAL", "Kondor - Derivatives", "Legal", "Lexis Nexis - AML",
    "maincatalogs", "MessageHub", "ModeloRiesgo", "MoneyMarketBk",
    "MoneyMarketCB", "Nautilus", "Notificator API", "Nuba2.0", "OnBase",
    "Onboarding", "Onboarding-Gen", "Onboarding-PF", "Onboarding-PM",
    "Pagare", "Panjiva", "PIPELINE-BPM", "PLD", "PLD - Fraudes",
    "Power BI", "Price Vector", "PrivateCloud", "PROKEY1", "Proleasenet",
    "Quadient", "RecipientAccounts", "Release Management", "Rentabilidad",
    "RiskAnalysis", "RPA", "Sailpoint", "Salesforce", "SatEnrichment",
    "security", "Service Now", "Sibase", "Siglo", "Siscore", "SonarQube",
    "specoff", "SPEI", "SPID", "SWA", "SWIFT", "Tableau", "Taller Git",
    "Teller", "Transactional-linking", "Validanet", "Veritran VTET",
    "Volpay", "WebLandings", "WinService Alerts", "wiretransfer",
    "workflowcontroller", "Workspaces", "Wrapper", "Wso2_internal",
]


def _slugify(name: str) -> str:
    return re.sub(r"[\s_-]+", "_", re.sub(r"[^\w\s-]", "", name.strip().lower()))[:48] or "app"


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%dT%H:%M:%S")


def risk_colors() -> dict:
    return RISK_COLORS[is_dark()]


class AppInventoryStore:
    def __init__(self, reports_root: Path):
        self._lock = threading.Lock()
        self.inv_dir = Path(reports_root) / "inventory"
        self.inv_dir.mkdir(parents=True, exist_ok=True)
        self._index = self.inv_dir / "_index.json"

    def _ids(self) -> list[str]:
        ids = read_json(self._index)
        if not isinstance(ids, list):
            ids = sorted(p.stem for p in self.inv_dir.glob("*.json") if p.name != "_index.json")
            write_json(self._index, ids)
        return ids

    def _path(self, app_id: str) -> Path:
        return self.inv_dir / f"{app_id}.json"

    def list_apps(self) -> list[dict]:
        with self._lock:
            return [a for a in (read_json(self._path(i)) for i in self._ids()) if isinstance(a, dict)]

    def get_app(self, app_id: str) -> Optional[dict]:
        with self._lock:
            a = read_json(self._path(app_id))
            return a if isinstance(a, dict) else None

    def save_app(self, app: dict) -> None:
        with self._lock:
            app["id"] = app.get("id") or _slugify(app.get("name", "app"))
            ids = self._ids()
            if app["id"] not in ids:
                base, n = app["id"], 1
                while self._path(app["id"]).exists():
                    app["id"], n = f"{base}_{n}", n + 1
                write_json(self._index, ids + [app["id"]])
            app["updated_at"] = _now()
            app["created_at"] = app.get("created_at") or app["updated_at"]
            write_json(self._path(app["id"]), app)

    def delete_app(self, app_id: str) -> None:
        with self._lock:
            write_json(self._index, [i for i in self._ids() if i != app_id])
            self._path(app_id).unlink(missing_ok=True)

    def record_scan(self, app_id: str, meta: dict) -> None:
        app = self.get_app(app_id)
        if app is None:
            return
        counts = meta.get("counts", {})
        c, h, m, lo = (int(counts.get(k, 0) or 0) for k in ("critical", "high", "medium", "low"))
        app.update(last_scan=_now(), last_mode=meta.get("mode", ""), vuln_critical=c, vuln_high=h, vuln_medium=m,
                   vuln_low=lo, vuln_total=int(meta.get("total", 0) or 0),
                   secrets_total=int(meta.get("secrets_total", 0) or 0),
                   risk_tier=next((t for t, n in zip(RISK_LABELS, (c, h, m, lo)) if n), "Ninguno"))
        app["scan_history"] = (app.get("scan_history") or [])[-49:] + [
            {"ts": app["last_scan"], "mode": app["last_mode"], "critical": c, "high": h, "medium": m, "low": lo,
             "total": app["vuln_total"]}]
        self.save_app(app)


def _ago(stamp) -> str:
    try:
        d = datetime.now() - datetime.fromisoformat(str(stamp)[:19])
    except Exception:
        return ""
    if d.days >= 60:
        return f"hace {d.days // 30} meses"
    if d.days >= 1:
        return "hace 1 día" if d.days == 1 else f"hace {d.days} días"
    h = d.seconds // 3600
    return f"hace {h} h" if h else "hace minutos"


def _stale(app: dict, days: int = 30) -> bool:
    try:
        return not app.get("last_scan") or datetime.fromisoformat(str(app["last_scan"])[:19]) < datetime.now() - timedelta(days=days)
    except Exception:
        return False


_TILES = (("all", "Aplicaciones", "text", None), ("Crítico", "Riesgo crítico", "sev_critical", "Crítico"),
          ("Alto", "Riesgo alto", "sev_high", "Alto"), ("Medio", "Riesgo medio", "sev_medium", "Medio"),
          ("stale", "Sin escaneo en 30 días", "muted", "stale"))
_SEV_KEYS = (("critical", "Críticas"), ("high", "Altas"), ("medium", "Medias"), ("low", "Bajas"))
DETAIL_W = 400
_TILE_TIPS = {"all": "Clic para ver todas las aplicaciones.",
              "Crítico": "Aplicaciones cuyo último escaneo tuvo al menos un hallazgo crítico. Clic para filtrar.",
              "Alto": "Aplicaciones cuyo peor hallazgo fue alto. Clic para filtrar.",
              "Medio": "Aplicaciones cuyo peor hallazgo fue medio. Clic para filtrar.",
              "stale": "Aplicaciones sin escaneo en los últimos 30 días (o nunca escaneadas): su estado real puede "
                       "ser peor de lo que muestran. Clic para filtrar."}


class _AppsTabMixin:
    # ── Página «Aplicaciones» ───────────────────────────────────────────────
    def _build_tab_apps(self, parent):
        self._app_filter = None
        wrap = tk.Frame(parent, bg=T["bg"], padx=px(28), pady=px(4))
        wrap.pack(fill="both", expand=True)
        strip = tk.Frame(wrap, bg=T["bg"])
        strip.pack(fill="x", pady=(0, CARD_GAP))
        self._dash_tiles = {}
        for i, (key, label, role, flt) in enumerate(_TILES):
            strip.columnconfigure(i, weight=1, uniform="tile")
            tile = tk.Frame(strip, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"],
                            cursor="hand2", padx=px(16), pady=px(10))
            tile.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else CARD_GAP // 2, 0))
            num = tk.Label(tile, text="—", font=(FUI_TITLE, 20, "bold"), bg=T["panel_bg"], fg=T[role], anchor="w")
            num.pack(fill="x")
            cap = tk.Label(tile, text=label, font=(FUI, 10), bg=T["panel_bg"], fg=T["muted"], anchor="w")
            cap.pack(fill="x")
            self._dash_tiles[key] = (tile, num, cap)
            for w in (tile, num, cap):
                w.bind("<Button-1>", lambda _e, f=flt: self._set_app_filter(f))
            tip(tile, _TILE_TIPS.get(key))
        bar = tk.Frame(wrap, bg=T["bg"])
        bar.pack(fill="x", pady=(0, px(8)))
        sbox = tk.Frame(bar, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"])
        sbox.pack(side="left", fill="x", expand=True)
        tk.Label(sbox, text=ico("search"), font=icon_font(11), bg=T["panel_bg"], fg=T["muted"]).pack(
            side="left", padx=(px(10), px(6)))
        placeholder = "Buscar por nombre, tipo, entorno, responsable…"
        self._app_search = tk.StringVar(value=placeholder)
        self._app_search_ph = placeholder
        e = tk.Entry(sbox, textvariable=self._app_search, relief="flat", bd=0, font=(FUI, 11), bg=T["panel_bg"],
                     fg=T["muted"], insertbackground=T["text"])
        e.pack(side="left", fill="x", expand=True, ipady=px(6))
        e.bind("<FocusIn>", lambda _e: self._app_search.get() == placeholder and (
            self._app_search.set(""), e.configure(fg=T["text"])))
        e.bind("<FocusOut>", lambda _e: not self._app_search.get() and (
            self._app_search.set(placeholder), e.configure(fg=T["muted"])))
        self._app_filter_chip = tk.Frame(bar, bg=T["bg"])
        self._app_filter_chip.pack(side="left", padx=(px(8), 0))
        self._app_search.trace_add("write", lambda *_: self._refresh_inventory())
        PillButton(bar, "Nueva aplicación", lambda: self._edit_app_profile(None), icon="add", variant="primary").pack(
            side="right", padx=(px(8), 0))
        split = tk.Frame(wrap, bg=T["bg"])
        split.pack(fill="both", expand=True, pady=(0, px(8)))
        split.columnconfigure(0, weight=1)
        split.columnconfigure(1, minsize=px(DETAIL_W))
        split.rowconfigure(0, weight=1)
        left = tk.Frame(split, bg=T["bg"])
        left.grid(row=0, column=0, sticky="nsew", padx=(0, CARD_GAP))
        self._apps_tree = make_tree(left, ("name", "risk", "vulns", "crit", "env", "last_scan"), [
            ("Aplicación", 240, "w", True), ("Riesgo", 90, "w", False), ("C · A · M · B", 120, "center", False),
            ("Criticidad", 150, "w", False), ("Entorno", 150, "w", False), ("Último escaneo", 120, "w", False)], 20)
        self._apps_tree.bind("<<TreeviewSelect>>", lambda _e: self._show_app_detail(self._selected_app()))
        self._apps_tree.bind("<Double-1>", lambda _e: (a := self._selected_app()) and self._load_app_profile(a))
        self._apps_tree.bind("<Return>", lambda _e: (a := self._selected_app()) and self._load_app_profile(a))
        self._apps_tree.bind("<Delete>", lambda _e: self._delete_selected_app())
        right = tk.Frame(split, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"],
                         width=px(DETAIL_W))
        right.grid(row=0, column=1, sticky="nsew")
        right.grid_propagate(False)
        right.pack_propagate(False)
        self._app_detail = scroll_frame(right, bg=T["panel_bg"])
        self._refresh_inventory()
        self._show_app_detail(self._active_app and self._inv_store.get_app(self._active_app.get("id", "")))

    def _set_app_filter(self, flt):
        self._app_filter = None if flt == getattr(self, "_app_filter", None) else flt
        self._refresh_inventory()

    def _refresh_inventory(self):
        tree = getattr(self, "_apps_tree", None)
        if tree is None or not tree.winfo_exists():
            return
        apps = self._inv_store.list_apps()
        counts = {"all": len(apps), "stale": sum(map(_stale, apps)),
                  **{t: sum(1 for a in apps if a.get("risk_tier") == t) for t in ("Crítico", "Alto", "Medio")}}
        flt = getattr(self, "_app_filter", None)
        for key, (tile, num, cap) in self._dash_tiles.items():
            num.config(text=str(counts.get(key, 0)))
            on = flt is not None and key == flt or flt is None and key == "all"
            tile.config(highlightbackground=T["accent"] if on else T["border"], highlightthickness=2 if on else 1)
        chip = self._app_filter_chip
        for w in chip.winfo_children():
            w.destroy()
        if flt:
            label = next(lbl for k, lbl, _, f in _TILES if f == flt)
            PillButton(chip, f"{label}  ✕", lambda: self._set_app_filter(flt), variant="ghost", size=10).pack()
        rc = risk_colors()
        for tier, colour in rc.items():
            tree.tag_configure(tier.lower(), foreground=colour)
        tree.tag_configure("active", font=(FUI, 10, "bold"))
        clear_tree(tree)
        needle = self._app_search.get().strip().lower()
        needle = "" if needle == self._app_search_ph.lower() else needle
        active_id = (self._active_app or {}).get("id")
        order = {t: i for i, t in enumerate(RISK_LABELS)}
        for a in sorted(apps, key=lambda a: (order.get(a.get("risk_tier", "Ninguno"), 9), a.get("name", "").lower())):
            if needle and needle not in " ".join(str(a.get(k, "")) for k in (
                    "name", "app_type", "environment", "risk_tier", "criticality", "owner", "tech_stack")).lower():
                continue
            tier = a.get("risk_tier", "Ninguno")
            if flt == "stale" and not _stale(a) or flt in RISK_LABELS and tier != flt:
                continue
            last = a.get("last_scan")
            tags = (tier.lower(),) + (("active",) if a["id"] == active_id else ())
            tree.insert("", "end", iid=a["id"], tags=tags, values=(
                ("●  " if a["id"] == active_id else "") + a.get("name", ""), tier if last else "Sin escanear",
                " · ".join(str(a.get(f"vuln_{k}", 0)) for k in ("critical", "high", "medium", "low")) if last else "—",
                a.get("criticality", ""), a.get("environment", ""), _ago(last) or "Nunca"))
        sel = tree.selection()
        if active_id and tree.exists(active_id) and not sel:
            tree.selection_set(active_id)
            tree.see(active_id)

    def _selected_app(self) -> Optional[dict]:
        tree = getattr(self, "_apps_tree", None)
        sel = tree.selection() if tree is not None and tree.winfo_exists() else ()
        return self._inv_store.get_app(sel[0]) if sel else None

    # ── Panel de detalle ────────────────────────────────────────────────────
    def _show_app_detail(self, app: Optional[dict]):
        pad = getattr(self, "_app_detail", None)
        if pad is None or not pad.winfo_exists():
            return
        for w in pad.winfo_children():
            w.destroy()
        p = T["panel_bg"]
        if not app:
            box = tk.Frame(pad, bg=p, padx=px(24), pady=px(60))
            box.pack(fill="both", expand=True)
            tk.Label(box, text=ico("apps"), font=icon_font(28), bg=p, fg=T["border_strong"]).pack()
            tk.Label(box, text="Seleccione una aplicación", font=(FUI_TITLE, 13, "bold"), bg=p, fg=T["text"]).pack(
                pady=(px(10), px(2)))
            tk.Label(box, text="Verá su riesgo, objetivos de escaneo y tendencia.", font=(FUI, 10), bg=p,
                     fg=T["muted"], wraplength=px(DETAIL_W - 80), justify="center").pack()
            PillButton(box, "Nueva aplicación", lambda: self._edit_app_profile(None), icon="add").pack(pady=(px(16), 0))
            return
        inner_w = px(DETAIL_W) - px(48) - px(16)
        body = tk.Frame(pad, bg=p, padx=px(20), pady=px(18))
        body.pack(fill="both", expand=True)
        is_active = (self._active_app or {}).get("id") == app.get("id")
        tier = app.get("risk_tier", "Ninguno")
        scanned = bool(app.get("last_scan"))
        top = tk.Frame(body, bg=p)
        top.pack(fill="x")
        chips = tk.Frame(top, bg=p)
        chips.pack(fill="x", pady=(0, px(6)))
        risk_role = {"Crítico": ("sev_critical", "err_soft"), "Alto": ("sev_high", "warn_soft"),
                     "Medio": ("sev_medium", "surface3"), "Bajo": ("sev_low", "ok_soft")}.get(tier, ("muted", "surface3"))
        tip(pill_label(chips, f"Riesgo {tier.lower()}" if scanned else "Sin escanear", *risk_role),
            "El riesgo es la severidad más alta encontrada en el último escaneo de esta aplicación.").pack(side="left")
        if is_active:
            pill_label(chips, "Cargada", "button_fg", "accent").pack(side="left", padx=(px(6), 0))
        tk.Label(top, text=app.get("name", ""), font=(FUI_TITLE, 16, "bold"), bg=p, fg=T["text"], anchor="w",
                 justify="left", wraplength=inner_w).pack(fill="x")
        sub = " · ".join(x for x in (app.get("app_type"), app.get("tech_stack")) if x)
        if sub:
            tk.Label(top, text=sub, font=(FUI, 10), bg=p, fg=T["muted"], anchor="w", justify="left",
                     wraplength=inner_w).pack(fill="x")
        if app.get("description"):
            tk.Label(top, text=app["description"], font=(FUI, 10), bg=p, fg=T["text"], anchor="w", justify="left",
                     wraplength=inner_w).pack(fill="x", pady=(px(6), 0))
        acts = tk.Frame(body, bg=p)
        acts.pack(fill="x", pady=(px(14), px(4)))
        PillButton(acts, "Escanear" if is_active else "Cargar y escanear",
                   lambda: (self._load_app_profile(app, silent=True), self._show_tab("scan")), icon="play",
                   variant="primary").pack(side="left")
        PillButton(acts, "Editar", lambda: self._edit_app_profile(app), icon="edit").pack(side="left", padx=(px(6), 0))
        PillButton(acts, "", self._delete_selected_app, icon="delete", variant="danger_ghost",
                   tooltip="Eliminar aplicación").pack(side="right")
        if scanned:
            self._detail_section(body, "Último escaneo")
            tiles = tk.Frame(body, bg=p)
            tiles.pack(fill="x")
            for i, (k, label) in enumerate(_SEV_KEYS):
                fg_role, bg_role = SEV_ROLES[k]
                n = int(app.get(f"vuln_{k}", 0) or 0)
                tiles.columnconfigure(i, weight=1, uniform="sev")
                t = tk.Frame(tiles, bg=T[bg_role] if n else T["surface2"], padx=px(8), pady=px(8))
                t.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else px(4), 0))
                tk.Label(t, text=str(n), font=(FUI_TITLE, 17, "bold"), bg=t["bg"],
                         fg=T[fg_role] if n else T["muted"]).pack()
                tk.Label(t, text=label, font=(FUI, 9), bg=t["bg"], fg=T["muted"]).pack()
            meta = [f"{(app.get('last_scan') or '')[:16].replace('T', ' ')}  ·  {_ago(app.get('last_scan'))}"]
            if app.get("last_mode"):
                meta.append("Etapas: " + ", ".join(STAGE_LABELS.get(m, m.upper()) for m in app["last_mode"].split("+")))
            if app.get("secrets_total"):
                meta.append(f"{app['secrets_total']} secreto(s) expuesto(s)")
            for m in meta:
                tk.Label(body, text=m, font=(FUI, 9), bg=p, fg=T["muted"], anchor="w", justify="left",
                         wraplength=inner_w).pack(fill="x", pady=(px(4) if m is meta[0] else 0, 0))
            hist = (app.get("scan_history") or [])[-12:]
            if len(hist) >= 2:
                self._detail_section(body, "Tendencia")
                self._draw_trend(body, hist)
        else:
            self._detail_section(body, "Último escaneo")
            tk.Label(body, text="Esta aplicación aún no se ha escaneado.", font=(FUI, 10), bg=p, fg=T["muted"],
                     anchor="w").pack(fill="x")
        self._detail_section(body, "Objetivos de escaneo", action=("Editar", lambda: self._edit_app_profile(app)))
        targets = self._app_targets(app)
        if not targets:
            tk.Label(body, text="Sin objetivos configurados. Agregue la carpeta del repositorio, la URL o las imágenes "
                     "para escanear con un clic.", font=(FUI, 10), bg=p, fg=T["muted"], anchor="w", justify="left",
                     wraplength=inner_w).pack(fill="x")
        for icon, label, value in targets:
            row = tk.Frame(body, bg=p)
            row.pack(fill="x", pady=(0, px(6)))
            tk.Label(row, text=ico(icon), font=icon_font(11), bg=p, fg=T["accent"], width=2).pack(side="left", anchor="n",
                                                                                                    pady=(px(2), 0))
            col = tk.Frame(row, bg=p)
            col.pack(side="left", fill="x", expand=True, padx=(px(6), 0))
            tk.Label(col, text=label, font=(FUI, 9), bg=p, fg=T["muted"], anchor="w").pack(fill="x")
            v = tk.Label(col, text=middle_ellipsis(value, 46), font=(FMONO, 9), bg=p, fg=T["text"], anchor="w")
            v.pack(fill="x")
            if len(value) > 46:
                Tooltip(v, value)
        self._detail_section(body, "Clasificación")
        grid = tk.Frame(body, bg=p)
        grid.pack(fill="x")
        grid.columnconfigure(0, weight=1, uniform="cls")
        grid.columnconfigure(1, weight=1, uniform="cls")
        fields = (("Entorno", "environment"), ("Criticidad", "criticality"), ("Datos", "data_class"),
                  ("Responsable", "owner"))
        for i, (label, key) in enumerate(fields):
            cell = tk.Frame(grid, bg=p)
            cell.grid(row=i // 2, column=i % 2, sticky="nw", pady=(0, px(10)), padx=(0, px(8)))
            tk.Label(cell, text=label.upper(), font=(FUI, 8, "bold"), bg=p, fg=T["muted"], anchor="w").pack(fill="x")
            tk.Label(cell, text=app.get(key) or "—", font=(FUI, 10), bg=p, fg=T["text"], anchor="w", justify="left",
                     wraplength=inner_w // 2 - px(10)).pack(fill="x")
        if app.get("owner_email"):
            mail = tk.Label(body, text=app["owner_email"], font=(FUI, 10, "underline"), bg=p, fg=T["border2"],
                            anchor="w", cursor="hand2")
            mail.pack(fill="x")
            mail.bind("<Button-1>", lambda _e: webbrowser.open(f"mailto:{app['owner_email']}"))
        if app.get("compliance"):
            self._detail_section(body, "Cumplimiento")
            tk.Label(body, text=", ".join(app["compliance"]), font=(FUI, 10), bg=p, fg=T["text"], anchor="w",
                     justify="left", wraplength=inner_w).pack(fill="x")
        if app.get("notes"):
            self._detail_section(body, "Notas")
            tk.Label(body, text=app["notes"], font=(FUI, 10), bg=p, fg=T["text"], anchor="w", justify="left",
                     wraplength=inner_w).pack(fill="x")

    def _detail_section(self, parent, title, action=None):
        p = T["panel_bg"]
        tk.Frame(parent, bg=T["border"], height=1).pack(fill="x", pady=(px(16), px(10)))
        row = tk.Frame(parent, bg=p)
        row.pack(fill="x", pady=(0, px(8)))
        tk.Label(row, text=title, font=(FUI, 11, "bold"), bg=p, fg=T["text"]).pack(side="left")
        if action:
            lnk = tk.Label(row, text=action[0], font=(FUI, 10), bg=p, fg=T["border2"], cursor="hand2")
            lnk.pack(side="right")
            lnk.bind("<Button-1>", lambda _e: action[1]())

    @staticmethod
    def _app_targets(app: dict) -> list:
        out = []
        paths = app.get("static_paths") or ([app["target_path"]] if app.get("target_path") else [])
        for pth in paths:
            out.append(("folder", "Código (SCA · SAST · Secretos)", pth))
        if app.get("dast_url"):
            out.append(("globe", "Sitio web (DAST)", app["dast_url"]))
        if app.get("api_spec"):
            out.append(("link", "Especificación de API", app["api_spec"]))
        for s in app.get("container_sources") or []:
            out.append(("container", {"registry": "Imagen de contenedor", "archive": "Imagen (.tar)",
                                      "sbom": "SBOM"}.get(s.get("type"), "Imagen"), s.get("value", "")))
        for pth in app.get("iac_paths") or []:
            out.append(("iac", "Infraestructura como código", pth))
        return out

    def _draw_trend(self, parent, hist):
        H = px(96)
        cv = tk.Canvas(parent, height=H, bg=T["surface2"], bd=0, highlightthickness=0)
        cv.pack(fill="x")
        series = (("critical", T["sev_critical"]), ("high", T["sev_high"]), ("medium", T["sev_medium"]),
                  ("total", T["muted"]))

        def draw(_e=None):
            cv.delete("all")
            W = max(cv.winfo_width(), px(200))
            top = max((e.get("total", 0) or 0) for e in hist) or 1
            xs = [int(px(14) + i / max(len(hist) - 1, 1) * (W - px(28))) for i in range(len(hist))]
            y = lambda v: int(H - px(18) - v / top * (H - px(32)))
            for frac in (0.5, 1.0):
                cv.create_line(px(6), y(top * frac), W - px(6), y(top * frac), fill=T["border"], dash=(2, 4))
            for key, colour in series:
                pts = [c for i, e in enumerate(hist) for c in (xs[i], y(e.get(key, 0) or 0))]
                cv.create_line(pts, fill=colour, width=2 if key != "total" else 1, smooth=True)
            for key, colour in series[:3]:
                if v := hist[-1].get(key, 0) or 0:
                    cv.create_oval(xs[-1] - 4, y(v) - 4, xs[-1] + 4, y(v) + 4, fill=colour, outline="")
            cv.create_text(xs[0], H - px(4), text=str(hist[0].get("ts", ""))[:10], font=(FUI, 8), fill=T["muted"],
                           anchor="sw")
            cv.create_text(xs[-1], H - px(4), text=str(hist[-1].get("ts", ""))[:10], font=(FUI, 8), fill=T["muted"],
                           anchor="se")
        cv.bind("<Configure>", draw)
        leg = tk.Frame(parent, bg=T["panel_bg"])
        leg.pack(fill="x", pady=(px(4), 0))
        for (key, colour), name in zip(series, ("Críticas", "Altas", "Medias", "Total")):
            tk.Label(leg, text="●", font=(FUI, 9), bg=T["panel_bg"], fg=colour).pack(side="left")
            tk.Label(leg, text=name, font=(FUI, 9), bg=T["panel_bg"], fg=T["muted"]).pack(side="left", padx=(px(2), px(10)))

    # ── Editor de perfil ─────────────────────────────────────────────────────
    def _edit_app_profile(self, app: Optional[dict], on_saved=None):
        data = {**EMPTY_APP, **(app or {})}
        popup = self._popup("Perfil de aplicación")
        self._popup_hdr(popup, "Editar aplicación" if app else "Nueva aplicación",
                        subtitle="Solo el nombre es obligatorio. Los objetivos permiten escanear con un clic.")
        wrap = tk.Frame(popup, bg=T["bg"])
        wrap.pack(fill="both", expand=True)
        pad = scroll_frame(wrap, pad=(px(24), px(8)))
        v = {k: tk.StringVar(value=data.get(k) or "") for k in (
            "name", "description", "owner", "owner_email", "repo_url", "app_type", "tech_stack", "environment",
            "criticality", "data_class", "target_path", "dast_url", "api_spec")}
        reg = [s["value"] for s in data.get("container_sources") or [] if s.get("type") == "registry"]
        v["images"] = tk.StringVar(value=", ".join(reg))
        v["iac_path"] = tk.StringVar(value=(data.get("iac_paths") or [""])[0])
        stage_vars = {k: tk.BooleanVar(value=k in (data.get("scan_stages") or NO_APP_STAGES)) for k in STAGES}

        def section(title, hint=""):
            card = self._card(pad, title, collapsible=False)
            if hint:
                tk.Label(card, text=hint, font=(FUI, 10), bg=T["panel_bg"], fg=T["muted"], anchor="w", justify="left",
                         wraplength=px(760)).pack(fill="x", pady=(0, px(10)))
            g = tk.Frame(card, bg=T["panel_bg"])
            g.pack(fill="x")
            g.columnconfigure(0, weight=1, uniform="ed")
            g.columnconfigure(1, weight=1, uniform="ed")
            return g

        def field(g, row, col, label, widget, span=1):
            cell = tk.Frame(g, bg=T["panel_bg"])
            cell.grid(row=row, column=col, columnspan=span, sticky="ew", pady=(0, px(10)),
                      padx=(0 if col == 0 else px(8), 0 if col + span >= 2 else px(8)))
            tk.Label(cell, text=label, font=(FUI, 10, "bold"), bg=T["panel_bg"], fg=T["muted"], anchor="w").pack(fill="x")
            w = widget(cell)
            w.pack(fill="x", pady=(px(3), 0))
            return w

        def browse_row(cell, var, kind):
            f = tk.Frame(cell, bg=T["panel_bg"])
            ttk.Entry(f, textvariable=var).pack(side="left", fill="x", expand=True)

            def pick():
                with dialog_guard(self):
                    got = (filedialog.askdirectory(title="Seleccione la carpeta", initialdir=var.get() or APP_DIR)
                           if kind == "dir" else filedialog.askopenfilename(title="Especificación de API", filetypes=[
                               ("OpenAPI / Postman / GraphQL", "*.json *.yaml *.yml *.graphql"), ("Todos", "*.*")]))
                if got:
                    var.set(got)
            PillButton(f, "", pick, icon="folder", tooltip="Examinar…").pack(side="left", padx=(px(6), 0))
            return f

        g = section("Identidad")
        name_cell = field(g, 0, 0, "Nombre de la aplicación *", lambda c: tk.Frame(c, bg=T["panel_bg"]), span=2)
        search = tk.StringVar()
        entry = ttk.Entry(name_cell, textvariable=search)
        entry.pack(fill="x")
        lbw = tk.Frame(name_cell, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"])
        lb = tk.Listbox(lbw, height=4, font=(FUI, 10), bg=T["surface2"], fg=T["card_fg"], selectbackground=T["accent"],
                        selectforeground=T["button_fg"], activestyle="none", relief="flat", highlightthickness=0,
                        exportselection=False)
        sb = ttk.Scrollbar(lbw, orient="vertical", command=lb.yview)
        lb.configure(yscrollcommand=sb.set)
        lb.pack(side="left", fill="x", expand=True)
        sb.pack(side="right", fill="y")
        hint = tk.Label(name_cell, text="Escriba para buscar en el catálogo del banco, o use un nombre nuevo.",
                        font=(FUI, 9), bg=T["panel_bg"], fg=T["muted"], anchor="w")
        hint.pack(fill="x", pady=(px(2), 0))
        names = sorted(set(BANK_APPS) | {a["name"] for a in self._inv_store.list_apps() if a.get("name")}, key=str.lower)

        def populate(text=""):
            lb.delete(0, "end")
            t = text.strip().lower()
            hits = [n for n in names if t in n.lower()] if t else []
            for n in hits[:50]:
                lb.insert("end", n)
            exact = any(n.lower() == t for n in hits)
            if hits and not exact:
                lbw.pack(fill="x", pady=(px(2), 0), before=hint)
            else:
                lbw.pack_forget()

        def typed(*_):
            v["name"].set(search.get().strip())
            populate(search.get())

        def picked(_e=None):
            if sel := lb.curselection():
                name = lb.get(sel[0])
                search.trace_remove("write", tid[0])
                search.set(name)
                v["name"].set(name)
                tid[0] = search.trace_add("write", typed)
                lbw.pack_forget()
        search.set(data.get("name") or "")
        tid = [search.trace_add("write", typed)]
        lb.bind("<<ListboxSelect>>", picked)
        entry.focus_set()
        field(g, 1, 0, "Descripción", lambda c: ttk.Entry(c, textvariable=v["description"]), span=2)
        field(g, 2, 0, "Responsable / equipo", lambda c: ttk.Entry(c, textvariable=v["owner"]))
        field(g, 2, 1, "Correo del responsable", lambda c: ttk.Entry(c, textvariable=v["owner_email"]))
        field(g, 3, 0, "URL del repositorio", lambda c: ttk.Entry(c, textvariable=v["repo_url"]), span=2)

        g = section("Objetivos de escaneo", "Lo que configure aquí se carga al abrir la aplicación. Deje vacío lo que "
                    "no aplique.")
        field(g, 0, 0, "Carpeta del repositorio (código)", lambda c: browse_row(c, v["target_path"], "dir"), span=2)
        field(g, 1, 0, "URL del sitio web (DAST)", lambda c: ttk.Entry(c, textvariable=v["dast_url"]))
        field(g, 1, 1, "Especificación de API", lambda c: browse_row(c, v["api_spec"], "file"))
        field(g, 2, 0, "Imágenes de contenedor (separadas por coma)", lambda c: ttk.Entry(c, textvariable=v["images"]))
        field(g, 2, 1, "Carpeta de IaC (vacío = carpeta del repositorio)", lambda c: browse_row(c, v["iac_path"], "dir"))
        st = field(g, 3, 0, "Etapas predeterminadas", lambda c: tk.Frame(c, bg=T["panel_bg"]), span=2)
        for c in range(4):
            st.columnconfigure(c, weight=1, uniform="stg")
        for i, k in enumerate(STAGES):
            ToggleSwitch(st, text=STAGE_LABELS[k], variable=stage_vars[k]).grid(row=i // 4, column=i % 4, sticky="w",
                                                                                padx=(0, px(18)), pady=px(2))

        g = section("Clasificación")
        for i, (label, key, values) in enumerate((
                ("Tipo de aplicación", "app_type", APP_TYPES), ("Stack tecnológico", "tech_stack", TECH_STACKS),
                ("Entorno", "environment", ENVIRONMENTS), ("Criticidad de negocio", "criticality", CRITICALITY),
                ("Clasificación de datos", "data_class", DATA_CLASSES))):
            field(g, i // 2, i % 2, label, lambda c, k=key, vals=values: ttk.Combobox(
                c, textvariable=v[k], values=vals, state="readonly"))
        notes = field(g, 3, 0, "Notas", lambda c: tk.Text(c, height=3, font=(FUI, 10), bg=T["surface2"], fg=T["text"],
                                                          relief="flat", highlightthickness=1,
                                                          highlightbackground=T["border"], wrap="word",
                                                          insertbackground=T["text"]), span=2)
        notes.insert("1.0", data.get("notes") or "")
        auto = tk.BooleanVar(value=True)

        def save():
            name = v["name"].get().strip() or search.get().strip()
            if not name:
                return status.config(text="El nombre de la aplicación es obligatorio.")
            url = v["dast_url"].get().strip()
            if url and not re.match(r"^https?://", url, re.I):
                return status.config(text="La URL del sitio debe comenzar con http:// o https://")
            a = {**data, **{k: x.get().strip() for k, x in v.items() if k not in ("images", "iac_path")}, "name": name}
            a["notes"] = notes.get("1.0", "end").strip()
            a["scan_stages"] = [k for k in STAGES if stage_vars[k].get()]
            tp = a.get("target_path", "")
            paths = [p for p in data.get("static_paths") or [] if p != tp]
            a["static_paths"] = ([tp] if tp else []) + paths
            others = [s for s in data.get("container_sources") or [] if s.get("type") != "registry"]
            imgs = [x.strip() for x in re.split(r"[,\n;]+", v["images"].get()) if x.strip()]
            a["container_sources"] = [{"type": "registry", "value": x} for x in dict.fromkeys(imgs)] + others
            iac_first = v["iac_path"].get().strip()
            rest = [p for p in (data.get("iac_paths") or [])[1:] if p != iac_first]
            a["iac_paths"] = ([iac_first] if iac_first else []) + rest
            a["id"] = a.get("id") or _slugify(name)
            self._inv_store.save_app(a)
            popup.close()
            self._refresh_inventory()
            if self._apps_tree.winfo_exists() and self._apps_tree.exists(a["id"]):
                self._apps_tree.selection_set(a["id"])
                self._apps_tree.see(a["id"])
            self._show_app_detail(a)
            is_active = (self._active_app or {}).get("id") == a["id"]
            if auto.get() or is_active:
                self._load_app_profile(a, silent=True)
            self._toast(f"«{name}» guardada" + (" y cargada" if auto.get() or is_active else ""), "ok")
            if on_saved:
                on_saved(a)
        bar, status = self._popup_foot(popup, ("Cancelar", popup.close), ("Guardar", save), with_status=True)
        ToggleSwitch(bar.buttons[0].master, text="Cargar esta aplicación al guardar", variable=auto).pack(side="left")

    def _delete_selected_app(self):
        app = self._selected_app()
        if not app:
            return

        def delete():
            self._inv_store.delete_app(app["id"])
            if self._active_app and self._active_app.get("id") == app["id"]:
                self._close_app_tab(app["id"])
            self._refresh_inventory()
            self._show_app_detail(None)
            self._toast(f"«{app['name']}» eliminada", "info")
        self._show_confirm_popup("Eliminar aplicación", f"¿Eliminar «{app['name']}» del inventario?\n\nLos reportes ya "
                                 "generados se conservan en su carpeta.", on_yes=delete, yes_label="Eliminar",
                                 no_label="Cancelar")

    def _load_selected_app(self):
        if app := self._selected_app():
            self._load_app_profile(app)

    # ── Carga de la aplicación activa ───────────────────────────────────────
    def _load_app_profile(self, app: dict, *, silent: bool = False) -> None:
        self._active_app = app
        for key, var in (("target_path", self._target_var), ("dast_url", self._dast_url_var),
                         ("api_spec", self._api_spec_var)):
            var.set(app.get(key) or "")
        stages = app.get("scan_stages") or NO_APP_STAGES
        for k, var in self._scan_vars.items():
            var.set(k in stages)
        self._static_paths[:] = app.get("static_paths") or ([app["target_path"]] if app.get("target_path") else [])
        self._render_static_paths()
        if hasattr(self, "_container_sources"):
            self._container_sources[:] = [s for s in app.get("container_sources") or [] if isinstance(s, dict)]
            self._iac_paths[:] = [p for p in app.get("iac_paths") or [] if isinstance(p, str)]
            self._render_container_sources()
            self._render_iac_paths()
        self._refresh_scan_btn()
        if (aid := app.get("id")) and aid not in self._open_app_tabs:
            self._open_app_tabs.append(aid)
        self._last_app_id = app.get("id")
        self._refresh_active_app_banner()
        self._save_settings()
        self._refresh_inventory()
        self._show_app_detail(app)
        self._refresh_rep_tree()
        for hook in ("_refresh_engine_cards", "_refresh_engine_badge_text", "_paint_badges"):
            if callable(fn := getattr(self, hook, None)):
                try:
                    fn()
                except Exception as e:
                    self._emit_log(f"[apps] {hook}: {e!r}")
        if not silent:
            self._show_tab("scan")
            self._toast(f"Aplicación «{app['name']}» cargada", "ok")

    def _switch_app_tab(self, app_id: str) -> None:
        if self._active_app and self._active_app.get("id") == app_id:
            return
        if self._any_busy():
            return self._show_warn_popup("Cambiar de aplicación", "No se puede cambiar de aplicación mientras hay un "
                                         "escaneo en curso.\n\nEspere a que termine o deténgalo antes de cambiar.")
        if app := self._inv_store.get_app(app_id):
            self._load_app_profile(app, silent=True)
            self._toast(f"Aplicación «{app['name']}» cargada", "ok")
        else:
            self._open_app_tabs.remove(app_id)
            self._rebuild_app_tabs()

    def _close_app_tab(self, app_id: str) -> None:
        if self._any_busy():
            return self._show_warn_popup("Cerrar aplicación", "No se puede cerrar una aplicación mientras hay un "
                                         "escaneo en curso.")
        self._open_app_tabs[:] = [a for a in self._open_app_tabs if a != app_id]
        if self._active_app and self._active_app.get("id") == app_id:
            if self._open_app_tabs and (fb := self._inv_store.get_app(self._open_app_tabs[-1])):
                return self._load_app_profile(fb, silent=True)
            self._active_app = self._last_app_id = None
            self._apply_no_app_default_stages()
            self._refresh_scan_btn()
            for hook in ("_refresh_engine_cards", "_refresh_engine_badge_text"):
                if callable(fn := getattr(self, hook, None)):
                    fn()
        self._save_settings()
        self._rebuild_app_tabs()
        self._refresh_rep_tree()
        self._refresh_inventory()

    def _auto_load_last_app(self) -> None:
        self._open_app_tabs = [a for a in self._saved_open_app_ids if self._inv_store.get_app(a)]
        app = self._last_app_id and self._inv_store.get_app(self._last_app_id)
        if app:
            self._load_app_profile(app, silent=True)
            self._log_line(f"[apps] perfil recargado automáticamente: {app.get('name')}")
        else:
            if self._last_app_id:
                self._apply_no_app_default_stages()
                self._refresh_scan_btn()
            self._rebuild_app_tabs()

    def _refresh_active_app_banner(self) -> None:
        self._rebuild_app_tabs()
