from __future__ import annotations

import json
import threading
from datetime import datetime
from pathlib import Path
from typing import Optional

import test_servicenow_ticket as core
from report_engine import build_context

STORE_FILENAME = "servicenow_tickets.json"
_LOCK = threading.Lock()
_SEV = ("critical", "high", "medium", "low")


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _pl(n: int, one: str, many: str) -> str:
    return one if n == 1 else many


def _fmt(c: dict) -> str:
    return f"C{c.get('critical', 0)}/A{c.get('high', 0)}/M{c.get('medium', 0)}/B{c.get('low', 0)}"


def _hot(c: dict) -> bool:
    return bool((c or {}).get("critical") or (c or {}).get("high"))


def _summarize(target, version, parts: dict) -> dict:
    ctxs = {name: build_context(*args, target, version, **kw) for name, (args, kw) in parts.items()}
    return {"counts": {s: sum(int(c["counts"].get(s, 0) or 0) for c in ctxs.values()) for s in _SEV},
            "total": sum(c["total"] for c in ctxs.values()), "ctx": ctxs}


def summarize_static(sca_raw, code_raw, secrets_raw, target, snyk_version) -> dict:
    s = _summarize(target, snyk_version, {"sca": ((sca_raw, None), {}), "code": ((None, code_raw), {}),
                                          "sec": ((None, None), {"secrets_data": secrets_raw})})
    c = s.pop("ctx")
    s["services"] = {"sast_sca": _hot(c["sca"]["counts"]) or _hot(c["code"]["counts"]), "secretos": _hot(c["sec"]["counts"])}
    return s


def summarize_dynamic(dast_raw, api_raw, target, snyk_version) -> dict:
    s = _summarize(target, snyk_version, {"dast": ((None, None), {"dast_data": dast_raw}),
                                          "api": ((None, None), {"api_data": api_raw})})
    c = s.pop("ctx")
    s["services"] = {"dast": _hot(c["dast"]["counts"]), "api": _hot(c["api"]["counts"])}
    return s


def _delta(prev: dict, cur: dict) -> tuple[int, int]:
    return (sum(max((prev or {}).get(s, 0) - (cur or {}).get(s, 0), 0) for s in _SEV),
            sum(max((cur or {}).get(s, 0) - (prev or {}).get(s, 0), 0) for s in _SEV))


def _text_created(name: str, summary: dict) -> str:
    c, total = summary["counts"], summary.get("total", 0)
    crit, high = c.get("critical", 0), c.get("high", 0)
    return (f"Escaneo automático detectó {crit} {_pl(crit, 'vulnerabilidad crítica', 'vulnerabilidades críticas')} y "
            f"{high} {_pl(high, 'alta', 'altas')} en {name}. Se solicita revisión y remediación. Detalle: {_fmt(c)} sobre "
            f"{total} {_pl(total, 'hallazgo', 'hallazgos')} {_pl(total, 'total', 'totales')}.")


def _text_progress(name: str, prev: dict, cur: dict) -> str:
    rem, new = _delta(prev, cur)
    parts = [f"Re-escaneo de {name}: estado actual {_fmt(cur)}."]
    if rem:
        parts.append(f"Se {_pl(rem, 'remedió', 'remediaron')} {rem} {_pl(rem, 'hallazgo', 'hallazgos')} desde la última "
                     "actualización.")
    if new:
        parts.append(f"Se {_pl(new, 'detectó', 'detectaron')} {new} {_pl(new, 'hallazgo nuevo', 'hallazgos nuevos')}.")
    crit, high = cur.get("critical", 0), cur.get("high", 0)
    parts.append(f"Siguen pendientes {crit} {_pl(crit, 'crítica', 'críticas')} y {high} {_pl(high, 'alta', 'altas')}.")
    return " ".join(parts)


def _text_closed(name: str, opened: dict, cur: dict) -> str:
    rem, _ = _delta(opened, cur)
    med, low = cur.get("medium", 0), cur.get("low", 0)
    return (f"Re-escaneo de {name} ya no reporta vulnerabilidades críticas ni altas ({rem} "
            f"{_pl(rem, 'remediada', 'remediadas')} desde la apertura del ticket). Se cierra el seguimiento "
            f"automáticamente. Quedan {med} {_pl(med, 'media', 'medias')} y {low} {_pl(low, 'baja', 'bajas')} sin impacto "
            "en el gate.")


def _label(rec) -> str:
    return rec.get("ritm_number") or rec.get("request_number") or rec.get("sys_id", "")


def _create(key, kind, name, summary, app_name, environment, auth, hdrs, log) -> dict:
    services = [s for s, on in summary.get("services", {}).items() if on] or (["sast_sca"] if kind == "static" else ["dast"])
    overrides = {"repositorio_s": json.dumps([{"name": name}], ensure_ascii=False), "ruta_monorepo": "/"} \
        if kind == "static" and "secretos" in services else {}
    payload = core.build_payload(services, ambiente=environment, app_name=app_name or name,
                                 descripcion=_text_created(name, summary), overrides=overrides)
    row = core.send_request(f"{kind}:{name}", payload, auth, hdrs, dry_run=False, log=log)
    ok, now = row.get("status") in (200, 201), _now()
    rec = {"key": key, "kind": kind, "name": name, "app_name": app_name, "status": "open" if ok else "error",
           "sys_id": row.get("sys_id", ""), "request_number": row.get("request_number", ""), "ritm_sys_id": "",
           "ritm_number": "", "created_at": now, "updated_at": now, "opened_counts": dict(summary["counts"]),
           "last_counts": dict(summary["counts"]), "scans_since_open": 1,
           "history": [{"ts": now, "event": "created" if ok else "create_failed",
                        "note": _text_created(name, summary) if ok else row.get("error", "")}]}
    if ok and rec["sys_id"]:
        ritm = core.find_ritm_for_request(rec["sys_id"], auth, hdrs, log=log)
        rec["ritm_sys_id"], rec["ritm_number"] = ritm.get("ritm_sys_id", ""), ritm.get("ritm_number", "")
    log(f"[servicenow] ticket creado para {name}: {_label(rec)}" if ok else
        f"[servicenow] no se pudo crear el ticket para {name}: {row.get('error', '')[:200]}")
    return rec


def _touch(rec, summary, auth, hdrs, log, close: bool) -> None:
    cur = summary["counts"]
    note = _text_closed(rec["name"], rec.get("opened_counts", {}), cur) if close else \
        _text_progress(rec["name"], rec.get("last_counts", {}), cur)
    table = core.RITM_TABLE if rec.get("ritm_sys_id") else core.CANCEL_TABLE
    fields = {core.RESOLVE_STATE_FIELD: core.RESOLVE_STATE_VALUE, "close_notes": note} if close else {core.COMMENT_FIELD: note}
    ok = core.update_record(table, rec.get("ritm_sys_id") or rec.get("sys_id"), fields, auth, hdrs, log=log)
    rec.update(last_counts=dict(cur), updated_at=_now())
    if close and ok:
        rec.update(status="closed", closed_at=rec["updated_at"])
    if not close:
        rec["scans_since_open"] = rec.get("scans_since_open", 0) + 1
    event = ("closed" if close else "comment") + ("" if ok else "_failed")
    rec["history"] = (rec.get("history") or [])[-19:] + [{"ts": rec["updated_at"], "event": event, "note": note}]
    log(f"[servicenow] " + (("ticket cerrado" if ok else "no se pudo cerrar el ticket") + ":" if close else
                            "comentario agregado en" if ok else "no se pudo comentar") + f" {_label(rec)}")


def sync_ticket(reports_root, *, kind: str, name: str, summary: dict, app_name: str = "",
                environment: str = "Desarrollo", actor: str = "", log=print) -> Optional[dict]:
    name = (name or "").strip()
    if not name:
        log(f"[servicenow] sin nombre de {'repositorio' if kind == 'static' else 'aplicación'} — se omite ticket")
        return None
    auth_pair = core.get_auth_silent()
    key = f"{kind}:{name.lower()}"
    path = Path(reports_root) / STORE_FILENAME
    with _LOCK:
        try:
            store = json.loads(path.read_text(encoding="utf-8"))
            store.setdefault("tickets", {})
        except Exception:
            store = {"version": 1, "tickets": {}}
        rec = store["tickets"].get(key)
        hot = _hot(summary["counts"])
        is_open = bool(rec and rec.get("status") == "open")
        if auth_pair is None:
            if hot or is_open:
                log("[servicenow] sin credenciales guardadas — no se sincroniza el ticket (configure su usuario y "
                    "contraseña de ServiceNow en el aviso de configuración o en el ServiceNow Ticket Tester)")
            return rec
        auth, hdrs = auth_pair
        try:
            if is_open:
                _touch(rec, summary, auth, hdrs, log, close=not hot)
            elif hot:
                if rec and rec.get("status") == "closed":
                    log(f"[servicenow] {name}: vuelven a aparecer vulnerabilidades altas/críticas tras haberse cerrado "
                        f"el ticket anterior ({_label(rec)}) — se abre uno nuevo")
                rec = _create(key, kind, name, summary, app_name, environment, auth, hdrs, log)
        except Exception as e:
            log(f"[servicenow] error de sincronización, se continúa sin ticket: {e!r}")
        if rec is not None:
            store["tickets"][key] = rec
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(store, indent=2, ensure_ascii=False), encoding="utf-8")
        return rec


def public_view(rec: Optional[dict]) -> dict:
    if not rec:
        return {}
    return {"kind": rec.get("kind", ""), "name": rec.get("name", ""), "status": rec.get("status", ""),
            "number": rec.get("ritm_number") or rec.get("request_number") or "",
            "link": core.ritm_url(rec["ritm_sys_id"]) if rec.get("ritm_sys_id") else ""}
