"""static_scanner.py — unified Static-analysis engine + its GUI tab."""

from __future__ import annotations

import json, os, re, sys, shutil, subprocess, platform, tempfile, time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Optional


# ══ SCA + SAST (Snyk) ════════════════════════════════════════════════════════
# ── Platform flags ────────────────────────────────────────────────────────────
IS_WIN   = os.name == "nt"
IS_MAC   = sys.platform == "darwin"
IS_LINUX = not IS_WIN and not IS_MAC


def _augment_path() -> None:
    """The process PATH at launch is often stale or minimal (desktop launcher,
    a terminal opened before an installer updated the registry, etc.), so
    tools like node, npm, snyk, brew become invisible to shutil.which() even
    though they're on disk. Prepend the usual locations (only those that
    exist) so _which() finds them."""
    if IS_WIN:
        candidates = []
        local = os.environ.get("LOCALAPPDATA")
        if local:
            # Where this app's own Snyk CLI installers cache the binary
            # (both the legacy single-file location and the current
            # standalone-binary fallback's "bin" subfolder).
            candidates += [str(Path(local) / "snyk"), str(Path(local) / "snyk" / "bin")]
        appdata = os.environ.get("APPDATA")
        if appdata:
            # Default npm global prefix on Windows: `npm install -g <pkg>`
            # drops its .cmd/.ps1 shims here.
            candidates.append(str(Path(appdata) / "npm"))
        cur = os.environ.get("PATH", "")
        parts = cur.split(os.pathsep)
        extra = [c for c in candidates if c and c not in parts and os.path.isdir(c)]
        if extra:
            os.environ["PATH"] = os.pathsep.join(extra + parts)
        return
    home = Path.home()
    candidates = [
        "/opt/homebrew/bin", "/opt/homebrew/sbin",   # Apple-silicon Homebrew
        "/usr/local/bin", "/usr/local/sbin",          # Intel Homebrew / common
        str(home / ".local" / "bin"), str(home / "bin"),
        "/opt/local/bin",                             # MacPorts
        str(home / ".nvm" / "current" / "bin"),       # nvm symlink (if present)
    ]
    cur = os.environ.get("PATH", "")
    parts = cur.split(os.pathsep)
    extra = [c for c in candidates if c and c not in parts and os.path.isdir(c)]
    if extra:
        os.environ["PATH"] = os.pathsep.join(extra + parts)


_augment_path()



# ── Platform utils ────────────────────────────────────────────────────────────
def _which(cmd: str) -> Optional[str]:
    if (f := shutil.which(cmd)):
        return f
    if os.name == "nt":
        for ext in (".cmd", ".bat", ".exe"):
            if (f := shutil.which(cmd + ext)):
                return f
    return None


# On Windows, every console-subsystem child (snyk, git, winget, schtasks…)
# pops its own visible window even when the parent has none (pythonw.exe) —
# CREATE_NO_WINDOW is the flag that suppresses it. No-op elsewhere.
_NOWIN = {"creationflags": subprocess.CREATE_NO_WINDOW} if IS_WIN else {}


def _run(args, cwd=None, env=None, timeout=600) -> subprocess.CompletedProcess:
    return subprocess.run(
        args, cwd=str(cwd) if cwd else None,
        env=env if env is not None else os.environ.copy(),
        timeout=timeout, capture_output=True, text=True,
        encoding="utf-8", errors="replace", shell=False, **_NOWIN)


# Markers that indicate a TLS / corporate-proxy / binary-download failure
# rather than a normal scan result. Covers both hyphenated ("self-signed")
# and spaced ("self signed") spellings, plus Node's SELF_SIGNED_CERT_IN_CHAIN
# error code (lowercased: self_signed_cert_in_chain).
_TLS_ERROR_MARKERS = (
    "self-signed certificate", "self signed certificate", "self_signed_cert",
    "unable to verify", "unable to get local issuer", "cert_in_chain",
    "cert_has_expired", "err_tls", "certificate chain", "econnreset",
    "tunneling socket", "depth_zero_self_signed", "ssl",
)


def _looks_like_tls_error(text: str) -> bool:
    low = (text or "").lower()
    return any(m in low for m in _TLS_ERROR_MARKERS)


# Markers that mean "Snyk ran but you are not (validly) authenticated" — a
# stale/expired/invalid credential. Must be distinguished from a clean scan:
# Snyk emits {"ok": false, "error": "Use `snyk auth` to authenticate."} which
# otherwise parses as valid JSON with zero vulnerabilities (a false clean).
_AUTH_ERROR_MARKERS = (
    "use `snyk auth`", "use 'snyk auth'", "snyk auth` to authenticate",
    "snyk auth' to authenticate", "not authenticated", "must be authenticated",
    "authentication error", "unauthorized", "token is invalid",
    "invalid auth", "re-authenticate", "401",
)


def _looks_like_auth_error(text: str) -> bool:
    low = (text or "").lower()
    return any(m in low for m in _AUTH_ERROR_MARKERS)


def _find_ca_bundle() -> Optional[str]:
    """Locate a corporate CA bundle the user (or their MDM/IT) may already
    have configured, so we can verify the proxy's cert *properly* instead of
    disabling verification. Checked in priority order; the first existing,
    non-empty file wins."""
    for var in ("NODE_EXTRA_CA_CERTS", "SSL_CERT_FILE",
                "REQUESTS_CA_BUNDLE", "CURL_CA_BUNDLE", "SNYK_CA_BUNDLE"):
        p = os.environ.get(var)
        if p and Path(p).is_file() and Path(p).stat().st_size > 0:
            return p
    return None


def _export_windows_ca_bundle(log: Callable[[str], None]) -> Optional[str]:
    """On Windows, the corporate root/intermediate CA almost always lives in
    the system certificate store (pushed by GPO) even when no *_CA_CERTS env
    var is set. Export the machine ROOT + CA stores to a PEM bundle so Node /
    Snyk can trust the proxy chain without turning verification off."""
    if not IS_WIN:
        return None
    out = Path(tempfile.gettempdir()) / "bbscanner_corp_ca.pem"
    if out.exists() and out.stat().st_size > 0:
        return str(out)
    # PowerShell: dump every cert in LocalMachine\Root and \CA as base64 PEM.
    ps = (
        "$ErrorActionPreference='SilentlyContinue';"
        "$o=@();"
        "foreach($s in 'Root','CA'){"
        "  Get-ChildItem \"Cert:\\LocalMachine\\$s\" | ForEach-Object {"
        "    $b=[Convert]::ToBase64String($_.RawData,'InsertLineBreaks');"
        "    $o+=\"-----BEGIN CERTIFICATE-----`n$b`n-----END CERTIFICATE-----\"}};"
        f"$o -join \"`n\" | Out-File -FilePath '{out}' -Encoding ascii"
    )
    try:
        r = _run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps],
                 timeout=120)
        if out.exists() and out.stat().st_size > 0 and "BEGIN CERTIFICATE" in \
                out.read_text(encoding="ascii", errors="ignore"):
            log(f"[tls] exported Windows cert store → {out}")
            return str(out)
        if r.stderr:
            log(f"[tls] could not export Windows cert store: {r.stderr.strip()[:200]}")
    except Exception as e:
        log(f"[tls] cert-store export failed: {e!r}")
    return None


def _run_tls(args, cwd=None, timeout=900,
             log: Callable[[str], None] = lambda _: None) -> subprocess.CompletedProcess:
    """Run a Node/Snyk command, retrying through a corporate TLS-inspecting
    proxy: first with a discovered/exported CA bundle (secure), then — only
    if that still fails — with verification disabled (insecure, logged)."""
    env = os.environ.copy()
    log(f"$ {' '.join(args)}")
    r = _run(args, cwd=cwd, env=env, timeout=timeout)
    combined = (r.stdout or "") + (r.stderr or "")
    if r.returncode != 0 and _looks_like_tls_error(combined):
        ca = _find_ca_bundle() or _export_windows_ca_bundle(log)
        if ca:
            log(f"[tls-retry] retrying with NODE_EXTRA_CA_CERTS={ca}")
            env2 = os.environ.copy(); env2["NODE_EXTRA_CA_CERTS"] = ca
            r = _run(args, cwd=cwd, env=env2, timeout=timeout)
            if r.returncode == 0 or not _looks_like_tls_error((r.stdout or "") + (r.stderr or "")):
                return r
        log("[tls-retry] CA bundle unavailable/insufficient — retrying with "
            "TLS verification DISABLED (NODE_TLS_REJECT_UNAUTHORIZED=0). "
            "This is a local workaround for the proxy cert only.")
        env["NODE_TLS_REJECT_UNAUTHORIZED"] = "0"
        r = _run(args, cwd=cwd, env=env, timeout=timeout)
    return r


# The npm `snyk` wrapper downloads its real binary on first use; that download
# runs in a child Node process that inherits THIS process's environment. So the
# most reliable fix for a TLS-inspecting proxy is to put the workaround into
# os.environ ONCE — then every snyk invocation (wrapper download, auth, scan)
# picks it up automatically, with no per-call retry needed.
_TLS_ENV_READY = False


def setup_proxy_tls_env(log: Callable[[str], None] = lambda _: None,
                        prefer_insecure: bool = False) -> str:
    """Configure os.environ so Node/Snyk can talk through a corporate proxy.
    Returns the mode applied: 'ca-bundle', 'insecure', or 'preset' (the user
    already had something configured). Idempotent — safe to call repeatedly."""
    global _TLS_ENV_READY
    # Respect an existing, working configuration unless we're escalating.
    if not prefer_insecure:
        if os.environ.get("NODE_TLS_REJECT_UNAUTHORIZED") == "0":
            _TLS_ENV_READY = True; return "preset"
        if os.environ.get("NODE_EXTRA_CA_CERTS") and \
                Path(os.environ["NODE_EXTRA_CA_CERTS"]).is_file():
            _TLS_ENV_READY = True; return "preset"
        ca = _find_ca_bundle() or _export_windows_ca_bundle(log)
        if ca:
            os.environ["NODE_EXTRA_CA_CERTS"] = ca
            log(f"[tls] trusting corporate proxy via NODE_EXTRA_CA_CERTS={ca}")
            _TLS_ENV_READY = True; return "ca-bundle"
    # Escalation / no CA available: disable Node TLS verification for our
    # child processes only (Python's own TLS is unaffected by this Node var).
    os.environ["NODE_TLS_REJECT_UNAUTHORIZED"] = "0"
    os.environ.pop("NODE_EXTRA_CA_CERTS", None)
    log("[tls] disabling Node TLS verification (NODE_TLS_REJECT_UNAUTHORIZED=0) "
        "so the Snyk CLI can run behind the proxy. Scoped to this app's child "
        "processes; set NODE_EXTRA_CA_CERTS to your company CA for the secure "
        "alternative.")
    _TLS_ENV_READY = True
    return "insecure"


# Cache de resultado de `snyk --version`: el binario no cambia durante la sesión.
# El boot loader ya lo verifica en splash; `ensure_snyk_ready` (llamado antes de
# abrir el browser de auth) lo reutiliza del caché → elimina el timeout de 30 s
# (y hasta 180 s en reintentos) que causaba el minuto de espera antes del browser.
_SNYK_WORKS_CACHE: tuple[bool, str] | None = None
_SNYK_WORKS_CACHE_AT: float = 0.0
_SNYK_WORKS_CACHE_TTL: float = 300.0  # 5 minutos


def _snyk_works(timeout: int = 90) -> tuple[bool, str]:
    """True iff `snyk --version` actually returns a version — i.e. the binary
    exists AND can start (the wrapper's one-time download didn't fail). A snyk
    on PATH whose binary download is blocked will NOT pass this check.
    Result is cached for 5 minutes to avoid repeated slow subprocess calls."""
    global _SNYK_WORKS_CACHE, _SNYK_WORKS_CACHE_AT
    now = time.time()
    if _SNYK_WORKS_CACHE is not None and (now - _SNYK_WORKS_CACHE_AT) < _SNYK_WORKS_CACHE_TTL:
        return _SNYK_WORKS_CACHE
    sb = _which("snyk")
    if not sb:
        result = False, "Snyk CLI not found on PATH"
        _SNYK_WORKS_CACHE, _SNYK_WORKS_CACHE_AT = result, now
        return result
    try:
        r = _run([sb, "--version"], timeout=timeout)
        if r.returncode == 0 and re.search(r"\d+\.\d+\.\d+", r.stdout or ""):
            result = True, (r.stdout or "").strip().splitlines()[0][:60]
        else:
            detail = ((r.stdout or "") + (r.stderr or "")).strip()
            result = False, detail[:300] or f"exit code {r.returncode}"
    except Exception as e:
        result = False, repr(e)
    # Solo cachear resultados positivos — si falló, permitir reintento pronto
    if result[0]:
        _SNYK_WORKS_CACHE, _SNYK_WORKS_CACHE_AT = result, now
    return result


def ensure_snyk_ready(log: Callable[[str], None]) -> bool:
    """Guarantee a *runnable* Snyk CLI, repairing the common corporate failure
    where the npm wrapper is installed but its binary download is blocked by a
    TLS-inspecting proxy's self-signed certificate.

    Strategy (each step only runs if the previous didn't fix it):
      1. Apply the proxy TLS workaround to os.environ, then re-test — this lets
         the wrapper complete its blocked one-time binary download.
      2. Escalate to disabling TLS verification, re-test.
      3. Bypass the npm wrapper entirely by installing Snyk's standalone binary
         (downloaded via Python, which tolerates the proxy cert), then re-test.
    """
    ok, detail = _snyk_works(timeout=30)
    if ok:
        log(f"[snyk] CLI ready ({detail})")
        return True
    log(f"[snyk] CLI present but not runnable yet: {detail}")

    # Step 1 — apply TLS workaround (CA bundle preferred) and let the wrapper
    # finish downloading its binary.
    mode = setup_proxy_tls_env(log)
    ok, detail = _snyk_works(timeout=180)
    if ok:
        log(f"[snyk] CLI ready after TLS setup [{mode}] ({detail})")
        return True

    # Step 2 — escalate to insecure if we tried a CA bundle first.
    if mode == "ca-bundle":
        setup_proxy_tls_env(log, prefer_insecure=True)
        ok, detail = _snyk_works(timeout=180)
        if ok:
            log(f"[snyk] CLI ready after disabling TLS verification ({detail})")
            return True

    # Step 3 — bypass the wrapper with the standalone binary.
    log("[snyk] repairing by installing the standalone Snyk binary "
        "(bypasses the npm wrapper's blocked download)…")
    if _install_standalone_snyk(log):
        ok, detail = _snyk_works(timeout=180)
        if ok:
            log(f"[snyk] standalone CLI ready ({detail})")
            return True
        log(f"[snyk] standalone CLI still not runnable: {detail}")
    log("[snyk] could not get a runnable Snyk CLI automatically. If your "
        "network uses a TLS-inspecting proxy, ask IT for the root CA .pem and "
        "set NODE_EXTRA_CA_CERTS to it, then retry.")
    return False


# ── Package-manager / tool resolvers ──────────────────────────────────────────
def _brew() -> Optional[str]:
    """Locate Homebrew even when it's not on the (possibly minimal) PATH."""
    if p := shutil.which("brew"):
        return p
    for cand in ("/opt/homebrew/bin/brew", "/usr/local/bin/brew"):
        if Path(cand).exists():
            return cand
    return None


def _snyk_bin() -> str:
    """Resolved snyk executable (snyk.cmd on Windows), falling back to 'snyk'."""
    return _which("snyk") or "snyk"


def _linux_pkg_mgr() -> Optional[tuple[str, list[str]]]:
    """Return (manager, install-prefix-args) for the host Linux distro."""
    if shutil.which("apt-get"):
        return "apt-get", ["apt-get", "install", "-y"]
    if shutil.which("dnf"):
        return "dnf", ["dnf", "install", "-y"]
    if shutil.which("yum"):
        return "yum", ["yum", "install", "-y"]
    if shutil.which("zypper"):
        return "zypper", ["zypper", "--non-interactive", "install"]
    if shutil.which("pacman"):
        return "pacman", ["pacman", "-S", "--noconfirm"]
    return None


def _sudo_prefix() -> list[str]:
    """Non-interactive sudo prefix when needed and available, else empty."""
    if os.geteuid() == 0 if hasattr(os, "geteuid") else False:
        return []
    if shutil.which("sudo"):
        return ["sudo", "-n"]   # -n: never prompt; fail fast if a password is required
    return []


def _download_file(url: str, dest: Path, log: Callable[[str], None],
                   timeout: int = 120) -> bool:
    """GET `url` to `dest`. Falls back to an unverified TLS context when the
    chain fails *only* on certificate validation (e.g. a corporate
    TLS-inspecting proxy that mints CA certs with Basic Constraints not
    marked critical — OpenSSL 3.x rejects those even though the proxy's
    presence, not the download target, is the real source of mistrust).
    The fallback never widens what's downloaded — same fixed, hard-coded
    host — it just stops a misconfigured local MITM cert from blocking it."""
    import ssl, urllib.error, urllib.request
    req = urllib.request.Request(url, headers={"User-Agent": "vuln-scanner/1.0"})
    try:
        log(f"[download] {url}")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:  # nosec - fixed host
                data = resp.read()
        except urllib.error.URLError as e:
            if isinstance(e.reason, ssl.SSLCertVerificationError):
                log(f"[download] TLS verify failed ({e.reason}); "
                    f"retrying without cert verification (fixed host only)…")
                ctx = ssl._create_unverified_context()
                with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:  # nosec - fixed host
                    data = resp.read()
            else:
                raise
        if not data:
            log("[download] empty response"); return False
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        log(f"[download] saved {len(data)//1024} KB → {dest}")
        return True
    except Exception as e:
        log(f"[download] failed: {e!r}")
        return False


def _standalone_snyk_asset() -> Optional[str]:
    """Asset name for Snyk's npm-free standalone CLI binary for this host."""
    arch = (platform.machine() or "").lower()
    is_arm = arch in ("arm64", "aarch64")
    if IS_WIN:
        return "snyk-win.exe"
    if IS_MAC:
        return "snyk-macos-arm64" if is_arm else "snyk-macos"
    # Linux: detect musl (Alpine) vs glibc.
    if Path("/etc/alpine-release").exists():
        return "snyk-alpine-arm64" if is_arm else "snyk-alpine"
    return "snyk-linux-arm64" if is_arm else "snyk-linux"


def _install_standalone_snyk(log: Callable[[str], None]) -> bool:
    """Universal npm-free fallback: download the official Snyk CLI binary to
    ~/.local/bin (or %LOCALAPPDATA% on Windows) and make it executable."""
    asset = _standalone_snyk_asset()
    if not asset:
        return False
    if IS_WIN:
        bindir = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "snyk" / "bin"
        target = bindir / "snyk.exe"
    else:
        bindir = Path.home() / ".local" / "bin"
        target = bindir / "snyk"
    if target.exists() and target.stat().st_size > 1024:
        log(f"[snyk] standalone CLI already cached → {target}")
        os.environ["PATH"] = str(bindir) + os.pathsep + os.environ.get("PATH", "")
        return True
    url = f"https://static.snyk.io/cli/latest/{asset}"
    log(f"[snyk] installing standalone CLI ({asset})…")
    if not _download_file(url, target, log, timeout=180):
        return False
    if not IS_WIN:
        try: os.chmod(target, 0o755)
        except Exception: pass
    # Make sure the freshly-installed binary is visible to this process now.
    os.environ["PATH"] = str(bindir) + os.pathsep + os.environ.get("PATH", "")
    if _which("snyk"):
        log(f"[snyk] standalone CLI ready → {target}")
        return True
    log(f"[snyk] installed to {target}, but {bindir} is not on PATH. "
        f"Add it to your shell profile (e.g. export PATH=\"{bindir}:$PATH\").")
    return target.exists()


# ── Environment checks ────────────────────────────────────────────────────────
@dataclass
class CheckResult:
    name: str; ok: bool; detail: str = ""; fixable: bool = False


def check_python() -> CheckResult:
    v = sys.version_info
    return CheckResult("Python ≥ 3.9",
                       (v.major, v.minor) >= (3, 9),
                       f"Python {v.major}.{v.minor}.{v.micro}")


def _check_tool(label: str, cmd: str) -> CheckResult:
    resolved = _which(cmd)
    if not resolved:
        return CheckResult(label, False, "not found in PATH", fixable=True)
    try:
        r = _run([resolved, "--version"])
        return CheckResult(label, r.returncode == 0,
                           (r.stdout or "").strip(), fixable=True)
    except Exception as e:
        return CheckResult(label, False, str(e), fixable=True)


def check_node() -> CheckResult: return _check_tool("Node.js", "node")
def check_npm()  -> CheckResult: return _check_tool("npm", "npm")


def tool_present(cmd: str) -> bool:
    """Cheap presence-only check: a PATH lookup, no subprocess spawn. Used by
    the launcher's boot-cache fast path to avoid paying the `--version` spawn
    cost (what _check_tool/_snyk_works actually do) on every single launch
    once a tool has already been verified working. Weaker than check_node()/
    check_npm()/check_snyk() — a tool can be on PATH but broken (see
    check_snyk()'s docstring) — so this is only meant for the fast-path re-
    verification, not as a replacement for the real checks."""
    return _which(cmd) is not None


def check_snyk() -> CheckResult:
    """Snyk is only 'OK' if it actually RUNS. The npm wrapper can sit on PATH
    while its real binary download is blocked by a proxy cert — that must read
    as not-ready (and fixable), not as installed."""
    if not _which("snyk"):
        return CheckResult("Snyk CLI", False, "not found in PATH", fixable=True)
    ok, detail = _snyk_works(timeout=30)
    if ok:
        return CheckResult("Snyk CLI", True, detail, fixable=True)
    if _looks_like_tls_error(detail) or "download" in detail.lower() \
            or "ENOENT" in detail or "exit code" in detail:
        return CheckResult("Snyk CLI", False,
                           "present but can't start (proxy/cert blocks its "
                           "download) — click Fix", fixable=True)
    return CheckResult("Snyk CLI", False, detail[:120], fixable=True)



# ── Snyk configstore fast-path ────────────────────────────────────────────────
# `snyk config get <key>` spawns a full Node.js process (~1-3 s startup each).
# For auth checks that run at startup and after every login, that becomes
# visibly slow (2-6 s for SSO users who hit 2 keys). Reading the configstore
# JSON directly cuts that to <1 ms. We fall back to the CLI only if the file
# can't be found (rare: non-standard install or config path override).

_CFG_FILE_SEARCHED: bool = False   # have we done the one-time path search?
_CFG_FILE_PATH:     str  = ""      # "" = searched but not found; else the path
_CFG_CACHE:         dict = {}      # parsed JSON, refreshed on mtime change
_CFG_CACHE_MTIME:   float = 0.0


def _snyk_configstore_path() -> str:
    """Locate Snyk's configstore JSON without running the CLI (one-time search)."""
    global _CFG_FILE_SEARCHED, _CFG_FILE_PATH
    if _CFG_FILE_SEARCHED:
        return _CFG_FILE_PATH
    _CFG_FILE_SEARCHED = True
    candidates: list[Path] = []
    if sys.platform == "win32":
        for env_key in ("APPDATA", "LOCALAPPDATA"):
            base = os.environ.get(env_key, "")
            if base:
                candidates.append(Path(base) / "configstore" / "snyk.json")
    home = Path.home()
    candidates += [
        home / ".config" / "configstore" / "snyk.json",
        home / ".snyk" / "config.json",
    ]
    for p in candidates:
        try:
            if p.exists():
                _CFG_FILE_PATH = str(p)
                return _CFG_FILE_PATH
        except Exception:
            continue
    _CFG_FILE_PATH = ""
    return ""


def _snyk_cfg_from_file(key: str) -> str | None:
    """Read a config key from the Snyk JSON file.
    Returns the value string (non-empty) if the file was found AND the key has a value.
    Returns None in ALL other cases (file not found, key absent, parse error) so
    the caller always falls back to `snyk config get` when the answer is not certain.
    Returning "" for absent keys was the bug that prevented the subprocess fallback."""
    global _CFG_CACHE, _CFG_CACHE_MTIME
    try:
        path = _snyk_configstore_path()
        if not path:
            return None          # file not found → caller tries subprocess
        mtime = os.path.getmtime(path)
        if not _CFG_CACHE or abs(mtime - _CFG_CACHE_MTIME) > 0.01:
            _CFG_CACHE      = json.loads(Path(path).read_text(encoding="utf-8"))
            _CFG_CACHE_MTIME = mtime
        v = _CFG_CACHE.get(key)
        if v is None:
            return None          # key absent → subprocess may find it elsewhere
        sv = str(v)
        if sv.lower() in ("", "undefined", "null", "not set"):
            return None          # key exists but empty → treat as absent
        return sv               # key present and non-empty → trust it
    except Exception:
        return None             # any error → fall back to subprocess


def _snyk_cfg(key: str) -> str:
    # Fast path: read directly from configstore JSON (avoids Node.js startup per call)
    fast = _snyk_cfg_from_file(key)
    if fast is not None:
        return fast
    # Slow fallback: shell out to snyk CLI (only when file isn't found)
    try:
        v = (_run([_snyk_bin(), "config", "get", key]).stdout or "").strip()
        return "" if v.lower() in ("", "undefined", "null", "not set") else v
    except Exception:
        return ""


def _snyk_cred_kind() -> str:
    """What credential is configured locally (for labelling only)."""
    # Try all three keys in a single file read (cache hit after the first call).
    if _snyk_cfg("api"):
        return "token"
    if _snyk_cfg("INTERNAL_OAUTH_TOKEN_STORAGE") or _snyk_cfg("oauth_token"):
        return "SSO/OAuth"
    return ""


def _extract_access_token(val) -> str:
    """Pull the bearer access token out of a Snyk OAuth credential. The
    INTERNAL_OAUTH_TOKEN_STORAGE value may be a dict, a JSON-encoded string
    ({"access_token": "...", "token_type": "Bearer", ...}), or already a bare
    token string."""
    if not val:
        return ""
    if isinstance(val, dict):
        return str(val.get("access_token") or val.get("token") or "").strip()
    s = str(val).strip()
    if s.startswith("{"):
        try:
            d = json.loads(s)
            return str(d.get("access_token") or d.get("token") or "").strip()
        except Exception:
            return ""
    return s


def get_snyk_token(log: Callable[[str], None] = lambda *_: None) -> str:
    """Return the Snyk credential to REUSE for Snyk API & Web (Probely) scans.

    The app authenticates to Snyk via SSO, so there is no separate Probely API
    key — we reuse the same credential the CLI already stored. Preference order:
      1. the SSO/OAuth access token (INTERNAL_OAUTH_TOKEN_STORAGE),
      2. a legacy oauth_token,
      3. a manual `api` token (non-SSO fallback).
    Returns "" if nothing is configured (caller treats that as 'not signed in')."""
    # Read the OAuth blob straight from the configstore so we get the real JSON
    # object (str() of a dict is not valid JSON).
    val = None
    try:
        path = _snyk_configstore_path()
        if path:
            data = json.loads(Path(path).read_text(encoding="utf-8"))
            val = data.get("INTERNAL_OAUTH_TOKEN_STORAGE")
    except Exception:
        val = None
    if val is None:
        val = _snyk_cfg("INTERNAL_OAUTH_TOKEN_STORAGE") or None
    tok = _extract_access_token(val)
    if tok:
        return tok
    for key in ("oauth_token", "api"):
        v = _snyk_cfg(key)
        if v:
            return v.strip()
    return ""


def get_snyk_auth_scheme() -> str:
    """HTTP Authorization scheme matching the reused credential. SSO/OAuth access
    tokens are bearer tokens; a manual API key uses Probely's historical 'JWT'
    scheme."""
    if _snyk_cfg("INTERNAL_OAUTH_TOKEN_STORAGE") or _snyk_cfg("oauth_token"):
        return "Bearer"
    return "JWT"


# The cloud DAST/API scanner authenticates to Probely with a SEPARATE, per-user
# API key (generated in plus.probely.app → Settings → API Keys), NOT the Snyk
# CLI/SSO token. This is the single in-process source of truth for that key.
# The GUI loads it from settings at startup (set_probely_key) and reads it back
# wherever a DastConfig/ApiConfig is built (get_probely_key). Probely's API keys
# are always sent with the 'JWT' Authorization scheme.
_PROBELY_KEY: str = ""


def set_probely_key(key: str) -> None:
    """Set the in-process Probely API key (called by the GUI from settings or
    after the user pastes/validates a key). Whitespace is stripped; a blank
    value clears it (treated as 'not configured')."""
    global _PROBELY_KEY
    _PROBELY_KEY = (key or "").strip()


def get_probely_key() -> str:
    """Return the user's Probely API key, or '' if none is configured."""
    return _PROBELY_KEY


def get_probely_auth_scheme() -> str:
    """Probely API keys are always sent as 'Authorization: JWT <key>'."""
    return "JWT"


def check_auth() -> CheckResult:
    """Report whether a Snyk credential is configured locally.

    We deliberately DON'T probe the server here (the only purpose-built check,
    `snyk whoami`, is experimental and unreliable across versions). Whether the
    credential actually WORKS is verified for real at scan time: a stale/expired
    token makes the scan emit an auth error, which the scanner detects and turns
    into a clear 're-login' prompt. So the panel just reflects presence; the
    scan is the source of truth."""
    if not _which("snyk"):
        return CheckResult("Snyk auth", False, "Snyk CLI missing", fixable=True)
    kind = _snyk_cred_kind()
    if kind:
        return CheckResult("Snyk auth", True, f"{kind} configured", fixable=True)
    return CheckResult("Snyk auth", False, "not authenticated", fixable=True)


def clear_snyk_credentials(log: Callable[[str], None]) -> None:
    """Remove any locally-stored Snyk credential so the next `snyk auth` starts
    clean. Critical for orgs on SSO: a leftover manual API token takes
    precedence over OAuth in the CLI, so an expired token keeps breaking scans
    even after the user signs in through SSO. Clearing it lets SSO take over.

    Fast path: modifies the configstore JSON directly (instant I/O vs 3×
    subprocess calls that each pay the Node.js startup cost ≈ 1-3 s each).
    Falls back to `snyk config unset` if the file can't be written."""
    _CRED_KEYS = ("api", "INTERNAL_OAUTH_TOKEN_STORAGE", "oauth_token")
    path = _snyk_configstore_path()
    if path:
        try:
            data = json.loads(Path(path).read_text(encoding="utf-8"))
            changed = False
            for key in _CRED_KEYS:
                if key in data:
                    del data[key]
                    changed = True
            if changed:
                Path(path).write_text(
                    json.dumps(data, indent=2, ensure_ascii=False),
                    encoding="utf-8",
                )
                # Invalidate the in-memory cache so the next _snyk_cfg call
                # re-reads the now-modified file.
                global _CFG_CACHE, _CFG_CACHE_MTIME
                _CFG_CACHE = {}
                _CFG_CACHE_MTIME = 0.0
            log("[auth] cleared stored Snyk credentials (direct file update) — "
                "starting a fresh sign-in through your organization's SSO.")
            return
        except Exception as exc:
            log(f"[auth] direct file clear failed ({exc!r}), falling back to CLI.")
    # Slow fallback: subprocess per key (3 × Node.js startup ≈ 3-9 s)
    for key in _CRED_KEYS:
        try:
            _run([_snyk_bin(), "config", "unset", key], timeout=20)
        except Exception:
            pass
    log("[auth] cleared stored Snyk credentials — starting a fresh sign-in "
        "through your organization's SSO.")


# ── Installers ────────────────────────────────────────────────────────────────
def install_node(log: Callable[[str], None]) -> bool:
    if _which("node") and _which("npm"):
        log("[node] already installed"); return True

    if IS_WIN:
        if not _which("winget"):
            log("[node] install Node.js LTS from https://nodejs.org/"); return False
        log("[node] installing via winget (source: winget, not msstore)…")
        r = _run(["winget", "install", "--id", "OpenJS.NodeJS.LTS", "-e",
                  "--source", "winget", "--silent", "--accept-package-agreements",
                  "--accept-source-agreements"], timeout=1800)
        log((r.stdout or "") + (r.stderr or ""))
        return r.returncode == 0

    if IS_MAC:
        brew = _brew()
        if not brew:
            log("[node] Homebrew not found. Install it from https://brew.sh "
                "then re-run, or install Node.js LTS from https://nodejs.org/.")
            return False
        log("[node] installing via Homebrew (brew install node)…")
        r = _run([brew, "install", "node"], timeout=1800)
        if r.stdout: log(r.stdout.strip()[-2000:])
        if r.stderr: log(r.stderr.strip()[-2000:])
        _augment_path()
        return _which("node") is not None and _which("npm") is not None

    # Linux
    mgr = _linux_pkg_mgr()
    if not mgr:
        log("[node] no supported package manager found. Install Node.js LTS via "
            "your distro or nvm (https://github.com/nvm-sh/nvm).")
        return False
    name, install_args = mgr
    # Debian/Ubuntu ship the binary as 'nodejs'; most distros also provide 'npm'.
    pkgs = ["nodejs", "npm"] if name in ("apt-get", "dnf", "yum") else ["nodejs", "npm"]
    sudo = _sudo_prefix()
    if name == "apt-get":
        log("[node] apt-get update…")
        _run(sudo + ["apt-get", "update"], timeout=600)
    log(f"[node] installing via {name} ({' '.join(pkgs)})…")
    r = _run(sudo + install_args + pkgs, timeout=1800)
    if r.stdout: log(r.stdout.strip()[-2000:])
    if r.stderr: log(r.stderr.strip()[-2000:])
    if r.returncode != 0 and sudo and "-n" in sudo:
        log("[node] automatic install needs elevated rights. Run manually:\n"
            f"    sudo {' '.join(install_args + pkgs)}")
    _augment_path()
    return _which("node") is not None and _which("npm") is not None


def install_snyk(log: Callable[[str], None]) -> bool:
    # Apply the proxy TLS workaround up front so any download below (npm
    # wrapper binary, standalone binary) can actually complete.
    setup_proxy_tls_env(log)

    # A snyk may already be on PATH. If it RUNS, we're done; if it's the
    # wrapper-with-blocked-download case, repair it instead of declaring victory.
    if _which("snyk"):
        ok, _ = _snyk_works(timeout=30)
        if ok:
            log("[snyk] already installed and runnable"); return True
        log("[snyk] found on PATH but not runnable — repairing…")
        if ensure_snyk_ready(log):
            return True
        log("[snyk] repair did not succeed; attempting a fresh install…")

    # Preferred path: npm (works on every OS when Node is present).
    if _which("npm"):
        npm = "npm.cmd" if IS_WIN else "npm"
        log("[snyk] npm install -g snyk")
        r = _run_tls([npm, "install", "-g", "snyk"], log=log, timeout=1800)
        if r.stdout: log(r.stdout)
        if r.stderr: log(r.stderr)
        _augment_path()
        if _which("snyk") and ensure_snyk_ready(log):
            return True
        log("[snyk] npm install did not yield a runnable 'snyk'; trying fallback…")

    # No npm (or it failed): use a native package manager where possible.
    if IS_MAC and _brew():
        brew = _brew()
        log("[snyk] installing via Homebrew (brew install snyk-cli)…")
        r = _run([brew, "install", "snyk-cli"], timeout=1800)
        if r.returncode != 0:                      # older tap name
            r = _run([brew, "install", "snyk"], timeout=1800)
        if r.stdout: log(r.stdout.strip()[-2000:])
        if r.stderr: log(r.stderr.strip()[-2000:])
        _augment_path()
        if _which("snyk") and ensure_snyk_ready(log):
            return True

    if IS_WIN and _which("winget"):
        log("[snyk] installing via winget (Snyk.SnykCLI, source: winget, not msstore)…")
        r = _run(["winget", "install", "--id", "Snyk.SnykCLI", "-e",
                  "--source", "winget", "--silent",
                  "--accept-package-agreements", "--accept-source-agreements"],
                 timeout=1800)
        log((r.stdout or "") + (r.stderr or ""))
        _augment_path()
        if _which("snyk") and ensure_snyk_ready(log):
            return True

    # Universal npm-free fallback: official standalone binary, then verify.
    log("[snyk] falling back to the standalone Snyk CLI binary…")
    if _install_standalone_snyk(log):
        return ensure_snyk_ready(log)
    return False


def start_snyk_auth(log: Callable[[str], None]) -> subprocess.Popen:
    setup_proxy_tls_env(log)   # auth also traverses the proxy
    log("[auth] launching `snyk auth` — browser will open shortly.")
    kwargs: dict = {}
    if IS_WIN:
        # New process group so we can later send it a CTRL_BREAK_EVENT to
        # cancel, OR'd with CREATE_NO_WINDOW so it doesn't also flash a
        # console — the two are independent bit flags.
        kwargs["creationflags"] = (subprocess.CREATE_NEW_PROCESS_GROUP |
                                    subprocess.CREATE_NO_WINDOW)  # type: ignore[attr-defined]
    # Disabling analytics removes a network round-trip the CLI otherwise makes
    # on start-up, so it prints the auth URL (and we open the browser) sooner.
    env = dict(os.environ)
    env.setdefault("SNYK_DISABLE_ANALYTICS", "1")
    env.setdefault("DISABLE_ANALYTICS", "1")
    return subprocess.Popen([_snyk_bin(), "auth"],
                            stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True,
                            encoding="utf-8", errors="replace",
                            env=env,
                            **kwargs)


# ── JSON helpers ──────────────────────────────────────────────────────────────
def _parse_json_loose(stdout: str) -> Any:
    if not stdout or not stdout.strip():
        return None
    try:
        return json.loads(stdout)
    except json.JSONDecodeError:
        docs = []
        for line in stdout.splitlines():
            line = line.strip()
            if line:
                try: docs.append(json.loads(line))
                except json.JSONDecodeError: pass
        return docs or None


def _count_vulns(data: Any) -> int:
    projects = (data if isinstance(data, list) else [data]) if data else []
    return sum(
        len((p or {}).get("vulnerabilities") or [])
        for p in projects if isinstance(p, dict))


def _looks_like_result(it: Any) -> bool:
    """True if a parsed item is a genuine scan RESULT (not an error envelope).
    Snyk returns ok:false when vulnerabilities ARE found, so ok alone can't be
    used — we look for the shapes a real result carries."""
    if not isinstance(it, dict):
        return False
    return (it.get("ok") is True
            or "vulnerabilities" in it
            or "dependencyCount" in it
            or "packageManager" in it
            or "uniqueCount" in it
            or "runs" in it)            # snyk code SARIF shape


def _error_envelope_msg(data: Any) -> str:
    """Return the error message if `data` is ONLY a Snyk error envelope
    ({"ok": false, "error": "..."}) with no real result anywhere — e.g.
    "Snyk was unable to find supported files." on an empty/unsupported target.
    Returns "" when at least one genuine result is present (partial success on
    --all-projects) or when there's no error envelope. Auth errors are handled
    separately upstream and are excluded here."""
    items = data if isinstance(data, list) else [data]
    if any(_looks_like_result(it) for it in items):
        return ""                       # something scanned fine → not an error
    for it in items:
        if isinstance(it, dict) and it.get("ok") is False and it.get("error"):
            err = str(it.get("error"))
            if not _looks_like_auth_error(err):   # auth handled elsewhere
                return err
    return ""


# ── Python sandbox helper ─────────────────────────────────────────────────────
def _prepare_pip_sandbox(target: Path,
                         log: Callable[[str], None]) -> Optional[dict]:
    req = target / "requirements.txt"
    if not req.exists():
        return None
    venv_dir   = target / ".snyk-venv"
    wheels_dir = target / ".snyk-wheels"
    wheels_dir.mkdir(exist_ok=True)
    scripts = venv_dir / ("Scripts" if os.name == "nt" else "bin")
    py_exe  = scripts  / ("python.exe" if os.name == "nt" else "python")
    if not py_exe.exists():
        log(f"[sandbox] creating isolated venv at {venv_dir}…")
        r = _run([sys.executable, "-m", "venv", str(venv_dir)], timeout=300)
        if r.returncode != 0:
            log(f"[sandbox] venv failed: {(r.stderr or r.stdout).strip()}")
            return None
        _run([str(py_exe), "-m", "pip", "install", "--upgrade", "pip",
              "--disable-pip-version-check"], timeout=600)
    log("[sandbox] downloading wheels (wheels-only, no code executes)…")
    dl = _run([str(py_exe), "-m", "pip", "download", "--only-binary=:all:",
               "--dest", str(wheels_dir), "-r", str(req),
               "--disable-pip-version-check"], timeout=900)
    if dl.stdout: log(dl.stdout.strip()[-1500:])
    if dl.stderr: log(dl.stderr.strip()[-1500:])
    if not list(wheels_dir.glob("*.whl")):
        log("[sandbox] no wheels downloaded; skipping sandbox."); return None
    inst = _run([str(py_exe), "-m", "pip", "install", "--no-index",
                 "--find-links", str(wheels_dir), "--only-binary=:all:",
                 "--no-build-isolation", "-r", str(req),
                 "--disable-pip-version-check"], timeout=900)
    if inst.stdout: log(inst.stdout.strip()[-1500:])
    if inst.stderr: log(inst.stderr.strip()[-1500:])
    installed = (_run([str(py_exe), "-m", "pip", "list", "--format=freeze"],
                      timeout=60).stdout or "").strip()
    if not installed:
        log("[sandbox] venv empty; SCA may report 0."); return None
    log(f"[sandbox] ready ({len(installed.splitlines())} packages visible to Snyk).")
    env = os.environ.copy()
    env["VIRTUAL_ENV"] = str(venv_dir)
    env["PATH"] = str(scripts) + os.pathsep + env.get("PATH", "")
    env.pop("PYTHONHOME", None)
    return env


# ── Core scan runner ──────────────────────────────────────────────────────────
class SnykScanError(RuntimeError):
    """Raised when a Snyk scan could not complete (e.g. the CLI binary could
    not be downloaded behind a TLS-inspecting proxy, auth failed, or the
    target could not be analysed). Distinct from a *clean* scan that simply
    found zero vulnerabilities — that returns normally with empty results.

    `is_auth` is True when the failure was specifically an authentication
    problem (expired/missing credential), so the UI can prompt a re-login."""
    def __init__(self, *args, is_auth: bool = False):
        super().__init__(*args)
        self.is_auth = is_auth


def _snyk_json_scan(args, *, target, out_dir, out_name, log, env=None,
                    timeout=1800, write_raw=False,
                    count_label="") -> tuple[Any, Path]:
    log(f"[scan] $ snyk {' '.join(args[1:])}  (cwd={target})")
    base_env = env if env is not None else os.environ.copy()
    r = _run(args, cwd=target, env=base_env, timeout=timeout)
    combined = (r.stdout or "") + (r.stderr or "")
    data = _parse_json_loose(r.stdout or "")

    # A TLS / proxy / binary-download failure produces no parseable JSON on
    # stdout. Recover *before* we mistake that for "0 vulnerabilities found":
    # retry through the corporate CA bundle, then (last resort) with TLS
    # verification disabled — mirroring the install path.
    if data is None and _looks_like_tls_error(combined):
        ca = _find_ca_bundle() or _export_windows_ca_bundle(log)
        if ca:
            log(f"[scan][tls-retry] retrying with NODE_EXTRA_CA_CERTS={ca}")
            env2 = dict(base_env); env2["NODE_EXTRA_CA_CERTS"] = ca
            r = _run(args, cwd=target, env=env2, timeout=timeout)
            data = _parse_json_loose(r.stdout or "")
            combined = (r.stdout or "") + (r.stderr or "")
        if data is None and _looks_like_tls_error(combined):
            log("[scan][tls-retry] CA bundle unavailable/insufficient — "
                "retrying with TLS verification DISABLED "
                "(NODE_TLS_REJECT_UNAUTHORIZED=0) + snyk --insecure.")
            env3 = dict(base_env); env3["NODE_TLS_REJECT_UNAUTHORIZED"] = "0"
            args_insecure = list(args)
            # Insert --insecure right after the snyk subcommand verbs so it
            # applies to both `snyk test ...` and `snyk code test ...`.
            if "--insecure" not in args_insecure:
                args_insecure.append("--insecure")
            r = _run(args_insecure, cwd=target, env=env3, timeout=timeout)
            data = _parse_json_loose(r.stdout or "")
            combined = (r.stdout or "") + (r.stderr or "")

    if r.stderr:
        log(r.stderr.strip()[-2000:])

    # Some early/fatal Snyk failures (e.g. "The request cannot be processed")
    # are printed as a valid {"ok": false, "error": "..."} JSON envelope on
    # STDERR rather than stdout. Without this, that perfectly good reason was
    # silently discarded and every such failure surfaced as the generic,
    # unhelpful "no JSON returned" — losing the actual cause.
    if data is None and r.stderr:
        data = _parse_json_loose(r.stderr)

    out_path = out_dir / out_name
    out_path.write_text(
        r.stdout or "" if write_raw else json.dumps(data, indent=2),
        encoding="utf-8")

    # Authentication failure — Snyk ran but the credential is missing/expired.
    # Catch this for BOTH shapes: the parsed {"ok": false, "error": "...auth..."}
    # JSON (which would otherwise count as 0 vulns = a false clean) and the
    # plain-text-on-stderr case. Must be checked before the no-JSON branch and
    # before counting, so it never reads as a clean scan.
    def _is_auth_fail(d: Any) -> bool:
        items = d if isinstance(d, list) else [d]
        for it in items:
            if isinstance(it, dict) and it.get("ok") is False \
                    and _looks_like_auth_error(str(it.get("error", ""))):
                return True
        return False

    if _is_auth_fail(data) or (data is None and _looks_like_auth_error(combined)):
        raise SnykScanError(
            f"{count_label or 'Snyk'} scan failed: not authenticated to Snyk. "
            f"The saved credential is missing or expired. Click 'Re-login to "
            f"Snyk' to sign in again (this clears any stale token and signs in "
            f"through your organization's SSO).", is_auth=True)

    # Non-auth error envelope: Snyk RAN, returned valid JSON, but the JSON is
    # just {"ok": false, "error": "..."} with no result (e.g. "unable to find
    # supported files" on an empty/unsupported target). Without this, SCA logs
    # it as "0 vulnerabilities" = a false PASS, while SAST already hard-fails on
    # the same input. Flag both consistently so the stage shows FAILED.
    _env_err = _error_envelope_msg(data)
    if _env_err:
        raise SnykScanError(
            f"{count_label or 'Snyk'} scan could not analyse the target "
            f"(nothing scannable here): {_env_err}")

    # If we STILL have no JSON, the scan genuinely failed — do not pretend it
    # found nothing. Surface it so the orchestrator marks the stage failed.
    if data is None:
        snippet = (combined.strip() or "no output").splitlines()
        tail = " ".join(snippet[-6:])[:600] if snippet else "no output"
        if _looks_like_tls_error(combined):
            raise SnykScanError(
                f"{count_label or 'Snyk'} scan failed: the Snyk CLI could not "
                f"reach Snyk through the network (TLS/self-signed-certificate "
                f"error from a corporate proxy). Set NODE_EXTRA_CA_CERTS to your "
                f"company CA bundle, or run with --insecure. Details: {tail}")
        raise SnykScanError(
            f"{count_label or 'Snyk'} scan failed — no JSON returned. "
            f"Details: {tail}")

    if count_label:
        log(f"[scan] {count_label} total vulnerabilities: {_count_vulns(data)}")
    log(f"[scan] raw JSON → {out_path}")
    return data, out_path


# ── Snyk organization pinning ─────────────────────────────────────────────────
# Snyk auto-creates a PERSONAL org named after each user (e.g. "srangel").
# That personal org does NOT carry the corporate license, so `snyk code`
# (SAST) and entitlement-gated features fail there with
# "... is not supported for your current organization: <user>".
# When the CLI is invoked without --org it falls back to the account's
# preferred org, which after an SSO `snyk auth` is usually that personal org.
# We therefore pin every scan to the corporate org explicitly.
_DEFAULT_SNYK_ORG = "7c545e26-1865-4ce9-a2e5-2b8c1c215e62"   # banco-base-default
_SNYK_ORG: str = (os.environ.get("SNYK_ORG", "").strip() or _DEFAULT_SNYK_ORG)


def get_snyk_org() -> str:
    return _SNYK_ORG


def _org_args() -> list[str]:
    """`--org=<id>` flag list, or empty when no org is configured."""
    org = get_snyk_org()
    return [f"--org={org}"] if org else []


def run_snyk_test(target: Path, out_dir: Path,
                  log: Callable[[str], None]) -> tuple[Any, Path]:
    """SCA scan via `snyk test --all-projects`."""
    setup_proxy_tls_env(log)   # ensure the wrapper's binary download can complete
    sb_env = _prepare_pip_sandbox(target, log)
    args = [_snyk_bin(), "test", "--all-projects", "--detection-depth=10",
            "--strict-out-of-sync=false", "--skip-unresolved",
            *_org_args(), "--json"]
    return _snyk_json_scan(args, target=target, out_dir=out_dir,
                           out_name="snyk_test.json", log=log, env=sb_env,
                           count_label="SCA")


def run_snyk_code(target: Path, out_dir: Path,
                  log: Callable[[str], None]) -> tuple[Any, Path]:
    """SAST scan via `snyk code test`."""
    setup_proxy_tls_env(log)   # ensure the wrapper's binary download can complete
    return _snyk_json_scan([_snyk_bin(), "code", "test", *_org_args(), "--json"],
                           target=target, out_dir=out_dir,
                           out_name="snyk_code.json",
                           log=log, write_raw=True)


# ── SARIF / merged-JSON exporters ─────────────────────────────────────────────
_SARIF_LEVEL = {"critical": "error", "high": "error",
                "medium": "warning", "low": "note", "info": "note"}


def _sarif_run(tool_name: str, results: list[dict]) -> dict:
    rules: dict[str, dict] = {}
    out_results = []
    for r in results:
        rule_id  = r.get("rule_id") or r.get("title") or "finding"
        rules.setdefault(rule_id, {
            "id": rule_id,
            "name": rule_id[:120],
            "shortDescription": {"text": (r.get("title") or rule_id)[:200]},
            "properties": {k: v for k, v in (("cwe", r.get("cwe")),) if v},
        })
        sev = (r.get("severity") or "low").lower()
        msg = r.get("title") or rule_id
        ev  = r.get("evidence") or ""
        loc_uri = r.get("url") or r.get("location") or ""
        res = {
            "ruleId": rule_id,
            "level": _SARIF_LEVEL.get(sev, "note"),
            "message": {"text": f"{msg}\n{ev}".strip()},
            "properties": {"severity": sev,
                           "category": r.get("category", "")},
        }
        if loc_uri:
            res["locations"] = [{"physicalLocation": {
                "artifactLocation": {"uri": loc_uri}}}]
        out_results.append(res)
    return {
        "tool": {"driver": {
            "name": tool_name,
            "informationUri": "https://snyk.io",
            "rules": list(rules.values())}},
        "results": out_results,
    }


def _collect_sca_findings(data) -> list[dict]:
    projects = (data if isinstance(data, list) else [data]) if data else []
    out = []
    for p in projects:
        if not isinstance(p, dict): continue
        for v in (p.get("vulnerabilities") or []):
            if not isinstance(v, dict): continue
            pkg = v.get("packageName") or v.get("package") or ""
            ver = v.get("version") or ""
            out.append({
                "rule_id":  v.get("id") or v.get("title") or "snyk-sca",
                "title":    v.get("title") or v.get("id") or "Vulnerability",
                "severity": (v.get("severity") or "low").lower(),
                "evidence": f"{pkg}@{ver}  " + (
                    " > ".join(map(str, (v.get("from") or [])[:6]))),
                "location": (p.get("displayTargetFile") or p.get("targetFile")
                             or p.get("path") or pkg),
                "cwe": ",".join(
                    v.get("identifiers", {}).get("CWE", []) or []),
                "category": "sca",
            })
    return out


def _read_json(path: Path):
    """Load a JSON file, returning None if missing or unparseable."""
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def export_sarif(out_dir: Path) -> Optional[Path]:
    """Build a single SARIF 2.1.0 log from every scanner's raw output in
    out_dir. Returns the path, or None if nothing could be assembled."""
    runs: list[dict] = []

    def _load(name): return _read_json(out_dir / name)

    sca = _load("snyk_test.json")
    if sca is not None:
        sca_findings = _collect_sca_findings(sca)
        if sca_findings:
            runs.append(_sarif_run("Snyk Open Source (SCA)", sca_findings))

    # snyk code --json already emits SARIF — merge its runs verbatim.
    code = _load("snyk_code.json")
    if isinstance(code, dict) and isinstance(code.get("runs"), list):
        runs.extend(code["runs"])
    elif isinstance(code, list):
        for doc in code:
            if isinstance(doc, dict) and isinstance(doc.get("runs"), list):
                runs.extend(doc["runs"])

    for name, tool in (("dast.json", "DAST Crawler"),
                       ("api.json",  "API Scanner")):
        d = _load(name)
        if isinstance(d, dict) and d.get("findings"):
            runs.append(_sarif_run(tool, d["findings"]))

    if not runs:
        return None
    sarif = {
        "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
        "version": "2.1.0",
        "runs": runs,
    }
    path = out_dir / "findings.sarif"
    path.write_text(json.dumps(sarif, indent=2), encoding="utf-8")
    return path


def export_merged_json(out_dir: Path) -> Optional[Path]:
    """One flat JSON array of all non-SAST findings (DAST + API + SCA).
    Snyk Code SARIF stays in snyk_code.json."""
    merged: list[dict] = []

    def _load(name): return _read_json(out_dir / name)

    sca = _load("snyk_test.json")
    if sca is not None:
        merged.extend(_collect_sca_findings(sca))
    for name in ("dast.json", "api.json"):
        d = _load(name)
        if isinstance(d, dict):
            merged.extend(d.get("findings") or [])
    if not merged:
        return None
    order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
    merged.sort(
        key=lambda x: order.get((x.get("severity") or "low").lower(), 5))
    path = out_dir / "findings_merged.json"
    path.write_text(json.dumps(merged, indent=2), encoding="utf-8")
    return path


# ══ Secrets scanner ══════════════════════════════════════════════════════════
# The full secrets-detection engine (git-secrets bootstrap/execution, the
# technology-organised built-in provider set, the entropy fallback, filename
# heuristics, and the HTML/JSON report writer) now lives in its own module,
# secrets_scanner.py — see that file's docstring for why it isn't literally
# named "secrets.py" (it would shadow Python's stdlib `secrets` module for
# every other file in this project). Everything is re-exported here under
# the same names so every existing call site — `static_scanner.scan_path(...)`,
# `static_scanner.ensure_git_secrets(...)`, the CLI smoke test below, etc. —
# keeps working unchanged.
from secrets_scanner import (
    SEVERITY_ORDER, GIT_SECRETS_RAW_URL,
    get_git_secrets_status, get_engine_label, ensure_git_secrets,
    scan_path, redact, redact_line, render_secrets_html, write_secrets_report,
    load_baseline, save_baseline_entry, remove_baseline_entry,
)
import secrets_scanner as secrets_scanner_module  # noqa: F401 — kept importable as static_scanner.secrets_scanner_module for anyone introspecting the split



# ══ Static-paths display (plain labels, not a boxed field) ═════════════════
class _PathListDisplay:
    """Drop-in replacement for the tk.Listbox that used to show the Estático
    tab's queued folders/files: renders each path as its own one-line Label
    sitting directly on the card background — no field/box chrome — instead
    of inside a bordered Listbox widget. Exposes just enough of the Listbox
    API (get/insert/delete/curselection/size) that every existing call site
    across the app (session save/restore, app-profile switching, the wizard's
    own sync, scan-readiness checks) keeps working unchanged; those call
    sites only ever exercise that subset, verified by grep before writing
    this.

    Composition, not a tk widget subclass on purpose — self.frame is a plain
    tk.Frame, so the app's theme-toggle recolour walk (_recolour_widget,
    which recurses on real widget children) repaints it and its Label rows
    automatically without any special-casing."""

    def __init__(self, parent, *, font, fg, bg, select_bg, select_fg):
        self.frame = tk.Frame(parent, bg=bg)
        self._font = font
        self._fg = fg
        self._bg = bg
        self._select_bg = select_bg
        self._select_fg = select_fg
        self._items: list[str] = []
        self._selected: set[int] = set()
        self._anchor: Optional[int] = None
        self._empty_lbl: Optional["tk.Label"] = None
        self._redraw()

    # ── layout passthroughs, so call sites can treat this like any widget ──
    def pack(self, **kw): self.frame.pack(**kw)
    def grid(self, **kw): self.frame.grid(**kw)

    # ── rendering ────────────────────────────────────────────────────────
    def _redraw(self) -> None:
        for w in self.frame.winfo_children():
            w.destroy()
        if not self._items:
            self._empty_lbl = tk.Label(
                self.frame, text="  (ninguna ruta agregada)", font=self._font,
                bg=self._bg, fg=T["muted"], anchor="w")
            self._empty_lbl.pack(fill="x")
            return
        self._empty_lbl = None
        for i, path in enumerate(self._items):
            sel = i in self._selected
            row = tk.Label(
                self.frame, text=f"  {path}", font=self._font, anchor="w",
                bg=self._select_bg if sel else self._bg,
                fg=self._select_fg if sel else self._fg,
                cursor="hand2")
            row.pack(fill="x")
            row.bind("<Button-1>", lambda e, i=i: self._on_click(i, e))

    def _on_click(self, idx: int, event) -> None:
        ctrl = bool(event.state & 0x0004)
        shift = bool(event.state & 0x0001)
        if shift and self._anchor is not None:
            lo, hi = sorted((self._anchor, idx))
            self._selected = set(range(lo, hi + 1))
        elif ctrl:
            if idx in self._selected: self._selected.discard(idx)
            else: self._selected.add(idx)
            self._anchor = idx
        else:
            self._selected = {idx}
            self._anchor = idx
        self._redraw()

    # ── Listbox-compatible API ──────────────────────────────────────────────
    def get(self, first, last=None):
        lo = 0 if first in (0, "0") else int(first)
        if last is None:
            return self._items[lo] if 0 <= lo < len(self._items) else ""
        hi = (len(self._items) - 1) if last == "end" else int(last)
        return tuple(self._items[lo:hi + 1])

    def insert(self, index, value) -> None:
        if index == "end":
            self._items.append(value)
        else:
            self._items.insert(int(index), value)
        self._redraw()

    def delete(self, first, last=None) -> None:
        if not self._items:
            return
        lo = 0 if first in (0, "0") else int(first)
        if last is None:
            hi = lo
        elif last == "end":
            hi = len(self._items) - 1
        else:
            hi = int(last)
        del self._items[lo:hi + 1]
        self._selected = set()
        self._anchor = None
        self._redraw()

    def curselection(self):
        return tuple(sorted(self._selected))

    def size(self) -> int:
        return len(self._items)


# ══ ScannerApp integration (was gui_static_tab.py) ══════════════════════════

class _StaticTabMixin(secrets_scanner_module._SecretsPanelMixin):
    def _sev_brand_color(self, sev):
        sev = _sev_norm(sev)
        if sev in ("critical", "high"): return T["err"]     # brand red
        if sev == "medium":             return T["accent"]  # brand gold
        return T["muted"]                                   # low / info

    def _sev_leaf_tag(self, sev):
        sev = _sev_norm(sev)
        if sev in ("critical", "high"): return "crit"
        if sev == "medium":             return "med"
        return "muted"

    def _apply_group_tags(self, tree):
        tree.tag_configure("group", foreground=T["text"], font=(_FUI, 12))
        tree.tag_configure("crit",  foreground=T["err"])
        tree.tag_configure("med",   foreground=T["text"])
        tree.tag_configure("muted", foreground=T["muted"])

    def _group_tree(self, parent, tree_col, cols, headings, height):
        """Árbol colapsable de 2 niveles (grupo → hallazgos) con estilo de marca."""
        # Nested inside the outer SCA/SAST panel card — no drop-shadow of its
        # own (only exterior cards get one; see _shadow_wrap's docstring).
        # Same plain-bordered convention _make_tree already uses for every
        # other nested tree in the app (e.g. the orchestrator pool table).
        outer = tk.Frame(parent, bg=T["panel_bg"], highlightthickness=1, highlightbackground=T["border"])
        outer.pack(fill="both", expand=True)
        tk.Frame(outer, bg=T["border_bg"], height=2).pack(fill="x", side="top")
        tf = tk.Frame(outer, bg=T["panel_bg"]); tf.pack(fill="both", expand=True)
        tree = ttk.Treeview(tf, columns=cols, show="tree headings", height=height)
        tcol_txt, tcol_w = tree_col
        tree.heading("#0", text=tcol_txt, anchor="w",
                    command=lambda: _group_tree_sort_col(tree, "#0", False))
        tree.column("#0", width=tcol_w, stretch=True, anchor="w")
        for c, (txt, w, anchor, stretch) in zip(cols, headings):
            tree.heading(c, text=txt, anchor=anchor,
                        command=lambda col=c: _group_tree_sort_col(tree, col, False))
            tree.column(c, width=w, anchor=anchor, stretch=stretch)
        tree.pack(side="left", fill="both", expand=True)
        ttk.Scrollbar(tf, command=tree.yview, orient="vertical").pack(side="right", fill="y")
        self._apply_group_tags(tree)
        return tree

    def _tree_empty(self, tree, msg="Sin hallazgos — ejecute un escaneo."):
        for iid in tree.get_children(): tree.delete(iid)
        tree.insert("", "end", text="  " + msg, tags=("muted",))

    def _set_panel_summary(self, lbl, total, worst):
        if lbl is None: return
        if total == 0:
            lbl.config(text="sin hallazgos")
        else:
            lbl.config(text=f"{total} finding{'' if total == 1 else 's'}")

    def _render_sca(self, projects):
        """SCA is about *which dependency to upgrade* — group by package, surface
        the fix version, collapse the individual CVEs underneath."""
        tree = self._static_sca_tree
        for iid in tree.get_children(): tree.delete(iid)
        groups: dict = {}
        for proj in projects or []:
            for i in proj.get("issues", []):
                groups.setdefault(i.get("package", "—"), []).append(i)
        total = 0; worst = "info"
        for pkg in sorted(groups):
            issues = groups[pkg]; total += len(issues)
            gw = "info"; fix = ""
            for i in issues:
                s = _sev_norm(i.get("severity"))
                if _SEV_RANK[s] > _SEV_RANK[gw]: gw = s
                if not fix and i.get("fixedIn") not in (None, "", "—"): fix = str(i.get("fixedIn"))
            if _SEV_RANK[gw] > _SEV_RANK[worst]: worst = gw
            p = tree.insert("", "end", text=f"{pkg}   ({len(issues)})",
                            values=(gw.upper(), ("→ " + fix) if fix else "—"), tags=("group",), open=False)
            for i in issues:
                s = _sev_norm(i.get("severity"))
                fx = i.get("fixedIn"); fx = ("→ " + str(fx)) if fx not in (None, "", "—") else "—"
                tree.insert(p, "end", text="   " + (i.get("title", "") or ""),
                            values=(s.upper(), fx), tags=(self._sev_leaf_tag(s),))
        if total == 0: self._tree_empty(tree)
        self._set_panel_summary(self._sca_summary, total, worst)

    def _render_sast(self, files):
        """SAST is about *where in the code* — group by file (data already is),
        collapse the per-line findings underneath."""
        tree = self._static_sast_tree
        for iid in tree.get_children(): tree.delete(iid)
        total = 0; worst = "info"
        for fobj in files or []:
            issues = fobj.get("issues", [])
            if not issues: continue
            total += len(issues); gw = "info"
            for i in issues:
                s = _sev_norm(i.get("severity"))
                if _SEV_RANK[s] > _SEV_RANK[gw]: gw = s
            if _SEV_RANK[gw] > _SEV_RANK[worst]: worst = gw
            p = tree.insert("", "end", text=f"{fobj.get('file', '—')}   ({len(issues)})",
                            values=(gw.upper(), ""), tags=("group",), open=False)
            for i in issues:
                s = _sev_norm(i.get("severity"))
                tree.insert(p, "end", text="   " + (i.get("title", "") or ""),
                            values=(s.upper(), str(i.get("line", "?"))), tags=(self._sev_leaf_tag(s),))
        if total == 0: self._tree_empty(tree)
        self._set_panel_summary(self._sast_summary, total, worst)

    def _build_tab_static(self, parent):
        pad = self._scrollable(parent)

        # ── Top row: target path(s) (left half) + run buttons (right half) ───────
        top_row = tk.Frame(pad, bg=T["bg"]); top_row.pack(fill="x", pady=(0, 2))

        fold = self._side_card(top_row, "")
        # Multi-path list, styled to sit directly in the card — no field/box
        # chrome at all now (not even a Listbox widget): each loaded path
        # prints as its own one-line label straight onto the card
        # background as it's added, instead of living inside a boxed
        # control. The tab itself already scrolls (see _scrollable(parent)
        # above), so this doesn't need its own scrollbar.
        self._static_paths_lb = _PathListDisplay(
            fold, font=(_FMONO, 10), fg=T["text"], bg=T["panel_bg"],
            select_bg=T["surface2"], select_fg=T["text"])
        self._static_paths_lb.pack(fill="x")

        # Buttons row for path management
        path_btns = tk.Frame(fold, bg=T["panel_bg"]); path_btns.pack(fill="x", pady=(1, 0))

        def _add_folder():
            initial = self._target_var.get() or str(SCRIPT_DIR)
            d = filedialog.askdirectory(title="Agregar carpeta al escaneo", initialdir=initial)
            if d:
                existing = list(self._static_paths_lb.get(0, "end"))
                if d not in existing:
                    self._static_paths_lb.insert("end", d)
                self._target_var.set(d)  # keep _target_var pointing to last selected
                self._persist_static_paths()

        def _add_files():
            initial = self._target_var.get() or str(SCRIPT_DIR)
            files = filedialog.askopenfilenames(
                title="Agregar archivos o .csproj al escaneo",
                initialdir=initial,
                filetypes=[
                    ("Todos los compatibles", "*.csproj *.sln *.json *.py *.js *.ts *.cs *.java *.go *.rb *.php"),
                    ("Proyectos Visual Studio", "*.csproj *.sln"),
                    ("Manifiestos de dependencias", "*.json *.xml *.lock *.toml *.gradle"),
                    ("Código fuente", "*.py *.js *.ts *.cs *.java *.go *.rb *.php *.cpp *.c *.h"),
                    ("Todos los archivos", "*.*"),
                ])
            if files:
                existing = list(self._static_paths_lb.get(0, "end"))
                for f in files:
                    # If it's a .csproj, auto-add the containing folder too
                    p = Path(f)
                    if p.suffix.lower() == ".csproj":
                        folder = str(p.parent)
                        if folder not in existing:
                            self._static_paths_lb.insert("end", folder)
                            existing.append(folder)
                            self._log_line(f"[static] .csproj detected: using folder '{folder}'")
                    else:
                        if f not in existing:
                            self._static_paths_lb.insert("end", f)
                            existing.append(f)
                if files:
                    self._target_var.set(str(Path(files[-1]).parent))
                self._persist_static_paths()

        def _remove_selected():
            # Remove selected items in reverse order to keep indices valid
            sel = list(self._static_paths_lb.curselection())
            for idx in reversed(sel):
                self._static_paths_lb.delete(idx)
            # Update target_var to last remaining — and just as importantly,
            # CLEAR it when the list becomes empty. Leaving the old value in
            # place here is what let a stale route survive: _run_static_scan_now
            # falls back to _target_var when the listbox is empty, so an
            # uncleared leftover made "remove all routes, click ▶" silently
            # re-run the last removed path instead of warning about no target.
            items = self._static_paths_lb.get(0, "end")
            if items: self._target_var.set(items[-1])
            else: self._target_var.set("")
            self._persist_static_paths()

        def _open_add_popup():
            """Popup de agregar objetivos — dos paneles _side_card lado a lado.
            La cabecera y el pie son built manually (same pattern as ReportsViewer)
            to avoid _popup_hdr/_popup_foot calling _hdiv with T["border"], which
            in dark mode is "#ffffff12" — an alpha-channel hex that Tkinter
            rejects as a bg= value.  We strip alpha with _bdr before any Frame."""
            popup = self._create_popup("Agregar objetivos")

            # T["border_bg"] is the Tkinter-safe opaque border (added to both
            # palettes in Snyk_Scanner_GUI.py to fix the #ffffff12 alpha crash).
            _bdr = T["border_bg"]
            hb   = T["panel_bg"]

            # ── Header ────────────────────────────────────────────────────────────────────
            hdr = tk.Frame(popup, bg=hb, padx=8, pady=4); hdr.pack(fill="x")
            row = tk.Frame(hdr, bg=hb); row.pack(fill="x")
            tk.Label(row, text="📂  Agregar objetivos",
                     font=(_FUI, 12, "bold"), bg=hb, fg=T["text"]).pack(side="left")
            tk.Label(row, text="Seleccione qué incluir en el análisis estático",
                     font=(_FUI, 10, "italic"), bg=hb, fg=T["muted"]).pack(side="left", padx=(3, 0))
            _cfn = getattr(popup, "close", None)
            if _cfn:
                xbtn = tk.Label(row, text="✕", font=(_FUI, 10, "bold"),
                                bg=hb, fg=T["muted"], cursor="hand2", padx=2)
                xbtn.pack(side="right")
                xbtn.bind("<Button-1>", lambda e: _cfn())
                xbtn.bind("<Enter>",    lambda e: xbtn.config(fg=T["err"]))
                xbtn.bind("<Leave>",    lambda e: xbtn.config(fg=T["muted"]))
            tk.Frame(popup, bg=_bdr, height=1).pack(fill="x")

            # ── Body ──────────────────────────────────────────────────────────────────────
            body = tk.Frame(popup, bg=T["bg"], padx=10, pady=8)
            body.pack(fill="both", expand=True)
            cards_row = tk.Frame(body, bg=T["bg"])
            cards_row.pack(fill="both", expand=True)

            # Left card: Add Folder
            fi = self._side_card(cards_row, "📂  AGREGAR CARPETA", padx=(0, 2))
            self._lbl(fi,
                      "Escanea todo el directorio de un proyecto.\n\n"
                      "Snyk analizará recursivamente todos los archivos de manifiesto compatibles "
                      "(package.json, pom.xml, requirements.txt, .csproj…) and "
                      "every source file it finds under the selected folder.",
                      size=10, fg=T["muted"], wraplength=520,
                      justify="left", anchor="nw").pack(fill="x", pady=(0, 4))
            tk.Frame(fi, bg=hb).pack(fill="both", expand=True)
            self._btn(fi, "📂  Explorar carpeta…",
                      lambda: [_add_folder(), popup.close()],
                      kind="accent").pack(fill="x")

            # Right card: Add File(s) / .csproj
            fi2 = self._side_card(cards_row, "📄  AGREGAR ARCHIVO(S) / .CSPROJ", padx=(2, 0))
            self._lbl(fi2,
                      "Escanea archivos específicos o un proyecto de Visual Studio.\n\n"
                      "Elija archivos fuente individuales, archivos de bloqueo o un .csproj / .sln. "
                      "Al seleccionar un .csproj, la carpeta contenedora se incluye automáticamente. "
                      "included so the full build graph is available to Snyk.",
                      size=10, fg=T["muted"], wraplength=520,
                      justify="left", anchor="nw").pack(fill="x", pady=(0, 4))
            tk.Frame(fi2, bg=hb).pack(fill="both", expand=True)
            self._btn(fi2, "📄  Explorar archivo(s)…",
                      lambda: [_add_files(), popup.close()],
                      kind="accent").pack(fill="x")

            # ── Footer ──────────────────────────────────────────────────────────────────
            tk.Frame(popup, bg=_bdr, height=1).pack(fill="x")
            foot = tk.Frame(popup, bg=hb, padx=10, pady=4); foot.pack(fill="x")
            self._btn(foot, "  Cerrar  ", popup.close, "accent").pack(side="right")

        # + opens the add-targets popup; - removes the currently selected
        # entry. Square icon buttons — visual clone (size/shape/colors) of
        # the header's ▶/■ run/stop buttons, see _icon_square_btn — instead
        # of the app's normal pill-shaped _btn(), per explicit design
        # request.
        self._icon_square_btn(path_btns, "+", _open_add_popup).pack(side="left", padx=(0, 1))
        self._icon_square_btn(path_btns, "−", _remove_selected).pack(side="left", padx=(0, 2))
        # Run Static sits immediately to the right — icon-only (▶, no
        # "Análisis estático" label) to match that same square shape; the
        # change is purely visual, it still targets SCA+SAST+Secrets exactly
        # as before.
        self._static_run_btns = []
        run_btn = self._icon_square_btn(path_btns, "▶",
                            lambda: self._start_static_scan({"sca", "code", "secrets"}))
        run_btn.pack(side="left")
        self._static_run_btns.append(run_btn)

        # Restore the path list saved on a previous run (clean close), falling
        # back to _target_var (e.g. set by an app profile) when nothing was saved.
        _saved_paths = getattr(self, "_saved_static_paths", None)
        if _saved_paths:
            for p in _saved_paths:
                self._static_paths_lb.insert("end", p)
            # Keep _target_var pointing at a real, currently-listed path —
            # _add_folder/_add_files/_remove_selected all do this on every
            # edit, but restoring the saved list on load never did, so
            # _target_var could stay empty (or stale) even though the
            # listbox visibly had folders in it. That's what made the main
            # Ejecutar button (which only checks _target_var) wrongly claim
            # no path was set until the user removed and re-added one.
            self._target_var.set(_saved_paths[-1])
        elif self._target_var.get():
            self._static_paths_lb.insert("end", self._target_var.get())

        # ── RESULTS — each analysis rendered in the form that suits its data ────
        # Hidden by default: these three cards only add noise before a scan
        # has actually produced something to show. _reveal_static_results()
        # packs them back in (once, in order) the first time a scan finishes.
        results_row = tk.Frame(pad, bg=T["bg"])
        sca_half = tk.Frame(results_row, bg=T["bg"]); sca_half.pack(side="left", fill="both", expand=True, padx=(0, 2))
        sast_half = tk.Frame(results_row, bg=T["bg"]); sast_half.pack(side="left", fill="both", expand=True, padx=(2, 0))
        self._static_results_row = results_row

        # SCA → grouped by package (the unit you actually upgrade), fix version surfaced.
        sca_inner, sca_right = self._panel(sca_half, "(SCA) Código Abierto", pady=(0, 0))
        self._sca_summary = tk.Label(sca_right, text="sin hallazgos", font=(_FUI, 10),
                                     bg=T["pill_idle_bg"], fg=T["pill_idle_fg"]); self._sca_summary.pack(side="right")
        self._static_sca_tree = self._group_tree(
            sca_inner, ("Paquete  /  Vulnerabilidad", 220), ("sev", "fix"),
            [("Severidad", 90, "w", False), ("Corrección disponible", 140, "w", False)], height=7)
        self._tree_empty(self._static_sca_tree)

        # SAST → grouped by file (where the weakness lives), line surfaced on each leaf.
        sast_inner, sast_right = self._panel(sast_half, "(SAST) Código Estático", pady=(0, 0))
        self._sast_summary = tk.Label(sast_right, text="sin hallazgos", font=(_FUI, 10),
                                      bg=T["pill_idle_bg"], fg=T["pill_idle_fg"]); self._sast_summary.pack(side="right")
        self._static_sast_tree = self._group_tree(
            sast_inner, ("Archivo  /  Hallazgo", 220), ("sev", "line"),
            [("Severidad", 90, "w", False), ("Línea", 70, "center", False)], height=7)
        self._tree_empty(self._static_sast_tree)

        # Secrets → few + urgent: one alert card each, redacted value in monospace.
        # Wrapped in its own frame (instead of sitting straight on `pad`) so it
        # can be hidden/shown independently, same as the SCA/SAST row above.
        # Panel itself is built by _SecretsPanelMixin (secrets_scanner.py) —
        # this file only decides where it sits relative to SCA/SAST.
        self._static_secrets_wrap = self._build_secrets_panel(pad)

        self._static_results_visible = False

    def _reveal_static_results(self) -> None:
        """Show the SCA/SAST/Secrets cards — called once a static scan has
        actually completed (even with zero findings in every category).
        Safe to call repeatedly; only packs on the first successful run."""
        if getattr(self, "_static_results_visible", False):
            return
        row = getattr(self, "_static_results_row", None)
        wrap = getattr(self, "_static_secrets_wrap", None)
        if row is not None:
            row.pack(fill="x", pady=(0, 2))
        if wrap is not None:
            wrap.pack(fill="x")
        self._static_results_visible = True

    def _start_static_scan(self, sel: set):
        """Public entry point — the Static-analysis tab's '▶ Análisis
        estático' button. Warns first if no app profile is loaded (see
        _confirm_scan_without_app); crash-recovery resume calls
        _run_static_scan_now() directly, bypassing this gate."""
        if self._static_busy:
            self._log_line("[static] a scan is already running"); return
        self._confirm_scan_without_app(lambda: self._run_static_scan_now(sel))

    def _run_static_scan_now(self, sel: set):
        # Reflect the static run in the pipeline cards: any of SCA / SAST /
        # Secrets that were de-selected get selected now, so the cards always
        # show what Run Static actually executes (and that becomes the new
        # remembered default).
        changed = False
        for k in ("sca", "code", "secrets"):
            if k in sel:
                var = self._scan_vars.get(k)
                if var is not None and not var.get():
                    var.set(1); changed = True
                apply_fn = getattr(self, "_stage_apply", {}).get(k)
                if apply_fn:
                    try: apply_fn(True)
                    except Exception: pass
        if changed:
            self._refresh_scan_btn(); self._persist_scan_stages()

        # Collect paths from the multi-path listbox
        raw_paths = list(getattr(self, "_static_paths_lb", None) and
                         self._static_paths_lb.get(0, "end") or [])
        # Filter out the placeholder text
        paths = [p for p in raw_paths if p.strip() and not p.strip().startswith("(empty")]
        if not paths:
            # Fallback to _target_var for backward compat (e.g. loaded from app profile)
            tv = self._target_var.get().strip()
            if tv: paths = [tv]
        if not paths:
            self._show_warn_popup("Análisis estático",
                "Sin carpetas ni archivos seleccionados.\n\n"
                "Use '📂 + Carpeta' o '📄 + Archivo(s) / .csproj' para agregar objetivos."); return

        # Validate paths
        valid_paths = []
        for p in paths:
            pp = Path(p).resolve()
            if pp.exists():
                valid_paths.append(pp)
            else:
                self._log_line(f"[static] ⚠ path not found, skipping: {p}")
        if not valid_paths:
            self._show_warn_popup("Análisis estático",
                "Ninguna de las rutas seleccionadas existe en disco.\n\n"
                "Verifique las rutas e intente de nuevo."); return

        # Scan EVERY valid path, not just the first. _static_scan iterates over
        # _static_targets; _target_var is kept only for display/back-compat.
        self._static_targets = valid_paths
        self._target_var.set(str(valid_paths[0]))

        # SCA/SAST need a logged-in Snyk session (the CLI itself is installed at boot).
        if {"sca", "code"} & sel:
            checks = self._checks or {}
            auth_ok = bool(checks.get("auth") and checks["auth"].ok)
            if not auth_ok:
                self._show_warn_popup("Análisis estático",
                    "SCA y SAST requieren una sesión SSO activa en Snyk.\n\n"
                    "Vaya a la pestaña ▶ Ejecutar → Prerrequisitos y haga clic en '🔑 Iniciar sesión SSO'.")
                return
        self._static_run_sel = sel
        for b in getattr(self, "_static_run_btns", []):
            b.config(state="disabled")
        if hasattr(self, "_static_count_lbl"):
            self._static_count_lbl.config(text="Escaneando… (" + " + ".join(sorted(sel)).upper() + ")")
        self._run_async(self._static_scan, label="static analysis",
                        busy_attr="_static_busy", done_kind="__static_done__")

    @staticmethod
    def _dir_has_files(p) -> bool:
        """True if the target contains at least one regular file (recursive),
        or is itself a file. Used to flag empty folders so SCA/Secrets don't
        report a misleading 'completed / 0 findings'. On any error we return
        True so we never block a real scan over a probe failure."""
        try:
            p = Path(p)
            if p.is_file():
                return True
            for child in p.rglob("*"):
                if child.is_file():
                    return True
        except Exception:
            return True
        return False

    def _static_scan(self):
        """Iterate EVERY queued target (multi-folder). Each folder gets its own
        report; empty/inexistent folders are flagged and skipped so they never
        produce a false 'completed'."""
        self._static_cancel_evt.clear()
        sel = getattr(self, "_static_run_sel", {"sca", "code", "secrets"})
        targets = getattr(self, "_static_targets", None)
        if not targets:
            tv = self._target_var.get().strip()
            targets = [tv] if tv else []
        targets = [Path(x).resolve() for x in targets]
        if not targets:
            self._emit_log("[static] sin objetivos — nada que escanear")
            self._event_queue.put(("static_results", None)); return

        # Multi-route progress: clear any leftover fill from a previous run
        # (the Static tab never used to do this at all — see pipeline_reset's
        # other caller in _do_scan) before this batch's own stage cards start
        # reporting. Each of the N queued targets is then worth an even 1/N
        # slice of the "Estático" ribbon tab's bar, computed in
        # _recompute_pipeline_header via _static_route_index/_static_route_total.
        self._event_queue.put(("pipeline_reset", None))

        scanned = 0
        total_targets = len(targets)
        batch_summaries: list[dict] = []
        for i, t in enumerate(targets, 1):
            if self._static_cancel_evt.is_set():
                self._emit_log("[static] cancelado — objetivos restantes omitidos")
                break
            if not t.exists():
                self._emit_log(f"[static] ⚠ ruta inexistente, se omite: {t}")
                batch_summaries.append({"path": str(t), "scanned": False, "reason": "ruta inexistente"})
                continue
            if not self._dir_has_files(t):
                self._emit_log(f"[static] ⚠ objetivo vacío (sin archivos), se omite: {t}")
                batch_summaries.append({"path": str(t), "scanned": False, "reason": "carpeta vacía"})
                continue
            self._emit_log(f"[static] === objetivo {i}/{total_targets}: {t} ===")
            summary = self._static_scan_one(t, sel, route_index=i - 1, route_total=total_targets)
            if summary:
                batch_summaries.append(summary)
            scanned += 1

        if scanned == 0:
            self._emit_log("[static] ningún objetivo escaneable "
                           "(todas las carpetas vacías o inexistentes)")
            self._event_queue.put(("static_results", None))
            return

        if total_targets > 1:
            self._build_static_batch_index(batch_summaries)

    def _build_static_batch_index(self, batch_summaries: list[dict]) -> None:
        """More than one folder was queued for this run — build the linking/
        aggregating index page and make IT (not any individual sub-report)
        the one that auto-opens."""
        try:
            from report_engine import render_static_batch_index
            reports_root = Path(self._reports_var.get()).resolve()
            _report_label, app_reports_root = self._scoped_report_paths(reports_root)
            idx_path = render_static_batch_index(
                batch_summaries, app_reports_root, filename=f"index_{_ts()}.html")
            self._emit_log(f"[report] índice de análisis por carpetas ({len(batch_summaries)}) → {idx_path}")
            self._last_report = idx_path
            self._last_static_report = idx_path
            self._event_queue.put(("report", {"path": str(idx_path), "primary": True}))
        except Exception as e:
            self._emit_log(f"[report] no se pudo construir el índice del lote: {e!r}")

    def _static_scan_one(self, target, sel, route_index: int = 0, route_total: int = 1):
        """Run the selected folder-based analyses (SCA / SAST / Secrets) for a
        SINGLE target through the unified report pipeline. Each target produces
        its own report directory and report.

        route_index/route_total — this target's 0-based position and the total
        number of targets in the current multi-folder batch (single-folder runs
        just pass the defaults 0/1). Used only to scale the "Estático" ribbon
        tab's overall progress bar in _recompute_pipeline_header so N routes
        fill it in N even 1/N steps instead of each one independently jumping
        from 0% to 100%."""
        target = Path(target).resolve()
        reports_root = Path(self._reports_var.get()).resolve(); reports_root.mkdir(parents=True, exist_ok=True)
        active_app = getattr(self, "_active_app", None)
        _report_label, app_reports_root = self._scoped_report_paths(reports_root)
        mode = "+".join(sorted(sel))
        out_dir = app_reports_root / f"report_{_ts()}_{mode}"; out_dir.mkdir(parents=True, exist_ok=True)
        self._session_begin("static", set(sel))   # crash-recovery marker
        import audit_log
        audit_log.write_event(reports_root, "scan_start", actor=self._user,
                              app=(active_app.get("name") if active_app else ""),
                              mode=mode, target=str(target), out_dir=str(out_dir), lane="static",
                              log=self._emit_log)
        self._emit_log(f"[static] pipeline: {mode.upper()}")
        self._emit_log(f"[static] output → {out_dir}")
        _snyk_usable = True
        if {"sca", "code"} & sel:
            try:
                if not ensure_snyk_ready(self._emit_log):
                    _snyk_usable = False
                    self._emit_log("[static] Snyk CLI is not runnable — "
                                   "skipping SCA/SAST. Click Fix to repair it.")
            except Exception as e:
                self._emit_log(f"[static] snyk readiness check error: {e!r}")
        try: v = _run(["snyk", "--version"]).stdout.strip()
        except Exception: v = "?"

        results: dict[str, Any] = {"sca": None, "code": None, "dast": None, "api": None, "secrets": None}
        # Stages that were attempted (present in `jobs`) but raised — kept
        # separate from `results[key] is None`, which also means "not
        # selected" / "skipped". Without this split a stage that genuinely
        # errored is indistinguishable downstream from one that was never
        # run, so the cumulative report/history silently reports it as a
        # clean 0 instead of an unknown/failed result.
        failed_stages: set[str] = set()
        # Tell the header which route this is BEFORE the stage events below —
        # it resets this route's own stage cards back to 0% (a re-used stage
        # key like "sca" would otherwise still show the previous route's
        # terminal 100% while this route's scan is only just starting).
        self._event_queue.put(("static_route_start",
                               (route_index, route_total,
                                [k for k in ("sca", "code", "secrets") if k in sel])))
        for k in ("sca", "code", "secrets"):
            running = k in sel and (_snyk_usable or k == "secrets")
            self._event_queue.put(("stage", (k, "running" if running else "skipped")))

        jobs: list[tuple[str, Callable[[], None]]] = []
        if "sca" in sel and _snyk_usable:
            jobs.append(("sca", lambda: results.__setitem__(
                "sca", run_snyk_test(target, out_dir, self._emit_log)[0])))
            self.after(0, lambda: self._start_stage_pulse("sca"))
        if "code" in sel and _snyk_usable:
            jobs.append(("code", lambda: results.__setitem__(
                "code", run_snyk_code(target, out_dir, self._emit_log)[0])))
            self.after(0, lambda: self._start_stage_pulse("code"))
        if "secrets" in sel:
            def _run_secrets_stage():
                self._emit_log("[secrets] running secret scan…")
                result = scan_path(target, self._emit_log, cancel=self._static_cancel_evt,
                                   git_secrets_status=get_git_secrets_status(),
                                   progress=lambda n, t: self._event_queue.put(
                                       ("card_progress", ("secrets", n, t))))
                sec_dir = out_dir / "secrets"
                write_secrets_report(result, sec_dir)
                self._emit_log(f"[secrets] {result['total']} finding(s) across "
                               f"{result['scanned_files']} file(s)")
                results["secrets"] = result
            jobs.append(("secrets", _run_secrets_stage))

        def run_stage(item):
            key, fn = item
            try:
                fn(); self._event_queue.put(("stage", (key, "done")))
            except Exception as e:
                self._event_queue.put(("stage", (key, "failed")))
                failed_stages.add(key)
                self._emit_log(f"[static] {key} failed: {e!r}")
                if getattr(e, "is_auth", False):
                    self._event_queue.put(("auth_required", None))

        try:
            if len(jobs) > 1:
                self._emit_log(f"[static] running {len(jobs)} analyses concurrently")
                with ThreadPoolExecutor(max_workers=len(jobs)) as ex_:
                    list(ex_.map(run_stage, jobs))
            else:
                for j in jobs: run_stage(j)

            if failed_stages:
                # A stage that errored out must never be silently reported as
                # "0 findings, all clear" — say so loudly, before the report
                # is built, so it can't be missed in the log.
                self._emit_log(
                    "[static] ⚠ " + "/".join(sorted(failed_stages)).upper() +
                    " no se completó — el resultado de este objetivo es "
                    "INCOMPLETO, no interprete el total como un escaneo limpio.")

            # Persist each completed kind so later cumulative reports stay complete.
            state = self._scan_state
            for kind in ("sca", "code", "secrets"):
                raw = results.get(kind)
                if raw is not None:
                    try:
                        state.save_kind(kind, raw, target=str(target), snyk_version=v, mode=mode)
                        self._emit_log(f"[state] {kind} result persisted")
                    except Exception as e:
                        self._emit_log(f"[state] could not save {kind}: {e!r}")

            ctx = build_cumulative_context(state, target_hint=target,
                                           snyk_version_hint=v, current_results=results)
            ctx["scan_mode"] = mode
            ctx["failed_stages"] = sorted(failed_stages)
            ctx["incomplete"] = bool(failed_stages)
            # Full set of folders queued for this batch run (multi-folder static
            # scan) — each folder gets its own report, but every report should
            # still show the complete list configured for the batch, not just
            # the single target it covers.
            _batch = getattr(self, "_static_targets", None) or [target]
            ctx["batch_targets"] = [str(Path(t).resolve()) for t in _batch]
            self._emit_log("[report] building cumulative report (all scan types merged)")
            _base = _report_basename(self._user, mode)
            report_html = render_html(ctx, out_dir, filename=f"{_base}.html")
            self._emit_log(f"[report] HTML → {report_html}")
            try:
                csv_path = export_csv(ctx, out_dir / f"{_base}.csv", report_label=_report_label)
                self._emit_log(f"[report] CSV bundle (ZIP): {csv_path}")
            except Exception as e:
                self._emit_log(f"[report] CSV export skipped: {e!r}")
            sec_html_src = out_dir / "secrets" / "secrets.html"
            if sec_html_src.exists():
                try:
                    sec_html_dst = out_dir / f"{_base}_secrets.html"
                    shutil.copyfile(sec_html_src, sec_html_dst)
                    self._emit_log(f"[report] Secrets HTML → {sec_html_dst}")
                except Exception as e:
                    self._emit_log(f"[report] secrets HTML copy skipped: {e!r}")
            try:
                sarif_path = export_sarif(out_dir)
                if sarif_path: self._emit_log(f"[report] SARIF: {sarif_path}")
            except Exception as e:
                self._emit_log(f"[report] SARIF export skipped: {e!r}")
            try:
                merged_path = export_merged_json(out_dir)
                if merged_path: self._emit_log(f"[report] merged JSON: {merged_path}")
            except Exception as e:
                self._emit_log(f"[report] merged JSON skipped: {e!r}")

            meta = {
                "generated_at": ctx["generated_at"], "target": ctx["target"], "mode": mode,
                "counts": ctx["counts"], "total": ctx["total"],
                "sca_total": ctx.get("sca_total", 0), "code_total": ctx.get("code_total", 0),
                "dast_total": ctx.get("dast_total", 0), "api_total": ctx.get("api_total", 0),
                "secrets_total": ctx.get("secrets_total", 0), "snyk_version": ctx.get("snyk_version", ""),
                "failed_stages": sorted(failed_stages), "incomplete": bool(failed_stages),
            }
            (out_dir / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
            try:
                rec = update_history_after_scan(reports_root, ctx, meta,
                                                actor=getattr(self, "_user", ""), report_dir=out_dir)
                self._emit_log(f"[history] recorded — remediated {rec.get('remediated_count', 0)}, "
                               f"new {rec.get('introduced_count', 0)}")
            except Exception as e:
                self._emit_log(f"[history] could not update: {e!r}")
            if active_app and active_app.get("id"):
                try:
                    self._inv_store.record_scan(active_app["id"], meta)
                    self._event_queue.put(("inv_refresh", active_app["id"]))
                except Exception as e:
                    self._emit_log(f"[inventory] could not update: {e!r}")

            self._last_context = ctx; self._last_report_dir = out_dir
            self._last_static_report = Path(report_html)
            audit_log.write_event(reports_root, "scan_end", actor=self._user,
                                  app=(active_app.get("name") if active_app else ""),
                                  mode=mode, total=ctx.get("total", 0), counts=ctx.get("counts", {}),
                                  report=str(report_html), lane="static",
                                  failed_stages=sorted(failed_stages), incomplete=bool(failed_stages),
                                  cancelled=self._static_cancel_evt.is_set(), log=self._emit_log)
            self._event_queue.put(("static_results", ctx))
            # Part of a multi-folder batch (route_total > 1) → bookkeeping
            # only (recents list, buttons), no auto-open; the batch index
            # built once the whole loop finishes is the one primary report.
            self._event_queue.put(("report", {"path": str(report_html), "primary": route_total == 1}))
            return {"path": str(target), "scanned": True, "report_path": str(report_html),
                    "counts": dict(ctx.get("counts", {})), "total": ctx.get("total", 0)}
        except Exception as e:
            self._emit_log(f"[static] scan failed: {e!r}")
            audit_log.write_event(reports_root, "scan_failed", actor=self._user,
                                  app=(active_app.get("name") if active_app else ""),
                                  mode=mode, lane="static", error=repr(e), log=self._emit_log)
            self._event_queue.put(("static_results", None))
            return {"path": str(target), "scanned": False, "reason": f"error: {e}"}
        finally:
            # Whether it finished or errored gracefully, the run is over — clear
            # the crash-recovery marker (it only survives a hard kill/close).
            self._session_end("static")


# ── CLI smoke test: python static_scanner.py <folder> ─────────────────────────
if __name__ == "__main__":
    tgt = sys.argv[1] if len(sys.argv) > 1 else "."
    st = ensure_git_secrets(print)
    res = scan_path(tgt, print, git_secrets_status=st)
    out = write_secrets_report(res, Path(tgt) / "_secrets_out")
    print("secrets report:", out)

